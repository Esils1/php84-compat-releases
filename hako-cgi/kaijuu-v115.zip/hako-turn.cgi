#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.20
# 턴진행모듈(ver1.03)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 괴수퇴치제도 ver1.15
# 턴진행모듈(ver1.10)
# Arranged by 차차마루
# 사용 조건등은,readme.txt 파일을 참조
# 배포페이지: http://www.geocities.co.jp/SiliconValley-Bay/2566/
#
# [이력]
# v1.00 2000/03/12 처음판
# 2000/05/07 일반배포시작
# v1.10 2000/06/11
# 2000/07/01 bug fixed
#----------------------------------------------------------------------


package H2;

#주변 2헥스의 좌표
my(@ax) = (0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
my(@ay) = (0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);
# 토마호크용 주변 1헥스 좌표
my(@sax) = (0, 1, 1, 1, 0,-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
my(@say) = (0,-1, 0, 1, 1, 0,-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

#----------------------------------------------------------------------
# 섬 신규 생성 모드
#----------------------------------------------------------------------
# 메인
sub newIslandMain {
 # 섬이 가득 차서 없습니까 확인
 if($H2::islandNumber>= $H2::maxIsland) {
	unlock();
	tempNewIslandFull();
	return;
 }

 # 이름이 있는 지 확인
 if($H2::currentName eq '') {
	unlock();
	tempNewIslandNoName();
	return;
 }

 # 이름이 유효한지 확인
 if($H2::currentName =~ /[,\?\(\)\<\>\$]|^무인$/) {
	# 사용 불가 이름
	unlock();
	tempNewIslandBadName();
	return;
 }

 # 이름의 중복 확인
 if(nameToNumber($H2::currentName) != -1) {
	# 이미 발견완료
	unlock();
	tempNewIslandAlready();
	return;
 }

 # password 의존재판정
 if($H2::inputPassword eq '') {
	# password 무시
	unlock();
	tempNewIslandNoPassword();
	return;
 }

 # 확인용 비밀번호
 if($H2::inputPassword2 ne $H2::inputPassword) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 새 섬의 번호 정하기
 $H2::currentNumber = $H2::islandNumber;
 $H2::islandNumber++;
 $H2::islands[$H2::currentNumber] = makeNewIsland();
 my($island) = $H2::islands[$H2::currentNumber];

 # 각종의 값을 설정
 $island->{'name'} = $H2::currentName;
 $island->{'id'} = $H2::islandNextID;
 $H2::islandNextID ++;
 $island->{'absent'} = $H2::giveupTurn - 3;

 # 리도와 호스트(가져오지 못한 경우에는 IP 주소)을 처리해 코멘트 데이터에 추가
 my($host) = $ENV{'REMOTE_HOST'};
 my($addr) = $ENV{'REMOTE_ADDR'};
 if ($host eq '') { $host = $addr; }
 if ($host eq $addr) { $host = gethostbyaddr(pack('C4',split(/\./,$host)),2) || $addr; }
 $island->{'comment'} = '(미 등록)'."\t". $host;### 탭 구분

 $island->{'password'} = encode($H2::inputPassword);

 # 인구기타 산출
 estimate($H2::currentNumber);

 # 데이터 쓰기
 writeIslandsFile($island->{'id'});
 logDiscover($H2::currentName); # 로그

 # 개방
 unlock();

 # 발견 화면
 tempNewIslandHead($H2::currentName); # 발견했습니다!!
 islandInfo(); # 섬의 정보
 islandMap(1); # 섬 지도, 소유자 모드
}

# 새 섬 만들기
sub makeNewIsland {
 # 지형을 만들기
 my($land, $landValue) = makeNewLand();

 # 초기 명령을 생성
 my(@command, $i);
 for($i = 0; $i < $H2::commandMax; $i++) {
	 $command[$i] = {
	 'kind' => $H2::comDoNothing,
	 'target' => 0,
	 'x' => 0,
	 'y' => 0,
	 'arg' => 0
	 };
 }

 # 초기 게시판 생성
 my(@lbbs);
 for($i = 0; $i < $H2::lbbsMax; $i++) {
	 $lbbs[$i] = "0>>";
 }

 # 섬으로 반환
 return {
	'land' => $land,
	'landValue' => $landValue,
	'command' => \@command,
	'lbbs' => \@lbbs,
	'money' => $H2::initialMoney,
	'food' => $H2::initialFood,
	'prize' => '0,0,',
### ---v--- ver1.10 ---v---
	'score' => 0,
	'sturn' => $H2::islandTurn
### ---^--- ver1.10 ---^---
 };
}

# 새 섬 지형 만들기
sub makeNewLand {
 # 기본형 생성
 my(@land, @landValue, $x, $y, $i);

 # 바다에 초기화
 for($y = 0; $y < $H2::islandSize; $y++) {
	 for($x = 0; $x < $H2::islandSize; $x++) {
	 $land[$x][$y] = $H2::landSea;
	 $landValue[$x][$y] = 0;
	 }
 }

 # 섬 중앙 4×4에 황무지를 배치
 my($center) = $H2::islandSize / 2 - 1;
 for($y = $center - 1; $y < $center + 3; $y++) {
	 for($x = $center - 1; $x < $center + 3; $x++) {
	 $land[$x][$y] = $H2::landWaste;
	 }
 }

 # 8*8범위내에육지를 증식
 for($i = 0; $i < 120; $i++) {
	 # 무작위좌표
	 $x = random(8) + $center - 3;
	 $y = random(8) + $center - 3;

	 my($tmp) = countAround(\@land, $x, $y, $H2::landSea, 7);
	 if(countAround(\@land, $x, $y, $H2::landSea, 7) != 7){
	 # 주변에 육지가 있는 경우, 얕은 바다로
	 # 얕은 바다는 황무지로
	 # 황무지는 평지로
	 if($land[$x][$y] == $H2::landWaste) {
		 $land[$x][$y] = $H2::landPlains;
		 $landValue[$x][$y] = 0;
	 } else {
		 if($landValue[$x][$y] == 1) {
 $land[$x][$y] = $H2::landWaste;
 $landValue[$x][$y] = 0;
		 } else {
		 $landValue[$x][$y] = 1;
		 }
	 }
	 }
 }

 # 숲을 만들기
 my($count) = 0;
 while($count < 4) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이이미 숲이 아니면, 숲을 만들기
	 if($land[$x][$y] != $H2::landForest) {
	 $land[$x][$y] = $H2::landForest;
	 $landValue[$x][$y] = 5; # 처음은500본
	 $count++;
	 }
 }

 # 마을을 만들기
 $count = 0;
 while($count < 2) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲이나 도시가 아니면 도시를 만들기
	 if(($land[$x][$y] != $H2::landTown) &&
	 ($land[$x][$y] != $H2::landForest)) {
	 $land[$x][$y] = $H2::landTown;
	 $landValue[$x][$y] = 5; # 처음은500인
	 $count++;
	 }
 }

 # 산을 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲이나 도시가 아니면 도시를 만들기
	 if(($land[$x][$y] != $H2::landTown) &&
	 ($land[$x][$y] != $H2::landForest)) {
	 $land[$x][$y] = $H2::landMountain;
	 $landValue[$x][$y] = 0; # 처음은 채굴장없음
	 $count++;
	 }
 }

 # 기지를 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $H2::landTown) &&
	 ($land[$x][$y] != $H2::landForest) &&
	 ($land[$x][$y] != $H2::landMountain)) {
	 $land[$x][$y] = $H2::landBase;
	 $landValue[$x][$y] = 0;
	 $count++;
	 }
 }

 return (\@land, \@landValue);
}

#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeMain {
 # id에서 섬을 가져옴
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];
 my($flag) = 0;

 # 비밀번호 확인
 if($H2::oldPassword eq $H2::specialPassword) {
	# 특수 비밀번호
	$island->{'money'} = 9999;
	$island->{'food'} = 9999;
 } elsif(!checkPassword($island->{'password'},$H2::oldPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 확인용 비밀번호
 if($H2::inputPassword2 ne $H2::inputPassword) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($H2::currentName ne '') {
	# 이름 변경의 경우
	# 이름이 유효한지 확인
	if($H2::currentName =~ /[,\?\(\)\<\>]|^무인$/) {
	 # 사용 불가 이름
	 unlock();
	 tempNewIslandBadName();
	 return;
	}

	# 이름의 중복 확인
	if(nameToNumber($H2::currentName) != -1) {
	 # 이미 발견완료
	 unlock();
	 tempNewIslandAlready();
	 return;
	}

	if($island->{'money'} < $H2::costChangeName) {
	 # 자금 부족
	 unlock();
	 tempChangeNoMoney();
	 return;
	}

	# 대금
	if($H2::oldPassword ne $H2::specialPassword) {
	 $island->{'money'} -= $H2::costChangeName;
	}

	# 이름을 변경
	logChangeName($island->{'name'}, $H2::currentName);
	$island->{'name'} = $H2::currentName;
	$flag = 1;
 }

 # password 변경의 경우
 if($H2::inputPassword ne '') {
	# 비밀번호를 변경
	$island->{'password'} = encode($H2::inputPassword);
	$flag = 1;
 }

 if(($flag == 0) && ($H2::oldPassword ne $H2::specialPassword)) {
	# 어느 쪽도 변경되어 있지 않음
	unlock();
	tempChangeNothing();
	return;
 }

 # 데이터 쓰기
 writeIslandsFile($H2::currentID);
 unlock();

 # 변경성공
 tempChange();
}

#----------------------------------------------------------------------
# 턴진행 모드
#----------------------------------------------------------------------
# 메인
sub turnMain {
 # 최종 갱신 시간을 갱신
 $H2::islandLastTime += $H2::unitTime;

 # 로그 파일을 뒤에밀기
 my($i, $j, $s, $d);
 for($i = ($H2::logMax - 1); $i>= 0; $i--) {
	$j = $i + 1;
	my($s) = "${H2::dirName}/hakojima.log$i";
	my($d) = "${H2::dirName}/hakojima.log$j";
	unlink($d);
	rename($s, $d);
 }

 # 좌표배열을 만들기
 makeRandomPointArray();

 # 턴번호
 $H2::islandTurn++;

 # 순서결메
 my(@order) = randomArray($H2::islandNumber);

 # 수입, 소비단계
 for($i = 0; $i < $H2::islandNumber; $i++) {
	estimate($order[$i]);
	income($H2::islands[$order[$i]]);

	# 턴시작전의 인구를 메모루
	$H2::islands[$order[$i]]->{'oldPop'} = $H2::islands[$order[$i]]->{'pop'};
 }

 # 괴수 이동
 for($i = 0; $i < $H2::islandNumber; $i++) {
	doMoveMonster($H2::islands[$order[$i]]);
 }

 # 명령 처리
 for($i = 0; $i < $H2::islandNumber; $i++) {
	# 반환 값1이 이 될 시까지 반복
	while(doCommand($H2::islands[$order[$i]]) == 0){};
 }

 # 성장 및 단일 헥스 재해
 for($i = 0; $i < $H2::islandNumber; $i++) {
	doEachHex($H2::islands[$order[$i]]);
 }

 # 섬 전체 처리
 my($remainNumber) = $H2::islandNumber;
 my($island);
 for($i = 0; $i < $H2::islandNumber; $i++) {
	$island = $H2::islands[$order[$i]];
	doIslandProcess($order[$i], $island);

	# 사멸판정(원인업와 같은)
	if($island->{'dead'} == 1) {
	 $island->{'pop'} = 0;
	 $island->{'score'} = -999999999;
	 $remainNumber--;
	} elsif($island->{'pop'} == 0) {
	 $island->{'dead'} = 1;
	 $island->{'score'} = -999999999;
	 $remainNumber--;
	 # 사멸 메시지
	 my($tmpid) = $island->{'id'};
	 logDead($tmpid, $island->{'name'});
	 unlink("island.$tmpid");
	}
 }

 # 포인트순에정렬
 islandSort();



 # 시상 대상 턴이면, 그 처리
 if(($H2::islandTurn % $H2::turnPrizeUnit) == 0) {
	my($island) = $H2::islands[0];
	logPrize($island->{'id'}, $island->{'name'}, "$H2::islandTurn${H2::prize[0]}");
	$island->{'prize'}.= "${H2::islandTurn},";
 }

 # 섬 수자르기
 $H2::islandNumber = $remainNumber;

 # 백업 턴이면 삭제 전에 rename
 if(($H2::islandTurn % $H2::backupTurn) == 0) {
	my($i);
	my($tmp) = $H2::backupTimes - 1;
	myrmtree("${H2::dirName}.bak$tmp");
	for($i = ($H2::backupTimes - 1); $i> 0; $i--) {
	 my($j) = $i - 1;
	 rename("${H2::dirName}.bak$j", "${H2::dirName}.bak$i");
	}
	rename("${H2::dirName}", "${H2::dirName}.bak0");
	mkdir("${H2::dirName}", $H2::dirMode);

	# 로그 파일만 복구
	for($i = 0; $i <= $H2::logMax; $i++) {
	 rename("${H2::dirName}.bak0/hakojima.log$i",
		 "${H2::dirName}/hakojima.log$i");
	}
	rename("${H2::dirName}.bak0/hakojima.his",
	 "${H2::dirName}/hakojima.his");
 }

 # 파일에쓰기
 writeIslandsFile(-1);

 # 로그 쓰기
 logFlush();

 # 기록 로그 조정
 logHistoryTrim();

 # 맨 위로
 topPageMain();
}

# 디렉터리 삭제
sub myrmtree {
 my($dn) = @_;
 opendir(DIN, "$dn/");
 my($fileName);
 while($fileName = readdir(DIN)) {
	unlink("$dn/$fileName");
 }
 closedir(DIN);
 rmdir($dn);
}

# 수입, 소비단계
sub income {
 my($island) = @_;
 my($pop, $farm, $factory, $mountain) =
	(
	 $island->{'pop'},
	 $island->{'farm'} * 10,
	 $island->{'factory'},
	 $island->{'mountain'}
	 );

 # 수입
 if($pop> $farm) {
	# 농업만으로 인력이 남는 경우
	$island->{'food'} += $farm; # 농장 전체가동

	# 정전판정
	if(($factory + $mountain> 200) && (random(1000) < $H2::disTeiden)) {# 공업인구20만을 초과 이 경우
		# 정전발생
		my($fact_mount) = '';
		if(($factory> 0) && ($mountain> 0)) { $fact_mount = '공장, 채굴장'; }
		elsif($factory> 0) { $fact_mount = '공장'; }
		elsif($mountain> 0) { $fact_mount = '채굴장'; }
		logTeiden($island->{'id'}, $island->{'name'}, $fact_mount);
	} else {
	$island->{'money'} +=
	 min(int(($pop - $farm) / 10),
		 $factory + $mountain);
	}
 } else {
	# 농장 규모가 최대치인 경우
	$island->{'food'} += $pop; # 전체나 생 직원일
 }

 # 식량소비

 # 대식 대회판정
 if(($island->{'food'}> 5000) && (random(1000) < $H2::disOogui)) {# 식량50만을 초과 이 경우
	# 대식 대회개최
	logOogui($island->{'id'}, $island->{'name'});
	$island->{'food'} = int(($island->{'food'}) - ($pop * $H2::eatenFood * 4));# 4배의 소비(일반 소비와 합쳐5배)
 }
 $island->{'food'} = int(($island->{'food'}) - ($pop * $H2::eatenFood));# 일반 소비
}


# 명령 단계
sub doCommand {
 my($island) = @_;

 # 명령 처리 시작
 my($comArray, $command);
 $comArray = $island->{'command'};
 $command = $comArray->[0]; # 첫 항목을 꺼냄
 slideFront($comArray, 0); # 이후를 막힘하기

 # 각 요소 꺼내기
 my($kind, $target, $x, $y, $arg) =
	(
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($landKind) = $land->[$x][$y];
 my($lv) = $landValue->[$x][$y];
 my($cost) = $H2::comCost[$kind];
 my($comName) = $H2::comName[$kind];
 my($point) = "($x, $y)";
 my($landName) = landName($landKind, $lv);
### ---v--- ver1.10 ---v---
 my($sturn) = $island->{'sturn'};
### ---^--- ver1.10 ---^---

 if($kind == $H2::comDoNothing) {
	# 자금 조달
	logDoNothing($id, $name, $comName);
	$island->{'money'} += 10;
	$island->{'absent'} ++;

	# 자동포기
	if($island->{'absent'}>= $H2::giveupTurn) {
	 $comArray->[0] = {
		'kind' => $H2::comGiveup,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0
	 }
	}
	return 1;
 }

 $island->{'absent'} = 0;

 # 비용 확인
 if($cost> 0) {
	# 금의 경우
	if($island->{'money'} < $cost) {
	 logNoMoney($id, $name, $comName);
	 return 0;
	}
 } elsif($cost < 0) {
	# 식량의 경우
	if($island->{'food'} < (-$cost)) {
	 logNoFood($id, $name, $comName);
	 return 0;
	}
 }

 # 명령에서 분기
 if(($kind == $H2::comPrepare) ||
 ($kind == $H2::comPrepare2)) {
	# 개간, 땅고르기
	if(($landKind == $H2::landSea) ||
	 ($landKind == $H2::landSbase) ||
	 ($landKind == $H2::landOil) ||
	 ($landKind == $H2::landMountain) ||
### ---v--- ver1.10 ---v---
	 ($landKind == $H2::landMonsterS) ||
### ---^--- ver1.10 ---^---
	 ($landKind == $H2::landMonster)) {
	 # 바다, 해저 기지, 유전, 산, 괴수는 개간할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 대상 위치를 평지로
	$land->[$x][$y] = $H2::landPlains;
	$landValue->[$x][$y] = 0;
	logLandSuc($id, $name, '개간', $point);

	# 돈을 차감
	$island->{'money'} -= $cost;

	if($kind == $H2::comPrepare2) {
	 # 땅고르기
	 $island->{'prepare2'}++;

	 # 턴 소비하지 않고
	 return 0;
	} else {
	 # 땅고르기이면 매장금 발견 가능성 있음
	 if(random(1000) < $H2::disMaizo) {
		my($v) = 300 + random(701);### 300~1000
		$island->{'money'} += $v;
		logMaizo($id, $name, $comName, $v);
	 }
	 return 1;
	}
 } elsif($kind == $H2::comReclaim) {
	# 매립
	if(($landKind != $H2::landSea) &&
	 ($landKind != $H2::landOil) &&
	 ($landKind != $H2::landSbase)) {
	 # 바다, 해저 기지, 유전만매립할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 주변에육이 있는 지 확인
	my($seaCount) =
	 countAround($land, $x, $y, $H2::landSea, 7) +
	 countAround($land, $x, $y, $H2::landOil, 7) +
	 countAround($land, $x, $y, $H2::landSbase, 7);
 if($seaCount == 7) {
	 # 전체 바다다에서 매립불능
	 logNoLandAround($id, $name, $comName, $point);
	 return 0;
	}

	if(($landKind == $H2::landSea) && ($lv == 1)) {
	 # 얕은 바다의 경우
	 # 대상 위치를 황무지로
	 $land->[$x][$y] = $H2::landWaste;
	 $landValue->[$x][$y] = 0;
	 logLandSuc($id, $name, $comName, $point);
	 $island->{'area'}++;

	 if($seaCount <= 4) {
		# 주변 바다가 3헥스 이내이므로, 얕은 바다로
		my($i, $sx, $sy);

		for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		 }

		 if(($sx < 0) || ($sx>= $H2::islandSize) ||
		 ($sy < 0) || ($sy>= $H2::islandSize)) {
		 } else {
			# 범위 안의 경우
			if($land->[$sx][$sy] == $H2::landSea) {
			 $landValue->[$sx][$sy] = 1;
			}
		 }
		}
	 }
	} else {
	 # 바다, 해저 기지, 유전라면, 대상 위치를 얕은 바다로
	 $land->[$x][$y] = $H2::landSea;
	 $landValue->[$x][$y] = 1;
	 logLandSuc($id, $name, $comName, $point);
	}

	# 돈을 차감
	$island->{'money'} -= $cost;

	# 횟수 지정이면, 명령을 되돌림
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;
 } elsif($kind == $H2::comDestroy) {
	# 굴착
	if(($landKind == $H2::landSbase) ||
	 ($landKind == $H2::landOil) ||
### ---v--- ver1.10 ---v---
	 ($landKind == $H2::landMonsterS) ||
### ---^--- ver1.10 ---^---
	 ($landKind == $H2::landMonster)) {
	 # 해저 기지, 유전, 괴수는 굴착할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	if(($landKind == $H2::landSea) && ($lv == 0)) {
	 # 바다이면 유전 탐사 시
	 # 투자액결정
	 if($arg == 0) { $arg = 1; }
	 my($value, $str, $p);
	 $value = min($arg * ($cost), $island->{'money'});
	 $str = "$value$H2::unitMoney";
	 $p = int($value / $cost);
	 $island->{'money'} -= $value;

	 # 보기사용는 가판정
	 if($p> random(100)) {
		# 유전보기사용루
		logOilFound($id, $name, $point, $comName, $str);
		$land->[$x][$y] = $H2::landOil;
		$landValue->[$x][$y] = 0;
	 } else {
		# 헛발사치에끝나쁨
		logOilFail($id, $name, $point, $comName, $str);
	 }
	 return 1;
	}

	# 대상 위치를 바다로 변경. 산이면 황무지로, 얕은 바다이면 바다로 변경.
	if($landKind == $H2::landMountain) {
	 $land->[$x][$y] = $H2::landWaste;
	 $landValue->[$x][$y] = 0;
	} elsif($landKind == $H2::landSea) {
	 $landValue->[$x][$y] = 0;
	} else {
	 $land->[$x][$y] = $H2::landSea;
	 $landValue->[$x][$y] = 1;
	 $island->{'area'}--;
	}
	logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $H2::comSellTree) {
	# 벌채
	if($landKind != $H2::landForest) {
	 # 숲이외는 벌채할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 대상 위치를 평지로
	$land->[$x][$y] = $H2::landPlains;
	$landValue->[$x][$y] = 0;
	logLandSuc($id, $name, $comName, $point);

	# 매각금을 얻기루
	$island->{'money'} += $H2::treeValue * $lv;
	return 1;
 } elsif(($kind == $H2::comPlant) ||
	 ($kind == $H2::comFarm) ||
	 ($kind == $H2::comFactory) ||
	 ($kind == $H2::comBase) ||
	 ($kind == $H2::comMonument) ||
	 ($kind == $H2::comHaribote) ||
	 ($kind == $H2::comHoihoi) ||
	 ($kind == $H2::comDbase)) {

	# 지상건설계
	if(!
	 (($landKind == $H2::landPlains) ||
	 ($landKind == $H2::landTown) ||
# 기념비 발사를 사용할 경우 아래 ##을 삭제
##	 (($landKind == $H2::landMonument) && ($kind == $H2::comMonument)) ||
	 (($landKind == $H2::landFarm) && ($kind == $H2::comFarm)) ||
	 (($landKind == $H2::landFactory) && ($kind == $H2::comFactory)) ||
	 (($landKind == $H2::landDefence) && ($kind == $H2::comDbase)))) {
	 # 부적절나 지형
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 종류에서 분기
	if($kind == $H2::comPlant) {
	 # 대상 위치를 숲로.
	 $land->[$x][$y] = $H2::landForest;
	 $landValue->[$x][$y] = 1; # 목은 최소단위
	 logPBSuc($id, $name, $comName, $point);
	} elsif($kind == $H2::comBase) {
	 # 대상 위치를 미사일 기지로.
	 $land->[$x][$y] = $H2::landBase;
	 $landValue->[$x][$y] = 0; # 경험치0
	 logPBSuc($id, $name, $comName, $point);
	} elsif($kind == $H2::comHaribote) {
	 # 대상 위치를 가짜 시설로
	 $land->[$x][$y] = $H2::landHaribote;
	 $landValue->[$x][$y] = 0;
	 logHariSuc($id, $name, $comName, $H2::comName[$H2::comDbase], $point);
	} elsif($kind == $H2::comHoihoi) {
### ---v--- ver1.10 ---v---
	 if(countAround($land, $x, $y, $H2::landMonster, 7) +
	 countAround($land, $x, $y, $H2::landMonsterS, 7)) {
### ---^--- ver1.10 ---^---
		# 주변가괴수다에서 설치불능
		logMonAround($id, $name, $comName, $point);
		return 0;
	 } else {
		# 대상 위치를 방어 시설에
		$land->[$x][$y] = $H2::landHoihoi;
		$landValue->[$x][$y] = 0;
	 	logLandSuc($id, $name, $comName, $point);
	 }
	} elsif($kind == $H2::comFarm) {
	 # 농장
	 if($landKind == $H2::landFarm) {
		# 이미 농장의 경우
		$landValue->[$x][$y] += 2; # 규모 + 2000인
		if($landValue->[$x][$y]> 50) {
		 $landValue->[$x][$y] = 50; # 최대 50000인
		}
	 } else {
		# 대상 위치를 농장에
		$land->[$x][$y] = $H2::landFarm;
		$landValue->[$x][$y] = 10; # 규모 = 10000인
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $H2::comFactory) {
	 # 공장
	 if($landKind == $H2::landFactory) {
		# 이미 공장의 경우
		$landValue->[$x][$y] += 10; # 규모 + 10000인
		if($landValue->[$x][$y]> 100) {
		 $landValue->[$x][$y] = 100; # 최대 100000인
		}
	 } else {
		# 대상 위치를 공장에
		$land->[$x][$y] = $H2::landFactory;
		$landValue->[$x][$y] = 30; # 규모 = 10000인
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $H2::comDbase) {
	 # 방위 시설
	 if($landKind == $H2::landDefence) {
		# 이미 방위 시설인 경우
		$landValue->[$x][$y] = 1; # 자폭장치 설정
		logBombSet($id, $name, $landName, $point);
	 } else {
		# 대상 위치를 방위 시설에
		$land->[$x][$y] = $H2::landDefence;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
	 }
	} elsif($kind == $H2::comMonument) {
	 # 기념비
	 if($landKind == $H2::landMonument) {
		# 이미 기념비인 경우
		# 대상 가져오기
		my($tn) = $H2::idToNumber{$target};
		if($tn eq '') {
		 # 대상이 이미 없음
		 # 아무 메시지도 출력하지 않음
		 return 0;
		}
		my($tIsland) = $H2::islands[$tn];
		$tIsland->{'bigmissile'}++;

		# 그장소는 황무지에
		$land->[$x][$y] = $H2::landWaste;
		$landValue->[$x][$y] = 0;
		logMonFly($id, $name, $landName, $point);
	 } else {
		# 대상 위치를 기념비에
		$land->[$x][$y] = $H2::landMonument;
		if($arg>= $H2::monumentNumber) {
		 $arg = 0;
		}
		$landValue->[$x][$y] = $arg;
		logLandSuc($id, $name, $comName, $point);
	 }
	}

	# 돈을 차감
	$island->{'money'} -= $cost;

	# 횟수 지정이면, 명령을 되돌림
	if(($kind == $H2::comFarm) ||
	 ($kind == $H2::comFactory)) {
	 if($arg> 1) {
		my($command);
		$arg--;
		slideBack($comArray, 0);
		$comArray->[0] = {
		 'kind' => $kind,
		 'target' => $target,
		 'x' => $x,
		 'y' => $y,
		 'arg' => $arg
		 };
	 }
	}
	return 1;
 } elsif($kind == $H2::comMountain) {
	# 채굴장
	if($landKind != $H2::landMountain) {
	 # 산이외에는 만들 수 없음
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	$landValue->[$x][$y] += 5; # 규모 + 5000인
	if($landValue->[$x][$y]> 200) {
	 $landValue->[$x][$y] = 200; # 최대 200000인
	}
	logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;

	# 횟수 지정이면, 명령을 되돌림
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;
 } elsif($kind == $H2::comSbase) {
	# 해저 기지
	if(($landKind != $H2::landSea) || ($lv != 0)){
	 # 바다이외에는 만들 수 없음
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	$land->[$x][$y] = $H2::landSbase;
	$landValue->[$x][$y] = 0; # 경험치0
	logLandSuc($id, $name, $comName, '(?, ?)');

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;
 } elsif(($kind == $H2::comMissileNM) ||
	 ($kind == $H2::comMissilePP) ||
	 ($kind == $H2::comMissileST) ||
	 ($kind == $H2::comMissileTH) ||
	 ($kind == $H2::comMissileSPP) ||
	 ($kind == $H2::comMissileSTI) ||
	 ($kind == $H2::comMissileLD)) {
	# 미사일계

### ---v--- ver1.10 ---v---
	# 미사일 발사허가?
	if((($H2::islandTurn - $sturn) <= $H2::noMissileTurn) && ($id != $target)) {
	 logNotPermitted($id, $name, $comName);
	 return 1;
	}
### ---^--- ver1.10 ---^---

	# 육지 파괴탄을 다른 섬에발사
	if(($kind == $H2::comMissileLD) && ($id != $target)) {
	 logMsNoOwnLD($id, $name, $comName);
	 return 1;
	}

	# 대상 가져오기
	my($tn) = $H2::idToNumber{$target};
	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

	my($flag) = 0;
	if($arg == 0) {
	 # 값이 0이면 공격 중인 대상만
	 $arg = 10000;
	}

	# 사전준비
	my($tIsland) = $H2::islands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty, $err);

	# 난민의 수
	my($boat) = 0;

	# 오차
	if(($kind == $H2::comMissilePP) ||
	 ($kind == $H2::comMissileSTI) ||
	 ($kind == $H2::comMissileSPP)) {
	 $err = 7;
	} else {
	 $err = 19;
	}

	# 자금이 부족하면 지정수량을 충족하거나 전체 기지 가격에 도달할 시까지 반복
	my($bx, $by, $count) = (0,0,0);
	while(($arg> 0) &&
	 ($island->{'money'}>= $cost)) {
	 # 기지를 찾을 시까지 반복
	 while($count < $H2::pointNumber) {
		$bx = $H2::rpx[$count];
		$by = $H2::rpy[$count];
		if((($land->[$bx][$by] == $H2::landBase) && ($kind != $H2::comMissileTH))||# 토마호크는 해저 기지에서 만
		 ($land->[$bx][$by] == $H2::landSbase)) {
		 last;
		}
		$count++;
	 }
	 if($count>= $H2::pointNumber) {
		# 찾을 수 없으면 그곳까지
		last;
	 }
	 # 최소하나기지가 있었던이므로,flag 을설립하고 있는
	 $flag = 1;

	 # 기지의 레벨을 산출
	 my($level) = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]);
	 # 기지내에서 루프
	 while(($level> 0) &&
		 ($arg> 0) &&
		 ($island->{'money'}>= $cost)) {### bug fixed
		# 명중이 확정이므로, 각 값을 소도
		$level--;
		$arg--;
		$island->{'money'} -= $cost;

		# 접속착탄환 발사실패
		if (($kind == $H2::comMissileSTI) && (random(200) == 0)) {
			# 경험치
			if(($land->[$bx][$by] == $H2::landBase) ||
			 ($land->[$bx][$by] == $H2::landSbase)) {
			 # 아직 기지인 경우만
			 if($landValue->[$bx][$by]> 0) {
				$landValue->[$bx][$by]--;
			 }
			}
			logMsFail($id, $target, $name, $tName, $comName, $point);
			next;
		}

		# 착탄 지점 산출
		if ($kind == $H2::comMissileTH) {
			# 토마호크
			my($r) = random(19);
			$tx = $x + $sax[$r];
			$ty = $y + $say[$r];
		} else {
			my($r) = random($err);
			$tx = $x + $ax[$r];
			$ty = $y + $ay[$r];
		}
		if((($ty % 2) == 0) && (($y % 2) == 1)) {
		 $tx--;
		}

		# 착탄 지점범위안팎 확인
		if(($tx < 0) || ($tx>= $H2::islandSize) ||
		 ($ty < 0) || ($ty>= $H2::islandSize)) {
		 # 범위 밖
		 if($kind == $H2::comMissileST) {
			# 스텔스
			logMsOutS($id, $target, $name, $tName,
				 $comName, $point);
		 } else {
			# 일반계
			logMsOut($id, $target, $name, $tName,
				 $comName, $point);
		 }
		 next;
		}

		# 착탄 지점의 지형등 산출
		my($tL) = $tLand->[$tx][$ty];
		my($tLv) = $tLandValue->[$tx][$ty];
		my($tLname) = landName($tL, $tLv);
		my($tPoint) = "($tx, $ty)";

		# 방위 시설 판정
	# 접속착탄은 방위 시설을 통과 합니다(방위 시설 판정하지 않음)
	unless($kind == $H2::comMissileSTI) {
		my($defence) = 0;
		if($H2::defenceHex[$id][$tx][$ty] == 1) {
		 $defence = 1;
		} elsif($H2::defenceHex[$id][$tx][$ty] == -1) {
		 $defence = 0;
		} else {
		 if($tL == $H2::landDefence) {
			# 방위 시설에 명중
			# 플래그를 지우기
			my($i, $count, $sx, $sy);
			for($i = 0; $i < 19; $i++) {
			 $sx = $tx + $ax[$i];
			 $sy = $ty + $ay[$i];

			 # 행 기준 위치 조정
			 if((($sy % 2) == 0) && (($ty % 2) == 1)) {
				$sx--;
			 }

			 if(($sx < 0) || ($sx>= $H2::islandSize) ||
			 ($sy < 0) || ($sy>= $H2::islandSize)) {
				# 범위 밖이면 아무것도 하지 않음
			 } else {
				# 범위 안의 경우
				$H2::defenceHex[$id][$sx][$sy] = 0;
			 }
			}
		 } elsif(countAround($tLand, $tx, $ty, $H2::landDefence, 19)) {
			$H2::defenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		 } else {
			$H2::defenceHex[$id][$tx][$ty] = -1;
			$defence = 0;
		 }
		}

		if($defence == 1) {
		 # 공안폭파
		 if($kind == $H2::comMissileST) {
			# 스텔스
			logMsCaughtS($id, $target, $name, $tName,
				 $comName, $point, $tPoint);
		 } else {
			# 일반계
			logMsCaught($id, $target, $name, $tName,
				 $comName, $point, $tPoint);
		 }
		 next;
		}
	}

		# '효과 없음' hex를 먼저 판정
		if((($tL == $H2::landSea) && ($tLv == 0))|| # 깊은 바다
		 ((($tL == $H2::landSea) || # 바다또는...
		 ($tL == $H2::landSbase) || # 해저 기지또는...
		 ($tL == $H2::landMountain)) # 산에서...
		 && ($kind != $H2::comMissileLD))) { # 육상 파괴탄이외
		 # 해저 기지는 바다처럼 표시
		 if($tL == $H2::landSbase) {
			$tL = $H2::landSea;
		 }
		 $tLname = landName($tL, $tLv);

		 # 무효화
		 if($kind == $H2::comMissileST) {
			# 스텔스
			logMsNoDamageS($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
		 } elsif ($kind == $H2::comMissileSTI) {
			# 접속착탄
			logMsNoDamageSTI($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 } else {
			# 일반계
			logMsNoDamage($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 }
		 next;
		}

		# 탄 종류에서 분기
		if($kind == $H2::comMissileLD) {
		 # 육지 파괴탄
		 if($tL == $H2::landMountain) {
			# 산(황무지가 됨)
			logMsLDMountain($id, $target, $name, $tName,
					 $comName, $tLname, $point, $tPoint);
			# 황무지가 됨
			$tLand->[$tx][$ty] = $H2::landWaste;
			$tLandValue->[$tx][$ty] = 0;
			next;

		 } elsif($tL == $H2::landSbase) {
			# 해저 기지
			logMsLDSbase($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
### ---v--- ver1.10 ---v---
		 } elsif(($tL == $H2::landMonster)||($tL == $H2::landMonsterS)) {
### ---^--- ver1.10 ---^---
			# 괴수
			logMsLDMonster($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
		 } elsif($tL == $H2::landSea) {
			# 얕은 바다
			logMsLDSea1($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 } else {
			# 기타
			logMsLDLand($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 }

		 # 경험치
		 if($tL == $H2::landTown) {
			if(($land->[$bx][$by] == $H2::landBase) ||
			 ($land->[$bx][$by] == $H2::landSbase)) {
			 # 아직 기지인 경우만
			 $landValue->[$bx][$by] += int($tLv / 20);
			 if($landValue->[$bx][$by]> $H2::maxExpPoint) {
				$landValue->[$bx][$by] = $H2::maxExpPoint;
			 }
			}
		 }

		 # 얕은 바다가 됨
		 $tLand->[$tx][$ty] = $H2::landSea;
		 $tIsland->{'area'}--;
		 $tLandValue->[$tx][$ty] = 1;

		 # 라도유전, 얕은 바다, 해저 기지였으면 바다
		 if(($tL == $H2::landOil) ||
			($tL == $H2::landSea) ||
		 ($tL == $H2::landSbase)) {
			$tLandValue->[$tx][$ty] = 0;
		 }
		} elsif($kind == $H2::comMissileSTI) {
		 # 접속착탄
### ---v--- ver1.10 ---v---
		 if(($tL == $H2::landMonster)||($tL == $H2::landMonsterS)) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($tLv);

			# 인공 괴수에는 효과가 없음
			if($mKind == 0) {
			 logMsMonNoDamage2($id, $target, $name, $tName, $comName, $mName, $point, $tPoint);
			 next;
			}

			# 착탄 지점?
			if($tL == $H2::landMonster) {
			 # 착탄 지점이 아님
			 $tLand->[$tx][$ty] = $H2::landMonsterS; # 접착
			 logMsMonStick($id, $target, $name, $tName, $comName, $mName, $point, $tPoint);
			} else {
			 # 착탄 지점
			 logMsMonNoDamage2($id, $target, $name, $tName, $comName, $mName, $point, $tPoint);
			}
##			# 격츠의 를나 하기
##			$arg = 0;
### ---^--- ver1.10 ---^---
		 } else {
			# 괴수이외는'효과 없음'
# 미사일 기지를 원형 보기에서 사용하지 않도록 설정의 경우 아래의 ## 두 곳을 삭제하면 됩니다
##			# 미사일 기지의 경우, 숲처럼 처리
##			if($tL == $H2::landBase) { $tL = $H2::landForest; }
			# 가짜 시설은 방위 시설처럼 처리
			if($tL == $H2::landHaribote) { $tL = $H2::landDefence; }
			$tLname = landName($tL, $tLv);
			logMsNoDamageSTI($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 }
		} else {
		 # 기타 미사일
		 my($MonKillFlag) = 0;# 괴수살상판정 flag
		 if($tL == $H2::landWaste) {
			# 황무지(피해없음)
			if($kind == $H2::comMissileST) {
			 # 스텔스
			 logMsWasteS($id, $target, $name, $tName,
					 $comName, $tLname, $point, $tPoint);
			} else {
			 # 일반
			 logMsWaste($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
			}
### ---v--- ver1.10 ---v---
		 } elsif(($tL == $H2::landMonster)||($tL == $H2::landMonsterS)) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($tLv);
### ---^--- ver1.10 ---^---
			my($special) = $H2::monsterSpecial[$mKind];

			# 경화 중?
			if((($special == 3) && (($H2::islandTurn % 2) == 1)) ||
			 (($special == 4) && (($H2::islandTurn % 2) == 0))) {
			 # 경화 중
			 if($kind == $H2::comMissileST) {
				# 스텔스
				logMsMonNoDamageS($id, $target, $name, $tName,
					 $comName, $mName, $point,
					 $tPoint);
			 } else {
				# 일반탄
				logMsMonNoDamage($id, $target, $name, $tName,
					 $comName, $mName, $point,
					 $tPoint);
			 }
			 next;
			} else {
			 # 경화 중이 아님
			 # SPP 이 경우체력2라도사망누
			 if(($mHp == 1) || (($mHp == 2) && ($kind == $H2::comMissileSPP))) {
				# 괴수를 처치했습니다
				# 포인트
				$island->{'score'} += $mHp * 2;# 체력분
				$island->{'score'} += $H2::monsterExp[$mKind] * 10;# 경험치분
				if(($land->[$bx][$by] == $H2::landBase) ||
				 ($land->[$bx][$by] == $H2::landSbase)) {
				 # 경험치
				 $landValue->[$bx][$by] += $H2::monsterExp[$mKind];
				 if($landValue->[$bx][$by]> $H2::maxExpPoint) {
					$landValue->[$bx][$by] = $H2::maxExpPoint;
				 }
				}

				if($kind == $H2::comMissileST) {
				 # 스텔스
				 logMsMonKillS($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				} else {
				 # 일반
				 logMsMonKill($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				}

				# flag 을설립하고 있는
				$MonKillFlag = 1;

				# 수입와 상금
				my($value) = $H2::monsterValue[$mKind];
				my($value2) = int($H2::monsterValue[$mKind]*0.7);
				if($value> 0) {
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($target, $mName, $value);
				 # 타 섬의 경우0.7배의 상금
				 if($id != $target) {
					$island->{'money'} += $value2;
					logMsMonMoneyH($id, $name, $mName, $value2);
				 }
				}

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $mKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
			 } else {
				# 괴수살아하고 있는
				if($kind == $H2::comMissileST) {
				 # 스텔스
				 logMsMonsterS($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				} else {
				 # 일반
				 logMsMonster($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				}
				# HP가 1 감소
				$tLandValue->[$tx][$ty]--;
				# 체력분 포인트
				$island->{'score'} += 2;
				# SPP 이 경우추가로 HP1감, 포인트추가
				if($kind == $H2::comMissileSPP) {
					$tLandValue->[$tx][$ty]--;
					$island->{'score'} += 2;
				}
				next;
			 }

			}
		 } else {
			# 일반 지형
			# 마이너스 포인트
			if(($id != $target) && ($tL != $H2::landPlains)) { # 다른 섬의 평지가 아님
			 # 마을 계열
			 if($tL == $H2::landTown) {
				$island->{'score'} -= int($tLv / 20) + 1;
			 # 농장
			 } elsif($tL == $H2::landFarm) {
				$island->{'score'} -= int(($tLv - 10) / 2) + 1;
			 # 공장
			 } elsif($tL == $H2::landFactory) {
				$island->{'score'} -= int(($tLv - 30) / 10) + 1;
			 # 미사일 기지
			 } elsif($tL == $H2::landBase) {
				my($tLevel) = expToLevel($tL, $tLv);
				$island->{'score'} -= $tLevel * 10;
			 # 해저 유전, 방어 시설
			 } elsif(($tL == $H2::landOil) || ($tL == $H2::landHoihoi)) {
				$island->{'score'} -= 50;
			 # 기타
			 } else {
				$island->{'score'} -= 1;
			 }
			}
			if($kind == $H2::comMissileST) {
			 # 스텔스
			 logMsNormalS($id, $target, $name, $tName,
					 $comName, $tLname, $point,
					 $tPoint);
			} else {
			 # 일반
			 logMsNormal($id, $target, $name, $tName,
					 $comName, $tLname, $point,
					 $tPoint);
			}
		 }
		 # 경험치
		 if($tL == $H2::landTown) {
			if(($land->[$bx][$by] == $H2::landBase) ||
			 ($land->[$bx][$by] == $H2::landSbase)) {
# 마을, 마을, 도시에 명중해도 기지에 경험치가 들어가도록 하려면 아래의 ##을 삭제
##			 $landValue->[$bx][$by] += int($tLv / 20);
			 $boat += $tLv; # 일반 미사일이므로 난민에플러스
			 if($landValue->[$bx][$by]> $H2::maxExpPoint) {
				$landValue->[$bx][$by] = $H2::maxExpPoint;
			 }
			}
		 }

 # 황무지가 됨
		 $tLand->[$tx][$ty] = $H2::landWaste;
		 unless(($tL == $H2::landWaste)&&(($tLv> 1))) { # 한 송이의 꽃은 무사
			$tLandValue->[$tx][$ty] = 1; # 착탄 지점
		 }
		 #라도괴수시와 메하면75%데한 송이의 꽃
		 if(($MonKillFlag == 1)&&(random(4)> 0)) {
			$tLandValue->[$tx][$ty] = 10; # 한 송이의 꽃
			LogMsFlowBloom($target, $tName, $tPoint);
		 }
		 # 라도유전였으면 바다
		 if($tL == $H2::landOil) {
			$tLand->[$tx][$ty] = $H2::landSea;
			$tLandValue->[$tx][$ty] = 0;
		 }
		}
	 }

	 # 카운트 증가
	 $count++;
	}


	if($flag == 0) {
	 # 기지가 하나도 없어진 경우
	 logMsNoBase($id, $name, $comName);
	 return 0;
	}

	# 난민판정
	$boat = int($boat / 2);
	if(($boat> 0) && ($id != $target) && ($kind != $H2::comMissileST)) {
	 # 난민표착
	 my($achive); # 도달난민
	 my($i);
	 for($i = 0; ($i < $H2::pointNumber && $boat> 0); $i++) {
		$bx = $H2::rpx[$i];
		$by = $H2::rpy[$i];
		if($land->[$bx][$by] == $H2::landTown) {
		 # 마을의 경우
		 my($lv) = $landValue->[$bx][$by];
		 if($boat> 50) {
			$lv += 50;
			$boat -= 50;
			$achive += 50;
		 } else {
			$lv += $boat;
			$achive += $boat;
			$boat = 0;
		 }
		 if($lv> 200) {
			$boat += ($lv - 200);
			$achive -= ($lv - 200);
			$lv = 200;
		 }
		 $landValue->[$bx][$by] = $lv;
		} elsif($land->[$bx][$by] == $H2::landPlains) {
		 # 평지의 경우
		 $land->[$bx][$by] = $H2::landTown;;
		 if($boat> 10) {
			$landValue->[$bx][$by] = 5;
			$boat -= 10;
			$achive += 10;
		 } elsif($boat> 5) {
			$landValue->[$bx][$by] = $boat - 5;
			$achive += $boat;
			$boat = 0;
		 }
		}
		if($boat <= 0) {
		 last;
		}
	 }
	 if($achive> 0) {
		# 조금이라도 도착한 경우 로그를 출력
		logMsBoatPeople($id, $name, $achive);

		# 난민의 수가일정수이상라면, 평화상의 가능성있음
		if($achive>= 200) {
		 my($prize) = $island->{'prize'};
		 $prize =~ /([0-9]*),([0-9]*),(.*)/;
		 my($flags) = $1;
		 my($monsters) = $2;
		 my($turns) = $3;

		 if((!($flags & 8)) && $achive>= 200){
			$flags |= 8;
			logPrize($id, $name, $H2::prize[4]);
		 } elsif((!($flags & 16)) && $achive> 500){
			$flags |= 16;
			logPrize($id, $name, $H2::prize[5]);
		 } elsif((!($flags & 32)) && $achive> 800){
			$flags |= 32;
			logPrize($id, $name, $H2::prize[6]);
		 }
		 $island->{'prize'} = "$flags,$monsters,$turns";
		}
	 }
	}
	return 1;
 } elsif($kind == $H2::comSendMonster) {
	# 괴수 파견
### ---v--- ver1.10 ---v---
	# 괴수 파견허가?
	if((($H2::islandTurn - $sturn) <= $H2::noSendMonsterTurn) && ($id != $target)) {
	 logNotPermitted($id, $name, $comName);
	 return 1;
	}
### ---^--- ver1.10 ---^---
	# 대상 가져오기
	my($tn) = $H2::idToNumber{$target};
	my($tIsland) = $H2::islands[$tn];
	my($tName) = $tIsland->{'name'};

	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

	# 메시지
	logMonsSend($id, $target, $name, $tName);
	$tIsland->{'monstersend'}++;

	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $H2::comSell) {
	# 수출량 결정
	if($arg == 0) { $arg = 1; }
	my($value) = min($arg * (-$cost), $island->{'food'});

	# 수출 로그
	logSell($id, $name, $comName, $value);
	$island->{'food'} -= $value;
	$island->{'money'} += ($value / 10);
	return 0;
 } elsif(($kind == $H2::comFood) ||
	 ($kind == $H2::comMoney)) {
	# 지원계
### ---v--- ver1.10 ---v---
	# 지원허가?
	if(($H2::islandTurn - $sturn) <= $H2::noAidTurn) {
	 logNotPermitted($id, $name, $comName);
	 return 1;
	}
### ---^--- ver1.10 ---^---
	# 대상 가져오기
	my($tn) = $H2::idToNumber{$target};
	my($tIsland) = $H2::islands[$tn];
	my($tName) = $tIsland->{'name'};

	# 지원량 결정
	if($arg == 0) { $arg = 1; }
	my($value, $str);
	if($cost < 0) {
	 $value = min($arg * (-$cost), $island->{'food'});
	 $str = "$value$H2::unitFood";
	} else {
	 $value = min($arg * ($cost), $island->{'money'});
	 $str = "$value$H2::unitMoney";
	}

	# 지원 로그
	logAid($id, $target, $name, $tName, $comName, $str);

	if($cost < 0) {
	 $island->{'food'} -= $value;
	 $tIsland->{'food'} += $value;
	} else {
	 $island->{'money'} -= $value;
	 $tIsland->{'money'} += $value;
	}
	return 0;
 } elsif($kind == $H2::comPropaganda) {
	# 유치 활동
	logPropaganda($id, $name, $comName);
	$island->{'propaganda'} = 1;
	$island->{'money'} -= $cost;

	# 횟수 지정이면, 명령을 되돌림
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;
 } elsif($kind == $H2::comGiveup) {
	# 포기
	logGiveup($id, $name);
	$island->{'dead'} = 1;
	unlink("island.$id");
	return 1;
 }

 return 1;
}

# 괴수 이동
sub doMoveMonster {
 my($island) = @_;
 my(@monsterMove);

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 # 루프
 my($x, $y, $i);
 for($i = 0; $i < $H2::pointNumber; $i++) {
	$x = $H2::rpx[$i];
	$y = $H2::rpy[$i];
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];

### ---v--- ver1.10 ---v---
	if(($landKind == $H2::landMonster)||($landKind == $H2::landMonsterS)) {

	 if($monsterMove[$x][$y] == 2) {
		# 이미 이동한 후
		next;
	 }

	 # 각 요소 꺼내기
	 my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	 my($special) = $H2::monsterSpecial[$mKind];

	 if($H2::monsterPreMove[$mKind] == 0) {
		# 선 행 이동이 아님
		next;
	 }

	 # 착탄 지점?
	 if($landKind == $H2::landMonsterS) {
		# 착탄 지점
		if(random(6) == 0) {
			# 접착해제
			$land->[$x][$y] = $H2::landMonster;
			logMonsStickOff($id, $name, "($x, $y)", $mName);
		}
	 next;
	 }
### ---^--- ver1.10 ---^---
	 # 경화 중?
	 if((($special == 3) && (($H2::islandTurn % 2) == 1)) ||
	 (($special == 4) && (($H2::islandTurn % 2) == 0))) {
		# 경화 중
		next;
	 }
	 # 포효
	 if(($H2::monsterShout[$mKind] == 1) && (random(10) == 0)) {
		$island->{'shout'}++;
		logMonsShout($id, $name, "($x, $y)", $mName);
		next;
	 }

	 # 이동 방향을 결정
	 my($d, $sx, $sy);
	 my($i);
	 for($i = 0; $i < 3; $i++) {
		# 주변에방어 시설가 있다면그곳
		($sx, $sy) = searchAroundPoint($land, $x, $y, $H2::landHoihoi);
		if(($sx != -1) && ($sy != -1)) { last; }
		# 주변에 방어 시설가 없으면 무작위
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}

		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $H2::islandSize) ||
		 ($sy < 0) || ($sy>= $H2::islandSize)) {
		 next;
		}

### ---v--- ver1.10 ---v---
		# 산, 기념비, 괴수
		if(($land->[$sx][$sy] == $H2::landMountain) ||
		 ($land->[$sx][$sy] == $H2::landMonument) ||
		 ($land->[$sx][$sy] == $H2::landMonsterS) ||
		 ($land->[$sx][$sy] == $H2::landMonster)) {
		 next;
		}

		# 바다, 바다 기준, 유전에서  또한, 바다등로의 이동없음
		if((($land->[$sx][$sy] == $H2::landSea) ||
		 ($land->[$sx][$sy] == $H2::landSbase) ||
		 ($land->[$sx][$sy] == $H2::landOil)) &&
		 ($H2::monsterSeaMove[$mKind] != 1)) {
		 next;
		}
		# 그 외
		last;
### ---^--- ver1.10 ---^---
	 }

	 if($i == 3) {
		# 작동없었습니다
		next;
	 }

	 # 이동분포인트
	 $island->{'score'} += $mHp;

	 # 이동한 위치의 지형에 따라 처리
	 my($l) = $land->[$sx][$sy];
	 my($lv) = $landValue->[$sx][$sy];
	 my($lName) = landName($l, $lv);
	 my($point) = "($sx, $sy)";

	 # 이동
	 $land->[$sx][$sy] = $land->[$x][$y];
	 $landValue->[$sx][$sy] = $landValue->[$x][$y];

### ---v--- ver1.10 ---v---
	 if(($l == $H2::landSea)||($l == $H2::landSbase)||($l == $H2::landOil)) {
	 # 이동 전 위치가 바다, 바다 기준, 유전라면, 원래 위치를 바다로
		$land->[$x][$y] = $H2::landSea;
		$landValue->[$x][$y] = 0;
	 } else {
	 # 그 외는, 원래 위치를 황무지로
		$land->[$x][$y] = $H2::landWaste;
		$landValue->[$x][$y] = 0;
	 }
### ---^--- ver1.10 ---^---

	 # 이동 완료 플래그
	 if($H2::monsterSpecial[$mKind] == 2) {
		# 이동 완료 플래그가 설정되어 있지 않음
	 } elsif($H2::monsterSpecial[$mKind] == 1) {
		# 속이괴수
		$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
	 } else {
		# 일반 괴수
		$monsterMove[$sx][$sy] = 2;
	 }

	 if(($l == $H2::landDefence) && ($H2::dBaseAuto == 1)) {
		# 방위 시설을 밟습니다
		logMonsMoveDefence($id, $name, $lName, $point, $mName);

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $sx, $sy);
	 } elsif($l == $H2::landHoihoi) {
		# 방어 시설에포획
		# 이동 대상을 바다에
		$land->[$sx][$sy] = $H2::landSea;
		$landValue->[$sx][$sy] = 0;
		logMonsMoveHoihoi($id, $name, $lName, $point, $mName);
		# 포인트
		$island->{'score'} += $H2::monsterExp[$mKind] * 20;
	 } elsif(($l == $H2::landFarm) && ($mKind != 0)) {
		# 농장을 식이악성체력회복(인공괴수이외)
		my($upmHp) = 0;
		my($upMax) = int($lv / 10);
		while($upMax> 0) {
		 $upMax --;
### ---v--- ver1.10 ---v---
		 my($smKind, $smName, $smHp) = monsterSpec($landValue->[$sx][$sy]);
### ---^--- ver1.10 ---^---
		 if($smHp < 9) {
			$landValue->[$sx][$sy] ++;
			$upmHp ++;
		 } else {
			last;
		 }
		}
### ---v--- ver1.10 ---v---
		if($H2::monsterInvisible[$mKind] == 1) { $point = '(?, ?)'; }
### ---^--- ver1.10 ---^---
		if($upmHp) {
		 logMonsMoveFarm($id, $name, $lName, $point, $mName, $upmHp);
		} else {
		 logMonsMove($id, $name, $lName, $point, $mName);
		}
### ---v--- ver1.10 ---v---
	 } elsif(($l == $H2::landSea)||($l == $H2::landSbase)||($l == $H2::landOil)) {
		# 연결선이 바다가 됨
		if($H2::monsterInvisible[$mKind] == 1) { $point = '(?, ?)'; }
		logMonsMoveSea($id, $name, $lName, $point, $mName);
### ---^--- ver1.10 ---^---
	 } else {
		# 연결선이황무지가 됨
### ---v--- ver1.10 ---v---
		if($H2::monsterInvisible[$mKind] == 1) { $point = '(?, ?)'; }
### ---^--- ver1.10 ---^---
		logMonsMove($id, $name, $lName, $point, $mName);
	 }
	}
 }
}

# 성장 및 단일 헥스 재해
sub doEachHex {
 my($island) = @_;
 my(@monsterMove);

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 # 늘어나면인구의 타네 값
 my($addpop) = 10; # 마을, 마을
 my($addpop2) = 0; # 도시
 if($island->{'food'} < 0) {
	# 식량 부족
	$addpop = -30;
 } elsif($island->{'propaganda'} == 1) {
	# 유치 활동 중
	$addpop = 30;
	$addpop2 = 3;
 }

 # 루프
 my($x, $y, $i);
 for($i = 0; $i < $H2::pointNumber; $i++) {
	$x = $H2::rpx[$i];
	$y = $H2::rpy[$i];
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];

	if($landKind == $H2::landTown) {
	 # 마을 계열
	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $H2::landPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 100) {
		 $lv += random($addpop) + 1;
		 if($lv> 100) {
			$lv = 100;
		 }
		} else {
		 # 도시가 되면 성장 지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 200) {
		$lv = 200;
	 }
	 $landValue->[$x][$y] = $lv;
	} elsif($landKind == $H2::landPlains) {
	 # 평지
	 if(random(5) == 0) {
		# 주변에 농장, 마을이 있다면, 여기도 마을이 됨
	 if(countGrow($land, $landValue, $x, $y)){
		 $land->[$x][$y] = $H2::landTown;
		 $landValue->[$x][$y] = 1;
		}
	 }
	} elsif($landKind == $H2::landWaste) {
	 # 황무지(한 송이의 꽃)
	 if($lv> 2) {
		$landValue->[$x][$y]--; # 아직 한 송이의 꽃
		$island->{'flower'}++;
	 }
	 # 8턴째에는25% 확률로 시듦
	 elsif($lv == 2) {
		if(random(4) == 0) {
			$landValue->[$x][$y] = 0;
			LogMsFlowWither($id, $name, "($x, $y)");
	 	} else {
			$island->{'flower'}++;
		}
	 }
	} elsif($landKind == $H2::landForest) {
	 # 숲
	 if($lv < 200) {
		# 나무가 늘어남
		$landValue->[$x][$y]++;
	 }
	} elsif($landKind == $H2::landDefence) {
	 if($lv == 1) {
		# 방위 시설 자폭
		my($lName) = &landName($landKind, $lv);
		logBombFire($id, $name, $lName, "($x, $y)");

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y);
	 }
	} elsif($landKind == $H2::landOil) {
	 # 해저 유전
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = $H2::oilMoney;
	 $island->{'money'} += $value;
	 $str = "$value$H2::unitMoney";

	 # 수입 로그
	 logOilMoney($id, $name, $lName, "($x, $y)", $str);

	 # 고갈판정
	 if(random(1000) < $H2::oilRatio) {
		# 고갈
		logOilEnd($id, $name, $lName, "($x, $y)");
		$land->[$x][$y] = $H2::landSea;
		$landValue->[$x][$y] = 0;
	 }
	} elsif($landKind == $H2::landHoihoi) {
	 # 방어 시설
	 # 유지비50억
	 $island->{'money'} -= 50;
	 if($island->{'money'} < 0) {
		$island->{'money'} = 0;
		# 1/3에서 약품사고
		if(random(3) == 0) {
		 my($lName) = landName($landKind, $lv);
		 logYakuhin($id, $name, $lName, "($x, $y)");
		 # 중간 범위 피해 루틴
		 middleDamage($id, $name, $land, $landValue, $x, $y);
		}
	 }
### ---v--- ver1.10 ---v---
	} elsif(($landKind == $H2::landMonster)||($landKind == $H2::landMonsterS)) {

	 if($monsterMove[$x][$y] == 2) {
		# 이미 이동한 후
		next;
	 }

	 # 각 요소 꺼내기
	 my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	 my($special) = $H2::monsterSpecial[$mKind];

	 if($H2::monsterPreMove[$mKind] == 1) {
		# 선 줄 이동
		next;
	 }

	 # 착탄 지점?
	 if($landKind == $H2::landMonsterS) {
		# 착탄 지점
		if(random(6) == 0) {
			# 접착해제
			$land->[$x][$y] = $H2::landMonster;
			logMonsStickOff($id, $name, "($x, $y)", $mName);
		}
	 next;
	 }
	 # 경화 중?
	 if((($special == 3) && (($H2::islandTurn % 2) == 1)) ||
	 (($special == 4) && (($H2::islandTurn % 2) == 0))) {
		# 경화 중
		next;
	 }
	 # 포효
	 if(($H2::monsterShout[$mKind] == 1) && (random(10) == 0)) {
		$island->{'shout'}++;
		logMonsShout($id, $name, "($x, $y)", $mName);
		next;
	 }

	 # 이동 방향을 결정
	 my($d, $sx, $sy);
	 my($i);
	 for($i = 0; $i < 3; $i++) {
		# 주변에방어 시설가 있다면그곳
		($sx, $sy) = searchAroundPoint($land, $x, $y, $H2::landHoihoi);
		if(($sx != -1) && ($sy != -1)) { last; }
		# 주변에 방어 시설가 없으면 무작위
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}

		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $H2::islandSize) ||
		 ($sy < 0) || ($sy>= $H2::islandSize)) {
		 next;
		}

		# 산, 기념비, 괴수
		if(($land->[$sx][$sy] == $H2::landMountain) ||
		 ($land->[$sx][$sy] == $H2::landMonument) ||
		 ($land->[$sx][$sy] == $H2::landMonsterS) ||
		 ($land->[$sx][$sy] == $H2::landMonster)) {
		 next;
		}

		# 바다, 바다 기준, 유전에서  또한, 바다등로의 이동없음
		if((($land->[$sx][$sy] == $H2::landSea) ||
		 ($land->[$sx][$sy] == $H2::landSbase) ||
		 ($land->[$sx][$sy] == $H2::landOil)) &&
		 ($H2::monsterSeaMove[$mKind] != 1)) {
		 next;
		}
		# 그 외
		last;
	 }

	 if($i == 3) {
		# 작동없었습니다
		next;
	 }

	 # 이동분포인트
	 $island->{'score'} += $mHp;

	 # 이동한 위치의 지형에 따라 처리
	 my($l) = $land->[$sx][$sy];
	 my($lv) = $landValue->[$sx][$sy];
	 my($lName) = landName($l, $lv);
	 my($point) = "($sx, $sy)";

	 # 이동
	 $land->[$sx][$sy] = $land->[$x][$y];
	 $landValue->[$sx][$sy] = $landValue->[$x][$y];

	 if(($l == $H2::landSea)||($l == $H2::landSbase)||($l == $H2::landOil)) {
	 # 이동 전 위치가 바다, 바다 기준, 유전라면, 원래 위치를 바다로
		$land->[$x][$y] = $H2::landSea;
		$landValue->[$x][$y] = 0;
	 } else {
	 # 그 외는, 원래 위치를 황무지로
		$land->[$x][$y] = $H2::landWaste;
		$landValue->[$x][$y] = 0;
	 }

	 # 이동 완료 플래그
	 if($H2::monsterSpecial[$mKind] == 2) {
		# 이동 완료 플래그가 설정되어 있지 않음
	 } elsif($H2::monsterSpecial[$mKind] == 1) {
		# 속이괴수
		$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
	 } else {
		# 일반 괴수
		$monsterMove[$sx][$sy] = 2;
	 }

	 if(($l == $H2::landDefence) && ($H2::dBaseAuto == 1)) {
		# 방위 시설을 밟습니다
		logMonsMoveDefence($id, $name, $lName, $point, $mName);

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $sx, $sy);
	 } elsif($l == $H2::landHoihoi) {
		# 방어 시설에포획
		# 이동 대상을 바다에
		$land->[$sx][$sy] = $H2::landSea;
		$landValue->[$sx][$sy] = 0;
		logMonsMoveHoihoi($id, $name, $lName, $point, $mName);
		# 포인트
		$island->{'score'} += $H2::monsterExp[$mKind] * 20;
	 } elsif(($l == $H2::landFarm) && ($mKind != 0)) {
		# 농장을 식이악성체력회복(인공괴수이외)
		my($upmHp) = 0;
		my($upMax) = int($lv / 10);
		while($upMax> 0) {
		 $upMax --;
		 my($smKind, $smName, $smHp) = monsterSpec($landValue->[$sx][$sy]);
		 if($smHp < 9) {
			$landValue->[$sx][$sy] ++;
			$upmHp ++;
		 } else {
			last;
		 }
		}
		if($H2::monsterInvisible[$mKind] == 1) { $point = '(?, ?)'; }
		if($upmHp) {
		 logMonsMoveFarm($id, $name, $lName, $point, $mName, $upmHp);
		} else {
		 logMonsMove($id, $name, $lName, $point, $mName);
		}
	 } elsif(($l == $H2::landSea)||($l == $H2::landSbase)||($l == $H2::landOil)) {
		# 연결선이 바다가 됨
		if($H2::monsterInvisible[$mKind] == 1) { $point = '(?, ?)'; }
		logMonsMoveSea($id, $name, $lName, $point, $mName);
	 } else {
		# 연결선이황무지가 됨
		if($H2::monsterInvisible[$mKind] == 1) { $point = '(?, ?)'; }
		logMonsMove($id, $name, $lName, $point, $mName);
	 }
	}
### ---^--- ver1.10 ---^---

	# 화재판정
	if((($landKind == $H2::landTown) && ($lv> 30)) ||
	 ($landKind == $H2::landHaribote) ||
	 ($landKind == $H2::landFactory)) {
	 if(random(1000) < $H2::disFire) {
		# 주변의 숲과 기념비를 흡수 가능
		if((countAround($land, $x, $y, $H2::landForest, 7) +
		 countAround($land, $x, $y, $H2::landMonument, 7)) == 0) {
		 # 없어진 경우 화재로 괴멸
		 my($l) = $land->[$x][$y];
		 my($lv) = $landValue->[$x][$y];
		 my($point) = "($x, $y)";
		 my($lName) = landName($l, $lv);
		 logFire($id, $name, $lName, $point);
		 $land->[$x][$y] = $H2::landWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }
	}
 }
}

# 주변의 마을, 농장이 있는 지반정
sub countGrow {
 my($land, $landValue, $x, $y) = @_;
 my($i, $sx, $sy);
 for($i = 1; $i < 7; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	 }

	 if(($sx < 0) || ($sx>= $H2::islandSize) ||
	 ($sy < 0) || ($sy>= $H2::islandSize)) {
	 } else {
	 # 범위 안의 경우
	 if(($land->[$sx][$sy] == $H2::landTown) ||
		($land->[$sx][$sy] == $H2::landFarm)) {
		 if($landValue->[$sx][$sy] != 1) {
		 return 1;
		 }
	 }
	 }
 }
 return 0;
}

# 섬 전체
sub doIslandProcess {
 my($number, $island) = @_;

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 # 지진판정
 if(random(1000) < (($island->{'prepare2'} + 1) * $H2::disEarthquake)) {
	# 지진발생
	logEarthquake($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $H2::pointNumber; $i++) {
	 $x = $H2::rpx[$i];
	 $y = $H2::rpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if((($landKind == $H2::landTown) && ($lv>= 100)) ||
	 ($landKind == $H2::landHaribote) ||
	 ($landKind == $H2::landFactory)) {
		# 1/4에서 괴멸
		if(random(4) == 0) {
		 logEQDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $H2::landWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }

	}
 }

 # 식량 부족
 if($island->{'food'} < 0) {
	# 부족 메시지
	logStarve($id, $name);
	$island->{'food'} = 0;

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $H2::pointNumber; $i++) {
	 $x = $H2::rpx[$i];
	 $y = $H2::rpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $H2::landFarm) ||
	 ($landKind == $H2::landFactory) ||
	 ($landKind == $H2::landBase) ||
	 ($landKind == $H2::landDefence)) {
		# 1/4에서 괴멸
		if(random(4) == 0) {
		 logSvDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $H2::landWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }
	}
 }

 # 쓰나미판정
 if(random(1000) < $H2::disTsunami) {
	# 쓰나미발생
	logTsunami($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $H2::pointNumber; $i++) {
	 $x = $H2::rpx[$i];
	 $y = $H2::rpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $H2::landTown) ||
	 ($landKind == $H2::landFarm) ||
	 ($landKind == $H2::landFactory) ||
	 ($landKind == $H2::landBase) ||
	 ($landKind == $H2::landDefence) ||
	 ($landKind == $H2::landHaribote)) {
		# 1d12 <= (주변의 바다 - 1) 데붕괴
		if(random(12) <
		 (countAround($land, $x, $y, $H2::landOil, 7) +
		 countAround($land, $x, $y, $H2::landSbase, 7) +
		 countAround($land, $x, $y, $H2::landSea, 7) - 1)) {
		 logTsunamiDamage($id, $name, landName($landKind, $lv),
				 "($x, $y)");
		 $land->[$x][$y] = $H2::landWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }

	}
 }

 # 괴수판정
 my($r) = random(10000);
 my($pop) = $island->{'pop'};
 do{
### ---v--- ver1.10 ---v---
	 # 꽃 한 송이당1헥스주변마이너스하다
	if((($r < (($H2::disMonster - ($island->{'flower'} * $H2::disFlower))* $island->{'area'})) && ($pop>= $H2::disMonsBorder1)) ||
### ---^--- ver1.10 ---^---
	 ($island->{'shout'}> 0) ||# 포효
	 ($island->{'monstersend'}> 0)) {
	 # 괴수출현
	 # 종류를 결하기
	 my($lv, $kind);
	 if($island->{'monstersend'}> 0) {
		# 인공
		$kind = 0;
		$island->{'monstersend'}--;
	 } elsif($island->{'shout'}> 1) {# 포효2회이상
### ---v--- ver1.10 ---v---
		# level5까지
		$kind = random($H2::monsterLevel5) + 1;
### ---^--- ver1.10 ---^---
	 } elsif($island->{'shout'} == 1) {# 포효1회
		# level1만
		$kind = random($H2::monsterLevel1) + 1;
### ---v--- ver1.10 ---v---
	 } elsif($pop>= $H2::disMonsBorder5) {
		# level5까지
		$kind = random($H2::monsterLevel5) + 1;
	 } elsif($pop>= $H2::disMonsBorder4) {
		# level4까지
		$kind = random($H2::monsterLevel4) + 1;
### ---^--- ver1.10 ---^---
	 } elsif($pop>= $H2::disMonsBorder3) {
		# level3까지
		$kind = random($H2::monsterLevel3) + 1;
	 } elsif($pop>= $H2::disMonsBorder2) {
		# level2까지
		$kind = random($H2::monsterLevel2) + 1;
	 } else {
		# level1만
		$kind = random($H2::monsterLevel1) + 1;
	 }

	 # lv 의 값을 결하기
	 $lv = $kind * 10
		+ $H2::monsterBHP[$kind] + random($H2::monsterDHP[$kind]);

	 # 어디에 출현할지 결정
	 my($bx, $by, $i);
	 for($i = 0; $i < $H2::pointNumber; $i++) {
		$bx = $H2::rpx[$i];
		$by = $H2::rpy[$i];
		if($land->[$bx][$by] == $H2::landTown) {

		 # 지형 이름
		 my($lName) = landName($H2::landTown, $landValue->[$bx][$by]);

		 # 해당 헥스를 괴수로
		 $land->[$bx][$by] = $H2::landMonster;
		 $landValue->[$bx][$by] = $lv;

		 # 괴수 정보
### ---v--- ver1.10 ---v---
		 my($mKind, $mName, $mHp) = monsterSpec($lv);
### ---^--- ver1.10 ---^---

		 # 출현포인트
		 $island->{'score'} += $H2::monsterExp[$mKind] * 2;

		 # 메시지
### ---v--- ver1.10 ---v---
		 my($point) = "($bx, $by)";
		 if($H2::monsterInvisible[$mKind] == 1) { $point = '(?, ?)'; }
		 logMonsCome($id, $name, $mName, $point, $lName);
### ---^--- ver1.10 ---^---
		 last;
		}
	 }
	}
 } while($island->{'monstersend'}> 0);

 # 지반 침하판정
 if(($island->{'area'}> $H2::disFallBorder) &&
 (random(1000) < $H2::disFalldown)) {
	# 지반 침하발생
	logFalldown($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $H2::pointNumber; $i++) {
	 $x = $H2::rpx[$i];
	 $y = $H2::rpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind != $H2::landSea) &&
	 ($landKind != $H2::landSbase) &&
	 ($landKind != $H2::landOil) &&
	 ($landKind != $H2::landMountain)) {

		# 주변에 바다가 있다면, 값을-1에
		if(countAround($land, $x, $y, $H2::landSea, 7) +
		 countAround($land, $x, $y, $H2::landSbase, 7)) {
		 logFalldownLand($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = -1;
		 $landValue->[$x][$y] = 0;
		}
	 }
	}

	for($i = 0; $i < $H2::pointNumber; $i++) {
	 $x = $H2::rpx[$i];
	 $y = $H2::rpy[$i];
	 $landKind = $land->[$x][$y];

	 if($landKind == -1) {
		# -1에나하고 있는 장소를 얕은 바다에
		$land->[$x][$y] = $H2::landSea;
		$landValue->[$x][$y] = 1;
	 } elsif ($landKind == $H2::landSea) {
		# 얕은 바다는 바다에
		$landValue->[$x][$y] = 0;
	 }

	}
 }

 # 태풍판정
 if(random(1000) < $H2::disTyphoon) {
	# 태풍발생
	logTyphoon($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $H2::pointNumber; $i++) {
	 $x = $H2::rpx[$i];
	 $y = $H2::rpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $H2::landFarm) ||
	 ($landKind == $H2::landHaribote)) {

		# 1d12 <= (6 - 주변의 숲) 데붕괴
		if(random(12) <
		 (6
		 - countAround($land, $x, $y, $H2::landForest, 7)
		 - countAround($land, $x, $y, $H2::landMonument, 7))) {
		 logTyphoonDamage($id, $name, landName($landKind, $lv),
				 "($x, $y)");
		 $land->[$x][$y] = $H2::landPlains;
		 $landValue->[$x][$y] = 0;
		}
	 }

	}
 }

 # 거대운석판정
 if(random(1000) < $H2::disHugeMeteo) {
	my($x, $y, $landKind, $lv, $point);

	# 낙하
	$x = random($H2::islandSize);
	$y = random($H2::islandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";

	# 메시지
	logHugeMeteo($id, $name, $point);

	# 광역 피해 루틴
	wideDamage($id, $name, $land, $landValue, $x, $y);
 }

 # 거대 미사일판정
 while($island->{'bigmissile'}> 0) {
	$island->{'bigmissile'} --;

	my($x, $y, $landKind, $lv, $point);

	# 낙하
	$x = random($H2::islandSize);
	$y = random($H2::islandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";

	# 메시지
	logMonDamage($id, $name, $point);

	# 광역 피해 루틴
	wideDamage($id, $name, $land, $landValue, $x, $y);
 }

 # 운석판정
 if(random(1000) < $H2::disMeteo) {
	my($x, $y, $landKind, $lv, $point, $first);
	$first = 1;
	while((random(3) == 0) || ($first == 1)) {# 연속낙하1/3
	 $first = 0;

	 # 낙하
	 $x = random($H2::islandSize);
	 $y = random($H2::islandSize);
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 $point = "($x, $y)";

	 if(($landKind == $H2::landSea) && ($lv == 0)){
		# 바다포차
		logMeteoSea($id, $name, landName($landKind, $lv),
			 $point);
	 } elsif($landKind == $H2::landMountain) {
		# 산파괴
		logMeteoMountain($id, $name, landName($landKind, $lv),
				 $point);
		$land->[$x][$y] = $H2::landWaste;
		$landValue->[$x][$y] = 0;
		next;
	 } elsif($landKind == $H2::landSbase) {
		logMeteoSbase($id, $name, landName($landKind, $lv),
			 $point);
### ---v--- ver1.10 ---v---
	 } elsif(($landKind == $H2::landMonster)||($landKind == $H2::landMonsterS)) {
### ---^--- ver1.10 ---^---
		logMeteoMonster($id, $name, landName($landKind, $lv),
				$point);
	 } elsif($landKind == $H2::landSea) {
		# 얕은 바다
		logMeteoSea1($id, $name, landName($landKind, $lv),
			 $point);
	 } else {
		logMeteoNormal($id, $name, landName($landKind, $lv),
			 $point);
	 }
	 $land->[$x][$y] = $H2::landSea;
	 $landValue->[$x][$y] = 0;
	}
 }

 # 분화 판정정
 if(random(1000) < $H2::disEruption) {
	my($x, $y, $sx, $sy, $i, $landKind, $lv, $point);
	$x = random($H2::islandSize);
	$y = random($H2::islandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";
	logEruption($id, $name, landName($landKind, $lv),
		 $point);
	$land->[$x][$y] = $H2::landMountain;
	$landValue->[$x][$y] = 0;

	for($i = 1; $i < 7; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
		$sx--;
	 }

	 $landKind = $land->[$sx][$sy];
	 $lv = $landValue->[$sx][$sy];
	 $point = "($sx, $sy)";

	 if(($sx < 0) || ($sx>= $H2::islandSize) ||
	 ($sy < 0) || ($sy>= $H2::islandSize)) {
	 } else {
		# 범위 안의 경우
		$landKind = $land->[$sx][$sy];
		$lv = $landValue->[$sx][$sy];
		$point = "($sx, $sy)";
		if(($landKind == $H2::landSea) ||
		 ($landKind == $H2::landOil) ||
		 ($landKind == $H2::landSbase)) {
		 # 바다의 경우
		 if($lv == 1) {
			# 얕은 바다
			logEruptionSea1($id, $name, landName($landKind, $lv),
					$point);
		 } else {
			logEruptionSea($id, $name, landName($landKind, $lv),
				 $point);
			$land->[$sx][$sy] = $H2::landSea;
			$landValue->[$sx][$sy] = 1;
			next;
		 }
		} elsif(($landKind == $H2::landMountain) ||
			($landKind == $H2::landMonster) ||
### ---v--- ver1.10 ---v---
			($landKind == $H2::landMonsterS) ||
### ---^--- ver1.10 ---^---
			($landKind == $H2::landWaste)) {
		 next;
		} else {
		 # 그 외의 경우
		 logEruptionNormal($id, $name, landName($landKind, $lv),
				 $point);
		}
		$land->[$sx][$sy] = $H2::landWaste;
		$landValue->[$sx][$sy] = 0;
	 }
	}
 }

 # 식량이 넘치면 환전
 if($island->{'food'}> 9999) {
	$island->{'money'} += int(($island->{'food'} - 9999) / 10);
	$island->{'food'} = 9999;
 }

 # 자금이 넘치면 잘라냄
 if($island->{'money'}> 99999) {# 상한99999에 변경
	$island->{'money'} = 99999;
 }

 # 각종의 값을 계산
 estimate($number);

 # 번영, 재난상
 $pop = $island->{'pop'};
 my($damage) = $island->{'oldPop'} - $pop;
 my($prize) = $island->{'prize'};
 $prize =~ /([0-9]*),([0-9]*),(.*)/;
 my($flags) = $1;
 my($monsters) = $2;
 my($turns) = $3;

 # 번영상
 if((!($flags & 1)) && $pop>= 3000){
	$flags |= 1;
	logPrize($id, $name, $H2::prize[1]);
 } elsif((!($flags & 2)) && $pop>= 5000){
	$flags |= 2;
	logPrize($id, $name, $H2::prize[2]);
 } elsif((!($flags & 4)) && $pop>= 10000){
	$flags |= 4;
	logPrize($id, $name, $H2::prize[3]);
 }

 # 재난상
 if((!($flags & 64)) && $damage>= 500){
	$flags |= 64;
	logPrize($id, $name, $H2::prize[7]);
 } elsif((!($flags & 128)) && $damage>= 1000){
	$flags |= 128;
	logPrize($id, $name, $H2::prize[8]);
 } elsif((!($flags & 256)) && $damage>= 2000){
	$flags |= 256;
	logPrize($id, $name, $H2::prize[9]);
 }

 $island->{'prize'} = "$flags,$monsters,$turns";
}

# 포인트순에정렬
sub islandSort {
 my($flag, $i, $tmp);
 my @idx = (0..$#H2::islands);
 # 포인트가 같으면 이전 턴의 순서를 유지
 @idx = sort { $H2::islands[$b]->{'score'} <=> $H2::islands[$a]->{'score'} || $a <=> $b } @idx;
 @H2::islands = @H2::islands[@idx];
}

# 광역 피해 루틴
sub wideDamage {
 my($id, $name, $land, $landValue, $x, $y) = @_;
 my($sx, $sy, $i, $landKind, $landName, $lv, $point);

 for($i = 0; $i < 19; $i++) {
	$sx = $x + $ax[$i];
	$sy = $y + $ay[$i];

	# 행 기준 위치 조정
	if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	}

	$landKind = $land->[$sx][$sy];
	$lv = $landValue->[$sx][$sy];
	$landName = landName($landKind, $lv);
	$point = "($sx, $sy)";

	# 범위 밖 판정
	if(($sx < 0) || ($sx>= $H2::islandSize) ||
	 ($sy < 0) || ($sy>= $H2::islandSize)) {
	 next;
	}

	# 범위에 한분기
	if($i < 7) {
	 # 중심 및 1헥스
	 if($landKind == $H2::landSea) {
		$landValue->[$sx][$sy] = 0;
		next;
	 } elsif(($landKind == $H2::landSbase) ||
		 ($landKind == $H2::landOil)) {
		logWideDamageSea2($id, $name, $landName, $point);
		$land->[$sx][$sy] = $H2::landSea;
		$landValue->[$sx][$sy] = 0;
	 } else {
### ---v--- ver1.10 ---v---
		if(($landKind == $H2::landMonster)||($landKind == $H2::landMonsterS)) {
### ---^--- ver1.10 ---^---
		 logWideDamageMonsterSea($id, $name, $landName, $point);
		} else {
		 logWideDamageSea($id, $name, $landName, $point);
		}
		$land->[$sx][$sy] = $H2::landSea;
		if($i == 0) {
		 # 바다
		 $landValue->[$sx][$sy] = 0;
		} else {
		 # 얕은 바다
		 $landValue->[$sx][$sy] = 1;
		}
	 }
	} else {
	 # 2헥스
	 if(($landKind == $H2::landSea) ||
	 ($landKind == $H2::landOil) ||
	 ($landKind == $H2::landWaste) ||
	 ($landKind == $H2::landMountain) ||
	 ($landKind == $H2::landSbase)) {
		next;
### ---v--- ver1.10 ---v---
	 } elsif(($landKind == $H2::landMonster)||($landKind == $H2::landMonsterS)) {
### ---^--- ver1.10 ---^---
		logWideDamageMonster($id, $name, $landName, $point);
		$land->[$sx][$sy] = $H2::landWaste;
		$landValue->[$sx][$sy] = 0;
	 } else {
		logWideDamageWaste($id, $name, $landName, $point);
		$land->[$sx][$sy] = $H2::landWaste;
		$landValue->[$sx][$sy] = 0;
	 }
	}
 }
}

# 중간 범위 피해 루틴(약품사고)
sub middleDamage {
 my($id, $name, $land, $landValue, $x, $y) = @_;
 my($sx, $sy, $i, $landKind, $landName, $lv, $point);

 for($i = 0; $i < 7; $i++) {
	$sx = $x + $ax[$i];
	$sy = $y + $ay[$i];

	# 행 기준 위치 조정
	if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	}

	$landKind = $land->[$sx][$sy];
	$lv = $landValue->[$sx][$sy];
	$landName = landName($landKind, $lv);
	$point = "($sx, $sy)";

	# 범위 밖 판정
	if(($sx < 0) || ($sx>= $H2::islandSize) ||
	 ($sy < 0) || ($sy>= $H2::islandSize)) {
	 next;
	}

### ---v--- ver1.10 ---v---
	if(($landKind == $H2::landMonster)||($landKind == $H2::landMonsterS)) {
### ---^--- ver1.10 ---^---
	 next;
	} elsif($landKind == $H2::landSea) {
	 $landValue->[$sx][$sy] = 0;
	 next;
	} elsif(($landKind == $H2::landSbase) ||
		($landKind == $H2::landOil)) {
	 logMiddleDamageSea2($id, $name, $landName, $point);
	 $land->[$sx][$sy] = $H2::landSea;
	 $landValue->[$sx][$sy] = 0;
	} else {
	 logMiddleDamageSea($id, $name, $landName, $point);
	 $land->[$sx][$sy] = $H2::landSea;
		if($i == 0) {
		# 바다
		$landValue->[$sx][$sy] = 0;
	 } else {
		# 얕은 바다
		$landValue->[$sx][$sy] = 1;
	 }
	}
 }
}

# 로그로 출력
# 제1인 수:메시지
# 제2인 수:당사자
# 제3인 수:상대
# 일반 로그
sub logOut {
 push(@H2::logPool,"0,$H2::islandTurn,$_[1],$_[2],$_[0]");
}

# 지연 로그
sub logLate {
 push(@H2::lateLogPool,"0,$H2::islandTurn,$_[1],$_[2],$_[0]");
}

# 기밀 로그
sub logSecret {
 push(@H2::secretLogPool,"1,$H2::islandTurn,$_[1],$_[2],$_[0]");
}

# 기록 로그
sub logHistory {
 open(HOUT, ">>${H2::dirName}/hakojima.his");
 print HOUT "$H2::islandTurn,$_[0]\n";
 close(HOUT);
}

# 기록 로그 조정
sub logHistoryTrim {
 open(HIN, "${H2::dirName}/hakojima.his");
 my(@line, $l, $count);
 $count = 0;
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
	$count++;
 }
 close(HIN);

 if($count> $H2::historyMax) {
	open(HOUT, ">${H2::dirName}/hakojima.his");
	my($i);
	for($i = ($count - $H2::historyMax); $i < $count; $i++) {
	 print HOUT "$line[$i]\n";
	}
	close(HOUT);
 }
}

# 로그 쓰기
sub logFlush {
 open(LOUT, ">${H2::dirName}/hakojima.log0");

 # 전체를 역순으로 출력
 my($i);
 for($i = $#H2::secretLogPool; $i>= 0; $i--) {
	print LOUT $H2::secretLogPool[$i];
	print LOUT "\n";
 }
 for($i = $#H2::lateLogPool; $i>= 0; $i--) {
	print LOUT $H2::lateLogPool[$i];
	print LOUT "\n";
 }
 for($i = $#H2::logPool; $i>= 0; $i--) {
	print LOUT $H2::logPool[$i];
	print LOUT "\n";
 }
 close(LOUT);
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
# 정전발생
sub logTeiden {
 my($id, $name, $fact_mount) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서${H2::tagDisaster_}정전${H2::_tagDisaster}발생!!$fact_mount에서 수입이 없었습니다.",$id);
}

# 대식 대회개최
sub logOogui {
 my($id, $name) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서${H2::tagDisaster_}대식 대회${H2::_tagDisaster}개최!!평소의5배의 식량이 소비되었습니다.",$id);
}

# 자금 부족
sub logNoMoney {
 my($id, $name, $comName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}$comName${H2::_tagComName}은, 자금이 부족해 중지되었습니다.",$id);
}

# 식량 부족
sub logNoFood {
 my($id, $name, $comName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}$comName${H2::_tagComName}은, 비축 식량 부족으로 중지되었습니다.",$id);
}

# 대상 지형 종류 때문에 실패
sub logLandFail {
 my($id, $name, $comName, $kind, $point) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}$comName${H2::_tagComName}은, 예정지 ${H2::tagName_}$point${H2::_tagName}이<B>$kind</B>였기 때문에 중지되었습니다.",$id);
END
}

# 주변에 육지가 없으면 매립 실패
sub logNoLandAround {
 my($id, $name, $comName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}$comName${H2::_tagComName}은, 예정지 ${H2::tagName_}$point${H2::_tagName} 주변에 육지가 없었기 때문에 중지되었습니다.",$id);
END
}

# 주변에 괴수가 있고방어 시설 설치실패
sub logMonAround {
 my($id, $name, $comName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}$comName${H2::_tagComName}은, 예정지 ${H2::tagName_}$point${H2::_tagName} 주변에 괴수가 있었기 때문에 중지되었습니다.",$id);
}

# 개간 계열 성공
sub logLandSuc {
 my($id, $name, $comName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}에서${H2::tagComName_}${comName}${H2::_tagComName}이 실행되었습니다.",$id);
END
}

# 유전 발견
sub logOilFound {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}에서<B>$str</B>의 예산을 투입하여${H2::tagComName_}${comName}${H2::_tagComName}이 진행되어,<B>유전이 채굴되었습니다</B>.",$id);
END
}

# 유전 발견 여부
sub logOilFail {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}에서<B>$str</B>의 예산을 투입하여${H2::tagComName_}${comName}${H2::_tagComName}이 실행되었지만, 유전은 발견되지 않았습니다.",$id);
END
}

# 유전에서 수입
sub logOilMoney {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>에서 <B>$str</B> 수익이 발생했습니다.",$id);
END
}

# 유전 고갈
sub logOilEnd {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은 고갈된 것 같습니다.",$id);
END
}

# 방위 시설, 자폭 설정
sub logBombSet {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>의<B>자폭장치가 설정</B>되었습니다.",$id);
END
}

# 방위 시설, 자폭 작동
sub logBombFire {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>,${H2::tagDisaster_}자폭장치 작동!!${H2::_tagDisaster}",$id);
END
}

# 기념비, 발사
sub logMonFly {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>이<B>굉음과 함께 흔들렸습니다</B>.",$id);
END
}

# 기념비, 낙하
sub logMonDamage {
 my($id, $name, $point) = @_;
 logOut("<B>정체불명의 물체</B>가${H2::tagName_}${name} 섬 $point${H2::_tagName}지점에 낙하했습니다!!",$id);
}

# 나무심기 or 미사일 기지
sub logPBSuc {
 my($id, $name, $comName, $point) = @_;
 logSecret("${H2::tagName_}${name} 섬 $point${H2::_tagName}에서${H2::tagComName_}${comName}${H2::_tagComName}이 실행되었습니다.",$id);
 logOut("어디선가 ${H2::tagName_}${name} 섬${H2::_tagName}의<B>숲</B>이 늘어난 것 같습니다.",$id);
END
}

# 가짜 시설
sub logHariSuc {
 my($id, $name, $comName, $comName2, $point) = @_;
 logSecret("${H2::tagName_}${name} 섬 $point${H2::_tagName}에서${H2::tagComName_}${comName}${H2::_tagComName}이 실행되었습니다.",$id);
 logLandSuc($id, $name, $comName2, $point);
END
}

### ---v--- ver1.10 ---v---
# 허가되지 않는
sub logNotPermitted {
 my($id, $name, $comName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}${comName}${H2::_tagComName}은, 허가되지 않았습니다.",$id);
}
### ---^--- ver1.10 ---^---

# 육지 파괴탄격하려고했지만대상이자신의 섬에서 없는
sub logMsNoOwnLD {
 my($id, $name, $comName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}${comName}${H2::_tagComName}은, 자신의 섬을 대상으로 지정할 수 없기 때문에 중지되었습니다.",$id);
}

# 미사일 발사 또는 괴수 파견 대상이 없음
sub logMsNoTarget {
 my($id, $name, $comName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}${comName}${H2::_tagComName}은, 대상 섬이 무인도이므로 중지되었습니다.",$id);
END
}

# 미사일 발사를 시도했지만 기지가 없음
sub logMsNoBase {
 my($id, $name, $comName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 예정되어 있던${H2::tagComName_}${comName}${H2::_tagComName}은,<B>미사일 설비가 없어</B> 실행할 수 없었습니다.",$id);
END
}

# 발사실패
sub logMsFail {
 my($id, $tId, $name, $tName, $comName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을해 주려고했지만,<B>발사실패</B>했습니다.",$id, $tId);
}

# 미사일 발사 결과 범위 밖
sub logMsOut {
 my($id, $tId, $name, $tName, $comName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
}

# 스텔스 미사일 발사 결과 범위 밖
sub logMsOutS {
 my($id, $tId, $name, $tName, $comName, $point) = @_;
 logSecret("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
 logLate("<B>누군가</B>가${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$tId);
}

# 미사일이 방위 시설에 포착됨
sub logMsCaught {
 my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
}

# 스텔스 미사일이 방위 시설에 포착됨
sub logMsCaughtS {
 my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
 logSecret("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
 logLate("<B>누군가</B>가${H2::tagName_}${tName} 섬 $point${H2::_tagName}을 대상으로${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$tId);
}

# 미사일 발사 결과 효과 없음
sub logMsNoDamage {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);
}

# 접속착탄격했음이효과 없음
sub logMsNoDamageSTI {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 빗나갔기 때문에 효과가 없었습니다.",$id, $tId);
}

# 스텔스 미사일 발사 결과 효과 없음
sub logMsNoDamageS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);

 logLate("<B>누군가</B>가${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$tId);
}

# 육지 파괴탄, 산에 명중
sub logMsLDMountain {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 사라지고, 황무지가 되었습니다.",$id, $tId);
}

# 육지 파괴탄, 해저 기지에 명중
sub logMsLDSbase {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}에 착탄한 뒤 폭발, 같은 지점에 있던<B>$tLname</B>은 흔적도 없이 날아갔습니다.",$id, $tId);
}

# 육지 파괴탄, 괴수에 명중
sub logMsLDMonster {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}에 착탄해 폭발. 육지는<B>괴수 $tLname</B>까지 수몰되었습니다.",$id, $tId);
}

# 육지 파괴탄, 얕은 바다에 명중
sub logMsLDSea1 {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 착탄. 해저가 깎였습니다.",$id, $tId);
}

# 육지 파괴탄, 기타의 지형에 명중
sub logMsLDLand {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 착탄. 육지가 수몰되었습니다.",$id, $tId);
}

# 일반 미사일, 황무지에 착탄
sub logMsWaste {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id, $tId);
}

# 스텔스 미사일, 황무지에 착탄
sub logMsWasteS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id, $tId);
 logLate("<B>누군가</B>가${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행했지만,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 떨어졌습니다.",$tId);
}

# 일반 미사일, 괴수에 명중, 경화 중에서 무사
sub logMsMonNoDamage {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 경화 중에서 무사
sub logMsMonNoDamageS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$id, $tId);
 logOut("<B>누군가</B>가${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$tId);
}

# 괴수에 명중, 알 수 없예유에서 무사
sub logMsMonNoDamage2 {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중, 그러나효과가 없었습니다.",$id, $tId);
}

# 접속착탄, 괴수에 명중, 접착
sub logMsMonStick {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 흔적도 없이 사라졌습니다.",$id, $tId);
}

# 일반 미사일, 괴수에 명중, 살상
sub logMsMonKill {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 힘이 다해 쓰러졌습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 살상
sub logMsMonKillS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 힘이 다해 쓰러졌습니다.",$id, $tId);
 logLate("<B>누군가</B>가${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 힘이 다해 쓰러졌습니다.", $tId);
}

# 일반 미사일, 괴수에 명중, 피해
sub logMsMonster {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 고통스러운 듯 포효했습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 피해
sub logMsMonsterS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 고통스러운 듯 포효했습니다.",$id, $tId);
 logLate("<B>누군가</B>가${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 고통스러운 듯 포효했습니다.",$tId);
}

# 괴수의 시체
sub logMsMonMoney {
 my($tId, $mName, $value) = @_;
 logOut("<B>괴수$mName</B>의 잔해에는,<B>$value$H2::unitMoney</B>의 값어치가 있었습니다.",$tId);
}

# 괴수의HIT상금
sub logMsMonMoneyH {
 my($id, $name, $mName, $value) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}은<B>괴수$mName</B>퇴치의 공로로<B>$value$H2::unitMoney</B>획득했습니다.",$id);
}

# 한 송이의 꽃피다쿠
sub LogMsFlowBloom{
 my($tId, $tName, $tPoint) = @_;
 logOut("${H2::tagName_}${tName} 섬$tPoint${H2::_tagName}의황무지에<B>한 송이의 꽃이피다옵니다했습니다</B>.",$tId);
}

# 한 송이의 꽃마름됨
sub LogMsFlowWither{
 my($id, $name, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의황무지에피어 있던<B>한 송이의 꽃이시들었습니다</B>.",$id);
}

# 일반 미사일 일반 지형에 명중
sub logMsNormal {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.",$id, $tId);
}

# 스텔스 미사일 일반 지형에 명중
sub logMsNormalS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.",$id, $tId);
 logLate("<B>누군가</B>가${H2::tagName_}${tName} 섬 $point${H2::_tagName}지점을 향해${H2::tagComName_}${comName}${H2::_tagComName}을 실행하여,${H2::tagName_}$tPoint${H2::_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.",$tId);
}

# 난민 도착
sub logMsBoatPeople {
 my($id, $name, $achive) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에어디선가<B>$achive${H2::unitPop}명의 난민</B>이 표류해 왔습니다.${H2::tagName_}${name} 섬${H2::_tagName}은 살기 좋아진 것 같습니다.",$id);
}

# 괴수 파견
sub logMonsSend {
 my($id, $tId, $name, $tName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이<B>인공괴수</B>를 만들었습니다.${H2::tagName_}${tName} 섬${H2::_tagName}로 보냈습니다.",$id, $tId);
}

# 자금 조달
sub logDoNothing {
 my($id, $name, $comName) = @_;
# logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서${H2::tagComName_}${comName}${H2::_tagComName}이 실행되었습니다.",$id);
}

# 수출
sub logSell {
 my($id, $name, $comName, $value) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이<B>$value$H2::unitFood</B>의${H2::tagComName_}${comName}${H2::_tagComName}을 실행했습니다.",$id);
}

# 지원
sub logAid {
 my($id, $tId, $name, $tName, $comName, $str) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이${H2::tagName_}${tName} 섬${H2::_tagName}로<B>$str</B>의${H2::tagComName_}${comName}${H2::_tagComName}을 실행했습니다.",$id, $tId);
}

# 유치 활동
sub logPropaganda {
 my($id, $name, $comName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서${H2::tagComName_}${comName}${H2::_tagComName}이 실행되었습니다.",$id);
}

# 포기
sub logGiveup {
 my($id, $name) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}은 포기되어 <B>무인 섬</B>이 되었습니다.",$id);
 logHistory("${H2::tagName_}${name} 섬${H2::_tagName}, 포기되어 <B>무인 섬</B>이 됩니다.");
}

# 사멸
sub logDead {
 my($id, $name) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서 주민이 사라져 <B>무인 섬</B>이 되었습니다.",$id);
 logHistory("${H2::tagName_}${name} 섬${H2::_tagName}, 주민이 사라져 <B>무인 섬</B>이 됩니다.");
}

# 발견
sub logDiscover {
 my($name) = @_;
 logHistory("${H2::tagName_}${name} 섬${H2::_tagName}이 발견됩니다.");
}

# 이름의 변경
sub logChangeName {
 my($name1, $name2) = @_;
 logHistory("${H2::tagName_}${name1} 섬${H2::_tagName}, 명칭을${H2::tagName_}${name2} 섬${H2::_tagName}에 변경.");
}

# 기아
sub logStarve {
 my($id, $name) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}의${H2::tagDisaster_}식량이 부족${H2::_tagDisaster}하고 있습니다!!",$id);
}

# 괴수 출현
sub logMonsCome {
 my($id, $name, $mName, $point, $lName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에<B>괴수$mName</B> 출현!!${H2::tagName_}$point${H2::_tagName}의<B>$lName</B>이 짓밟혀 파괴되었습니다.",$id);
}

# 괴수 이동
sub logMonsMove {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>이<B>괴수$mName</B>에게 짓밟혀 파괴되었습니다.",$id);
}

### ---v--- ver1.10 ---v---
# 괴수, 바다로 이동
sub logMonsMoveSea {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>에서 <B>괴수$mName</B>이 바다 목욕을 즐겼습니다.",$id);
}
### ---^--- ver1.10 ---^---

# 괴수는 방위 시설을 밟지 않음
sub logMonsMoveDefence {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("<B>괴수$mName</B>이${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>로 도달,<B>${lName}의 자폭장치가 작동!!</B>",$id);
}

# 괴수, 포효
sub logMonsShout {
 my($id, $name, $point, $mName) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>괴수$mName</B>이<B>포효</B>을 올렸습니다!",$id);
}

# 괴수, 농장식이거침하게 함
sub logMonsMoveFarm {
 my($id, $name, $lName, $point, $mName, $upmHp) = @_;
 logOut("<B>괴수$mName</B>이${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>을 식이악성,<B>체력을$upmHp 증가</B>하게했습니다.",$id);
}

# 괴수, 방어 시설에포획
sub logMonsMoveHoihoi {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>이<B>괴수$mName</B>을 포획,<B>괴수$mName</B>은<B>육지마저 녹여 버렸습니다</B>했습니다.",$id);
}

# 괴수, 접착해제
sub logMonsStickOff {
 my($id, $name, $point, $mName) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>괴수$mName</B>로의<B>착탄 효과 가 사라짐</B>, 다시 움직이기 시작했습니다.",$id);
}

# 약품사고
sub logYakuhin {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>데${H2::tagDisaster_}약품 사고 발생!!${H2::_tagDisaster}",$id);
}

# 안영역 피해, 수몰
sub logMiddleDamageSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의 육지는 녹아내렸고, <B>$lName</B>은 <B>수몰</B>되었습니다.",$id);
}

# 안영역 피해, 바다의 건설
sub logMiddleDamageSea2 {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은 용해해제했습니다.",$id);
}

# 화재
sub logFire {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>이${H2::tagDisaster_}화재${H2::_tagDisaster}로 괴멸되었습니다.",$id);
}

# 매장금
sub logMaizo {
 my($id, $name, $comName, $value) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}로의${H2::tagComName_}$comName${H2::_tagComName}중에,<B>$value$H2::unitMoney 상당의 매장금</B>을 발견했습니다.",$id);
}

# 지진발생
sub logEarthquake {
 my($id, $name) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}로 대규모${H2::tagDisaster_}지진${H2::_tagDisaster}이 발생!!",$id);
}

# 지진 피해
sub logEQDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은${H2::tagDisaster_}지진${H2::_tagDisaster}로 괴멸되었습니다.",$id);
}

# 식량 부족 피해
sub logSvDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>에<B>식량을 찾는 주민이 몰려들었습니다</B>.<B>$lName</B>은 괴멸되었습니다.",$id);
}

# 쓰나미발생
sub logTsunami {
 my($id, $name) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}부근에서${H2::tagDisaster_}쓰나미${H2::_tagDisaster}발생!!",$id);
}

# 쓰나미 피해
sub logTsunamiDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은${H2::tagDisaster_}쓰나미${H2::_tagDisaster}로붕괴했습니다.",$id);
}

# 태풍발생
sub logTyphoon {
 my($id, $name) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에${H2::tagDisaster_}태풍${H2::_tagDisaster}상륙!!",$id);
}

# 태풍 피해
sub logTyphoonDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은${H2::tagDisaster_}태풍${H2::_tagDisaster}으로 날아갔습니다.",$id);
}

# 운석, 바다
sub logMeteoSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>에${H2::tagDisaster_}운석${H2::_tagDisaster}이 낙하했습니다.",$id);
}

# 운석, 산
sub logMeteoMountain {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>에${H2::tagDisaster_}운석${H2::_tagDisaster}이 낙하,<B>$lName</B>은 사라졌습니다.",$id);
}

# 운석, 해저 기지
sub logMeteoSbase {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>에${H2::tagDisaster_}운석${H2::_tagDisaster}이 낙하,<B>$lName</B>은 붕괴했습니다.",$id);
}

# 운석, 괴수
sub logMeteoMonster {
 my($id, $name, $lName, $point) = @_;
 logOut("<B>괴수$lName</B>이 있던${H2::tagName_}${name} 섬 $point${H2::_tagName}지점에${H2::tagDisaster_}운석${H2::_tagDisaster}이 낙하, 육지는<B>괴수 $lName</B>까지 수몰되었습니다.",$id);
}

# 운석, 얕은 바다
sub logMeteoSea1 {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}지점에${H2::tagDisaster_}운석${H2::_tagDisaster}이 낙하, 해저가 깎였습니다.",$id);
}

# 운석, 기타
sub logMeteoNormal {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}지점의<B>$lName</B>에${H2::tagDisaster_}운석${H2::_tagDisaster}이 낙하, 일대가 수몰되었습니다.",$id);
}

# 운석, 기타
sub logHugeMeteo {
 my($id, $name, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}지점에${H2::tagDisaster_}거대운석${H2::_tagDisaster}이 낙하!!",$id);
}

# 분화
sub logEruption {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}지점에서${H2::tagDisaster_}화산이 분화${H2::_tagDisaster},<B>산</B>이 생겼습니다.",$id);
}

# 분화, 얕은 바다
sub logEruptionSea1 {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}지점의<B>$lName</B>은,${H2::tagDisaster_}분화${H2::_tagDisaster}의 영향으로 육지가 되었습니다.",$id);
}

# 분화, 바다 or 바다 기준
sub logEruptionSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}지점의<B>$lName</B>은,${H2::tagDisaster_}분화${H2::_tagDisaster}의 영향으로 해저가 융기하여, 얕은 바다가 되었습니다.",$id);
}

# 분화, 기타
sub logEruptionNormal {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}지점의<B>$lName</B>은,${H2::tagDisaster_}분화${H2::_tagDisaster}의 영향으로 괴멸되었습니다.",$id);
}

# 지반 침하발생
sub logFalldown {
 my($id, $name) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}에서${H2::tagDisaster_}지반 침하${H2::_tagDisaster}이 발생했습니다!!",$id);
}

# 지반 침하 피해
sub logFalldownLand {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은 바다의 안로 침몰봄했습니다.",$id);
}

# 광역 피해, 수몰
sub logWideDamageSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은<B>수몰</B>했습니다.",$id);
}

# 광역 피해, 바다의 건설
sub logWideDamageSea2 {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은 흔적도 없이 사라졌습니다.",$id);
}

# 광역 피해, 괴수수몰
sub logWideDamageMonsterSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의 육지는<B>괴수 $lName</B>까지 수몰되었습니다.",$id);
}

# 광역 피해, 괴수
sub logWideDamageMonster {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>괴수$lName</B>은 사라졌습니다.",$id);
}

# 광역 피해, 황무지
sub logWideDamageWaste {
 my($id, $name, $lName, $point) = @_;
 logOut("${H2::tagName_}${name} 섬 $point${H2::_tagName}의<B>$lName</B>은 한순간에 <B>황무지</B>가 되었습니다.",$id);
}

# 수상
sub logPrize {
 my($id, $name, $pName) = @_;
 logOut("${H2::tagName_}${name} 섬${H2::_tagName}이<B>$pName</B>을 수상했습니다.",$id);
 logHistory("${H2::tagName_}${name} 섬${H2::_tagName},<B>$pName</B>을 수상");
}

# 섬이 가득 찬 경우
sub tempNewIslandFull {
 out(<<END);
${H2::tagBig_}신청이 몰려, 섬이 가득 차서 등록할 수 없습니다.${H2::_tagBig}$H2::tempBack
END
}

# 신규 등록 시 이름이 없는 경우
sub tempNewIslandNoName {
 out(<<END);
${H2::tagBig_} 섬 이름이 필요합니다.${H2::_tagBig}$H2::tempBack
END
}

# 신규 등록 시 이름이 올바르지 않은 경우
sub tempNewIslandBadName {
 out(<<END);
${H2::tagBig_}',?()<>\$'등을 넣거나,'무인 섬'등 이상한 이름은 피하세요~${H2::_tagBig}$H2::tempBack
END
}

# 이미 같은 이름의 섬이 있는 경우
sub tempNewIslandAlready {
 out(<<END);
${H2::tagBig_}그 섬이면 이미 발견되어 있습니다.${H2::_tagBig}$H2::tempBack
END
}

# 비밀번호가 없는 경우
sub tempNewIslandNoPassword {
 out(<<END);
${H2::tagBig_} 비밀번호가필요입니다.${H2::_tagBig}$H2::tempBack
END
}

# 섬을 발견했습니다!!
sub tempNewIslandHead {
 out(<<END);
<CENTER>
${H2::tagBig_} 섬을 발견했습니다!!${H2::_tagBig}<BR>
${H2::tagBig_}${H2::tagName_}'${H2::currentName} 섬'${H2::_tagName}을 찾았습니다.${H2::_tagBig}<BR>
$H2::tempBack<BR>
</CENTER>
END
}

# 지형의 호출분
sub landName {
 my($land, $lv) = @_;
 if($land == $H2::landSea) {
	if($lv == 1) {
 return '얕은 바다';
 } else {
 return '바다';
	}
 } elsif($land == $H2::landWaste) {
	return '황무지';
 } elsif($land == $H2::landPlains) {
	return '평지';
 } elsif($land == $H2::landTown) {
	if($lv < 30) {
	 return '마을';
	} elsif($lv < 100) {
	 return '마을';
	} else {
	 return '도시';
	}
 } elsif($land == $H2::landForest) {
	return '숲';
 } elsif($land == $H2::landFarm) {
	return '농장';
 } elsif($land == $H2::landFactory) {
	return '공장';
 } elsif($land == $H2::landBase) {
	return '미사일 기지';
 } elsif($land == $H2::landDefence) {
	return '방위 시설';
 } elsif($land == $H2::landMountain) {
	return '산';
### ---v--- ver1.10 ---v---
 } elsif(($land == $H2::landMonster)||($land == $H2::landMonsterS)) {
	my($kind, $name, $hp) = monsterSpec($lv);
	return $name;
### ---^--- ver1.10 ---^---
 } elsif($land == $H2::landSbase) {
	return '해저 기지';
 } elsif($land == $H2::landOil) {
	return '해저 유전';
 } elsif($land == $H2::landMonument) {
	return $H2::monumentName[$lv];
 } elsif($land == $H2::landHaribote) {
	return '가짜 시설';
 } elsif($land == $H2::landHoihoi) {
	return '방어 시설';
 }
}

# 인구기타의 값을 산출
sub estimate {
 my($number) = $_[0];
 my($island);
 my($pop, $area, $farm, $factory, $mountain) = (0, 0, 0, 0, 0, 0);

 # 지형을 가져옴
 $island = $H2::islands[$number];
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 # 수 가능
 my($x, $y, $kind, $value);
 for($y = 0; $y < $H2::islandSize; $y++) {
	for($x = 0; $x < $H2::islandSize; $x++) {
	 $kind = $land->[$x][$y];
	 $value = $landValue->[$x][$y];
	 if(($kind != $H2::landSea) &&
	 ($kind != $H2::landSbase) &&
	 ($kind != $H2::landOil)){
		$area++;
		if($kind == $H2::landTown) {
		 # 마을
		 $pop += $value;
		} elsif($kind == $H2::landFarm) {
		 # 농장
		 $farm += $value;
		} elsif($kind == $H2::landFactory) {
		 # 공장
		 $factory += $value;
		} elsif($kind == $H2::landMountain) {
		 # 산
		 $mountain += $value;
		}
	 }
	}
 }

 # 대입
 $island->{'pop'} = $pop;
 $island->{'area'} = $area;
 $island->{'farm'} = $farm;
 $island->{'factory'} = $factory;
 $island->{'mountain'} = $mountain;
}


# 범위 안의 지형을 수 가능
sub countAround {
 my($land, $x, $y, $kind, $range) = @_;
 my($i, $count, $sx, $sy);
 $count = 0;
 for($i = 0; $i < $range; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	 }

	 if(($sx < 0) || ($sx>= $H2::islandSize) ||
	 ($sy < 0) || ($sy>= $H2::islandSize)) {
	 # 범위 밖의 경우
	 if($kind == $H2::landSea) {
		 # 바다이면 가 산
		 $count++;
	 }
	 } else {
	 # 범위 안의 경우
	 if($land->[$sx][$sy] == $kind) {
		 $count++;
	 }
	 }
 }
 return $count;
}

# 1hex 선의 목표 지형의 좌표를 무작위로 탐색
sub searchAroundPoint {
 my($land, $x, $y, $kind) = @_;
 #주변 1헥스(현지점제외)의 좌표
 my(@rax) = ( 1, 1, 1, 0,-1, 0);
 my(@ray) = (-1, 0, 1, 1, 0,-1);

 # 셔터 전체
 my($i);
 for ($i = 6; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; };
	@rax[$i,$j] = @rax[$j,$i];
	@ray[$i,$j] = @ray[$j,$i];
 }

 my($k, $sx, $sy);
 for($k = 0; $k < 6; $k++) {
	$sx = $x + $rax[$k];
	$sy = $y + $ray[$k];

	# 행 기준 위치 조정
	if((($sy % 2) == 0) && (($y % 2) == 1)) {
		$sx--;
	}

	if(($sx < 0) || ($sx>= $H2::islandSize) ||
	 ($sy < 0) || ($sy>= $H2::islandSize)) {
	 # 범위 밖
		next;
	 } else {
	 # 범위 안의 목표 지형
	 if($land->[$sx][$sy] == $kind) {
		last;
	 }
	 }
 }

 #목표 지형없음
 if($k == 6) {$sx = $sy = -1;}

 return ($sx, $sy);
}

# 0에서(n - 1)까지의 숫자가한 번씩출해 옵니다 수열을 만들기
sub randomArray {
 my($n) = @_;
 my(@list, $i);

 # 초기 값
 if($n == 0) {
	$n = 1;
 }
 @list = (0..$n-1);

 # 셔터 전체
 for ($i = $n; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; };
	@list[$i,$j] = @list[$j,$i];
 }

 return @list;
}

# 이름 변경실패
sub tempChangeNothing {
 out(<<END);
${H2::tagBig_}이름과 비밀번호가 모두 비어 있습니다${H2::_tagBig}$H2::tempBack
END
}

# 이름 변경 자금 부족
sub tempChangeNoMoney {
 out(<<END);
${H2::tagBig_} 자금 부족으로 변경할 수 없습니다${H2::_tagBig}$H2::tempBack
END
}

# 이름 변경성공
sub tempChange {
 out(<<END);
${H2::tagBig_}변경을 완료했습니다${H2::_tagBig}$H2::tempBack
END
}

1;
