#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30개정 괴수 대작전 ver1.0.0
# 명예의 전당 스크립트(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도(할아버지)의 페이지: http://t.pos.to/ozzy/
#----------------------------------------------------------------------
# Arranged by 차차마루 : http://www.geocities.co.jp/SiliconValley-Bay/2566/
# 2000/06/17
#----------------------------------------------------------------------

# 전체 명예의 전당 데이터 읽기
sub readHofFile {
 open(HOF, "${HEnvDirName}/hof.log");

 $HnumOfHof = int(<HOF>);

 for ($i = 0; $i < $HnumOfHof; $i ++) {
	$HhofIslands[$i] = readHofIsland( );
 }

 close(HOF);
}

# 섬 하나 읽기
sub readHofIsland {
 my($id, $name, $turn, $comment);

 $id = int(<HOF>);
 $name = <HOF>;
 chomp($name);
 $turn = int(<HOF>);
 $comment = <HOF>;
 chomp($comment);

 return {
	'id' => $id,
	'name' => $name,
	'turn' => $turn,
	'comment' => $comment,
 };
}

# 전체 명예의 전당 파일 쓰기
sub writeHofFile {
 hofSort(); # 정렬
 if ($HnumOfHof> 50) {
	$HnumOfHof = 50; # 상위 항목만 유지
 }

 open(HOF, ">${HEnvDirName}/hof.log");

 print HOF "$HnumOfHof\n";

 my($i);
 for ($i = 0; $i < $HnumOfHof; $i++) {
	writeHofIsland($HhofIslands[$i]);
 }

 close(HOF);
 writeHofHtml();
}

sub writeHofIsland {
 my($island) = @_;
 print HOF $island->{'id'}. "\n";
 print HOF $island->{'name'}. "\n";
 print HOF $island->{'turn'}. "\n";
 print HOF $island->{'comment'}. "\n";
}

# 정렬
sub hofSort {
 # 같은 기록이면 이전 턴의 순서를 유지
 my @idx = (0..$#HhofIslands);
 @idx = sort { $HhofIslands[$a]->{'turn'} <=> $HhofIslands[$b]->{'turn'} || $HhofIslands[$a]->{'id'} <=> $HhofIslands[$b]->{'id'} } @idx;
 @HhofIslands = @HhofIslands[@idx];
}

# 추가
sub pushHofIsland {
 my($island) = @_;

 $HhofIslands[$HnumOfHof++] = {
	'id' => $island->{'id'},
	'name' => $island->{'name'},
	'turn' => $HislandTurn - $island->{'ext'}[0],
	'comment' => $island->{'comment'},
 };
}

# HTML 파일 생성
sub writeHofHtml {
 open(HOFHTML, ">hof.cgi");
 my($htmlBody) = 'BGCOLOR="#EEFFFF"';
 # 여기는 약간의 예외 처리
print HOFHTML "#!$HEnvPerl\n";
print HOFHTML "print <<END;\n";

 # 헤더
print HOFHTML "Content-type: text/html; charset=UTF-8\n\n";
print HOFHTML "<HTML><HEAD><META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\"><TITLE>$Htitle</TITLE><BASE HREF=\"$HEnvImageDir/\"></HEAD>\n";
print HOFHTML "<BODY $htmlBody><A HREF=\"http://t.pos.to/hako/\">모형정원 제도 스크립트 배포처</A><HR>\n";


print HOFHTML "<CENTER><H1>${HtagHeader_}위대한 괴수 헌터 달성 기록${H_tagHeader}</H1>$HtempBack<BR><HR>\n";
print HOFHTML "<TABLE BORDER><TR>\n";
print HOFHTML "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>\n";
print HOFHTML "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 섬 이름${H_tagTH}</NOBR></TH>\n";
print HOFHTML "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}기록${H_tagTH}</NOBR></TH>\n";
print HOFHTML "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}코멘트${H_tagTH}</NOBR></TH></TR>\n";

 my($i, $j, $island);
 my($tmpTurn) = 0;
 for ($i = 0; $i < $HnumOfHof; $i++) {
	$island = $HhofIslands[$i];
	if ($tmpTurn < $island->{'turn'}) {
	 $tmpTurn = $island->{'turn'};
	 $j = $i + 1;
	}

print HOFHTML "<TR><TD $HbgNumberCell align=center nowrap=nowrap><NOBR>${HtagNumber_}$j${H_tagNumber}</NOBR></TD>\n";
print HOFHTML "<TD $HbgNameCell align=left nowrap=nowrap><NOBR>${HtagName_}$island->{'name'} 섬${_HtagName}</NOBR></TD>\n";
print HOFHTML "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'turn'}턴</NOBR></TD>\n";
print HOFHTML "<TD $HbgCommentCell align=left nowrap=nowrap><NOBR>$island->{'comment'}</NOBR></TD></TR>\n";
 }

print HOFHTML "</TABLE></CENTER>\n";
print HOFHTML "</P></BODY></HTML>\n";

print HOFHTML "END\n";
 close(HOFHTML);
}
### ---v--- arrange ---v---
 chmod($HEnvHofMode, 'hof.cgi');
### ---^--- arrange ---^---

1;
