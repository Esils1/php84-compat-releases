#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30개정 괴수 대작전 ver1.0.0
# 환경 설정 스크립트(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도(할아버지)의 페이지: http://t.pos.to/ozzy/
#----------------------------------------------------------------------
# Arranged by 차차마루 : http://www.geocities.co.jp/SiliconValley-Bay/2566/
# 2000/06/17
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 설정 값
# 아래 설정 값을 서버 환경에 맞게 변경해 주세요.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 반드시 설정해야 하는 항목입니다
#----------------------------------------------------------------------

# 이 파일을 설치할 디렉터리
# $HEnvBaseDir = 'http://서버/디렉터리';
#
# 예)
# http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa/hako-main.cgi
# 처럼 배치한 경우,
# $HEnvBaseDir = 'http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa';
# 지합니다. 끝에 슬래시(/)는 붙이지 않습니다.

my $HEnvScheme = (($ENV{'HTTPS'} || '') =~ /^(on|1)$/i) ? 'https' : 'http';
my $HEnvHost = $ENV{'HTTP_HOST'} || $ENV{'SERVER_NAME'} || 'localhost';
if (!$ENV{'HTTP_HOST'} && $ENV{'SERVER_PORT'} && !(($HEnvScheme eq 'http' && $ENV{'SERVER_PORT'} == 80) || ($HEnvScheme eq 'https' && $ENV{'SERVER_PORT'} == 443))) {
 $HEnvHost.= ":$ENV{'SERVER_PORT'}";
}
my $HEnvScriptDir = $ENV{'SCRIPT_NAME'} || '';
$HEnvScriptDir =~ s{/[^/]*$}{};
$HEnvBaseDir = "$HEnvScheme://$HEnvHost$HEnvScriptDir";


# 이미지 파일을 둘 디렉터리
# $HEnvImageDir = 'http://서버/디렉터리';
#$HEnvImageDir = $HEnvBaseDir;
$HEnvImageDir = 'https://esils.com/BBdata/hakoimg';
# 문자 변환 라이브러리 위치
# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.

# perl 위치(hof용)
#$HEnvPerl = '/usr/loca/bin/perl';
$HEnvPerl = '/usr/bin/perl';

### ---v--- arrange ---v---
# hof.cgi 권한
$HEnvHofMode = 0755;
### ---^--- arrange ---^---

# 마스터 비밀번호
# 이 비밀번호는, 모든 섬의 비밀번호를 대신 사용할 수 있습니다.
# 예를 들어,'다른 섬의 비밀번호 변경'등도 할 수 있습니다.
$HEnvMasterPassword = '1064';

# 특수 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 그 섬의 자금, 식량이 최댓값이 됩니다.
# (실제로 이름이 변경될 필요는 없습니다.)
$HEnvSpecialPassword = 'yourspecialpassword';

# 디렉터리 권한
# 일반적으로 0755이면 좋지만,0777,0705,0704등에서 없으면 사용 불가는 서버도 있습니다
$HEnvDirMode = 0755;

# 데이터 디렉터리 이름
# 여기에서 설정한 이름의 디렉터리 아래에 데이터가 저장됩니다.
# 기본값에서는'data'로 되어 있지만, 보안상
# 보안을 위해 다른 이름으로 변경해 주세요.
$HEnvDirName = 'data';

# 데이터 쓰기 권한

# 잠금 방식
# 1 디렉터리
# 2 시스템 콜(가능하면 이 방식을 권장합니다)
# 3 심볼릭 링크
# 4 일반 파일(권장하지 않음)
$HEnvLockMode = 2;

# (주)
# 4을 선택하는 경우에는,'key-free'라는, 권한 666의 빈 파일을,
# 이 파일과 같은 위치에 배치해 주세요.

# 비밀번호 암호화(0: 암호화하지 않음, 1: 암호화함)
$HEnvCryptOn = 1;

# 디버그 모드(1이면 '턴 진행' 버튼을 사용할 수 있음)
$HEnvDebug = 0;

1;
