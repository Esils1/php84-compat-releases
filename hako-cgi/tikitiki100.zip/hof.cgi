#!/usr/bin/perl
print <<END;
Content-type: text/html; charset=UTF-8

<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8"><TITLE>치키치키괴수 대작전!</TITLE><BASE HREF="https://esils.com/BBdata/hakoimg/"></HEAD>
<BODY BGCOLOR="#EEFFFF"><A HREF="http://t.pos.to/hako/">모형정원 제도 스크립트 배포처</A><HR>
<CENTER><H1><FONT COLOR="#4444ff">위대한 괴수 헌터 달성 기록</FONT></H1><A HREF="hako-main.cgi"><FONT SIZE=6>맨 위로 돌아가기</FONT></A><BR><HR>
<TABLE BORDER><TR>
<TH BGCOLOR="#ccffcc" align=center nowrap=nowrap><NOBR><FONT COLOR="#C00000"><B>순위</B></FONT></NOBR></TH>
<TH BGCOLOR="#ccffcc" align=center nowrap=nowrap><NOBR><FONT COLOR="#C00000"><B> 섬 이름</B></FONT></NOBR></TH>
<TH BGCOLOR="#ccffcc" align=center nowrap=nowrap><NOBR><FONT COLOR="#C00000"><B>기록</B></FONT></NOBR></TH>
<TH BGCOLOR="#ccffcc" align=center nowrap=nowrap><NOBR><FONT COLOR="#C00000"><B>코멘트</B></FONT></NOBR></TH></TR>
</TABLE></CENTER>
</P></BODY></HTML>
END
