#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# JavaScript 개발 화면 모듈
#----------------------------------------------------------------------

sub _jsq {
 my($s) = @_;
 $s =~ s/\\/\\\\/g;
 $s =~ s/'/\\'/g;
 $s =~ s/\r//g;
 $s =~ s/\n/ /g;
 return $s;
}

sub _js_cost_label {
 my($kind) = @_;
 my($cost) = $HcomCost[$kind];
 if($cost == 0) {
  return '무료';
 } elsif($cost < 0) {
  $cost = -$cost;
  return "${cost}${HunitFood}";
 } else {
  return "${cost}${HunitMoney}";
 }
}

#---------------------------------------------------------------------
# 개발 화면(JavaScript 모드)
#---------------------------------------------------------------------
sub tempOwnerJava {
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];

 my(@command_rows);
 for(my $i = 0; $i < $HcommandMax; $i++) {
  my($command) = $island->{'command'}->[$i];
  my($s_kind, $s_target, $s_x, $s_y, $s_arg) =
  (
   $command->{'kind'},
   $command->{'target'},
   $command->{'x'},
   $command->{'y'},
   $command->{'arg'}
  );
  push(@command_rows, "[$s_kind,$s_x,$s_y,$s_arg,$s_target]");
 }
 my($set_com) = join(",\n", @command_rows);

 my(@list_rows);
 for(my $i = 0; $i < $HcommandTotal; $i++) {
  my($kind) = $HcomList[$i];
  next if($kind == $HcomAutoPrepare || $kind == $HcomAutoPrepare2 || $kind == $HcomAutoDelete);
  my($name) = _jsq($HcomName[$kind]);
  push(@list_rows, "[$kind,'$name']");
 }
 my($set_listcom) = join(",\n", @list_rows);

 my(@island_rows);
 for(my $i = 0; $i < $HislandNumber; $i++) {
  my($name) = _jsq($Hislands[$i]->{'name'});
  my($id) = $Hislands[$i]->{'id'};
  push(@island_rows, "[$id,'$name']");
 }
 my($set_island) = join(",\n", @island_rows);

 my(@auto_option_rows);
 for my $kind ($HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoDelete) {
  next if(!defined($HcomName[$kind]) || $HcomName[$kind] eq '');
  my($cost) = _js_cost_label($kind);
  push(@auto_option_rows, qq#<OPTION VALUE="$kind">$HcomName[$kind]($cost)</OPTION>#);
 }
 my($auto_option_html) = join("\n", @auto_option_rows);

 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
var isIE4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appVersion).indexOf("MSIE") != -1);
var isNN6 = !!document.getElementById;
var mouseX = 0;
var mouseY = 0;

var command = [
$set_com
];
var comlist = [
$set_listcom
];
var islname = [
$set_island
];
var g = new Array(command.length);
var tmpcom1 = [];
var tmpcom2 = [];
var k1 = [];
var k2 = [];

function init(){
 for(var i = 0; i < command.length ; i++) {
  g[i] = commandName(command[i][0]);
 }
 outp();
 var str = plchg();
 str = "<NOBR><font color=blue>---- 전송 완료 ----</font></NOBR><br>" + str;
 disp(str, "#ccffcc");
 document.onmousedown = getMouseData;
 document.onkeydown = commandKeyDown;
}

function commandKeyDown(e) {
 e = e || window.event;
 var src = e.target || e.srcElement;
 var tag = src && src.tagName ? src.tagName.toUpperCase() : '';
 if(tag == 'INPUT' || tag == 'TEXTAREA' || tag == 'SELECT') { return true; }
 var code = e.keyCode || e.which;
 if(code == 46) {
  cominput(3);
  if(e.preventDefault) { e.preventDefault(); }
  return false;
 }
 return true;
}

function commandName(kind) {
 for(var i = 0; i < comlist.length; i++) {
  if(parseInt(comlist[i][0], 10) == parseInt(kind, 10)) {
   return comlist[i][1];
  }
 }
 return '자금 조달';
}

function islandName(id) {
 for(var i = 0; i < islname.length; i++) {
  if(parseInt(islname[i][0], 10) == parseInt(id, 10)) {
   return islname[i][1] + ' 섬';
  }
 }
 return '무인';
}

function markDirty(){
 var str = plchg();
 str = "<NOBR><font color=red><b>----- 미전송 -----</b></font></NOBR><br>" + str;
 disp(str, "white");
 outp();
}

function cominput(x, k, z) {
 var form = document.myForm;
 var a = parseInt(form.NUMBER.options[form.NUMBER.selectedIndex].value, 10);
 var b = parseInt(form.COMMAND.options[form.COMMAND.selectedIndex].value, 10);
 var c = parseInt(form.POINTX.options[form.POINTX.selectedIndex].value, 10);
 var d = parseInt(form.POINTY.options[form.POINTY.selectedIndex].value, 10);
 var e = parseInt(form.AMOUNT.options[form.AMOUNT.selectedIndex].value, 10);
 var f = parseInt(form.TARGETID.options[form.TARGETID.selectedIndex].value, 10);
 if(x == 6){ b = parseInt(k, 10); }
 if(z) { f = parseInt(z, 10); }

 if (x == 1 || x == 6) {
  for(var i = $HcommandMax - 1; i > a; i--) {
   command[i] = command[i-1];
   g[i] = g[i-1];
  }
 } else if(x == 3) {
  for(var i = a; i < ($HcommandMax - 1); i++) {
   command[i] = command[i + 1];
   g[i] = g[i + 1];
  }
  command[$HcommandMax - 1] = [$HcomDoNothing,0,0,0,0];
  g[$HcommandMax - 1] = '자금 조달';
  markDirty();
  return true;
 } else if(x == 4) {
  if(a == 0){ return true; }
  tmpcom1[a] = command[a]; tmpcom2[a] = command[a - 1];
  command[a] = tmpcom2[a]; command[a - 1] = tmpcom1[a];
  k1[a] = g[a]; k2[a] = g[a - 1];
  g[a] = k2[a]; g[a - 1] = k1[a];
  ns(a - 1);
  markDirty();
  return true;
 } else if(x == 5) {
  if(a == $HcommandMax - 1){ return true; }
  tmpcom1[a] = command[a]; tmpcom2[a] = command[a + 1];
  command[a] = tmpcom2[a]; command[a + 1] = tmpcom1[a];
  k1[a] = g[a]; k2[a] = g[a + 1];
  g[a] = k2[a]; g[a + 1] = k1[a];
  ns(a + 1);
  markDirty();
  return true;
 }

 g[a] = commandName(b);
 command[a] = [b,c,d,e,f];
 ns(a + 1);
 markDirty();
 menuclose();
 return true;
}

function plchg(){
 var strn1 = "";
 for(var i = 0; i < $HcommandMax; i++) {
  var c = command[i];
  var kindName = '<FONT COLOR="#d08000"><B>' + g[i] + '</B></FONT>';
  var x = c[1];
  var y = c[2];
  var arg = c[3];
  var tgt = c[4];
  var point = '<FONT COLOR="#a06040"><B>(' + x + ',' + y + ')</B></FONT>';
  var target = '<FONT COLOR="#a06040"><B>' + islandName(tgt) + '</B></FONT>';
  var strn2 = '';

  if(c[0] == $HcomDoNothing || c[0] == $HcomGiveup || c[0] == $HcomPropaganda || c[0] == $HcomSetMonster) {
   strn2 = kindName;
  } else if(c[0] == $HcomMissileNM || c[0] == $HcomMissilePP || c[0] == $HcomMissileST || c[0] == $HcomMissileLD) {
   var shots = (arg == 0) ? '(무제한)' : '(' + arg + '발)';
   strn2 = target + point + '로 ' + kindName + shots;
  } else if(c[0] == $HcomSendMonster) {
   strn2 = target + '로 ' + kindName;
  } else if(c[0] == $HcomSell) {
   if(arg == 0){ arg = 1; }
   strn2 = kindName + '(' + (arg * 100) + '$HunitFood)';
  } else if(c[0] == $HcomMoney) {
   if(arg == 0){ arg = 1; }
   strn2 = target + '로 ' + kindName + '(' + (arg * $HcomCost[$HcomMoney]) + '$HunitMoney)';
  } else if(c[0] == $HcomFood) {
   if(arg == 0){ arg = 1; }
   strn2 = target + '로 ' + kindName + '(' + (arg * 100) + '$HunitFood)';
  } else if(c[0] == $HcomDestroy) {
   if(arg == 0){
    strn2 = point + '에서 ' + kindName;
   } else {
    strn2 = point + '에서 ' + kindName + '(예산' + (arg * $HcomCost[$HcomDestroy]) + '$HunitMoney)';
   }
  } else if(c[0] == $HcomFarm || c[0] == $HcomFactory || c[0] == $HcomMountain) {
   if(arg != 0){
    strn2 = point + '에서 ' + kindName + '(' + arg + '회)';
   } else {
    strn2 = point + '에서 ' + kindName;
   }
  } else {
   strn2 = point + '에서 ' + kindName;
  }

  var tmpnum = (i < 9) ? '0' : '';
  strn1 += '<A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns(' + i + ')"><NOBR>' +
           tmpnum + (i + 1) + ':' + strn2 + '</NOBR></A><BR>\\n';
 }
 return strn1;
}

function disp(str,bgclr){
 if(str == null) str = "";
 if(document.getElementById) {
  document.getElementById("LINKMSG1").innerHTML = str;
  document.getElementById("plan").bgColor = bgclr;
 } else if(document.all) {
  document.all("LINKMSG1").innerHTML = str;
  document.all.plan.bgColor = bgclr;
 }
}

function outp(){
 var comary = "";
 for(var k = 0; k < command.length; k++){
  comary += command[k][0] + " " + command[k][1] + " " + command[k][2] + " " + command[k][3] + " " + command[k][4] + " ";
 }
 document.myForm.COMARY.value = comary;
}

function ps(e, x, y) {
 if(typeof y == "undefined") {
  y = x;
  x = e;
  e = window.event;
 }
 getMouseData(e);
 document.myForm.POINTX.options[x].selected = true;
 document.myForm.POINTY.options[y].selected = true;
 showMenu();
 return true;
}

function ns(x) {
 if (x >= $HcommandMax){ return true; }
 document.myForm.NUMBER.options[x].selected = true;
 return true;
}

function set_com(x, y, land) {
 var com_str = land + "\\n";
 for(var i = 0; i < $HcommandMax; i++) {
  var c = command[i];
  if(x == c[1] && y == c[2] && c[0] < 30){
   com_str += "[" + (i + 1) + "]" + g[i] + " ";
  }
 }
 window.status = com_str;
 document.myForm.COMSTATUS.value = com_str;
}

function jump(theForm) {
 var sIndex = theForm.TARGETID.selectedIndex;
 var url = theForm.TARGETID.options[sIndex].value;
 if (url != "") window.open("$HthisFile?IslandMap=" + url, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}

function showMenu() {
 var el = document.getElementById ? document.getElementById("menu") : window["menu"];
 if(!el) return true;
 var topPos = mouseY - 50;
 if(topPos < 0) { topPos = 0; }
 el.style.position = "absolute";
 el.style.left = mouseX + "px";
 el.style.top = topPos + "px";
 el.style.zIndex = 9999;
 el.style.display = "block";
 el.style.visibility = "visible";
 return true;
}

function menuclose() {
 var el = document.getElementById ? document.getElementById("menu") : window["menu"];
 if(el) el.style.display = "none";
 return true;
}

function getMouseData(e) {
 e = e || window.event;
 if(!e) { return true; }
 if(typeof e.pageX == "number") {
  mouseX = e.pageX;
  mouseY = e.pageY;
 } else {
  mouseX = e.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft || 0);
  mouseY = e.clientY + (document.documentElement.scrollTop || document.body.scrollTop || 0);
 }
 return true;
}

function selectCommandValue(value, label) {
 var sel = document.myForm.COMMAND;
 for(var i = 0; i < sel.options.length; i++) {
  if(String(sel.options[i].value) == String(value)) {
   sel.selectedIndex = i;
   return true;
  }
 }
 sel.options[sel.options.length] = new Option(label || value, value);
 sel.selectedIndex = sel.options.length - 1;
 return true;
}

function firstEmptySlot() {
 for(var i = 0; i < command.length; i++) {
  if(Number(command[i][0]) == $HcomDoNothing) { return i; }
 }
 return command.length - 1;
}

function selectPlanNumber(value) {
 var sel = document.myForm.NUMBER;
 for(var i = 0; i < sel.options.length; i++) {
  if(Number(sel.options[i].value) == Number(value)) {
   sel.selectedIndex = i;
   return true;
  }
 }
 return false;
}

function autoCommandSubmit() {
 var form = document.myForm;
 if(!form || !form.AUTOCOMMAND) { return true; }
 var auto = form.AUTOCOMMAND;
 var label = auto.options[auto.selectedIndex].text;
 selectCommandValue(auto.value, label);
 selectPlanNumber(firstEmptySlot());
 form.COMMANDMODE.value = 'insert';
 return true;
}
//-->
</SCRIPT>
<DIV ID="menu" STYLE="position:absolute; visibility:hidden; display:none; z-index:9999;">
<TABLE BORDER=0 BGCOLOR=#ccffcc>
<TR><TD NOWRAP>
END

 for(my $i = 0; $i < $HcommandTotal; $i++) {
  my($kind) = $HcomList[$i];
  next if($kind >= 30 || $kind == $HcomAutoPrepare || $kind == $HcomAutoPrepare2 || $kind == $HcomAutoDelete);
  my($cost) = _js_cost_label($kind);
  out("<a href=\"javascript:void(0);\" onClick=\"cominput(6,${kind}); return false;\" STYLE=\"text-decoration:none\">$HcomName[$kind]($cost)<BR></A>\n");
 }

 out(<<END);
<HR>
<a href="Javascript:void(0);" onClick="menuclose()" STYLE="text-decoration:none">메뉴 닫기</A>
</TD></TR>
</TABLE>
</DIV>
END

 islandInfo();

 out(<<END);
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell>
<CENTER>
<B>비밀번호</B><BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>동작</B><BR>
<A HREF=JavaScript:void(0); onClick="cominput(1)">삽입</A>
<A HREF=JavaScript:void(0); onClick="cominput(2)">덮어쓰기</A>
<A HREF=JavaScript:void(0); onClick="cominput(3);return false;">삭제</A>
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
 for(my $i = 0; $i < $HcommandMax; $i++) {
  my($j) = $i + 1;
  out("<OPTION VALUE=$i>$j\n");
 }
 out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<SELECT NAME=COMMAND>
END

 for(my $i = 0; $i < $HcommandTotal; $i++) {
  my($kind) = $HcomList[$i];
  next if($kind == $HcomAutoPrepare || $kind == $HcomAutoPrepare2 || $kind == $HcomAutoDelete);
  my($cost) = _js_cost_label($kind);
  my($s) = ($kind == $HdefaultKind) ? 'SELECTED' : '';
  out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>
END
 for(my $i = 0; $i < $HislandSize; $i++) {
  if($i == $HdefaultX) { out("<OPTION VALUE=$i SELECTED>$i\n"); }
  else { out("<OPTION VALUE=$i>$i\n"); }
 }
 out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END
 for(my $i = 0; $i < $HislandSize; $i++) {
  if($i == $HdefaultY) { out("<OPTION VALUE=$i SELECTED>$i\n"); }
  else { out("<OPTION VALUE=$i>$i\n"); }
 }
 out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END
 for(my $i = 0; $i < 100; $i++) {
  out("<OPTION VALUE=$i>$i\n");
 }
 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B>:
<B><BIG><A HREF=JavaScript:void(0); onClick="jump(myForm)" STYLE="text-decoration:none">표시</A></BIG></B><BR>
<SELECT NAME=TARGETID>
$HtargetList<BR>
</SELECT>
<HR>
<B>명령 이동</B><BR>
<BIG><A HREF=JavaScript:void(0); onClick="cominput(4)" STYLE="text-decoration:none">▲</A>..
<A HREF=JavaScript:void(0); onClick="cominput(5)" STYLE="text-decoration:none">▼</A></BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="">
<INPUT TYPE="hidden" NAME="COMMANDMODE" VALUE="insert">
<INPUT TYPE="hidden" NAME="JAVAMODE" VALUE="java">
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}>
<p><font size=2>마지막에 <font color=red>계획 전송 버튼</font>을<br>누르는 것을 잊지 마세요.</font>
</CENTER><BR>
</TD>
<TD $HbgMapCell><CENTER>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA></CENTER>
END
 islandMapJava(1);
 my $comment = $Hislands[$HcurrentNumber]->{'comment'};
 out(<<END);
</TD>
<TD $HbgCommandCell id="plan">
<CENTER>
<B>자동 입력</B><BR>
<SELECT NAME="AUTOCOMMAND">
$auto_option_html
</SELECT><BR>
<INPUT TYPE=submit VALUE="자동 입력 계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'} onClick="return autoCommandSubmit();">
</CENTER>
<HR>
<span id="LINKMSG1"></span>
<BR>
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
<HR>
<CENTER>
${HtagBig_}코멘트 갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$comment"><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="hidden" NAME="JAVAMODE" VALUE="java">
<INPUT TYPE=submit VALUE="코멘트 갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</FORM>
</CENTER>
END
}

#---------------------------------------------------------------------
# 로컬 게시판 입력 양식(JavaScript 모드)
#---------------------------------------------------------------------
sub tempLbbsInputJava {
 out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH>비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="기록" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
 for(my $i = 0; $i < $HlbbsMax; $i++) {
  my($j) = $i + 1;
  out("<OPTION VALUE=$i>$j\n");
 }
 out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$HcurrentID">
<INPUT TYPE="hidden" NAME="JAVAMODE" VALUE="java">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

#---------------------------------------------------------------------
# JavaScript 모드 명령 저장
#---------------------------------------------------------------------
sub commandJavaMain {
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 if(!checkPassword($island->{'password'},$HinputPassword)) {
  unlock();
  tempWrongPassword();
  return;
 }

 my($command) = $island->{'command'};
 my(@values) = split(/\s+/, $HcommandComary);
 for(my $i = 0; $i < $HcommandMax; $i++) {
  my($kind) = shift(@values);
  my($x) = shift(@values);
  my($y) = shift(@values);
  my($arg) = shift(@values);
  my($target) = shift(@values);
  $kind = $HcomDoNothing if(!defined($kind) || $kind eq '' || $kind == 0);
  $x = 0 if(!defined($x) || $x eq '');
  $y = 0 if(!defined($y) || $y eq '');
  $arg = 0 if(!defined($arg) || $arg eq '');
  $target = 0 if(!defined($target) || $target eq '');
  $command->[$i] = {
   'kind' => $kind,
   'x' => $x,
   'y' => $y,
   'arg' => $arg,
   'target' => $target
  };
 }
 tempCommandAdd();
 writeIslandsFile($HcurrentID);
 ownerMain();
}

#---------------------------------------------------------------------
# 지도 표시(JavaScript 모드)
#---------------------------------------------------------------------
sub islandMapJava {
 my($mode) = @_;
 my($island) = $Hislands[$HcurrentNumber];
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 out("<CENTER><TABLE BORDER><TR><TD>\n");
 my($command) = $island->{'command'};
 my(@comStr);
 if($HmainMode eq 'owner') {
  for(my $i = 0; $i < $HcommandMax; $i++) {
   my($j) = $i + 1;
   my($com) = $command->[$i];
   if($com->{'kind'} < 20) {
    $comStr[$com->{'x'}][$com->{'y'}].= " [${j}]$HcomName[$com->{'kind'}]";
   }
  }
 }

 out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");
 for(my $y = 0; $y < $HislandSize; $y++) {
  if(($y % 2) == 0) { out("<IMG SRC=\"space${y}.gif\" width=16 height=32>"); }
  for(my $x = 0; $x < $HislandSize; $x++) {
   my($l) = $land->[$x][$y];
   my($lv) = $landValue->[$x][$y];
   landStringJava($l, $lv, $x, $y, $mode, $comStr[$x][$y]);
  }
  if(($y % 2) == 1) { out("<IMG SRC=\"space${y}.gif\" width=16 height=32>"); }
  out("<BR>");
 }
 out("</TD></TR></TABLE></CENTER>\n");
}

sub landStringJava {
 my($l, $lv, $x, $y, $mode, $comStr) = @_;
 my($point) = "($x,$y)";
 my($image, $alt);

 if($l == $HlandSea) {
  if($lv == 1) { $image = 'land14.gif'; $alt = '바다(얕은 바다)'; }
  else { $image = 'land0.gif'; $alt = '바다'; }
 } elsif($l == $HlandWaste) {
  if($lv == 1) { $image = 'land13.gif'; $alt = '황무지'; }
  else { $image = 'land1.gif'; $alt = '황무지'; }
 } elsif($l == $HlandPlains) {
  $image = 'land2.gif'; $alt = '평지';
 } elsif($l == $HlandForest) {
  $image = 'land6.gif';
  $alt = ($mode == 1) ? "숲(${lv}$HunitTree)" : '숲';
 } elsif($l == $HlandTown) {
  my($p, $n);
  if($lv < 30) { $p = 3; $n = '마을'; }
  elsif($lv < 100) { $p = 4; $n = '마을'; }
  else { $p = 5; $n = '도시'; }
  $image = "land${p}.gif"; $alt = "$n(${lv}$HunitPop)";
 } elsif($l == $HlandFarm) {
  $image = 'land7.gif'; $alt = "농장(${lv}0${HunitPop}규모)";
 } elsif($l == $HlandFactory) {
  $image = 'land8.gif'; $alt = "공장(${lv}0${HunitPop}규모)";
 } elsif($l == $HlandBase) {
  if($mode == 0) { $image = 'land6.gif'; $alt = '숲'; }
  else { my($level) = expToLevel($l, $lv); $image = 'land9.gif'; $alt = "미사일 기지 (레벨 ${level}/경험치 $lv)"; }
 } elsif($l == $HlandSbase) {
  if($mode == 0) { $image = 'land0.gif'; $alt = '바다'; }
  else { my($level) = expToLevel($l, $lv); $image = 'land12.gif'; $alt = "해저 기지 (레벨 ${level}/경험치 $lv)"; }
 } elsif($l == $HlandDefence) {
  $image = 'land10.gif'; $alt = '방위 시설';
 } elsif($l == $HlandHaribote) {
  $image = 'land10.gif'; $alt = ($mode == 0) ? '방위 시설' : '가짜 시설';
 } elsif($l == $HlandOil) {
  $image = 'land16.gif'; $alt = '해저 유전';
 } elsif($l == $HlandMountain) {
  if($lv > 0) { $image = 'land15.gif'; $alt = "산(채굴장${lv}0${HunitPop}규모)"; }
  else { $image = 'land11.gif'; $alt = '산'; }
 } elsif($l == $HlandMonument) {
  $image = $HmonumentImage[$lv]; $alt = $HmonumentName[$lv];
 } elsif($l == $HlandMonster) {
  my($kind, $name, $hp) = monsterSpec($lv);
  my($special) = $HmonsterSpecial[$kind];
  $image = $HmonsterImage[$kind];
  if((($special == 3) && (($HislandTurn % 2) == 1)) || (($special == 4) && (($HislandTurn % 2) == 0))) {
   $image = $HmonsterImage2[$kind];
  }
  $alt = "괴수$name(체력${hp})";
 }
 $alt = '' if(!defined($alt));
 $image = 'land0.gif' if(!defined($image) || $image eq '');
 $comStr = '' if(!defined($comStr));

 if($mode == 1) {
  out(qq#<A HREF="JavaScript:void(0);" onclick="ps((typeof event!='undefined'?event:window.event),$x,$y); return false;" onMouseOver="set_com($x, $y, '$point $alt'); return true;" onMouseOut="window.status = '';">#);
 } elsif($HmainMode eq 'landmap') {
  out(qq#<A HREF="JavaScript:void(0);" onclick="ps((typeof event!='undefined'?event:window.event),$x,$y); return false;" onMouseOver="window.status = '$point $alt $comStr'; return true;" onMouseOut="window.status = '';">#);
 } else {
  out(qq#<A HREF="JavaScript:void(0);" onMouseOver="window.status = '$point $alt $comStr'; return true;" onMouseOut="window.status = '';">#);
 }
 out("<IMG SRC=\"$image\" ALT=\"$point $alt $comStr\" TITLE=\"$point $alt $comStr\" width=32 height=32 BORDER=0></A>");
}

#---------------------------------------------------------------------
# 대상 섬 지도 팝업
#---------------------------------------------------------------------
sub printIslandJava {
 unlock();
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 if($HcurrentNumber eq '') {
  tempProblem();
  return;
 }
 $HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

 out(<<END);
<SCRIPT Language="JavaScript">
<!--
var mouseX = 0;
var mouseY = 0;
document.onmousedown = getMouseData;
function ps(e, x, y) {
 if(typeof y == "undefined") { y = x; x = e; e = window.event; }
 getMouseData(e);
 if(window.opener && window.opener.document && window.opener.document.myForm) {
  window.opener.document.myForm.POINTX.options[x].selected = true;
  window.opener.document.myForm.POINTY.options[y].selected = true;
 }
 showMenu();
 return true;
}
function showMenu() {
 var el = document.getElementById("menu");
 if(!el) return true;
 var topPos = mouseY - 20;
 if(topPos < 0) { topPos = 0; }
 el.style.position = "absolute";
 el.style.left = mouseX + "px";
 el.style.top = topPos + "px";
 el.style.zIndex = 9999;
 el.style.visibility = "visible";
 el.style.display = "block";
 return true;
}
function menuclose() {
 var el = document.getElementById("menu");
 if(el) el.style.display = "none";
 return true;
}
function getMouseData(e) {
 e = e || window.event;
 if(!e) { return true; }
 if(typeof e.pageX == "number") { mouseX = e.pageX; mouseY = e.pageY; }
 else {
  mouseX = e.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft || 0);
  mouseY = e.clientY + (document.documentElement.scrollTop || document.body.scrollTop || 0);
 }
 return true;
}
function cominput(kind) {
 if(window.opener && window.opener.cominput) {
  window.opener.cominput(6, kind, $HcurrentID);
 }
 menuclose();
}
function ShowMsg(n){ window.status = n; }
//-->
</SCRIPT>
<DIV ID="menu" STYLE="position:absolute; visibility:hidden; display:none; z-index:9999;">
<TABLE BORDER=0 BGCOLOR=#ccffcc>
<TR><TD NOWRAP>
END
 for(my $i = 0; $i < $HcommandTotal; $i++) {
  my($kind) = $HcomList[$i];
  next if(!(($kind >= 30 && $kind <= 35) || $kind == $HcomMoney || $kind == $HcomFood));
  my($cost) = _js_cost_label($kind);
  out("<a href=\"javascript:void(0);\" onClick=\"cominput(${kind}); return false;\" STYLE=\"text-decoration:none\">$HcomName[$kind]($cost)<BR></A>\n");
 }
 out(<<END);
<HR>
<a href="Javascript:void(0);" onClick="menuclose()" STYLE="text-decoration:none">메뉴 닫기</A>
</TD></TR>
</TABLE>
</DIV>
<CENTER>${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}${H_tagBig}</CENTER>
END
 islandMapJava(0);
 tempRecent(0);
}

1;
