#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://t.pos.to/hako
#----------------------------------------------------------------------
# '괴수 대작전' ver1.0.0 by 할아버지 http://t.pos.to/ozzy/
# 사용 조건은 모형정원 제도와 동일합니다. 자세한 내용은 동봉된 readme.txt 파일을 참조해 주세요
#----------------------------------------------------------------------
# 치키치키괴수 대작전!
# 톱 페이지 모듈(ver1.00)
# 사용 조건등은, 원본의 hako-readme.txt 파일에 따름
# Arranged by 차차마루
# 배포페이지: http://www.geocities.co.jp/SiliconValley-Bay/2566/
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 톱 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
 # 개방
 unlock();

 # 템플릿출력
 tempTopPage();
}

# 톱 페이지
sub tempTopPage {
 # 제목
 out(<<END);
${HtagTitle_}$Htitle${H_tagTitle}
END

 # 디버그 모드이면 '턴 진행' 버튼
 if($HEnvDebug == 1) {
 out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
 }

 my($mStr1) = '';
 if($HhideMoneyMode != 0) {
	$mStr1 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
 }

 # 갱신 시간 표시
 my($remainTime, $rtStr);
 if ($HmainMode ne 'turn') {
	$remainTime = $HunitTime - time() + $HislandLastTime;
	$rtStr = "다음 갱신까지,";
	$rtStr.= int($remainTime / 3600). "시간 ";
	$rtStr.= int(($remainTime % 3600) / 60). "분 ";
	$rtStr.= $remainTime % 60 . "초";
 }
 else {
	$rtStr = "턴을 갱신했습니다";
 }

 # 양식
 out(<<END);
<H1>${HtagHeader_}턴$HislandTurn${H_tagHeader}</H1>
<B>$rtStr</B>

<HR>
<!--### ---v--- arrange ---v--- ###-->
END

 my($cgicheck, $javacheck);
 if(($HjavaMode || '') eq 'java') {
	$javacheck = 'CHECKED';
 } else {
	$cgicheck = 'CHECKED';
 }

 out(<<END);
<SCRIPT language="JavaScript">
<!--
function develope(){
 projectWindow = window.open("", "projectWindow", "menubar=no,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=1000,height=720");
 document.Island.target = "projectWindow";
 document.Island.submit();
 document.Island.target = "";
 return true;
}
//-->
</SCRIPT>
<HR>
<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>

비밀번호 입력!!<BR>
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="hidden" NAME="OwnerButton" VALUE="1">
<INPUT TYPE="submit" VALUE="개발하러 간다">
<INPUT TYPE="button" VALUE="새 창" onClick="develope()"><BR>
<INPUT TYPE="radio" NAME="JAVAMODE" VALUE="cgi" $cgicheck>통상 모드
<INPUT TYPE="radio" NAME="JAVAMODE" VALUE="java" $javacheck>JavaScript 모드
<BR>
</FORM>
<!--### ---^--- arrange ---^--- ###-->
<HR>
<A STYLE="text-decoration:none" HREF="${HEnvBaseDir}/hof.cgi">
<H1>${HtagHeader_}
위대한 헌터 달성 기록
${H_tagHeader}</H1>
</A>
<P>
과거에 임무를 달성한 위대한 헌터들의 기록을 볼 수 있습니다.
</P>
<HR>
<H1>${HtagHeader_}섬의 정보${H_tagHeader}</H1>
<P>
섬 이름을 클릭하면,<B>관광</B>할 수 있습니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 섬${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}레벨${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}턴${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}채굴장규모${H_tagTH}</NOBR></TH>
</TR>
END

 my($island, $j, $farm, $factory, $mountain, $name, $id, $prize, $ii, $level);
 for($ii = 0; $ii < $HislandNumber; $ii++) {
	$j = $ii + 1;
	$island = $Hislands[$ii];

	$id = $island->{'id'};
	$farm = $island->{'farm'};
	$factory = $island->{'factory'};
	$mountain = $island->{'mountain'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
	} else {
	 $name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
	}

	$prize = $island->{'prize'};
	my($flags, $monsters, $turns);
	$prize =~ /([0-9]*),([0-9]*),(.*)/;
	$flags = $1;
	$monsters= $2;
	$turns = $3;
	$prize = '';

	# 남은 턴 표시
	while($turns =~ s/([0-9]*),//) {
	 $prize.= "<IMG SRC=\"prize0.gif\" ALT=\"$1${Hprize[0]}\" WIDTH=16 HEIGHT=16> ";
	}

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		$prize.= "<IMG SRC=\"prize${i}.gif\" ALT=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
	 }
	 $f *= 2;
	}

	# 레벨의 표시(괴수 대작전)
	if($island->{'ext'}[2]) {
	 $level = "${HtagRed_}Lv$island->{'ext'}[1]($island->{'ext'}[3])${H_tagRed}";
	} else {
	 $level = "${HtagBlue_}Lv$island->{'ext'}[1]($island->{'ext'}[3])${H_tagBlue}";
	}

### ---v--- arrange ---v---
	# 쓰러뜨린 괴수 목록(모두 나열해 표시)
	$f = 1;
	for($i = 0; $i < $HmonsterNumber; $i++) {
	 if($monsters & $f) {
		$prize.= "<IMG SRC=\"${HmonsterImage[$i]}\" ALT=\"${HmonsterName[$i]}\" WIDTH=16 HEIGHT=16> ";
	 }
	 $f *= 2;
	}
### ---^--- arrange ---^---

	my($mStr1) = '';
	if($HhideMoneyMode == 1) {
	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$HunitMoney</NOBR></TD>";
	} elsif($HhideMoneyMode == 2) {
	 my($mTmp) = aboutMoney($island->{'money'});
	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}

	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>${HtagNumber_}$j${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR>
<A STYLE="text-decoration:none" HREF="${HthisFile}?Sight=${id}">
$name
</A>
</NOBR><BR>
$prize
</TD>
<TD $HbgInfoCell align=left nowrap=nowrap>
<NOBR>$level</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{'ext'}[0]턴</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
$mStr1
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$farm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$factory</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mountain</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=9 align=left nowrap=nowrap><NOBR>${HtagTH_}코멘트:${H_tagTH}$island->{'comment'}</NOBR></TD>
</TR>
END
 }

 out(<<END);
</TABLE>

<HR>
<H1>${HtagHeader_}새 섬을 탐색${H_tagHeader}</H1>
END

 if($HislandNumber < $HmaxIsland) {
	out(<<END);
<FORM action="$HthisFile" method="POST">
섬 이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton">
</FORM>
END
 } else {
	out(<<END);
 섬의 수가 최대 수입니다... 현재 등록할 수 없습니다.
END
 }

 out(<<END);
<HR>
<H1>${HtagHeader_} 정보 변경${H_tagHeader}</H1>
<P>
(주의) 이름 변경에는 $HcostChangeName${HunitMoney}이 들어갑니다.
</P>
<FORM action="$HthisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
새 이름을 입력하세요(변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
</FORM>

<HR>

<H1>${HtagHeader_}최근 사건${H_tagHeader}</H1>
END
 logPrintTop();
 out(<<END);
<H1>${HtagHeader_}발견 기록${H_tagHeader}</H1>
END
 historyPrint();
}

# 톱 페이지용 로그 표시
sub logPrintTop {
 my($i);
 for($i = 0; $i < $HtopLogTurn; $i++) {
	logFilePrint($i, 0, 0);
 }
}

# 기록 파일 표시
sub historyPrint {
 open(HIN, "${HEnvDirName}/hakojima.his");
 my(@line, $l);
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
 }
 @line = reverse(@line);

 foreach $l (@line) {
	$l =~ /^([0-9]*),(.*)$/;
	out("<NOBR>${HtagNumber_}턴${1}${H_tagNumber}:${2}</NOBR><BR>\n");
 }
 close(HIN);
}

1;


