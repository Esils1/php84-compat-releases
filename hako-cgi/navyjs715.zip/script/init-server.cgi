#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 모형정원 바다전쟁 JS ver7.xx
# 서버 설정모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------

# 디버그 모드(1이면 '턴 진행' 버튼을 사용할 수 있음)
$Hdebug = 1;

#----------------------------------------
# 서버
#----------------------------------------
# 이 파일을 설치할 디렉터리
my $HbaseScheme = (($ENV{'HTTPS'} || '') =~ /^(on|1)$/i) ? 'https' : 'http';
my $HbaseHost = $ENV{'HTTP_HOST'} || $ENV{'SERVER_NAME'} || 'localhost';
if (!$ENV{'HTTP_HOST'} && $ENV{'SERVER_PORT'} && !(($HbaseScheme eq 'http' && $ENV{'SERVER_PORT'} == 80) || ($HbaseScheme eq 'https' && $ENV{'SERVER_PORT'} == 443))) {
 $HbaseHost.= ":$ENV{'SERVER_PORT'}";
}
my $HbaseScriptDir = $ENV{'SCRIPT_NAME'} || '';
$HbaseScriptDir =~ s{/[^/]*$}{};
$HbaseDir = "$HbaseScheme://$HbaseHost$HbaseScriptDir";


# 이미지 파일을 둘 디렉터리
#$HimageDir = $HbaseDir;
$HimageDir = 'https://esils.com/BBdata/navyimg';

# 외부 js 파일, 설정 목록(setup.html)을 배치할 디렉터리
$efileDir = "${HbaseDir}";
# $HbaseDir에서 $efileDir로 가는 상대 경로입니다. 로컬 설정을 사용하는 경우 이대로 두면 됩니다.
$HefileDir = '.';


# CSS 을배치할 디렉터리
$HcssDir = "${HbaseDir}";
# 기본값 CSS 파일의 이름
$HcssDefault = 'style.css';

# 비밀번호 파일 이름
# 마스터 비밀번호와 특수 비밀번호는 암호화되어 비밀번호 파일에 저장되어 있습니다.
$HpasswordFile = 'passwd.cgi';

# GMT 에 대한 JST 의 시차(서버 시간이 맞지 않을 때만 조정해 주세요)
$Hjst = 32400; # 9 시간

# 관리자 이름
$HadminName = '관리자의 이름';

# 관리자의 메일 주소
$Hemail = 'admin@example.com';

# 게시판 주소
#$Hbbs = 'http://서버/게시판.cgi';
# 일반 게시판도 YY-BOARD 을이용하는 경우
$Hbbs = "${HbaseDir}/hako-yy-bbs.cgi";

# 홈페이지 주소
$Htoppage = "${HbaseDir}/";

## 이미지 경로 설정의 설명페이지
$imageExp = "${HbaseDir}/e.html";
# 로컬 이미지 압축 파일(다운로드받음)
$localImg = "${HbaseDir}/navyimg.zip";

# 디렉터리 권한
# 일반적으로 0755이면 좋지만,0777,0705,0704등에서 없으면 사용 불가는 서버도 있습니다
$HdirMode = 0755;

# 데이터 디렉터리 이름
# 여기에서 설정한 이름의 디렉터리 아래에 데이터가 저장됩니다.
# 기본값에서는'data'로 되어 있지만, 보안상
# 보안을 위해 다른 이름으로 변경해 주세요.
$HdirName = 'data'; # 메인 데이터, 섬 데이터, 로그 데이터
$HlogdirName = 'log'; # 로컬 게시판 데이터, 역대기록
$HsavedirName = 'save'; # 지형세부 데이터(토너먼트 관련)

# 메인 데이터의 이름
$HmainData = 'hakojima.cgi';

# 섬 데이터의 이름(앞에 '섬 ID'가 지급됩니다)
$HsubData = 'island.cgi';

# 명령 데이터의 이름(앞에 '섬 ID'가 지급됩니다)
$HcommandData = 'command.cgi';

# 로그 데이터의 이름
$HlogData = 'hakolog.cgi';
#!주:ver6.36.8이전의 로그는 읽을 수 없습니다. 이전한 경우, 서버상에예전 데이터가남아버립니다에서  수동으로 삭제해 주세요.

# 섬 데이터의 업로드를 사용.(0:금지)
$HuseUpload = 1; # 금지를 권합니다
# 업로드 스크립트(잠금하지 않음이므로 명칭 변경권장)
$HuploadFile = "${HbaseDir}/hako-upload.cgi";

# 데이터 쓰기 권한

# 잠금 방식
# 1 디렉터리<mkdir>
# 2 시스템 콜(가능하면 이 방식을 권장합니다)<flock>
# 3 심볼릭 링크<symlink>
# 4 일반 파일(권장하지 않음)<unlink>
# 5 이름 변경<rename>
$lockMode = 5;
# (주)
# 4,5을 선택하는 경우에는,'lockfile'라는, 권한 666의 빈 파일을,
# 이 파일과 같은 위치에 배치해 주세요.

# gzip을 사용해 압축 전송할까요? 0: 미사용 1: 사용
$Hgzip = 0;

# gzip 설치 경로
$HpathGzip = '/usr/bin';

$oroti = 0;# BASE HREF 을무효로 극길나광고대책(1에서 유효)

1;
