#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.

# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 관리 도구(ver1.01)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 모형정원 제도 2nd
#								 v1.5
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							 모형정원 모형정원 바다전쟁
#								 v1.3
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――
BEGIN {
	# Perl 5.004 이상이필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}

# 초기 설정용 파일을 읽기
require './hako-init.cgi';
require './hako-io.cgi';

# hako-mente.cgi 을처음 브라우저에서 열면, 마스터 비밀번호와 특수 비밀번호의
# 입력이 필요합니다. 여기에서 입력한 비밀번호는 암호화됨, 비밀번호 파일
# 에기됩니다.

# 비밀번호를 변경하는 경우,FTP 로 접속하고 비밀번호 파일을 삭제해 주세요.
# 그 후 hako-mente.cgi를 브라우저에서 열고 비밀번호의 설정을 수행합니다.
# 이 조작으로 게임 데이터가 손상되지는 않습니다. 게임 중에도 변경할 수 있습니다.

# index 이아니면경고하다?(1:하다,0:사용 안 함)
$alertNoIndex = 0;
$indexName = 'index.html';
# ――――――――――――――――――――――――――――――
# 각종 설정 값
# ――――――――――――――――――――――――――――――
# use Time::Local을 사용할 수 없는 환경에서는 'use Time::Local' 줄을 삭제해 주세요.
# 참고로 이 파일의 맨 마지막에 주석 처리된 Time::Local 호환 함수가 있음
# sub timelocal 을사용라고하세요.

#use Time::Local;
# ――――――――――――――――――――――――――――――
# 설정 항목은 여기까지
# ――――――――――――――――――――――――――――――
my $title = '모형정원 모형정원 바다전쟁 관리 도구';

# 큰 글자
my $HtagBig_ = '<span class="big">';
my $H_tagBig = '</span>';
# ――――――――――――――――――――――――――――――
# 메인
# ――――――――――――――――――――――――――――――

# 각종변수
my($mainMode);
my($mpass1, $mpass2, $spass1, $spass2);
my($deleteID);
my($currentID);
my($ctYear);
my($ctMon);
my($ctDate);
my($ctHour);
my($ctMin);
my($ctSec);

if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	close(PIN);
}

cookieInput();
cgiInput();
cookieOutput();

if($HskinName ne '' ){
	$baseSKIN = $HskinName;
} else {
	$baseSKIN = "${HcssDir}/$HcssDefault";
}

print <<END;
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>$title</TITLE>
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$Body
$Hheader
<HR>
END

if($alertNoIndex) {
	my $flag = 0;
	if(!(-e $indexName)) {
		print "${HbaseDir}에${indexName} 없습니다!";
		$flag = 1;
	}
#	if(!(-e "$HdirName/$indexName")) {
#		print "<BR>\n" if($flag);
#		print "${HbaseDir}/${HdirName}에${indexName} 없습니다!";
#		$flag = 1;
#	}
	print "<HR>\n" if($flag);
}

if($mainMode eq 'delete') {
	deleteMode() if(passCheck());
} elsif($mainMode eq 'current') {
	currentMode() if(passCheck());
} elsif($mainMode eq 'backup') {
	backupMode() if(passCheck());
} elsif($mainMode eq 'time') {
	timeMode() if(passCheck());
} elsif($mainMode eq 'stime') {
	stimeMode() if(passCheck());
} elsif($mainMode eq 'new') {
	newMode() if(passCheck());
} elsif($mainMode eq 'setup' || $mainMode eq 'changepw') {
	setupMode($modeValue) if(!$modeValue || passCheck());
} elsif($mainMode eq 'allylog') {
	allyLogMain() if(passCheck());
} elsif($mainMode eq 'dellog') {
	dellogMode() if(passCheck());
} elsif($mainMode eq 'log2html') {
	log2htmlMain() if(passCheck());
} elsif($mainMode eq 'mente') {
	menteMode() if(passCheck());
} elsif($mainMode eq 'unmente') {
	unmenteMode() if(passCheck());
}
if(($mainMode eq 'admin' || $dellcheck) && (passCheck())) {
	adminMode();
} elsif(($mainMode ne 'allylog') && ($mainMode ne 'dellog') && ($mainMode ne 'log2html')) {
	mainMode();
}

print<<"END";
</FORM></BODY></HTML>
END
exit(0);

sub myrmtree {
	my($dn) = @_;
	opendir(DIN, "$dn/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		unlink("$dn/$fileName");
	}
	closedir(DIN);
	rmdir($dn);
}

sub currentMode {
	myrmtree "${HdirName}";
	mkdir("${HdirName}", $HdirMode);
	opendir(DIN, "${HdirName}.bak$currentID/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		fileCopy("${HdirName}.bak$currentID/$fileName", "${HdirName}/$fileName");
	}
	closedir(DIN);
}

sub backupMode {
	myrmtree "${HdirName}.bak$backupNo";
	mkdir("${HdirName}.bak$backupNo", $HdirMode);
	opendir(DIN, "${HdirName}/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		fileCopy("${HdirName}/$fileName", "${HdirName}.bak$backupNo/$fileName");
	}
	closedir(DIN);
}

sub deleteMode {
	if($deleteID eq '') {
		myrmtree "${HdirName}";
	} else {
		myrmtree "${HdirName}.bak$deleteID";
	}
	unlink "hakojimalockflock";
}

sub newMode {
	mkdir($HdirName, $HdirMode);
	mkdir($HlogdirName, $HdirMode);
	mkdir($HbbsdirName, $HdirMode);

	# 현재 시간을 가져옴
	my($now) = time();
	$now -= $now % $HunitTime if($HunitTime);

	open(OUT, ">$HdirName/$HmainData"); # 파일을 열기
	print OUT "0,1\n"; # 턴 수 0, 게임플래그 1
	print OUT "$now\n"; # 시작 시간
	print OUT "0\n"; # 섬의 수
	print OUT "1\n"; # 다음에 할당할 ID
	print OUT "\n"; # 관리자 위임 임시의 섬 ID
	# 토너먼트용
	print OUT "0\n"; # 현재의 전투 모드
	print OUT "$HyosenTurn\n";# 전환에 턴
	print OUT "0\n"; # 몇 번째 경기인지
	print OUT "0\n"; # 턴 갱신 횟수

	print OUT "\n"; # 예비
	print OUT "\n"; # 예비
	print OUT "\n"; # 예비
	print OUT "\n"; # 예비
	print OUT "\n"; # 예비
	print OUT "\n"; # 예비

	# 파일을 닫기
	close(OUT);

	open(AOUT, ">${HdirName}/${HallyData}"); # 파일을 열기
	print AOUT "0\n"; # 동맹 수 0
	close(AOUT);

	if($HoceanMode) {
		open(MOUT, ">${HdirName}/world.${HsubData}"); # 파일을 열기
		for($y = 0; $y < $HoceanSizeY*$HislandSizeY; $y++) {
			for($x = 0; $x < $HoceanSizeX*$HislandSizeX; $x++) {
				printf MOUT ("%02x%08x", 0, 0);
			}
			print MOUT "\n";
		}
		close(MOUT);
	}

}

sub setupMode {
	if (!($mpass1 && $mpass2) || ($mpass1 ne $mpass2)) {
		print "${HtagBig_}마스터 비밀번호가 입력되어 있지 않거나 오류가 있습니다${H_tagBig}";
		return;
	}
	if (!($spass1 && $spass2) || ($spass1 ne $spass2)) {
		print "${HtagBig_}특수 비밀번호가 입력되어 있지 않거나 오류가 있습니다${H_tagBig}";
		return;
	}

	if (-e $HpasswordFile) {
		if(!$modeValue) {
			# 보안 홀의 확인
			print "${HtagBig_}이미 비밀번호가 설정되어 있습니다${H_tagBig}";
			return;
		} else {
			unlink("$HpasswordFile");
		}
	}

	$HinputPassword = $mpass1;
	$mpass1 = crypt($mpass1, 'ma');
	$spass1 = crypt($spass1, 'sp');

	open(OUT, ">$HpasswordFile") || die $!;
	print OUT <<END;
$mpass1
$spass1
END
	close(OUT);
	$modeValue = (!$modeValue) ? '설정' : '변경';
	print "${HtagBig_} 비밀번호를${modeValue}했습니다${H_tagBig}";
}

sub timeMode {
	$ctMon--;
	$ctYear -= 1900;
	$ctSec = timelocal($ctSec, $ctMin, $ctHour, $ctDate, $ctMon, $ctYear);
	stimeMode();
}

sub stimeMode {
	my($t) = $ctSec;
	open(IN, "${HdirName}/$HmainData");
	my(@lines);
	@lines = <IN>;
	close(IN);

	$lines[1] = "$t\n";

	open(OUT, ">${HdirName}/$HmainData");
	print OUT @lines;
	close(OUT);
}

sub mainMode {
	print <<END;
<STYLE type="text/css">
<!--
A { text-decoration:none; }
A:HOVER { text-decoration:underline; }
H1, H3, H5 { display:inline; }
H5 { color: green; }
-->
</STYLE>
<FORM action="$HmenteFile" method="POST">
<H1>$title</H1> [<a href="$HthisFile">$HtitleTag</a>]
<HR>
END

	unless (-e $HpasswordFile) {
		# 비밀번호 파일이 없음
		print <<END;
<H2>마스터 비밀번호와 특수 비밀번호를 설정해 주세요.</H2>
<P>참고: 입력 실수를 방지하기 위해, 각각2회씩입력해 주세요.</P>
<B>마스터 비밀번호:</B><BR>
(1) <INPUT type="password" name="MPASS1" value="$mpass1">&nbsp;&nbsp;(2) <INPUT type="password" name="MPASS2" value="$mpass2"><BR>
<BR>
<B>특수 비밀번호:</B><BR>
(1) <INPUT type="password" name="SPASS1" value="$spass1">&nbsp;&nbsp;(2) <INPUT type="password" name="SPASS2" value="$spass2"><BR>
<BR>
<INPUT type="submit" value="비밀번호 설정" name="SETUP">
END
		return;
	}
	$HinputPassword = $HdefaultPassword if($HinputPassword eq '');
	print <<END;
<B>마스터 비밀번호:</B><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HinputPassword">
<INPUT type="submit" value="관리자실로 이동" name="ADMIN">
END

	opendir(DIN, "./");

	# 현재 데이터
	if(-d "${HdirName}") {
		if(-e "./mente_lock") {
			print qq#<INPUT TYPE="submit" VALUE="점검 모드 해제" NAME="UNMENTE">\n#;
		} else {
			print qq#<INPUT TYPE="submit" VALUE="점검 모드" NAME="MENTE">\n#;
		}
		dataPrint("");
	} else {
		print <<END;
	<HR>
	<INPUT TYPE="submit" VALUE="새 데이터 만들기" NAME="NEW">
END
	}

	# 백업 데이터
	my($dn);
#	while($dn = readdir(DIN)) {
#		if($dn =~ /^${HdirName}.bak(.*)/) {
#			dataPrint($1);
#		}
#	}
	my(@suf);
	while($dn = readdir(DIN)) {
		if($dn =~ /^${HdirName}.bak(.*)/) {
			push(@suf, $1);
		}
	}
	foreach (sort { $a <=> $b } @suf) {
		dataPrint($_);
	}
	closedir(DIN);
}

# 관리자실
sub adminMode {
	print <<END;
<STYLE type="text/css">
<!--
A { text-decoration:none; }
A:HOVER { text-decoration:underline; }
H1, H3, H5 { display:inline; }
H5 { color: green; }
#changpw, #setupvalue, #news, #lbbslist, #exbbs, #axeslog, #centercamp, #bbsally, #bbsdead, #bbsdel, #event,
#log2html, #allymake, #allysetup, #dewarsetup, #predelete, #counter, #datachange, #mapchange, #mapsave, #viewlose, #movefleet,
#delisland, #present, #punish, #bfmake, #bfin { display:none; }
-->
</STYLE>
<script type="text/javascript">
<!--
function display(id) {
 if(document.getElementById){
 var obj = document.getElementById(id);
 if (obj.style.display == 'block'){
 obj.style.display='none';
 } else {
 obj.style.display='block';
 }
 }
}
-->
</script>
<FORM action="$HmenteFile" method="POST">
[<A href="$HmenteFile">돌아가기</A>]
<INPUT type=hidden name=PASSWORD value="${HinputPassword}">
<INPUT type=hidden name=ADMIN value=1>
 <H1>모형정원 모형정원 바다전쟁 관리자실</H1>
 [<a href="$HthisFile">$HtitleTag</a>]
END
	print <<END;
<HR>
END
	if($Hbbs eq "${HbaseDir}/hako-yy-bbs.cgi") {
		print "[<A HREF=\"$Hbbs\" target=\"_blank\">게시판</A>(<A HREF=\"$Hbbs?id=0&cpass=${HinputPassword}\" target=\"_blank\">관리 모드</A>)] ";
	} else {
		print "[<A HREF=\"$Hbbs\" target=\"_blank\">게시판</A>] ";
	}
	print <<END;
[<A href="$HthisFile?Amity=0" target="_blank">우호국 목록</A>]
[<A href="$HthisFile?Fleet=1" target="_blank">함정 보유 목록</A>]
[<A href="$HthisFile?Item=0" target="_blank">아이템 획득 현황</A>]
[<A href="$HthisFile?Rekidai=0" target="_blank">역대기록</A>]
[<A href="$HthisFile?Rank=0" target="_blank">순위</A>]
END
	if((-e "${HefileDir}/setup.html") && $sfFlag) {
		print "[<A href=\"${efileDir}/setup.html\"> 설정 목록</A>] ";
	} else {
		print "[<A href=\"$HthisFile?SetupV=0\"> 설정 목록</A>] ";
	}
	print "[<A href=\"$HthisFile?FightLog=0\" class=\"M\" TARGET=_blank>대전 기록</A>] " if($Htournament);
	if(!$HhtmlLogMode || !(-e "${HhtmlDir}/hakolog.html") || $Hgzip) {
		print "[<A href=\"${HbaseDir}/history.cgi?Event=0\" target=\"_blank\">최근 사건</A>] ";
	} else {
		print "[<A href=\"${htmlDir}/hakolog.html\" target=\"_blank\">최근 사건</A>] ";
	}
	print <<END;
<HR>
<H3><span class='disaster'>참고: 아래 작업은 턴 갱신 중에 실행하면 매우 위험합니다!</span></H3>
END
	if(-e "./mente_lock") {
		print qq# <INPUT TYPE="submit" VALUE="점검 모드 해제" NAME="UNMENTE">\n#;
	} else {
		print qq# <INPUT TYPE="submit" VALUE="점검 모드" NAME="MENTE">\n#;
	}
	my $exMark = '▼';
	print "<blockquote><h5>$exMark</h5>을 클릭하면 간단한 설명이 표시됩니다.";
	print <<END;
</FORM>
<FORM name="CHANGEPW" action="${HmenteFile}" method=POST>
<a href="javascript: display('changpw');"><h5>$exMark</h5></a>
<H3><a href="javascript: display('changpw');">마스터 비밀번호와 특수 비밀번호의 변경</a></H3>
<DIV id='changpw'>
<INPUT type=hidden name=PASSWORD value="${HinputPassword}">
<P>참고: 새 비밀번호는, 입력 실수를 방지하기 위해, 각각2회씩입력해 주세요.</P>
<B>새 마스터 비밀번호:</B><BR>
(1) <INPUT type="password" name="MPASS1" value="$mpass1">&nbsp;&nbsp;(2) <INPUT type="password" name="MPASS2" value="$mpass2"><BR>
<BR>
<B>새 특수 비밀번호:</B><BR>
(1) <INPUT type="password" name="SPASS1" value="$spass1">&nbsp;&nbsp;(2) <INPUT type="password" name="SPASS2" value="$spass2"><BR>
<BR>
 <INPUT type="submit" value="비밀번호 설정" name="CHANGEPW">
</FORM>
</DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('setupvalue');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?SetupV=${HinputPassword}" target="_blank"> 설정 목록(관리자용)표시</A>(<A HREF="${HthisFile}?SetupV=0" target="_blank"> 설정 목록을 치환 가능</A>)</H3>
<DIV id='setupvalue'>
<UL>
<LI>관리자용와 메인 페이지의 링크와의차이는, 플레이어에공개사용하지 않도록 설정도열람할 수 있는 것구라이입니다.
<LI> 설정을 변경한 경우 HTML도 다시 생성해 두는 것이 좋습니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('news');"><h5>$exMark</h5></a>
<H3><A HREF="hako-news.cgi?pass=${HinputPassword}" target="_blank">뉴스를 치환 가능</A></H3>
<DIV id='news'>
<UL>
<LI>메인 페이지의 오알림알림을 치환 가능기능입니다.<br>
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('lbbslist');"><h5>$exMark</h5></a>
<H3><A HREF="${HlbbsFile}" target="_blank">관광객 통신 목록</A></H3>
<DIV id='lbbslist'>
<UL>
<LI>lbbslist.cgi 을설치하고 있는 경우, 전체 참가자의 관광객 통신을 확인할 수 있습니다.<br>
<LI>이 스크립트는, 서버에 부하가 걸릴 수 있으므로, 잦은 접속이나 새로고침은 삼가 주세요.
<LI>관리자 모드에서 들어가면, 극비 통신을 볼 수 있습니다. 관리자 권한이 있더라도 불필요하게 열람하지 마세요.<br>주:COOKIE에 마스터 비밀번호가 저장되어 있으면'관리자 모드'가 됩니다.
</UL></DIV><BR><BR>
END

	print <<END if($HuseExlbbs);
<a href="javascript: display('exbbs');"><h5>$exMark</h5></a>
<H3><A HREF="${HlbbsDir}/view.cgi" target="_blank">외부 간이 게시판을 열람하다</A>(<A HREF="${HlbbsDir}/view.cgi?admin=${HviewPass}" target="_blank">관리자 모드</A>)</H3>
<DIV id='exbbs'>
<UL>
<LI>초기 설정(hako-init.cgi)에서 '외부 간이 게시판 사용'을 허용하지 않으면 표시할 수 없습니다.
<LI>view.cgi 의 설정에서 소유자 확인을ON으로 하고 있는 경우,'열람'에서는 게시할 수 없게 됩니다. 또한,'index 갱신'의버튼을 누르지 않으면, 목록은 최신 데이터가 되지 않습니다.
<LI>관리자 모드에서 접속하면, 각 게시판의 관리자 기능을 사용할 수 있게 됩니다.(관리자 쿠키가 남아 있으므로, 조작 후 게시에는 충분히 주의하세요)
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('axeslog');"><h5>$exMark</h5></a>
<H3><A HREF="JavaScript:void(0)" onClick="document.AXESLOG.target='newWindow';document.AXESLOG.submit();return false;">접속 로그 보기</a></H3>
<DIV id='axeslog'>
<FORM name="AXESLOG" action="${HaxesFile}" method=POST>
<INPUT type=hidden name=password value="${HinputPassword}">
<INPUT type=hidden name=mode value="analyze">
<INPUT type=hidden name=category value="a">
</FORM>
<UL>
<LI>메인 스크립트(hako-main.cgi)의 설정에서'접속 로그를 와 루'수 있도록 하지 않으면, 볼 수 없습니다.
<LI>로그를 남기는 작업의 부하는 무시할 수 없으므로, 모형정원 본체 동작에도 영향을 줄 수 있음을 고려해 주세요.
</UL></DIV><BR><BR>
END

	my $viewCommand = $HrepeatTurn * $HcampCommandTurnNumber;
	print <<END;
<FORM name="MAINCAMP" action="${HthisFile}" method="POST" target="_blank">
<a href="javascript: display('centercamp');"><h5>$exMark</h5></a>
<H3>
<A HREF="JavaScript:void(0)" onClick="document.MAINCAMP.target='newWindow';document.MAINCAMP.submit();return false;">바다전쟁운영본부로</a></H3>
<INPUT type=hidden name=camp value="0">
<INPUT type=hidden name=cpass value="${HinputPassword}">
<INPUT type=hidden name=id value="0">
<DIV id='centercamp'>
</FORM>
<UL>
<LI>전체 섬의 명령(각 섬$viewCommand 회분)와 함대의 상황을 열람할 수 있습니다.
<LI>이기능은, 서버에 부하가 걸릴 수 있으므로, 잦은 접속이나 새로고침은 삼가 주세요.
</UL></DIV><BR><BR>
END

	my $allyList = '';
	my $deadallyList = '';
	if($HallyUse || $HarmisticeTurn) {
		if($HallyBbs) {
			readAllyFile();
			if($HallyNumber) {
				foreach (0..$#Hally) {
					my $s = '';
					$s = ' SELECTED' if(!$_);
					$allyList.= "<OPTION VALUE=\"$Hally[$_]->{'id'}\"$s>$Hally[$_]->{'name'}\n"
				}
				print <<END;
<FORM name="ALLYBBS" action="${HbaseDir}/$HallyBbsScript" method=POST>
<a href="javascript: display('bbsally');"><h5>$exMark</h5></a>
<H3><select name=ally>${allyList}</select>
<A HREF="JavaScript:void(0)" onClick="document.ALLYBBS.target='newWindow';document.ALLYBBS.submit();return false;">동맹 게시판에</a></H3>
<INPUT type=hidden name=id value="0">
<INPUT type=hidden name=cpass value="${HinputPassword}">
<DIV id='bbsally'>
</FORM>
<UL>
<LI>'동맹 게시판'을열람할 수 있습니다.
<LI>게시하면, 이름이'바다전쟁운영본부'가 됩니다.
</UL></DIV>

<FORM name="DEADBBS" action="${HmenteFile}" method=POST>
<a href="javascript: display('bbsdead');"><h5>$exMark</h5></a>
<H3><select name=ALLYID>${allyList}</select>
<A HREF="JavaScript:void(0)" onClick="document.DEADBBS.submit();return false;">동맹 게시판 로그를 소멸 로그로 이전</a></H3>
<INPUT type=hidden name=PASSWORD value="${HinputPassword}">
<INPUT type=hidden name=ALLYLOG>
<DIV id='bbsdead'>
</FORM>
<UL>
<LI>동맹의 삭제는 상의'진영(동맹)의 작성·설정 변경'로 가능합니다.<BR>
'진영(동맹)의 작성·설정 변경'이 경우,'발견 기록'에해산 로그가 표시되어, 동맹 게시판의 로그는 그대로 저장됩니다.<BR>
이 작업은 동맹 자체는 유지하고, 동맹 게시판 로그만 삭제 로그로 이동합니다.
<LI>소멸 로그는 hako-yy-bbs.cgi의 상단에 연결됩니다.<BR>
</UL></DIV><BR><BR>
END
			}
			if(-f "${HbbsdirName}/dead${HallyData}") {
				open(DIN, "${HbbsdirName}/dead${HallyData}") || die $!;
				my @dead = <DIN>;
				close(DIN);
				foreach (@dead) {
					my($dally, $daName, $diName) = split(/\,/, $_);
					my($did, $dturn) = split(/-/, $dally);
					$daName =~ s/<[^<]*>//g;
					$deadallyList.= "<OPTION VALUE=\"$dally\">$daName($HallyTopName:$diName 턴$dturn 에소멸)\n"
				}
				print <<END if(@dead> 0);
<FORM name="DELBBS" action="${HmenteFile}" method=POST>
<a href="javascript: display('bbsdel');"><h5>$exMark</h5></a>
<H3><select name=DEADALLY>${deadallyList}</select>
<A HREF="JavaScript:void(0)" onClick="document.DELBBS.submit();return false;">소멸 로그의 삭제</a></H3>
<INPUT type=hidden name=PASSWORD value="${HinputPassword}">
<INPUT type=hidden value='소멸 로그의 삭제' name="DELLOG">
<DIV id='bbsdel'>
</FORM>
<UL>
<LI>동맹 게시판의 소멸 로그를 삭제합니다.
</UL></DIV><BR><BR>
END
			}
		}
		if($Hbbs == "${HbaseDir}/hako-yy-bbs.cgi" || $allyList ne '' || $deadallyList ne '') {
				print <<END;
<FORM name="HTMLLOG" action="${HmenteFile}" method=POST>
<a href="javascript: display('log2html');"><h5>$exMark</h5></a>
<H3><a href="javascript: display('log2html');">게시판 로그의 HTML화</a></H3>
<DIV id='log2html'>
<BR><select name=ALLYID><OPTION VALUE="0">바다전쟁 게시판
${allyList}${deadallyList}</select>
 파일 이름<INPUT type=text name=HTMLNAME value="bbslog" size=8>
원글(1페이지주변)<INPUT type=text name=MAXLINE value="100" size=3>
amity 태그의 출력<INPUT type=checkbox name=AMITY value="1" checked>
<INPUT type=hidden name=PASSWORD value="${HinputPassword}">
<BR><BR><INPUT type=submit value='게시판 로그의 HTML화' name="HTMLLOG">
<UL>
<LI>'동맹 게시판'의 로그를, 과거 로그도포함해서 HTML로 출력합니다.
<LI>HTML 파일은,'최근 사건'을 HTML화하다 설정(hako-init.cgi)와 같은 디렉터리에 생성됩니다.
<UL>
<LI>'파일 이름' 부분을 'bbslog'로 하면 bbslog0000.html 부터 필요한 만큼 파일을 분할한 상태로 작동합니다.
<LI>'원글(1페이지분)'은 $HallyBbsScript에서 설정한 '최대 글 수'를 넘을 수 없습니다.
<LI>'amity 태그 출력'을 선택 해제하면 출력하지 않습니다.
</UL></UL></FORM>
</DIV>
<BR><BR>
END
		}

		print <<END;
<a href="javascript: display('allymake');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?JoinA=${HinputPassword}">진영(동맹)의 작성·설정 변경</A></H3>
<DIV id='allymake'>
<UL>
<LI>'진영전쟁 모드'를유효로 하고 있는 경우, 여기에서 진영(동맹)을 신규 작성해 주세요.
<LI>진영(동맹)와 섬을 선택하고 변경 버튼을 누르면, 진영(동맹)의 맹주를 임명할 수 있습니다.
</UL></DIV><BR><BR>
END
	}

	print <<END if($HuseAmity || $HallyUse || $HarmisticeTurn);
<a href="javascript: display('allysetup');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?ASetup=${HinputPassword}">우호국·동맹(진영)의 소속 변경</A></H3>
<DIV id='allysetup'>
<UL>
<LI>우호국 설정이나 동맹 소속의 변경을 수행합니다.
</UL></DIV><BR><BR>
END

	print <<END if($HuseDeWar);
<a href="javascript: display('dewarsetup');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?WSetup=${HinputPassword}">선전포고점검</A></H3>
<DIV id='dewarsetup'>
<UL>
<LI>선전포고의 점검을 수행합니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('event');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?Esetup=${HinputPassword}">이벤트 설정</A></H3>
<DIV id='event'>
<UL>
<LI>이벤트를 설정합니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('predelete');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?Pdelete=${HinputPassword}">참가 ${AfterName}을 관리자 보관 처리</A></H3>
<DIV id='predelete'>
<UL>
<LI>보관 처리된 ${AfterName}은 턴 처리(수입 처리·명령 처리·성장·재해·실업자 이민) 대상에서 제외됩니다.
<LI>다른${AfterName}에서 공격도받을 수 없습니다.
<LI> 명령 목록 첫 줄에 '섬 포기'를 입력했을 때만, 처리되도록 되어 있습니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('counter');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?ICounter=${HinputPassword}">참가 ${AfterName}의 확장 데이터 카운터 설정</A></H3>
<DIV id='counter'>
<UL>
<LI>지도 화면 아래의'턴○○~현재'의 데이터 영역(카운터)의 추가·초기화·삭제를 수행합니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('datachange');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?ISetup=${HinputPassword}">참가 ${AfterName}의 ${AfterName} 데이터를 수정하기</A></H3>
<DIV id='datachange'>
<UL>
<LI>악의적 행위, 서버 문제, 스크립트 버그 등으로 ${AfterName} 데이터가 비정상 상태가 된 ${AfterName}을 복구합니다.
<LI>아래의'지형 데이터'에서는 없이, 메인 데이터와 관련된 수정을 수행합니다.
<LI>메인 데이터를 직접 수정하는 것보다 안정적일 수 있지만, 지식이 없으면 사용하기 어렵습니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('mapchange');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?Lchange=${HinputPassword}">참가 ${AfterName}의 지형 데이터를 변경</A></H3>
<DIV id='mapchange'>
<UL>
<LI>악의적 행위, 서버 문제, 스크립트 버그 등으로 지형 데이터가 비정상 상태가 된 ${AfterName}을 복구합니다.
<LI>좌표를 하나씩 처리하므로 부분적인 복구 조치만 가능합니다. 전체적인 변경은 데이터를 직접 수정하는 편이 빠릅니다.
<LI>또한, 인구, 농장 규모 등의 수치 데이터 반영은 턴 갱신 처리가 실행된 뒤 적용되므로, 주의해 주세요.
<LI>'지형'과 '지형 값'에 대한 지식이 없으면 사용하기 어렵습니다. 예를 들어 '바다' 값을 1로 지정하면 '얕은 바다'가 되며, 도시 인구의 표시 숫자와 실제 데이터 숫자 차이(10000명이 100으로 기록되는 경우 등), 농장이나 공장의 발전 규모별 사용 가능한 숫자 값 등을 이해해야 합니다(hako-make.cgi의 sub landCheck에서 간단히 확인할 수 있습니다).
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('mapsave');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?ISave=${HinputPassword}">참가 ${AfterName}의 지형 데이터를 저장·복원한</A></H3>
<DIV id='mapsave'>
<UL>
<LI>토너먼트 모드의 부전승 처리의 재사용입니다.
<LI> 섬 전체의 지형 데이터와자금·식량을 저장·복원할 수 있습니다.
<LI>토너먼트 모드에서는 전투 기간에 들어갈 시, 세부 데이터가 덮어써집니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('viewlose');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?ViewLose=${HinputPassword}">저장 데이터 목록(복원·삭제)</A></H3>
<DIV id='viewlose'>
<UL>
<LI>'패자의${AfterName} 목록'에서는 토너먼트 모드의 패자가 된 ${AfterName}의 침몰 시 저장된 데이터를 볼 수 있습니다.
<LI>'패자의${AfterName}'은, 토너먼트 외에도 소멸 처리 시 데이터를 저장할 수 있도록 설정할 수 있습니다(init-game.cgi 의\$HdeadToSaveAsLose).
<LI>'저장 데이터 목록'에서는'참가 ${AfterName}의 지형 데이터를 저장·복원한'에 저장된 데이터를 볼 수 있습니다.
<LI> 데이터는 지형만데없이 섬의 기본 데이터모두가저장되 있습니다.
<LI> 섬을 선택하고 '복원'하면, 생존 중인 섬은 데이터가 교체되고, 사멸한 섬은 전쟁 전 상태로 복구됩니다.
<LI>현재 존재하는 섬의 판정은 ID, 섬 이름, 소유자 이름, 비밀번호 4개 데이터가 모두 일치하는지 여부입니다. 하나라도 다르면 신규 ID를 할당해 복구합니다.
</UL>
</DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('movefleet');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?Mfleet=${HinputPassword}">함대를 강제로 이동하게 함</A></H3>
<DIV id='movefleet'>
<UL>
<LI>특정 섬에 있는 함대를 다른 섬으로 이동합니다.
<LI>좌표지정은 할 수 없습니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('delisland');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?Rename=0" target="_blank">참가 ${AfterName}을 강제 삭제</A></H3>
<DIV id='delisland'>
<UL>
<LI>'정보 변경'화면에서  해당의${AfterName} 이름을'무인'${AfterName}또는'침몰'${AfterName}로 설정해 주세요.
<LI>그 시, 비밀번호 입력란에는'특수 비밀번호'를입력해나 합니다.
<LI>'무인'${AfterName}에하면'발견 기록'에,'바다신의 <B>분노를 받아</B> 육지가 모두 <span class='disaster'>침몰했습니다.</span>'라는 로그가 남습니다.
<LI>'침몰'${AfterName}이 경우 로그를 출하지 않습니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('present');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?Present=">참가 ${AfterName}에게 선물 지급</A></H3>
<DIV id='present'>
<UL>
<LI>'발견 기록'에 로그가 남는 이벤트로 지원을 지급할 수 있습니다.
<LI>표시된 양식에 필요한 값이나 메시지를 입력하고, 비밀번호에 '특수 비밀번호'를 입력한 뒤 '선물 지급' 버튼을 누르면 선물이 지급됩니다.
<LI>로그에는 HTML 태그도 사용할 수 있지만, 잘못 입력한 로그는 삭제할 수 없으므로 신중하게 입력해 주세요. 미리 브라우저에서 표시 테스트를 해 보는 것이 좋습니다. 발견 기록에 이상한 로그가 남으면 곤란합니다.
<LI>선물 지급 결과자금이나 식량 보유량이 제한값을 초과할 수 있습니다. 다음 턴 갱신에서 제한값으로 조정되지만, 그 턴에는 초과분까지 사용할 수 있습니다.
예를 들어 보유량이 20000인 상태에서 그대로 턴 갱신하면 9999로 상한 처리됩니다. 그러나 그 턴에 굴착을 99회 실행하면 비용 19800이 차감되어 200만 남습니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('punish');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?Punish=${HinputPassword}">참가 ${AfterName}에게 제재 적용</A></H3>
<DIV id='punish'>
<UL>
<LI>제재는 지정한 자연재해를 반드시 발생시킵니다. 예를 들어 'A${AfterName}에 지반 침하'라는 지시를 내리면 다음 턴에 지반 침하가 발생합니다.
<LI>거대 운석과 분화는 좌표 지정이 가능하며, 지정한 좌표에 반드시 발생합니다. 무인 플레이어를 배제하거나 견제하는 데 효과적으로 사용할 수 있습니다.
<LI>이 개조는 '악성이라고 단정하긴 어렵지만 모형정원의 분위기를 해치는 행위를 하는 플레이어'나 '관리자가 정한 로컬 규칙을 위반했고 개선 가능성이 없는 플레이어' 등, 운영상 바람직하지 않다고 판단된 플레이어에게 자연재해를 임의로 발생시키기 위한 기능입니다.
<LI>관리자가 바람직하지 않다고 판단한 플레이어와는 게시판 등에서 먼저 대화하는 것이 좋지만, 경우에 따라서는 대화만으로 해결되지 않을 수 있습니다. 이런 경우 참가 ${AfterName} 사이에서 '저 ${AfterName}을 파괴하자'는 식의 분위기가 생길 수 있으나, 뒷맛이 좋지 않습니다.
<LI>관리자에 따라서는 '저 ${AfterName}은 악성 플레이어이므로 공격해 주세요'처럼 전체 ${AfterName} 공격을 허용하는 경우도 있지만, 그 정도까지 자동 대응하기는 어렵습니다. 강제로 ${AfterName}을 포기 처리하는 기능은 아직 안정적이지 않지만, 포기 처리된 ${AfterName}의 플레이어가 남아 있으면 분쟁이 생길 수 있습니다.
<LI>이런 경우 '좋은 위치에 거대 운석', '불리한 지반 침하' 같은 제재를 사용하면 큰 논란 없이 문제 ${AfterName}을 약화시킬 수 있습니다. 다만 남용하면 모형정원의 분위기가 나빠질 수 있으므로 주의가 필요합니다.
</UL></DIV><BR><BR>
END

	print <<END;
<a href="javascript: display('bfmake');"><h5>$exMark</h5></a>
<H3><A HREF="${HthisFile}?Bfield=${HinputPassword}">Battle Field 작성</A></H3>
<DIV id='bfmake'>
<UL>
<LI>인구가 0이 되어도 침몰하지 않는 ${AfterName}을 만듭니다. 이른바 '연습용 ${AfterName}'이지만, 경험치나 난민 발생용으로 사용할 수 있습니다(평화 지향).
<LI>미리 '새 ${AfterName}을 탐색'으로 ${AfterName}을 만들어 두어야 합니다. 등록 수가 최대치를 넘은 상태에서 변경·추가해야 하므로 번거롭지만, 현재는 이런 사양입니다.
<LI>악성 ${AfterName}이나 중복 등록 ${AfterName}을 Battle Field로 변경할 수도 있습니다.
<LI>또한 Battle Field로 지정된 ${AfterName}을 원래대로 복구할 수도 있지만, ${AfterName} 등록 수가 최대이면 실행할 수 없습니다.
<LI><B>Battle Field 사양</B>
<UL>
<LI>농장이 없어도 식량 부족은 발생하지 않습니다.
<LI>황무지는 매우 높은 확률로 평지가 되며, 평지는 숲이나 도시에 인접하지 않아도 마을이 발생합니다.
<LI>괴수 출현 확률은 일반 섬의 2배이며, 인구와 관계없이 항상 레벨 2로 판정됩니다.
<LI>괴수를 쓰러뜨렸을 시의 포상금은 쓰러뜨린 섬의 것이 됩니다.
</UL>
</UL></DIV><BR><BR>
END

	print <<END;
<FORM name="BFDEVELOP" action="${HthisFile}" method=POST>
<a href="javascript: display('bfin');"><h5>$exMark</h5></a>
<H3><a href="JavaScript:void(0)" onClick="document.BFDEVELOP.target='newWindow';document.BFDEVELOP.submit();return false;">Battle Field 개발 화면으로 이동</a></H3>
<INPUT type=hidden name=PASSWORD value="${HinputPassword}">
<INPUT type=hidden name=dummy value="dummy">
<DIV id='bfin'>
</FORM>
<UL>
<LI>메인 페이지의 섬 목록에서 Battle Field를 선택할 수 있게 됩니다.
<LI>Battle Field를 작성하지 않으면 일반 메인 페이지가 표시됩니다.
</UL></DIV><BR><BR>
END

	print "</blockquote>";
}

# 동맹 게시판 로그를 소멸 로그로 이전
sub allyLogMain {
	# 섬 데이터 읽기
	if(!readIslandsFile()) {
		print "데이터 읽기오류발생!<HR>";
		return;
	}
	my $an = $HidToAllyNumber{$HallyID};
	if(defined $an) {
		my $n = $HidToNumber{$HallyID};
		my $name = $Hislands[$n]->{'name'}. $AfterName;
		$name = "${HallyTopName}부재" if !(defined $n);
		if($dellcheck) {
			if(make_pastlog($HallyID, $name)) {
				print "이전성공! <a href='${HbaseDir}/hako-yy-bbs.cgi'>게시판에</a><HR>";
			} else {
				print "게시판 로그를 찾을 수 없음. 또는, 이전실패!<HR>";
			}
		} else {
			my $allyName = $Hally[$an]->{'name'};
			print <<END;
<H2>$allyName 의 동맹 게시판 로그를 소멸 로그로 옮길까요?</H2>
<H2><FORM name="DEADBBS" action="${HmenteFile}" method=POST>
<INPUT type=hidden name=DELLOK value="1">
<INPUT type=hidden name=PASSWORD value="${HinputPassword}">
<INPUT type=hidden name=ALLYID value="${HallyID}">
<INPUT type=hidden name=ALLYLOG>
<a href="JavaScript:void(0)" onClick="document.DEADBBS.submit();return false;">예</a> <a href="${HmenteFile}?ADMIN=${HinputPassword}">아니오</a></H2>
END
		}
		return;
	} else {
		print "동맹이 존재하지 않습니다!<HR>";
		$dellcheck = 1;
	}
	return;
}

# 동맹 게시판 로그의 HTML화
sub log2htmlMain {
	# 섬 데이터 읽기
	if(!readIslandsFile()) {
		print "데이터 읽기오류발생!<HR>";
		return;
	}
	my $an = $HidToAllyNumber{$HallyID};
	my $allyName = $Hally[$an]->{'name'};
	if(!(defined $an)) {
		if($HallyID eq '0') {
			$allyName = '바다전쟁 게시판';
			$HallyID = '';
		} else {
			open(DIN, "${HbbsdirName}/dead${HallyData}") || die $!;
			my @dead = <DIN>;
			close(DIN);
			foreach (@dead) {
				my($dally, $daName, $diName) = split(/\,/, $_);
				next if($dally ne $HallyID);
				my($did, $dturn) = split(/-/, $dally);
				$allyName = "$daName($HallyTopName:$diName 턴$dturn 에소멸)";
				last;
			}
		}
	}
	my $amitycheck = ('하지 않음', '하다')[$Hamity];
	print <<END;
<H3>'$allyName'의 동맹 게시판 로그를 HTML화할까요?</H3>
파일 이름:${HhtmlName}0000.html~
<BR>원글의 수(1페이지주변):$HmaxLine
<BR>amity 태그의 출력:$amitycheck
<FORM name="HTMLLOG" action="${HbaseDir}/$HallyBbsScript" method=POST>
<INPUT type=hidden name=ally value="$HallyID">
<INPUT type=hidden name=htmlname value="$HhtmlName">
<INPUT type=hidden name=maxline value="$HmaxLine">
<INPUT type=hidden name=amity value="$Hamity">
<INPUT type=hidden name=id value="0">
<INPUT type=hidden name=mode value="html">
<INPUT type=hidden name=cpass value="${HinputPassword}">
</FORM>
<H2><a href="JavaScript:void(0)" onClick="document.HTMLLOG.submit();return false;">예</a> <a href="${HmenteFile}?ADMIN=${HinputPassword}">아니오</a></H2>
END
	return;
}

# 소멸 로그 삭제
sub dellogMode {
	if($dellcheck) {
		my $logfile = "${HbbsdirName}/${deadally}$Hlogfile_name";
		unlink($logfile) if (-f $logfile);
		# 맹주 로그 파일
		my $logfile2 = "${HbbsdirName}/${deadally}$Hlogfile2_name";
		unlink($logfile2) if (-f $logfile2);
		# 카운터 파일
		if($Hcounter) {
			my $cntfile = "${HbbsdirName}/${deadally}$Hcntfile_name";
			unlink($cntfile) if (-f $cntfile);
		}
		# 과거 로그용 NO 파일
		if($Hpastkey) {
			my $nofile = "${HbbsdirName}/${deadally}$Hnofile_name";
			my $count;
			if (-f $nofile) {
				# 과거 NO 을 열기
				open(NO,"$nofile") || die $!;
				$count = <NO>;
				close(NO);
			}
			unlink($nofile);
			foreach (1..$count) {
				my $pastfile = sprintf("%s/%04d\.%s\.cgi", $HpastdirName,$_,$deadally);
				unlink($pastfile) if (-f $pastfile);
			}
		}
		open(DIN, "${HbbsdirName}/dead${HallyData}") || die $!;
		my @dead = <DIN>;
		close(DIN);
		open(DOUT, ">${HbbsdirName}/dead${HallyData}") || die $!;
		foreach (@dead) {
			my($dally, $daName, $diName) = split(/\,/, $_);
			next if($dally eq $deadally);
			print DOUT $_;
		}
		close(DOUT);
	} else {
		open(DIN, "${HbbsdirName}/dead${HallyData}") || die $!;
		my @dead = <DIN>;
		close(DIN);
		my $deadallyList;
		foreach (@dead) {
			my($dally, $daName, $diName) = split(/\,/, $_);
			my($did, $dturn) = split(/-/, $dally);
			$deadallyList = "$daName($HallyTopName:$diName 턴$dturn 에소멸)\n";
			last if($dally eq $deadally);
			$deadallyList = '';
		}
		if($deadallyList eq '') {
			$dellcheck = 1;
			return;
		}

		print <<END if(@dead> 0);
<H2>$deadallyList의 소멸 로그를 삭제하시겠습니까?</H2>
<H2><FORM name="DELBBS" action="${HmenteFile}" method=POST>
<INPUT type=hidden name=DELLOK value="1">
<INPUT type=hidden name=DEADALLY value="${deadally}">
<INPUT type=hidden name=PASSWORD value="${HinputPassword}">
<INPUT type=hidden value='소멸 로그의 삭제' name="DELLOG">
<a href="JavaScript:void(0)" onClick="document.DELBBS.submit();return false;">예</a> <a href="${HmenteFile}?ADMIN=${HinputPassword}">아니오</a></H2>
END
	}
	return;
}

# 표시 모드
sub dataPrint {
	my($suf) = @_;

	print "<HR>";
	if($suf eq "") {
		open(IN, "${HdirName}/$HmainData");
		print "<H1>현재 데이터</H1>";
	} else {
		open(IN, "${HdirName}.bak$suf/$HmainData");
		print "<H1>백업$suf</H1>";
	}

	my($lastTurn, $playNow);
	my $tmp = <IN>;
	chomp($tmp);
	($lastTurn, $playNow) = split(/,/, $tmp); # 턴 수, 게임안플래그
	if($playNow) {
		$playNow = '';
	} else {
		$playNow = '(게임종료)';
	}
	my($lastTime);
	$lastTime = <IN>;

	my($timeString) = timeToString($lastTime);

	print <<END;
	 <H3>[턴 $lastTurn]</H5>$playNow<BR>
	<B>최종 갱신 시간</B>:$timeString<BR>
	<B>최종 갱신 시간(초 단위 표시)</B>:1970년1월1일에서$lastTime 초<BR>
	<INPUT TYPE="submit" VALUE="이 데이터 삭제" NAME="DELETE$suf">
END

	if($suf eq "") {
		my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime($lastTime + $Hjst);
		$mon++;
		$year += 1900;

		print <<END;
	<INPUT TYPE="submit" VALUE="이 데이터를 백업" NAME="BACKUP">
	백업 No.<SELECT NAME="BUNO"><OPTION VALUE="0" SELECTED>0
END
	foreach (1..99) {
		print "<OPTION VALUE=\"$_\">$_\n";
	}

		print <<END;
	</SELECT>
	<H2>최종 갱신 시간의 변경</H2>
	<INPUT TYPE="text" SIZE=4 NAME="YEAR" VALUE="$year">년
	<INPUT TYPE="text" SIZE=2 NAME="MON" VALUE="$mon">월
	<INPUT TYPE="text" SIZE=2 NAME="DATE" VALUE="$date">일
	<INPUT TYPE="text" SIZE=2 NAME="HOUR" VALUE="$hour"> 시
	<INPUT TYPE="text" SIZE=2 NAME="MIN" VALUE="$min">분
	<INPUT TYPE="text" SIZE=2 NAME="NSEC" VALUE="$sec">초
	<INPUT TYPE="submit" VALUE="변경" NAME="NTIME"><BR>
	1970년1월1일에서<INPUT TYPE="text" SIZE=32 NAME="SSEC" VALUE="$lastTime">초
	<INPUT TYPE="submit" VALUE="초지정에서 변경" NAME="STIME">
END
	} else {
		print <<END;
	<INPUT TYPE="submit" VALUE="이 데이터를 현재 데이터로 사용" NAME="CURRENT$suf">
END
	}
}

# CGI 읽기
sub cgiInput {
	my($line);

	# 입력을 받음
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};

	if($line =~ /DELETE([0-9]*)/) {
		$mainMode = 'delete';
		$deleteID = $1;
	} elsif($line =~ /CURRENT([0-9]*)/) {
		$mainMode = 'current';
		$currentID = $1;
	} elsif($line =~ /BACKUP/) {
		$mainMode = 'backup';
		if($line =~ /BUNO=([0-9]*)/) {
			$backupNo = $1;
		} else {
			$backupNo = 0;
		}
	} elsif($line =~ /NEW/) {
		$mainMode = 'new';
	} elsif($line =~ /UNMENTE/) {
		$mainMode = 'unmente';
		if($line =~ /ADMIN=([0-9])\&/) {
			$dellcheck = $1;
		}
	} elsif($line =~ /MENTE/) {
		$mainMode = 'mente';
		if($line =~ /ADMIN=([0-9])\&/) {
			$dellcheck = $1;
		}
	} elsif($line =~ /ALLYLOG/) {
		$mainMode = 'allylog';
		if($line =~ /ALLYID=([0-9]*)\&/) {
			$HallyID = $1;
		}
		if($line =~ /DELLOK=([0-9])\&/) {
			$dellcheck = $1;
		}
	} elsif($line =~ /DELLOG/) {
		$mainMode = 'dellog';
		$line =~ /DEADALLY=([0-9]*\-[0-9]*)\&/;
		$deadally = $1;
		if($line =~ /DELLOK=([0-9])\&/) {
			$dellcheck = $1;
		}
	} elsif($line =~ /HTMLLOG/) {
		$mainMode = 'log2html';
		if($line =~ /ALLYID=([0-9\-]*)\&/) {
			$HallyID = $1;
		}
		if($line =~ /HTMLNAME=([^\&]*)\&/) {
			$HhtmlName = $1;
		}
		if($line =~ /MAXLINE=([0-9]*)\&/) {
			$HmaxLine = $1;
		}
		if($line =~ /AMITY=([0-9])/) {
			$Hamity = $1;
		}
	} elsif($line =~ /ADMIN/) {
		$mainMode = 'admin';
	} elsif($getLine =~ /ADMIN=([^\&]*)/) {
		$mainMode = 'admin';
		$HinputPassword = htmlEscape($1);
	} elsif($line =~ /SETUP/ || $line =~ /CHANGEPW/) {
		$mainMode = 'setup';
		$modeValue = ($line =~ /CHANGEPW/) ? 1 : 0;
		if($line =~ /MPASS1=([^\&]*)\&/) {
			$mpass1 = htmlEscape($1);
		}
		if($line =~ /MPASS2=([^\&]*)\&/) {
			$mpass2 = htmlEscape($1);
		}
		if($line =~ /SPASS1=([^\&]*)\&/) {
			$spass1 = htmlEscape($1);
		}
		if($line =~ /SPASS2=([^\&]*)\&/) {
			$spass2 = htmlEscape($1);
		}
	} elsif($line =~ /NTIME/) {
		$mainMode = 'time';
		if($line =~ /YEAR=([0-9]*)/) {
			$ctYear = $1;
		}
		if($line =~ /MON=([0-9]*)/) {
			$ctMon = $1;
		}
		if($line =~ /DATE=([0-9]*)/) {
			$ctDate = $1;
		}
		if($line =~ /HOUR=([0-9]*)/) {
			$ctHour = $1;
		}
		if($line =~ /MIN=([0-9]*)/) {
			$ctMin = $1;
		}
		if($line =~ /NSEC=([0-9]*)/) {
			$ctSec = $1;
		}
	} elsif($line =~ /STIME/) {
		$mainMode = 'stime';
		$ctSec = $1 if($line =~ /SSEC=([0-9]*)/);
	} elsif($line =~ /TOURNAMENTTIME/) {
		$mainMode = 'tournamenttime';
	}

	if($line =~ /PASSWORD=([^\&]*)\&/) {
		$HinputPassword = htmlEscape($1);
	}
	if(checkMasterPassword($HinputPassword)) {
		$HcurrentID = 0;
		$defaultID = 0;
	}
}

# 파일의 복사
sub fileCopy {
	my($src, $dist) = @_;
	open(IN, $src);
	open(OUT, ">$dist");
	while(<IN>) {
		print OUT;
	}
	close(IN);
	close(OUT);
}

# 경로 확인
sub passCheck {
	if(checkMasterPassword($HinputPassword)) {
		return 1;
	} else {
		tempWrongPassword(); # 비밀번호 불일치
		print<<"END";
</BODY></HTML>
END
		exit(0);
	}
}

# 점검 모드
sub menteMode {
 mkdir("./mente_lock", $HdirMode);
}

# 관리 모드 해제
sub unmenteMode {
	rmdir("./mente_lock");
}

# Time::Local 의호환함수
sub timelocal {
	my($sec, $min, $hour, $day, $mon, $year) = @_;

	$year += 1900;
	$mon++;
	if ($mon <= 2) { $mon += 12; $year--; }

	my $days = $year * 365 + int($year / 4) - int($year / 100) + int($year / 400)
	+ $mon * 30 + int(($mon + 1) * 3 / 5) + $day - 33 - 719528; # 719528 = 1970/1/1

	return (($days * 24 + $hour) * 60 + $min) * 60 + $sec - $Hjst;
}

1;
