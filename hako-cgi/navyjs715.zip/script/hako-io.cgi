#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 입출력용스크립트(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 모형정원 제도 2nd
#								 v1.5
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							 모형정원 모형정원 바다전쟁
#								 v1.3
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#----------------------------------------------------------------------
# 섬 데이터 입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readIslandsFile {
	my($num) = @_; # 0이면 지형·명령·게시판 로그를 읽기 전
				 # -1이면 전체 지형·전체 명령을 읽어들임
				 # -2이면 전체 지형을 읽어들임
				 # -3이면 전체 명령을 읽어들임
				 # -4이면 전체 게시판 로그를 읽어들임
				 # 번호이면 그 섬의 지형·명령·게시판 로그만은 읽어들임

	# 데이터 파일 열기
	if(!open(IN, "${HdirName}/$HmainData")) {
		rename("${HdirName}/hakojima.tmp", "${HdirName}/$HmainData");
		if(!open(IN, "${HdirName}/$HmainData")) {
			return 0;
		}
	}

	# 각매개변수읽기
	my $tmp = <IN>;
	chomp($tmp);
	($HislandTurn, $HplayNow) = split(/,/, $tmp); # 턴 수, 게임안플래그
#	if($HislandTurn == 0) {
#		return 0;
#	}
	$HislandLastTime = int(<IN>); # 최종 갱신 시간
	if($HislandLastTime == 0) {
		return 0;
	}
	# unitTime 토 repeatTurn 의덮어쓰기
	my $armTurn = ($HarmisticeTurn < $HsurvivalTurn) ? $HsurvivalTurn : $HarmisticeTurn;
	$HarmTime = $HunitTime;
	$HarmRepeatTurn = $HrepeatTurn;
	if($armTurn && ($HislandTurn < $armTurn)){
		$HunitTime = $HarmisticeTime;
		$HrepeatTurn = $HarmisticeRepeatTurn;
	}
	$HislandNumber = int(<IN>); # 섬의 총 수
	$islandNumber = $HislandNumber - 1; # 섬의 총 수 - 1
	$HislandNextID = int(<IN>); # 다음에 할당할 ID
	# 관리자 위임 임시의 섬 ID
	$tmp = <IN>;
	chomp($tmp);
	my(%preFlag);
	foreach (split(/,/, $tmp)) {
		my($pID, $pTurn) = split(/<>/, $_);
		$preFlag{$pID} = $pTurn;
		push(@HpreDeleteID, $pID);
	}

	# 토너먼트용
	$HislandFightMode = int(<IN>); # 현재의 전투 모드
	$HislandChangeTurn = int(<IN>); # 전환에 턴
	$HislandFightCount = int(<IN>); # 몇 번째 경기인지

	chomp($tmp = <IN>); # 전쟁국 목록
	@HwarIsland = split(/,/, $tmp);
	<IN>;# 확장용
	<IN>;# 확장용
	<IN>;# 확장용
	<IN>;# 확장용
	<IN>;# 확장용
	<IN>;# 확장용
	if($Htournament){
		# 토너먼트 모드
		if(($HislandChangeTurn != $HyosenTurn) && ($HislandTurn < $HyosenTurn)) {
			# 도중에 설정 변경한 경우의 처리
			$HislandChangeTurn = $HyosenTurn;
			$HislandFightMode = 0;
			$HislandFightCount = 0;
		}
		$HcounterSetting = 0;
		$HallyUse = 0;
		$HuseAmity = 0;
		$HuseDeWar = 0;
		$HarmisticeTurn = 0;
		$HsurvivalTurn = 0;
		if($HislandFightMode == 1) {
			# 개발
			@HflexTime = @HtmTime2;
			$HunitTime = $HdevelopeTime;
			$HunitTime = (($HislandTurn> $HyosenTurn) && ($HislandTurn == $HislandChangeTurn - $HdevelopeTurn)) ? $HinterTime : $HdevelopeTime;
			$HrepeatTurn = $HdeveRepCount;
		} elsif($HislandFightMode == 2) {
			# 전투
			@HflexTime = @HtmTime3;
			$HunitTime = $HfightTime;
			$HrepeatTurn = $HfightRepCount;
		} else {
			# 예선
			@HflexTime = @HtmTime1;
			$HunitTime = $HyosenTime;
			$HrepeatTurn = $HyosenRepCount;
		}
	} else {
		$HislandFightMode = 0; # 현재의 전투 모드
		$HislandChangeTurn = 0; # 전환에 턴
		$HislandFightCount = 0; # 몇 번째 경기인지
	}
	# flexTime 처리
	$HunitTime = 3600 * $HflexTime[($HislandTurn % ($#HflexTime + 1))] if($HflexTimeSet);
	# 턴 처리판정
	my($now) = time;
	my $flag = 0; # 턴 갱신전은0, 갱신 시는1
	my $tempMode = $HmainMode;
	my $predelNumber = @HpreDeleteID; # 관리자 보관의 섬
	if (
		( ($Hdebug && ($HmainMode eq 'Hdebugturn')) || (($now - $HislandLastTime)>= $HunitTime) )
		&&
		( !$HgameLimitTurn || ($HislandTurn < $HgameLimitTurn) )
		&&
		( !$HsurvivalTurn || ($islandNumber != $predelNumber) || ($HislandTurn <= $HsurvivalTurn) )
		&&
		( !$Htournament || ($islandNumber != $predelNumber) || ($HislandTurn <= $HyosenTurn) )
	 ) {
		$HmainMode = 'turn';
		$num = -1; # 전체 섬읽어들임
		$flag = 1; # 갱신플래그를1에
	}

	$HnextTime = $HislandLastTime + $HunitTime;
	if($flag) {
		if($HflexTimeSet) {
			$HnextTime += 3600 * $HflexTime[(($HislandTurn + 1) % ($#HflexTime + 1))];
		} else {
			$HnextTime += $HunitTime;
		}
	}

	if (
		!($HgameLimitTurn && !($HislandTurn < $HgameLimitTurn)) &&
		!($HsurvivalTurn && !($islandNumber> $predelNumber) && ($HislandTurn> $HsurvivalTurn)) &&
		!($Htournament && !($islandNumber> $predelNumber) && ($HislandTurn> $HyosenTurn))
	 ) {
		$HleftTime = $HnextTime - $now;
		$HplayNow = 1 if(!$HarmisticeTurn && !$Htournament);
		$HnextTime = sprintf('%d월 %d일 %d 시', (gmtime($HnextTime + $Hjst))[4] + 1, (gmtime($HnextTime + $Hjst))[3,2]);
	} else {
		$HplayNow = 0;
		$HnextTime = ' ';
		$HmainMode = ($tempMode ne '') ? $tempMode : 'top';
	}

	# 섬읽기
	if($HoceanMode && !(-e "${HdirName}/world.${HsubData}") && !(-e "${HdirName}/worldtmp.${HsubData}")) {
		$HoceanMapNone = 1;
	}
	my($i);
	# 관리자 보관의 플래그 설정
	$HbfieldNumber = 0;
	foreach $i (0..$islandNumber) {
		$Hislands[$i] = readIsland($num);
		$HidToNumber{$Hislands[$i]->{'id'}} = $i;
		if($Hislands[$i]->{'field'}) {
			$HbfieldNumber++;
		}
		if($preFlag{$Hislands[$i]->{'id'}}) {
			# 관리자 보관의 플래그 설정
			$Hislands[$i]->{'predelete'} = $preFlag{$Hislands[$i]->{'id'}};
		}
	}
	# 파일을 닫기
	close(IN);

	# 해역
	my($island);
	if($HoceanMapNone && ($num>= -2)) {
		my($x, $y, $i, $j, @land, @landValue);
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$i];
			foreach $y (@{$island->{'map'}->{'y'}}) {
				foreach $x (@{$island->{'map'}->{'x'}}) {
					$Hworld->{'land'}->[$x][$y] = $island->{'land'}->[$x][$y];
					$Hworld->{'landValue'}->[$x][$y] = $island->{'landValue'}->[$x][$y];
				}
			}
		}
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$i];
			($island->{'land'}, $island->{'landValue'}) = ($Hworld->{'land'}, $Hworld->{'landValue'});
		}
	} elsif(($HoceanMode && ($num>= -2)) || $HislandMapNone) {
		if(!open(WIN, "${HdirName}/world.${HsubData}")) {
			if(-e "${HdirName}/worldtmp.${HsubData}") {
				rename("${HdirName}/worldtmp.${HsubData}", "${HdirName}/world.${HsubData}");
			}
			if(!open(WIN, "${HdirName}/world.${HsubData}")) {
				exit(0);
			}
		}
		chomp(my @line = <WIN>);
		close(WIN);
		my $map = { 'x' => \@defaultX, 'y' => \@defaultY };
		($Hworld->{'land'}, $Hworld->{'landValue'}) = readLand($map, @line);
		if(!$HislandMapNone) {
			foreach $i (0..$islandNumber) {
				$island = $Hislands[$i];
				($island->{'land'}, $island->{'landValue'}) = ($Hworld->{'land'}, $Hworld->{'landValue'});
			}
		} else {
			foreach $i (0..$islandNumber) {
				$island = $Hislands[$i];
				my(@mx) = @{$island->{'map'}->{'x'}};
				my(@my) = @{$island->{'map'}->{'y'}};
				my($x, $y, $i, $j, @land, @landValue);
				foreach $j (@defaultY) {
					$y = $my[$j];
					foreach $i (@defaultX) {
						$x = $mx[$i];
						$land[$i][$j] = $Hworld->{'land'}->[$x][$y];
						$landValue[$i][$j] = $Hworld->{'landValue'}->[$x][$y];
					}
				}
				$island->{'land'} = \@land;
				$island->{'landValue'} = \@landValue;
				$island->{'map'} = $map;
			}
		}
	}
	# 동맹 데이터 읽기
	readAllyFile() if($HallyUse || $HarmisticeTurn || ($HmainMode eq 'asetup'));

	# 아이템의 준비
	if($HuseItem) {
		my $iKind;
		foreach $iKind (1..$#HitemName) {
			foreach (0..5) {
				push(@{$Hitems[$_]}, $iKind) if($HitemSpecial[$iKind][$_] != 0);
			}
			foreach (6..23) {
				push(@{$Hitems[$_]}, $iKind) if($HitemSpecial[$iKind][$_] != 1);
			}
		}
		my %keyItem;
		foreach (@{$Hitems[0]}) {
			$keyItem{$_} = 1;
		}
		$HitemComplete = 0;
		$HitemCompleteA = 0;
		my(%checkItemA);
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$i];
			foreach (1..23) {
				$island->{'itemAbility'}[$_] = $HitemSpecial[0][$_];
			}
			my(%checkItem);
			foreach $iKind (@{$island->{'item'}}) {
				next if($checkItem{$iKind});
				$checkItem{$iKind} = 1;
				next if($iKind eq '');
				$island->{'itemNumber'}++;
				foreach (1..6, 24) {
					$island->{'itemAbility'}[$_] = $HitemSpecial[$iKind][$_] if($island->{'itemAbility'}[$_] < $HitemSpecial[$iKind][$_]);
				}
				foreach (7..23) {
					$island->{'itemAbility'}[$_] *= $HitemSpecial[$iKind][$_];
				}
				$HitemGetId[$iKind]{$island->{'id'}} = 1;
				next if(!$keyItem{$iKind});
				$island->{'keyItemNumber'}++;
				next if(!$HallyItemComplete);
				foreach (@{$island->{'allyId'}}) {
					my $aNum = $HidToAllyNumber{$_};
					next if($checkItemA{$aNum}{$iKind});
					$checkItemA{$aNum}{$iKind} = 1;
					my $ally = $Hally[$aNum];
					$ally->{'keyItemNumber'}++;
					$HitemCompleteA = $ally->{'id'} if(@{$Hitems[0]} && ($ally->{'keyItemNumber'} == @{$Hitems[0]}));
				}
			}
			@{$island->{'item'}} = sort { $a <=> $b } keys %checkItem;
			$HitemComplete = $island->{'id'} if(@{$Hitems[0]} && ($island->{'keyItemNumber'} == @{$Hitems[0]}));
		}
		foreach (1..$#HitemName){
			push(@Hitem, $_) if!(keys %{$HitemGetId[$_]});
		}
		$HitemRest = @Hitem;
	} else {
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$i];
			foreach (1..23) {
				$island->{'itemAbility'}[$_] = $HitemSpecial[0][$_];
			}
		}
	}
	foreach $i (0..$islandNumber) {
		$island = $Hislands[$i];
		if($HoceanMode) {
			# 좌표에서 지형의 ID 을 설정
			my($x, $y);
			foreach $x (@{$island->{'map'}->{'x'}}) {
				foreach $y (@{$island->{'map'}->{'y'}}) {
					$HlandID[$x][$y] = $island->{'id'};
				}
			}
		}
		# 명령 실행플래그 처리
		next if($HmainMode ne 'turn');
		foreach (keys %{$island->{'epoint'}}) {
			delete $island->{'epoint'}{$_} if!($Hislands[$HidToNumber{$_}]->{'event'}[0]);
		}
		if(!$HcomflagUse) {
			$island->{'comflag'} = 0;
		} elsif($HcomflagUse == 1) {
			$island->{'comflag'} = 1;
		}
	}
	makeRen() if($HoceanMode && $HnotuseNavyMove);
	if (
		!$HplayNow ||
		$HitemComplete || $HitemCompleteA ||
		($HsurvivalTurn && ($islandNumber - $predelNumber == $HbfieldNumber) && ($HislandTurn> $HsurvivalTurn)) ||
		($Htournament && ($islandNumber - $predelNumber == $HbfieldNumber) && ($HislandTurn> $HyosenTurn))
	 ) {
		# 중단 모드에 변경
		$HmainMode = ($tempMode ne '') ? $tempMode : 'top';
		$HplayNow = 0;
		$HnextTime = ' ';
	}
	return 1;
}

# 섬 하나 읽기
sub readIsland {
	my($num) = @_;
	my($name, $owner, $birthday, $id, $prize, $absent, $preab, $comflag, $earth, $comment, $password, $money, $food,
		$pop, $area, $farm, $factory, $mountain, $tmp, @amity, @fleet, @priority, @fkind, $gain, $monskill, $monslive,
		@sinktmp, @sink, @sinkself, @subSink, @subSinkself, @exttmp, @ext, @subExt, $field, @item, @weather,
		$fight_id, $rest, @event, $point, @defeat,%epoint, @epointtmp, @xytmp, @x, @y, $map, $wmap, @move);
	chomp($name = <IN>); # 섬 이름
	chomp($owner = <IN>); # 소유자의 이름
	$birthday = int(<IN>); # 시작 턴
	$id = int(<IN>); # ID 번호
	chomp($prize = <IN>); # 수상
	chomp(($absent, $preab, $comflag, $earth) = split(/\,/, <IN>)); # 연속자금 조달 수, 개발위임위탁(진영보관), 명령 실행 설정, 지구 모드주변 표시
	chomp($comment = <IN>); # 코멘트
	chomp($password = <IN>); # 암호화 비밀번호
	$money = int(<IN>); #자금
	$food = int(<IN>); # 식량
	$pop = int(<IN>); # 인구
	$area = int(<IN>); # 면적
	$farm = int(<IN>); # 농장
	$factory = int(<IN>); # 공장
	$mountain = int(<IN>); # 채굴장
	chomp($tmp = <IN>); # 우호국
		@amity = split(/\,/, $tmp);
	chomp($tmp = <IN>); # 함대 이름
		@fleet = split(/\,/, $tmp);
	chomp($tmp = <IN>); # 색적 순서
		@priority = split(/\,/, $tmp);
	chomp($tmp = <IN>); # 보유 함정종류
		@fkind = split(/\,/, $tmp);
	$gain = int(<IN>); # 총 획득 경험치
	$monskill = int(<IN>); # 괴수퇴치 수
	chomp($monslive = <IN>); # 괴수출현 수, 종류, 종류(거대), 소속 불명 함정 출현 수, 종류
	chomp($tmp = <IN>); # 격침 수
		@sinktmp = split(/\-/, $tmp);
			@sink = split(/\,/,$sinktmp[0]); # 자기 섬 이외의 함정
			@sinkself = split(/\,/,$sinktmp[1]); # 자기 섬
			@subSink = split(/\,/,$sinktmp[2]); # 하위자기 섬 이외의 함정
			@subSinkself = split(/\,/,$sinktmp[3]); # 하위자기 섬
	chomp($tmp = <IN>); # 확장 영역
		@exttmp = split(/<>/, $tmp);
			@ext = split(/\,/,$exttmp[0]); # 확장 영역
			# 승리 플래그, 공헌도x10, 방어 격파, 미사일 격파, 난민 구조, 날아온 탄환, 탄환 발사, 탄환 방어, 함정 파견, 함정 피격, 함정 파괴
			@subExt = split(/\,/,$exttmp[1]); # 하위확장 영역
			# 기록 턴, 공헌도x10, 방어 격파, 미사일 격파, 난민 구조, 날아온 탄환, 탄환 발사, 탄환 방어, 함정 파견, 함정 피격, 함정 파괴, 퇴치 수, 포상금
	chomp($field = <IN>); # 피루도속성
	chomp($tmp = <IN>); # 아이템
		@item = split(/\,/, $tmp);
	chomp($tmp = <IN>); # 기온, 기압, 습도, 풍속, 지반, 파력, 이상, 날씨(로그 표시 수)
		$tmp = "20,1013,40,0,0,0,0,2,2,2,2" if($tmp == '');
		@weather = split(/\,/, $tmp);
	chomp(($fight_id, $rest) = split(/\,/, <IN>)); # 토너먼트 대전 상대 ID, 남은 개발 정지 턴 수
	chomp($tmp = <IN>); # 이벤트플래그 시작 턴 기간 함정 수 함종 제한 유형 보상금 보상식량 관리자선물의 유무 보상 아이템 추가 파견 괴수출현1 괴수출현2 거대괴수출현1 거대괴수출현2 함정 출현1 함정 출현2 자동귀환
# 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3
		$tmp = "0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,1,0,0,0,0" if($tmp == '');
		@event = split(/\,/, $tmp);
	$point = int(<IN>); # 포인트
	chomp($tmp = <IN>); # 침몰한 섬 이름, 턴 수,...
		@defeat = split(/\,/, $tmp);
	chomp($tmp = <IN>); # 이벤트포인트
		@epointtmp = split(/\,/, $tmp);
		for($i=0;$i<$#epointtmp;$i+=2) {
			$epoint{$epointtmp[$i]} = $epointtmp[$i+1];
		}
	chomp($tmp = <IN>); # 지도배열저장 x0,x1,...,xn<>y0,y1,...,yn<>x<>y
		if(!$HoceanMode && !(-e "${HdirName}/${id}.${HsubData}") && !(-e "${HdirName}/${id}tmp.${HsubData}")) {
			$HislandMapNone = 1;
		}
		@xytmp = split(/<>/, $tmp);
			@x = (($HoceanMode || $HislandMapNone) && (defined $xytmp[0])) ? split(/\,/, $xytmp[0]) : (0..($HislandSizeX-1));
			@y = (($HoceanMode || $HislandMapNone) && (defined $xytmp[1])) ? split(/\,/, $xytmp[1]) : (0..($HislandSizeY-1));
		$map = { 'x' => \@x, 'y' => \@y };
		$wmap = { 'x' => $xytmp[2], 'y' => $xytmp[3] };
		if($HoceanMapNone) {
			$wmap = randomIslandMap(); # 섬의 좌표를 결하기
			# 지도배열
			my @x = (($wmap->{'x'} * $HislandSizeX)..($wmap->{'x'} * $HislandSizeX + $HislandSizeX - 1));
			my @y = (($wmap->{'y'} * $HislandSizeY)..($wmap->{'y'} * $HislandSizeY + $HislandSizeY - 1));
			$map = { 'x' => \@x, 'y' => \@y };
		}
		$HoceanMap[$wmap->{'x'}][$wmap->{'y'}] = $id;
	chomp($tmp = <IN>); # 이동 지령 x,y<>x,y<>x,y<>x,y
		@move = split(/<>/, $tmp);
	<IN>; # 예비
	<IN>; # 예비

	# HidToName 테이블에 저장
	$HidToName{$id} = $name;

	my(@line, @land, $command, $lbbs);

	# 지형
	if((!$HoceanMode && (($num == -1) || ($num == -2) || ($num == $id))) || $HoceanMapNone) {
		if(!open(IIN, "${HdirName}/${id}.${HsubData}")) {
			if(-e "${HdirName}/${id}tmp.${HsubData}") {
				rename("${HdirName}/${id}tmp.${HsubData}", "${HdirName}/${id}.${HsubData}");
			}
			if(!open(IIN, "${HdirName}/${id}.${HsubData}")) {
				#exit(0);
				$HislandMapNone = 1;
			}
		}
		if(!$HislandMapNone) {
			chomp(@line = <IIN>);
			close(IIN);
			@land = readLand($map, @line);
		}
	}

	# 명령
	if(($num == -1) || ($num == -3) || ($num == $id)) {
		if( $HmainMode eq 'owner' || # 개발 모드
			$HmainMode eq 'commandJava' || # 명령 입력 모드
			$HmainMode eq 'command' || # 명령 입력 모드
			$HmainMode eq 'command2' || # 명령 입력 모드(ver1.1부터 추가·자동 입력용)
			$HmainMode eq 'comment' || # 코멘트입력 모드
			$HmainMode eq 'fleetname' || # 함대 이름 변경 모드
			$HmainMode eq 'priority' || # 색적 순서 변경 모드
			$HmainMode eq 'earth' || # 주변 표시 설정 모드
			$HmainMode eq 'comflag' || # 명령 실행 설정 모드
			$HmainMode eq 'preab' || # 진영공동개발 모드
			$HmainMode eq 'lbbs' || # 로컬 게시판 모드
			$HmainMode eq 'new' || # 섬 신규 생성
			$HmainMode eq 'print' || # 관광 모드
			$HmainMode eq 'reload' || # 저장 데이터복원 모드
			$HmainMode eq 'turn' || # 턴진행
			$HmainMode eq 'camp' || # 진영 모드
			$HmainMode eq 3 || # 모바이루 모드
			$HmainMode eq 4 # 모바이루 모드
		) {
			$command = readCommand($id, $HcommandMax);
		}
	}

	# 로컬 게시판
	if(($num == -4) || ($num == $id)) {
		if( $HmainMode eq 'owner' || # 개발 모드
			$HmainMode eq 'commandJava' || # 명령 입력 모드
			$HmainMode eq 'command' || # 명령 입력 모드
			$HmainMode eq 'command2' || # 명령 입력 모드(ver1.1부터 추가·자동 입력용)
			$HmainMode eq 'comment' || # 코멘트입력 모드
			$HmainMode eq 'fleetname' || # 함대 이름 변경 모드
			$HmainMode eq 'priority' || # 색적 순서 변경 모드
			$HmainMode eq 'earth' || # 주변 표시 설정 모드
			$HmainMode eq 'comflag' || # 명령 실행 설정 모드
			$HmainMode eq 'preab' || # 진영공동개발 모드
			$HmainMode eq 'lbbs' || # 로컬 게시판 모드
			$HmainMode eq 'landmap' || # 관광 모드
			$HmainMode eq 'new' || # 섬 신규 생성
			$HmainMode eq 'print' || # 관광 모드
			$HmainMode eq 'reload' || # 저장 데이터복원 모드
			$HmainMode eq 5 # 모바이루 모드
		) {
			$lbbs = readLbbs($id);
		}
	}

	# 섬 형태로 반환
	return {
		'name' => $name,
		'owner' => $owner,
		'birthday' => $birthday,
		'id' => $id,
		'prize' => $prize,
		'absent' => $absent,
		'preab' => $preab,
		'comflag' => $comflag,
		'earth' => $earth,
		'comment' => $comment,
		'password' => $password,
		'money' => $money,
		'food' => $food,
		'pop' => $pop,
		'area' => $area,
		'farm' => $farm,
		'factory' => $factory,
		'mountain' => $mountain,
		'amity' => \@amity,
		'fleet' => \@fleet,
		'priority' => \@priority,
		'fkind' => \@fkind,
		'gain' => $gain,
		'monsterkill' => $monskill,
		'monsterlive' => $monslive,
		'sink' => \@sink,
		'sinkself' => \@sinkself,
		'subSink' => \@subSink,
		'subSinkself' => \@subSinkself,
		'ext' => \@ext,
		'subExt' => \@subExt,
		'field' => $field,
		'item' => \@item,
		'weather' => \@weather,
		'fight_id' => $fight_id,
		'rest' => $rest,
		'event' => \@event,
		'point' => $point,
		'defeat' => \@defeat,
		'epoint' => \%epoint,
		'map' => $map,
		'wmap' => $wmap,
		'move' => \@move,
		'land' => $land[0],
		'landValue' => $land[1],
		'command' => $command,
		'lbbs' => $lbbs,
	};
}

# 지형읽기
sub readLand {
	my($map, @line) = @_;

	my(@land, @landValue, @mx, @my);
	@mx = sort { $a <=> $b } @{$map->{'x'}};
	@my = sort { $a <=> $b } @{$map->{'y'}};
	my($x, $y, $dx, $dy, $startx, $sflagx, $endx, $starty, $sflagy, $endy);
	if(!$HoceanMode && !$HislandMapNone) {
		$dx = @{$map->{'x'}} - (length($line[0]) / 10);
		$dy = @{$map->{'y'}} - @line;
		$sflagx = int($dx/2);
		$startx = ($sflagx < 0) ? 0 : abs($sflagx);
		$sflagx = 0 if($sflagx> 0);
		$endx = $startx + $#{$map->{'x'}};
		$sflagy = int($dy/2);
		$starty = ($sflagy < 0) ? 0 : abs($sflagy);
		$endy = $starty + $#{$map->{'y'}};
	} else {
		$sflagx = 0;
		$startx = 0;
		$endx = (length($line[0]) / 10) - 1;
		$sflagy = 0;
		$starty = 0;
		$endy = $#line;
		if($HislandMapNone) {
			@mx = ($startx..$endx);
			@my = ($starty..$endy);
		}
	}
	foreach $y ($starty..$endy) {
		foreach $x ($startx..$endx) {
			$line[$y - $sflagy] =~ s/^(..)(........)//;
			next if($x + $sflagx < 0);
			$land[$mx[$x + $sflagx]][$my[$y]] = hex($1);
			$landValue[$mx[$x + $sflagx]][$my[$y]] = hex($2);
			last if(!length($line[$y - $sflagy]));
		}
	}
	return (\@land, \@landValue);
}

# 명령읽기
sub readCommand {
	my($id, $cnum) = @_;
	my(@line, @command);
	if(!open(CIN, "${HdirName}/${id}.${HcommandData}")) {
		if(-e "${HdirName}/${id}tmp.${HcommandData}") {
			rename("${HdirName}/${id}tmp.${HcommandData}", "${HdirName}/${id}.${HcommandData}");
		}
		if(!open(CIN, "${HdirName}/${id}.${HcommandData}")) {
			open(COUT, ">${HdirName}/${id}.${HcommandData}");
			close(COUT);
			open(CIN, "${HdirName}/${id}.${HcommandData}");
		}
	}
	chomp(@line = <CIN>);
	close(CIN);

	my($i);
	for($i = 0; $i < $cnum; $i++) {
		$line = shift(@line);
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		my($kind, $target, $x, $y, $arg, $target2) = (int($1), int($2), int($3), int($4), int($5), int($6));
		($kind, $target, $x, $y, $arg, $target2) = (41, 0, 0, 0, 0, 0) if(!$kind);
		$command[$i] = {
			'kind' => $kind,
			'target' => $target,
			'x' => $x,
			'y' => $y,
			'arg' => $arg,
			'target2' => $target2
		}
	}

	return \@command;
}

# 로컬 게시판읽기
sub readLbbs {
	my($id) = @_;
	my(@lbbs);
	if(!open(LIN, "${HlogdirName}/${id}.${HlbbsData}")) {
		if(-e "${HlogdirName}/${id}tmp.${HlbbsData}") {
			rename("${HlogdirName}/${id}tmp.${HlbbsData}", "${HlogdirName}/${id}.${HlbbsData}");
		}
		if(!open(LIN, "${HlogdirName}/${id}.${HlbbsData}")) {
			open(LOUT, ">${HlogdirName}/${id}.${HlbbsData}");
			close(LOUT);
			open(LIN, "${HlogdirName}/${id}.${HlbbsData}");
		}
	}
	chomp(@lbbs = <LIN>);
	close(LIN);

	return \@lbbs;
}

# 전체 섬 데이터 쓰기
sub writeIslandsFile {
	my($num) = @_; # 0이면 지형·명령·게시판 로그를 지형쓰기코먼저
				 # -1이면 전체 지형·전체 명령을 쓰기코무
				 # -2이면 전체 지형을 쓰기코무
				 # -3이면 전체 명령을 쓰기코무
				 # -4이면 전체 게시판 로그를 쓰기코무
				 # 번호이면 그 섬의 지형·명령·게시판 로그만은 쓰기코무

	# 파일을 열기
	open(OUT, ">${HdirName}/hakojima.tmp");

	# 각매개변수쓰기
	print OUT "$HislandTurn,$HplayNow\n";
	print OUT "$HislandLastTime\n";
	print OUT "$HislandNumber\n";
	print OUT "$HislandNextID". "\n";
	my(@preTemp, %preCheck);
	foreach (@HpreDeleteID) {
		next if($preCheck{$_});
		my $turn = $Hislands[$HidToNumber{$_}]->{'predelete'};
		if($turn) {
			push(@preTemp, "$_<>$turn");
			$preCheck{$_} = 1;
		}
	}
	print OUT join(',', @preTemp). "\n";
	print OUT "$HislandFightMode\n";
	print OUT "$HislandChangeTurn\n";
	print OUT "$HislandFightCount\n";
	print OUT join(',', @HwarIsland). "\n";
	print OUT "\n";
	print OUT "\n";
	print OUT "\n";
	print OUT "\n";
	print OUT "\n";
	print OUT "\n";

	# 섬의 쓰기
	my($i);
	foreach $i (0..$islandNumber) {
		writeIsland($Hislands[$i], $num, 1);
	}
	# 파일을 닫기
	close(OUT);

	# 해역
	if($HoceanMode && ($num>= -2)) {
		open(IOUT, ">${HdirName}/worldtmp.${HsubData}");
		writeLand(*IOUT, $Hworld->{'land'}, $Hworld->{'landValue'}, { 'x' => \@defaultX, 'y' => \@defaultY });
		close(IOUT);
		unlink("${HdirName}/world.${HsubData}");
		rename("${HdirName}/worldtmp.${HsubData}", "${HdirName}/world.${HsubData}");
	}

	# 동맹 데이터의 쓰기
	writeAllyFile() if($HallyUse || $HarmisticeTurn || ($HmainMode eq 'asetup'));

	# 원래 이름으로
	unlink("${HdirName}/$HmainData");
	rename("${HdirName}/hakojima.tmp", "${HdirName}/$HmainData");
}

# 섬 하나 쓰기
sub writeIsland {
	my($island, $num, $mode) = @_;
	if($mode) {

		my $priority = $island->{'priority'};
		my $fleet = $island->{'fleet'};
		my @fnum = ('제1', '제2', '제3', '제4');
		foreach (0..3) {
			$fleet->[$_] = $fnum[$_] if($fleet->[$_] eq '');
			$priority->[$_] = "0-1-2-3-4-5-6-7" if($priority->[$_] eq '' || !$HusePriority);
		}

		my $fkind = $island->{'fkind'};
		my @flist = @$fkind;
		my @idx = (0..$#flist);
		@idx = sort { (navyUnpack(hex($flist[$a])))[0] <=> (navyUnpack(hex($flist[$b])))[0] || (navyUnpack(hex($flist[$a])))[7] <=> (navyUnpack(hex($flist[$b])))[7] } @idx;
		@flist = @flist[@idx];

		$island->{'ext'}[1] = 0 if($island->{'allyId'}[0] eq '');

		print OUT $island->{'name'}. "\n";
		print OUT $island->{'owner'}. "\n";
		print OUT $island->{'birthday'}. "\n";
		print OUT $island->{'id'}. "\n";
		print OUT $island->{'prize'}. "\n";
		print OUT $island->{'absent'}. ",". $island->{'preab'}. ",". $island->{'comflag'}. ",". $island->{'earth'}. "\n";
		print OUT $island->{'comment'}. "\n";
		print OUT $island->{'password'}. "\n";
		print OUT $island->{'money'}. "\n";
		print OUT $island->{'food'}. "\n";
		print OUT $island->{'pop'}. "\n";
		print OUT $island->{'area'}. "\n";
		print OUT $island->{'farm'}. "\n";
		print OUT $island->{'factory'}. "\n";
		print OUT $island->{'mountain'}. "\n";
		print OUT join(',', @{$island->{'amity'}}). "\n";
		print OUT join(',', @$fleet). "\n";
		print OUT join(',', @$priority). "\n";
		print OUT join(',', @flist). "\n";
		print OUT $island->{'gain'}. "\n";
		print OUT $island->{'monsterkill'}. "\n";
		print OUT $island->{'monsterlive'}. "\n";
		print OUT join(',', @{$island->{'sink'}}). "-". join(',', @{$island->{'sinkself'}}). "-". join(',', @{$island->{'subSink'}}). "-". join(',', @{$island->{'subSinkself'}}). "\n";
		print OUT join(',', @{$island->{'ext'}}). "<>". join(',', @{$island->{'subExt'}}). "\n";
		print OUT $island->{'field'}. "\n";
		print OUT join(',', @{$island->{'item'}}). "\n";
		print OUT join(',', @{$island->{'weather'}}). "\n";
		print OUT $island->{'fight_id'}. ",". $island->{'rest'}. "\n";
		print OUT join(',', @{$island->{'event'}}). "\n";
		print OUT $island->{'point'}. "\n";
		print OUT join(',', @{$island->{'defeat'}}). "\n";
		my(@epoint);
		foreach (keys %{$island->{'epoint'}}){
			push(@epoint, "$_,$island->{'epoint'}{$_}");
		}
		print OUT join(',', @epoint). "\n";
		print OUT join(',', @{$island->{'map'}->{'x'}}). "<>". join(',', @{$island->{'map'}->{'y'}}). "<>". $island->{'wmap'}->{'x'}. "<>". $island->{'wmap'}->{'y'}. "\n";
		print OUT join('<>', @{$island->{'move'}}). "\n";
		print OUT "\n";
		print OUT "\n";
	}

	my $id = $island->{'id'};
	# 지형
	if(!$HoceanMode && (($num == -1) || ($num == -2) || ($num == $id))) {
		my($land, $landValue, $map);
		$land = $island->{'land'};
		$landValue = $island->{'landValue'};
		$map = $island->{'map'};

		open(IOUT, ">${HdirName}/${id}tmp.${HsubData}");
		writeLand(*IOUT, $land, $landValue, $map);
		close(IOUT);
		unlink("${HdirName}/${id}.${HsubData}");
		rename("${HdirName}/${id}tmp.${HsubData}", "${HdirName}/${id}.${HsubData}");
	}
	# 명령
	if(($num == -1) || ($num == -3) || ($num == $id)) {
		if($HmainMode eq 'commandJava' || $HmainMode eq 'command2' || $HmainMode eq 'turn' || $HmainMode eq 'command' || $HmainMode eq 'new' || $HmainMode eq 'reload' || $HmainMode eq 'bfield') {
			writeCommand($id, $island->{'command'});
		}
	}
	# 로컬 게시판
	if(($num == -4) || ($num == $id)) {
		if($HmainMode eq 'lbbs' || $HmainMode eq 'new' || $HmainMode eq 'reload' || $HmainMode eq 'bfield') {
			writeLbbs($id, $island->{'lbbs'});
		}
	}
}

# 지형쓰기
sub writeLand {
	local(*FH, $land, $landValue, $map) = @_;
	my($x, $y);
	foreach $y (sort { $a <=> $b } @{$map->{'y'}}) {
		foreach $x (sort { $a <=> $b } @{$map->{'x'}}) {
			printf FH ("%02x%08x", $land->[$x][$y], $landValue->[$x][$y]);
		}
		print FH "\n";
	}
}

# 명령쓰기
sub writeCommand {
	my($id, $command) = @_;
	my($i);
	open(COUT, ">${HdirName}/${id}tmp.${HcommandData}");
	for($i = 0; $i < $HcommandMax; $i++) {
		printf COUT ("%d,%d,%d,%d,%d,%d\n",
			$command->[$i]->{'kind'},
			$command->[$i]->{'target'},
			$command->[$i]->{'x'},
			$command->[$i]->{'y'},
			$command->[$i]->{'arg'},
			$command->[$i]->{'target2'}
		);
	}
	close(COUT);
	unlink("${HdirName}/${id}.${HcommandData}");
	rename("${HdirName}/${id}tmp.${HcommandData}", "${HdirName}/${id}.${HcommandData}");
}

# 로컬 게시판쓰기
sub writeLbbs {
	my($id, $lbbs) = @_;
	while ($HlbbsMax < @$lbbs) { pop @$lbbs; }
#	open(LOUT, ">${HlogdirName}/${id}tmp.${HlbbsData}");
	open(LOUT, ">${HlogdirName}/${id}.${HlbbsData}");
	foreach (@$lbbs) {
		next if($_ eq '0<<0>>' || $_ eq '');
		print LOUT $_. "\n";
	}
	close(LOUT);
#	unlink("${HlogdirName}/${id}.${HlbbsData}");
#	rename("${HlogdirName}/${id}tmp.${HlbbsData}", "${HlogdirName}/${id}.${HlbbsData}");
}

# 소멸 시 데이터 파일 삭제 처리
sub deleteIslandData {
	my($island) = @_;
	my($id) = $island->{'id'};
	if(!$HoceanMode) {
		unlink("${HdirName}/${id}.${HsubData}");
		unlink("${HdirName}/${id}.${HcommandData}");
		unlink("${HlogdirName}/${id}.${HlbbsData}");
	} else {
		# 바다에 초기화
		foreach $y (@{$island->{'map'}->{'y'}}) {
			foreach $x (@{$island->{'map'}->{'x'}}) {
				$island->{'land'}[$x][$y] = $HlandSea;
				$island->{'landValue'}[$x][$y] = 0;
			}
		}
	}
#HdebugOut("$island->{'id'} : $island->{'wmap'}->{'x'}, $island->{'wmap'}->{'y'}\n");
#HdebugOut("@{$island->{'map'}->{'x'}}\n");
#HdebugOut("@{$island->{'map'}->{'y'}}\n");
#		foreach $y (@defaultY) {
#			foreach $x (@defaultX) {
#				$d = sprintf("%02x%08x", $island->{'land'}[$x][$y], $island->{'landValue'}[$x][$y]);
#HdebugOut("$d");
#			}
#HdebugOut("\n");
#		}
}

# 전투 기간 시작 시의 섬의 상태를 저장(토너먼트)
# mode 0:해군마다저장 1:해군이외를 저장
# ***패자의 소멸 시저장 island_save($island, $HfightdirName, 'lose', 0);
# ***mode 0세부저장 island_save($island, $HsavedirName, 'save', 0);
# ***mode 1세부저장 island_save($island, $HsavedirName, 'save', 1, \@land, \@landValue);(로도 데이터를 전달스)
sub island_save {
	my($island, $dir, $suf, $mode, $oldland, $oldlandValue) = @_;
	my($id) = $island->{'id'};

	my $land = $island->{'land'}; # 현재의 지형
	my $landValue = $island->{'landValue'};
	my $map = $island->{'map'};
	my($x, $y);
	my(@saveland, @savelandValue, @stack); # 저장하기 지형 데이터를 구성
	foreach $y (@{$map->{'y'}}) {
		foreach $x (@{$map->{'x'}}) {
			if($mode && ($land->[$x][$y] == $HlandNavy)) {
				# 저장 데이터의 그대로
				if($oldland->[$x][$y] == $HlandNavy) {
					$saveland[$x][$y] = $oldland->[$x][$y];
					$savelandValue[$x][$y] = $oldlandValue->[$x][$y];
				} else {
					my $nSea = (navyUnpack($island->{'landValue'}[$x][$y]))[3];
					$saveland[$x][$y] = $HlandSea;
					$savelandValue[$x][$y] = $oldlandValue->[$x][$y];
				}
			} elsif($mode && ($oldland->[$x][$y] == $HlandNavy)) {
				if(($land[$x][$y] == $HlandSea) || ($land[$x][$y] == $HlandNavy)) {
					# 저장 데이터의 그대로
					$saveland[$x][$y] = $oldland->[$x][$y];
					$savelandValue[$x][$y] = $oldlandValue->[$x][$y];
				} else {
					# 일단세부 지형
					$saveland[$x][$y] = $land->[$x][$y];
					$savelandValue[$x][$y] = $landValue->[$x][$y];
					push(@stack, { 'x' => $x, 'y' => $y });
				}
			} elsif((@stack> 0) && (($land->[$x][$y] == $HlandSea) || ($land->[$x][$y] == $HlandNavy))) {
				my $point = shift(@stack);
				$saveland[$x][$y] = $oldland->[$point->{'x'}][$point->{'y'}];
				$savelandValue[$x][$y] = $oldlandValue->[$point->{'x'}][$point->{'y'}];
			} else {
				$saveland[$x][$y] = $land->[$x][$y];
				$savelandValue[$x][$y] = $landValue->[$x][$y];
			}
		}
	}
	# 스타쿠 지형이 있다면도한 번루프
	if(@stack> 0) {
		foreach $y (@{$map->{'y'}}) {
			last if(!@stack);
			foreach $x (@{$map->{'x'}}) {
				last if(!@stack);
				if(($land->[$x][$y] == $HlandSea) || ($land->[$x][$y] == $HlandNavy)) {
					my $point = shift(@stack);
					$saveland[$x][$y] = $oldland->[$point->{'x'}][$point->{'y'}];
					$savelandValue[$x][$y] = $oldlandValue->[$point->{'x'}][$point->{'y'}];
				}
			}
		}
	}

	# 저장 디렉터리의 확인
	if(!opendir(DIN, "${dir}/")) {
		mkdir("${dir}", $HdirMode);
	} else {
		closedir(DIN);
	}

	open(OUT, ">${dir}/${id}tmp_${suf}.${HsubData}");
	writeIsland($island, 0, 1);
	writeLand(*OUT, \@saveland, \@savelandValue, $map);
	close(OUT);
	unlink("${dir}/${id}_${suf}.${HsubData}");
	rename("${dir}/${id}tmp_${suf}.${HsubData}", "${dir}/${id}_${suf}.${HsubData}");
}

# 저장했습니다 섬의 상태를 복원(토너먼트)
# mode 0:해군마다복원 1:현 데이터를 저장후, 해군마다복원
# mode 2:해군이외복원 3:현 데이터(해군이외)저장후, 해군이외복원
# mode -1:토너먼트부전승 시, 지형등회복 처리
sub island_load {
	my($island, $mode) = @_;
	my($id) = $island->{'id'};

	open(IIN, "${HsavedirName}/${id}_save.${HsubData}");
	chomp(my @line = <IIN>);
	close(IIN);

	my(@tmp) = splice(@line, 0, 36);
	my(@mandf) = splice(@tmp, 8, 25);
	my($money) = shift(@mandf); #자금
	my($food) = shift(@mandf); # 식량
#	my($tmp) = pop(@mandf); # 지도
#	my(@xytmp) = split(/<>/, $tmp);
#	my(@x) = split(/\,/, $xytmp[0]);
#	my(@y) = split(/\,/, $xytmp[1]);
#	my $map = { 'x' => \@x, 'y' => \@y };
#	# 7.12이전의 데이터 때문에 처리
#	$map = $island->{'map'} if(!@x || !@y);
#	$island->{'map'} = $map;
	$map = $island->{'map'};

	# 로도했습니다생 데이터
 	my($land, $landValue) = readLand($map, @line);

	if($mode == 1) {
		island_save($island, $HsavedirName, 'save', 0);
	} elsif($mode == 3) {
		island_save($island, $HsavedirName, 'save', 1, $land, $landValue);
	}

	my(@loadland, @loadlandValue, @stack); # 로도하다 지형 데이터를 구성
	if($HoceanMode) {
		@loadland = @{$island->{'land'}};
		@loadlandValue = @{$island->{'landValue'}};
	}
	foreach $y (@{$map->{'y'}}) {
		foreach $x (@{$map->{'x'}}) {
			if(($mode> 1) && ($island->{'land'}[$x][$y] == $HlandNavy)) { # $island->{'land'} 지금의 지형(세부하다)
				if(($land->[$x][$y] == $HlandSea) || ($land->[$x][$y] == $HlandNavy)) {
					# 지금의 그대로
					$loadland[$x][$y] = $island->{'land'}[$x][$y];
					$loadlandValue[$x][$y] = $island->{'landValue'}[$x][$y];
				} else {
					# 일단로 도 지형
					$loadland[$x][$y] = $land->[$x][$y];
					$loadlandValue[$x][$y] = $landValue->[$x][$y];
					push(@stack, { 'x' => $x, 'y' => $y });
				}
			} elsif(($mode> 1) && ($land->[$x][$y] == $HlandNavy)) {
				if($island->{'land'}[$x][$y] == $HlandNavy) {
					# 지금의 그대로
					$loadland[$x][$y] = $island->{'land'}[$x][$y];
					$loadlandValue[$x][$y] = $island->{'landValue'}[$x][$y];
				} else {
					my $nSea = (navyUnpack($landValue->[$x][$y]))[3];
					$loadland[$x][$y] = $HlandSea;
					$loadlandValue[$x][$y] = $nSea;
				}
			} elsif((@stack> 0) && (($land->[$x][$y] == $HlandSea) || ($land->[$x][$y] == $HlandNavy))) {
				my $point = shift(@stack);
				$loadland[$x][$y] = $island->{'land'}[$point->{'x'}][$point->{'y'}];
				$loadlandValue[$x][$y] = $island->{'landValue'}[$point->{'x'}][$point->{'y'}];
			} else {
				$loadland[$x][$y] = $land->[$x][$y];
				$loadlandValue[$x][$y] = $landValue->[$x][$y];
			}
		}
	}
	# 스타쿠 지형이 있다면도한 번루프
	if(@stack> 0) {
		foreach $y (@{$map->{'y'}}) {
			last if(!@stack);
			foreach $x (@{$map->{'x'}}) {
				last if(!@stack);
				if(($land->[$x][$y] == $HlandSea) || ($land->[$x][$y] == $HlandNavy)) {
					my $point = shift(@stack);
					$loadland[$x][$y] = $island->{'land'}[$point->{'x'}][$point->{'y'}];
					$loadlandValue[$x][$y] = $island->{'landValue'}[$point->{'x'}][$point->{'y'}];
				}
			}
		}
	}

	$island->{'money'} = $money; #자금
	$island->{'food'} = $food; # 식량
	$island->{'map'} = $map; # 지도
	$island->{'land'} = \@loadland;
	$island->{'landValue'} = \@loadlandValue;

	if($mode>= 0) {
		foreach $i (0..$islandNumber) {
			undef $Hislands[$i]->{'fkind'};
		}
		foreach $i (0..$islandNumber) {
			estimateNavy($i);
		}
		writeIslandsFile(-2);
	}
}

#----------------------------------------------------------------------
# 동맹 데이터입출력
#----------------------------------------------------------------------
# 동맹 데이터 읽기
sub readAllyFile {
	# 데이터 파일 열기
	if(!open(IN, "${HdirName}/${HallyData}")) {
		rename("${HdirName}/ally.tmp", "${HdirName}/${HallyData}");
		if(!open(IN, "${HdirName}/${HallyData}")) {
			return 0;
		}
	}

	# 동맹읽기
	my($i);
	$HallyNumber = int(<IN>); # 동맹의 총 수
	for ($i = 0; $i < $HallyNumber; $i++) {
		$Hally[$i] = readAlly();
		$HidToAllyNumber{$Hally[$i]->{'id'}} = $i;
	}
	# 가입한 동맹의 ID를 저장
	for ($i = 0; $i < $HallyNumber; $i++) {
		my $member = $Hally[$i]->{'memberId'};
		foreach (@$member) {
			my $n = $HidToNumber{$_};
			next unless(defined $n);
			push(@{$Hislands[$n]->{'allyId'}}, $Hally[$i]->{'id'});
		}
	}

	# 파일을 닫기
	close(IN);

	return 1;
}

# 동맹하나읽기
sub readAlly {
	my($name, $mark, $color, $id, $ownerName, $password, $jpass, $score, $number,
		$occupation, $tmp, @allymember, @ext, $comment, $title, $message, @veto, $vkind);
	chomp($name = <IN>); # 동맹 이름
	chomp($mark = <IN>); # 동맹의 식별 표시
	chomp($color = <IN>); # 식별 표시의 색
	$id = int<IN>; # 동맹 ID(주 행사자의 것와 함께)
	chomp($ownerName = <IN>); # 주 행사자의 섬 이름
	chomp($password = <IN>); # 비밀번호(주 행사자의 것과 동일)
	chomp($jpass = <IN>); # 비밀번호(Takayan 의 jpass:턴 갱신 시 치환용)
	$score = int(<IN>); # 동맹의 스코어
	$number = int(<IN>); # 동맹에 소속된 섬의 수
	$occupation = int(<IN>); # 점유율
	chomp($tmp = <IN>); # 동맹 소속 섬 ID
	@allymember = split(/\,/,$tmp);
	chomp($tmp = <IN>); # 확장 영역
	@ext = split(/\,/,$tmp);
	#$name = $HwinnerMark. $name if($ext[5]);
	chomp($comment = <IN>); # 코멘트
	chomp(($title, $message) = split('<>', <IN>)); # 제목, 메시지
	chomp($tmp = <IN>); # 거부 ID
	@veto = split(/\,/,$tmp);
	$vkind = shift @veto;
	<IN>; # 예비
	<IN>; # 예비

	# 진영 형태로 반환
	return {
		'name' => $name,
		'mark' => $mark,
		'color' => $color,
		'id' => $id,
		'oName' => $ownerName,
		'password' => $password,
		'Takayan' => $jpass,
		'score' => $score,
		'number' => $number,
		'occupation' => $occupation,
		'memberId' => \@allymember,
		'ext' => \@ext,
		'comment' => $comment,
		'title' => $title,
		'message' => $message,
		'vetoId' => \@veto,
		'vkind' => $vkind,
	};
}

# 동맹 데이터 쓰기
sub writeAllyFile {
	# 파일을 열기
	open(OUT, ">${HdirName}/ally.tmp");

	# 진영 데이터의 쓰기
	print OUT "$HallyNumber\n";
	for($i = 0; $i < $HallyNumber; $i++) {
		writeAlly($Hally[$i]);
	}
	# 파일을 닫기
	close(OUT);

	# 원래 이름으로
	unlink("${HdirName}/${HallyData}");
	rename("${HdirName}/ally.tmp", "${HdirName}/${HallyData}");
}

# 동맹하나쓰기
sub writeAlly {
	my($ally) = @_;
	print OUT $ally->{'name'}. "\n";
	print OUT $ally->{'mark'}. "\n";
	print OUT $ally->{'color'}. "\n";
	print OUT $ally->{'id'}. "\n";
	print OUT $ally->{'oName'}. "\n";
	print OUT $ally->{'password'}. "\n";
	print OUT $ally->{'Takayan'}. "\n";
	print OUT $ally->{'score'}. "\n";
	print OUT $ally->{'number'}. "\n";
	print OUT $ally->{'occupation'}. "\n";
	my $memId = $ally->{'memberId'};
	print OUT join(',', @$memId). "\n";
	#확장 영역
	my $ext = $ally->{'ext'};
	print OUT join(',', @$ext). "\n";
	print OUT $ally->{'comment'}. "\n";
	print OUT $ally->{'title'}. '<>'. $ally->{'message'}. "\n";
	my @vetoId = @{$ally->{'vetoId'}};
	unshift(@vetoId, $ally->{'vkind'});
	print OUT join(',', @vetoId). "\n";
	print OUT "\n";
	print OUT "\n";
}

# [a-zA-Z]로 구성된 8문자의 비밀번호를 만들기
sub makeRandomString {
	my($baseString) = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	my($baseLen) = length($baseString);
	my($i, $passward);

	foreach $i (1..8) {
		$passward.= substr($baseString, rand($baseLen), 1);
	}

	return $passward;
}

# 동맹의 점유율의 계산
sub allyOccupy {
	my($i);
	my($totalScore) = 0;
	return if(!$HallyNumber);

	for ($i = 0; $i < $HallyNumber; $i++) {
		$totalScore += $Hally[$i]->{'score'};
	}
	for ($i = 0; $i < $HallyNumber; $i++) {
		if ($totalScore != 0) {
			$Hally[$i]->{'occupation'} = int($Hally[$i]->{'score'} / $totalScore * 100);
		} else {
			$Hally[$i]->{'occupation'} = int(100 / $HallyNumber);
		}
	}
	return;
}

# 섬 포기 시 동맹 관련 처리
sub islandDeadAlly {
	my($island, $id, $name) = @_;

	$id = $island->{'id'} if($id eq '');
	$name = $island->{'name'}. $AfterName if($name eq '');
	my $n = $HidToAllyNumber{$id};
	if(($HarmisticeTurn && $HcampDeleteRule && ($HautoKeeper != 1)) || (defined $n)) {
		if(($HarmisticeTurn && $HcampDeleteRule && ($HautoKeeper != 1)) ||
			(!$HarmisticeTurn && $HallyAutoBreakup) ||
			($Hally[$n]->{'number'} == 1)) {
			make_pastlog($id, $name) if($HallyAutoBreakup == 2);
			$Hally[$n]->{'dead'} = 1;
			undef $island->{'allyId'};
			$HidToAllyNumber{$id} = undef;
			$HallyNumber--;
			allySort();
		}
	} else {
		make_pastlog($id, $name) if($HallyAutoBreakup == 2);
		foreach (@{$island->{'allyId'}}) {
			my $i = $HidToAllyNumber{$_};
			my $allyMember = $Hally[$i]->{'memberId'};
			my @newAllyMember = ();
			foreach (@$allyMember) {
				if(!(defined $HidToNumber{$_})) {
				} elsif($_ == $id) {
					$Hally[$i]->{'score'} -= $island->{$HrankKind} if(!$island->{'predelete'});
					$Hally[$i]->{'number'} -= 1;
				} else {
					push(@newAllyMember, $_);
				}
			}
			$Hally[$i]->{'memberId'} = \@newAllyMember;
		}
		undef $island->{'allyId'};
	}
}

#----------------------------------------
# 과거 로그 처리(YY-BBS)
#----------------------------------------
sub make_pastlog {
	my($id, $name) = @_;
	# 로그 파일
	my $logfile = "${HbbsdirName}/${id}$Hlogfile_name";
	return if !(-f $logfile);
	open(IN,"$logfile") || die $!;
	my $top = <IN>;
	close(IN);
	my $allyName = (split(/<>/, $top))[3];
	$allyName =~ s/작전회의 실//;
	my $logfileNew = "${HbbsdirName}/${id}-${HislandTurn}$Hlogfile_name";
#	return if !(-f $logfile);
	rename($logfile, $logfileNew);
	# 맹주 로그 파일
	my $logfile2 = "${HbbsdirName}/${id}$Hlogfile2_name";
	my $logfile2New = "${HbbsdirName}/${id}-${HislandTurn}$Hlogfile2_name";
	return if !(-f $logfile2);
	rename($logfile2, $logfile2New);
	# 카운터 파일
	if($Hcounter) {
		my $cntfile = "${HbbsdirName}/${id}$Hcntfile_name";
		my $cntfileNew = "${HbbsdirName}/${id}-${HislandTurn}$Hcntfile_name";
		return if !(-f $cntfile);
		rename($cntfile, $cntfileNew);
	}
	# 과거 로그용 NO 파일
	if($Hpastkey) {
		my $nofile = "${HbbsdirName}/${id}$Hnofile_name";
		return if !(-f $nofile);
		# 과거 NO 을 열기
		open(NO,"$nofile") || die $!;
		my $count = <NO>;
		close(NO);
		my $nofileNew = "${HbbsdirName}/${id}-${HislandTurn}$Hnofile_name";
		rename($nofile, $nofileNew);
		foreach (1..$count) {
			my $pastfile = sprintf("%s/%04d\.%d\.cgi", $HpastdirName,$_,$id);
			my $pastfileNew = sprintf("%s/%04d\.%d-%d\.cgi", $HpastdirName,$_,$id,$HislandTurn);
			rename($pastfile, $pastfileNew);
		}
	}
	# 소멸했습니다 동맹의 데이터를 저장
	my(@lines);
	if(!open(IN, "${HbbsdirName}/dead${HallyData}")) {
		@lines = ();
	} else {
		@lines = <IN>;
		close(IN);
	}
	unshift(@lines, "${id}-${HislandTurn},$allyName,${name}\n");
	open(OUT, ">${HbbsdirName}/dead${HallyData}");
	print OUT @lines;
	close(OUT);

	return 1;
}

# 섬 이름을 반환
sub islandName {
	my($island) = @_;

	my($name);
#	$name = $HwinnerMark if($island->{'ext'}[0] || ($HitemComplete == $island->{'id'}));
#	if($HitemComplete == $island->{'id'}) {
#		$name = $HwinnerMark[0];
#	}
#	if($island->{'ext'}[0]) {
#		my $f = 2;
#		foreach (1..$#HwinnerMark) {
#			$name.= $HwinnerMark[$_] if($island->{'ext'}[0] & $f);
#			$f *= 2;
#		}
#	}
	foreach (@{$island->{'allyId'}}) {
		my $i = $HidToAllyNumber{$_};
		my $mark = $Hally[$i]->{'mark'};
		my $color = $Hally[$i]->{'color'};
		$name.= '<FONT COLOR="'. $color. '"><B>'. $mark. '</B></FONT>';
	}
	$name.= $island->{'name'}. $AfterName;

	return ($name);
}

# 지형의 호출분
sub landName {
	my($land, $lv) = @_;
	if(($land == $HlandSea) || ($land == $HlandWaste)) {
		return $HlandName[$land][$lv];
	} elsif($land == $HlandTown) {
		foreach (reverse(0..$#HlandTownValue)) {
			if($HlandTownValue[$_] <= $lv) {
				return $HlandTownName[$_];
			}
		}
	} elsif($land == $HlandDefence) {
		if($HdurableDef){
			$lv++;
			if($lv>= $HdefLevelUp) {
				return $HlandName[$land][1];
			}
		}
		return $HlandName[$land][0];
	} elsif($land == $HlandComplex) {
		# 복합 지형
		my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($lv);
		return $HcomplexName[$cKind];
	} elsif($land == $HlandMonster) {
		# 괴수
		my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
		my $mName = $HmonsterName[$mKind];
		my($name);
		$name = islandName($Hislands[$HidToNumber{$mId}]) if (defined $HidToNumber{$mId});
		$mName.= "(${name})" if (defined $name);
		return $mName;
	} elsif($land == $HlandHugeMonster) {
		# 거대괴수
		my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
		my $mName = $HhugeMonsterName[$mKind];
		my($name);
		$name = islandName($Hislands[$HidToNumber{$mId}]) if (defined $HidToNumber{$mId});
		$mName.= "(${name})" if (defined $name);
		return $mName;
	} elsif($land == $HlandNavy) {
		# 해군
		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		my $nName = $HnavyName[$nKind];
		$nName.= '의잔해' if($nFlag & 1);
		my($name);
		$name = islandName($Hislands[$HidToNumber{$nId}]) if (defined $HidToNumber{$nId});
		my $nSpecial = $HnavySpecial[$nKind];
		if(!($nSpecial & 0x8) && !($nFlag & 1)) {
			if(defined $HidToName{$nId}) {
				$nName.= "(${name})";
			} else {
				$nName.= "(소속 불명)";
			}
		}
		return $nName;
	} elsif($land == $HlandMountain) {
		my $mlv = ($lv> 0) ? 1 : 0;
		return $HlandName[$land][$mlv];
	} elsif($land == $HlandMonument) {
		return $HmonumentName[$lv];
	} elsif($land == $HlandCore) {
		my $lFlag = int($lv / 10000);
		return $HlandName[$land][$lFlag];
	} else {
		return $HlandName[$land];
	}
}

# 범위 안의 군항을 가까운 순서로 탐색하고 좌표를 반환. $range가 0인 경우 주변 12(20)헥스를 조사한 뒤 전체 섬을 조사.
sub searchNavyPort {
	my($island, $x, $y, $range) = @_;
	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};
	my($count, $sx, $sy, $i);
	$count = 0;
	if($range) {
		$range--;
	} else {
		$range = $an[$#an] - 1;
	}
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖의 경우
		next if(($sx < 0) || ($sy < 0) || ($HoceanMode && ($HlandID[$sx][$sy] != $island->{'id'})));

		if($land->[$sx][$sy] == $HlandNavy) {
			my($nId, $nKind) = (navyUnpack($landValue->[$sx][$sy]))[0, 7];
			my $nSpecial = $HnavySpecial[$nKind];
			if($nSpecial & 0x8) {
				$count = 1;
				last;
			}
		}
	}
	if(!$count && ($range == $an[$#an] - 1)) {
		foreach $i (0..$island->{'pnum'}) {
			$sx = $island->{'rpx'}[$i];
			$sy = $island->{'rpy'}[$i];
			next if($HoceanMode && ($HlandID[$sx][$sy] != $island->{'id'})); # 안전 확인용
			if($land->[$sx][$sy] == $HlandNavy) {
				my($nId, $nKind) = (navyUnpack($landValue->[$sx][$sy]))[0, 7];
				my $nSpecial = $HnavySpecial[$nKind];
				if($nSpecial & 0x8) {
					$count = 1;
					last;
				}
			}
		}
	}
	return ($count, $sx, $sy);
}

# 섬의 없음좌표를 무작위로반환
sub randomIslandMap {
	my($x, $y, @pos);

	for ($x = 0; $x < $HoceanSizeX; $x++) {
		for ($y = 0; $y < $HoceanSizeY; $y++) {
			next if($HoceanMap[$x][$y]);
			push(@pos, { 'x' => $x, 'y' => $y });
		}
	}

	return $pos[int(rand($#pos + 1))];
}

# 섬끼리의 연결를 조사하기메인
sub makeRen {
	# @correct 생성($correct[$sx + $#an])
	my(@ax) = (0..($HoceanSizeX - 1));
	my(@ay) = (0..($HoceanSizeY - 1));
	if($Hroundmode){
		@RcorrectX = ($ax[$#ax], @ax, $ax[0]);
		@RcorrectY = ($ay[$#ay], @ay, $ay[0]);
	} else {
		@RcorrectX = (-1, @ax, -1);
		@RcorrectY = (-1, @ay, -1);
	}
	my($x, $y);
	my $ren = -1;
	foreach $y (@ay) {
		foreach $x (@ax) {
			if($HoceanMap[$x][$y]) { # 섬이 있음
				my($num) = $HidToNumber{$HoceanMap[$x][$y]};
				if((defined $num) &&
					( # 미접속 섬
					$Hislands[$num]->{'predelete'} || # 관리자 보관
					$Hislands[$num]->{'rest'} || # 부전승
					($HfieldUnconnect && $Hislands[$num]->{'field'}) # 설정 시, 전장
					)
					) {
					$HislandConnect[$x][$y] = $ren--;
					next;
				}
			}
			$HislandConnect[$x][$y] = 0;
		}
	}
	$ren = 1;
	foreach $y (@ay) {
		foreach $x (@ax) {
			if(classRen($x, $y, $ren)) {
				$ren++;
			}
		}
	}

#foreach $y (@ay) {
#	foreach $x (@ax) {
#		HdebugOut("$HislandConnect[$x][$y](${\int($HoceanMap[$x][$y])}),");
#	}
#	HdebugOut("\n");
#}
}

# 섬끼리의 연결를 조사하기하위
sub classRen {
	my($x, $y, $ren) = @_;
	return if(!$HoceanMap[$x][$y]); # 미지의 해역
	return if($HislandConnect[$x][$y]); # 조사완료미
	$HislandConnect[$x][$y] = $ren;
	my($sx, $sy);
	my(@check) = ([-1, 0], [1, 0], [0, -1], [0, 1]); # 왼쪽, 오른쪽, 상, 하
	if(!($HislandSizeY % 2)) {
		push(@check, [-1, 1]); # 왼쪽 아래
		push(@check, [1, -1]); # 오른쪽 위
	} elsif(!($HoceanSizeY % 2)) {
		if($y % 2) {
			push(@check, [-1, -1]); # 왼쪽 위
			push(@check, [-1, 1]); # 왼쪽 아래
		} else {
			push(@check, [1, -1]); # 오른쪽 위
			push(@check, [1, 1]); # 오른쪽 아래
		}
	} else {
		if($y % 2) {
			push(@check, [-1, -1]); # 왼쪽 위
			push(@check, [-1, 1]) if($y < $HoceanSizeY - 1); # 왼쪽 아래
		} else {
			push(@check, [1, -1]) if($y); # 오른쪽 위
			push(@check, [1, 1]); # 오른쪽 아래
		}
	}
	foreach (@check) {
		$sx = $RcorrectX[$x + $_->[0] + 1];
		$sy = $RcorrectY[$y + $_->[1] + 1];
		next if (($sx < 0) || ($sy < 0));
		# 범위 안의 경우
		classRen($sx, $sy, $ren);
	}
	return 1;
}

# 바다의 연결를 조사하기메인
sub makeSeaRen {
	my($island, $map) = @_;
	my($land) = $island->{'land'};
	foreach $y (@{$map->{'y'}}) {
		foreach $x (@{$map->{'x'}}) {
			$island->{'seaconnect'}->[$x][$y] = 0;
		}
	}
	my $rensea = 1;
	my($x, $y);
	foreach $y (@{$map->{'y'}}) {
		foreach $x (@{$map->{'x'}}) {
			next if($island->{'seaconnect'}->[$x][$y]);
			if(classRen($land, $x, $y, $rensea)) {
				$rensea++;
			}
		}
	}
}

# 바다의 연결를 조사하기하위
sub classSeaRen {
	my($land, $x, $y, $rensea) = @_;
	return if($island->{'seaconnect'}->[$x][$y] || ($land->[$x][$y] != $HlandSea));
	$island->{'seaconnect'}->[$x][$y] = $rensea;
	my($sx, $sy);
	foreach (1..6) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		next if (($sx < 0) || ($sy < 0));
		# 범위 안의 경우
		classSeaRen($land, $sx, $sy, $rensea);
	}
	return 1;
}
#----------------------------------------------------------------------
# 지형 데이터
#----------------------------------------------------------------------
# 지형의 정보를 Unpack
sub landUnpack {
	my $lv = shift;

	# bit 의미
	#-----------
	# 8 예비
	# 5 종류
	# 9 턴 플래그
	# 6 식량 플래그
	# 6자금 플래그
	my $money = $lv & 0x3f; $lv>>= 6;
	my $food = $lv & 0x3f; $lv>>= 6;
	my $turn = $lv & 0x1ff; $lv>>= 9;
	my $kind = $lv & 0x1f; $lv>>= 5;
	my $tmp = $lv & 0xff;

	return ($tmp, $kind, $turn, $food, $money);
}

# 지형의 정보를 Pack
sub landPack {
	my($tmp, $kind, $turn, $food, $money) = @_;

	# bit 의미
	#-----------
	# 8 예비
	# 5 종류
	# 9 턴 플래그
	# 6 식량 플래그
	# 6자금 플래그
	my $lv = 0;
	$lv |= $tmp & 0xff; $lv <<= 5;
	$lv |= $kind & 0x1f; $lv <<= 9;
	$lv |= $turn & 0x1ff; $lv <<= 6;
	$lv |= $food & 0x3f; $lv <<= 6;
	$lv |= $money & 0x3f;

	return $lv;
}

# 괴수의 정보를 Unpack
sub monsterUnpack {
	my $lv = shift;

	# bit 의미
	#-----------
	# 8 섬 ID
	# 3 거대괴수플래그
	# 1 얕은 바다플래그
	# 8 경험치
	# 2 플래그
	# 5 종류
	# 5 내구력
	my $hp = $lv & 0x1f; $lv>>= 5;
	my $kind = $lv & 0x1f; $lv>>= 5;
	my $flag = $lv & 0x03; $lv>>= 2;
	my $exp = $lv & 0xff; $lv>>= 8;
	my $sea = $lv & 0x01; $lv>>= 1;
	my $hflag = $lv & 0x07; $lv>>= 3;
	my $id = $lv;

	return ($id, $hflag, $sea, $exp, $flag, $kind, $hp);
}

# 괴수의 정보를 Pack
sub monsterPack {
	my($id, $hflag, $sea, $exp, $flag, $kind, $hp) = @_;

	# bit 의미
	#-----------
	# 8 섬 ID
	# 3 거대괴수플래그
	# 1 얕은 바다플래그
	# 8 경험치
	# 2 플래그
	# 5 종류
	# 5 내구력
	my $lv = 0;
	$lv |= $id & 0xff; $lv <<= 3;
	$lv |= $hflag & 0x07; $lv <<= 1;
	$lv |= $sea & 0x01; $lv <<= 8;
	$lv |= $exp & 0xff; $lv <<= 2;
	$lv |= $flag & 0x03; $lv <<= 5;
	$lv |= $kind & 0x1f; $lv <<= 5;
	$lv |= $hp & 0x1f;

	return $lv;
}

# 해군의 정보를 Unpack
sub navyUnpack {
	my $lv = shift;

	# bit 의미
	#-----------
	# 7 섬 ID
	# 1 예비
	# 2 상태
	# 1 얕은 바다플래그
	# 8 경험치
	# 2 플래그
	# 2 함대번호
	# 5 종류
	# 4 내구력
	my $hp = $lv & 0x0f; $lv>>= 4;
	my $kind = $lv & 0x1f; $lv>>= 5;
	my $no = $lv & 0x03; $lv>>= 2;
	my $flag = $lv & 0x03; $lv>>= 2;
	my $exp = $lv & 0xff; $lv>>= 8;
	my $sea = $lv & 0x01; $lv>>= 1;
	my $stat = $lv & 0x03; $lv>>= 2;
	my $temp = $lv & 0x01; $lv>>= 1;
	my $id = $lv;

	return ($id, $temp, $stat, $sea, $exp, $flag, $no, $kind, $hp);
}

# 해군의 정보를 Pack
sub navyPack {
	my($id, $temp, $stat, $sea, $exp, $flag, $no, $kind, $hp) = @_;

	# bit 의미
	#-----------
	# 7 섬 ID
	# 1 예비
	# 2 상태
	# 1 얕은 바다플래그
	# 8 경험치
	# 2 플래그
	# 2 함대번호
	# 5 종류
	# 4 내구력
	my $lv = 0;
	$lv |= $id & 0x7f; $lv <<= 1;
	$lv |= $temp & 0x01; $lv <<= 2;
	$lv |= $stat & 0x03; $lv <<= 1;
	$lv |= $sea & 0x01; $lv <<= 8;
	$lv |= $exp & 0xff; $lv <<= 2;
	$lv |= $flag & 0x03; $lv <<= 2;
	$lv |= $no & 0x03; $lv <<= 5;
	$lv |= $kind & 0x1f; $lv <<= 4;
	$lv |= $hp & 0x0f;

	return $lv;
}

#----------------------------------------------------------------------
# 비밀번호 확인
#----------------------------------------------------------------------
sub checkPassword {
	my($island, $p2) = @_;
	my $p1 = $island->{'password'};

	# null 확인
	if($p2 eq '') {
		return 0;
	}

	# 마스터 비밀번호 확인
	if(checkMasterPassword($p2)) {
		return 2;
	}

	# 본래의 확인
	if($p1 eq encode($p2)) {
		return 1;
	}

	if($island->{'preab'} && ($HmainMode ne 'preab') && ($HpassChangeOK || ($HmainMode ne 'change'))) {
		my $ally = $Hally[$HidToAllyNumber{$island->{'allyId'}[0]}];
		if($ally->{'Takayan'} eq $p2) {
			$Hcodevelope = 1;
			return 1;
		}
	}
	return 0;
}

# 마스터 비밀번호의 확인
sub checkMasterPassword {
	my $pass = shift;
	return (crypt($pass, 'ma') eq $HmasterPassword);
}

# 특수 비밀번호의 확인
sub checkSpecialPassword {
	my $pass = shift;
	return (crypt($pass, 'sp') eq $HspecialPassword || crypt($pass, 'ma') eq $HmasterPassword);
}

# 비밀번호의 엔코드
sub encode {
	my $pass = shift;
	return ($cryptOn ? crypt($pass, 'h2') : $pass);
}

# 비밀번호 오류
sub tempWrongPassword {
	if($HinputPassword eq '') {
		tempWrong("<span class=\"big\"> 비밀번호를 잊으셨나요?</span>"); # 비밀번호 미입력
		axeslog(1, 'NoPass error!') if($HtopAxes && $HtopAxes != 3);
		return;
	}
	axeslog(1, 'PASS error!') if($HtopAxes && $HtopAxes != 3);
	out(<<END);
<SCRIPT Language="JavaScript">
<!--
function init(){
}
function SelectList(theForm){
}
//-->
</SCRIPT>
<span class="big"> 비밀번호가 다릅니다.
<A HREF=\"$HthisFile\">맨 위로 돌아가기</span></A>
END
	if($HpassError) {
		my $agent = $ENV{'HTTP_USER_AGENT'};
		my $addr = $ENV{'REMOTE_ADDR'};
		my $host = $ENV{'REMOTE_HOST'};
		if ($gethostbyaddr && (($host eq '') || ($host eq $addr))) {
			$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2) || $addr;
		} elsif($host eq '') {
			$host = $addr;
		}
		my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = gmtime(time + $Hjst);
		my $day = ('일','월','불','수','목','금','와 지')[$wday];
		$year = $year + 1900;
		$mon = $mon + 1;
		my $date = sprintf("%04d/%02d/%02d(%s) %02d:%02d:%02d",$year,$mon,$mday,$day,$hour,$min,$sec);
		out(<<END);
<HR>
<TABLE><TR><TH><span class="big">[${HtagDisaster_}!경고!${H_tagDisaster}]</span></TH></TR>
<TR><TD>당신의 정보를 기록했습니다.
 $date<BR><B>$host - $addr - $agent</B>
</TD></TR>
<TR><TD class='N'>
<BR><A HREF='http://www.ipa.go.jp/security/ciadr/law199908.html' target='_blank'><B>부정 접속 행위의 금지등에 관한법률</B></A>이2001년2월13일에시 행 진행되어했습니다.
<BR><BR>이 법률은 첨단 기술범죄를 방지하고 고도 정보통신 사회의 건전한 발전을 돕기 위해, 기존 형법으로 처벌하기 어려운 부정 접속 행위를 처벌 대상으로 삼는 법률입니다.
<BR><BR>형법에서는 명확한 피해가 발생하지 않으면 처벌하기 어려웠지만, 부정 접속금지법에서는,
${HtagDisaster_}부정 접속을 실행한 시점부터 처벌 대상이 됩니다.${H_tagDisaster}
<BR><BR>실제의 법률을 물기미분쇄있고설명하면,
'<A HREF='http://www.ipa.go.jp/security/ciadr/law199908.html#부정 접속 행위' target='_blank'><B>부정 접속</B></A>란,<B> 비밀번호 등으로 보호된 영역에, 권한이 없는 사람이 임의로 접속하는 것</B>이며,
이를 위반한 경우 '${HtagDisaster_}1년 이하의 징역 또는 50만 엔 이하의 벌금${H_tagDisaster}'이 부과될 수 있습니다.
<BR><BR>단순한 '비밀번호 입력 실수'라면 괜찮지만, 지나치게 빈번하면 <B>관리자로서 대응 조치를 취할 수밖에 없습니다.</B>
<BR><BR>${HtagTH_}반복해서 비밀번호 오류가 발생한 경우, 특별한 사유가 있다면, 아래의 '게시판' 또는 '메일' 링크로 연락해 주세요.${H_tagTH}
</TD></TR></TABLE>
END
	}
}

# ID 차이 or 로컬 설정 안 함 or 쿠키를 설정 안 함
sub tempWrong {
	my($str) = @_;

	out(<<END);
<SCRIPT Language="JavaScript">
<!--
function init(){
}
function SelectList(theForm){
}
//-->
</SCRIPT>
${HtagBig_}$str${H_tagBig}$HtempBack
END
}
#----------------------------------------------------------------------
# 접속 로그가져오기
#----------------------------------------------------------------------
sub axeslog {
	my($mode, $error) = @_;

	# '크로스 사이트 스크립팅 취약점' 대응
	# http://espion.s7.xrea.com/diary/20031027.html#p02 보다
	foreach (%ENV) {
		s/&(?!(?:amp|quot|lt|gt);)/&amp;/g;
		s/"/&quot;/g; #"
		s/'/&#x27;/g; #'
		s/ /&#32;/g;
		s/</&lt;/g;
		s/>/&gt;/g;
	}

	my($agent, $addr, $host, $referer);
	$agent = $ENV{'HTTP_USER_AGENT'};
	$addr = $ENV{'REMOTE_ADDR'};
	$host = $ENV{'REMOTE_HOST'};
	$referer = $ENV{'HTTP_REFERER'} if(!$mode);
	if (($host eq $addr) || ($host eq '')) {
		$host = gethostbyaddr(pack('C4',split(/\./,$addr)),2) || $addr;
	}
	my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = gmtime(time + $Hjst);
	my $day = ('일','월','불','수','목','금','와 지')[$wday];
	$year = $year + 1900;
	$mon = $mon + 1;
	my $date = sprintf("%04d/%02d/%02d(%s) %02d:%02d:%02d",$year,$mon,$mday,$day,$hour,$min,$sec);
	my($pcheck);
	if($proxycheck) {
		my @proxy_env = (
			'HTTP_CACHE_CONTROL', # FORM 전송 시 no_cache 이 됨처럼(·_·?
			'HTTP_CACHE_INFO',
			'HTTP_CLIENT_IP',
			'HTTP_FORWARDED',
			'HTTP_FROM',
			'HTTP_PROXY_CONNECTION',
			'HTTP_SP_HOST',
			'HTTP_VIA',
			'HTTP_X_FORWARDED_FOR',
			'HTTP_XONNECTION',
			'HTTP_XROXY_CONNECTION',
		);
		$pcheck = $ENV{'HTTP_CONNECTION'};
		foreach (@proxy_env){
			$pcheck.= '<>'. $ENV{$_};
		}
	}

	open(IN, "$HaxesLogfile");
	my @lines = <IN>;
	close(IN);

	while ($HaxesMax <= @lines) { pop @lines; }
	my $id;
	if($mode) {
		$id = ($defaultID eq $HcurrentID) ? $defaultID : "$defaultID=>$HcurrentID";
	} else {
		$id = $defaultID;
	}
	my($pass);
	$pass = $HinputPassword if(($error =~ /error/) || ($HtopAxes> 4));
	unshift(@lines, "[$date] - $referer - $host - $addr - $agent - $id - $pass - $error - $pcheck\n");

	if(open(OUT, ">$HaxesLogfile")){
		foreach $line (@lines) {
#			print OUT $line; # 문자 변환 라이브러리 사용 시
			print OUT $line;
		}
		close(OUT);
	} else {
		tempProblem();
		return;
	}
}
#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# 표준 출력으로 출력
sub out {
# UTF-8 환경에서는 별도 문자 변환 출력이 필요 없습니다
	print STDOUT $_[0];
}

# 디버그 로그
sub HdebugOut {
	if($Hdebug) {
		open(DOUT, ">>debug.log");
		print DOUT ($_[0]);
		close(DOUT);
	}
}

# 시간의 가져오기
sub timeToString {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime($_[0] + $Hjst);
	$mon++;
	$year += 1900;
	my $timestring = sprintf("%04d년 %02d월 %02d일 %02d 시", $year, $mon, $date, $hour);
	$timestring.= sprintf(" %02d분", $min) if($min || $sec);
	$timestring.= sprintf(" %02d초", $sec) if($sec);

#	return "${year}년 ${mon}월 ${date}일 ${hour}시 ${min}분 ${sec}초";
	return $timestring;
}

# 이스케이프문자의 처리
sub htmlEscape {
	my($s, $mode) = @_;
	$s =~ s/&/&amp;/g;
	$s =~ s/</&lt;/g;
	$s =~ s/>/&gt;/g;
	$s =~ s/"/&quot;/g; #"
	$s =~ s/'/&#x27;/g; #'
	$s =~ s/ /&#32;/g;
	$s =~ s/\,/&#44;/g;
	if ($mode) {
		$s =~ s/\r\n/<br>/g;
		$s =~ s/\r/<br>/g;
		$s =~ s/\n/<br>/g;
		$s =~ s/(<br>){5,}//g; # 대량 줄바꿈대책
	}
	return $s;
}

#----------------------------------------------------------------------
# cookie
#----------------------------------------------------------------------
# cookie 입력
sub cookieInput {
	# 바다전쟁쿠키
	local($key, $val, *cook);

	# 쿠키가져오기
	$cook = $ENV{'HTTP_COOKIE'};

	# 해당 ID 을꺼내기
	foreach ( split(/;/, $cook) ) {
		($key, $val) = split(/=/);
		$key =~ s/\s//g;
		$cook{$key} = $val;
	}

	# 데이터를 URL 데코드하고복원
	@cook=();
	foreach ( split(/<>/, $cook{'KAISEN_JS'}) ) {
#		s/%([0-9A-Fa-f][0-9A-Fa-f])/pack("C", hex($1))/eg;
		s/%([0-9A-Fa-f][0-9A-Fa-f])/pack("H2", $1)/eg;
		push(@cook,$_);
	}
	(
		$defaultID,
		$HdefaultPassword,
		$defaultTarget,
		$HdefaultName,
		$HdefaultX,
		$HdefaultY,
		$HdefaultKind,
		$HjavaModeSet,
		$HimgLine,
		$HskinName,
		$defaultChipSize
	)
		= @cook;
}

# cookie 출력
sub cookieOutput {
	my($cookie, $gmt, $cook, @t, @m, @w);

	@t = gmtime(time + 14 *24*60*60); # 기한14일
	@m = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	@w = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');

	# 국제표준 시를 정의
	$gmt = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$w[$t[6]], $t[3], $m[$t[4]], $t[5]+1900, $t[2], $t[1], $t[0]);

	# 바다전쟁쿠키
	$cookie = 'Set-Cookie: KAISEN_JS=';

	my @data =
	(
		(($HmainMode eq 'owner') && !$Hcodevelope) ? $HcurrentID : $defaultID,
		($HinputPassword ne '') ? $HinputPassword : $HdefaultPassword,
		$defaultTarget,
		$HdefaultName,
		$HdefaultX,
		$HdefaultY,
		$HdefaultKind,
		($HjavaMode ne '') ? $HjavaMode : $HjavaModeSet,
		$HimgLine,
		$HskinName,
		(!$defaultChipSize) ? $HchipSize : $defaultChipSize
	);

	# 저장 데이터를 URL 엔코드
	foreach (@data) {
		s/(\W)/sprintf("%%%02X", unpack("C", $1))/eg;
		$cookie.= "$_<>";
	}

	out("$cookie; expires=$gmt\n");
}

1;
