#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.
# perl5용입니다.

# 바다전쟁 JS.(based on ver1.3) patchworked by neo_otacky
# The Return of Neptune: http://no-one.s53.xrea.com/
# 개조 시 비표시로 해도 상관없지만 가능하면 변경하지 마세요.
my $versionInfo = "version7.15"; # JS 판원본의 버전.
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 메인 스크립트(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 모형정원 제도 2nd
#								 v1.5
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							 모형정원 모형정원 바다전쟁
#								 v1.3
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

BEGIN {
	# Perl 5.004 이상이필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}

# 초기 설정용 파일을 읽기(require 의 require 순서를 변경하면 안 됩니다!)
require './hako-init.cgi';
require './hako-io.cgi';
require './init-game.cgi';

#----------------------------------------------------------------------
# 아래는 필요에 따라 설정하는 항목입니다
#----------------------------------------------------------------------
# 이상종료 기준 시간
# (잠금 후 몇 초 뒤 강제 해제할지)
my($unlockTime) = 120;

#----------------------------------------------------------------------
# 필요에 따라 설정하는 항목은 여기까지입니다
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 변수
#----------------------------------------------------------------------
# COOKIE
# $defaultID; # 섬 이름
# $defaultTarget; # 대상의 이름

#----------------------------------------------------------------------
# 메인
#----------------------------------------------------------------------
# 접속제한
my $host = $ENV{'REMOTE_HOST'};
my $addr = $ENV{'REMOTE_ADDR'};
if ($gethostbyaddr && (($host eq '') || ($host eq $addr))) {
	$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2) || $addr;
}
if($host eq '') {
	$host = $addr;
}
my $flag = 0;
foreach (@Hdeny) {
	if (!$_) { next; }
	s/\*/\.\*/g;
	if ($host =~ /$_/i || $addr =~ /$_/i) { $flag=1; last; }
}
if ($flag) {
	if($HdenyLocation ne '') {
		print "Location: $HdenyLocation\n\n";
		exit;
	} else {
		tempHeader();
		tempWrong("접속이 허가되어 있지 않습니다");
		tempFooter();
		exit(0);
	}
}

# '돌아가기'링크
$HtempBack = "<A HREF=\"$HthisFile\">${HtagBig_}맨 위로 돌아가기${H_tagBig}</A>";

my $agent=$ENV{'HTTP_USER_AGENT'};
if($agent =~ /(DoCoMo|J-PHONE|UP\.Browser|DDIPOCKET|ASTEL|PDXGW)/i) {
 # 휴대 단말
 $Hmobile = 1;
}

# 잠금을 끼치기
if(!hakolock()) {
	# 잠금실패
	# 헤더출력
	tempHeader();

	# 잠금실패 메시지
	tempLockFail();

	# 푸터출력
	tempFooter();

	# 종료
	exit(0);
}

# 난수의 초기화
srand(time() ^ ($$ + ($$ << 15)));

if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	chomp($HspecialPassword = <PIN>); # 특수 비밀번호를 읽기
	close(PIN);
} else {
	unlock();
	tempHeader();
	tempNoHpasswordFile();
	tempFooter();
	exit(0);
}

# COOKIE 읽기
cookieInput();
$HchipSize = 16 if(!$HchipSize);

# CGI 읽기
cgiInput();

# 관리 모드
if(-e "./mente_lock") {
	if(!checkSpecialPassword($HdefaultPassword) && !checkSpecialPassword($HcampPassword)) {
		unlock();
		mente_mode()
	}
}

# 섬 데이터 읽기
if(!readIslandsFile($HcurrentID)) {
	unlock();
	tempHeader();
	tempNoDataFile();
	tempFooter();
	exit(0);
}

if($Hmobile) {
	require('hako-mobile.cgi');
	exit(0);
}

# 서바이벌 모드 턴 소비판정
if($HsurvivalTurn && ($HislandTurn>= $HsurvivalTurn)){
	foreach (
			$HcomReclaim,$HcomDestroy,$HcomPlant,$HcomFarm,$HcomFactory,$HcomMountain,
			$HcomMonument,$HcomDbase,$HcomBase,$HcomSbase,$HcomBouha,$HcomSeaMine,
			$HcomNavyWreckRepair,$HcomNavyWreckSell,@HcomNavy #,$HcomHaribote # 턴 소비용에가짜 시설(^^;
		) {
		$HcomTurn[$_] = 0;
	}
}

# COOKIE를 이용한 ID 확인
if($HmainMode eq 'owner') {
	unless($ENV{'HTTP_COOKIE'}) {
		cookieOutput(); # COOKIE가 삭제되었는지 쓰기 확인
		next if($ENV{'HTTP_COOKIE'}); # 쓰기 OK
		# 쿠키를 유효로 하지 않음
		axeslog(1, 'cookie invalid') if($HtopAxes && $HtopAxes != 3);
		unlock();
		tempHeader();
		tempWrong("쿠키가 활성화되어 있는지 확인한 뒤 다시 시도해 주세요.");
		tempFooter();
		exit(0);
	}
	my($pcheck) = checkPassword($Hislands[$HidToNumber{$HcurrentID}],$HinputPassword);
	if(!$pcheck) {
		unlock();
		tempHeader();
		tempWrongPassword(); # 비밀번호 불일치
		tempFooter();
		exit(0);
	}
	if($checkID || $checkImg) {
		# id에서 섬을 가져옴
		my $free = 0;
		foreach (@freepass){
			$free += 1 if(($_ == $defaultID) || ($_ == $HcurrentID));
		}
		my($icheck) = !($checkID && ($HcurrentID != $defaultID) && $defaultID);
		my($lcheck) = !($checkImg && ($HimgLine eq '' || $HimgLine eq $HimageDir));
		# 비밀번호
		if(($pcheck != 2) && ($free != 2) && ((!$icheck && !$Hcodevelope) || !$lcheck)) {
			# 1개의 섬을 초보자용으로 개방할 때 등에는 ($free != 2) 부분을 !$free 에 변경해 주세요.
			unlock();
			tempHeader();
			if(!$icheck) {
				axeslog(1, 'ID error!') if($HtopAxes && $HtopAxes != 3);
				tempWrong("자신의 섬 이외에는 들어갈 수 없습니다!"); # ID 차이
			} else {
				axeslog(1, 'image invalid') if($HtopAxes && $HtopAxes != 3);
				tempWrong("'이미지 경로 설정'을해 주세요."); # 로컬 설정 안 함
			}
			tempFooter();
			exit(0);
		}
	}
	# 접속·로그
	if($HtopAxes && ($HcurrentID != $defaultID)) {
		axeslog(1, 'ID differ!');
	} elsif(($HtopAxes == 2) || ($HtopAxes> 3)) {
		axeslog(1);
	}

# 템플릿을 초기화
	tempInitialize(1);
} elsif(!checkMasterPassword($HinputPassword) && (($HmainMode eq '') || ($HmainMode eq 'top'))) {
	tempInitialize(0);
} else {
	tempInitialize(1);
}

# COOKIE 출력
cookieOutput() if($HmainMode ne 'setupv');

# 헤더출력
if($HmainMode eq 'owner' && $HjavaMode eq 'java' ||
	$HmainMode eq 'commandJava' || # 명령 입력 모드
	$HmainMode eq 'command2' || # 명령 입력 모드(ver1.1부터 추가·자동 입력용)
	$HmainMode eq 'comment' && $HjavaMode eq 'java' || # 코멘트입력 모드
	$HmainMode eq 'fleetname' && $HjavaMode eq 'java' || # 함대 이름 변경 모드
	$HmainMode eq 'priority' && $HjavaMode eq 'java' || # 색적 순서 변경 모드
	$HmainMode eq 'earth' && $HjavaMode eq 'java' || # 주변 표시 설정 모드
	$HmainMode eq 'comflag' && $HjavaMode eq 'java' || # 명령 실행 설정 모드
	$HmainMode eq 'preab' && $HjavaMode eq 'java' || # 진영공동개발 모드
	$HmainMode eq 'lbbs' && $HjavaMode eq 'java') { # 코멘트입력 모드

	$Body = $BodyJs;
	require('./hako-map.cgi');
	# 헤더출력
	tempHeaderJava();
	if($HmainMode eq 'commandJava') {
		# 개발 모드
		commandJavaMain();
	} elsif($HmainMode eq 'command2') {
		# 개발 모드2(자동 입력 명령용(ver1.1부터 추가))
		commandMain();
	} elsif($HmainMode eq 'comment') {
		# 코멘트입력 모드
		commentMain();
	} elsif($HmainMode eq 'fleetname') {
		# 함정 이름 변경 모드
		fleetnameMain();
	} elsif($HmainMode eq 'priority') {
		# 색적 순서 변경 모드
		priorityMain();
	} elsif($HmainMode eq 'earth') {
		# 주변 표시 설정 모드
		earthMain();
	} elsif($HmainMode eq 'comflag') {
		# 명령 실행 설정 모드
		comflagMain();
	} elsif($HmainMode eq 'preab') {
		# 진영공동개발 모드
		preabMain();
	} elsif($HmainMode eq 'lbbs') {
		# 로컬 게시판 모드
		require('./hako-lbbs.cgi');
		localBbsMain();
	}else{
		ownerMain();
	}
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
}elsif($HmainMode eq 'landmap'){
	require('./hako-map.cgi');
	# 헤더출력
	tempHeaderJava();
	# 관광 모드
	printIslandJava();
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
} elsif($HmainMode ne 'lbbs' && $HmainMode ne 'new' && $HmainMode ne 'download'){
	# 헤더출력
	tempHeader();
}

if($HmainMode eq 'turn') {
	# 턴진행
	require('./hako-turn.cgi');
	require('./hako-top.cgi');
	turnMain();

} elsif($HmainMode eq 'new') {
	# 섬 신규 생성
	require('./hako-make.cgi');
	require('./hako-map.cgi');
	newIslandMain(0);

} elsif($HmainMode eq 'newally') {
	# 동맹의 신규 작성
	require('./hako-make.cgi');
	require('./hako-top.cgi');
	makeAllyMain();

} elsif($HmainMode eq 'delally') {
	# 동맹의 삭제
	require('./hako-make.cgi');
	require('./hako-top.cgi');
	deleteAllyMain();

} elsif($HmainMode eq 'inoutally') {
	# 동맹의 가입·탈퇴
	require('./hako-make.cgi');
	require('./hako-top.cgi');
	joinAllyMain();

} elsif($HmainMode eq 'allypact') {
	# 맹주코멘트 모드
	require('./hako-make.cgi');
	allyPactMain();

} elsif($HmainMode eq 'print') {
	# 관광 모드
	require('./hako-map.cgi');
	printIslandMain();

} elsif($HmainMode eq 'oceanmap') {
	# 해역 지도 모드
	require('hako-map.cgi');
	printIslandMapMain();

} elsif($HmainMode eq 'owner') {
	# 개발 모드
	require('./hako-map.cgi');
	ownerMain();

} elsif($HmainMode eq 'command') {
	# 명령 입력 모드
	require('./hako-map.cgi');
	commandMain();

} elsif($HmainMode eq 'comment') {
	# 코멘트입력 모드
	require('./hako-map.cgi');
	commentMain();

} elsif($HmainMode eq 'fleetname') {
	# 함정 이름 변경 모드
	require('./hako-map.cgi');
	fleetnameMain();

} elsif($HmainMode eq 'priority') {
	# 색적 순서 변경 모드
	require('./hako-map.cgi');
	priorityMain();

} elsif($HmainMode eq 'earth') {
	# 주변 표시 설정 모드
	require('./hako-map.cgi');
	earthMain();

} elsif($HmainMode eq 'comflag') {
	# 명령 실행 설정 모드
	require('./hako-map.cgi');
	comflagMain();

} elsif($HmainMode eq 'preab') {
	# 진영공동개발 모드
	require('./hako-map.cgi');
	preabMain();

} elsif($HmainMode eq 'lbbs') {
	# 로컬 게시판 모드
	require('./hako-map.cgi');
	require('./hako-lbbs.cgi');
	localBbsMain();

} elsif($HmainMode eq 'change') {
	# 정보 변경 모드
	require('./hako-make.cgi');
	changeMain();

} elsif($HmainMode eq 'FightIsland') {
	# 토너먼트 패자의 섬 표시
	require('hako-map.cgi');
	fightMap($HadminMode);

} elsif($HmainMode eq 'FightView') {
	# 토너먼트 LOG 모드
	require('hako-table.cgi');
	FightViewMain();

} elsif($HmainMode eq 'TimeTable') {
	# 토너먼트 타이무테이블
	require('hako-table.cgi');
	TimeTableMain();

} elsif($HmainMode eq 'camp') {
	# 진영 모드
	require('./hako-map.cgi');
	require('./hako-camp.cgi');
	campMain();

} elsif($HmainMode eq 'join') {
	# 새 섬을 탐색
	require('./hako-make.cgi');
	require('./hako-map.cgi');
	newIslandTop();

} elsif($HmainMode eq 'rename') {
	# 정보 변경
	require('./hako-make.cgi');
	renameIslandMain();

} elsif($HmainMode eq 'joinally') {
	# 동맹 설정
	require('./hako-make.cgi');
	newAllyTop();

} elsif($HmainMode eq 'localimg') {
	# 이미지 경로 설정
	require('./hako-limg.cgi');
	localImgMain();

} elsif($HmainMode eq 'hakoskin') {
	# 스킨 설정
	require('./hako-skin.cgi');
	hakoSkinMain();

} elsif($HmainMode eq 'rank') {
	# 순위
	require('./hako-rank.cgi');
	rankIslandMain();

} elsif($HmainMode eq 'rekidai') {
	# 역대기록
	require('./hako-reki.cgi');
	rankingReki();

} elsif($HmainMode eq 'aoa') {
	# 동맹내의 우호국 설정
	require('./hako-top.cgi');
	amityOfAlly();

} elsif($HmainMode eq 'amity') {
	# 우호국 설정 목록
	require('./hako-table.cgi');
	amityInfo();

} elsif($HmainMode eq 'item') {
	#아이템 획득 현황
	require('./hako-table.cgi');
	ItemInfo();

} elsif($HmainMode eq 'fleet') {
	# 함정 보유 현황
	require('./hako-table.cgi');
	fleetInfo();

} elsif($HmainMode eq 'mfleet') {
	# 함대강제 이동 모드
	require('./hako-admin.cgi');
	moveFleetAdmin();

} elsif($HmainMode eq 'bfield') {
	# BattleField 작성 모드
	require('./hako-make.cgi');
	bfieldMain();

} elsif($HmainMode eq 'esetup') {
	# 이벤트 설정 모드
	require('./hako-admin.cgi');
	setupEvent();

} elsif($HmainMode eq 'download') {
	# 저장 데이터다운로드 모드
	require('./hako-admin.cgi');
	dataDownload($HadminMode);

} elsif($HmainMode eq 'vlose') {
	# 저장 데이터 목록 모드
	require('./hako-admin.cgi');
	loseIslandAdminTop();

} elsif($HmainMode eq 'reload') {
	# 저장 데이터복원 모드
	require('./hako-map.cgi');
	fightMap($HadminMode);

} elsif($HmainMode eq 'delete') {
	# 저장 데이터 삭제 모드
	require('./hako-admin.cgi');
	dataDelete($HadminMode);

} elsif($HmainMode eq 'present') {
	# 관리자 선물 지급 모드
	require('./hako-admin.cgi');
	presentMain();

} elsif($HmainMode eq 'punish') {
	# 관리자가 수행하는 제재 모드
	require('./hako-admin.cgi');
	punishMain();

} elsif($HmainMode eq 'lchange') {
	# 관리자가 수행하는 지형 변경 모드
	require('./hako-admin.cgi');
	lchangeMain();

} elsif($HmainMode eq 'predelete') {
	# 관리자가 수행하는 보관 모드
	require('./hako-admin.cgi');
	preDeleteMain();

} elsif($HmainMode eq 'asetup') {
	# 우호국 설정 확인 모드
	require('./hako-admin.cgi');
	amitySetupMain();

} elsif($HmainMode eq 'wsetup') {
	# 선전포고 확인 모드
	require('./hako-admin.cgi');
	dewarSetupMain();

} elsif($HmainMode eq 'isetup') {
	# 섬 데이터 수정 모드
	require('./hako-make.cgi');
	islandSetupMain();

} elsif($HmainMode eq 'isave') {
	# 지형 데이터 저장·복원 모드
	require('./hako-map.cgi');
	islandSaveMain();

} elsif($HmainMode eq 'icounter') {
	# 확장 데이터 카운터 설정 모드
	require('./hako-map.cgi');
	islandCounterMain();

} elsif($HmainMode eq 'setupv') {
	# 초기 설정 확인 모드
	require('./hako-table.cgi');
	setupValue();

} else {
	# 그 외에는 메인 페이지 모드
	require('./hako-top.cgi');
	topPageMain();
}

# 푸터출력
tempFooter();

# 종료
exit(0);

# 명령을 앞으로 당기기
sub slideFront {
	my($command, $number) = @_;
	my($i);

	# 각각밀기
	splice(@$command, $number, 1);

	# 마지막에자금 조달
	$command->[$HcommandMax - 1] = {
		'kind' => $HcomDoNothing,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0
	};
}

# 명령을 뒤로 밀기
sub slideBack {
	my($command, $number) = @_;
	my($i);

	# 각각밀기
	return if $number == $#$command;
	pop(@$command);
	splice(@$command, $number, 0, $command->[$number]);
}

#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------
# CGI 읽기
sub cgiInput {
	my($line, $getLine);

	# 입력을 받아 UTF-8로 처리
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9]{2})/pack(H2, $1)/eg;
#	 # 문자 변환 라이브러리 사용 시
#HdebugOut("$line\n");
	if($line !~ /Allypact=([^\&]*)\&/) {
#		$line =~ s/[\x00-\x1f\,]//g;
		$line =~ s/[\x00-\x1f]//g;
		$line =~ s/\,/,/g;
	} else {
# 맹주코멘트 모드
# 변경 버튼이 눌렸을 시 시작
		$HmainMode = 'allypact';
		$HdefaultPassword = htmlEscape($1);
		$line =~ /AllypactMode=([0-9]+)\&/;
		$HallyPactMode = $1 + 1;
		$line =~ /ISLANDID=([0-9]+)\&/;
		$HcurrentID = $1;
		if($HallyPactMode == 2) {
			while($line =~/VETOID=([0-9]*)\&/g) {
				push(@HvetoID, $1);
			}
			$line =~ /VETOKIND=([0-9]*)\&/;
			$HvetoKind = $1;
			$line =~ /ALLYCOMMENT=([^\&]*)\&/;
			$HallyComment = cutColumn($1, $HlengthAllyComment*2);
			$line =~ /ALLYTITLE=([^\&]*)\&/;
			$HallyTitle = cutColumn($1, $HlengthAllyTitle*2);
			$line =~ s/(.*)ALLYMESSAGE=//g;
			$HallyMessage = cutColumn($line, $HlengthAllyMessage*2);
		}
		return;
	}
	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};
#HdebugOut("$getLine\n");
	# 대상의 섬
	if($line =~ /ISLANDID=([0-9]+)\&/){
		$HcurrentID = $1;
	}

	# 비밀번호
	if($line =~ /OLDPASS=([^\&]*)\&/) {
		$HoldPassword = $HdefaultPassword = htmlEscape($1);
	}
	if($line =~ /PASSWORD=([^\&]*)\&/) {
		$HinputPassword = $HdefaultPassword = htmlEscape($1);
	}
	if($line =~ /PASSWORD2=([^\&]*)\&/) {
		$HinputPassword2 = htmlEscape($1);
	}

	# Java스크립트 모드
	if($line =~ /JAVAMODE=(cgi|java)/) {
		$HjavaMode = $1;
	} elsif($getLine =~ /JAVAMODE=(cgi|java)/) {
		$HjavaMode = $1;
	}

	# 비동기화통신플래그
	if($line =~ /async=true\&/) {
		$Hasync = 1;
	}

	# main mode 의가져오기
	if($line =~ /TurnButton/) {
		if(checkSpecialPassword($HdefaultPassword) && ($Hdebug == 1)) {
			$HmainMode = 'Hdebugturn';
		}
	} elsif($getLine =~ /Top=([^\&]*)/) {
		$HtopTemplateFile = $1;
		if($HtopTemplateFile !~ /.htm/) {
			$HtopTemplateFile = '';
		}
		$HmainMode = 'top';
	} elsif($line =~ /OwnerButton/) {
		if($HcurrentID) {
			$HmainMode = 'owner';
		}
	} elsif($line =~ /CommandJavaButton([0-9]+)=/ || $line =~ /CommandJavaButtonSub([0-9]+)=/) {
		# 명령 전송버튼의 경우(Java스크립트)
		$HcurrentID = $1;
		$HmainMode = 'commandJava';
		$line =~ /COMARY=([^\&]*)\&/;
		$HcommandComary = $1;
		$line =~ /COMMAND=([^\&]*)\&/;
		$HcommandKind = $1;
		$HdefaultKind = $1;
		$line =~ /AMOUNT=([^\&]*)\&/;
		$HcommandArg = $1;
		$line =~ /TARGETID=([^\&]*)\&/;
		$HcommandTarget = $1;
		$defaultTarget = $1;
		$line =~ /TARGETID2=([^\&]*)\&/;
		$HcommandTarget2 = $1;
		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		# 명령의 팝업 메뉴를 열기?
		if($line =~ /MENUOPEN=on/) {
			$HmenuOpen = 'CHECKED';
		} elsif($line =~ /MENUOPEN2=on/) {
			$HmenuOpen2 = 'CHECKED';
		} elsif($line =~ /MENUOPEN3=on/) {
			$HmenuOpen3 = 'CHECKED';
		}
	} elsif($line =~ /CommandButton([0-9]+)=/) {
		# 명령 전송버튼의 경우
		$HcurrentID = $1;
		if($HjavaMode eq 'java'){
			$HmainMode = 'command2';
		}else{
			$HmainMode = 'command';
		}

		# 명령 모드의 경우, 명령의 가져오기
		$line =~ /NUMBER=([^\&]*)\&/;
		$HcommandPlanNumber = $1;
		$line =~ /COMMAND=([^\&]*)\&/;
		$HcommandKind = $1;
		$HdefaultKind = $1;
		$line =~ /AMOUNT=([^\&]*)\&/;
		$HcommandArg = $1;
		$line =~ /TARGETID=([^\&]*)\&/;
		$HcommandTarget = $1;
		$defaultTarget = $1;
		$line =~ /TARGETID2=([^\&]*)\&/;
		$HcommandTarget2 = $1;
		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		if($line =~ /COMMANDMODE=(write|insert|delete)/) {
			$HcommandMode = $1;
		}
		# 명령의 팝업 메뉴를 열기?
		if($line =~ /MENUOPEN=on/) {
			$HmenuOpen = 'CHECKED';
		} elsif($line =~ /MENUOPEN2=on/) {
			$HmenuOpen2 = 'CHECKED';
		} elsif($line =~ /MENUOPEN3=on/) {
			$HmenuOpen3 = 'CHECKED';
		}
	} elsif($getLine =~ /Sight=([0-9]*)/) {
		$HmainMode = 'print';
		$HcurrentID = $1;
		# 관리자 모드
		if($getLine =~ /ADMINMODE=([0-9]*)/) {
			$HadminMode = 1;
			$HinputPassword = htmlEscape($1);
			$HdefaultPassword = $HinputPassword;
		}
	} elsif($getLine =~ /OceanMap=([0-9]*)/) {
		# 해역 지도 표시
		if($HuseOceanMap) {
			$HmainMode = 'oceanmap';
			$HcurrentID = $1;
		}
	} elsif($line =~ /LbbsButton(..)([0-9]*)/) {
		$HmainMode = 'lbbs';
		if($1 eq 'AD') {
			# 관리자
			$HlbbsMode = 7;
		} elsif($1 eq 'DA') {
			# 관리자 삭제
			$HlbbsMode = 9;
		} elsif($1 eq 'VA') {
			# 관리자열람 수 변경
			$HlbbsMode = 11;
		} elsif($1 eq 'OW') {
			# 섬주
			$HlbbsMode = 1;
		} elsif($1 eq 'DL') {
			# 섬주 삭제
			$HlbbsMode = 3;
		} elsif($1 eq 'VO') {
			# 섬주열람 수 변경
			$HlbbsMode = 5;
		} elsif($1 eq 'VS') {
			# 관광객열람 수 변경
			$HlbbsMode = 6;
		} elsif($1 eq 'DS') {
			# 관광객 삭제
			$HlbbsMode = 2;
		} elsif($1 eq 'CK') {
			# 관광객극비 확인
			$HlbbsMode = 4;
		} else {
			# 관광객
			$HlbbsMode = 0;
			$mode = 1;
		}
		$HcurrentID = $2;

		if($line =~ /LBBSNAME=([^\&]*)\&/) {
			$HlbbsName = cutColumn($1, $HlengthLbbsName*2);
			$HdefaultName = $HlbbsName;
		}
		if($line =~ /LBBSMESSAGE=([^\&]*)\&/) {
			my $lbbsMessage = $1;
			my $comment_length = $HlengthLbbsMessage * 2;
			if(($HlbbsAutolinkSymbol ne '') && ($lbbsMessage =~ /((http|ftp):\/\/([^\x81-\xFF\s\"\'\(\)\<\>\\\`\[\{\]\}\|]+))/ )) {
				my $matched_url = $1;
				$comment_length += length($matched_url) - 2;
			}
			$HlbbsMessage = cutColumn($lbbsMessage, $comment_length);
		}
		# 게시판의 발언 섬
		$line =~ /ISLANDID2=([0-9]+)\&/;
		$HspeakerID = $1;
		# 게시판의 통신형식
		$line =~ /LBBSTYPE=([^\&]*)\&/;
		$HlbbsType = $1;
		# 삭제할 수 없으므로 번호를 가져옴
		if($line =~ /NUMBER=([^\&]*)\&/) {
			$HcommandPlanNumber = $1;
		}
		# 열람 수가져오기
		if($line =~ /LBBSVIEW=([0-9]+)\&/) {
			$HlbbsView = $1;
		}
	} elsif($line =~ /ChangeInfoButton/) {
		$HmainMode = 'change';

		# 이름 지정의 경우
		if($line =~ /ISLANDNAME=([^\&]*)\&/){
			$HcurrentName = htmlEscape(cutColumn($1, $HlengthIslandName*2));
		}
		# 소유자 이름 가져오기
		if($line =~ /OWNERNAME=([^\&]*)\&/){
			$HcurrentOwnerName = htmlEscape(cutColumn($1, $HlengthOwnerName*2));
		}
	} elsif($line =~ /MessageButton([0-9]*)/) {
		$HmainMode = 'comment';
		$HcurrentID = $1;
		# 메시지
		if($line =~ /MESSAGE=([^\&]*)\&/){
			$Hmessage = cutColumn($1, $HlengthMessage*2);
		}
	} elsif($line =~ /FleetnameButton([0-9]*)/) {
		$HmainMode = 'fleetname';
		$HcurrentID = $1;
		# 함정 이름
		$line =~ /FLEET1=([^\&]*)\&FLEET2=([^\&]*)\&FLEET3=([^\&]*)\&FLEET4=([^\&]*)\&/;
		$HfleetName[0] = cutColumn($1, $HlengthFleetName*2);
		$HfleetName[1] = cutColumn($2, $HlengthFleetName*2);
		$HfleetName[2] = cutColumn($3, $HlengthFleetName*2);
		$HfleetName[3] = cutColumn($4, $HlengthFleetName*2);
	} elsif($line =~ /PriorityButton([0-9]*)/) {
		$HmainMode = 'priority';
		$HcurrentID = $1;
		# 색적 순서
		$line =~ /PSF=([0-9])\&PS0=([0-9])\&PS1=([0-9])\&PS2=([0-9])\&PS3=([0-9])\&PS4=([0-9])\&PS5=([0-9])\&PS6=([0-9])\&PS7=([0-9])\&/;
		$HfleetNumber = $1;
		$HfleetPriority = "$2-$3-$4-$5-$6-$7-$8-$9";
	} elsif($line =~ /EarthButton([0-9]*)/) {
		$HmainMode = 'earth';
		$HcurrentID = $1;
	} elsif($line =~ /ComflagButton([0-9]*)/) {
		$HmainMode = 'comflag';
		$HcurrentID = $1;
	} elsif($line =~ /PreabButton([0-9]*)/) {
		$HmainMode = 'preab';
		$HcurrentID = $1;
	} elsif($getLine =~ /View=([0-9]*)/) {
		$HmainMode = 'top';
		$HviewIslandNumber = $1;
	} elsif($getLine =~ /IslandMap=([0-9]*)/) {
		$HmainMode = 'landmap';
		$HcurrentID = $1;
		if($getLine =~ /MISSILEMODE=([0-9]*)/) {
			# 미사일착탄 지점
			$HmissileMode = $1;
		}
	} elsif($getLine =~ /JoinA=([^\&]*)/) {
		$HmainMode = 'joinally';
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /NewAllyButton/) {
		$HmainMode = 'newally';
		# 동맹 이름 가져오기
		if($line =~ /ALLYNUMBER=([0-9]*)\&/) {
			$HcurrentAnumber = $1;
		}
		if($line =~ /ALLYID=([0-9]*)\&/) {
			$HallyID = $1;
		}
		$line =~ /ALLYNAME=([^\&]*)\&/;
		$HallyName = htmlEscape(cutColumn($1, $HlengthAllyName*2));
		$line =~ /MARK=([^\&]*)\&/;
		$HallyMark = $1;
		$line =~ /COLOR1=([0-9A-F])\&COLOR2=([0-9A-F])\&COLOR3=([0-9A-F])\&COLOR4=([0-9A-F])\&COLOR5=([0-9A-F])\&COLOR6=([0-9A-F])\&/;
		$HallyColor = $1. $2. $3. $4. $5. $6;
	} elsif($line =~ /DeleteAllyButton/) {
		$HmainMode = 'delally';
		if($line =~ /ALLYID=([0-9]*)\&/) {
			$HallyID = $1;
		}
		$line =~ /ALLYNUMBER=([0-9]*)\&/;
		$HcurrentAnumber = $1;
	} elsif($line =~ /JoinAllyButton/) {
		$HmainMode = 'inoutally';
		$line =~ /ALLYNUMBER=([0-9]*)\&/;
		$HcurrentAnumber = $1;
	} elsif($getLine =~ /AmiOfAlly=([0-9]*)/) {
		$HmainMode = 'aoa';
		$HallyID = $1;
	} elsif($getLine =~ /Allypact=([^\&]*)/) {
		# 맹주코멘트 모드
		# 처음 시작
		$HmainMode = 'allypact';
		$HallyPactMode = 0;
		$HcurrentID = $1;

	} elsif($getLine =~ /Amity=([0-9]*)/) {
		$HmainMode = 'amity';
	} elsif($getLine =~ /Item=([0-9]*)/) {
		$HmainMode = 'item';
		$HitemNumber = $1;
	} elsif($getLine =~ /Fleet=([0-9]*)/) {
		$HmainMode = 'fleet';
		$HinfoMode = $1;
	} elsif ($line =~ /camp=([0-9]*)/) {
		$HmainMode = 'camp';
		$HcurrentCampID = $1;
		if($line =~ /jpass=([a-zA-Z0-9]*)/) {
			$HtakayanPassword = htmlEscape($1); # 진영 비밀번호
		}
		if($line =~ /cpass=([^\&]*)\&/) {
			$HcampPassword = htmlEscape($1);
		}
		if($line =~ /id=([0-9]*)/) {
			$HcurrentID = $1;
		}
	} elsif($getLine =~ /Rank=([0-9]*)/) {
		$HmainMode = 'rank';
	} elsif($getLine =~ /Rekidai=([0-9]*)/) {
		$HmainMode = 'rekidai';
	} elsif($getLine =~ /Rename=([0-9]*)/) {
		$HmainMode = 'rename';
	} elsif($getLine =~ /Limg=([0-9]*)/) {
		$HmainMode = 'localimg';
	} elsif($getLine =~ /Skin=([0-9]*)/) {
		$HmainMode = 'hakoskin';
	} elsif($getLine =~ /Join=([0-9]*)/) {
		# 누구나 새 섬을 탐색하게 함
		$HmainMode = ($HadminJoinOnly ? 'top' : 'join');
	} elsif($line =~ /Join=([0-9]*)/) {
		# 관리자만 새 섬을 탐색하게 함
		$HmainMode = ($HadminJoinOnly ? 'join' : 'top');
	} elsif($line =~ /NewIslandButton/) {
		$HmainMode = 'new';
		# 이름 가져오기
		$line =~ /ISLANDNAME=([^\&]*)\&/;
		$HcurrentName = htmlEscape(cutColumn($1, $HlengthIslandName*2));
		# 소유자 이름 가져오기
		$line =~ /OWNERNAME=([^\&]*)\&/;
		$HcurrentOwnerName = htmlEscape(cutColumn($1, $HlengthOwnerName*2));
		if($HarmisticeTurn && $HcampSelectRule == 2) {
			# 진영을 선택 가능이 경우
			if($line =~ /CAMPNUMBER=([\-]?[0-9]+)\&/) {
				$HcampNumber = $1;
			}
		}
		if($HoceanMode && $HoceanSelect) {
			# 좌표를 선택 가능이 경우
			if($line =~ /OCEANX=([^\&]*)\&/) {
				$HoceanMapX = $1;
			}
			if($line =~ /OCEANY=([^\&]*)\&/) {
				$HoceanMapY = $1;
			}
			if($line =~ /RANDOM=([0-9]*)\&/) {
				$HmapRandom = $1;
			}
		}

# 초기 설정 확인 모드
	} elsif($getLine =~ /SetupV=([^\&]*)/) {
		$HmainMode = 'setupv';
		$HdefaultPassword = htmlEscape($1);

# 토너먼트 모드
	} elsif($getLine =~ /LoseMap=([0-9]*)/) {
		$HmainMode = 'FightIsland';
		$HadminMode = 0;
		$HcurrentID = $1;
		if($getLine =~ /ADMINMODELOSE=([0-9]*)/) {
			$HadminMode = 2;
			$HinputPassword = htmlEscape($1);
			$HdefaultPassword = $HinputPassword;
		} elsif($getLine =~ /ADMINMODESAVE=([0-9]*)/) {
			$HadminMode = 1;
			$HinputPassword = htmlEscape($1);
			$HdefaultPassword = $HinputPassword;
		}
	} elsif($getLine =~ /FightLog/) {
		$HmainMode = 'FightView';
	} elsif($getLine =~ /TimeTable/) {
		$HmainMode = 'TimeTable';

# 우호국 설정 확인 모드
	} elsif($getLine =~ /ASetup=([^\&]*)/) {
		$HmainMode = 'asetup';
		$HasetupMode = 0;
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /ASetup=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 시 시작
		$HmainMode = 'asetup';
		$HasetupMode = 1;
		$HdefaultPassword = htmlEscape($1);
		while($line =~/amity=([^\&]*)\&/g) {
			push(@HamityChange, $1);
		}
		while($line =~/ally=([^\&]*)\&/g) {
			push(@HallyChange, $1);
		}

# 선전포고 확인 모드
	} elsif($getLine =~ /WSetup=([^\&]*)/) {
		$HmainMode = 'wsetup';
		$HwsetupMode = 0;
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /WSetup=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 시 시작
		$HmainMode = 'wsetup';
		$HwsetupMode = 1;
		$HdefaultPassword = htmlEscape($1);
		while($line =~/war=([0-9]*)\&/g) {
			push(@HdeWarChange, $1);
		}
		while($line =~/del=([0-9]*)\&/g) {
			$HdeWarDel{$1} = 1;
		}

# 섬 데이터 수정 모드
	} elsif($getLine =~ /ISetup=([^\&]*)/) {
		$HmainMode = 'isetup';
		$HisetupMode = 0;
		$HdefaultPassword = htmlEscape($1);
		if($getLine =~ /id=([0-9]*)/) {
			$HcurrentID = $1;
		}
	} elsif($line =~ /ISetup=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 시 시작
		$HmainMode = 'isetup';
		$HisetupMode = 1;
		$HdefaultPassword = htmlEscape($1);
		if($line =~ /IslandChange/) {
			$HisetupMode = 2;
			# 이름 가져오기
			$line =~ /ISLANDNAME=([^\&]*)\&/;
			$HcurrentName = cutColumn($1, $HlengthIslandName*2);
			# 소유자 이름 가져오기
			$line =~ /OWNERNAME=([^\&]*)\&/;
			$HcurrentOwnerName = cutColumn($1, $HlengthOwnerName*2);
			$line =~ /BIRTHDAY=([0-9]*)\&/;
			$Hbirthday = $1;
			$line =~ /ABSENT=([0-9]*)\&/;
			$Habsent = $1;
			if($line =~ /PREAB=([0-9]*)\&/) {
				$Hpreab = $1;
			}
			$line =~ /MONEY=([0-9]*)\&/;
			$Hmoney = $1;
			$line =~ /FOOD=([0-9]*)\&/;
			$Hfood = $1;
			$line =~ /GAIN=([0-9]*)\&/;
			$Hgain = $1;
			if($line =~ /FIELD=([0-9]*)\&/) {
				$Hfield = $1;
			}
			$line =~ /FIGHT_ID=([\-0-9]*)\&/;
			$Hfight_id = $1;
			$line =~ /REST=([0-9]*)\&/;
			$Hrest = $1;
			while($line =~/FLAGS=([0-9]*)\&/g) {
				push(@Hflags, $1);
			}
			while($line =~/MONSTERS=([0-9]*)\&/g) {
				push(@Hmonsters, $1);
			}
			$line =~ /MONSTERKILL=([0-9]*)\&/;
			$Hmonsterkill = $1;
			while($line =~/HMONSTERS=([0-9]*)\&/g) {
				push(@Hhmonsters, $1);
			}
			while($line =~/SINK=([0-9]*)\&/g) {
				push(@Hsink, $1);
			}
			while($line =~/SINKSELF=([0-9]*)\&/g) {
				push(@Hsinkself, $1);
			}
			while($line =~/EXT=([0-9]*)\&/g) {
				push(@Hext, $1);
			}
			while($line =~/SUBEXT=([0-9]*)\&/g) {
				push(@HsubExt, $1);
			}
			while($line =~/ITEM=([0-9]*)\&/g) {
				push(@HtmpItem, $1);
			}
			while($line =~/WEATHER=([0-9]*)\&/g) {
				push(@HtmpWeather, $1);
			}
			if($HoceanMode) {
				# 좌표를 선택 가능이 경우
				if($line =~ /OCEANX=([^\&]*)\&/) {
					$HoceanMapX = $1;
				}
				if($line =~ /OCEANY=([^\&]*)\&/) {
					$HoceanMapY = $1;
				}
				if($line =~ /RANDOM=([0-9]*)\&/) {
					$HmapRandom = $1;
				}
			}
		}

# 지형 데이터 저장·복원 모드
	} elsif($getLine =~ /ISave=([^\&]*)/) {
		$HmainMode = 'isave';
		$HisaveMode = 0;
	} elsif($line =~ /ISave=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 시 시작
		$HmainMode = 'isave';
		$HisaveMode = 1;
		$HinputPassword = htmlEscape($1);
		$HdefaultPassword = $HinputPassword;
		if($line =~ /SaveButton/) {
			# 저장
			$HisaveMode = 2;
		} elsif($line =~ /LoadButton/) {
			# 복원
			$HisaveMode = 3;
		} elsif($line =~ /ChangeButton/) {
			# 저장·복원(데이터의 교체에)
			$HisaveMode = 4;
		} elsif($line =~ /SaveLandButton/) {
			# 저장(해군을 제외)
			$HisaveMode = 5;
		} elsif($line =~ /LoadLandButton/) {
			# 복원(해군을 제외)
			$HisaveMode = 6;
		} elsif($line =~ /ChangeLandButton/) {
			# 저장·복원(해군을 제외)
			$HisaveMode = 7;
		}

# 저장 데이터다운로드
	} elsif($getLine =~ /Download=([^\&]*)\&/) {
		$HmainMode = 'download';
		$HinputPassword = htmlEscape($1);
		$HdefaultPassword = $HinputPassword;
		$getLine =~ /mode=([0-9]*)\&/;
		$HadminMode = $1;
		$getLine =~ /id=([0-9]*)/;
		$HcurrentID = $1;

# 저장 데이터 목록
	} elsif($getLine =~ /ViewLose=([^\&]*)/) {
		$HmainMode = 'vlose';
		$HinputPassword = htmlEscape($1);
		$HdefaultPassword = $HinputPassword;
	} elsif($line =~ /Reload=([^\&]*)/) { # 복원버튼누름
		$HmainMode = 'vlose';
		$HinputPassword = htmlEscape($1);
		$HdefaultPassword = $HinputPassword;
		if($line =~ /ReloadButton/) {
			if($line =~ /RELOADIDLOSE=([0-9]*)/) {
				$HmainMode = 'reload';
				$HadminMode = 4;
				$HcurrentID = $1;
			} elsif($line =~ /RELOADIDSAVE=([0-9]*)/) {
				$HmainMode = 'reload';
				$HadminMode = 3;
				$HcurrentID = $1;
			}
		} elsif($line =~ /DeleteButton/) {
			while($line =~/DELETEIDLOSE=([0-9]*)\&/g) {
				push(@HloseID, $1);
				$HadminMode |= 2;
			}
			while($line =~/DELETEIDSAVE=([0-9]*)\&/g) {
				push(@HsaveID, $1);
				$HadminMode |= 1;
			}
			$HmainMode = 'delete' if($HadminMode);
		}

# 확장 데이터 카운터 설정 모드
	} elsif($getLine =~ /ICounter=([^\&]*)/) {
		my $tmp = $1;
		$HdefaultPassword = htmlEscape($tmp) if($tmp ne '0');
		$HmainMode = 'icounter';
		$HicounterMode = 0;
	} elsif($line =~ /ICounter=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 시 시작
		$HmainMode = 'icounter';
		$HicounterMode = 1;
		$HinputPassword = $HdefaultPassword = htmlEscape($1);
		if($line =~ /AllSetButton/) {
			$HicounterMode = 4;
		} elsif($line =~ /SetButton/) {
			$HicounterMode = 2;
		} elsif($line =~ /AllDelButton/) {
			$HicounterMode = 5;
		} elsif($line =~ /DelButton/) {
			$HicounterMode = 3;
		}

# 함대강제 이동 모드
	} elsif($getLine =~ /Mfleet=([^\&]*)/) {
		# 처음 시작
		$HmainMode = 'mfleet';
		$HmfleetMode = 0;
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /Mfleet=([^\&]*)\&/) {
		# 함대 강제 이동 버튼이 눌렸을 시 시작
		$HmainMode = 'mfleet';
		$HmfleetMode = 1;
		$HdefaultPassword = htmlEscape($1);
		$line =~ /FROMID=([0-9]*)\&/;
		$HfromID = $1;
		$line =~ /TOID=([0-9]*)\&/;
		$HtoID = $1;
		$line =~ /FLEETNUMBER=([0-4])\&/;
		$HfleetNo = $1;

# 이벤트 설정 모드
	} elsif($getLine =~ /Esetup=([^\&]*)/) {
		# 처음 시작
		$HmainMode = 'esetup';
		$HsetEventMode = 0;
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /Esetup=([^\&]*)\&/) {
		# 이벤트 설정 버튼이 눌렸을 시 시작
		$HmainMode = 'esetup';
		$HdefaultPassword = htmlEscape($1);
		if($line =~ /SetEventButton/) {
			$HsetEventMode = 1;
			$line =~ /START=([0-9]*)\&/;
			$Hstart = $1;
			$line =~ /TURM=([0-9]*)\&/;
			$Hturm = $1;
			$line =~ /MAXSHIP=([0-9]*)\&/;
			$Hmaxship = $1;
			while($line =~/KIND=([0-9]*)\&/g) {
				$HpermitKind |= (2 ** $1);
			}
			$line =~ /ADDITION=([0-9]*)\&/;
			$Haddition = $1;
			while($line =~/RESTRICTION=([0-9]*)\&/g) {
				$Hrestriction |= (2 ** $1);
			}
			$line =~ /TYPE=([0-9]*)\&/;
			$Htype = $1;
			$line =~ /AUTORETURN=([0-9]*)\&/;
			$HautoReturn = $1;
			$line =~ /MONSTERTURN=([0-9]*)\&/;
			$HmonsterTurn = $1;
			$line =~ /MONSTERNUMBER=([0-9]*)\&/;
			$HmonsterNumber = $1;
			$line =~ /HUGEMONSTERTURN=([0-9]*)\&/;
			$HhugeMonsterTurn = $1;
			$line =~ /HUGEMONSTERNUMBER=([0-9]*)\&/;
			$HhugeMonsterNumber = $1;
			$line =~ /UNKNOWNTURN=([0-9]*)\&/;
			$HunkownTurn = $1;
			$line =~ /UNKNOWNNUMBER=([0-9]*)\&/;
			$HunkownNumber = $1;
			$line =~ /CORETURN=([0-9]*)\&/;
			$HcoreTurn = $1;
			$line =~ /CORENUMBER=([0-9]*)\&/;
			$HcoreNumber = $1;
			$line =~ /COREMINHP=([0-9]*)\&/;
			$HcoreMinHP = $1;
			$line =~ /COREMAXHP=([0-9]*)\&/;
			$HcoreMaxHP = $1;
			$line =~ /COREFLAG=([0-9]*)\&/;
			$HcoreFlag = $1;
			$line =~ /MONEY=([0-9]*)\&/;
			$HprizeMoney = int($1);
			$line =~ /FOOD=([0-9]*)\&/;
			$HprizeFood = int($1);
			if($line =~ /PRESENT=([0-9]*)\&/) {
				$HprizePresent = int($1);
			}
			my(%tmpItem);
			while($line =~/ITEM=([0-9]*)\&/g) {
				$tmpItem{$1} = 1;
			}
			foreach(0..$#HitemName) {
				push(@HprizeItem, int($tmpItem{$_}));
			}
		} else {
			$HsetEventMode = 2;
			while($line =~/DEL=([0-9]*)\&/g) {
				$HeventDel{$1} = 1;
			}
		}

# BattleField 작성 모드
	} elsif($getLine =~ /Bfield=([^\&]*)/) {
		# 처음 시작
		$HmainMode = 'bfield';
		$HbfieldMode = 0;
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /Bfield=([^\&]*)\&/) {
		# BattleField 작성 버튼이 눌렸을 시 시작
		$HmainMode = 'bfield';
		$HbfieldMode = 1;
		$HdefaultPassword = htmlEscape($1);
		if($HoceanMode) {
			# 좌표를 선택 가능이 경우
			if($line =~ /OCEANX=([^\&]*)\&/) {
				$HoceanMapX = $1;
			}
			if($line =~ /OCEANY=([^\&]*)\&/) {
				$HoceanMapY = $1;
			}
			if($line =~ /RANDOM=([0-9]*)\&/) {
				$HmapRandom = $1;
			}
		}

# 관리자 선물 지급 모드
	} elsif($getLine =~ /Present/) {
		# 처음 시작
		$HmainMode = 'present';
		$HpresentMode = 0;
	} elsif($line =~ /Present/) {
		# 선물 버튼이 눌렸을 시 시작
		$HmainMode = 'present';
		$HpresentMode = 1;
		($HpresentMoney) = ($line =~ /PRESENTMONEY=([^\&]*)\&/);
		($HpresentFood ) = ($line =~ /PRESENTFOOD=([^\&]*)\&/);
		$line =~ /PRESENTLOG=([^\&]*)\&/;
		$HpresentLog = cutColumn($1, $HlengthPresentLog*2);

# 관리자가 수행하는 제재 모드
	} elsif($getLine =~ /Punish=([^\&]*)/) {
		# 처음 시작
		$HmainMode = 'punish';
		$HpunishMode = 0;
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /Punish=([^\&]*)\&/) {
		# 제재 버튼이 눌렸을 시 시작
		$HmainMode = 'punish';
		$HpunishMode = 1;
		$HdefaultPassword = htmlEscape($1);

		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		$line =~ /PUNISHID=([^\&]*)\&/;
		$HpunishID = $1;

# 관리자가 수행하는 지형 변경 모드
	} elsif($getLine =~ /Lchange=([^\&]*)/) {
		# 처음 시작
		$HmainMode = 'lchange';
		$HlchangeMode = 0;
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /Lchange=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 시 시작
		$HmainMode = 'lchange';
		$HlchangeMode = 1;
		$HdefaultPassword = htmlEscape($1);

		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		$line =~ /LCHANGEKIND=([^\&]*)\&/;
		$HlchangeKIND = $1;
		$line =~ /LCHANGEVALUE=([^\&]*)\&/;
		$HlchangeVALUE = $1;

# 관리자가 수행하는 보관 모드
	} elsif($getLine =~ /Pdelete=([^\&]*)/) {
		# 처음 시작
		$HmainMode = 'predelete';
		$HpreDeleteMode = 0;
		$HdefaultPassword = htmlEscape($1);
	} elsif($line =~ /Pdelete=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 시 시작
		$HmainMode = 'predelete';
		$HpreDeleteMode = 1;
		$HdefaultPassword = htmlEscape($1);
		$line =~ /SETTURN=([0-9]*)\&/;
		$HsetTurn = $1;

# 모바이루 모드
	} elsif($line =~ /Mobile([0-9]*)/) {
		$HmainMode = $1;

# 기타는 중단 모드
	} else {
		$HmainMode = 'top';
	}

	if($line =~ /IMGLINEMAC=([^&]*)\&/){
		my($flag) = $1;
		if($flag eq ''){
			$flag = $HimageDir;
		} else {
			$flag =~ s/ /%20/g;
			$flag = 'file://'. $flag;
		}
		$HimgLine = $flag;
	} elsif($line =~ /IMGLINE=([^&]*)\&/){
		my($flag) = $1;
		$flag =~ tr/\\/\//;
		if(($flag eq 'deletemodenow') || ($flag eq '')){
			$flag = $HimageDir;
		} else {
			$flag =~ s/:/|/g;
			$flag =~ s/\/[\w\.]+\.gif$//g;
			$flag = 'file://'. $flag;
		}
		$HimgLine = $flag;
	} elsif($line =~ /SKIN=([^\&]*)\&/) {
		my($flag) = $1;
		if(($flag eq 'del') || ($flag eq '')){
			$flag = "${HcssDir}/$HcssDefault";
		} else {
			$flag = "${HcssDir}/". $flag;
		}
		$HskinName = $flag;
	}

}

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------
sub hakolock {
	if($lockMode == 1) {
		# directory 방식 잠금
		return hakolock1();
	} elsif($lockMode == 2) {
		# flock 방식 잠금
		return hakolock2();
	} elsif($lockMode == 3) {
		# symlink 방식 잠금
		return hakolock3();
	} elsif($lockMode == 4) {
		# 일반 파일 방식 잠금
		return hakolock4();
	} else {
		# rename 방식 잠금
		$lfh = hakolock5() or die return 0;
		return 1;
	}
}

sub hakolock1 {
	# 잠금을 시도
	if(mkdir('hakojimalock', $HdirMode)) {
		# 성공
		return 1;
	} else {
		# 실패
		my($b) = (stat('hakojimalock'))[9];
		if(($b> 0) && ((time() - $b)> $unlockTime)) {
			# 강제 해제
			unlock();
			# 헤더출력
			tempHeader();
			# 강제 해제 메시지
			tempUnlock();
			# 푸터출력
			tempFooter();
			# 종료
			exit(0);
		}
		return 0;
	}
}

sub hakolock2 {
	open(LOCKID, '>>hakojimalockflock');
	if(flock(LOCKID, 2)) {
		# 성공
		return 1;
	} else {
		# 실패
		return 0;
	}
}

sub hakolock3 {
	# 잠금을 시도
	if(symlink('hakojimalockdummy', 'hakojimalock')) {
		# 성공
		return 1;
	} else {
		# 실패
		my($b) = (lstat('hakojimalock'))[9];
		if(($b> 0) && ((time() - $b)> $unlockTime)) {
			# 강제 해제
			unlock();
			# 헤더출력
			tempHeader();
			# 강제 해제 메시지
			tempUnlock();
			# 푸터출력
			tempFooter();
			# 종료
			exit(0);
		}
		return 0;
	}
}

sub hakolock4 {
	# 잠금을 시도
	if(unlink('lockfile')) {
		# 성공
		open(OUT, '>lockfile.lock');
		print OUT time;
		close(OUT);
		return 1;
	} else {
		# 잠금 시간 확인
		if(!open(IN, 'lockfile.lock')) {
			return 0;
		}
		my($t);
		$t = <IN>;
		close(IN);
		if(($t != 0) && (($t + $unlockTime) < time)) {
			# 120초 이상 경과하면 강제로 잠금을 해제
			unlock();
			# 헤더출력
			tempHeader();
			# 강제 해제 메시지
			tempUnlock();
			# 푸터출력
			tempFooter();
			# 종료
			exit(0);
		}
		return 0;
	}
}

# rename 식(Perl 메모 http://www.din.or.jp/~ohzaki/perl.htm#File_Lock)
sub hakolock5 {
	my %lfh = (dir => "./", basename => "lockfile", timeout => $unlockTime, trytime => 3, @_);
	$lfh{path} = $lfh{dir}.$lfh{basename};

	for (my $i = 0; $i < $lfh{trytime}; $i++, sleep 1) {
		return \%lfh if (rename($lfh{path}, $lfh{current} = $lfh{path}. time));
	}

	opendir(LOCKDIR, $lfh{dir});
	my @filelist = readdir(LOCKDIR);
	closedir(LOCKDIR);

	foreach (@filelist) {
		if (/^$lfh{basename}(\d+)/) {
			return \%lfh if (time - $1> $lfh{timeout} and
			rename($lfh{dir}. $_, $lfh{current} = $lfh{path}. time));
			last;
		}
	}
	undef;
}

# 잠금을 해제
sub unlock {
	if($lockMode == 1) {
		# directory 방식 잠금
		rmdir('hakojimalock');
	} elsif($lockMode == 2) {
		# flock 방식 잠금
		close(LOCKID);
	} elsif($lockMode == 3) {
		# symlink 방식 잠금
		unlink('hakojimalock');
	} elsif($lockMode == 4) {
		# 일반 파일 방식 잠금
		my($i);
		$i = rename('lockfile.lock', 'lockfile');
	} else {
		# rename 방식 잠금
		rename($lfh->{current}, $lfh->{path});
	}
}

# 작은 쪽을 반환
sub min {
	return (sort { $a <=> $b } @_)[0];
}

# 큰분을 반환
sub max {
	return (sort { $b <=> $a } @_)[0];
}

# 1000억단위원형메루틴
sub aboutMoney {
	my($m) = @_;
	if($m < 500) {
		return "추정500${HunitMoney}미만";
	} else {
		$m = int(($m + 500) / 1000);
		return "추정${m}000${HunitMoney}";
	}
}

# 80자리에절리갖춤에
sub cutColumn {
	my($s, $c) = @_;

	if(length($s) <= $c) {
		return $s;
	} else {
		if($HlengthAlert) {
			unlock();
			tempHeader();
			tempWrong("문자 수 초과 입니다!");
			tempFooter();
			exit(0);
		}
		# 합계80자리가 됨까지절리 처리
		my($ss) = '';
		my($count) = 0;
		while($count < $c) {
			$s =~ s/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])//;
			if($1) {
				$ss.= $1;
				$count ++;
			} else {
				$ss.= $2;
			}
			$count ++;
		}
		return $ss;
	}
}

# 경험치에서 레벨을 산출
sub expToLevel {
	my($kind, $exp) = @_;
	my($i);
	if ($kind == $HlandNavy) {
		# 해군
		for ($i = $maxNavyLevel; $i> 1; $i--) {
			if ($exp>= $navyLevelUp[$i - 2]) {
				return $i;
			}
		}
		return 1;
	} elsif ($kind == $HlandBase) {
		# 미사일 기지
		for ($i = $maxBaseLevel; $i> 1; $i--) {
			if ($exp>= $baseLevelUp[$i - 2]) {
				return $i;
			}
		}
		return 1;
	} elsif($kind == $HlandSbase) {
		# 해저 기지
		for ($i = $maxSBaseLevel; $i> 1; $i--) {
			if ($exp>= $sBaseLevelUp[$i - 2]) {
				return $i;
			}
		}
		return 1;
	}
}

# 총 획득 경험치에서 레벨을 산출
sub gainToLevel {
	my($gain) = @_;
	my($i);
	for ($i = $HmaxComNavyLevel; $i> 1; $i--) {
		if ($gain>= $HcomNavyBorder[$i - 2]) {
			return $i;
		}
	}
	return 1;
}

# (0,0)에서(size - 1, size - 1)까지의 숫자가한 번씩 나오도록
# $pnum($pointNumber)(@rpx, @rpy)을 설정
sub makeRandomIslandPointArray {
	my($island) = @_;

	undef $island->{'rpx'};
	undef $island->{'rpy'};
	my(@rpx, @rpy, $map, @x, @y, $xsize, $ysize, $pnum);
	$map = $island->{'map'};
	@x = @{$map->{'x'}};
	@y = @{$map->{'y'}};
	$xsize = @x;
	$ysize = @y;
	$pnum = $xsize * $ysize;

	my($x);
	# 초기 값
	@rpx = (@x) x $ysize;
	foreach $y (@y) {
		push(@rpy, ($y) x $xsize);
	}

	# 셔터 전체
	my($i, $j);
	for ($i = $pnum; --$i; ) {
		$j = int(rand($i+1));
		next if($i == $j);
		@rpx[$i,$j] = @rpx[$j,$i];
		@rpy[$i,$j] = @rpy[$j,$i];
	}

	$island->{'pnum'} = $pnum - 1;
	$island->{'rpx'} = \@rpx;
	$island->{'rpy'} = \@rpy;
}

# 0에서(n - 1)의 난수
sub random {
	return int(rand(1) * $_[0]);
}

# 정렬
sub islandSort {
	my($kind, $mode) = @_;

	my @idx = (0..$#Hislands);
	@idx = sort {
			$Hislands[$b]->{'field'} <=> $Hislands[$a]->{'field'} || # 전장우선
			$Hislands[$a]->{'dead'} <=> $Hislands[$b]->{'dead'} || # 사멸 플래그가 설정되어 있으면후로 로
			$Hislands[$a]->{'predelete'} <=> $Hislands[$b]->{'predelete'} || # 관리자 보관 플래그가 설정되어 있으면후로 로
			$Hislands[$b]->{$kind} <=> $Hislands[$a]->{$kind} || # $kind 에서정렬
			$a <=> $b # $kind가 같으면 이전 순서를 유지
		 } @idx;
	if($mode) {
		my @Hidx;
		foreach (0..$#idx) {
			$Hidx[$idx[$_]] = $_;
		}
		my %temp = %HidToNumber;
		while (my($k,$v) = each %temp){
			$HidToNumber{$k} = $Hidx[$v] if(defined $v);
		}
	}
	# 순위의 원래가 됨요소의 경우, 배열을 갱신
	if($kind eq $HrankKind) {
		@Hislands = @Hislands[@idx] ;
		@idx = (0..$#Hislands);
	}
	return $Hislands[$idx[$HbfieldNumber]];
}

# 정렬(동맹버전)
sub allySort {
	# score가 같으면 이전 턴의 순서를 유지
	my @idx = (0..$#Hally);
	@idx = sort {
			$Hally[$a]->{'dead'} <=> $Hally[$b]->{'dead'} || # 사멸 플래그가 설정되어 있으면후로 로
			$Hally[$b]->{'score'} <=> $Hally[$a]->{'score'} ||
			$a <=> $b
		 } @idx;
	@Hally = @Hally[@idx];
	my @Hidx;
	foreach (0..$#idx) {
		$Hidx[$idx[$_]] = $_;
	}
	my %temp = %HidToAllyNumber;
	while (my($k,$v) = each %temp){
		$HidToAllyNumber{$k} = $Hidx[$v] if(defined $v);
	}
}

# 해군의 값을 산출
sub estimateNavy {
	my($number) = @_;
	my($island, $fkind, $monslive, $monstertype, $hmonstertype, $unknownlive, $unknowntype);

	# 지형을 가져옴
	$island = $Hislands[$number];
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($map) = $island->{'map'};

	# 수 가능
	my($x, $y, $kind, $value);
	foreach $y (@{$map->{'y'}}) {
		foreach $x (@{$map->{'x'}}) {
			$kind = $land->[$x][$y];
			$value = $landValue->[$x][$y];
			if ($kind == $HlandNavy) {
				my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($value);
				my $nSpecial = $HnavySpecial[$nKind];
				my $n = $HidToNumber{$nId};
				if($HautoKeepID{$nId} && ($nId != $id)) {
					# 바다로
					$land->[$x][$y] = $HlandSea;
					$landValue->[$x][$y] = $nSea;
				} elsif(defined $n) {
#					if(!($nFlag & 1) && !($nSpecial & 0x8)) {
#						$Hislands[$n]->{'ships'}[$nNo]++;
#						$Hislands[$n]->{'ships'}[4]++;
#					}
#					$Hislands[$n]->{'shipk'}[nKind]++;
					my $fvalue = sprintf("%08x", navyPack($id, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp));
					push(@{$Hislands[$n]->{'fkind'}}, "$fvalue");
					$Hislands[$n]->{'navy'}[$nKind]++;
				} elsif(!($nSpecial & 0x8) && !($nFlag & 1)) {
					$unknownlive++;
					$unknowntype |= (2 ** $nKind);
				}
			} elsif(($kind == $HlandMonster) || ($kind == $HlandHugeMonster)){
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($value);
				if($HautoKeepID{$mId}) {
					if ($mFlag & 2) {
						$land->[$x][$y] = $HlandSea;
						$landValue->[$sx][$sy] = $mSea;
					} else {
						$land->[$x][$y] = $HlandWaste;
						$landValue->[$sx][$sy] = 0;
					}
				} elsif(($kind == $HlandHugeMonster) && ($mHflag == 0)) {
					$monslive++;
					$hmonstertype |= (2 ** $mKind);
				} elsif($kind == $HlandMonster) {
					$monslive++;
					$monstertype |= (2 ** $mKind);
				}
			}
		}
	}
	$island->{'monsterlive'} = "$monslive,$monstertype,$hmonstertype,$unknownlive,$unknowntype";
}

#----------------------------------------------------------------------
# 로그 표시
#----------------------------------------------------------------------
# 파일 번호를 지정해 로그 표시
sub logFilePrint {
	my($fileNumber, $id, $mode) = @_;
	my $nowTurn = -1;

	open(LIN, "${HdirName}/$_[0]$HlogData");
	my($line, $m, $turn, $id1, $id2, $id3, $message, @ids);
	while($line = <LIN>) {
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9\-\s]*),(.*)$/;
		($m, $turn, $id1, $id2, $id3, $message) = ($1, $2, $3, $4, $5, $6);
		next if($m eq '');
		@ids = ($id1, $id2, split('-', $id3));
		if ($nowTurn != $turn) {
			out("</BLOCKQUOTE>\n") if ($nowTurn != -1);
			out("<HR>${HtagNumber_}턴 $turn${H_tagNumber}\n<BLOCKQUOTE>\n");
			$nowTurn = $turn;
		}

		# 기밀관계
		if($m == 1) {
			if(($mode == 0) || ($id1 != $id)) {
				# 기밀 표시 권한 없음
				next;
			}
			$m = "<span class='lbbsST'>(기밀)</span>";
		} else {
			$m = '';
		}

		# 정확히 표시할지
		if($id != 0) {
			my $flag = 1;
			foreach (@ids) {
				if($id == $_) {
					$flag = 0;
					last;
				}
			}
			next if($flag);
		}

		# 표시
		my $str = "${m}$message<BR>";
		if($Hmobile) {
			1 while $str =~ s/(.*)(<BR>--- (.*))/$1<BR>/i;
			1 while $str =~ s/(.*)(<(span[\s\w\=\+\-\#\"\']+)>(.*)<\/span>)/$1$4/i;
			if($str =~ /( --- )/) {
				if($str !~ /(침몰|기밀)/) {
					$str = (split(/./, $str))[0]. '<BR>';
				}
			} elsif($str =~ /(,,, )/) {
				next;
			} elsif($str =~ /( )/) {
				1 while $str =~ s/(.*)(<B>(.*)<\/B>)/$1$3/i;
			} else {
				$str = '◆'. $str;
			}
		}
		out("$str\n");
	}
	close(LIN);

	out("</BLOCKQUOTE>\n") if ($nowTurn != -1);
}

#----------------------------------------------------------------------
# 템플릿
#----------------------------------------------------------------------
# 초기화
sub tempInitialize {
	my($mode) = @_;

	# 섬 선택(기본값은 자신)
	$HislandList = getIslandList($defaultID, $mode);
	$HtargetList = getIslandList($defaultTarget, $mode);
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
	my($select, $mode, $color) = @_;
	my($list, $name, $id, $s, $i, $c);

	#섬 목록의 메뉴
	$list = '';
	$list = "<OPTION VALUE=\"0\" SELECTED>신규 작성(모두 바다)\n" if($select == -1);
	foreach $i (0..$islandNumber) {
		$island = $Hislands[$i];
		next if($mode == 2 && !$island->{'field'});
		$name = islandName($island);
		$name =~ s/<[^<]*>//g;
		$id = $Hislands[$i]->{'id'};
		if($id eq $select) {
			$s = ' SELECTED';
			$c = " style=\"background:$color;\"" if($color ne '');
		} else {
			$s = '';
			$c = '';
		}

		$list.= "<OPTION VALUE=\"$id\"$c$s>${name}\n" if($mode || !$island->{'field'});
	}
	return $list;
}

# 잠금실패
sub tempLockFail {
	# 제목
	out(<<END);
${HtagBig_}동시접속오류입니다.<BR>
브라우저의'돌아가기'버튼을 누름시,<BR>
잠시 기다렸다가 다시오시 도시하세요.${H_tagBig}$HtempBack
END
}

# 강제 해제
sub tempUnlock {
	# 제목
	out(<<END);
${HtagBig_}지난 접속이 비정상 종료된 것 같습니다.<BR>
잠금을 강제 해제했습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호 파일이 없음
sub tempNoHpasswordFile {
	out(<<END);
${HtagBig_} 비밀번호 파일을 열 수 없습니다.${H_tagBig}$HtempBack
END
}

# 메인 데이터가 없음
sub tempNoDataFile {
	out(<<END);
${HtagBig_}데이터 파일을 열 수 없습니다.${H_tagBig}$HtempBack
END
}

# 무언가문제발생
sub tempProblem {
	out(<<END);
${HtagBig_}문제발생, 일단복귀해 주세요.${H_tagBig}$HtempBack
END
}

# 코멘트
sub tempAnyString {
	out(<<END);
${HtagBig_}$_[0]${H_tagBig}$HtempBack
END
}

# 점검안
sub mente_mode {
	# 헤더출력
	tempHeader();

	# 메시지
	out("${HtagBig_}단지지금점검안입니다.<BR>잠시쿠기다려 주세요.${H_tagBig}");

	# 푸터출력
	tempFooter();

	# 종료
	exit(0);
}
#----------------------------------------------------------------------
# 헤더
#----------------------------------------------------------------------
sub tempHeader {
	$baseIMG = $HimageDir;
	my($bIstr) = ($HmainMode eq 'setupv') ? "" : "<BASE HREF='${baseIMG}/'>";
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${HcssDir}/$HcssDefault";
	}

	# UTF-8 환경: charset 은 utf-8을 사용합니다.
 	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $Hgzip == 1){
		print qq{Content-type: text/html; charset=UTF-8\n};
		print qq{Content-encoding: gzip\n\n};
		open(STDOUT,"| $HpathGzip/gzip -1 -c");
		print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};
	}else{
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};
	}

	if(!$Hmobile) {
		out(<<END);
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$HtitleTag($versionInfo)
</TITLE>
$bIstr
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$Body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
$Hheader
END

		my $nextturn = '';
		foreach (1..$HrepeatTurn) {
			$nextturn.= '·' if($_ != 1);
			$nextturn.= $HislandTurn + $_;
			last if($HislandTurn + $_ == $HarmisticeTurn || $HislandTurn + $_ == $HsurvivalTurn || $HislandTurn + $_ == $HislandChangeTurn);
		}
		out(<<END) if($Hrealtimer && (defined $HleftTime));
<DIV ID="REALTIME" class="timer"></DIV>
<SCRIPT language="JavaScript">
<!--
var leftTime = $HleftTime;
var hour, min, sec;

function showTimeLeft() {
	if (leftTime> 0) {
		setTimeout('showTimeLeft()', 1000);
		hour = Math.floor(leftTime / 3600);
		min = Math.floor(leftTime % 3600 / 60);
		sec = leftTime % 60;
		leftTime--;
		document.all.REALTIME.innerHTML = '다음 갱신(<span class="number">턴$nextturn</span>)까지 남은 ' + hour + '시간 ' + min + '분 ' + sec + '초 ($HnextTime)';
	} else {
		document.all.REALTIME.innerHTML = '턴 갱신 시각이 되었습니다! ($HnextTime)';
	}
}

if ($HplayNow) {
	showTimeLeft();
} else {
	document.all.REALTIME.innerHTML = '게임이 종료되었습니다!';
}
//-->
</SCRIPT>
END
		out("<HR></DIV>");
	} else {
 out(<<END);
<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8"><TITLE>$Htitle</TITLE></HEAD>
<BODY bgcolor="#ffffff">
<a href="./hako-main.cgi">중단</a> <a href="./hako-main.cgi?SetupV=1">도움말</a> <a href="./hako-main.cgi?FightLog=1">링크</a>
<HR>
END
	}
}

#----------------------------------------------------------------------
# 푸터
#----------------------------------------------------------------------
sub tempFooter {
	out(<<END) if(!$Hmobile);
<HR>
<DIV ID='LinkFoot'>
$Hfooter
<DIV align="right">
END
##### 추가 친분20020307
	if($Hperformance && !$Hmobile) {
		my($uti, $sti, $cuti, $csti) = times();
		$uti += $cuti;
		$sti += $csti;
		my($cpu) = $uti + $sti;

	#	 로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
	#	 open(POUT,">>cpu-h.log");
	#	 print POUT "CPU($cpu) : user($uti) system($sti)\n";
	#	 close(POUT);

		out(<<END);
 <SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
END
	}
#####
	out(<<END) if(!$Hmobile);
<HR>
<B>바다전쟁 JS.$versionInfo(based on ver1.3)</B> patchworked by <a style='text-decoration:none;' href='http://no-one.s53.xrea.com/'>neo_otacky</a>
</DIV></DIV></DIV>
END
	if($oroti) {
		out(<<END);
<script type="text/javascript">
<!--
var image = document.getElementsByTagName('img');
for (var i = 0; i < image.length; i++){
	image[i].src = image[i].src.replace("$HbaseDir","$baseIMG");
}
//-->
</script>
END
	}
	out("</BODY></HTML>");
}
