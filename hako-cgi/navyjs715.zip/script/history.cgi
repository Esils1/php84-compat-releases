#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

# The Return of Neptune: http://no-one.s53.xrea.com/
# patchworked by neo_otacky. for 바다전쟁 JS
#---------------------------------------------------------------------
#
#	궁극 구상의 모형정원 최근 사건과 최근 날씨의 이력을 표시
#
#	작성일 : 2001/11/25 (ver0.10)
#	작성자 : 라스티아 <nayupon@mail.goo.ne.jp>
#
#---------------------------------------------------------------------
BEGIN {
	# Perl 5.004 이상이필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}

#---------------------------------------------------------------------
#	초기 설정
#---------------------------------------------------------------------
# 초기 설정용 파일을 읽기
require './hako-init.cgi';
require './hako-io.cgi';
require './init-game.cgi';
#----------------------------
#	HTML에 관한 설정
#----------------------------
# 브라우저의 제목막대의 명칭
$title = '최근 사건';

# 화면의'돌아가기'링크선(URL)
$bye = $HthisFile;

# 메인 루틴-------------------------------------------------------
unless($ENV{HTTP_REFERER} =~ /${HbaseDir}/) {
	print qq{Content-type: text/html; charset=UTF-8\n\n};
	out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$Body
<H1>부정나접속입니다</H1>
</BODY></HTML>
END
	exit(0);
}
cookieInput();
cgiInput();
if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	chomp($HspecialPassword = <PIN>); # 특수 비밀번호를 읽기
	close(PIN);
}

if($HhtmlLogMake && ($HcurrentID == 0)) {
	unless(-e "${HhtmlDir}/hakolog.html") {
		# 최근 사건HTML출력
		logPrintHtml();
		tempRefresh(3, '로그 작성안입니다. 그대로 잠시 기다려 주세요') if($HhtmlLogMode);
	} else {
		tempRefresh(0, '잠시 기다려 주세요') if($HhtmlLogMode);
	}
}

if(!readIslandsFile()){
	tempHeader();
	htmlError();
} else {
	# 무한루프회피
	$HrepeatTurn = 1 if(!$HrepeatTurn);

	$HislandList = getIslandList($HcurrentID);
	tempHeader();
	out("<DIV ID='RecentlyLog'>\n");

	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = islandName($island);
	if($HMode == 100 && $HuseWeather) {
		# 날씨
		&logTenki();
	} else {
		# 최근 사건
		if($HMode == 99) {
			if($HcurrentID == 0) {
				logFilePrintAll();
			} else {
				tempIslandHeader($HcurrentID, $HcurrentName);
				# 비밀번호
				if(checkPassword($island, $HinputPassword) && ($HcurrentID eq $defaultID)) {
					logPrintLocal(1);
				} else {
					# password 차이우
					logPrintLocal(0);
				}
			}
		} else {
			if($HcurrentID == 0) {
				foreach (1..$HrepeatTurn) {
					last if($HMode + $_ - 1>= $HlogMax);
					logFilePrint($HMode + $_ - 1, $HcurrentID, 0);
				}
			} else {
				tempIslandHeader($HcurrentID, $HcurrentName);
				# 비밀번호
				if(checkPassword($island, $HinputPassword) && ($HcurrentID eq $defaultID)) {
					foreach (1..$HrepeatTurn) {
						last if($HMode + $_ - 1>= $HlogMax);
						logFilePrint($HMode + $_ - 1, $HcurrentID, 1);
					}
				} else {
					# 비밀번호 오류
					foreach (1..$HrepeatTurn) {
						last if($HMode + $_ - 1>= $HlogMax);
						logFilePrint($HMode + $_ - 1, $HcurrentID, 0);
					}
				}
			}
		}
	}
	out("</DIV>\n");
}

tempFooter();
#종료
exit(0);

# 서브 루틴---------------------------------------------------------
#---------------------------------------------------------------------
#	함수명 : htmlError
#	기계 능 : HTML 의오류 메시지의 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlError{
	out("<h2>오류가 발생했습니다</h2>\n");
}
#--------------------------------------------------------------------
#	POST 또는 GET으로 입력된 데이터 가져오기
#--------------------------------------------------------------------
sub cgiInput {
	my($line, $getLine);

	# 입력을 받아 UTF-8로 처리
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9]{2})/pack(H2, $1)/eg;
#	 # 문자 변환 라이브러리 사용 시
	$line =~ s/[\x00-\x1f\,]//g;

	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};

	if($line =~ /ID=([0-9]*)/){
		$HcurrentID = $1;
	} elsif($getLine =~ /ID=([0-9]*)/){
		$HcurrentID = $1;
	}
	if($line =~ /PASSWORD=([^\&]*)/) {
		$HinputPassword = $1;
	} elsif($getLine =~ /PASSWORD=([^\&]*)/) {
		$HinputPassword = $1;
	}
	if($line =~ /Event=([0-9]*)/){
		$HMode = $1;
	} elsif($getLine =~ /Event=([0-9]*)/){
		$HMode = $1;
	} else {
		$HMode = 0;
	}
	if($line =~ /Topmode=([0-9]*)/){
		$HtopMode = $1;
	} elsif($getLine =~ /Topmode=([0-9]*)/) {
		$HtopMode = $1;
	}
}

#---------------------------------------------------------------------
#	HTML 의헤더와 푸터 부분을 출력
#---------------------------------------------------------------------
# 헤더
sub tempHeader {
	$baseIMG = $HimageDir;
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${HcssDir}/$HcssDefault";
	}
	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $Hgzip == 1){
		print qq{Content-type: text/html; charset=UTF-8\n};
		print qq{Content-encoding: gzip\n\n};
		open(STDOUT,"| $HpathGzip/gzip -1 -c");
		print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};
	}else{
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};
	}

	my($img);
	$img = "<BASE HREF=\"$baseIMG/\">" if($HMode == 100);
	out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
$img
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$Body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
END


	out(<<END) if(!$HtopMode);
$Hheader
<HR></DIV>
[<A HREF="$bye">돌아가기</A>]
<br><br>
END
	logDekigoto();

	out(<<END);
<HR>
<FORM name="recentForm" action="${HbaseDir}/history.cgi" method="POST" style="margin : 2px 0px;">
END
	if($HuseWeather) {
		if($HMode == 100) {
			out("[<B><span class=number>최근의 날씨</span></B>] ");
		} else {
			out("[<A HREF=\"${HbaseDir}/history.cgi?Event=100\">최근의 날씨</A>] ");
		}
	}

	out("<B>[최근 사건]</B>");
	if($HMode == 99 && $HcurrentID == 0) {
		out("[<B><span class=number>ALL</span></B>] ");
	} else {
		out("[<A HREF='${HbaseDir}/history.cgi?Event=99");
		out("&Topmode=1") if($HtopMode);
		out("'>ALL</A>] ");
	}
	my($i, $turn);
	for($i = 0;$i < $HtopLogTurn;$i+=$HrepeatTurn) {
		$turn = $HislandTurn - $i;
		last unless($turn> 0);
		$turn = "<a href='#${turn}' style='text-decoration:none;'>${turn}</a>" if($HMode == $i && $HcurrentID == 0);
		$turn = "턴${turn}(현재)" if(!$i);
		if($HrepeatTurn> 1) {
			foreach(2..$HrepeatTurn) {
				my $n = $HislandTurn - $i - ($_ - 1);
				last unless($n> 0 && $HislandTurn - $n < $HtopLogTurn);
				$n = "<a href='#${n}' style='text-decoration:none;'>${n}</a>" if($HMode == $i && $HcurrentID == 0);
				$turn.= "·$n";
			}
		}
		if($HMode == $i && $HcurrentID == 0) {
			out("[<B><span class=number>${turn}</span></B>]\n");
			next;
		}
		out("[<A HREF='${HbaseDir}/history.cgi?Event=${i}");
		out("&Topmode=1") if($HtopMode);
		out("'>${turn}</A>]\n");
	}

	out(<<END);
 <B>[링크]</B>
<SELECT NAME="ID">$HislandList</SELECT>
<INPUT type=hidden name=PASSWORD value="$HinputPassword">
<INPUT type=hidden name=Topmode value="$HtopMode">
<INPUT type="submit" value="보기">
</FORM>
END
}
# 푸터
sub tempFooter {
	if(!$HtopMode) {
		out(<<END);
<HR>
<DIV ID='LinkFoot'>
$Hfooter
<BR></DIV>
END
##### 추가 친분20020307
		if($Hperformance) {
			my($uti, $sti, $cuti, $csti) = times();
			$uti += $cuti;
			$sti += $csti;
			my($cpu) = $uti + $sti;

	#	 로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
	#	 open(POUT,">>cpu-h.log");
	#	 print POUT "CPU($cpu) : user($uti) system($sti)\n";
	#	 close(POUT);

			out(<<END);
<DIV align="right">
<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
</DIV>
END
		}
#####
		out("</DIV>");
	}
	out("</BODY></HTML>");
}

# HTML화리후레슈
sub tempRefresh {
	my($delay, $str) = @_;


	unless($Hgzip == 1) {
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
		out(<<END);
<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>HTML화</TITLE>
<meta HTTP-EQUIV='refresh' CONTENT='$delay; URL="${htmlDir}/hakolog.html"'>
</HEAD>$Body<DIV ID='BodySpecial'>
<H2>$str</H2>
END
	} else {
		open(IN, "<${HhtmlDir}/hakolog.html") || die $!;
		@buffer = <IN>;
		close(IN);
		if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/) {
			print qq{Content-type: text/html; charset=UTF-8;\n};
			print qq{Content-encoding: gzip\n\n};
			open(STDOUT,"| $HpathGzip/gzip -1 -c");
			print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		} else {
			print qq{Content-type: text/html; charset=UTF-8;\n\n};
		}
		print @buffer;
	}
	exit(0);
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
	my($select) = @_;
	my($list, $name, $id, $s, $i);

	#섬 목록의 메뉴
	$list = '';
	foreach $i (0..$islandNumber) {
		$name = islandName($Hislands[$i]);
		$id = $Hislands[$i]->{'id'};
		if($id eq $select) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		$list.= "<OPTION VALUE=\"$id\" $s>${name}\n";
	}
	return $list;
}
#---------------------------------------------------------------------
#	섬의 최근 소식의 링크
#---------------------------------------------------------------------
# 헤더
sub tempIslandHeader {
my($id, $name) = @_;

	if(checkPassword($Hislands[$HidToNumber{$id}], $HinputPassword) && ($HcurrentID eq $defaultID)) {
		out(<<END);
<HR>
<FONT COLOR=\"#FF0000\"><B>[${name}의 최근 소식]</B></FONT>
END
	} else {
		out(<<END);
<HR>
<B>[${name}의 최근 소식]</B>
END
	}

	if($HMode == 99) {
		out("[<B><span class=number>ALL</span></B>] ");
	} elsif($HinputPassword eq '') {
		out("[<A HREF='${HbaseDir}/history.cgi?ID=${id}&Event=99");
		out("&Topmode=1") if($HtopMode);
		out("'>ALL</A>] ");
	} else {
		out("[<A HREF='${HbaseDir}/history.cgi?ID=${id}&PASSWORD=${HinputPassword}&Event=99'>ALL</A>] ");
	}
	my($i, $turn);
	for($i = 0;$i < $HtopLogTurn;$i+=$HrepeatTurn) {
		$turn = $HislandTurn - $i;
		return unless($turn> 0);
		$turn = "<a href='#${turn}' style='text-decoration:none;'>${turn}</a>" if($HMode == $i);
		$turn = "턴${turn}(현재)" if(!$i);
		if($HrepeatTurn> 1) {
			foreach(2..$HrepeatTurn) {
				my $n = $HislandTurn - $i - ($_ - 1);
				last unless($n> 0 && $HislandTurn - $n < $HtopLogTurn);
				$n = "<a href='#${n}' style='text-decoration:none;'>${n}</a>" if($HMode == $i);
				$turn.= "·$n";
			}
		}
		if($HMode == $i) {
			out("[<B><span class=number>${turn}</span></B>]\n");
			next;
		}
		if($HinputPassword eq '') {
			out("[<A HREF='${HbaseDir}/history.cgi?ID=${id}&Event=${i}");
			out("&Topmode=1") if($HtopMode);
			out("'>${turn}</A>]\n");
		} else {
			out("[<A HREF='${HbaseDir}/history.cgi?ID=${id}&PASSWORD=${HinputPassword}&Event=${i}'>${turn}</A>]\n");
		}
	}
}
#---------------------------------------------------------------------
#	로그 파일제목
#---------------------------------------------------------------------
sub logDekigoto {
	out(<<END);
<H1>최근 사건</H1>
END
}
#---------------------------------------------------------------------
#	로그 파일 전체 표시
#---------------------------------------------------------------------
sub logFilePrintAll {
	my($i);
	for($i = 0; $i < $HtopLogTurn; $i++) {
		logFilePrint($i, 0, 0);
	}
}
#---------------------------------------------------------------------
# 개별 로그 표시
#---------------------------------------------------------------------
sub logPrintLocal {
	my($mode) = @_;
	my($i);
	for($i = 0; $i < $HtopLogTurn; $i++) {
		logFilePrint($i, $HcurrentID, $mode);
	}
}
#---------------------------------------------------------------------
#	파일 번호를 지정해 로그 표시 # 바다전쟁계
#---------------------------------------------------------------------
sub logFilePrint {
	my($fileNumber, $id, $mode) = @_;
	my $nowTurn = -1;

	open(LIN, "${HdirName}/$fileNumber$HlogData");
	my($line, $m, $turn, $id1, $id2, $id3, $message, @ids);
	while($line = <LIN>) {
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9\-\s]*),(.*)$/;
		($m, $turn, $id1, $id2, $id3, $message) = ($1, $2, $3, $4, $5, $6);
		next if($m eq '');
		@ids = ($id1, $id2, split('-', $id3));
		if ($nowTurn != $turn) {
			out("</BLOCKQUOTE>\n") if ($nowTurn != -1);
			out("<HR><span class=number><FONT SIZE=4><a name='$turn'>턴 $turn</a></FONT></span>\n<BLOCKQUOTE>\n");
			$nowTurn = $turn;
		}

		# 기밀관계
		if($m == 1) {
			if(!$mode || ($id1 != $id)) {
				# 기밀 표시 권한 없음
				next;
			}
			$m = "<span class='lbbsST'>(기밀)</span>";
		} else {
			$m = '';
		}

		# 정확히 표시할지
		if($id != 0) {
			my $flag = 1;
			foreach (@ids) {
				if($id == $_) {
					$flag = 0;
					last;
				}
			}
			next if($flag);
		}

		# 표시
		out("${m}$message<BR>\n");
	}
	close(LIN);

	out("</BLOCKQUOTE>\n") if ($nowTurn != -1);
}
#----------------------------------------------------------------------
# HTML생성
#----------------------------------------------------------------------
sub logPrintHtml {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime(time + $Hjst);
	$mon++;
	my($sss) = "${mon}월${date}일 ${hour}시 ${min}분${sec}초";

	$html1=<<_HEADER_;
<HTML><HEAD>
<META http-equiv="Content-Style-Type" content="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
최근 사건
</TITLE>
<link rel="stylesheet" type="text/css" href="${HcssDir}/$HcssDefault">
<BASE HREF="$htmlDir/">
</HEAD>
$Body
$Hheader
<DIV ID='BodySpecial'>
<DIV ID='RecentlyLog'>
<H1>최근 사건</H1>
<FORM>
최신갱신일:$sss..
<INPUT TYPE="button" VALUE=" 다시 읽기" onClick="location.reload()">
</FORM>
<hr>
_HEADER_

$html3=<<_HEADER_;
</DIV><HR>
</DIV></BODY>
</HTML>
_HEADER_
	my($i);
	for($i = 0; $i < $HhtmlLogTurn; $i++) {
		$id =0;
		$mode = 0;
		my($set_turn) = 0;
		open(LIN, "${HdirName}/$i$HlogData");
		my($line, $m, $turn, $id1, $id2, $message);
		while($line = <LIN>) {
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9\-]*),(.*)$/;
			($m, $turn, $id1, $id2, $id3, $message) = ($1, $2, $3, $4, $5, $6);
			next if($m eq '');

			# 기밀관계
			next if($m == 1);

			# 표시
			if($set_turn == 0){
				$html2.= "<B>=====[<span class=number><FONT SIZE=4>턴$turn </FONT></span>]================================================</B><BR>\n";
				$set_turn++;
			}
			$html2.= "<span class='number'>★</span>:$message<BR>\n";
		}
		close(LIN);
	}
	open(HTML, ">${HhtmlDir}/hakolog.html");
#	print HTML $html1;
#	print HTML $html2;
#	print HTML $html3;
	print HTML $html1;
	print HTML $html2;
	print HTML $html3;
	close (HTML);
	chmod(0666,"${HhtmlDir}/hakolog.html");
}
#---------------------------------------------------------------------
#	날씨 파일 표시
#---------------------------------------------------------------------
sub logTenki {
	my($i, $j, $island, $name, $turn);
	out(<<END);
<HR>
<span class=number><FONT SIZE=4>[최근의 날씨]</FONT></span>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 BGCOLOR="#000000"><TR><TD>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>
END
	my $line =<<END;
<TR>
<TD $headNameCellcolor rowspan=2 NOWRAP>${AfterName}</TD>
<TD $headNameCellcolor rowspan=2 colspan=4 NOWRAP>기상 데이터</TD>
<TD $headNameCellcolor colspan=3 NOWRAP><span $tomorrowColor>예보</span></TD>
END
	for($i = 0; $i < $HtopLogTurn; $i++) {
		$turn = $HislandTurn - $i;
		last if($turn < 0);
		if($i == 0) {
			$line.= "<TD $headNameCellcolor rowspan=2 NOWRAP><nobr><span $todayColor>턴${turn}<br><B>(현재)</B></nobr>";
		} else {
			$line.= "<TD $headNameCellcolor rowspan=2 NOWRAP>${turn}";
		}
		$line.= "</TD>";
	}
	$line.= "</TR><TR>";
	for($i = 0; $i < 3; $i++) {
		$turn = $HislandTurn + 3 - $i;
		$line.= "<TD $headNameCellcolor NOWRAP>";
		if($i == 2) {
			$line.= "<nobr><span $tomorrowColor>턴${turn}<br><B>(다음 턴)</B></nobr>";
		} else {
			$line.= "<nobr><span $tomorrowColor>턴${turn}</nobr>";
		}
		$line.= "</TD>";
	}
	my(@all);
	for($i = 0; $i < $HislandNumber; $i++) {
		$island = $Hislands[$i];
		$name = islandName($island);
		if($island->{'field'}) {
			$name = "${HtagNumber_}${name}${H_tagNumber}";
		} elsif($island->{'absent'} == 0) {
			$name = "${HtagName_}${name}${H_tagName}";
		} else {
			$name = "${HtagName2_}${name}($island->{'absent'})${H_tagName2}";
		}
		$name.= "${HtagDisaster_}★${H_tagDisaster}" if ($HislandTurn - $island->{'birthday'} <= $HdevelopTurn);
		if($island->{'predelete'}) {
			my $rest = ($island->{'predelete'} != 99999999) ? "<small>(남은$island->{'predelete'}턴)</small>" : '';
			$name = "${HtagDisaster_}[관리자 보관]$rest${H_tagDisaster}<BR>". $name;
		}
		my($kion, $kiatu, $situdo, $kaze, $jiban, $nami, $ijoh, @weather) = @{$Hislands[$i]->{'weather'}};
		foreach (0..6) {
			$all[$_] += $Hislands[$i]->{'weather'}[$_];
		}
		$line.= "<TR><TD $nameCellcolor rowspan=3><A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=$island->{'id'}\">${name}</A></TD>";
		$line.= "<TD $pointCellcolor>기온</TD><TD $pointCellcolor2>${kion}℃</TD><TD $pointCellcolor>풍속</TD><TD $pointCellcolor2>${kaze}m/s</TD>";
		for($j = 0; $j < $HtopLogTurn + 3; $j++) {
			$turn = $HislandTurn + 3 - $j;
			last if($turn < 0);
			$weather[$j] = 0 if($weather[$j] == '');
			$line.= "<TD $pointCellcolor rowspan=3 NOWRAP>";
			$line.= "<img src ='$HweatherImage[$weather[$j]]'><br>" if($weather[$j]);
			if($j> 3) {
				$line.= "<span $yesterdayColor>";
			} elsif($j == 3) {
				$line.= "<span $todayColor>";
			} else {
				$line.= "<span $tomorrowColor>";
			}
			if($weather[$j]) {
				$line.= "$HweatherName[$weather[$j]]</span></TD>";
			} else {
				$line.= "-</span></TD>";
			}
		}
		$line.=<<END;
</TR><TR>
<TD $pointCellcolor>기압</TD><TD $pointCellcolor2>${kiatu}hPa</TD>
<TD $pointCellcolor>지반</TD><TD $pointCellcolor2>${jiban}</TD>
</TR><TR>
<TD $pointCellcolor>습도</TD><TD $pointCellcolor2>${situdo}%</TD>
<TD $pointCellcolor>파력</TD><TD $pointCellcolor2>${nami}</TD>
</TR>
END
	}
	if($HislandNumber) {
		foreach (0..6) {
			$all[$_] = sprintf("%.1f", $all[$_]/$HislandNumber);
		}
		my $col = 8 + $HtopLogTurn;
		out("<TR><TD class='M' colspan='$col'><FONT COLOR='#FFFFFF'><B>기상 데이터 전체 섬평균등 기온:$all[0]℃ 기압:$all[1]hPa 습도:$all[2]% 풍속:$all[3]m/s 지반:$all[4] 파력:$all[5]</B></FONT></TD></TR>\n");
	}
	out("$line</TABLE></TD></TR></TABLE><br>\n");
}
