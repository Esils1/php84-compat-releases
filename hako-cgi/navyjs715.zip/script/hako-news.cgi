#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

# The Return of Neptune: http://no-one.s53.xrea.com/
# patchworked by neo_otacky. for 바다전쟁 JS
#---------------------------------------------------------------------
# 뉴스모듈
#	메인 페이지에 공지사항을 표시하기 위한 기능입니다.
#---------------------------------------------------------------------
BEGIN {
	# Perl 5.004 이상이필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}
#---------------------------------------------------------------------
#	초기 설정
#---------------------------------------------------------------------
# 초기 설정용 파일을 읽기
require './hako-init.cgi';
require './hako-io.cgi';
require './init-game.cgi';

#----------------------------
#	HTML에 관한 설정
#----------------------------
# 브라우저의 제목막대의 명칭
$title = '모형정원 뉴스';

# 모험머리의 메시지(HTML 서식)
$headKill = <<"EOF";
<h1>$Htitle 뉴스(관리용)</h1>
EOF

#여기까지-------------------------------------------------------------

if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	close(PIN);
}
&cookieInput;
&cgiInput;

$HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : "${HtagBig_}<small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}";

if($HskinName ne '' ){
	$baseSKIN = $HskinName;
} else {
	$baseSKIN = "${HcssDir}/$HcssDefault";
}

if(!(&readIslandsFile())){
	&htmlHeader;
	&htmlError;
} else {
	if(!checkSpecialPassword($HdefaultPassword)) {
		&htmlHeader;
		tempWrongPassword(); # 비밀번호 불일치
		&htmlFooter;
		exit(0);
	}

	if($HmainMode eq 'news') {
		&newsMain;
	}
	&htmlHeader;
	out("<DIV align='center'>");
	out($headKill);
	# 헤더의 코멘트를 치환 가이 경우(hako-init.cgi 토연동)
	if($HlayoutTop) {
		&tempNews(0);
	} else {
		&tempNews(1);
	}
	out("</DIV>");
}
&htmlFooter;
#종료
exit(0);

# 서브 루틴---------------------------------------------------------
#--------------------------------------------------------------------
#	POST 또는 GET으로 입력된 데이터 가져오기
#--------------------------------------------------------------------
sub cgiInput {
	my($line, $getLine);
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9]{2})/pack(H2, $1)/eg;

	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};

	if($getLine =~ /pass=([^\&]*)/) {
		# 처음 시작
		$HdefaultPassword = htmlEscape($1);
	}
	if($line =~ /NewsComment=([^\&]*)\&/) {
		$HdefaultPassword = htmlEscape($1);
		$line =~ /LAYOUT=([0-9])\&/;
		$Hlayout = $1;
		$line =~ /TYPE=([0-9])\&/;
		$Htype = $1;
		$line =~ s/(.*)NEWS([0-9])=//g;
		$HnewsComment = $line;
		$HmainMode = 'news';
	}
}

#---------------------------------------------------------------------
#	함수명 : htmlHeader
#	기계 능 : HTML 의헤더 부분을 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlHeader {
	$baseIMG = $HimageDir;
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${HcssDir}/$HcssDefault";
	}
	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $Hgzip == 1){
		print qq{Content-type: text/html; charset=UTF-8\n};
		print qq{Content-encoding: gzip\n\n};
		open(STDOUT,"| $HpathGzip/gzip -1 -c");
		print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};
	}else{
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};
	}
	my $term = '';
	$term = ($HislandTurn < $HarmisticeTurn) ? "(~$HarmisticeTurn <small>휴전 기간</small>)" : ($HislandTurn == $HarmisticeTurn) ? '(<small>다음 턴부터 전투 기간</small>)' : '(<small>전투 기간</small>)' if($HarmisticeTurn);

	out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
<BASE HREF="$baseIMG/">
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$Body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
$Hheader
END

	my $nextturn = '';
	foreach (1..$HrepeatTurn) {
		$nextturn.= '·' if($_ != 1);
		$nextturn.= $HislandTurn + $_;
		last if($HislandTurn + $_ == $HarmisticeTurn || $HislandTurn + $_ == $HsurvivalTurn || $HislandTurn + $_ == $HislandChangeTurn);
	}
	out(<<END) if(defined $HleftTime);
<HR>
<H1 style="display:inline;"><SMALL><B>턴</B> </SMALL>$HislandTurn<SMALL>${term}</SMALL> </H1>
<span ID="REALTIME" class="timer"></span>
<SCRIPT language="JavaScript">
<!--
var leftTime = $HleftTime;
var hour, min, sec;

function showTimeLeft() {
	if (leftTime> 0) {
		setTimeout('showTimeLeft()', 1000);

		hour = Math.floor(leftTime / 3600);
		min = Math.floor(leftTime % 3600 / 60);
		sec = leftTime % 60;
		leftTime--;

		document.all.REALTIME.innerHTML = '다음 갱신(<span class="number">턴$nextturn</span>)까지 남은 ' + hour + '시간 ' + min + '분 ' + sec + '초 ($HnextTime)';
	} else {
		document.all.REALTIME.innerHTML = '턴 갱신 시각이 되었습니다! ($HnextTime)';
	}
}

if ($HplayNow) {
	showTimeLeft();
} else {
	document.all.REALTIME.innerHTML = '게임이 종료되었습니다!';
}
//-->
</SCRIPT>
END

	out(<<END);
<HR></DIV>
$HtempBack2
END
}
#---------------------------------------------------------------------
#	함수명 : htmlFooter
#	기계 능 : HTML 의푸터 부분을 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlFooter {
	out(<<END);
<HR>
<DIV ID='LinkFoot'>
$Hfooter
<BR></DIV>
END
##### 추가 친분20020307
	if($Hperformance) {
		my($uti, $sti, $cuti, $csti) = times();
		$uti += $cuti;
		$sti += $csti;
		my($cpu) = $uti + $sti;

	#	 로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
	#	 open(POUT,">>cpu-h.log");
	#	 print POUT "CPU($cpu) : user($uti) system($sti)\n";
	#	 close(POUT);

		out(<<END);
<DIV align="right">
<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
</DIV>
END
	}
#####
	out(<<END);
</DIV></BODY>
</HTML>
END
}
#---------------------------------------------------------------------
#	함수명 : htmlError
#	기계 능 : HTML 의오류 메시지의 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlError{
	out("<H2>오류가 발생했습니다</H2>\n");
}

sub tempNews {
	my($type) = @_;
	my $newsline;
	my $layout=0;
	if(-e $Hnewsfile) {
		open(NEWS, $Hnewsfile);
		$layout = <NEWS>;
		my @news = <NEWS>;
		close(NEWS);
		$newsline = join(/\n/, @news);
		chomp($newsline);
	}
	my @check = ();
	$check[$layout] = ' CHECKED';
	my $po =<<"END";
<INPUT TYPE="radio" NAME="LAYOUT" VALUE="0"$check[0]>헤더링크 바로 아래
<INPUT TYPE="radio" NAME="LAYOUT" VALUE="1"$check[1]>턴 표시직하
<INPUT TYPE="radio" NAME="LAYOUT" VALUE="2"$check[2]>푸터링크직상
END
	my $str = (!$type) ? 'NEWS : 레이아웃 기능사용' : $po;
	out(<<END);
<TABLE>
<TR></TR>
<FORM name="f$type" action="${HbaseDir}/hako-news.cgi" method="POST">
<TR><TD colspan=4><big><B>코멘트 변경($str)</B></big>
 <INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="NewsComment">
 <INPUT TYPE="hidden" VALUE="$type" NAME="TYPE">
 <INPUT TYPE="submit" VALUE="변경">
</TD></TR>
<TR><TD colspan=4>
<P ALIGN="center">
<TABLE BORDER=2><TR><TD style="border-style:inset;">
<textarea name="NEWS$type" cols=100 rows=20 WRAP="soft">$newsline</textarea><BR>
</TD></TR></TABLE>
↓↓↓ Preview ↓↓↓
<TABLE BORDER=2><TR><TD style="border-style:inset;">
<span ID="outputN$type"></span><br>
<SCRIPT LANGUAGE=javascript>
<!--
outputN${type}.setExpression("innerHTML","f${type}.NEWS${type}.value");
//-->
</SCRIPT>
</TD></TR></TABLE>
</TD>
</FORM>
</TR>
</TABLE>
END
}

sub newsMain {

	if(!checkSpecialPassword($HdefaultPassword)) {
		&htmlHeader;
		tempWrongPassword(); # 비밀번호 불일치
		&htmlFooter;
		exit(0);
	}
	if($HnewsComment eq '') {
		unlink($Hnewsfile) if(-e $Hnewsfile);
	} else {

		my $rn = "\n";
		$HnewsComment =~ s/\r$rn/$rn/eg;
		open(NEWS, ">$Hnewsfile");
		print NEWS $Hlayout. "\n";
		print NEWS $HnewsComment;
		close(NEWS);
	}
	$Hnews = $HnewsComment;
}
