#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 신규 작성모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 모형정원 제도 2nd
#								 v1.5
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							 모형정원 모형정원 바다전쟁
#								 v1.3
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#----------------------------------------------------------------------
# 섬 신규 생성 모드
#----------------------------------------------------------------------
# 메인
sub newIslandMain {
	my($mode) = @_;
	# 부정 접속을 확인
	if($HadminJoinOnly) {
		unless($ENV{HTTP_REFERER} =~ /^$HthisFile/) {
			unlock();
			tempHeader();
			tempNoReferer();
			return 0;
		}
	}
	# 섬 등록 가능 여부 확인
	if(
		($HislandNumber - $HbfieldNumber>= $HmaxIsland) ||
		($HsurvivalTurn && ($HislandTurn>= $HsurvivalTurn)) # 서바이벌 모드
		) {
		unlock();
		tempHeader();
		tempNewIslandFull();
		return 0;
	}

	# 섬 이름이 있는 지 확인
	if($HcurrentName eq '') {
		unlock();
		tempHeader();
		tempNewIslandNoName();
		return 0;
	}

	# 소유자 이름이 있는 지 확인
	if($HcurrentOwnerName eq '') {
		unlock();
		tempHeader();
		tempNewIslandNoOwnerName();
		return 0;
	}

	# 섬 이름이 유효한지 확인
	if($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인|^침몰$/) {
		# 사용 불가 이름
		unlock();
		tempHeader();
		tempNewIslandBadName();
		return 0;
	}

	# 소유자 이름이 유효한지 확인
	if($HcurrentOwnerName =~ /[,\?\(\)\<\>\$]/) {
		# 사용 불가 이름
		unlock();
		tempHeader();
		tempNewIslandBadOwnerName();
		return 0;
	}

	# 진영을 결정
	my($campNum);
	if($HarmisticeTurn && ($HallyNumber> 1)) {
		if($HcampSelectRule != 2 || $HcampNumber == -1) {
			$campNum = selectCamp();
		} else {
			$campNum = $HcampNumber;
			if ($Hally[$campNum]->{'number'}>= ($HmaxIsland / $HallyNumber)) {
				# 그 진영은 충족잔
				unlock();
				tempHeader();
				tempNewIslandFull();
				return 0;
			}
		}
	}
	# 이름의 중복 확인
	if(nameToNumber($HcurrentName) != -1) {
		# 이미 발견완료
		unlock();
		tempHeader();
		tempNewIslandAlready();
		return 0;
	}

	# password 의존재판정
	if($HinputPassword eq '') {
		# password 무시
		unlock();
		tempHeader();
		tempNewIslandNoPassword();
		return 0;
	}

	# 확인용 비밀번호
	if($HinputPassword2 ne $HinputPassword) {
		# 비밀번호 오류
		unlock();
		tempHeader();
		tempWrongPassword();
		return 0;
	}

	# ID 사용이회시
	my $safety = 100;
	while(defined $HidToNumber{$HislandNextID}) {
		$HislandNextID ++;
		$HislandNextID = 1 if($HislandNextID> 100);
		last if(!$safety--);
	}

	# 로그 파일조정
	logFileAdjust(-1, $HislandNextID);

#	readIslandsFile(-3);
	# 지형 데이터, 게시판조정
	islandFileAdjust(-1, $HislandNextID);

	# 새 섬의 번호 정하기
	$HcurrentNumber = $HislandNumber;
	$HislandNumber++;
	$islandNumber++;
	$Hislands[$HcurrentNumber] = makeNewIsland($mode);
	my($island) = $Hislands[$HcurrentNumber];

	# 각종의 값을 설정
	$island->{'name'} = $HcurrentName;
	$island->{'owner'} = $HcurrentOwnerName;
	$island->{'birthday'} = $HislandTurn;
	$island->{'id'} = $HislandNextID;
	$HislandNextID ++;
	$HislandNextID = 1 if($HislandNextID> 100);
	$island->{'absent'} = $HjoinGiveupTurn;
	$island->{'comment'} = $HjoinComment;
	$island->{'password'} = encode($HinputPassword);
	$island->{'comflag'} = $HcomflagUse % 2;
	# 인구기타 산출
	estimate($HcurrentNumber);

	if($HarmisticeTurn) {
		my $ally = $Hally[$campNum];
		$ally->{'score'} += $island->{$HrankKind} if(!$island->{'predelete'});
		foreach (@{$ally->{'memberId'}}) {
			push(@{$Hislands[$HidToNumber{$_}]->{'amity'}}, $island->{'id'});
			push(@{$island->{'amity'}}, $_);
		}
		push(@{$ally->{'memberId'}}, $island->{'id'});
		$ally->{'number'}++;
		push(@{$island->{'allyId'}}, $ally->{'id'});
	}

	# 데이터 쓰기
	$HidToNumber{$island->{'id'}} = $HcurrentNumber;
	islandSort($HrankKind, 1);
	if($HarmisticeTurn) {
		allyOccupy();
		allySort();
	}
	writeIslandsFile($island->{'id'});
	$HcurrentNumber = $HidToNumber{$island->{'id'}};
	$HcurrentName = islandName($island);
	logDiscover($HcurrentName, $HcurrentOwnerName); # 로그

	$HcurrentID = $HislandNextID - 1;
	$HmainMode = 'owner';
	$HjavaMode = 'java';

	return 1 if($mode);
	# COOKIE 출력
	cookieOutput();

	# 화면 출력
	unlock();

	# 발견 화면
	tempHeader();
	tempNewIslandHead($HcurrentName); # 발견되었습니다.
	islandInfo(); # 섬의 정보
	islandMap(1); # 섬 지도, 소유자 모드
}

# 섬 수가 가장 적고, 순위가 최하위의 진영
sub selectMinCamp {
	my($i, $num) = (0, 0);
	for ($i = 1; $i < $HallyNumber; $i++) {
		if ($Hally[$i]->{'number'} <= $Hally[$num]->{'number'}) {
			$num = $i;
		}
	}
	return $num;
}

# 무작위("전체 섬 수/진영 수+1"까지)
sub selectRandomCamp {
	return 0 if(!$HallyNumber);
	my($i, $j, $ave, $iave, @array, $len);
	# 빈칸 진영배열의 작성
	$ave = $HmaxIsland / $HallyNumber;
	$iave = int($ave);
	if ($iave != $ave) { $iave++; };
	for ($i = 0; $i < $HallyNumber; $i++) {
		for ($j = $Hally[$i]->{'number'}; $j < $iave; $j++) {
			push(@array, $i);
			$len++;
		}
	}
	return $array[int(rand($len))];
}

# 진영의 선택루틴(설정으로 변경)
sub selectCamp {
	if ($HcampSelectRule == 0) {
		return selectMinCamp();
	} elsif ($HcampSelectRule == 1) {
		return selectRandomCamp();
	} else {
		# 어디든 가능를 선택
		return selectRandomCamp();
	}
}
#---------------------------------------------------------------------
#	파일조정
#---------------------------------------------------------------------
sub logFileAdjust {
	my($oldId, $newId) = @_;

	for($i = 0; $i < $HlogMax; $i++) {
		open(LIN, "${HdirName}/$i$HlogData");
		open(LOUT, ">${HdirName}/${i}tmp$HlogData");
		my($line, $m, $turn, $id1, $id2, $id3, $message);
		while($line = <LIN>) {
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9\-]*),(.*)$/;
			($m, $turn, $id1, $id2, $id3, $message) = ($1, $2, $3, $4, $5, $6);
			next if($m eq '');
			$id1 = 0 if($id1 == $newId);
			$id2 = 0 if($id2 == $newId);
			$id3 = 0 if($id3 == $newId);
			$id1 = $newId if($id1 == $oldId);
			$id2 = $newId if($id2 == $oldId);
			$id3 = $newId if($id3 == $oldId);
			print LOUT "$m,$turn,$id1,$id2,$id3,$message\n";
		}
		close(LIN);
		close(LOUT);
		unlink("${HdirName}/$i$HlogData");
		rename("${HdirName}/${i}tmp$HlogData", "${HdirName}/$i$HlogData");
	}
}

sub islandFileAdjust {
	my($oldId, $newId) = @_;

	foreach $i (0..$islandNumber) {
		my($tIsland) = $Hislands[$i];
		my($tId) = $tIsland->{'id'};
		my($tLand)	 = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		my($tMap) = $tIsland->{'map'};
		my($x, $y);
		my $writeflag = 0;
		foreach $y (@{$tMap->{'y'}}) {
			foreach $x (@{$tMap->{'x'}}) {
				if ($tLand->[$x][$y] == $HlandNavy) {
					# 해군라면
					my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($tLandValue->[$x][$y]);
					if($nId == $newId){
						$Hislands[$i]->{'landValue'}->[$x][$y] = navyPack(0, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
						$writeflag = 1;
					}
					if($nId == $oldId){
						$Hislands[$i]->{'landValue'}->[$x][$y] = navyPack($newId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
						$writeflag = 1;
					}
				}
			}
		}

		my($lbbs, $line, $j);
		$lbbs = $tIsland->{'lbbs'};
		for($j = 0; $j < $HlbbsMax; $j++) {
			$line = $lbbs->[$j];
			if($line =~ /([0-9]*)\<(.*)\<(.*)\>(.*)\>(.*)$/) {
				my($kind, $message, $HlbbsName, $HlbbsMessage) = ($1, $3, $4, $5);
				my($sName, $sID) = split(/,/, $2);
				if($sID == $newId) {
					$Hislands[$i]->{'lbbs'}->[$j] = "$kind<$sName<$message>$HlbbsName>$HlbbsMessage";
					$writeflag = 1;
				}
				if($sID == $oldId) {
					$Hislands[$i]->{'lbbs'}->[$j] = "$kind<$sName,$newId<$message>$HlbbsName>$HlbbsMessage";
					$writeflag = 1;
				}
			}
		}
		# 데이터 쓰기
		writeIsland($tIsland, $tId, 0) if($writeflag);
	}
}

#---------------------------------------------------------------------
# 새 섬 만들기
#---------------------------------------------------------------------
sub makeNewIsland {
	my($mode) = @_;
	# 해역좌표
	my($wmap, $map);
	if($HoceanMode) {
		if(($HoceanSelect || $HmainMode eq 'bfield' || $HmainMode eq 'isetup') &&
			!$HmapRandom && $HoceanMapX ne '' && $HoceanMapY ne '' && !$HoceanMap[$HoceanMapX][$HoceanMapY]) {
			$wmap = { 'x' => $HoceanMapX, 'y' => $HoceanMapY };
		} else {
			$wmap = randomIslandMap(); # 섬의 좌표를 결하기
		}
		unless(defined $wmap) {
			unlock();
			tempHeader();
			tempNewIslandFull();
			return 0;
		}
	} else {
		$wmap = { 'x' => 0, 'y' => 0 };
	}
	# 지도배열
	my @x = (($wmap->{'x'} * $HislandSizeX)..($wmap->{'x'} * $HislandSizeX + $HislandSizeX - 1));
	my @y = (($wmap->{'y'} * $HislandSizeY)..($wmap->{'y'} * $HislandSizeY + $HislandSizeY - 1));
	$map = { 'x' => \@x, 'y' => \@y };
	# 지형을 만들기
	my($land, $landValue) = makeNewLand($wmap, $map, $mode);

	# 초기 명령을 생성
	my(@command, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		$command[$i] = {
			'kind' => $HcomDoNothing,
			'target' => 0,
			'x' => 0,
			'y' => 0,
			'arg' => 0,
			'target2' => 0
		};
	}

	# 초기 게시판 생성
	my @lbbs = ();

	# 격침 수카운터 설정
	my $n = @HnavyName;
	my(@navy) = ((0)x$n);

	# 확장 데이터 설정
	my(@ext) = ((0)x11); # 0~10
	# 확장하위 데이터 설정
	# ext 의승리 플래그[0]을 턴에변해서, 마지막에퇴치 수[11], 포상금[12]을 추가.
	my(@subExt) = ($HislandTurn, (0)x12); # 0~12

	# 날씨 초기 값
	my(@weather) = (20,1000,60,0,0,0,0);
	for($i = 0; $i < 4; $i++) {
		 push(@weather,'2');
	}

	# 섬으로 반환
	return {
		'map' => $map,
		'wmap' => $wmap,
		'land' => $land,
		'landValue' => $landValue,
		'command' => \@command,
		'lbbs' => \@lbbs,
		'money' => (!$HarmisticeTurn || !$HislandTurn ? $HinitialMoney : $HinitialMoney2),
		'food' => (!$HarmisticeTurn || !$HislandTurn ? $HinitialFood : $HinitialFood2),
		'prize' => '0,0,0,',
		'monsterkill' => 0,
		'monsterlive' => '0,0,0,0,0',
		'gain' => 0,
		'sink' => \@navy,
		'sinkself' => \@navy,
		'subSink' => \@navy,
		'subSinkself' => \@navy,
		'ext' => \@ext,
		'subExt' => \@subExt,
		'fight_id' => 0,
		'rest' => 0,
		'weather' => \@weather,
	};
}

# (0,0)에서(7, 7)까지의 숫자가한 번씩 나오도록
# (@rpx, @rpy)을 설정
sub makeRandomEightArray {
	undef @rpx;
	undef @rpy;
	# 초기 값
	@rpx = (0..7) x 8;
	foreach (0..7) {
		push(@rpy, ($_) x 8);
	}
	# 셔터 전체
	for ($i = 64; --$i; ) {
		my($j) = int(rand($i+1));
		next if($i == $j);
		@rpx[$i,$j] = @rpx[$j,$i];
		@rpy[$i,$j] = @rpy[$j,$i];
	}
}

# 새 섬 지형 만들기
sub makeNewLand {
	my($wmap, $map, $mode) = @_;
	# 기본형 생성
	my(@land, @landValue, $x, $y, $i);
	if($HoceanMode) {
		@land = @{$Hworld->{'land'}};
		@landValue = @{$Hworld->{'landValue'}};
	}
	# 바다에 초기화
	foreach $y (@{$map->{'y'}}) {
		foreach $x (@{$map->{'x'}}) {
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 0;
		}
	}
	return (\@land, \@landValue) if($mode);
	# 중앙의4*4에황무지(평지)를 배치
	my($centerX) = $wmap->{'x'}*$HislandSizeX + int($HislandSizeX / 2) - 1;
	my($centerY) = $wmap->{'y'}*$HislandSizeY + int($HislandSizeY / 2) - 1;
	for($y = $centerY - 1; $y < $centerY + 3; $y++) {
		for($x = $centerX - 1; $x < $centerX + 3; $x++) {
			$land[$x][$y] = (!$HnewIslandSetting) ? $HlandWaste : $HlandPlains;
		}
	}
	my($count);
	if(!$HnewIslandSetting) {
		# 8*8범위내에육지를 증식
		foreach $i (1..120) {
			# 무작위좌표
			$x = random(8) + $centerX - 3;
			$y = random(8) + $centerY - 3;

			if(countAroundforMake(\@land, $x, $y, 7, $HlandSea) != 7){
				# 주변에 육지가 있는 경우, 얕은 바다로
				# 얕은 바다는 황무지로
				# 황무지는 평지로
				if($land[$x][$y] == $HlandWaste) {
					$land[$x][$y] = $HlandPlains;
					$landValue[$x][$y] = 0;
				} else {
					if($landValue[$x][$y] == 1) {
						$land[$x][$y] = $HlandWaste;
						$landValue[$x][$y] = 0;
					} elsif($land[$x][$y] == $HlandSea) {
						$landValue[$x][$y] = 1;
					}
				}
			}
		}
	} else {
		# 평지를 만들기
		makeRandomEightArray();
		$count = 0;
		$HcountLandArea -= 16;
		foreach $i (0..63) {
			last if($count>= $HcountLandArea);
			# 무작위좌표
			$x = $rpx[$i] + $centerX - 3;
			$y = $rpy[$i] + $centerY - 3;

			# 그곳이 바다에서 또한주변에육이 있다면, 평지를 만들기
			if(($land[$x][$y] == $HlandSea) && (countAroundforMake(\@land, $x, $y, 7, $HlandSea) != 7)) {
				$land[$x][$y] = $HlandPlains;
				$landValue[$x][$y] = 0;
				$count++;
			}
		}

		# 얕은 바다를 만들기
		makeRandomEightArray();
		$count = 0;
		foreach $i (0..63) {
			last if($count>= $HcountLandSea);
			# 무작위좌표
			$x = $rpx[$i] + $centerX - 3;
			$y = $rpy[$i] + $centerY - 3;

			# 그곳이 바다에서 또한주변에육이 있다면, 얕은 바다를 만들기
			if(($land[$x][$y] == $HlandSea) && !$landValue[$x][$y] && (countAroundforMake(\@land, $x, $y, 7, $HlandSea) != 7)) {
				$landValue[$x][$y] = 1;
				$count++;
			}
		}

		# 황무지를 만들기
		makeRandomEightArray();
		$count = 0;
		foreach $i (0..63) {
			last if($count>= $HcountLandWaste);
			# 무작위좌표
			$x = $rpx[$i] + $centerX - 3;
			$y = $rpy[$i] + $centerY - 3;

			# 그곳이이미평지라면, 황무지를 만들기
			if($land[$x][$y] == $HlandPlains) {
				$land[$x][$y] = $HlandWaste;
				$count++;
			}
		}
	}

	# 읍을 만들기
	makeRandomEightArray();
	$count = 0;
	foreach $i (0..63) {
		last if($count>= $HcountLandTown);
		# 무작위좌표
		$x = $rpx[$i] + $centerX - 3;
		$y = $rpy[$i] + $centerY - 3;

		# 해당 지점이 평지라면 마을 만들기
		if($land[$x][$y] == $HlandPlains) {
			$land[$x][$y] = $HlandTown;
			$landValue[$x][$y] = $HvalueLandTown; # 처음은500인
			$count++;
		}
	}

	# 숲을 만들기
	makeRandomEightArray();
	$count = 0;
	foreach $i (0..63) {
		last if($count>= $HcountLandForest);
		# 무작위좌표
		$x = $rpx[$i] + $centerX - 3;
		$y = $rpy[$i] + $centerY - 3;

		# 그곳이평지라면, 숲을 만들기
		if($land[$x][$y] == $HlandPlains) {
			$land[$x][$y] = $HlandForest;
			$landValue[$x][$y] = $HvalueLandForest; # 처음은500본
			# 복합 지형(숲)
#			$land[$x][$y] = $HlandComplex;
#			$landValue[$x][$y] = landPack(0, 3, 1, 0, 0); # 처음은100본
			$count++;
		}
	}

	# 산을 만들기
	makeRandomEightArray();
	$count = 0;
	foreach $i (0..63) {
		last if($count>= $HcountLandMountain);
		# 무작위좌표
		$x = $rpx[$i] + $centerX - 3;
		$y = $rpy[$i] + $centerY - 3;

		# 그곳이평지라면, 산을 만들기
		if($land[$x][$y] == $HlandPlains) {
			$land[$x][$y] = $HlandMountain;
			$landValue[$x][$y] = $HvalueLandMountain; # 처음은 채굴장없음
			$count++;
		}
	}

	# 군항을 만들기
	makeRandomEightArray();
	$count = 0;
	foreach $i (0..63) {
		last if($count>= $HcountLandPort);
		# 무작위좌표
		$x = $rpx[$i] + $centerX - 3;
		$y = $rpy[$i] + $centerY - 3;

		# 그곳이얕은 바다라면, 군항을 만들기
		if(($land[$x][$y] == $HlandSea) && $landValue[$x][$y]) {
			$land[$x][$y] = $HlandNavy;
			$landValue[$x][$y] = navyPack($HislandNextID, 0, 0, 0, 0, 0, 0, 0, $HnavyHP[0]);
			$count++;
		}
	}

	if ($HuseBase) {
		# 기지를 만들기
		makeRandomEightArray();
		$count = 0;
		foreach $i (0..63) {
			last if($count>= $HcountLandBase);
			# 무작위좌표
			$x = $rpx[$i] + $centerX - 3;
			$y = $rpy[$i] + $centerY - 3;

			# 그곳이평지라면, 기지
			if($land[$x][$y] == $HlandPlains) {
				$land[$x][$y] = $HlandBase;
				$landValue[$x][$y] = 0;
				$count++;
			}
		}
	}

	if($HoceanMode) {
		$Hworld->{'land'} = \@land;
		$Hworld->{'landValue'} = \@landValue;
	}
	return (\@land, \@landValue);
}

#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeMain {
	# id에서 섬을 가져옴
	readIsland
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($flag) = 0;

	# 비밀번호 확인
	if(checkSpecialPassword($HoldPassword)) {
		# 특수 비밀번호
		if($HcurrentName =~ /^로그$/) {
			# 최근 사건강제출력
			logPrintHtml();
			unlock();
			tempChange();
			return;
		} elsif($HcurrentName =~ /^무인$/) {
			# 섬 삭제 모드
			deleteIsland(1);
			return;
		} elsif($HcurrentName =~ /^침몰$/) {
			# 섬 삭제 모드
			deleteIsland(0);
			return;
		} elsif(!checkMasterPassword($HoldPassword)) {
			# 식량/자금 max 모드
			$island->{'money'} = $HmaximumMoney;
			$island->{'food'} = $HmaximumFood;
			$flag = 1;
		}
	} elsif(!checkPassword($island,$HoldPassword)) {
		# 비밀번호 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 확인용 비밀번호
	if($HinputPassword2 ne $HinputPassword) {
		# 비밀번호 오류
		unlock();
		tempWrongPassword();
		return;
	}

	if($HcurrentName ne '') {
		# 섬 이름 변경의 경우
		# 섬 이름이 유효한지 확인
		if($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인|^침몰$/) {
			# 사용 불가 이름
			unlock();
			tempNewIslandBadName();
			return;
		}

		# 이름의 중복 확인
		if(nameToNumber($HcurrentName) != -1) {
			# 이미 발견완료
			unlock();
			tempNewIslandAlready();
			return;
		}

		# 대금
		unless(checkSpecialPassword($HoldPassword)) {
			if($island->{'money'} < $HcostChangeName) {
				#자금 부족
				unlock();
				tempChangeNoMoney();
				return;
			}
			$island->{'money'} -= $HcostChangeName;
		}

		# 이름을 변경
		logChangeName($island->{'name'}, $HcurrentName);
		$island->{'name'} = $HcurrentName;
		$flag = 1;
		my $n = $HidToAllyNumber{$HcurrentID};
		if(defined $n) {
			$Hally[$n]->{'oName'} = $HcurrentName;
		}
	}

	if ($HcurrentOwnerName ne '') {
		# 소유자 이름 변경의 경우
		# 소유자 이름이 유효한지 확인
		if($HcurrentOwnerName =~ /[,\?\(\)\<\>\$]/) {
			# 사용 불가 이름
			unlock();
			tempNewIslandBadOwnerName();
			return;
		}

		# 대금
		unless(checkSpecialPassword($HoldPassword)) {
			if($island->{'money'} < $HcostChangeName) {
				#자금 부족
				unlock();
				tempChangeNoMoney();
				return;
			}
			$island->{'money'} -= $HcostChangeName;
		}

		# 이름을 변경
		logChangeOwnerName($island->{'name'}, $HcurrentOwnerName);
		$island->{'owner'} = $HcurrentOwnerName;
		$flag = 1;
	}

	# password 변경의 경우
	if($HinputPassword ne '') {
		# 비밀번호를 변경
		$island->{'password'} = encode($HinputPassword);
		$flag = 1;
		my $n = $HidToAllyNumber{$HcurrentID};
		if(defined $n) {
			$Hally[$n]->{'password'} = encode($HinputPassword);
		}
	}

	if($flag == 0) {
		# 어느 쪽도 변경되어 있지 않음
		unlock();
		tempChangeNothing();
		return;
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);
	unlock();

	# 변경 성공
	tempChange();
}

#----------------------------------------------------------------------
# 새 섬을 탐색
#----------------------------------------------------------------------
# 메인
sub newIslandTop {
	# 화면 출력
	unlock();

	# 관리자만 새 섬을 탐색하게 함?
	if ($HadminJoinOnly) {
		# 마스터 비밀번호 확인
		unless (checkMasterPassword($HinputPassword)) {
			# 비밀번호 오류
			tempWrongPassword();
			return;
		}
	}

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='newIsland'>
$HPoliciesDisclaimers
<H1>새 ${AfterName}을 탐색</H1>
END

	if(($HislandNumber - $HbfieldNumber < $HmaxIsland) && ($HmaxIsland <= 100) && (!$HarmisticeTurn || $HallyNumber)) {
		if($HoceanMode && $HoceanSelect) {
			readIslandsFile(0);
			printIslandMapMain(3);
		}
		out(<<END);
<FORM action="$HthisFile" name="JoinForm" method="POST">
END
		if($HoceanMode && $HoceanSelect) {
			out(<<END);
해역좌표를 지정해 주세요<BR>좌표(
<SELECT NAME="OCEANX">
END
			my($i);
			foreach $i (0..($HoceanSizeX-1)) {
				out("<OPTION VALUE=$i>$i\n");
			}
			out(<<END);
</SELECT>, <SELECT NAME="OCEANY">
END
			foreach $i (0..($HoceanSizeY-1)) {
				out("<OPTION VALUE=$i>$i\n");
			}
			out(<<END);
</SELECT>) <INPUT TYPE=CHECKBOX name='RANDOM' VALUE='1'>무작위<BR><BR>
END
		}
		if ($HarmisticeTurn && ($HcampSelectRule == 2) && $HallyNumber) {
			my $allyList;
			foreach (0..$#Hally) {
				next if ($Hally[$_]->{'number'}>= ($HmaxIsland / $HallyNumber));
				my $s = '';
				$s = ' SELECTED' if($_ == 0);
				$allyList.= "<OPTION VALUE=\"$_\"$s>$Hally[$_]->{'name'}\n";
			}
			out(<<END);
진영 이름을 선택해 주세요<BR>
<SELECT NAME="CAMPNUMBER">
$allyList
<OPTION VALUE=\"-1\">어디든 가능
</SELECT><BR>
END
		}

		$HjoinNewIslandButton = '찾으러 가기' if(!$HjoinNewIslandButton);
		out(<<END);
섬 이름<small>(최대 ${HlengthIslandName}자)</small><BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>${AfterName}<BR>
당신의 이름은?<small>(최대 ${HlengthOwnerName}자)</small><BR>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32 class=f><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32 class=f><BR>
<BR>
<INPUT TYPE="submit" VALUE="$HjoinNewIslandButton" NAME="NewIslandButton">
</FORM>
</DIV>
END
	} else {
	out(<<END);
		${AfterName}의 수가 최대 수입니다... 현재 등록할 수 없습니다.
</DIV>
END
	}
}

#----------------------------------------------------------------------
# 정보 변경
#----------------------------------------------------------------------
# 메인
sub renameIslandMain {
	# 화면 출력
	unlock();

	my($str);
	$str = "<BR>또한, '진영 비밀번호'에서는 비밀번호를 변경할 수 없습니다." if($HarmisticeTurn);
	$str = '<BR>진영 위임 임시 상태인 섬은 각 턴에 설정된 진영 비밀번호를 사용합니다.<BR>비밀번호 변경이 필요하면 관리자에게 연락하세요.' if($HarmisticeTurn && !$HpassChangeOK);
	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='changeInfo'>
<H1>정보 변경</H1>
<table border=0 width=50%><tr><td class="M"><P>
<span class='attention'>(주의)</span><BR>
 이름 변경에는 ${HtagMoney_}$HcostChangeName${HunitMoney}${H_tagMoney}이 들어갑니다.$str
</P>
<FORM action="$HthisFile" method="POST">
어느 ${AfterName}입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
새 이름을 입력하세요(변경하는 경우만)<small>(최대 ${HlengthIslandName}자)</small><BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>${AfterName}<BR>
당신의 이름을 변경할까요?(변경하는 경우만)<small>(최대 ${HlengthOwnerName}자)</small><BR>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32 class=f><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32 class=f><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32 class=f><BR>

<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
</FORM>
</td></tr></table></DIV>
END
}

# 섬 이름으로 번호를 얻음(ID가 아니라 번호)
sub nameToNumber {
	my($name) = @_;

	# 전체 섬에 서 찾기
	my($i);
	foreach $i (0..$islandNumber) {
		if($Hislands[$i]->{'name'} eq $name) {
			return $i;
		}
	}

	# 찾을 수 없었던 경우
	return -1;
}

# 동맹 이름에서 ID 을얻기루
sub aNameToId {
	my($name) = @_;

	# 전체 섬에 서 찾기
	my($i);
	for($i = 0; $i < $HallyNumber; $i++) {
		if($Hally[$i]->{'name'} eq $name) {
			return $Hally[$i]->{'id'};
		}
	}

	# 찾을 수 없었던 경우
	return -1;
}

# 동맹의 표시에서 ID 을얻기루
sub aMarkToId {
	my($mark) = @_;

	# 전체 섬에 서 찾기
	my($i);
	for($i = 0; $i < $HallyNumber; $i++) {
		if($Hally[$i]->{'mark'} eq $mark) {
			return $Hally[$i]->{'id'};
		}
	}

	# 찾을 수 없었던 경우
	return -1;
}

#----------------------------------------------------------------------
# 동맹의 신규 작성 모드
#----------------------------------------------------------------------
# 결성·변경 메인
sub makeAllyMain {

	my $adminMode = 0;
	# 비밀번호 확인
	if(checkSpecialPassword($HoldPassword)) {
		$adminMode = 1;
		if($HallyID> 200) {
			my $max = $HallyID;
			if($HallyNumber) {
				foreach (0..$#Hally) {
					$max = $Hally[$_]->{'id'} + 1 if($max <= $Hally[$_]->{'id'});
				}
			}
			$HcurrentID = $max;
		} elsif(defined $HcurrentAnumber) {
			my $ally = $Hally[$HcurrentAnumber];
			$HcurrentID = $ally->{'id'};
			my $wflag = 0;
			if($HallyID eq '0') {
				$wflag = 1;
				my $max = 200;
				if($HallyNumber) {
					foreach (0..$#Hally) {
						$max = $Hally[$_]->{'id'} + 1 if($max <= $Hally[$_]->{'id'});
					}
				}
				$HcurrentID = $max;
				$ally->{'id'} = $HcurrentID;
				$ally->{'oName'} = "";
			} elsif(($ally->{'name'} ne $HallyName) || ($ally->{'mark'} ne $HallyMark) || ($ally->{'color'} ne "#${HallyColor}")) {
				$wflag = 1;
				if((defined $HidToNumber{$HallyID}) && ($HcurrentID != $HallyID)) {
					$ally->{'id'} = $HallyID;
					$ally->{'oName'} = $Hislands[$HidToNumber{$HallyID}]->{'name'};
				}
				$ally->{'name'} = $HallyName;
				$ally->{'mark'} = $HallyMark;
				$ally->{'color'} = "#${HallyColor}";
			} elsif($HcurrentID != $HallyID) {
				$wflag = 1;
				$ally->{'id'} = $HallyID;
				$ally->{'oName'} = $Hislands[$HidToNumber{$HallyID}]->{'name'};
			}
			if($wflag) {
				# 동맹 데이터의 쓰기
				writeAllyFile() if($HallyUse || $HarmisticeTurn);
				$HislandList = getIslandList($HcurrentID, 0);

				# 화면 출력
				unlock();
				# 맨 위로
				topPageMain();
				return;
			}
		} else {
			unlock();
			out("${HtagBig_}결성 또는 변경할 수 없습니다.${H_tagBig}$HtempBack");
			return;
		}
	}

	# 동맹 이름이 있는 지 확인
	if($HallyName eq '') {
		unlock();
		$AfterName = '동맹';
		tempNewIslandNoName();
		return;
	}

	# 동맹 이름이 유효한지 확인
	if($HallyName =~ /[,\?\(\)\<\>\$]|^무인|^침몰$/) {
		# 사용 불가 이름
		unlock();
		tempNewIslandBadOwnerName();
		return;
	}
	# 이름의 중복 확인
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	if(!($adminMode && ($HallyID ne '') && ($HallyID < 200)) &&
		((nameToNumber($HallyName) != -1) ||
		((aNameToId($HallyName) != -1) && (aNameToId($HallyName) != $HcurrentID)))) {
		# 이미 결성 완료
		unlock();
		tempNewAllyAlready();
		return;
	}

	# 표시의 중복 확인
	if(!($adminMode && ($HallyID ne '') && ($HallyID < 200)) &&
		((aMarkToId($HallyMark) != -1) && (aMarkToId($HallyMark) != $HcurrentID))) {
		# 이미사용완료
		unlock();
		tempMarkAllyAlready();
		return;
	}

	# password 의판정
	my($island) = $Hislands[$HcurrentNumber];
	if(!$adminMode && !checkPassword($island,$HinputPassword)) {
		unlock();
		tempWrongPassword();
		return;
	}
	if(!$adminMode && $island->{'money'} < $HcostMakeAlly) {
		unlock();
		tempNoMoney();
		return;
	}
	my $n = $HidToAllyNumber{$HcurrentID};
	if(defined $n) {
		if($adminMode && ($HallyID ne '') && ($HallyID < 200)) {
			my $allyMember = $Hally[$n]->{'memberId'};
			my $aIsland = $Hislands[$HidToNumber{$HallyID}];
			my $flag = 0;
			foreach (@$allyMember) {
				if($_ == $HallyID) {
					$flag = 1;
					last;
				}
			}
			if(!$flag) {
				$flag = 2 if(@{$aIsland->{'allyId'}}[0] eq '');
			}
			if(!$flag) {
				unlock();
				out("${HtagBig_}변경할 수 없습니다.${H_tagBig}$HtempBack");
				return;
			}
			$Hally[$n]->{'id'} = $HallyID;
			$Hally[$n]->{'oName'} = $aIsland->{'name'};
			if($flag == 2) {
				$Hally[$n]->{'password'} = $aIsland->{'password'};
				$Hally[$n]->{'score'} = $aIsland->{$HrankKind} if(!$aIsland->{'predelete'});
				$Hally[$n]->{'number'}++;
				push(@{$Hally[$n]->{'memberId'}}, $aIsland->{'id'});
				push(@{$aIsland->{'allyId'}}, $aIsland->{'id'});
			}
		} else {
			# 이미 결성 완료이면 변경
			logChangeAlly($Hally[$n]->{'name'}, $HallyName) if(!$adminMode && ($Hally[$n]->{'name'} ne $HallyName));
		}
	} else {
		# 다른 섬의 동맹에 가입한 경우에는 결성할 수 없습니다
		my $flag = 0;
		for ($i = 0; $i < $HallyNumber; $i++) {
			my $allyMember = $Hally[$i]->{'memberId'};
			foreach (@$allyMember) {
				if($_ == $HcurrentID) {
					$flag = 1;
					last;
				}
			}
			last if($flag);
		}
		if($flag) {
			unlock();
			tempOtherAlready();
			return;
		}

		# 신규
		$n = $HallyNumber;
		$Hally[$n]->{'id'} = $HcurrentID;
		my @memberId = ();
	 if($HallyID < 200) {
			$Hally[$n]->{'oName'} = $island->{'name'};
			$Hally[$n]->{'password'} = $island->{'password'};
			$Hally[$n]->{'number'} = 1;
			@memberId = ($HcurrentID);
			$Hally[$n]->{'score'} = $island->{$HrankKind} if(!$island->{'predelete'});
		} else {
			$Hally[$n]->{'oName'} = '';
			$Hally[$n]->{'password'} = encode($HinputPassword);
			$Hally[$n]->{'number'} = 0;
			$Hally[$n]->{'score'} = 0;
		}
		$Hally[$n]->{'Takayan'} = makeRandomString();
		$Hally[$n]->{'occupation'} = 0;
		$Hally[$n]->{'memberId'} = \@memberId;
		$island->{'allyId'} = \@memberId;
		my @ext = (0, 0, 0, 0, 0);
		$Hally[$n]->{'ext'} = \@ext;
		$HidToAllyNumber{$HcurrentID} = $n;
		$HallyNumber++;
		logMakeAlly($HallyName, islandName($island)) if(!$adminMode); # 로그
	}

	# 동맹의 각종의 값을 설정
	$Hally[$n]->{'name'} = $HallyName;
	$Hally[$n]->{'mark'} = $HallyMark;
	$Hally[$n]->{'color'} = "#${HallyColor}";

	# 비용을 계산
	$island->{'money'} -= $HcostMakeAlly if(!$adminMode);
	# 데이터 쓰기
	allyOccupy();
	allySort();
	writeIslandsFile();
	$HislandList = getIslandList($HcurrentID, 0);

	# 화면 출력
	unlock();
	# 맨 위로
	topPageMain();
}

# 이미그 이름의 동맹이 있는 경우
sub tempNewAllyAlready {
	out(<<END);
${HtagBig_}그 동맹이면 이미 결성되어 있습니다.${H_tagBig}$HtempBack
END
}

# 이미그 표시의 동맹이 있는 경우
sub tempMarkAllyAlready {
	out(<<END);
${HtagBig_}그 표시예미사용되 있습니다.${H_tagBig}$HtempBack
END
}

# 다른 동맹을 결성하고 있는
sub tempLeaderAlready {
	out(<<END);
${HtagBig_}맹주는, 자신의 동맹 이외에는 가입할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 이미 다른 동맹에 가입한 경우
sub tempOtherAlready {
	out(<<END);
${HtagBig_}하나의 동맹에만 가입할 수 없습니다.${H_tagBig}$HtempBack
END
}

#자금 부족
sub tempNoMoney {
	out(<<END);
${HtagBig_}자금 부족입니다(/_<.)${H_tagBig}$HtempBack
END
}
# 해산
sub deleteAllyMain {

	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my $n = $HidToAllyNumber{$HcurrentID};
	my $adminMode = 0;
	# 비밀번호 확인
	if(checkSpecialPassword($HoldPassword)) {
		$n = $HcurrentAnumber;
		$HcurrentID = $Hally[$n]->{'id'};
		$adminMode = 1;
	} else {
		# password 의판정
		if(!checkPassword($island,$HinputPassword)) {
			unlock();
			tempWrongPassword();
			return;
		}
		if(!checkPassword($Hally[$n],$HinputPassword)) {
			unlock();
			tempWrongPassword();
			return;
		}
		# 안전 확인용 ID도 확인
		if($Hally[$n]->{'id'} != $HcurrentID) {
			unlock();
			tempWrongAlly();
			return;
		}
	}
	my $allyMember = $Hally[$n]->{'memberId'};
	if($adminMode && $HarmisticeTurn && ((@{$allyMember}[0] ne '') || !(defined $n))){
		unlock();
		out("${HtagBig_}삭제할 수 없습니다.${H_tagBig}$HtempBack");
		return;
	}
	foreach (@$allyMember) {
		my($island, $aId, @newId);
		$island = $Hislands[$HidToNumber{$_}];
		@newId = ();
		foreach $aId (@{$island->{'allyId'}}) {
			if($aId != $HcurrentID) {
				push(@newId, $aId);
			}
		}
		$island->{'allyId'} = \@newId;
	}
	logDeleteAlly($Hally[$n]->{'name'}) if(!$adminMode);
	$Hally[$n]->{'dead'} = 1;
	$HidToAllyNumber{$HcurrentID} = undef;
	$HallyNumber--;
	# 데이터 쓰기
	allyOccupy();
	allySort();
	writeIslandsFile();
	$HislandList = getIslandList($HcurrentID, 0);

	# 화면 출력
	unlock();
	# 맨 위로
	topPageMain();
}

# ID 확인에히걸립니다
sub tempWrongAlly {
	out(<<END);
${HtagBig_}당신은 맹주가 아닌 것으로 보입니다.${H_tagBig}$HtempBack
END
}

# 가입·탈퇴
sub joinAllyMain {

	# password 의판정
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	if(!checkPassword($island,$HinputPassword)) {
		unlock();
		tempWrongPassword();
		return;
	}
	if(defined $HidToAllyNumber{$HcurrentID}) {
		unlock();
		tempLeaderAlready();
		return;
	}
	my $ally = $Hally[$HcurrentAnumber];
	if($HallyJoinOne && ($island->{'allyId'}[0] ne '') && ($island->{'allyId'}[0] != $ally->{'id'})) {
		unlock();
		tempOtherAlready();
		return;
	}
	if(!$ally->{'vkind'}) {
		foreach(@{$ally->{'vetoId'}}) {
			if($island->{'id'} == $_) {
				unlock();
				logAllyVeto();
				return;
			}
		}
	} else {
		my $vflag = 1;
		foreach(@{$ally->{'vetoId'}}) {
			if($island->{'id'} == $_) {
				$vflag = 0;
				break;
			}
		}
		if($vflag) {
			unlock();
			logAllyVeto();
			return;
		}
	}
	my $allyMember = $ally->{'memberId'};
	my @newAllyMember = ();
	my $flag = 0;
	foreach (@$allyMember) {
		if(!(defined $HidToNumber{$_})) {
		} elsif($_ == $HcurrentID) {
			$flag = 1;
		} else {
			push(@newAllyMember, $_);
		}
	}
	my $allyNum = @newAllyMember;
	if($flag) {
		logAllyEnd(islandName($island), $ally->{'name'});
		my @newAlly = ();
		foreach (@{$island->{'allyId'}}) {
			if($_ != $ally->{'id'}) {
				push(@newAlly, $_);
			}
		}
		$island->{'allyId'} = \@newAlly;
		$ally->{'score'} -= $island->{$HrankKind} if(!$island->{'predelete'});
		$ally->{'number'}--;
	} else {
		if(!$HallyMax || $allyNum < $HallyMax) {
			logAlly(islandName($island), $ally->{'name'});
			push(@newAllyMember, $HcurrentID);
			push(@{$island->{'allyId'}}, $ally->{'id'});
			$ally->{'score'} += $island->{$HrankKind} if(!$island->{'predelete'});
			$ally->{'number'}++;
		} else {
			# 화면 출력
			unlock();
			logAllyMaxOver();
			exit(0);
		}
	}
	$island->{'money'} -= $HcomCost[$HcomAlly];
	$ally->{'memberId'} = \@newAllyMember;
	# 데이터 쓰기
	allyOccupy();
	allySort();
	writeIslandsFile();
	$HislandList = getIslandList($HcurrentID, 0);

	# 화면 출력
	unlock();
	# 맨 위로
	topPageMain();
}

# 결성
sub logMakeAlly {
	my($name, $owner) = @_;
	logHistory("동맹 '${HtagName_}${name}${H_tagName}'이 ${HtagName_}${owner}${H_tagName}에 의해 ${HtagNumber_}결성${H_tagNumber}되었습니다.");
}

# 변경
sub logChangeAlly {
	my($oldname, $newname) = @_;
	logHistory("동맹'${HtagName_}${oldname}${H_tagName}'이'${HtagName_}${newname}${H_tagName}'에명칭 변경.");
}

# 해산
sub logDeleteAlly {
	my($name) = @_;
	logHistory("동맹 '${HtagName_}${name}${H_tagName}'이${HtagDisaster_}해산!${H_tagDisaster}");
}

# 가입
sub logAlly {
	my($name, $allyName) = @_;
	logHistory("${HtagName_}${name}${H_tagName}이'${HtagName_}${allyName}${H_tagName}'에${HtagNumber_}가입${H_tagNumber}.");
}

# 탈퇴
sub logAllyEnd {
	my($name, $allyName) = @_;
	logHistory("${HtagName_}${name}${H_tagName}이'${HtagName_}${allyName}${H_tagName}'에서${HtagDisaster_}탈퇴!${H_tagDisaster}");
}

# 동맹 가입 가능 섬 수 초과
sub logAllyMaxOver {
	out(<<END);
${HtagBig_}가입 신청이 폐기되었습니다.(동맹 가입 가능 ${AfterName} 수 초과)${H_tagBig}$HtempBack
END
}

# 동맹 가입거부
sub logAllyVeto {
	out(<<END);
${HtagBig_}가입 신청이 폐기되었습니다.(거부 권한 행사)${H_tagBig}$HtempBack
END
}
#----------------------------------------------------------------------
# 동맹의 결성·변경·해산·가입·탈퇴
#----------------------------------------------------------------------
# 결성·변경·해산·가입·탈퇴
sub newAllyTop {

	my $adminMode = 0;
	my $HtempBack2 = $HtempBack;
	# 비밀번호 확인
	if(checkSpecialPassword($HdefaultPassword)) {
		$adminMode = 1;
		$HislandList = getIslandList($Hislands[$HbfieldNumber]->{'id'}, 1);
		$HtempBack2 = "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}";
	} elsif(!$HallyUse) {
		require('./hako-top.cgi');
		topPageMain();
	}
	# 화면 출력
	unlock();
	my($jsIslandList, $name, $id, $i);
	foreach $i (0..$islandNumber) {
		$name = $Hislands[$i]->{'name'};
		$name =~ s/'/\\'/g;
		$id = $Hislands[$i]->{'id'};
		$jsIslandList.= "island[$id] = '$name'\;\n";
	}
	my($allyname, $markList, @colorList, @allycolor, $allyList,
		$jsAllyList, $jsAllyIdList, $jsAllyMarkList, $jsAllyColorList);
	my($defaultMark, $defaultAllyId);
	my $n = $HidToAllyNumber{$defaultID};
	if($n eq '') {
		$allyname = '';
		$defaultMark = $Hally[0];
		$defaultAllyId= '';
	} else {
		$allyname = $Hally[$n]->{'name'};
		$allyname =~ s/'/\\'/g;
		$defaultMark = $Hally[$n]->{'mark'};
		$defaultAllyId = $Hally[$n]->{'id'};
	}
	foreach (0..$#HallyMark) {
		my $s = '';
		$s = ' SELECTED' if($HallyMark[$_] eq $defaultMark);
		$markList.= "<OPTION VALUE=\"$HallyMark[$_]\"$s>$HallyMark[$_]\n"
	}
	foreach $i (1..6) {
		if($n eq '') {
			$allycolor[$i] = 0;
		} else {
			$allycolor[$i] = substr($Hally[$n]->{'color'}, $i, 1);
		}
		foreach (0..9,A..F) {
			my $s = '';
			$s = ' SELECTED' if($_ eq $allycolor[$i]);
			$colorList[$i].= "<OPTION VALUE=\"$_\"$s>$_\n"
		}
	}
	my $max = 201;
	if($HallyNumber) {
		$jsAllyList = "ally = [";
		$jsAllyIdList = "allyID = [";
		$jsAllyMarkList = "allyMark = [";
		$jsAllyColorList = "allyColor = [";
		foreach (0..$#Hally) {
			my $s = '';
			$s = ' SELECTED' if($Hally[$_]->{'id'} == $defaultAllyId);
			$allyList.= "<OPTION VALUE=\"$_\"$s>$Hally[$_]->{'name'}\n";
			$jsAllyList.= "'$Hally[$_]->{'name'}'";
			$jsAllyIdList.= "$Hally[$_]->{'id'}";
			$jsAllyMarkList.= "'$Hally[$_]->{'mark'}'";
			$jsAllyColorList.= "[";
			foreach $i (1..6) {
				$jsAllyColorList.= '\''. substr($Hally[$_]->{'color'}, $i, 1). '\'';
				$jsAllyColorList.= ',' if($i < 6);
			}
			$jsAllyColorList.= "]";
			if($_ < $#Hally) {
				$jsAllyList.= ",\n";
				$jsAllyIdList.= ",\n";
				$jsAllyMarkList.= ",\n";
				$jsAllyColorList.= ",\n";
			}
			$max = $Hally[$_]->{'id'} + 1 if($max <= $Hally[$_]->{'id'});
		}
		$jsAllyList.= "];\n";
		$jsAllyIdList.= "];\n";
		$jsAllyMarkList.= "];\n";
		$jsAllyColorList.= "];\n";
	}
	my $str1 = $adminMode ? '(점검)' : $HallyJoinComUse ? '' : '·가입·탈퇴';
	my $str2 = $adminMode ? '' : 'onChange=colorPack() onClick=colorPack()';
	my $makeCost = $HcostMakeAlly ? "${HcostMakeAlly}${HunitMoney}" : '무료';
	my $keepCost = $HcostKeepAlly ? "${HcostKeepAlly}${HunitMoney}" : '무료';
	my $joinCost = $HcomCost[$HcomAlly] ? "${$HcomCost[$HcomAlly]}${HunitMoney}" : '무료';
	my $joinStr = $HallyJoinComUse ? '' : "가입·탈퇴의 시의 비용은,${HtagMoney_}$joinCost${H_tagMoney}입니다.<BR>";
	my $str3 = $adminMode ? "특수 비밀번호(필수)<BR>
<INPUT TYPE=\"password\" NAME=\"OLDPASS\" VALUE=\"$HdefaultPassword\" SIZE=32 MAXLENGTH=32 class=f><BR>동맹" : "<span class='attention'>(주의)</span><BR>
동맹의 결성·변경의 비용은,${HtagMoney_}${makeCost}${H_tagMoney}입니다.<BR>
또한, 매 턴 필요한 유지비는${HtagMoney_}$keepCost${H_tagMoney}입니다.<BR>
(유지비는 동맹에 소속된 ${AfterName}이 균등하게 부담합니다)<BR>
$joinStr
</P>
당신의 섬은?(필수)<BR>
<SELECT NAME=\"ISLANDID\" $str2>
$HislandList
</SELECT><BR>당신";

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<DIV ID='changeInfo'>
<H1>동맹의 결성·변경·해산${str1}</H1>
<table border=0 width=50%><tr><td class="M"><P>
<FORM name="AcForm" action="$HthisFile" method="POST">
$str3
의 비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32 class=f>
END

	if($HallyNumber) {
		my $str4 = $adminMode ? '·결성·변경' : $HallyJoinComUse ? '' : '·가입·탈퇴';
		my $str5 = ($adminMode || $HallyJoinComUse) ? '' : '<INPUT TYPE="submit" VALUE="가입·탈퇴" NAME="JoinAllyButton">';
		out(<<END);
<BR>
<BR><B><FONT SIZE=4>［해산${str4}］</FONT></B>
<BR>어느 동맹입니까?<BR>
<SELECT NAME="ALLYNUMBER" onChange=allyPack() onClick=allyPack()>
$allyList
</SELECT>
<BR>
<INPUT TYPE="submit" VALUE="해산" NAME="DeleteAllyButton">
$str5
<BR>
END
	}

	my $str7 = $adminMode ? "맹주 섬 변경(위 메뉴에서 동맹을 선택한 뒤 섬 이름 선택 또는 맹주 해고)<BR>or 동맹 신규 작성(위 메뉴는 무효)<BR><SELECT NAME=\"ALLYID\"><OPTION VALUE=\"$max\">신규 작성<OPTION VALUE=\"0\">맹주 해고\n$HislandList</SELECT><BR>" : '<BR><B><FONT SIZE=4>［결성·변경］</FONT></B><BR>';
	out(<<END);
<BR>
$str7
동맹 이름(변경)<small>(최대 ${HlengthAllyName}자)</small><BR>
<INPUT TYPE="text" NAME="ALLYNAME" VALUE="$allyname" SIZE=32 MAXLENGTH=32><BR>
표시(변경)<BR>
<SELECT NAME="MARK" onChange=colorPack() onClick=colorPack()>
$markList
</SELECT>
<ilayer name="PARENT_CTBL" width="100%" height="100%">
 <layer name="CTBL" width="200"></layer>
 <span id="CTBL"></span>
</ilayer>
<BR>
표시의 색코드(변경)<BR><TABLE BORDER=0><TR>
<TD align='center'>RED</TD>
<TD align='center'>GREEN</TD>
<TD align='center'>BLUE</TD>
</TR><TR>
<TD><SELECT NAME="COLOR1" onChange=colorPack() onClick=colorPack()>
$colorList[1]</SELECT><SELECT NAME="COLOR2" onChange=colorPack() onClick=colorPack()>
$colorList[2]</SELECT></TD>
<TD><SELECT NAME="COLOR3" onChange=colorPack() onClick=colorPack()>
$colorList[3]</SELECT><SELECT NAME="COLOR4" onChange=colorPack() onClick=colorPack()>
$colorList[4]</SELECT></TD>
<TD><SELECT NAME="COLOR5" onChange=colorPack() onClick=colorPack()>
$colorList[5]</SELECT><SELECT NAME="COLOR6" onChange=colorPack() onClick=colorPack()>
$colorList[6]</SELECT></TD>
</TR></TABLE>
<INPUT TYPE="submit" VALUE="결성(변경)" NAME="NewAllyButton">
<SCRIPT language="JavaScript">
<!--
END
	if(!$adminMode) {
		out(<<END);
function colorPack() {
	var island = new Array(128);
$jsIslandList
	a = document.AcForm.COLOR1.value;
	b = document.AcForm.COLOR2.value;
	c = document.AcForm.COLOR3.value;
	d = document.AcForm.COLOR4.value;
	e = document.AcForm.COLOR5.value;
	f = document.AcForm.COLOR6.value;
	mark = document.AcForm.MARK.value;
	number = document.AcForm.ISLANDID.value;

	str = "#" + a + b + c + d + e + f;
//	document.AcForm.AcColorValue.value = str;
	str = '표시샘플:'<B><span class="number"><FONT color="' + str +'">' + mark + '</FONT></B>'
	 + island[number] + '${AfterName}</span>'';

	if(document.getElementById){
		document.getElementById("CTBL").innerHTML = str;
	} else if(document.all){
		el = document.all("CTBL");
		el.innerHTML = str;
	} else if(document.layers) {
		lay = document.layers["PARENT_CTBL"].document.layers["CTBL"];
		lay.document.open();
		lay.document.write(str);
		lay.document.close();
	}

	return true;
}
function allyPack() {
$jsAllyList
$jsAllyMarkList
$jsAllyColorList
	document.AcForm.ALLYNAME.value = ally[document.AcForm.ALLYNUMBER.value];
	document.AcForm.MARK.value = allyMark[document.AcForm.ALLYNUMBER.value];
	document.AcForm.COLOR1.value = allyColor[document.AcForm.ALLYNUMBER.value][0];
	document.AcForm.COLOR2.value = allyColor[document.AcForm.ALLYNUMBER.value][1];
	document.AcForm.COLOR3.value = allyColor[document.AcForm.ALLYNUMBER.value][2];
	document.AcForm.COLOR4.value = allyColor[document.AcForm.ALLYNUMBER.value][3];
	document.AcForm.COLOR5.value = allyColor[document.AcForm.ALLYNUMBER.value][4];
	document.AcForm.COLOR6.value = allyColor[document.AcForm.ALLYNUMBER.value][5];
	colorPack();
	return true;
}
END
	} else {
		out(<<END);
function colorPack() {
	var island = new Array(128);
$jsIslandList
	a = document.AcForm.COLOR1.value;
	b = document.AcForm.COLOR2.value;
	c = document.AcForm.COLOR3.value;
	d = document.AcForm.COLOR4.value;
	e = document.AcForm.COLOR5.value;
	f = document.AcForm.COLOR6.value;
	mark = document.AcForm.MARK.value;
	name = document.AcForm.ALLYNAME.value;


	if(name == '') { name = '님푸루'; }
	str = "#" + a + b + c + d + e + f;
//	document.AcForm.AcColorValue.value = str;
	str = '표시샘플:'<B><span class="number"><FONT color="' + str +'">' + mark + '</FONT></B>'
	 + name + '${AfterName}</span>'';

	if(document.getElementById){
		document.getElementById("CTBL").innerHTML = str;
	} else if(document.all){
		el = document.all("CTBL");
		el.innerHTML = str;
	} else if(document.layers) {
		lay = document.layers["PARENT_CTBL"].document.layers["CTBL"];
		lay.document.open();
		lay.document.write(str);
		lay.document.close();
	}

	return true;
}
function allyPack() {
$jsAllyList
$jsAllyIdList
$jsAllyMarkList
$jsAllyColorList
	document.AcForm.ALLYID.value = allyID[document.AcForm.ALLYNUMBER.value];
	document.AcForm.ALLYNAME.value = ally[document.AcForm.ALLYNUMBER.value];
	document.AcForm.MARK.value = allyMark[document.AcForm.ALLYNUMBER.value];
	document.AcForm.COLOR1.value = allyColor[document.AcForm.ALLYNUMBER.value][0];
	document.AcForm.COLOR2.value = allyColor[document.AcForm.ALLYNUMBER.value][1];
	document.AcForm.COLOR3.value = allyColor[document.AcForm.ALLYNUMBER.value][2];
	document.AcForm.COLOR4.value = allyColor[document.AcForm.ALLYNUMBER.value][3];
	document.AcForm.COLOR5.value = allyColor[document.AcForm.ALLYNUMBER.value][4];
	document.AcForm.COLOR6.value = allyColor[document.AcForm.ALLYNUMBER.value][5];
	colorPack();
	return true;
}
END
	}
	out(<<END);
colorPack();
//-->
</SCRIPT>
</FORM>
</td></tr></table></DIV>
END
}

# 맹주코멘트 모드
sub allyPactMain {
	my $ally = $Hally[$HidToAllyNumber{$HcurrentID}];
	if($HallyPactMode != 2) {
		# 화면 출력
		unlock();
		if($HallyPactMode && !checkPassword($ally, $HdefaultPassword)) {
			# 비밀번호 오류
			tempWrongPassword();
			return;
		}
		# 템플릿 출력
		tempAllyPactPage();
	} else {
		# 비밀번호 확인
		if(checkPassword($ally, $HdefaultPassword)) {

			$HallyComment =~ s/[\x00-\x1f\,]//g;
			$ally->{'comment'} = htmlEscape($HallyComment);
			$ally->{'title'} = htmlEscape($HallyTitle);
			$ally->{'message'} = htmlEscape($HallyMessage, 1);
			$ally->{'vkind'} = $HvetoKind;
			$ally->{'vetoId'} = \@HvetoID;
			my(%vetoID);
			foreach(@HvetoID) {
				$vetoID{$_} = 1;
			}
			my @newAlly = ();
			if(!$HvetoKind) {
				foreach(@HvetoID) {
					my $vIsland = $Hislands[$HidToNumber{$_}];
					my($vId, @newVally);
					foreach $vId (@{$vIsland->{'allyId'}}) {
						push(@newVally, $vId) if($vId != $ally->{'id'});
					}
					$vIsland->{'allyId'} = \@newVally;
				}
				foreach (@{$ally->{'memberId'}}) {
					if(!$vetoID{$_}) {
						push(@newAlly, $_);
					}
				}
			} else {
				foreach(0..$islandNumber) {
					my $vIsland = $Hislands[$_];
					next if($vetoID{$vIsland->{'id'}} || ($vIsland->{'id'} == $ally->{'id'}));
					my($vId, @newVally);
					foreach $vId (@{$vIsland->{'allyId'}}) {
						push(@newVally, $vId) if($vId != $ally->{'id'});
					}
					$vIsland->{'allyId'} = \@newVally;
				}
				foreach (@{$ally->{'memberId'}}) {
					if($vetoID{$_} || ($_ == $ally->{'id'})) {
						push(@newAlly, $_);
					}
				}
			}
			$ally->{'memberId'} = \@newAlly;
			$ally->{'number'} = @newAlly;
			allyOccupy();
			# 데이터 쓰기
			writeAllyFile();
			unlock();
			# 변경 성공
			tempAllyPactOK($ally);
		} else {
			# 비밀번호 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
}

# 맹주코멘트 모드의 메인 페이지
sub tempAllyPactPage {
	my $ally = $Hally[$HidToAllyNumber{$HcurrentID}];
	my $allyMessage = $ally->{'message'};
	$allyMessage =~ s/<br>/\n/g;
	$allyMessage =~ s/&amp;/&/g;
	$allyMessage =~ s/&lt;/</g;
	$allyMessage =~ s/&gt;/>/g;
	$allyMessage =~ s/&quot;/\"/g; #"

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='changeInfo'>
<H1>정보 변경($ally->{'name'})</H1>
<table border=0 width=80%><tr><td class="M">
<FORM action="$HthisFile" method="POST">
<B>맹주 비밀번호</B><BR>
<INPUT TYPE="password" NAME="Allypact" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32 class=f>
<INPUT TYPE="hidden" NAME="ISLANDID" VALUE="$ally->{'id'}">
<INPUT TYPE="hidden" NAME="AllypactMode" VALUE="$HallyPactMode">
<INPUT TYPE="submit" VALUE="전송" NAME="AllypactButton">
END
	if($HallyPactMode) {
		out("<TABLE><TR><TD class='M'>");
		if($HallyVetoUse) {
			my(%vetoID);
			foreach (@{$ally->{'vetoId'}}) {
				$vetoID{$_} = 1;
			}
			out("<BR><BR><B>가입 ${AfterName} 설정</B><TABLE cellpadding=0 cellspacing=0>");
			foreach ($HbfieldNumber..$islandNumber) {
				my($id, $name, $s);
				$id = $Hislands[$_]->{'id'};
				next if($id == $ally->{'id'});
				$name = islandName($Hislands[$_]);
				$s = ' CHECKED' if($vetoID{$id});
				out("<TR><TD><input type=checkbox name=VETOID value=\"$id\"$s></TD><TD>$name</TD></TR>");
			}
			my($s1, $s2) = (!$ally->{'vkind'}) ? ('', ' checked') : (' checked', '');
			out("<TR><TD colspan=2 class='M'>참고: 확인을 받은 $AfterName의 가입을</TD><TR>");
			out("<TR><TD align='center' colspan=2 class='M'> <input type=radio name=VETOKIND value=\"1\"${s1}><FONT COLOR='#FF0000'>허가</FONT> <input type=radio name=VETOKIND value=\"0\"${s2}><FONT COLOR='#0000FF'>거부</FONT></TD><TR>");
			out("<TR><TD align='right' colspan=2 class='M'>합니다.</TD><TR>");
			out("<TR><TD align='center' colspan=2 class='M'><INPUT TYPE=\"submit\" VALUE=\"전송\" NAME=\"AllypactButton\"></TD><TR>");
			out("</TABLE>");
		}
		out(<<END);
</TD><TD class='M'>
<BR><BR><B>코멘트</B><small>(최대 ${HlengthAllyComment}자: 메인 페이지의'각 동맹 상황'화면에 표시됩니다)</small><BR>
<INPUT TYPE="text" NAME="ALLYCOMMENT" VALUE="$ally->{'comment'}" SIZE=100 MAXLENGTH=50><BR>
<BR>
<INPUT TYPE="submit" VALUE="전송" NAME="AllypactButton">
<BR><BR>
<B>메시지·동맹약속등</B>('동맹 정보'란의 화면에 표시됩니다)<BR>
제목<small>(최대 ${HlengthAllyTitle}자)</small><BR>
<INPUT TYPE="text" NAME="ALLYTITLE" VALUE="$ally->{'title'}" SIZE=100 MAXLENGTH=50><BR>
메시지<small>(최대 ${HlengthAllyMessage}자)</small><BR>
<TEXTAREA COLS=50 ROWS=16 NAME="ALLYMESSAGE" WRAP="soft">$allyMessage</TEXTAREA>
<BR>
'제목'을빈칸에하면'맹주의 메시지'라는 제목이 됩니다.<BR>
'메시지'를빈칸에하면'동맹 정보'란에는 아무것도 표시되지 않습니다.
</TD></TR></TABLE>
END
	}

	out(<<END);
</FORM>
</td></tr></table>
</DIV>
END
}

# 맹주코멘트 변경완료
sub tempAllyPactOK {
	my($ally) = @_;
	out(<<END);
${HtagBig_}<FONT COLOR="$ally->{'color'}">$ally->{'mark'}</FONT>$ally->{'name'}의 정보를 변경했습니다.${H_tagBig}<HR>
END
	$HallyPactMode = 1;
	tempAllyPactPage();
}

#----------------------------------------------------------------------
# HTML생성
#----------------------------------------------------------------------
sub logPrintHtml {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime(time + $Hjst);
	$mon++;
	my($sss) = "${mon}월${date}일 ${hour}시 ${min}분${sec}초";

	$html1=<<_HEADER_;
<HTML><HEAD>
<META http-equiv="Content-Style-Type" content="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
최근 사건
</TITLE>
<BASE HREF="$htmlDir/">
<link rel="stylesheet" type="text/css" href="${HcssDir}/$HcssDefault">
</HEAD>
$Body<DIV ID='BodySpecial'>
<DIV ID='RecentlyLog'>
<H1>최근 사건</H1>
<FORM>
최신갱신일:$sss..
<INPUT TYPE="button" VALUE=" 다시 읽기" onClick="location.reload()">
</FORM>
<hr>
_HEADER_

$html3=<<_HEADER_;
</DIV><HR>
</DIV></BODY>
</HTML>
_HEADER_
	my($i);
	for($i = 0; $i < $HhtmlLogTurn; $i++) {
		$id =0;
		$mode = 0;
		my($set_turn) = 0;
		open(LIN, "${HdirName}/$i$HlogData");
		my($line, $m, $turn, $id1, $id2, $message);
		while($line = <LIN>) {
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9\-]*),(.*)$/;
			($m, $turn, $id1, $id2, $id3, $message) = ($1, $2, $3, $4, $5, $6);
			next if($m eq '');

			# 기밀관계
			next if($m == 1);

			# 표시
			if($set_turn == 0){
				$html2.= "<B>=====[${HtagNumber_}<FONT SIZE=4>턴$turn </FONT>${H_tagNumber}]================================================</B><BR>\n";
				$set_turn++;
			}
			$html2.= "${HtagNumber_}★${H_tagNumber}:$message<BR>\n";
		}
		close(LIN);
	}
	open(HTML, ">${HhtmlDir}/hakolog.html");
#	print HTML $html1; # 문자 변환 라이브러리 사용 시
#	print HTML $html2;
#	print HTML $html3;
	print HTML $html1;
	print HTML $html2;
	print HTML $html3;
	close (HTML);
	chmod(0666,"${HhtmlDir}/hakolog.html");
}

#----------------------------------------------------------------------
# 인구기타의 값을 산출(축소)
#----------------------------------------------------------------------
sub estimate {
	my($number) = $_[0];
	my($island);
	my($pop, $area, $mountain, $navyPort, $sea) = (0, 0, 0, 0, 0);

	# 지형을 가져옴
	$island = $Hislands[$number];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($map) = $island->{'map'};

	# 수 가능
	my($x, $y, $kind, $value);
	foreach $y (@{$map->{'y'}}) {
		foreach $x (@{$map->{'x'}}) {
			$kind = $land->[$x][$y];
			$value = $landValue->[$x][$y];
			if($kind != $HlandSea){
				$area++;
				if($kind == $HlandTown) {
					# 읍
					$pop += $value;
				} elsif($kind == $HlandMountain) {
					# 산
					$mountain += $value;
				} elsif ($kind == $HlandNavy) {
					if ($HnavySpecial[(navyUnpack($value))[7]] & 0x8) {
						# 항구
						$navyPort++;
					}
				}
			} elsif(!$value) {
				$sea++;
			}
		}
	}

	# 대입
	$island->{'pop'} = $pop;
	$island->{'area'} = $area;
	$island->{'mountain'} = $mountain;
	$island->{'navyPort'} = $navyPort;
	$island->{'sea'} = $sea;
	$island->{'farm'} = 0;
	$island->{'factory'} = 0;
}

# 범위 안의 지형을 수 가능(섬작성용)
sub countAroundforMake {
	my($land, $x, $y, $range, @kind) = @_;
	my($sea, $count, $sx, $sy, @list, @correct);
	foreach (@kind){
		$list[$_] = 1;
	}
	$sea = 0;
	$count = 0;
	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		if(($sx < 0) || ($sy < 0)){
			# 범위 밖의 경우
			# 바다에가 산
			$sea++;
		} elsif($list[$land->[$sx][$sy]]) {
			# 범위 안의 경우
			$count++;
		}
	}
	$count += $sea if($list[$HlandSea]); # 바다이면 가 산
	return $count;
}
#----------------------------------------------------------------------
# 섬의 강제 삭제(정보 변경에서)
#----------------------------------------------------------------------
sub deleteIsland {
	my($num) = @_;
	my($island) = $Hislands[$HidToNumber{$HcurrentID}];

	if($HdeadToSaveAsLose == 2) {
		require('./hako-turn.cgi');
	 	island_save($island, $HfightdirName, 'lose', 0);
	}

	my $aNum = $HidToAllyNumber{$HcurrentID};
	if(defined $aNum) {
		logDeleteAlly($Hally[$aNum]->{'name'});
		$Hally[$aNum]->{'dead'} = 1;
		$HallyNumber--;
	}
	foreach (@{$island->{'allyId'}}) {
		my $ally = $Hally[$HidToAllyNumber{$_}];
		my $allyMember = $ally->{'memberId'};
		my @newAllyMember = ();
		foreach (@$allyMember) {
			if(!(defined $HidToNumber{$_})) {
			} elsif($_ == $HcurrentID) {
				$ally->{'score'} -= $island->{$HrankKind} if(!$island->{'predelete'});
				$ally->{'number'}--;
			} else {
				push(@newAllyMember, $_);
			}
		}
		$ally->{'memberId'} = \@newAllyMember;
	}
	my @newID = ();
	foreach (@HpreDeleteID) {
		if(!(defined $HidToNumber{$_})) {
		} elsif($_ != $HcurrentID) {
			push(@newID, $_);
		}
	}
	@HpreDeleteID = @newID;
	# 섬 테이블 조작
	$island->{'dead'} = 1;
	$island->{$HrankKind} = 0;
	$island->{'pop'} = 0;
	$island->{'field'} = 0;
	$island->{'predelete'} = 0;

	allyOccupy();
	allySort();
	islandSort($HrankKind);

	logDeleteIsland($HcurrentID, $island->{'name'}) if($num);

	# 메인 데이터의 조작
	$HislandNumber--;
	$islandNumber--;

	deleteIslandData($island);
	writeIslandsFile($HcurrentID);

	unlock();
	tempDeleteIsland($island->{'name'});
}

#----------------------------------------------------------------------
# BattleField 작성 모드
#----------------------------------------------------------------------
sub bfieldMain {
	if (!$HbfieldMode) {
		$HislandList = getIslandList(-1, 1);
		# 화면 출력
		unlock();
		# 템플릿 출력
		tempBfieldPage();
	} else {
		# 비밀번호 확인
		if(checkSpecialPassword($HdefaultPassword)) {
			# 특수 비밀번호
			if($HcurrentID == 0) {
				$HcurrentName = "BattleField ". ($HbfieldNumber + 1);
				$HcurrentOwnerName = $HadminName;
				$HinputPassword = $HmasterPassword;
				$HinputPassword2 = $HmasterPassword;
				if(!newIslandMain(1)) {
					unlock();
					return;
				}
			}

			# id에서 섬을 가져옴
			$HcurrentNumber = $HidToNumber{$HcurrentID};
			my($island) = $Hislands[$HcurrentNumber];
			my($name) = $island->{'name'};
			my($id) = $island->{'id'};

			my($bId, $str, $tmpid);
			my $safety = 0;
			if(!$island->{'field'}) {
				# 설정
				$Hislands[$HcurrentNumber]->{'field'} = 1;
				$str = "일반 섬 → Battle Field";
			} else {
				# 해제
				$Hislands[$HcurrentNumber]->{'field'} = 0;
				$str = "Battle Field → 일반 섬";
			}

			# 데이터 쓰기
			islandSort($HrankKind);
			writeIslandsFile($id);

			unlock();

			# 변경 성공
			tempBfieldOK($name, $str);
		} else {
			# 비밀번호 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
}

# BattleField 작성 모드의 메인 페이지
sub tempBfieldPage {
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2<BR>
<H1>Battle Field 작성</H1>
END
	if($HoceanMode) {
		require('./hako-map.cgi');
		printIslandMapMain(2);
	}
	out(<<END);
<FORM action="$HthisFile" name="BfieldForm" method="POST">
END
	if($HoceanMode) {
		out(<<END);
해역좌표를 지정해 주세요<BR>좌표(
<SELECT NAME="OCEANX">
END
		my($i);
		foreach $i (0..($HoceanSizeX-1)) {
			out("<OPTION VALUE=$i>$i\n");
		}
		out(<<END);
</SELECT>, <SELECT NAME="OCEANY">
END
		foreach $i (0..($HoceanSizeY-1)) {
			out("<OPTION VALUE=$i>$i\n");
		}
		out(<<END);
</SELECT>) <INPUT TYPE=CHECKBOX name='RANDOM' VALUE='1'>무작위<BR><BR>
END
	}

	out(<<END);
<B>Battle Field 설정을 변경${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Bfield">
<INPUT TYPE="submit" VALUE="설정 변경" NAME="BfieldButton"><BR>
</FORM>
'신규 작성(모두 바다)'이 경우, 섬의 비밀번호는 마스터 비밀번호가 됩니다.<BR>
작성후, 필요에 따라 비밀번호를 변경해 주세요.</DIV>
END
}

# BattleField 작성완료
sub tempBfieldOK {
	my($name, $str) = @_;
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR><BR>
${HtagBig_}$name${AfterName}의 Battle Field 설정을 변경했습니다.<br>$str${H_tagBig}
END
}

# BattleField 작성실패
sub tempBfieldNG {
	my($str) = @_;
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR><BR>
${HtagBig_}Battle Field 의 설정오류($str).${H_tagBig}$HtempBack2
END
}

#----------------------------------------------------------------------
# 관리자가 한 섬 데이터 수정 모드
#----------------------------------------------------------------------
sub islandSetupMain() {
	if (!$HisetupMode) {
		# 화면 출력
		unlock();
		# 템플릿 출력
		tempIslandSetupPage(0);
		return;
	} elsif(!checkSpecialPassword($HdefaultPassword)) {
		# 비밀번호 확인
		# 특수 비밀번호
		# 비밀번호 오류
		unlock();
		tempWrongPassword();
		return;
	}
	if($HisetupMode == 2) {
		$HcurrentNumber = $HidToNumber{$HcurrentID};
		my($island) = $Hislands[$HcurrentNumber];
		# 섬 이름이 유효한지 확인
		if($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인|^침몰$/) {
			# 사용 불가 이름
			unlock();
			tempNewIslandBadName();
			return;
		}
		# 소유자 이름이 유효한지 확인
		if($HcurrentOwnerName =~ /[,\?\(\)\<\>\$]/) {
			# 사용 불가 이름
			unlock();
			tempNewIslandBadOwnerName();
			return;
		}
		if($HoceanMode) {
			my($wmap) = $island->{'wmap'};
			my($wx, $wy) = ($wmap->{'x'}, $wmap->{'y'});
			if($HmapRandom) {
				my($wm) = randomIslandMap();
				if(defined $wm) {
					($HoceanMapX, $HoceanMapY) = ($wm->{'x'}, $wm->{'y'});
				} else {
					unlock();
					tempHeader();
					tempNewIslandFull();
					return 0;
				}
			}
			if($wx != $HoceanMapX || $wy != $HoceanMapY) {
				if(defined $HoceanMap[$HoceanMapX][$HoceanMapY]) {
					unlock();
					tempHeader();
					tempNewIslandAlready();
					return 0;
				}
				my($land, $landValue) = ($Hworld->{'land'}, $Hworld->{'landValue'});
				my $map = $island->{'map'};
				my(@mx) = @{$map->{'x'}};
				my(@my) = @{$map->{'y'}};
				my(@nx) = (($HoceanMapX * $HislandSizeX)..($HoceanMapX * $HislandSizeX + $HislandSizeX - 1));
				my(@ny) = (($HoceanMapY * $HislandSizeY)..($HoceanMapY * $HislandSizeY + $HislandSizeY - 1));
				my($i, $j, $x, $y, $xx, $yy, %convXY);
				foreach $j (0..$#my) {
					$y = $my[$j]; $yy = $ny[$j];
					foreach $i (0..$#mx) {
						$x = $mx[$i]; $xx = $nx[$i];
						$land->[$xx][$yy] = $land->[$x][$y];
						$landValue->[$xx][$yy] = $landValue->[$x][$y];
						$land->[$x][$y] = $HlandSea;
						$landValue->[$x][$y] = 0;
						$convXY{"$x,$y"} = { 'x'=>$xx, 'y'=>$yy };
					}
				}
				$island->{'wmap'} = { 'x' => $HoceanMapX, 'y' => $HoceanMapY };
				$island->{'map'} = { 'x' => \@nx, 'y' => \@ny };
				$HoceanMap[$wmap->{'x'}][$wmap->{'y'}] = undef;
				$HoceanMap[$HoceanMapX][$HoceanMapY] = $HcurrentID;
				makeRen();
				my($n, $nId, $nCommand, $change);
				foreach $n (0..$islandNumber) {
					$nId = $Hislands[$n]->{'id'};
					$nCommand = readCommand($nId, $HcommandMax);
					$change = 0;
					foreach (@{$nCommand}) {
						my($nkind, $nx, $ny) = ($_->{'kind'}, $_->{'x'}, $_->{'y'});
						if((defined $convXY{"$nx,$ny"}) && (($kind < 90) || ((100 < $kind) && ($kind < 200)) || ((330 < $kind) && ($kind < 350)) || ($kind == $HcomNavyWreckRepair) || ($kind == $HcomNavyWreckSell) ||
								# 내정(개발), 내정(건설), 복합시설, 해군(건조) <200, 330< 군사(건설) <350, 잔해 수리, 잔해 매각
							((215 < $kind) && ($kind < 220)) || ((350 < $kind) && ($kind < 361)))) {
								# 이동 조종, 이동 지령, 함정 지령 변경, 일제 공격과 군사(공격)[내정, 건조 이외에서  좌표 지정 명령]
							$_->{'x'} = $convXY{"$nx,$ny"}->{'x'};
							$_->{'y'} = $convXY{"$nx,$ny"}->{'y'};
							$change = 1;
						}
					}
					writeCommand($nId, $nCommand) if($change);
				}
			}
		}

		$island->{'name'} = $HcurrentName;
		$island->{'owner'} = $HcurrentOwnerName;
		$island->{'birthday'} = ($Hbirthday < 0) ? 0 : ($Hbirthday> $HislandTurn) ? $HislandTurn : $Hbirthday;
		$island->{'absent'} = ($Habsent < 0) ? 0 : ($Habsent> $HgiveupTurn) ? $HgiveupTurn : $Habsent;
		$island->{'preab'} = $Hpreab;
		$island->{'money'} = ($Hmoney < 0) ? 0 : ($Hmoney> $HmaximumMoney) ? $HmaximumMoney : $Hmoney;
		$island->{'food'} = ($Hfood < 0) ? 0 : ($Hfood> $HmaximumFood) ? $HmaximumFood : $Hfood;
		$Hgain = 0 if($Hgain < 0);
		$island->{'gain'} = $Hgain;
		$island->{'field'} = $Hfield;
		$island->{'fight_id'} = $Hfight_id;
		$island->{'rest'} = $Hrest;
		$island->{'prize'} =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
		my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
		my %check;
		foreach (@Hflags) {
			$check{$_} = 1;
		}
		$flags = 0;
		foreach(reverse(1..$#Hprize)) {
			$flags |= $check{$_};
			$flags <<= 1 if($_ != 1);
		}
		undef %check;
		my $num = $HmonsterNumber - 1;
		foreach (@Hmonsters) {
			$check{$_} = 1;
		}
		$monsters = 0;
		foreach(reverse(0..$num)) {
			$monsters |= $check{$_};
			$monsters <<= 1 if($_);
		}
		undef %check;
		$num = $HhugeMonsterNumber - 1;
		foreach (@Hhmonsters) {
			$check{$_} = 1;
		}
		$hmonsters = 0;
		foreach(reverse(0..$num)) {
			$hmonsters |= $check{$_};
			$hmonsters <<= 1 if($_);
		}
		$island->{'prize'} = "$flags,$monsters,$hmonsters,$turns";
		$Hmonsterkill = 0 if($Hmonsterkill < 0);
		$island->{'monsterkill'} = $Hmonsterkill;
		$island->{'sink'} = \@Hsink;
		$island->{'sinkself'} = \@Hsinkself;
		$island->{'ext'} = \@Hext;
		$island->{'subExt'} = \@HsubExt;
		$island->{'item'} = \@HtmpItem;
		$island->{'weather'} = \@HtmpWeather;
		islandSort($HrankKind, 1);
		if($HallyNumber) {
			allyOccupy();
			allySort();
		}
		writeIslandsFile();
	}
	# 화면 출력
	unlock();
	# 템플릿 출력
	tempIslandSetupPage(1);
}

# 섬 데이터 수정페이지
sub tempIslandSetupPage() {
	my($mode) = @_;

	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;
	$HislandList = getIslandList($HcurrentID, 1);

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<DIV ID='islandInfo'>
<H1>${AfterName} 데이터 수정</H1>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" NAME="ISetup" VALUE="$HdefaultPassword">
<B>데이터를 수정할 ${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<INPUT TYPE="submit" VALUE="데이터 수정 화면으로" NAME="IslandChoice"><BR>
</FORM>
END

	return if(!$mode);

	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];

	my($id) = $island->{'id'};
	my($name) = $island->{'name'};
	my($owner) = $island->{'owner'};
	my($birthday) = $island->{'birthday'};
	my($absent) = $island->{'absent'};
	my($preab) = $island->{'preab'};
	my($money) = $island->{'money'};
	my($food) = $island->{'food'};
	my($gain) = $island->{'gain'};
	my($prize) = $island->{'prize'};
	my($monsterkill) = $island->{'monsterkill'};
	my($sink) = $island->{'sink'};
	my($sinkself) = $island->{'sinkself'};
	my($subSink) = $island->{'subSink'};
	my($subSinkself) = $island->{'subSinkself'};
	my($ext) = $island->{'ext'};
	my($subExt) = $island->{'subExt'};
	my($field) = $island->{'field'};
	my($item) = $island->{'item'};
	my($weather) = $island->{'weather'};
	my($fight_id) = $island->{'fight_id'};
	my($rest) = $island->{'rest'};
	my($wmap) = $island->{'wmap'};
	my($wx, $wy) = ($wmap->{'x'}, $wmap->{'y'});

	$preab = ($preab == 1) ? ' checked' : '';
	$field = ($field == 1) ? ' checked' : '';
	my $islandList = '';
	my $fiName = '';
	if($fight_id == 0) {
		$islandList.= '<OPTION VALUE="-2">압승!';
		$islandList.= '<OPTION VALUE="-1">부전승';
		$islandList.= '<OPTION VALUE="0" style="background:yellow;" selected>미정';
		$islandList.= getIslandList(0, 1);
	} elsif($fight_id == -1) {
		$islandList.= '<OPTION VALUE="-2">압승!';
		$islandList.= '<OPTION VALUE="-1" style="background:yellow;" selected>부전승';
		$islandList.= '<OPTION VALUE="0">미정';
		$islandList.= getIslandList(0, 1);
	} elsif($fight_id == -2) {
		$islandList.= '<OPTION VALUE="-2" style="background:yellow;" selected>압승!';
		$islandList.= '<OPTION VALUE="-1">부전승';
		$islandList.= '<OPTION VALUE="0">미정';
		$islandList.= getIslandList(0, 1);
	} else {
		$islandList.= '<OPTION VALUE="-2">압승!';
		$islandList.= '<OPTION VALUE="-1">부전승';
		$islandList.= '<OPTION VALUE="0">미정';
		$islandList.= getIslandList($fight_id, 1, 'yellow');
	}

	my $predel = '';
	if($island->{'predelete'}) {
		my $rest = ($island->{'predelete'} != 99999999) ? "<small>(남은$island->{'predelete'}턴)</small>" : '';
		$predel = '[관리자 보관]$rest';
	}
	out("<HR>");
	if($HoceanMode) {
		require('./hako-map.cgi');
		printIslandMapMain(1);
	}
	out(<<END);
<FORM action="$HthisFile" name="IsetupForm" method="POST">
<INPUT TYPE="hidden" NAME="ISetup" VALUE="$HdefaultPassword">
<TABLE BORDER>
<TR><TH>${HtagTH_}$name${AfterName}${H_tagTH}$predel ${HtagTH_}데이터 수정${H_tagTH} <INPUT TYPE="submit" VALUE="수정" NAME="ChangeButton"></TH></TR>

<TR><TD class='M'>
<TABLE BORDER width="100%">
<TR><TH colspan=12>기본 데이터</TH></TR><TR>
<TR>
<TH $HbgTitleCell rowspan=2>${HtagTH_}${AfterName}ID${H_tagTH}</TH>
END
	out("<TH $HbgTitleCell rowspan=2>${HtagTH_}해역좌표${H_tagTH}</TH>") if($HoceanMode);
	out(<<END);
<TH $HbgTitleCell rowspan=2>${HtagTH_}${AfterName} 이름${H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>${HtagTH_}소유자 이름${H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>${HtagTH_}시작 턴${H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>${HtagTH_}자금 조달${H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>${HtagTH_}진영개발 가능${H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>${HtagTH_}자금${H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>${HtagTH_}총 획득 경험치${H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>${HtagTH_}피루도속성${H_tagTH}</TH>
<TH $HbgTitleCell colspan=2>${HtagTH_}토너먼트용${H_tagTH}</TH>
</TR>
<TR>
<TH $HbgTitleCell>${HtagTH_}대전 상대${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}개발 정지 턴 수${H_tagTH}</TH>
</TR>
<TR>
<TD align="center"><INPUT TYPE="hidden" NAME="ISLANDID" VALUE="$id">${id}</TD>
END
	if($HoceanMode) {
		out("<TD align=\"center\">(<SELECT NAME=\"OCEANX\">");
			my($i);
			foreach $i (0..($HoceanSizeX-1)) {
				if($i == $wx) {
					out("<OPTION VALUE=$i style=\"background:yellow;\" selected>$i\n");
				} else {
					out("<OPTION VALUE=$i>$i\n");
				}
			}
			out(<<END);
</SELECT>, <SELECT NAME="OCEANY">
END
			foreach $i (0..($HoceanSizeY-1)) {
				if($i == $wy) {
					out("<OPTION VALUE=$i style=\"background:yellow;\" selected>$i\n");
				} else {
					out("<OPTION VALUE=$i>$i\n");
				}
			}
			out(<<END);
</SELECT>)<BR><INPUT TYPE=CHECKBOX name='RANDOM' VALUE='1'>무작위</TD>
END
	}
	out(<<END);
<TD align="center"><INPUT TYPE="text" NAME="ISLANDNAME" VALUE="$name" SIZE=20 MAXLENGTH=32>${AfterName}</TD>
<TD align="center"><INPUT TYPE="text" NAME="OWNERNAME" VALUE="$owner" SIZE=20 MAXLENGTH=32></TD>
<TD align="center"><INPUT TYPE="text" NAME="BIRTHDAY" VALUE="$birthday" SIZE=5 MAXLENGTH=32></TD>
<TD align="center"><INPUT TYPE="text" NAME="ABSENT" VALUE="$absent" SIZE=5 MAXLENGTH=32></TD>
<TD align="center"><INPUT TYPE="checkbox" NAME="PREAB" VALUE="1"$preab></TD>
<TD align="center"><INPUT TYPE="text" NAME="MONEY" VALUE="$money" SIZE=5 MAXLENGTH=32>$HunitMoney</TD>
<TD align="center"><INPUT TYPE="text" NAME="FOOD" VALUE="$food" SIZE=5 MAXLENGTH=32>$HunitFood</TD>
<TD align="center"><INPUT TYPE="text" NAME="GAIN" VALUE="$gain" SIZE=5 MAXLENGTH=32>
END
	my $navyComLevel = gainToLevel($island->{'gain'});
	out("(Lv.${navyComLevel})") if($HmaxComNavyLevel);
	out(<<END);
</TD>
<TD align="center"><INPUT TYPE="checkbox" NAME="FIELD" VALUE="1"$field></TD>
<TD align="center"><SELECT NAME="FIGHT_ID">$islandList</SELECT></TD>
<TD align="center"><INPUT TYPE="text" NAME="REST" VALUE="$rest" SIZE=5 MAXLENGTH=32>턴</TD>
</TD></TR></TABLE></TD></TR>
END

	$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
	my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
	out("<TR><TD class='M'><TABLE BORDER width=\"100%\">\n");
	my $col = $#Hprize;
	out("<TR><TH colspan=$col>상</TH></TR><TR>\n");
	foreach(1..$#Hprize) {
		out("<TD class='T'>${HtagTH_}${Hprize[$_]->{'name'}}${H_tagTH}</TD>\n");
	}
	out("</TR><TR>\n");
	my($f) = 1;
	foreach(1..$#Hprize) {
		my $s = '';
		if($flags & $f) {
			$s = ' CHECKED';
		}
		out("<TD align=\"center\"><input type=checkbox name=FLAGS value=\"$_\"$s></TH>\n");
		$f <<= 1;
	}
	out("</TR></TABLE></TD></TR>\n");
	out("<TR><TD class='M'><TABLE BORDER width=\"100%\">\n");
	$col = $HmonsterNumber - 1;
	out("<TR><TH colspan=$HmonsterNumber>퇴치한 괴수</TH></TR><TR>\n");
	foreach(0..$col) {
		out("<TD class='T'>${HtagTH_}${HmonsterName[$_]}${H_tagTH}</TD>\n");
	}
	out("</TR><TR>\n");
	$f = 1;
	foreach(0..$col) {
		my $s = '';
		if($monsters & $f) {
			$s = ' CHECKED';
		}
		out("<TD align=\"center\"><input type=checkbox name=MONSTERS value=\"$_\"$s></TH>\n");
		$f <<= 1;
	}
	out("</TR></TABLE></TD></TR>\n");
	out("<TR><TD class='M'><TABLE BORDER width=\"100%\">\n");
	$col = $HhugeMonsterNumber - 1;
	out("<TR><TH colspan=$HhugeMonsterNumber>퇴치한 거대괴수</TH>\n");
#	out("<TH>괴수퇴치 수</TH>\n");
	out("</TR><TR>\n");
	foreach(0..$col) {
		out("<TD class='T'>${HtagTH_}${HhugeMonsterName[$_]}${H_tagTH}</TD>\n");
	}
#	out("<TD align=\"center\" rowspan=2><INPUT TYPE=\"text\" NAME=\"MONSTERKILL\" VALUE=\"$monsterkill\" SIZE=5 MAXLENGTH=32>$HunitMonster</TD>\n");
	out("</TR><TR>\n");
	$f = 1;
	foreach(0..$col) {
		my $s = '';
		if($hmonsters & $f) {
			$s = ' CHECKED';
		}
		out("<TD align=\"center\"><input type=checkbox name=HMONSTERS value=\"$_\"$s></TH>\n");
		$f <<= 1;
	}
	out("</TR></TABLE></TD></TR>\n");

	out("<TR><TD class='M'><TABLE BORDER width=\"100%\">\n");
	$col = @HnavyName + 2;
	out("<TR><TH colspan=$col>함정 격침 수 (격침 수=타 섬 + 자기 섬, 자폭 수=자기 섬)</TH></TR><TR><TD colspan=2> </TD>\n");
	foreach(@HnavyName) {
		out("<TD class='T'>${HtagTH_}$_${H_tagTH}</TD>\n");
	}
	out("</TR><TR><TH colspan=2>타 섬</TH>\n");
	my @kindNavy = ('함', '항구');
	foreach(0..$#HnavyName) {
		out("<TD align=\"center\"><INPUT TYPE=\"text\" NAME=\"SINK\" VALUE=\"@$sink[$_]\" SIZE=5 MAXLENGTH=32>$kindNavy[!$_]</TD>\n");
	}
	out("</TR><TR><TH colspan=2>자기 섬</TH>\n");
	foreach(0..$#HnavyName) {
		out("<TD align=\"center\"><INPUT TYPE=\"text\" NAME=\"SINKSELF\" VALUE=\"@$sinkself[$_]\" SIZE=5 MAXLENGTH=32>$kindNavy[!$_]</TD>\n");
	}
	my $turn = @$subExt[0];
	$turn-- if($turn> 0);
	out("</TR><TH rowspan=2>${turn}턴<BR>까지 기록</TH><TH>타 섬</TH>\n");
	foreach(0..$#HnavyName) {
		out("<TD align=\"center\"><INPUT TYPE=\"text\" NAME=\"SUBSINK\" VALUE=\"@$subSink[$_]\" SIZE=5 MAXLENGTH=32>$kindNavy[!$_]</TD>\n");
	}
	out("</TR><TR><TH>자기 섬</TH>\n");
	foreach(0..$#HnavyName) {
		out("<TD align=\"center\"><INPUT TYPE=\"text\" NAME=\"SUBSINKSELF\" VALUE=\"@$subSinkself[$_]\" SIZE=5 MAXLENGTH=32>$kindNavy[!$_]</TD>\n");
	}
	out("</TR></TABLE></TD></TR>\n");

	out("<TR><TD class='M'><TABLE BORDER width=\"100%\">\n");
	out("<TR><TH colspan=11>확장 데이터</TH>\n");
	out("<TH rowspan=2>괴수<BR>퇴치 수</TH>\n");
	out("<TD class='M' colspan='1'></TD>\n");
	out("</TR><TR>\n");
	foreach ('승리 플래그', '공헌도x10', '방어 격파', '미사일 격파', '난민 구조', '날아온 탄환', '탄환 발사', '탄환 방어', '함정 파견', '함정 피격', '함정 파괴') {
		out("<TH $HbgTitleCell>${HtagTH_}$_${H_tagTH}</TH>\n");
	}
	out("</TR><TR>");
	my @after = ('', '', '기준', '기준', "$HunitPop", '발', '발', '발', '함', '함', '함');
	foreach (0..10){
		out("<TD align=\"center\"><INPUT TYPE=\"text\" NAME=\"EXT\" VALUE=\"@$ext[$_]\" SIZE=5 MAXLENGTH=32>$after[$_]</TD>\n");
	}
	out("<TD align=\"center\"><INPUT TYPE=\"text\" NAME=\"MONSTERKILL\" VALUE=\"$monsterkill\" SIZE=5 MAXLENGTH=32>$HunitMonster</TD>\n");
	out("<TD class='M' colspan='1'></TD>\n");
	out("</TR><TR><TH colspan=13>하위확장 데이터(${turn}턴까지 기록)</TH></TR><TR>\n");
	foreach ('기록 턴', '공헌도x10', '방어 격파', '미사일 격파', '난민 구조', '날아온 탄환', '탄환 발사', '탄환 방어', '함정 파견', '함정 피격', '함정 파괴', '퇴치 수', '포상금') {
		out("<TH $HbgTitleCell>${HtagTH_}$_${H_tagTH}</TH>\n");
	}
	out("</TR><TR>");
	my @subAfter = ('턴 전', '', '기준', '기준', "$HunitPop", '발', '발', '발', '함', '함', '함', "$HunitMonster", "$HunitMoney");
	foreach (0..12){
		out("<TD align=\"center\"><INPUT TYPE=\"text\" NAME=\"SUBEXT\" VALUE=\"@$subExt[$_]\" SIZE=5 MAXLENGTH=32>$subAfter[$_]</TD>\n");
	}
	out("</TR></TABLE></TD></TR>\n");

	out("<TR><TD class='M'><TABLE BORDER width=\"100%\">\n");
	$col = $#HitemName;
	out("<TR><TH colspan=$col>보유 아이템 ($HitemName[0])</TH></TR><TR>\n");
	foreach (1..$#HitemName) {
		out("<TD class='T'>${HtagTH_}$HitemName[$_]${H_tagTH}</TH>\n");
	}
	out("</TR><TR>\n");
	my %iflag;
	foreach (@$item) {
		$iflag{$_} = 1;
	}
	foreach (1..$#HitemName) {
		my $s = '';
		if($iflag{$_}) {
			$s = ' CHECKED';
		}
		out("<TD align=\"center\"><input type=checkbox name=ITEM value=\"$_\"$s></TD>\n");
	}
	out("</TR></TABLE></TD></TR>\n");
	out("<TR><TD class='M'><TABLE BORDER width=\"100%\">\n");
	$col = 7 + $HtopLogTurn;
	out("<TR><TH colspan=$col>기상</TH></TR><TR>\n");
	foreach ('기온', '기압', '습도', '풍속', '지반', '파력', '(미사용)') {
		out("<TH $HbgTitleCell rowspan=2>${HtagTH_}$_${H_tagTH}</TH>\n");
	}
	out("<TH $HbgTitleCell colspan=$HtopLogTurn>${HtagTH_}날씨 목록${H_tagTH}</TH>\n");
	out("</TR><TR>");
	my($wTurn) = $HislandTurn + 3;
	foreach (1..$HtopLogTurn) {
		out("<TH $HbgTitleCell>${HtagTH_}턴$wTurn${H_tagTH}</TH>\n");
		$wTurn--;
	}
	out("</TR><TR>");
	my @wAfter = ('℃', 'hPa', '%', 'm/s', '', '', '');
	foreach (0..6){
		out("<TD align=\"center\"><INPUT TYPE=\"text\" NAME=\"WEATHER\" VALUE=\"@$weather[$_]\" SIZE=5 MAXLENGTH=32>$wAfter[$_]</TD>\n");
	}
	my($i) = 7;
	foreach (1..$HtopLogTurn){
		if(@$weather[$i]) {
			out("<TD align=\"center\"><INPUT TYPE=\"hidden\" NAME=\"WEATHER\" VALUE=\"@$weather[$i]\" SIZE=5 MAXLENGTH=32><img src ='${HimageDir}/$HweatherImage[@$weather[$i]]' width='16' height='16'>$HweatherName[@$weather[$i]]</TD>\n");
		} else {
			out("<TD align=\"center\"><INPUT TYPE=\"hidden\" NAME=\"WEATHER\" VALUE=\"@$weather[$i]\" SIZE=5 MAXLENGTH=32>-</TD>\n");
		}
		$i++;
	}
	out("</TR></TABLE></TD></TR>\n");
	out(<<END);
</TR></TABLE>
<TR><TH colspan=8>${HtagTH_}${AfterName} 데이터 수정${H_tagTH} <INPUT TYPE="submit" VALUE="수정" NAME="ChangeButton"></TH></TR>
</TR></TABLE>
<INPUT TYPE="hidden" VALUE="dummy" NAME="IslandChange"></FORM></DIV>
END
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
# 기록 로그
sub logHistory {
	open(HOUT, ">>${HdirName}/hakojima.his");
	print HOUT "$HislandTurn,$_[0]\n";
	close(HOUT);
}

# 발견
sub logDiscover {
	my($name, $owner) = @_;
	logHistory("${HtagName_}${name}${H_tagName}이 ${HtagName_}${owner}${H_tagName}에 의해 발견되었습니다.");
}

# 섬 이름의 변경
sub logChangeName {
	my($name1, $name2) = @_;
	logHistory("${HtagName_}${name1}${AfterName}${H_tagName}, 명칭을${HtagName_}${name2}${AfterName}${H_tagName}에 변경.");
}

# 소유자 이름의 변경
sub logChangeOwnerName {
	my($name1, $name2) = @_;
	logHistory("${HtagName_}${name1}${AfterName}${H_tagName}, 소유자를${HtagName_}${name2}${H_tagName}에 변경.");
}

# 부정 접속
sub tempNoReferer {
	out(<<END);
${HtagBig_}수상한 점은 알려 주세요 m(_ _)m${H_tagBig}$HtempBack
END
}

# 섬이 가득 찬 경우
sub tempNewIslandFull {
	out(<<END);
${HtagBig_}신청이 몰려 ${AfterName}이 가득 찼으므로 등록할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 신규에서 섬 이름이 없는 경우
sub tempNewIslandNoName {
	out(<<END);
${HtagBig_}${AfterName} 이름이 필요합니다.${H_tagBig}$HtempBack
END
}

# 신규에서 섬 이름이부정이 경우
sub tempNewIslandBadName {
	out(<<END);
${HtagBig_}',?()<>\$'가 들어 있거나, '무인${AfterName}' 같은 이름은 피하세요.${H_tagBig}$HtempBack
END
}

# 신규에서 소유자 이름이 없는 경우
sub tempNewIslandNoOwnerName {
	out(<<END);
${HtagBig_}당신의 이름이필요입니다.${H_tagBig}$HtempBack
END
}

# 신규에서 소유자 이름이부정이 경우
sub tempNewIslandBadOwnerName {
	out(<<END);
${HtagBig_}',?()<>\$' 문자가 들어간 이름은 피하세요.${H_tagBig}$HtempBack
END
}

# 이미 같은 이름의 섬이 있는 경우
sub tempNewIslandAlready {
	out(<<END);
${HtagBig_}그${AfterName}라면이미 발견되어 있습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호가 없는 경우
sub tempNewIslandNoPassword {
	out(<<END);
${HtagBig_} 비밀번호가필요입니다.${H_tagBig}$HtempBack
END
}

# 섬이 발견되었습니다.
sub tempNewIslandHead {
	out(<<END);
<DIV align='center'>
${HtagBig_}${AfterName}이 발견되었습니다.${H_tagBig}<BR>
${HtagBig_}${HtagName_}'${HcurrentName}'${H_tagName}을 찾았습니다.${H_tagBig}<BR>
$HtempBack<BR>
</DIV>
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
	return true;
}
function Navi(x, y) {
	return true;
}
function NaviClose() {
	return true;
}
function sv(x, y, land) {
	com_str = '(' + x + ', ' + y + ') ' + land + "\\n";
	status = com_str;
	return true;
}
function scls() {
	NaviClose();
	status = '';
	return false;
}
//-->
</SCRIPT>
END
}

# 이름 변경실패
sub tempChangeNothing {
	out(<<END);
${HtagBig_}이름과 비밀번호가 모두 비어 있습니다.${H_tagBig}$HtempBack
END
}

# 이름 변경자금 부족
sub tempChangeNoMoney {
	out(<<END);
${HtagBig_}자금 부족으로 변경할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 이름 변경 성공
sub tempChange {
	out(<<END);
${HtagBig_}변경을 완료했습니다.${H_tagBig}$HtempBack
END
}

# 강제 삭제 로그
sub logDeleteIsland {
	my($id, $name) = @_;
#	logHistory("${HtagName_}${name}${AfterName}${H_tagName},<B>관리자 권한로</B>${HtagDisaster_}퇴장${H_tagDisaster}이 됩니다.");
#	logHistory("${HtagName_}${name}${AfterName}${H_tagName}에, 돌진으로<B>천벌이하강리</B>아라는 마에${HtagDisaster_}바다에침몰시${H_tagDisaster}흔적도 없이 사라졌습니다.");
	logHistory("${HtagName_}${name}${AfterName}${H_tagName}은, 바다신의 <B>분노를 받아</B> 육지가 모두 ${HtagDisaster_}침몰했습니다.${H_tagDisaster}");
}

# 섬의 강제 삭제(스페샤루 모드)
sub tempDeleteIsland {
	my($name) = @_;
	out(<<END);
${HtagBig_}${name}${AfterName}을 강제 삭제했습니다.${H_tagBig}$HtempBack
END
}

1;
