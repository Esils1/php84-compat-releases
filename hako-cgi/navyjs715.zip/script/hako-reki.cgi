#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 역대순위모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------

# 데이터 파일 이름
my $HrekidaiData = 'rekidai.cgi';

# 기록할 데이터 종류(기본적으로 $island->{KIND}의 KIND에 들어 있어 데이터를 참조할 수 있는 항목으로 한정됩니다)
my @HrekidaiKind = (
	'pop',
	'area',
	'farm',
	'factory',
	'mountain',
	'defeatcount',
	'monsterkill',
	'monslive',
	'unknownlive',
	'gain',
	'totalNavyExp',
	'navyExp',
	'portExp',
	'totalSink',
);
# 데이터 항목 이름
my @HrekidaiName = (
	'인구',
	'면적',
	'농장',
	'직장',
	'채굴장',
	"${AfterName}격파 수",
	'괴수퇴치 수',
	'괴수출현 수',
	'소속 불명 함정 출현 수',
	'총 획득 경험치',
	'함정 경험치 합계',
	'함정 경험치',
	'군항 경험치',
	'함정 격침 수',
);
# 데이터가미지이미지
my @HrekidaiImage = (
	"$HlandTownImage[$#HlandTownImage]",
	"$HlandImage[$HlandPlains]",
	"$HlandImage[$HlandFarm]",
	"$HlandImage[$HlandFactory]",
	"$HlandImage[$HlandMountain][1]",
	"$HlandImage[$HlandWaste][1]",
	'monster7.gif',
	'monster0.gif',
	'navy1.gif',
	"$HlandImage[$HlandBase]",
	'navy2.gif',
	'navy3.gif',
	'navy0.gif',
	"$HnavyImageZ",
);
# 데이터 뒤에 추가
my @HrekidaiAfterName = (
	"$HunitPop",
	"$HunitArea",
	"0$HunitPop 규모",
	"0$HunitPop 규모",
	"0$HunitPop 규모",
	"$AfterName",
	"$HunitMonster",
	"$HunitMonster",
	'함',
	'',
	'',
	'',
	'',
	'함',
);

# 순위기록 수(가동안의 변경도 가능합니다)
my $HrecordNo = 10;
# 순위 표시 수(기록 수보다 크게 해도 의미 없습니다)
my $Hranking = 10;
# 한 화면에 표시되는 항목 수
my $Hcolum = 2;
#----------------------------------------------------------------------
# 필요에 따라 설정하는 항목은 여기까지입니다
#----------------------------------------------------------------------
# 데이터 읽기
sub readReki {
	# 데이터 파일 열기
	if(!open(RIN, "<${HlogdirName}/${HrekidaiData}")) {
		rename("${HlogdirName}/tmp${HrekidaiData}", "${HlogdirName}/${HrekidaiData}");
		if(!open(RIN, "${HlogdirName}/${HrekidaiData}")) {
			return 0;
		}
	}
	my $kind;
	my $j = 0;
	while($line = <RIN>) {
		if($line =~ /^([0-9]*),([0-9]*),([0-9]*),(.*)$/) {
			($id, $value, $turn, $name) = ($1, $2, $3, $4);
			$rekidai{$kind}[$j]->{'id'} = $id;
			$rekidai{$kind}[$j]->{'value'} = $value;
			$rekidai{$kind}[$j]->{'turn'} = $turn;
			$rekidai{$kind}[$j]->{'name'} = $name;
			$HidToNumberR{$kind}{$id} = $j;
			$j++;
		} elsif($line =~ /^<(.*)>$/) {
			$kind = $1;
			$j = 0;
		}
	}
	# 파일을 닫기
	close(RIN);

	return 1;
}

# 데이터 쓰기
sub writeReki {
	my $i;
	open(ROUT, ">${HlogdirName}/tmp${HrekidaiData}");
	foreach (@HrekidaiKind) {
		print ROUT '<'. $_. '>'. "\n";
		my @rdata = @{$rekidai{$_}};
		for($i = 0; $i < $HrecordNo; $i++) {
			my($id, $value, $turn, $name) = ($rdata[$i]->{'id'}, $rdata[$i]->{'value'}, $rdata[$i]->{'turn'}, $rdata[$i]->{'name'});
			print ROUT "$id,$value,$turn,$name\n";
		}
	}
	close(ROUT);
	unlink("${HlogdirName}/${HrekidaiData}");
	rename("${HlogdirName}/tmp${HrekidaiData}", "${HlogdirName}/${HrekidaiData}");
}

# 갱신 처리
sub mainReki {
	# 데이터 읽기
	readReki();

	# 바다전쟁 데이터가져오기($island->{KIND}이외)
	my($i, $island, $monster, $monslive, $fkind, $sink, $selfsink);
	foreach $i (0..$islandNumber) {
		$island = $Hislands[$i];

		$island->{'defeatcount'} = @{$island->{'defeat'}} / 2;

		$monster = $island->{'monsterlive'};
		$monster =~ /([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)/;
		$island->{'monslive'} = $1;
		$island->{'unknownlive'} = $4;

		$sink = $island->{'sink'};
		$sinkself = $island->{'sinkself'};
		foreach (0..$#HnavyName) {
			next if($HnavySpecial[$_] & 0x8); # 군항은 합계에 포함하지 않음
			$island->{'totalSink'} += $island->{'sink'}[$_] + $island->{'sinkself'}[$_];
			$island->{'selfSink'} += $island->{'sinkself'}[$_];
		}
		$fkind = $island->{'fkind'};
		foreach (@$fkind) {
			my($eId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack(hex($_));
			my $kind = 'navy'. $nKind; # 보유 수
			$island->{$kind}++;
			$island->{'totalNavyExp'} += $nExp;
			if($HnavySpecial[$nKind] & 0x8) {
				$island->{'portExp'} = $nExp if($nExp> $island->{'portExp'});
			} else {
				$island->{'navyExp'} = $nExp if($nExp> $island->{'navyExp'});
			}
		}
	}
	# 바다전쟁 데이터가져오기여기까지

	# 순위갱신
	my($kind,, $id, $value, $turn, $name, $n, $reki);
	foreach $kind (@HrekidaiKind){
		$j = $HrecordNo;
		foreach $i ($HbfieldNumber..$islandNumber) {
			$island = $Hislands[$i];
			$id = $island->{'id'};
			$name = islandName($island);
			$value = $island->{$kind};
			$n = $HidToNumberR{$kind}{$id};
			if(defined $n) {
				if($value> $rekidai{$kind}[$n]->{'value'}) {
					$rekidai{$kind}[$n]->{'id'} = $id;
					$rekidai{$kind}[$n]->{'value'} = $value;
					$rekidai{$kind}[$n]->{'turn'} = $HislandTurn;
					$rekidai{$kind}[$n]->{'name'} = $name;
				} elsif($rekidai[$n]->{'name'} ne $name){
					$rekidai[$n]->{'name'} = $name;
				}
			} else {
				$rekidai{$kind}[$j]->{'id'} = $id;
				$rekidai{$kind}[$j]->{'value'} = $value;
				$rekidai{$kind}[$j]->{'turn'} = $HislandTurn;
				$rekidai{$kind}[$j]->{'name'} = $name;
				$j++;
			}
		}

		# 인구가 같으면 이전 턴의 순서를 유지
		my $max = @{$rekidai{$kind}} - 1;
		my @idx = (0..$max);
		@idx = sort { $rekidai{$kind}[$b]->{'value'} <=> $rekidai{$kind}[$a]->{'value'} || $a <=> $b } @idx;
		@{$rekidai{$kind}} = @{$rekidai{$kind}}[@idx];
		splice(@{$rekidai{$kind}}, $HrecordNo);
	}

	# 데이터 읽기
	writeReki();

}

# 순위 표시
sub rankingReki {
	# 데이터 읽기
	readReki();
	# 화면 출력
	unlock();

	out(<<END);
<DIV ID='Ranking'>
<H1>역대순위</H1>
<P>
${AfterName}이 사라져도 이름은 남습니다!! 목표는 <B>ALL NO.1</B>! 존재하는 ${AfterName}은 <B>관광</B>할 수 있습니다.
</P>
[<A HREF="${HthisFile}?Rank=0">부문별도 No.1(턴${HislandTurn})로</A>]
END
	splice(@HrekidaiKind, -5) if($HnavyName[0] eq '');
	$Hcolum = 1 if(!$Hcolum);
	foreach (0..$#HrekidaiKind) {
		out("<TABLE ALIGN=\"center\" width=\"100%\"><TR>\n") if(!($_ % $Hcolum));
		out(<<END);
<td width="9%">
<TABLE BORDER=1 width="100%">
<TR><TD ALIGN="left"><img src="$HrekidaiImage[$_]"></TD>
<TD class="RankingCell" colspan=3 ALIGN="center" width="100%"><span class="bumon"><B>${HrekidaiName[$_]}</B></span></TD></TR>
<TR><TH>${HtagTH_}순위${H_tagTH}</TH><TH>${HtagTH_}${AfterName} 이름${H_tagTH}</TH><TH>${HtagTH_}기록${H_tagTH}</TH><TH>${HtagTH_}턴${H_tagTH}</TH></TR>
END
		my $max = $Hranking - 1;
		foreach my $i (0..$max) {
			my $id = $rekidai{$HrekidaiKind[$_]}[$i]->{'id'};
			my $name = $rekidai{$HrekidaiKind[$_]}[$i]->{'name'};
			my $value = $rekidai{$HrekidaiKind[$_]}[$i]->{'value'};
			my $turn = $rekidai{$HrekidaiKind[$_]}[$i]->{'turn'};

			if(($value ne '') && ($value != 0)) {
				my $j = $i + 1;
				my $value = "${value}${HrekidaiAfterName[$_]}";
				1 while $value =~ s/(.*\d)(\d\d\d)/$1,$2/;

				my ($Str1, $Str2);
				my $n = $HidToNumber{$id};
				if(defined $n) {
					$Str1 = "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=${id}\" alt=\"ID=${id}\" title=\"ID=${id}\">${HtagName_}";
					$Str2 = "${H_tagName}</A>";
				} else {
					$Str1 = $HtagName2_;
					$Str2 = $H_tagName2;
				}
				if($j == 1) {
				out(<<END);
<TR>
<TH ALIGN="right"><H3 style='display:inline'>$j</H3></TH>
<TH><H3 style='display:inline'>${Str1}${name}${Str2}</H3></TH>
<TH><H3 style='display:inline'>$value</H3></TH>
<TH><H3 style='display:inline'>$turn</H3></TH>
</TR>
END
				} else {
				out(<<END);
<TR>
<TD ALIGN="right">$j</TD>
<TD ALIGN="center">${Str1}${name}${Str2}</TD>
<TD ALIGN="center">$value</TD>
<TD ALIGN="center">$turn</TD>
</TR>
END
				}
			} else {
			out(<<END);
<TR>
<TD ALIGN="right"> - </TD>
<TD ALIGN="center">${HtagName_} - ${H_tagName}</TD>
<TD ALIGN="center"> - </TD>
<TD ALIGN="center"> - </TD>
</TR>
END
			}
		}
		out("</TABLE></TD>\n");
		out("</TR></TABLE>\n") if(!(($_ + 1) % $Hcolum));
	}
	out("</TR></TABLE>\n") if((($#HrekidaiKind + 1) % $Hcolum));
	out("</DIV>\n");
# 저작권 표시 - 다른 모형정원로 이식하는 경우 아래 주석 처리를 참고해 주세요.
	out("<DIV align='right'>patchworked by <a style='text-decoration:none;' href='http://no-one.s53.xrea.com/' target='_top'>neo_otacky</a></DIV>\n");
}

1;

###----------###
### 도입방법 ###
###----------###

### 행 앞부분의 #을 포함해 복사해 붙여넣으세요. ###은 도입 설명용 주석이므로 복사할 필요가 없습니다

### 메인 모드분기 부분에추가
#} elsif($HmainMode eq 'rekidai') {
#	# 역대기록
#	require('./hako-reki.cgi');
#	rankingReki();

### CGI 읽기 부분에추가 sub cgiInput 내의 main mode 의가져오기 부분
#	} elsif($getLine =~ /Rekidai=([0-9]*)/) {
#		$HmainMode = 'rekidai';

### 헤더나 메인 페이지의 링크 부분에추가
#	out(qq|[<A href="$HthisFile?Rekidai=0" target="_blank">역대기록</A>] |);
### out 을사용하지 않아도해도,[<A href="$HthisFile?Rekidai=0" target="_blank">역대기록</A>]이 HTML 안에 기술되도록 하면 됩니다

### 턴 갱신 처리에추가 sub turnMain 내의 writeIslandsFile 의상주변
#		# 역대기록 처리
#		require './hako-reki.cgi';
#		mainReki();

### 바다전쟁 데이터가져오기(line83-107)부분을 삭제또는 주석 처리로서, 기록할 데이터 종류의 설정을 치환해 주세요.
