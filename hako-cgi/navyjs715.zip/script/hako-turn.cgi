#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 턴진행모듈(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 모형정원 제도 2nd
#								 v1.5
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							 모형정원 모형정원 바다전쟁
#								 v1.3
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#----------------------------------------------------------------------
# 턴진행 모드
#----------------------------------------------------------------------
# 메인
sub turnMain {

	# 최종 갱신 시간을 갱신
	$HislandLastTime += $HunitTime if($HrepeatTurn);

	if($HallyNumber && $HrepeatTurn) { # 동맹의 정세를 표시스 데이터의 지우기
		for($i = 0; $i < $HallyNumber; $i++) {
			$Hally[$i]->{'ext'}[0] = 0;
			$Hally[$i]->{'ext'}[1] = 0;
			$Hally[$i]->{'ext'}[2] = 0;
			$Hally[$i]->{'ext'}[3] = 0;
			$Hally[$i]->{'ext'}[4] = 0;
		}
	}

	my $repeatTurn = $HrepeatTurn;
	while ($repeatTurn--) {
		my($i, $j, $s, $d, $island);

		# 순서결메
		my(@order) = randomArray($HislandNumber);

		my($island);
		# 좌표배열을 만들기
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			makeRandomIslandPointArray($island);
		}

		# 턴번호
		$HislandTurn++;
		# 정전(개발, 전투)기간마지막의 턴에서는 리피와 를정지
		$repeatTurn = 0 if($HislandTurn == $HarmisticeTurn || $HislandTurn == $HsurvivalTurn || $HislandTurn == $HislandChangeTurn);

		if($HarmisticeTurn || $HsurvivalTurn ||$Htournament) {
			# 재해있음?
			if(!$repeatTurn && !$Htournament) {
				# 마지막의 턴은 재해있음
				if ($HislandTurn < $HarmisticeTurn) {
					# 휴전 기간은 무재해
					$HnoDisFlag = 1;
				} else {
					# 재해있음
					$HnoDisFlag = 0;
				}
			} else {
				# 마지막의 턴이외는 재해없음
				$HnoDisFlag = 1;
			}
		} elsif($HuseDeWar) {
			# 전쟁시작 로그
			my @newWarIsland;
			for($i=0;$i < $#HwarIsland;$i+=4){
				my($tn1) = $HidToNumber{$HwarIsland[$i+1]};
				my($tn2) = $HidToNumber{$HwarIsland[$i+2]};
				next if(($tn1 eq '') || ($tn2 eq ''));
				#my($name) = islandName($Hislands[$tn1]);
				#my($tName) = islandName($Hislands[$tn2]);
				#$name = "${HtagName_}${name}${H_tagName}";
				#$tName = "${HtagName_}${tName}${H_tagName}";
				my($isl) = $Hislands[$tn1];
				my($tIsl) = $Hislands[$tn2];
				my($name) = "${HtagName_}${\islandName($isl)}${H_tagName}";
				my($tName) = "${HtagName_}${\islandName($tIsl)}${H_tagName}";
				if($HwarIsland[$i+3]) {
					my($f, $fturn) = ($HwarIsland[$i+3] % 10, int($HwarIsland[$i+3] / 10) + $HdeclareTurn);
					if($fturn < $HislandTurn) {
						if($f == 1) {
							$HwarIsland[$i+3] = 0;
							logOut("${name}이${tName}에제안했던 정전은 폐기되었습니다.", $HwarIsland[$i+1], $HwarIsland[$i+2]);
						} elsif($f == 2) {
							$HwarIsland[$i+3] = 0;
							logOut("${tName}이${name}에제안했던 정전은 폐기되었습니다.", $HwarIsland[$i+2], $HwarIsland[$i+1]);
						}
					}
				}
				push(@newWarIsland, @HwarIsland[$i..$i+3]);
				next if($HwarIsland[$i] != $HislandTurn);
				if($HmatchPlay> 1) {
					foreach ($isl, $tIsl){
						# 카운터 재설정
						$_->{'subSink'} = $_->{'sink'};
						$_->{'subSinkself'} = $_->{'sinkself'};
						my @wext = @{$_->{'ext'}};
						shift(@ext);
						unshift(@ext, $HislandTurn);
						push(@ext, $_->{'monsterkill'});
						push(@ext, 0);
						$_->{'subExt'} = \@ext;
						# 섬의 상태를 저장
						island_save($_, $HsavedirName, 'save', 0);
					}
				}
				my($wname) = "$name${HtagDisaster_} VS ${H_tagDisaster}$tName";
				logOut("${wname}전쟁 발발!!", $HwarIsland[$i+1], $HwarIsland[$i+2]);
				logHistory("${wname}전쟁 발발!!");
			}
			@HwarIsland = @newWarIsland;
		}
		if($HsurvivalTurn && ($HislandTurn == $HsurvivalTurn) && (-e "${HefileDir}/setup.html")){
			unlink("${HefileDir}/setup.html");
		}

		# 수입, 소비단계
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];

			# 코멘트란 변경 확인
			if($HjoinCommentPenalty && !$island->{'predelete'}) {
				if(($HislandTurn - $island->{'birthday'}>= $HjoinCommentPenalty) && ($island->{'comment'} eq $HjoinComment)){
					push(@HpreDeleteID, $island->{'id'});
					$island->{'predelete'} = (!$HautoKeeperSetTurn) ? 99999999 : ($HautoKeeperSetTurn + 1);
					my $name = islandName($island);
					logHistory("${HtagName_}${name}${H_tagName}, 코멘트이 없어서 <B>관리자 보관</B>.");
				}
			}
			# 변수의 초기화
			undef $island->{'ships'};
			undef $island->{'shipk'};
			undef $island->{'cIncome'};
			undef $island->{'rinmoney'};
			undef $island->{'rinfood'};
			undef $island->{'slaughterer'};
			$island->{'oilincome'} = 0;
			$island->{'inMoney'} = 0;
			$island->{'inFood'} = 0;
			$island->{'payFood'} = 0;
			$island->{'upkeepMoney'} = 0;
			$island->{'upkeepMoneyPlus'} = 0;
			$island->{'upkeepMoneyProbe'} = 0;
			$island->{'upkeepAlly'} = 0;
			$island->{'upkeepFood'} = 0;
			$island->{'upkeepFoodPlus'} = 0;
			$island->{'shellMoney'} = 0;
			# 턴시작전의 인구,자금, 식량을 메모루
			$island->{'oldPop'} = $island->{'pop'};
			$island->{'oldMoney'} = $island->{'money'};
			$island->{'oldFood'} = $island->{'food'};
			# 피우호국의 플래그 설정
			my $amityNum = 0;
			foreach (@{$island->{'amity'}}) {
				my $amn = $HidToNumber{$_};
				if(defined $amn) {
					# 나를 우호국으로 설정한 섬 ID 을'amityBy'에저장
					push(@{$Hislands[$amn]->{'amityBy'}}, $island->{'id'});
					$amityNum++;
				}
			}
			next if($island->{'predelete'} || $island->{'rest'});

			# 우호국유지비
			$island->{'upkeepAmity'} = ($HarmisticeTurn) ? 0 : $amityNum * $HamityMoney;
			$island->{'money'} -= $island->{'upkeepAmity'};
			$island->{'money'} = 0 if($island->{'money'} < 0);

			# 명령 확인(함대 이동, 파견, 귀환 처리를 할지)
			my($comArray, $c, $tflag, $ctflag);
			$comArray = $island->{'command'};
			$tflag = 0;
			$ctflag = int($island->{'itemAbility'}[6]);
			for($c = 0; $c < $HcommandMax; $c++) {
				my($ckind) = $comArray->[$c]->{'kind'};
				my($carg) = $comArray->[$c]->{'arg'};
				$carg--;
				if ($carg < 0) {
					$carg = 0;
				} elsif ($carg> 3) {
					$carg = 3;
				}
				$island->{'NavyMove_flag'}[$carg] = 1 if(($ckind == $HcomNavyMove) || ($ckind == $HcomNavySend) || ($ckind == $HcomNavyReturn));
				$tflag += $HcomTurn[$ckind];
				last if($tflag>= $ctflag);
			}

			# 기중단계
			if($HuseWeather) {
				my(@tempWeather) = ();
				foreach (1..$#HweatherName) {
					@tempWeather = (@tempWeather, ($_)x$HweatherRatio[$_] );
				}
				my($kion, $kiatu, $situdo, $kaze, $jiban, $nami, $ijoh, @weather) = @{$island->{'weather'}};
				# 기온
				my $dkion = ($HweatherSpecial[$weather[0]] & 0xF) - 8;
				$dkion = ($dkion == -8) ? 0 : $dkion * $HweatherSpecialRatio[0] + random($HrKion * 2 + 1) - $HrKion;
				$kion += $dkion;
				$kion = ($kion> 41) ? 25 : ($kion < -12) ? 0 : $kion;
				$kion = ($kion> 40) ? 40 : ($kion < -10) ? -10 : $kion;
				# 기압
				my $dkiatu = (($HweatherSpecial[$weather[0]] & 0xF0)>>(4*1)) - 8;
				$dkiatu = ($dkiatu == -8) ? 0 : $dkiatu * $HweatherSpecialRatio[1] + random($HrKiatu * 2 + 1) - $HrKiatu;
				$kiatu += $dkiatu;
				$kiatu = ($kiatu> 1105) ? 1000 : ($kiatu < 895) ? 1000 : $kiatu;
				$kiatu = ($kiatu> 1100) ? 1100 : ($kiatu < 900) ? 900 : $kiatu;
				# 습도
				my $dsitudo = (($HweatherSpecial[$weather[0]] & 0xF00)>>(4*2)) - 8;
				$dsitudo = ($dsitudo == -8) ? 0 : $dsitudo * $HweatherSpecialRatio[2] + random($HrSitudo * 2 + 1) - $HrSitudo;
				$situdo += $dsitudo;
				$situdo = ($situdo> 103) ? 90 : ($situdo < -1) ? 60 : $situdo;
				$situdo = ($situdo> 100) ? 100 : ($situdo < 0) ? 0 : $situdo;
				# 풍속
				$kaze += (abs($dkiatu)> $HrKiatu / 2) ? abs($dkiatu / 30) : -abs($dkiatu / 5);
				$kaze = ($kaze> 50) ? 50 : ($kaze < 0) ? 0 : int($kaze);
				# 지반지정수
				$jiban += int(($situdo - 50) / 4) if($situdo> 60);
				$jiban -= int($kion / 2) if($kion> 20);
				$jiban = ($jiban> 100) ? 100 : ($jiban < 0) ? 0 : $jiban;
				# 파력지정수
				$nami += ($kaze < 5) ? -int($kaze / 3) : int($kaze / 3);
				$nami = ($nami> 100) ? 100 : ($nami < 0) ? 0 : $nami;
				# 이상지정수(사용하지 않고)
				$ijoh = 0;
				# 날씨결정
				my(@newWeather);
				$newWeather[0] = $tempWeather[random($#tempWeather)];
				$newWeather[1] = (random(10) < 7) ? $weather[0] : $tempWeather[random($#tempWeather)];
				$newWeather[2] = (random(10) < 9) ? $weather[1] : $tempWeather[random($#tempWeather)];
				foreach (1..$HtopLogTurn) {
					$newWeather[($_ + 2)] = ($weather[($_ + 1)] == '') ? 0 : $weather[($_ + 1)];
				}
				@newWeather = ($kion, $kiatu, $situdo, $kaze, $jiban, $nami, $ijoh, @newWeather);
				$island->{'weather'} = \@newWeather;
			}
		}

		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			estimate($order[$i]);
			next if($island->{'predelete'} || $island->{'rest'});

			# 수입 처리
			income($island);
			# 해군의 보급 처리
			supplyNavy($island);
		}

		# 선 줄 처리
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			next if($island->{'predelete'} || $island->{'rest'});
			doPreEachHex($island);
		}

		# 명령 처리
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			next if(!($HforgivenGiveUp && $island->{'command'}[0]->{'kind'} == $HcomGiveup) && ($island->{'predelete'} || $island->{'rest'}));
			# 반환값이 1이 될 때까지 반복
			$HflagST = 0;
			$HflagCommand = 0;
			my $cflag = int($island->{'itemAbility'}[6]);
			$HflagDoNothing = ($island->{'command'}[0]->{'kind'} != $HcomDoNothing);
			my($safety) = $HcommandMax * 2;
			while ($HflagCommand < $cflag) {
				my($flagcom) = $HcomTurn[$island->{'command'}->[0]->{'kind'}];
				last if($HflagCommand + $flagcom> $cflag);
				if($island->{'comflag'}) {
					$HflagCommand += $flagcom;
					doCommand($island);
				} else {
					$HflagCommand += doCommand($island);
				}
				last if(!$safety--);
			}
			# 개간 로그(정리해서 로그 출력)
			logMatome($island);
		}

		# 성장 및 단일 헥스 재해
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			next if($island->{'predelete'} || $island->{'rest'});
			doEachHex($island);
		}

		my($remainCampNumber, $campDelete);
		if($HarmisticeTurn && $HallyNumber) {
			# 진영소멸판정
			$remainCampNumber = $HallyNumber;
			if ($HcampDeleteRule) {
				my($threshold);
				if($HcampDeleteRule == 1) {
					my($anumber) = 0;
					for ($i = 0; $i < $HallyNumber; $i++) {
						$anumber++ if($Hally[$i]->{'number'});
					}
					$anumber = 1 if(!$anumber);
				 	$threshold = 50 / $anumber;
				} else {
				 	$threshold = $HcampDeleteRule;
				}
				for ($i = 0; $i < $HallyNumber; $i++) {
					if ($Hally[$i]->{'number'} && ($Hally[$i]->{'occupation'} < $threshold)) {
						push(@{$campDelete->{'id'}}, $Hally[$i]->{'id'});
						push(@{$campDelete->{'name'}}, $Hally[$i]->{'name'});
						$campDelete->{'count'}++;
						foreach (@{$Hally[$i]->{'memberId'}}){
							if($HautoKeeper != 1) {
								$Hislands[$HidToNumber{$_}]->{'dead'} = 1;
							} else {
								$Hislands[$HidToNumber{$_}]->{'delete'} = 1;
							}
						}
						if($HautoKeeper == 1) {
							logCampPreDelete($Hally[$i]->{'name'});
						} else {
							$remainCampNumber--;
							logCampDelete($Hally[$i]->{'name'});
						}
					}
				}
			}
		}

		# 참가 섬에 대한 제재 내용을 읽기
		readPunishData();

		# 섬 전체 처리
		# 괴수출현인구플래그 처리
		foreach (@HdisMonsBorder) {
			$HdisMonsBorderMax = $_ if($HdisMonsBorderMax <= $_);
		}
		$HdisMonsBorderMin = $HdisMonsBorderMax;
		foreach (@HdisMonsBorder) {
			next if(!$_);
			$HdisMonsBorderMin = $_ if($HdisMonsBorderMin>= $_);
		}
		# 거대괴수출현인구플래그 처리
		foreach (@HdisHugeBorder) {
			$HdisHugeBorderMax = $_ if($HdisHugeBorderMax <= $_);
		}
		$HdisHugeBorderMin = $HdisHugeBorderMax;
		foreach (@HdisHugeBorder) {
			next if(!$_);
			$HdisHugeBorderMin = $_ if($HdisHugeBorderMin>= $_);
		}
		# 함정 출현인구플래그 처리
		foreach (@HdisNavyBorder) {
			$HdisNavyBorderMax = $_ if($HdisNavyBorderMax <= $_);
		}
		$HdisNavyBorderMin = $HdisNavyBorderMax;
		foreach (@HdisNavyBorder) {
			next if(!$_);
			$HdisNavyBorderMin = $_ if($HdisNavyBorderMin>= $_);
		}
		# 섬 전체 처리
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			next if($island->{'predelete'} || $island->{'rest'});
			doIslandProcess($island);
			undef $island->{'ships'};
			undef $island->{'shipk'};
		}

		# 섬 전체(estimate)처리
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			next if($island->{'predelete'} || $island->{'rest'});
			doIslandProcessEstimate($order[$i], $island);
			# 토너먼트 규정횟수만큼 전투 행위가 있었는지
			my $name = islandName($island);
			if(0 && $Htournament && ($HislandFightMode == 2) && ($island->{'fight_id'}> 0)) { # 토너먼트 규정전투횟수 확인
				if((int($HfightTurn / 2) == ($HislandChangeTurn - $HislandTurn)) &&
					($island->{'ext'}[6] - $island->{'subExt'}[6] < $do_fight) &&
					($island->{'ext'}[8] - $island->{'subExt'}[8] < min(1,$do_fight))) {
					my $fn = $HidToNumber{$island->{'fight_id'}};
					my $tIsland = $Hislands[$fn];
					next if($HnofleetNotAvail && $island->{'ships'}[4] && !$tIsland->{'ships'}[4]);
					logGiveup_no_do_fight($island->{'id'}, islandName($island));
					if($HautoKeeper != 1) {
						$island->{'dead'} = 1;
						logTDead($island->{'id'}, $name);
					} else {
						$island->{'delete'} = 1;
					}
				}
			}
			# 코어보유 확인
			if($HcorelessDead && !$island->{'field'} && !$island->{'event'}[0] && !$island->{'core'} &&
				!($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn)) &&
				!($HsurvivalTurn && ($HislandTurn <= $HsurvivalTurn)) &&
				!($Htournament && ($HislandFightMode < 2)) &&
				!($HislandTurn - $island->{'birthday'} <= $HdevelopTurn)
				) {
				logHistory("${HtagName_}${name}${H_tagName}의$HlandName[$HlandCore][0]이${HtagDisaster_}괴멸${H_tagDisaster}했습니다!");
				if($HcorelessDead == 1) {
					$island->{'dead'} = 1;
					logTDead($island->{'id'}, $name);
				} else {
					$island->{'delete'} = 1;
				}
			}
		}

		# 사멸판정·이벤트판정
		my $predelNumber = @HpreDeleteID; # 관리자 보관의 섬은 사멸 처리에서 도망됨
		my $remainNumber = $HislandNumber - $predelNumber;
		my $deadline = ($HarmisticeTurn || $HsurvivalTurn || $Htournament) ? 0 : $HautoKeeper;
		my $tournamentflg = 0;
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			if($island->{'event'}[0]) {
				# 이벤트판정
				my $winner;
				if($island->{'event'}[1] - $HnoticeTurn == $HislandTurn) {
					# 이벤트시작전(유예 기간)
					my $type = $HeventName[$island->{'event'}[6]];
					my $name = islandName($island);
					islandDeadNavy($island);# 함정 처리
					$island->{'comment'} = "<B>$type 개최!</B>";
					if(!$island->{'event'}[11]) {
						$island->{'comment'}.= "(<span class=attention>주의!</span>파견할 수 있는 기간은<B>턴$island->{'event'}[1]만</B>입니다)";
					} else {
						$island->{'comment'}.= "(<span class=attention>주의!</span><B>턴$island->{'event'}[1]에서</B>부터 파견 가능합니다)";
					}
					logHistory("${HtagName_}${name}${H_tagName}에서${HtagDisaster_}$type${H_tagDisaster}개최!(${HtagDisaster_}$island->{'event'}[1]턴${H_tagDisaster}시작)");
				} elsif($island->{'event'}[1] <= $HislandTurn) {
					# 이벤트 개최안
					$winner = islandEventNavy($island, $island->{'event'}[6]);
				}
				if($winner != 0) {
					my $type = $HeventName[$island->{'event'}[6]];
					my $name = islandName($island);
					$island->{'comment'} = "<B>$type 은종료했습니다!</B>($HislandTurn 턴)";
					if($winner> 0) {
						$island->{'comment'}.= " 승자:<span class=islName>$Hislands[$HidToNumber{$winner}]->{'name'}$AfterName</span>";
						$winner = islandName($Hislands[$HidToNumber{$winner}]);
						logHistory("${HtagName_}${name}${H_tagName}로 개최했습니다${HtagDisaster_}$type${H_tagDisaster}데${HtagName_}${winner}${H_tagName}이<B>승리</B>했습니다!");
					} else {
						logHistory("${HtagName_}${name}${H_tagName}로 개최했습니다${HtagDisaster_}$type${H_tagDisaster}은<B>승자 없음으로 종료</B>했습니다!");
						$island->{'comment'}.= " 승자:<span class=islName>없음</span>";
					}
					undef $island->{'event'}; # 플래그지우기
				}
			} elsif($island->{'dead'} == 1) {
				# 사멸판정(플래그있음)
				island_save($island, $HfightdirName, 'lose', 0) if($HdeadToSaveAsLose);
				$island->{$HrankKind} = 0;
				$island->{'pop'} = 0;
				my($tmpid) = $island->{'id'};
				islandDeadNavy($island); # 함정 처리
				# 토너먼트에서 전투 기간 안
				$tournamentflg = fightNoFight($island, $remainNumber) if($Htournament && ($island->{'fight_id'}> 0));
				preDelIdCut($tmpid);
				$HidToNumber{$tmpid} = undef;
				deleteIslandData($island);
				$remainNumber--;
			} elsif( (!$island->{'field'} && !$island->{'predelete'} && ($island->{'pop'} <= $deadline)
						&& (!$island->{'pop'} || ($HislandTurn - $island->{'birthday'}> $HdevelopTurn)))
				|| $island->{'delete'}
				) {
				# 사멸판정
				my($tmpid) = $island->{'id'};
				islandDeadNavy($island);
				# 토너먼트에서 전투 기간 안
				$tournamentflg = fightNoFight($island, $remainNumber) if($Htournament && ($island->{'fight_id'}> 0));
				# 코어파괴
				my $dNo2 = $HidToNumber{$island->{'slaughterer2'}};
				if(defined $dNo2) {
					push(@{$Hislands[$dNo2]->{'defeat'}},(islandName($island),$HislandTurn));
				}
				my $count = 0;
				if(!$island->{'pop'}) {
					my $dNo = $HidToNumber{$island->{'slaughterer'}};
					if(defined $dNo) {
						push(@{$Hislands[$dNo]->{'defeat'}},(islandName($island),$HislandTurn));
					}
					if($HautoKeeper && !$HarmisticeTurn && !$HsurvivalTurn && !$Htournament){
						# 초기인구에서 읍을 만들기
						my($land) = $island->{'land'};
						my($landValue) = $island->{'landValue'};
						foreach (0..$island->{'pnum'}) {
							last if($count>= $HcountLandTown);
							$x = $island->{'rpx'}[$i];
							$y = $island->{'rpy'}[$i];
							# 해당 지점이 평지 또는 황무지라면 마을
							if(($land->[$x][$y] == $HlandPlains) || ($land->[$x][$y] == $HlandWaste)) {
								$land->[$x][$y] = $HlandTown;
								$landValue->[$x][$y] = $HvalueLandTown;
								$island->{'pop'} += $HvalueLandTown;
								$count++;
							}
						}
					}
				}
				if(($HautoKeeper == 1) || $island->{'delete'}) {
					push(@HpreDeleteID, $tmpid);
					$island->{'predelete'} = (!$HautoKeeperSetTurn) ? 99999999 : ($HautoKeeperSetTurn + 1);
					undef $island->{'item'};
					$remainNumber--;
					$predelNumber++;
					logTDead2PD($tmpid, islandName($island));
				} elsif($HautoKeeper && ($island->{'pop'}> 0)) {
#					$island->{'money'} = $HinitialMoney;
#					$island->{'food'} = $HinitialFood;
					$island->{'birthday'} = $HislandTurn;
					$island->{'monsterlive'} = "0,0,0,0,0";
					undef $island->{'item'};
					#undef $island->{'allyId'};
					#undef $island->{'amity'};
					logAutoKeep($tmpid, islandName($island));
				} elsif($island->{'pop'} <= 0) {
					island_save($island, $HfightdirName, 'lose', 0) if($HdeadToSaveAsLose);
					$island->{'dead'} = 1;
					$island->{$HrankKind} = 0;
					$remainNumber--;
					# 사멸 메시지
					logDead($tmpid, islandName($island));
					$HidToNumber{$tmpid} = undef;
					deleteIslandData($island);
				}
			} else {
				$island->{'ext'}[1] += int($island->{$HrankKind}/10);
			}
			undef $island->{'fkind'};
		}
			# 진영소멸판정
		if($campDelete->{'count'}) {
			foreach (0..($campDelete->{'count'} - 1)) {
				islandDeadAlly('', $campDelete->{'id'}[$_], $campDelete->{'name'}[$_]);
			}
		}
		# 섬의 소멸 처리(서바이벌 모드)
		if($HsurvivalTurn && ($HislandTurn> $HsurvivalTurn) && ($remainNumber> $HbfieldNumber + 1)){
			# $HrankKind÷(전체 섬의 $HrankKind 합계÷100)이(100÷섬 수)÷2보다 적을 시, 그 섬은 소멸

			my $rNumber = $remainNumber;
			my($allscore, $i);
			my $rn = $rNumber - 1;
			foreach $i ($HbfieldNumber..$rn) {
				$allscore += $Hislands[$i]->{$HrankKind} if(!$Hislands[$i]->{'predelete'});
			}
			my $rNumber2 = $rNumber - 1;
			foreach $i ($HbfieldNumber..$rNumber2) {
				my($island) = $Hislands[$i];
				next if($island->{'dead'} || $island->{'predelete'});
				my $iocc = ($allscore> 0) ? sprintf("%.1f", $island->{$HrankKind} * 100 / $allscore) : 0;
				my $border = sprintf("%.1f", 50/$rNumber);
				if($iocc && ($iocc < $border)){
					if($remainNumber> $HbfieldNumber + 1){
						$remainNumber--;
						islandDeadNavy($island);
						# 사멸 메시지
						my($tmpid) = $island->{'id'};
						if($HautoKeeper != 1){
							island_save($island, $HfightdirName, 'lose', 0) if($HdeadToSaveAsLose);
							$island->{'dead'} = 1;
							$island->{$HrankKind} = 0;
							logTDead($tmpid, islandName($island));
							$HidToNumber{$tmpid} = undef;
							deleteIslandData($island);
						} elsif(!$island->{'predelete'}) {
							push(@HpreDeleteID, $tmpid);
							$island->{'predelete'} = (!$HautoKeeperSetTurn) ? 99999999 : ($HautoKeeperSetTurn + 1);
							$predelNumber++;
							logTDead2PD($tmpid, islandName($island));
						}
					}
			 }
			}
		}

		if($Htournament) {
			# 토너먼트
			foreach $i ($HbfieldNumber..$islandNumber) {
				# 보상금계산
				$island = $Hislands[$i];
				next if($island->{'predelete'});
				foreach (keys %Hreward) {
					$island->{'subExt'}[12] += int($island->{$_} * $Hreward{$_});
				}
			}

			if($HislandFightMode == 0) {
				# 예선
				if($HislandTurn == $HislandChangeTurn) {
					# 개발 턴에이전
					$tournamentflg = 1;
					$HislandFightMode = 1;
					$HislandChangeTurn = $HislandTurn + $HdevelopeTurn;
				}
			} elsif($HislandFightMode == 1) {
				# 개발
				if($HislandTurn == $HislandChangeTurn) {
					# 전투 턴에이전
					$tournamentflg = 2;# 대전 상대결정 처리는 인구정렬후에서
					$HislandFightMode = 2;
					$HislandFightCount++;
					if($remainNumber> 2) {
						# 결승전이외는, 시간을 공하기
						$HislandChangeTurn = $HislandTurn + $HfightTurn;
					} else {
						# 결승전
						$HislandChangeTurn = $HislandTurn + $HfinalTurn;
					}
					my $rno = $remainNumber - 1;
					foreach $i ($HbfieldNumber..$rno){
						$island = $Hislands[$i];
						# 카운터 재설정
						$island->{'subSink'} = $island->{'sink'};
						$island->{'subSinkself'} = $island->{'sinkself'};
						my @ext = @{$island->{'ext'}};
						shift(@ext);
						unshift(@ext, $HislandTurn);
						push(@ext, $island->{'monsterkill'});
						push(@ext, 0);
						#undef $island->{'subExt'};
						$island->{'subExt'} = \@ext;
						# 섬의 상태를 저장
						island_save($island, $HsavedirName, 'save');
					}
				}
			} elsif($HislandFightMode == 2) {
				# 전투
				if($HislandTurn == $HislandChangeTurn){
					# 승패결도착 개발 턴에이전
					$tournamentflg = 3;
					if(($remainNumber < $HbfieldNumber + 2) ||
						( ($remainNumber <= $HbfieldNumber + 2) &&
						($Hislands[$HbfieldNumber]->{'fight_id'}> -1) &&
						($Hislands[$HbfieldNumber+1]->{'fight_id'}> -1) )
					) {
						# 종료
						$HislandFightMode = 9;
						$repeatTurn = 0;
						$HplayNow = 0;
						$Hislands[$HbfieldNumber]->{'ext'}[0] |= (2 ** $#HwinnerMark);
					} else {
						$HislandFightMode = 1;
					}
					$HislandChangeTurn = $HislandTurn + $HdevelopeTurn;
					my $HwinIsland = 0; # 승리했습니다 섬의 수
					my $consolationScore = 0; # 패자부활대상 섬인구
					my $consolationID = 0; # 패자부활대상 섬ID
					my $rno = $remainNumber - 1;
					my $fightIslandNumber = 0;
					my $winIslandNumber = 0;
					foreach $i ($HbfieldNumber..$rno){
						$island = $Hislands[$i];
						if($island->{'fight_id'} < 0) {
							$winIslandNumber++;
						} elsif($island->{'fight_id'}> 0) {
							$fightIslandNumber++;
						}
					}
					$winIslandNumber += int(($fightIslandNumber + 1)/2);
					foreach $i ($HbfieldNumber..$rno){
						$island = $Hislands[$i];
						my $tn = $HidToNumber{$island->{'fight_id'}};
						my $tIsland = $Hislands[$tn];
						# 전투후의 승패
						my $reward = $island->{'subExt'}[12];
						if(($tn ne '' && $island->{$HrankKind}>= $tIsland->{$HrankKind}) || ($island->{'fight_id'} == -1) || ($island->{'fight_id'} == -2)) {
							# 승치
							my $name = islandName($island);
							my $tName = islandName($tIsland);
							my $tScore = 0;
							$HwinIsland++;
							if($island->{'fight_id'}> 0){
								$island->{'money'} += $reward;
								$island->{'prizemoney'} += $reward;
								logWin($island->{'id'}, $name, "승리", $reward, $winIslandNumber);
								$tScore = $tIsland->{$HrankKind};
								$tIsland->{'fight_id'} = 0;
								if($consolationScore <= $tScore){
									$consolationScore = $tScore;
									$consolationID = $tIsland->{'id'};
								}
								$tIsland->{'lose'} = 1;
								logOut("${HtagName_}${tName}${H_tagName},<B>패배</B>.",$tIsland->{'id'});
							} elsif($island->{'fight_id'} == -2) {
								# 콜드 승리 기준
								#$island->{'money'} += $reward;
								#$island->{'prizemoney'} += $reward;
								logWin($island->{'id'}, $name, "압승!", '', $winIslandNumber);
							} else {
								# 부전승
								logWin($island->{'id'}, $name, "부전승", '', $winIslandNumber);
							}
							my(@text);
							my(@iext) = @{$island->{'subExt'}};
							foreach (0..$#iext) {
								$iext[$_] = $island->{'ext'}[$_] - $island->{'subExt'}[$_];
								$iext[$_] = -$iext[$_] if($iext[$_] < 0);
								$text[$_] = $tIsland->{'ext'}[$_] - $tIsland->{'subExt'}[$_];
								$text[$_] = -$text[$_] if($text[$_] < 0);
							}
							if($island->{'fight_id'}> 0) {
								push(@HfightLogPool, "$HislandFightCount,$island->{'id'},$name,$island->{$HrankKind},". join('-', @iext). ",$island->{'fight_id'},$tName,$tScore,". join('-', @text). ",$reward");
							} else {
								push(@HfightLogPool, "$HislandFightCount,$island->{'id'},$name,$island->{$HrankKind},". join('-', @iext). ",$island->{'fight_id'},,,,$reward");
							}
						} elsif(($tn eq '') && ($island->{'fight_id'}> 0)){
							$HwinIsland++;
							my $name = islandName($island);
							$island->{'money'} += $reward;
							$island->{'prizemoney'} += $reward;
							logWin($island->{'id'}, $name, "압승!", $reward, $winIslandNumber);
							my(@iext) = @{$island->{'subExt'}};
							foreach (0..$#iext) {
								$iext[$_] = $island->{'ext'}[$_] - $island->{'subExt'}[$_];
								$iext[$_] = -$iext[$_] if($iext[$_] < 0);
							}
							push(@HfightLogPool, "$HislandFightCount,$island->{'id'},$name,$island->{$HrankKind},". join('-', @iext). ",-2,,,,$reward");
						}
						$island->{'fight_id'} = 0;
						$island->{'subExt'}[12] = 0;
					}
					$consolationID = 0 if($HislandFightMode == 9);
					# 패배했습니다 섬의 제거
					foreach $i (0..$islandNumber){
						$island = $Hislands[$i];
						islandDeadNavy($island);
						my $name = islandName($island);
						if($island->{'lose'}){
							if(($consolationID == $island->{'id'}) && (($HwinIsland % 2) != 0) && ($HconsolationMatch)){
								# 패자부활대상 섬에서 다음 회홀 수의 경우에서 패자부활 모드
								my(@iext) = @{$island->{'subExt'}};
								foreach (0..$#iext) {
									$iext[$_] = $island->{'ext'}[$_] - $island->{'subExt'}[$_];
									$iext[$_] = -$iext[$_] if($iext[$_] < 0);
								}
								my $reward = int($island->{'subExt'}[12] / 2);
								$island->{'money'} += $reward;
								$island->{'prizemoney'} += $reward;
								push(@HfightLogPool, "$HislandFightCount,$island->{'id'},$name,$island->{$HrankKind},". join('-', @iext). ",-9,,,,");
								logOut("${HtagName_}${name}${H_tagName},<B>패자부활!</B> $reward$HunitMoney</B>의 지급 자금이 지급되었습니다.",$island->{'id'});
							} else {
								island_save($island, $HfightdirName, 'lose', 0);
								if(!$island->{'predelete'}) {
									logHistory("${HtagName_}${name}${H_tagName},<B>패배</B>.");
									$remainNumber--;
									my($tmpid) = $island->{'id'};
									if($HautoKeeper != 1){
										$island->{'dead'} = 1;
										$island->{$HrankKind} = 0;
										#OceanMente($island->{'id'});
										logTDead($tmpid, $name);
										$HidToNumber{$tmpid} = undef;
										deleteIslandData($island);
									} else {
										push(@HpreDeleteID, $tmpid);
										$island->{'predelete'} = (!$HautoKeeperSetTurn) ? 99999999 : ($HautoKeeperSetTurn + 1);
										$predelNumber++;
										logTDead2PD($tmpid, $name);
									}
								}
							}
						}
					}
				}
			}
		}

		# 순위를 갱신
		if($HrankKind eq 'point') {
			# 포인트 처리
			foreach $i (0..$islandNumber) {
				calcPoint($i);
			}
		}
		islandSort($HrankKind, 1);
		# 시상 대상 턴이면, 그 처리
		if($HturnPrizeUnit && !($HislandTurn % $HturnPrizeUnit) && $remainNumber) {
			foreach (0..($Hprize[0]->{'kind'} - 1)) {
				my($island) = $Hislands[($HbfieldNumber + $_)];
				if($Hprize[0]->{'money'}) {
					$island->{'prizemoney'} += $Hprize[0]->{'money'};
					$island->{'money'} += $Hprize[0]->{'money'};
				}
				logPrize($island->{'id'}, islandName($island), "$HislandTurn${Hprize[0]->{'name'}}", $Hprize[0]->{'money'});
				$island->{'prize'}.= "${HislandTurn},";
			}
 			if($HitemGivePerTurn && $HuseItem) { #크리스탈 쟁탈전용
				my $i = 0;
				@Hitem = @Hitem[randomArray($#Hitem + 1)];
				foreach (@Hitem) {
					last if(($_ eq '') || ($HbfieldNumber + $i>= $remainNumber));
					my $num;
					my $flag = 0;
					while($HbfieldNumber + $i < $remainNumber) {
						$num = ($HitemGivePerTurn == 1) ? $HbfieldNumber + $i : $remainNumber - ($i + 1);
						if(($Hislands[$num]->{'keyItemNumber'} == @{$Hitems[0]} - 1) ||
							(($HnavyName[0] ne '') && !($Hislands[$num]->{'ships'}[4] + $Hislands[$num]->{'navyPort'}))) {
							$i++;
						} else {
							$flag = 1;
							last;
						}
					}
					if($flag) {
						push(@{$Hislands[$num]->{'item'}}, $_);
						my @str = ('</span><span>이옛대', '</span><span>이신비한', '</span><span>이환상마', '</span><span>이양불꽃');
						my @where = ('숲에서', '산에서', '바다에서', '대지에서');
						$Hislands[$num]->{'itemNumber'}++;
						logItemGetLucky($Hislands[$num]->{'id'}, islandName($Hislands[$num]), $str[random(4)], $HitemName[$_], $where[random(4)]);
					}
					$i++;
				}
			}
		}

		if($Htournament){
			# 토너먼트
			if($tournamentflg == 1){
				# 예선 탈락를 침몰하게 함
				while($remainNumber - $HbfieldNumber> $Htournament){
					$remainNumber--;
					$island = $Hislands[$remainNumber];
					my $name = islandName($island);
					unshift(@HfightLogPool, "0,$island->{'id'},$name,$island->{$HrankKind}");
					islandDeadNavy($island);
					my($tmpid) = $island->{'id'};
					if($HautoKeeper != 1){
						island_save($island, $HfightdirName, 'lose', 0) if($HdeadToSaveAsLose);
						$island->{'dead'} = 1;
						$island->{$HrankKind} = 0;
						logTDead($tmpid, islandName($island));
						$HidToNumber{$tmpid} = undef;
						deleteIslandData($island);
					} elsif(!$island->{'predelete'}) {
						push(@HpreDeleteID, $tmpid);
						$island->{'predelete'} = (!$HautoKeeperSetTurn) ? 99999999 : ($HautoKeeperSetTurn + 1);
						$predelNumber++;
						logTDead2PD($tmpid, islandName($island));
					}
					logLoseOut($island->{'id'}, islandName($island));
				}
			}
			if(($tournamentflg == 1) || ($tournamentflg == 3)){
				# 대전 상대결정 처리
				my($l,$r);
				$r = $remainNumber - 1;
				for($l = $HbfieldNumber; $l <= $r; $l++, $r--){
					if($Hislands[$r]->{'id'} == $Hislands[$l]->{'id'}){
						# 부전승
						$Hislands[$r]->{'fight_id'} = -1;
						$Hislands[$r]->{'rest'} += $HnofightTurn + $HislandFightCount * $HnofightUp;
					} else {
						$Hislands[$l]->{'fight_id'} = $Hislands[$r]->{'id'};
						$Hislands[$r]->{'fight_id'} = $Hislands[$l]->{'id'};
					}
				}
			}
		}

		# 최하위 탈락 시의 턴이면 처리(서바이벌 모드)
		if( $HsurvivalTurn && $HturnDead && !(($HislandTurn - $HsurvivalTurn) % $HturnDead) && ($HislandTurn> $HsurvivalTurn) ) {
			if($remainNumber> 1 + $HbfieldNumber){
				my $i = 1;
				$remainNumber--;
				$island = $Hislands[$remainNumber];
				islandDeadNavy($island);
				my($tmpid) = $island->{'id'};
				if($HautoKeeper != 1){
					island_save($island, $HfightdirName, 'lose', 0) if($HdeadToSaveAsLose);
					$island->{'dead'} = 1;
					$island->{$HrankKind} = 0;
					logTDead($tmpid, islandName($island));
					$HidToNumber{$tmpid} = undef;
					deleteIslandData($island);
				} elsif(!$island->{'predelete'}) {
					push(@HpreDeleteID, $tmpid);
					$island->{'predelete'} = (!$HautoKeeperSetTurn) ? 99999999 : ($HautoKeeperSetTurn + 1);
					$predelNumber++;
					logTDead2PD($tmpid, islandName($island));
				}
			}
		}

		# 섬 수자르기
		if($remainNumber + $predelNumber < $HislandNumber) {
			islandSort($HrankKind, 1);
			$HislandNumber = $remainNumber + $predelNumber;
			foreach $i ($HislandNumber..$islandNumber) {
				$HidToNumber{$Hislands[$i]->{'id'}} = undef;
				$Hislands[$i] = undef;
			}
			splice(@Hislands, $HislandNumber);
			$islandNumber = $HislandNumber - 1;
		}

		if($HallyNumber) { # 동맹 관련 처리
			# 진영자르기(소멸규칙)
			$HallyNumber = $remainCampNumber if($HarmisticeTurn && ($HautoKeeper != 1));
			for($i = 0; $i < $HallyNumber; $i++) {
				$Hally[$i]->{'score'} = 0;
				# 유지비(무인 섬이 되었을 시의 머릿수 할당에서 처리)
				my($keepCost);
				$keepCost = int($HcostKeepAlly / $Hally[$i]->{'number'}) if($Hally[$i]->{'number'});
				$Hally[$i]->{'number'} = 0;
				my $allyMember = $Hally[$i]->{'memberId'};
				foreach (@$allyMember) {
					my $no = $HidToNumber{$_};
					if(defined $no) {
						$Hally[$i]->{'score'} += $Hislands[$no]->{$HrankKind} if(!$Hislands[$no]->{'predelete'});
						$Hally[$i]->{'number'}++;
						# 유지비징 수
						if(!$HarmisticeTurn) {
							$Hislands[$no]->{'upkeepAlly'} += $keepCost;
							$Hislands[$no]->{'money'} -= $keepCost;
							$Hislands[$no]->{'money'} = 0 if($Hislands[$no]->{'money'} < 0);
						}
						# 공헌도(인구라면1만 명에 관련1포인트)
						$Hislands[$no]->{'ext'}[1] += int($island->{$HrankKind}/10);
					}
				}
				$Hally[$i]->{'Takayan'} = makeRandomString();
			}
			allyOccupy();
			allySort();
		}

		if($HbalanceLog) { # 수입·지출 로그(기밀)
			foreach $i ($HbfieldNumber..$islandNumber) {
				$island = $Hislands[$i];
				next if($island->{'predelete'});
				my $id = $island->{'id'};
				if($HcorelessDead && !$island->{'field'} && !$island->{'core'}) {
					my $dturn = $HdevelopTurn - ($HislandTurn - $island->{'birthday'}) + 1;
					my($alertstr);
					if($dturn <= 1) {
						$alertstr = '다음 턴에';
					} else {
						$alertstr = $dturn. '턴이내에';
					}
					logSecret(" --- <span class='attention'>경고!</span> 코어 없습니다!${HtagDisaster_}$alertstr${H_tagDisaster}건설 하지 않으면${HtagDisaster_}침몰${H_tagDisaster}합니다.",$id) if($dturn <= 10);
				}
				my($money) = $island->{'money'} - $island->{'oldMoney'};
				if($island->{'money'} && ($money < 0)) {
					my $turn = $island->{'money'} / (- $money);
					my $str;
					if($turn <= 1) {
						$str = "다음 턴에는";
					} else {
						$turn = int($turn);
						$str = "${turn}턴 후에";
					}
					logSecret(" --- <span class='attention'>경고!</span> $str 개발 자금이 부족해질 것으로 예상됩니다.",$id) if($turn <= 50);
				}
				$money = ($money>= 0) ? "${HtagMoney_}$money" : "<span class='attention'>$money";
				my($food) = $island->{'food'} - $island->{'oldFood'};
				if($island->{'food'} && ($food < 0)) {
					my $turn = $island->{'food'} / (- $food);
					my $str;
					if($turn <= 1) {
						$str = "다음 턴에는";
					} else {
						$turn = int($turn);
						$str = "${turn}턴 후에";
					}
					logSecret(" --- <span class='attention'>경고!</span> $str 비축 식량이 부족해질 것으로 예상됩니다.",$id) if($turn <= 50);
				}
				$food = ($food>= 0) ? "${HtagFood_}$food" : "<span class='attention'>$food";
				$food.= ($island->{'randomfood'}) ? "$HunitFood${H_tagFood} 무작위 수확:${HtagFood_}$island->{'randomfood'}" : '';
				my $uMoney = - $island->{'upkeepMoney'};
				$uMoney.= ($island->{'upkeepMoneyPlus'}) ? "$HunitMoney${H_tagMoney} 수입:${HtagMoney_}$island->{'upkeepMoneyPlus'}" : '';
				$uMoney.= ($island->{'upkeepMoneyProbe'}) ? "$HunitMoney${H_tagMoney} 조사비:${HtagMoney_}-$island->{'upkeepMoneyProbe'}" : '';
				my $uFood = - $island->{'upkeepFood'};
				$uFood.= ($island->{'upkeepFoodPlus'}) ? "$HunitFood${H_tagFood} 수확:${HtagFood_}$island->{'upkeepFoodPlus'}" : '';
				my $sMoney = - $island->{'shellMoney'};
				my $inMoney = $island->{'inMoney'};
				$inMoney.= ($island->{'prizemoney'}) ? "$HunitMoney${H_tagMoney} 획득 상금:${HtagMoney_}". $island->{'prizemoney'} : '';
				$inMoney.= ($island->{'randommoney'}) ? "$HunitMoney${H_tagMoney} 무작위 수입:${HtagMoney_}". $island->{'randommoney'} : '';
				$inMoney.= ($island->{'upkeepAlly'}) ? "$HunitMoney${H_tagMoney} 동맹유지비:${HtagMoney_}". - $island->{'upkeepAlly'} : '';
				$inMoney.= ($island->{'upkeepAmity'}) ? "$HunitMoney${H_tagMoney} 우호국유지비:${HtagMoney_}". - $island->{'upkeepAmity'} : '';
				my $pFood = - $island->{'payFood'};
				my $name = islandName($island);

				$logS[0] = " --- 종합 정산자금:$money$HunitMoney${H_tagMoney} 식량:$food$HunitFood${H_tagFood}";
				$logS[1] = " --- 함대 유지비:${HtagMoney_}$uMoney$HunitMoney${H_tagMoney} 유지 식량:${HtagFood_}$uFood$HunitFood${H_tagFood} 탄약비:${HtagMoney_}$sMoney$HunitMoney${H_tagMoney}";
				$logS[2] = " --- 기본 정산자금:${HtagMoney_}$inMoney$HunitMoney${H_tagMoney} 식량 생산량:${HtagFood_}$island->{'inFood'}$HunitFood${H_tagFood} 소비량:${HtagFood_}$pFood$HunitFood${H_tagFood}";
				$logS[3] = "${HtagName_}${name}${H_tagName}<B>《수입·지출 보고》</B>";
				foreach (0..3) {
					1 while $logS[$_] =~ s/(.*\d)(\d\d\d)/$1,$2/;
					logSecret("$logS[$_]",$id);
				}
			}
		}

		# 함정 산출 처리
		foreach $i (0..$islandNumber) {
			estimateNavy($i);
			$Hislands[$i]->{'rest'}-- if($Hislands[$i]->{'rest'}> 0);
			my $preflag = $Hislands[$i]->{'predelete'};
			$Hislands[$i]->{'predelete'}-- if(($Hislands[$i]->{'predelete'}> 0) && ($Hislands[$i]->{'predelete'} != 99999999));
			if($preflag && !$Hislands[$i]->{'predelete'}) {
				my($island) = $Hislands[$i];
				if(!$island->{'pop'}) {
					my($land) = $island->{'land'};
					my($landValue) = $island->{'landValue'};
					makeRandomIslandPointArray($island);
					foreach (0..$island->{'pnum'}) {
						last if($count>= $HcountLandTown);
						$x = $island->{'rpx'}[$_];
						$y = $island->{'rpy'}[$_];
						# 해당 지점이 평지 또는 황무지라면 마을
						if(($land->[$x][$y] == $HlandPlains) || ($land->[$x][$y] == $HlandWaste)) {
							$land->[$x][$y] = $HlandTown;
							$landValue->[$x][$y] = $HvalueLandTown;
							$island->{'pop'} += $HvalueLandTown;
							$count++;
						}
					}
				}
				if($HcorelessDead) {
					randomBuildCore($island, 1, 0, 0, 0) if(!$island->{'core'});
				}
			}
			if($Hislands[$i]->{'itemNumber'} && ($HnavyName[0] ne '') && !($Hislands[$i]->{'ships'}[4] + $Hislands[$i]->{'navyPort'})) {
				foreach(shift @{$Hislands[$i]->{'item'}}) {
					$HitemGetId[$_]{$Hislands[$i]->{'id'}} = undef;
				}
				$Hislands[$i]->{'item'} = undef;
				$Hislands[$i]->{'itemNumber'} = 0;
				$Hislands[$i]->{'gain'} = 0;# 추가로 경험치도재설정하거나하고(^^;
				logItemLost($Hislands[$i]->{'id'}, islandName($Hislands[$i]), "보유하고 있었음모두의$HitemName[0]", "해군소멸와 같이에");
			}
		}
		# 승자판정(서바이벌 모드·토너먼트 모드)
		if(
			( $HsurvivalTurn && ($remainNumber == $HbfieldNumber + 1) && ($HislandTurn> $HsurvivalTurn) ) ||
			( $Htournament && ($remainNumber == $HbfieldNumber + 1) && ($HislandTurn> $HyosenTurn) )
		) {
			my $name = islandName($Hislands[$HbfieldNumber]);
			logHistory("${HtagName_}${name}${H_tagName}이<B>승리</B>했습니다!");
			$Hislands[$HbfieldNumber]->{'ext'}[0] |= (2 ** $#HwinnerMark);
			$repeatTurn = 0;
			$HplayNow = 0;
		}

		# 종료조건의 판정
		my $n = gameOver();
		if ($n != -1) {
			my($v) = 2 ** $#HwinnerMark;
			if($HarmisticeTurn) {
				logHistory("${HtagName_}${Hally[$n]->{'name'}}${H_tagName}이<B>승리</B>했습니다!");
				$Hally[$n]->{'ext'}[5] |= $v;
				my $allyMember = $Hally[$n]->{'memberId'};
				foreach (@$allyMember) {
					my $no = $HidToNumber{$_};
					if(defined $no) {
						$Hislands[$no]->{'ext'}[0] |= $v;
					}
				}
			} else {
				my $name = islandName($Hislands[$HbfieldNumber]);
				logHistory("${HtagName_}${name}${H_tagName}이<B>중단</B>로 종료했습니다!");
				$Hislands[$HbfieldNumber]->{'ext'}[0] |= $v;
			}
			$repeatTurn = 0;
			$HplayNow = 0;
		}

		# 역대기록 처리
		if($HuseRekidai) {
			require './hako-reki.cgi';
			mainReki();
		}
		# 포인트 처리
#		if($HrankKind eq 'point') {
#			foreach $i (0..$islandNumber) {
#				calcPoint($i);
#			}
#			# 순위를 갱신
#			islandSort($HrankKind, 1);
#		}
		# 토너먼트 로그
		fightlog() if($Htournament && ($tournamentflg == 3 || $tournamentflg == 1));

		# 백업 턴이면 삭제 전에 rename
		if($HbackupTurn && !($HislandTurn % $HbackupTurn)) {
			my($i);
			my($tmp) = $HbackupTimes - 1;
			myrmtree("${HdirName}.bak$tmp");
			for($i = $tmp; $i> 0; $i--) {
				my($j) = $i - 1;
				rename("${HdirName}.bak$j", "${HdirName}.bak$i");
			}
			rename("${HdirName}", "${HdirName}.bak0");
			mkdir("${HdirName}", $HdirMode);

			# 로그 파일만 복구
			foreach $i (0..$HlogMax) {
				copy("${HdirName}.bak0/$i$HlogData", "${HdirName}/$i$HlogData") if (-e "${HdirName}.bak0/$i$HlogData");
			}
			copy("${HdirName}.bak0/hakojima.his", "${HdirName}/hakojima.his") if (-e "${HdirName}.bak0/hakojima.his");
		}

		# 파일에쓰기
		writeIslandsFile(-1);

		# 로그 파일을 뒤에밀기
		for($i = ($HlogMax - 1); $i>= 0; $i--) {
			$j = $i + 1;
			my($s) = "${HdirName}/$i$HlogData";
			my($d) = "${HdirName}/$j$HlogData";
			unlink($d);
			rename($s, $d);
		}

		# 부하계산(추가 친분20020307 by 라스티아)
		if($Hperformance) {
			my($uti, $sti, $cuti, $csti) = times();
			$uti += $cuti;
			$sti += $csti;
			my($cpu) = $uti + $sti;

			# 로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
			#open(POUT,">>cpu-t.log");
			#print POUT "CPU($cpu) : user($uti) system($sti)\n";
			#close(POUT);

			logLate("<SMALL>부하계측 CPU($cpu) : user($uti) system($sti)</SMALL>",0);
		}

		# 로그 쓰기
		logFlush();

		# 아직 턴진행하다?
		if ($repeatTurn) {
			# 종료 턴이면 루프를 빼기하기
			last if ($HgameLimitTurn && ($HislandTurn>= $HgameLimitTurn));

			# 필요한변수를 초기화하다
			undef %HidToNumber;
			undef %HidToName;
			undef %HidToAllyNumber;
			undef @HmonsterMove;
			undef @HnavyMove;
			undef @HlandMove;
			undef %HnavyAttackTarget;

			my($island, $id, $ally);
			foreach $i (0..$islandNumber) {
				$island = $Hislands[$i];
				$island->{'dead'} = 0;
				$island->{'delete'} = 0;
				$id = $island->{'id'};
				$HidToNumber{$id} = $i;
				$HidToName{$id} = $island->{'name'};
			}
			for ($i = 0; $i < $HallyNumber; $i++) {
				$ally = $Hally[$i];
				$id = $ally->{'id'};
				$HidToAllyNumber{$id} = $i;
			}
		}
	}

	if($HhtmlLogMake && $HrepeatTurn && (-e "${HhtmlDir}/hakolog.html")) {
		unlink("${HhtmlDir}/hakolog.html");
	}

	tempInitialize(0);
	# 맨 위로
	topPageMain();
}

# 종료여부
sub gameOver {
	# 시간절레
	if($HgameLimitTurn) {
		if ($HislandTurn>= $HgameLimitTurn) {
			# 중단된 진영을 되돌림
			return 0;
		}
	}
	# 콜드
	if($HarmisticeTurn) {
		my($i);
		for ($i = 0; $i < $HallyNumber; $i++) {
			if ($Hally[$i]->{'occupation'}>= $HfinishOccupation) {
				return $i;
			}
		}
	}
	return -1;
}

# 파일을 원형마다복사
#sub copy {
#	my($src, $dest) = @_;
#
#	open(FS, "<$src") || die $!;
#	open(FD, ">$dest") || die $!;
#	binmode(FS); # Windows 로컬에서는 필요
#	binmode(FD); # Windows 로컬에서는 필요
#
#	my $buf;
#	while (read(FS, $buf, 1024 * 8)> 0) {
#		print FD $buf;
#	}
#
#	close(FD);
#	close(FS);
#}
sub copy {
	my($src, $dest) = @_;

	open(FS, "<$src") || die $!;
	my @buf = <FS>;
	close(FS);
	open(FD, ">$dest") || die $!;
	print FD @buf;
	close(FD);
}

# 디렉터리 삭제
sub myrmtree {
	my($dn) = @_;
	opendir(DIN, "$dn/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		unlink("$dn/$fileName");
	}
	closedir(DIN);
	rmdir($dn);
}

# 참가 섬에 대한 제재 내용을 읽기
sub readPunishData {
	if (open(Fpunish, "<${HdirName}/punish.cgi")) {
		local(@_);
		my($island);
		while (<Fpunish>) {
			chomp;
			@_ = split(',');
			my($obj);
			$obj->{id} = shift;
			$obj->{punish} = shift;
			$obj->{x} = shift;
			$obj->{y} = shift;

			$HpunishInfo{$obj->{id}} = $obj;
		}
		close(Fpunish);
	}

	# 제재 데이터를 삭제
	unlink("${HdirName}/punish.cgi");
}


# 관리자 보관사멸 처리
sub preDelIdCut {
	my($id) = @_;
	my @newID = ();
	foreach (@HpreDeleteID) {
		if(!(defined $HidToNumber{$_})) {
		} elsif($_ != $id) {
			push(@newID, $_);
		}
	}
	@HpreDeleteID = @newID;
}

# 수입, 소비단계
sub income {
	my($island) = @_;
	my($pop, $farm, $factory, $mountain) =
	(
		$island->{'pop'},
		$island->{'farm'} * 10,
		$island->{'factory'},
		$island->{'mountain'}
	);

	my $fflag = $island->{'itemAbility'}[9];
	$fflag /= 2 if($HuseWeather && $island->{'weather'}[0] < 0);
	my $mflag = $island->{'itemAbility'}[10];
	# 수입
	if($pop> $farm) {
		# 농업만으로 인력이 남는 경우
		$island->{'inFood'} = int($farm * $HincomeRate * $fflag); # 농장 전체가동
		$island->{'inMoney'} =
		min(
			int(($pop - $farm) * $HincomeRate * $mflag / 10),
			int(($factory + $mountain) * $HincomeRate * $mflag)
		);
	} else {
		# 농장 규모가 최대치인 경우
		$island->{'inFood'} = int($pop * $HincomeRate * $fflag); # 전체나 생 직원일
	}
	$island->{'down'} = 1 if($pop - ($farm + $factory * 10 + $mountain * 10)>= $Hno_work);

	# 식량소비
	my $eflag = $island->{'itemAbility'}[15];
	$island->{'payFood'} = int($pop * $HeatenFood * $eflag);

	$island->{'money'} += $island->{'inMoney'};
	$island->{'food'} += ($island->{'inFood'} - $island->{'payFood'});
	$island->{'food'} = 0 if($island->{'field'} && ($island->{'food'} < 0));
	if($HallyNumber) {
		my $gnp = int($island->{'inMoney'} + ($island->{'inFood'} - $island->{'payFood'})/10);
		foreach (@{$island->{'allyId'}}) {
			${Hally[$HidToAllyNumber{$_}]->{'ext'}[2]} += $gnp;
		}
	}
}

# 로그를 정리하기
sub logMatome {
	my($island) = @_;

	my($sno, $i, $sArray, $spnt, $x, $y, $point);
	my %mkind = (
		'prepare' => "$HcomName[$HcomPrepare]",
		'selltree' => "$HcomName[$HcomSellTree]",
		'reclaim' => "$HcomName[$HcomReclaim]",
		'destroy' => "$HcomName[$HcomDestroy]",
	);
	foreach (keys %mkind) {
		$sno = @{$island->{$_}};
		$point = "";
		if($sno> 0) {
			if($HoutPoint) {
				$sArray = $island->{$_};
				for($i = 0; $i < $sno; $i++) {
					$point.= "($sArray->[$i]->{x}, $sArray->[$i]->{y})";
				}
			}
			$point.= "의<B>$sno 케장소</B>" if($i> 1 || !$HoutPoint);
		}
		unless($point eq "") {
			if($HoutPoint && ($sno> 1)) {
				logLandSucMatome($island->{'id'}, islandName($island), $mkind{$_}, "$point");
			} else {
				logLandSuc($island->{'id'}, islandName($island), $mkind{$_}, "$point");
			}
		}
		$island->{$_} = undef;
	}
}

# 명령 단계
sub doCommand {
	my($island) = @_;

	# 명령 처리 시작
	my($comArray, $command, $c);
	$comArray = $island->{'command'};
	$command = $comArray->[0]; # 첫 항목을 꺼냄
	slideFront($comArray, 0); # 이후를 막힘하기

	# 각 요소 꺼내기
	my($kind, $target, $x, $y, $arg, $target2) =
	(
		$command->{'kind'},
		$command->{'target'},
		$command->{'x'},
		$command->{'y'},
		$command->{'arg'},
		$command->{'target2'}
	);

	# 도출 값
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];
	my($comName) = $HcomName[$kind];
	my($point) = "($x, $y)";
	my($landName) = landName($landKind, $lv);

	my $cflag = $island->{'itemAbility'}[16];
	my($cost) = $HcomCost[$kind];
	$cost = int($HcomCost[$kind] * $cflag) if($cost> 0);

	if(($kind == $HcomDoNothing) ||
	 (($kind == $HcomGiveup) && $island->{'event'}[0])) {
		if(!$island->{'field'}) {
			#자금 조달
			$island->{'money'} += $HdoNothingMoney;
			$island->{'inMoney'} += $HdoNothingMoney;
			if(!$HflagDoNothing) {
				$island->{'absent'} ++;

				# 진영 위임 임시판정
				if ($HarmisticeTurn && ($island->{'absent'}> $HpreGiveupTurn)) {
					# passward 을 진영 비밀번호에 변경(매 턴)
#					$island->{'password'} = encode($ally->{'Takayan'});
					$island->{'preab'} = 1;
					$island->{'comment'} = "이 ${AfterName}은 진영 위임 임시 상태가 되었습니다.";
				}
			}

			# 자동포기
			if($island->{'absent'}>= (($HislandTurn - $island->{'birthday'} <= $HdevelopTurn) ? $HdevelopGiveupTurn : $HgiveupTurn)) {
				$comArray->[0] = {
					'kind' => $HcomGiveup,
					'target' => 0,
					'x' => 0,
					'y' => 0,
					'arg' => 0,
					'target2' => 0
				};
			}
		}
		return 1;
	}

	$island->{'absent'} = 0;

	# 비용 확인
	my($returnflag) = 0;
	if(($cost> 0) && ($island->{'money'} < $cost)) {
		# 금의 경우
		logNoMoney($id, $name, $comName);
		$returnflag = 1;
	} elsif(($cost < 0) && ($island->{'food'} < (-$cost))) {
		# 식량의 경우
		logNoFood($id, $name, $comName);
		$returnflag = 1;
	}
	if(($kind == $HcomAutoPrepare3 || $kind == $HcomFastFarm || $kind == $HcomFastFactory) && ($HislandFightMode == 2)){
		logLandNG($id, $name, $comName, '현재전투 기간 중이어서 ');
		$returnflag = 1;
	}
	if($HoceanMode) {
		if($HlandID[$x][$y] != $id) {
			# 대상 지형의 ID 이자기 섬에서 없는 경우
			if(($kind < 90) || ((100 < $kind) && ($kind < 200)) || ((330 < $kind) && ($kind < 350)) || ($kind == $HcomNavyWreckRepair) || ($kind == $HcomNavyWreckSell)) {
				# 내정(개발), 내정(건설), 복합시설, 해군(건조) <200, 330< 군사(건설) <350, 잔해 수리, 잔해 매각은 할 수 없
				logNotAvail($id, $name, $comName);
				$returnflag = 1;
			}
		}
		if(((215 < $kind) && ($kind < 220)) || ((350 < $kind) && ($kind < 361))) {
			# 이동 조종, 이동 지령, 함정 지령 변경, 일제 공격과 군사(공격)
			# 내정, 건조 이외에서  좌표 지정 명령은, 안전 확인용 $target 을 수정
			$target = $HlandID[$x][$y];
		}
	}
	if($returnflag) {
		if($island->{'comflag'}) {
			# 횟수 지정이면, 명령을 되돌림
			if($arg> 1) {
				$arg--;
				slideBack($comArray, 0);
				$comArray->[0] = {
					'kind' => $kind,
					'target' => $target,
					'x' => $x,
					'y' => $y,
					'arg' => $arg,
					'target2' => $target2
				};
			}
		}
		return 0;
	}

	# 명령에서 분기
	if(($kind == $HcomPrepare) || ($kind == $HcomPrepare2)) {
		# 개간, 땅고르기
		if(($landKind == $HlandSea) ||
			($landKind == $HlandSbase) ||
			($landKind == $HlandOil) ||
			($landKind == $HlandBouha) ||
			($landKind == $HlandSeaMine) ||
			($landKind == $HlandMountain) ||
			($landKind == $HlandMonster) ||
			($landKind == $HlandHugeMonster) ||
			(($landKind == $HlandCore) && int($lv / 10000)) ||
			(($landKind == $HlandComplex) && ($HcomplexAfter[my $cKind = (landUnpack($lv))[1]]->{'prepare'}[0] eq '')) ||
			($landKind == $HlandNavy)) {
			# 바다, 해저 기지, 유전, 방파제, 기뢰, 산, 괴수, 거대괴수, 코어(바다), 복합 지형(설정 없음), 해군은 개간할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 대상 위치를 평지로
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		if($landKind == $HlandComplex) {
			# 복합 지형이면 설정 지형
#			my $cKind = (landUnpack($lv))[1];
			$land->[$x][$y] = $HcomplexAfter[$cKind]->{'prepare'}[0];
			$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'prepare'}[1];
			$island->{'complex'}[$cKind]--;
		} elsif($landKind == $HlandDefence) {
			$island->{'dbase'}--;
		} elsif($landKind == $HlandCore) {
			$island->{'core'}--;
		}
		my $sno = @{$island->{'prepare'}};
		$island->{'prepare'}->[$sno]->{x} = $x;
		$island->{'prepare'}->[$sno]->{y} = $y;

		# 돈을 차감
		$island->{'money'} -= $cost;

		if($kind == $HcomPrepare2) {
			# 땅고르기
			$island->{'prepare2'}++;
		} else {
			# 땅고르기이면 매장금 발견 가능성 있음
			if(!$HnoDisFlag && random(1000) < $HdisMaizo) {
				my($v) = 100 + random(901);
				$island->{'money'} += $v;
				logMaizo($id, $name, $comName, $v);
			}
		}
		return $HcomTurn[$kind];

	} elsif($kind == $HcomPrepare3) {
		# 일괄 땅고르기
		my($i, $sx, $sy);
		my($prepareM, $prepareFlag) = ($HcomCost[$HcomPrepare2], 0);
		foreach $i (0..$island->{'pnum'}) {
			$sx = $island->{'rpx'}[$i];
			$sy = $island->{'rpy'}[$i];
			last if($island->{'money'} < $HcomCost[$HcomPrepare2]);
			if($land->[$sx][$sy] == $HlandWaste) {
				# 대상 위치를 평지로
				$land->[$sx][$sy] = $HlandPlains;
				$landValue->[$sx][$sy] = 0;
				if(($prepareM> 0) && ($island->{'money'} < $prepareM)) {
					logNoMoney($id, $name, $comName);
					return 0;
				}
				# 돈을 차감
				$island->{'money'} -= $prepareM;
				my $sno = @{$island->{'prepare'}};
				$island->{'prepare'}->[$sno]->{x} = $sx;
				$island->{'prepare'}->[$sno]->{y} = $sy;
				# 땅고르기
#				$island->{'prepare2'}++;
				$prepareFlag++;
				if($prepareFlag == $precheap){ $prepareM = int($prepareM * $precheap2 / 10); }
			}
		}
#		logAllPrepare($id, $name, $comName);
		return $HcomTurn[$kind];

	} elsif(($kind == $HcomReclaim) || ($kind == $HcomReclaim2)) {
		# 매립, 고속매립
		if(($landKind != $HlandSea) &&
			($landKind != $HlandOil) &&
			($landKind != $HlandBouha) &&
			($landKind != $HlandSeaMine) &&
			($landKind != $HlandSbase) &&
			!(($landKind == $HlandCore) && int($lv / 10000)) &&
			!(($landKind == $HlandComplex) && ($HcomplexAfter[my $cKind = (landUnpack($lv))[1]]->{'reclaim'}[0] ne '')) &&
			($landKind != $HlandNavy)) {
			# 바다, 해저 기지, 유전, 방파제, 기뢰, 코어(바다), 복합 지형(설정있음), 해군만매립할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 주변에육이 있는 지 확인
		my($seaCount) =
			countAround($island, $x, $y, $an[1], $HlandSea, $HlandOil, $HlandSeaMine, $HlandSbase);
		$seaCount += countAroundNavy($island, $x, $y, $an[1]) if($HnavyReclaim);
		$seaCount += countAroundMonster($island, $x, $y, $an[1]) if($HmonsterReclaim);

		if($seaCount == 7) {
			# 전체 바다다에서 매립불능
			logNoLandAround($id, $name, $comName, $point);
			return 0;
		}

		if($HedgeReclaim) { # 섬의 가장 바깥쪽을 매립 불가로 설정한 경우
			my($map) = $island->{'map'};
			my(@x) = @{$map->{'x'}};
			my(@y) = @{$map->{'y'}};
			if(($x < $x[0] + $HedgeReclaim) || ($x> $x[$#x] - $HedgeReclaim) || ($y < $y[0] + $HedgeReclaim) || ($y> $y[$#y] - $HedgeReclaim)) {
				logLandFail($id, $name, $comName, "섬의 가장 바깥쪽", $point);
				return 0;
			}
		}

		if ($landKind == $HlandNavy) {
			# 해군의 경우, 군항만
			my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
			my $nSpecial = $HnavySpecial[$nKind];
			unless ($nSpecial & 0x8) {
				# 항구 이외는 매립할 수 없
				logLandFail($id, $name, $comName, $landName, $point);
				return 0;
			}
			$island->{'navyPort'}--;
			$island->{'shipk'}[$nKind]--;
		} elsif($landKind == $HlandCore) {
			$island->{'core'}--;
		}

		if($landKind == $HlandComplex) {
			# 복합 지형이면 설정 지형
#			my $cKind = (landUnpack($lv))[1];
			$land->[$x][$y] = $HcomplexAfter[$cKind]->{'reclaim'}[0];
			$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'reclaim'}[1];
			$island->{'complex'}[$cKind]--;
			#$island->{'area'}++; 이 처리는 보류리
		} elsif((($landKind == $HlandSea) && ($lv == 1)) || (($landKind == $HlandCore) && (int($lv / 10000) == 1))) {
			# 얕은 바다의 경우
			# 대상 위치를 황무지로
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			$island->{'area'}++;

			if($seaCount <= 4) {
				# 주변 바다가 3헥스 이내이므로, 얕은 바다로
				my($i, $sx, $sy);
				foreach $i (1..6) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					# 행 기준 위치 조정
					$sx-- if(!($sy % 2) && ($y % 2));
					$sx = $correctX[$sx + $#an];
					$sy = $correctY[$sy + $#an];

					if (($sx < 0) || ($sy < 0)) {
						# 범위 밖이면 아무것도 하지 않음
					} else {
						# 범위 안의 경우
						$landValue->[$sx][$sy] = 1 if ($land->[$sx][$sy] == $HlandSea);
					}
				}
			}
		} else {
			# 바다이면 대상 위치를 얕은 바다로 변경
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			$island->{'bouha'}-- if($landKind == $HlandBouha); # 방파제의 시
		}
#		logLandSuc($id, $name, $comName, $point);
		my $sno = @{$island->{'reclaim'}};
		$island->{'reclaim'}->[$sno]->{x} = $x;
		$island->{'reclaim'}->[$sno]->{y} = $y;
		# 돈을 차감
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif(($kind == $HcomDestroy) || ($kind == $HcomDestroy2)) {
		# 굴착, 고속굴착
		if(($landKind == $HlandSbase) ||
			($landKind == $HlandOil) ||
			($landKind == $HlandSeaMine) ||
			($landKind == $HlandBouha) ||
			($landKind == $HlandMonster) ||
			($landKind == $HlandHugeMonster) ||
			(($landKind == $HlandCore) && (int($lv / 10000) != 2)) ||
			(($landKind == $HlandComplex) && ($HcomplexAfter[my $cKind = (landUnpack($lv))[1]]->{'destroy'}[0] eq '')) ||
			($landKind == $HlandNavy)) {
			# 해저 기지, 유전, 기뢰, 방파제, 괴수, 거대괴수, 코어(바다), 복합 지형(설정 없음), 해군은 굴착할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		if(($landKind == $HlandSea) && (!$lv)) {
			# 바다이면 유전 탐사 시
			if ($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn)) {
				# 개발 기간 안은 유전금지
				logNotAvail($id, $name, $comName);
				return 0;
			}
			# 투자액결정
			$arg = 1 if(!$arg);
			my($value, $str, $p);
			$value = min($arg * ($cost), $island->{'money'});
			$str = "$value$HunitMoney";
			$p = int($value / $cost) if($cost);
			$island->{'money'} -= $value;

			# 시야 사용는 가판정
			if($p> random(100) + $island->{'oil'} * 25) {
				# 유전시야 사용루
				logOilFound($id, $name, $point, $comName, $str);
				$land->[$x][$y] = $HlandOil;
				$landValue->[$x][$y] = 0;
				$island->{'oil'}++;
			} else {
				# 헛발사치에끝나쁨
				logOilFail($id, $name, $point, $comName, $str);
			}
			return $HcomTurn[$kind];
		}

		# 대상 위치를 바다로 변경. 산이면 황무지로, 얕은 바다이면 바다로 변경.
		if($landKind == $HlandMountain) {
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
		} elsif($landKind == $HlandSea) {
			$landValue->[$x][$y] = 0;
		} elsif($landKind == $HlandCore) {
			$land->[$x][$y] = $HlandSea;
			if(int($lv / 10000) == 1) {
				$landValue->[$x][$y] = 0;
			} else {
				$landValue->[$x][$y] = 1;
			}
			$island->{'core'}--;
		} elsif($landKind == $HlandComplex) {
			# 복합 지형이면 설정 지형
#			my $cKind = (landUnpack($lv))[1];
			$land->[$x][$y] = $HcomplexAfter[$cKind]->{'destroy'}[0];
			$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'destroy'}[1];
			$island->{'complex'}[$cKind]--;
		} else {
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			$island->{'area'}--;
			$island->{'dbase'}-- if($landKind == $HlandDefence);
		}
#		logLandSuc($id, $name, $comName, $point);
		my $sno = @{$island->{'destroy'}};
		$island->{'destroy'}->[$sno]->{x} = $x;
		$island->{'destroy'}->[$sno]->{y} = $y;

		# 돈을 차감
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomSellTree) {
		# 벌채
		if($landKind != $HlandForest) {
			# 숲이외는 벌채할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 대상 위치를 평지로
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
#		logLandSuc($id, $name, $comName, $point);
		my $sno = @{$island->{'selltree'}};
		$island->{'selltree'}->[$sno]->{x} = $x;
		$island->{'selltree'}->[$sno]->{y} = $y;

		# 매각금을 얻기루
		$island->{'money'} += $HtreeValue * $lv;
		return $HcomTurn[$kind];

	} elsif(($kind == $HcomPlant) ||
		($kind == $HcomFarm) ||
		($kind == $HcomFastFarm) ||
		($kind == $HcomFactory) ||
		($kind == $HcomFastFactory) ||
		($kind == $HcomBase) ||
		($kind == $HcomMonument) ||
		($kind == $HcomHaribote) ||
		($kind == $HcomBouha) ||
		($kind == $HcomDbase)) {

		# 지상건설계
		if(!
			(($landKind == $HlandPlains) ||
			($landKind == $HlandTown) ||
			(($landKind == $HlandMonument) && ($kind == $HcomMonument)) ||
			(($landKind == $HlandFarm) && ($kind == $HcomFarm || $kind == $HcomFastFarm)) ||
			(($landKind == $HlandFactory) && ($kind == $HcomFactory || $kind == $HcomFastFactory)) ||
			(($landKind == $HlandSea) && ($lv == 1) && ($kind == $HcomBouha)) ||
			(($landKind == $HlandBouha) && ($kind == $HcomBouha)) ||
			(($landKind == $HlandDefence) && ($kind == $HcomDbase)))) {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			if($island->{'comflag'}) {
				# 횟수 지정이면, 명령을 되돌림
				if(($kind == $HcomFarm) ||
					($kind == $HcomFactory) ||
					(($kind == $HcomDbase) && $HdurableDef)) {
					if($arg> 1) {
						$arg--;
						slideBack($comArray, 0);
						$comArray->[0] = {
							'kind' => $kind,
							'target' => $target,
							'x' => $x,
							'y' => $y,
							'arg' => $arg,
							'target2' => $target2
						};
					}
				}
			}
			return 0;
		}

		# 종류에서 분기
		if($kind == $HcomPlant) {
			# 대상 위치를 숲로.
			$land->[$x][$y] = $HlandForest;
			$landValue->[$x][$y] = 1; # 목은 최소단위
			logPBSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomBase) {
			return if(!$HuseBase);
			# 대상 위치를 미사일 기지로.
			$land->[$x][$y] = $HlandBase;
			$landValue->[$x][$y] = 0; # 경험치0
			logPBSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomHaribote) {
			# 대상 위치를 가짜 시설로
			$land->[$x][$y] = $HlandHaribote;
			$landValue->[$x][$y] = 0;
		 if ($HdBaseHide) { # 방위 시설을 숲에위장하다?
				logPBSuc($id, $name, $comName, $point);
		 } else {
				logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);
			}
		} elsif($kind == $HcomBouha) {
			return if(!$HuseBouha);
			# 대상 위치를 방파제로.
			if($HedgeReclaim) { # 섬의 가장 바깥쪽을 매립 불가로 설정한 경우
				my($map) = $island->{'map'};
				my(@x) = @{$map->{'x'}};
				my(@y) = @{$map->{'y'}};
				if(($x < $x[0] + $HedgeReclaim) || ($x> $x[$#x] - $HedgeReclaim) || ($y < $y[0] + $HedgeReclaim) || ($y> $y[$#y] - $HedgeReclaim)) {
					logLandFail($id, $name, $comName, "섬의 가장 바깥쪽", $point);
					return 0;
				}
			}
			if($island->{'bouha'}>= $HuseBouha) {
				# 보유 가능 최대 수 초과
				logOverFail($id, $name, $comName, $point);
				return 0;
			}
			$land->[$x][$y] = $HlandBouha;
			$landValue->[$x][$y] = 0;
			$island->{'bouha'}++;
			logLandSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomFarm || $kind == $HcomFastFarm) {
			# 농장
			$arg = 1 if(!$arg);
			my $rep = (!$HcomTurn[$kind]) ? $arg : 1;
			if($rep> 1) {
				my $value = min($rep * $cost, $island->{'money'});
				$rep = int($value / $cost) if($cost);
				$comName.= "($rep 회)";
				$cost *= $rep;
				$arg = 1;
			}
			if($landKind == $HlandFarm) {
				# 이미 농장의 경우
				$landValue->[$x][$y] += 2*$rep; # 규모 + 2000인
			} else {
				# 대상 위치를 농장에
				$land->[$x][$y] = $HlandFarm;
				$landValue->[$x][$y] = 10 + 2*($rep - 1); # 규모 = 10000인
			}
			if($landValue->[$x][$y]> 50) {
				$landValue->[$x][$y] = 50; # 최대 50000인
			}
			logLandSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomFactory || $kind == $HcomFastFactory) {
			# 공장
			$arg = 1 if(!$arg);
			my $rep = (!$HcomTurn[$kind]) ? $arg : 1;
			if($rep> 1) {
				my $value = min($rep * $cost, $island->{'money'});
				$rep = int($value / $cost) if($cost);
				$comName.= "($rep 회)";
				$cost *= $rep;
				$arg = 1;
			}
			if($landKind == $HlandFactory) {
				# 이미 공장의 경우
				$landValue->[$x][$y] += 10*$rep; # 규모 + 10000인
			} else {
				# 대상 위치를 공장에
				$land->[$x][$y] = $HlandFactory;
				$landValue->[$x][$y] = 30 + 10*($rep - 1); # 규모 = 10000인
			}
			if($landValue->[$x][$y]> 100) {
				$landValue->[$x][$y] = 100; # 최대 100000인
			}
			logLandSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomDbase) {
			# 방위 시설
			$arg = 1 if(!$arg);
			my $rep = (!$HcomTurn[$kind]) ? $arg : 1;
			# 한 번에 수량분의 내구력을 추가한 경우
			# 위 한 줄을 주석 처리하면 아래 코멘트를 표시하지 않음
			#my $rep = $arg;
			if($landKind == $HlandDefence) {
				# 이미 방위 시설인 경우
				if(!$HdurableDef) {
					$landValue->[$x][$y] += 10000; # 자폭장치 설정
					logBombSet($id, $name, $landName, $point);
					$island->{'money'} -= $cost;
					return $HcomTurn[$kind];
				} elsif($arg == $HdefExplosion) {
					$landValue->[$x][$y] += 10000; # 자폭장치 설정
					logBombSet($id, $name, $landName, $point);
					$island->{'money'} -= $cost;
					return $HcomTurn[$kind];
				} else {
					if($rep> 1) {
						my $value = min($rep * $cost, $island->{'money'});
						$rep = int($value / $cost) if($cost);
						$cost *= $rep;
						$arg = 1;
					}
					if($landValue->[$x][$y] == $HdurableDef - 1) {
						logBombDurableMax($id, $name, $landName, $point, $HdBaseHide);
					} else {
						$landValue->[$x][$y] += $rep;
						$landValue->[$x][$y] = $HdurableDef - 1 if($landValue->[$x][$y]> $HdurableDef - 1);
						logBombDurableUp($id, $name, $landName, $point, $rep, $HdBaseHide);
					}
				}
			} else {
				if($HdBaseMax && ($island->{'dbase'}>= $HdBaseMax)) {
					logOverFail($id, $name, $comName, $point);
					return 0;
				}
				if($rep> 1) {
					my $value = min($rep * $cost, $island->{'money'});
					$rep = int($value / $cost) if($cost);
					$rep = min($rep, $HdurableDef) if($HdurableDef);
					$comName.= "(내구력$rep)";
					$cost *= $rep;
					$arg = 1;
				}
				# 대상 위치를 방위 시설에
				$land->[$x][$y] = $HlandDefence;
				$rep = 1 if(!$HdurableDef);
				$landValue->[$x][$y] = $rep - 1;
				$island->{'dbase'}++;
				if ($HdBaseHide) { # 방위 시설을 숲에위장하다?
				 logPBSuc($id, $name, $comName, $point);
				} else {
				 logLandSuc($id, $name, $comName, $point);
				}
			}
		} elsif($kind == $HcomMonument) {
			# 기념비
			if($HuseBigMissile && ($landKind == $HlandMonument)) {
				# 이미 기념비인 경우

				# 대상 가져오기
				my($tn) = $HidToNumber{$target};
				my($tIsland) = $Hislands[$tn];
				my(%amityFlag);
				my($amity) = $island->{'amity'};
				foreach (@$amity) {
					$amityFlag{$_} = 1;
				}
				# 개발 기간이면 명령 무시
				if (
					($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn || $amityFlag{$target})) ||
					($HsurvivalTurn && ($HislandTurn <= $HsurvivalTurn))
					) {
					# 공격이 허가되어 있지 않음
					logNotAvail($id, $name, $comName);
					return 0;
				} elsif(($HislandTurn - $island->{'birthday'} <= $HdevelopTurn) ||
					($HislandTurn - $tIsland->{'birthday'} <= $HdevelopTurn)) {
					logDevelopTurnFail($id, $name, $comName);
					return 0;

				} elsif($Htournament) {
					if($HislandFightMode < 2) {
						logLandNG($id, $name, $comName, '현재 개발 기간 중이어서 ');
						return 0;
					} elsif($island->{'fight_id'} != $tIsland->{'id'}) {
						# 대전 상대가 아닌 경우
						logLandNG($id, $name, $comName, '목표가 대전 상대가 아니어서 ');
						return 0;
					}
				} elsif(($HuseDeWar> 1) && !$HarmisticeTurn && !$HsurvivalTurn) {
					my $warflag = chkWarIsland($id, $target);
					if(!$warflag) {
						logLandNG($id, $name, $comName, '선전포고를 하지 않아서 ');
						return 0;
					} elsif(($warflag == 1) && ($HuseDeWar == 3)) {
						logLandNG($id, $name, $comName, '유예 기간 중이어서 ');
						return 0;
					}
				} elsif($tIsland->{'event'}[0]) {
					if(($tIsland->{'event'}[1] - $HnoticeTurn < $HislandTurn) && ($HislandTurn < $tIsland->{'event'}[1])) {
						logLandNG($id, $name, $comName, '현재 이벤트 준비 기간 중이어서 ');
						return 0;
					} elsif(($tIsland->{'event'}[6] == 1) && ($HislandTurn> $tIsland->{'event'}[1])) {
						# 이벤트유형이서바이벌
						logLandNG($id, $name, $comName, '서바이벌 개최 중이 아니어서 ');
						return 0;
					}
				}

				if($tn eq '') {
					# 대상이 이미 없음
					# 아무 메시지도 출력하지 않음
					return 0;
				}

				$tIsland->{'bigmissile'}++;
				$island->{'ext'}[1] += $cost; #공헌도
				$tIsland->{'ext'}[1] += $cost; #공헌도

				# 그장소는 황무지에
				$land->[$x][$y] = $HlandWaste;
				$landValue->[$x][$y] = 0;
				logMonFly($id, $name, $landName, $point);
			} else {
				# 대상 위치를 기념비에
				$land->[$x][$y] = $HlandMonument;
				$arg = 0 if($arg>= $HmonumentNumber);
				$landValue->[$x][$y] = $arg;
				logLandSuc($id, $name, $comName, $point);
			}
		}

		# 돈을 차감
		$island->{'money'} -= $cost;

		# 횟수 지정이면, 명령을 되돌림
		if(($kind == $HcomFarm) ||
			($kind == $HcomFactory) ||
			(($kind == $HcomDbase) && $HdurableDef)) {
			if($arg> 1) {
				$arg--;
				slideBack($comArray, 0);
				$comArray->[0] = {
					'kind' => $kind,
					'target' => $target,
					'x' => $x,
					'y' => $y,
					'arg' => $arg,
					'target2' => $target2
				};
			}
		}
		return $HcomTurn[$kind];

	} elsif (($HcomComplex[0] <= $kind) && ($kind <= $HcomComplex[$#HcomplexComName])) {
		# 복합 지형건설
		$arg = 1 if(!$arg);
		my $rep = (!$HcomTurn[$kind]) ? $arg : 1;
		if($rep> 1) {
			my $value = min($rep * $cost, $island->{'money'});
			$rep = int($value / $cost) if($cost);
			$comName.= "($rep 회)";
			$cost *= $rep;
			$arg = 1;
		}
		unless (buildComplex($island, $comName, $kind - $HcomComplex[0], $rep, $x, $y)) {
			if($island->{'comflag'}) {
				if($arg> 1) {
					$arg--;
					slideBack($comArray, 0);
					$comArray->[0] = {
						'kind' => $kind,
						'target' => $target,
						'x' => $x,
						'y' => $y,
						'arg' => $arg,
						'target2' => $target2
					};
				}
			}
			return 0;
		}

		$island->{'money'} -= $cost;
		# 횟수 지정이면, 명령을 되돌림
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg,
				'target2' => $target2
			};
		}
		return $HcomTurn[$kind];

	} elsif($kind == $HcomMountain) {
		# 채굴장
		if($landKind != $HlandMountain) {
			# 산이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			if($island->{'comflag'}) {
				if($arg> 1) {
					$arg--;
					slideBack($comArray, 0);
					$comArray->[0] = {
						'kind' => $kind,
						'target' => $target,
						'x' => $x,
						'y' => $y,
						'arg' => $arg,
						'target2' => $target2
					};
				}
			}
			return 0;
		}
		$arg = 1 if(!$arg);
		my $rep = (!$HcomTurn[$kind]) ? $arg : 1;
		if($rep> 1) {
			my $value = min($rep * $cost, $island->{'money'});
			$rep = int($value / $cost) if($cost);
			$comName.= "($rep 회)";
			$cost *= $rep;
			$arg = 1;
		}

		$landValue->[$x][$y] += 5*$rep; # 규모 + 5000인
		if($landValue->[$x][$y]> 200) {
			$landValue->[$x][$y] = 200; # 최대 200000인
		}
		logLandSuc($id, $name, $comName, $point);

		# 돈을 차감
		$island->{'money'} -= $cost;
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg,
				'target2' => $target2
			};
		}
		return $HcomTurn[$kind];

	} elsif($kind == $HcomSeaMine) {
		# 기뢰
		return if(!$HuseSeaMine);
		if($landKind == $HlandSeaMine){
			# 이미기뢰이면 제거
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, '기뢰제거', '(?, ?)');
			$arg = min($lv, int($island->{'money'} / ($cost * 0.2))) if($cost);
			$island->{'money'} -= $arg * ($cost * 0.2);
			$island->{'mine'}--;
			return $HcomTurn[$kind];
		} elsif(($landKind != $HlandSea) || $lv){
			# 바다이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		if($HedgeReclaim) { # 섬의 가장 바깥쪽을 매립 불가로 설정한 경우
			my($map) = $island->{'map'};
			my(@x) = @{$map->{'x'}};
			my(@y) = @{$map->{'y'}};
			if(($x < $x[0] + $HedgeReclaim) || ($x> $x[$#x] - $HedgeReclaim) || ($y < $y[0] + $HedgeReclaim) || ($y> $y[$#y] - $HedgeReclaim)) {
				logLandFail($id, $name, $comName, "섬의 가장 바깥쪽", $point);
				return 0;
			}
		}
		if($island->{'mine'}>= $HuseSeaMine) {
			logOverFail($id, $name, $comName, $point);
			return 0;
		}

		# 파괴력상한 $HmineDamageMax
		if(!$arg){
			$arg = 1;
		} elsif($arg> $HmineDamageMax){
			$arg = $HmineDamageMax;
		}
		my $value = min($arg * $cost, $island->{'money'});
		$arg = int($value / $cost) if($cost);
		$land->[$x][$y] = $HlandSeaMine;
		$landValue->[$x][$y] = $arg; # 파괴력
		logLandSuc($id, $name, $comName, '(?, ?)');

		# 돈을 차감
		$island->{'money'} -= $value;
		$island->{'mine'}++;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomSbase) {
		# 해저 기지
		return if(!$HuseSbase || $Htournament);
		if(($landKind != $HlandSea) || $lv){
			# 바다이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		if($HedgeReclaim) { # 섬의 가장 바깥쪽을 매립 불가로 설정한 경우
			my($map) = $island->{'map'};
			my(@x) = @{$map->{'x'}};
			my(@y) = @{$map->{'y'}};
			if(($x < $x[0] + $HedgeReclaim) || ($x> $x[$#x] - $HedgeReclaim) || ($y < $y[0] + $HedgeReclaim) || ($y> $y[$#y] - $HedgeReclaim)) {
				logLandFail($id, $name, $comName, "섬의 가장 바깥쪽", $point);
				return 0;
			}
		}

		$land->[$x][$y] = $HlandSbase;
		$landValue->[$x][$y] = 0; # 경험치0
		logLandSuc($id, $name, $comName, '(?, ?)');

		# 돈을 차감
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomCore) {
		return if(!$HuseCore);
		if ($HuseCoreLimit && ($HislandTurn - $island->{'birthday'}> $HdevelopTurn)) {
			logDevelopTurnFail2($id, $name, $comName);
			return 0;
		}
		# 코어
		$arg = 1 if(!$arg);
		my $rep = (!$HcomTurn[$kind]) ? $arg : 1;
		# 한 번에 수량분의 내구력을 추가한 경우
		# 위 한 줄을 주석 처리하면 아래 코멘트를 표시하지 않음
		#my $rep = $arg;
		if($landKind == $HlandCore) {
			# 이미코어의 경우
			if(!$HdurableCore) {
				# 부적절나 지형
				logLandFail($id, $name, $comName, $landName, $point);
				if($island->{'comflag'}) {
					if($arg> 1) {
						$arg--;
						slideBack($comArray, 0);
						$comArray->[0] = {
							'kind' => $kind,
							'target' => $target,
							'x' => $x,
							'y' => $y,
							'arg' => $arg,
							'target2' => $target2
						};
					}
				}
				return 0;
			} else {
				if($rep> 1) {
					my $value = min($rep * $cost, $island->{'money'});
					$rep = int($value / $cost) if($cost);
					$cost *= $rep;
					$arg = 1;
				}
				if($lv % 10000 == $HdurableCore - 1) {
					logBombDurableMax($id, $name, $landName, $point, $HcoreHide);
				} else {
					$rep = ($HdurableCore - 1) - ($lv % 10000) if($rep> ($HdurableCore - 1) - ($lv % 10000));
					$landValue->[$x][$y] += $rep;
					logBombDurableUp($id, $name, $landName, $point, $rep, $HcoreHide);
				}
			}
		} else {
			if(($landKind != $HlandPlains) && ($landKind != $HlandSea)) {
				# 평지 또는 바다가 아니면 만들 수 없음
				logLandFail($id, $name, $comName, $landName, $point);
				if($island->{'comflag'}) {
					if($arg> 1) {
						$arg--;
						slideBack($comArray, 0);
						$comArray->[0] = {
							'kind' => $kind,
							'target' => $target,
							'x' => $x,
							'y' => $y,
							'arg' => $arg,
							'target2' => $target2
						};
					}
				}
				return 0;
			} elsif($HcoreMax && ($island->{'core'}>= $HcoreMax)) {
				logOverFail($id, $name, $comName, $point);
				if($island->{'comflag'}) {
					if($arg> 1) {
						$arg--;
						slideBack($comArray, 0);
						$comArray->[0] = {
							'kind' => $kind,
							'target' => $target,
							'x' => $x,
							'y' => $y,
							'arg' => $arg,
							'target2' => $target2
						};
					}
				}
				return 0;
			}
			if($rep> 1) {
				my $value = min($rep * $cost, $island->{'money'});
				$rep = int($value / $cost) if($cost);
				$rep = min($rep, $HdurableCore) if($HdurableCore);
				$comName.= "(내구력$rep)";
				$cost *= $rep;
				$arg = 1;
			}
			# 대상 위치를 코어에
			$land->[$x][$y] = $HlandCore;
			$rep = 1 if(!$HdurableCore);
			$landValue->[$x][$y] = $rep - 1;
			$island->{'core'}++;
			if($landKind == $HlandSea) {
				$landValue->[$x][$y] += (!$lv) ? 20000 : 10000; # 바다, 얕은 바다
			}
			if ($HcoreHide) { # 코어를 위장하다?
				if($landKind == $HlandPlains) {
				 logPBSuc($id, $name, $comName, $point); # 숲
				} else {
					logLandSuc($id, $name, $comName, '(?, ?)'); # 바다
				}
			} else {
			 logLandSuc($id, $name, $comName, $point);
			}
		}
		# 돈을 차감
		$island->{'money'} -= $cost;
		# 횟수 지정이면, 명령을 되돌림
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg,
				'target2' => $target2
			};
		}
		return $HcomTurn[$kind];

	} elsif (($HcomMissile[0] <= $kind) && ($kind <= $HcomMissile[$#HmissileName])) {
		return if(!$HuseBase || !HuseSbase);
		# 미사일계
		if((($HflagCommand += $HflagST)>= int($island->{'itemAbility'}[6])) && $STcheck{$kind}) {
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
			};
			return 1;
		}

		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		my($tIsland) = $Hislands[$tn];

		if ($id != $target) {
			# 다른 섬으로 공격

			# 발사 가능아니오 확인
			# 개발 기간이면 명령 무시
			if (
				($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn)) ||
				($HsurvivalTurn && ($HislandTurn <= $HsurvivalTurn))
				) {
				# 공격이 허가되어 있지 않음
				logNotAvail($id, $name, $comName);
				return 0;
			} elsif (($HislandTurn - $island->{'birthday'} <= $HdevelopTurn) ||
				($HislandTurn - $tIsland->{'birthday'} <= $HdevelopTurn)) {
				logDevelopTurnFail($id, $name, $comName);
				return 0;
			} elsif(!$HforgivenAttack && $tIsland->{'predelete'}) {
				logLandNG($id, $name, $comName, '현재 [관리자 보관] 상태이므로 ');
				return 0;

			} elsif($Htournament) {
				if($HislandFightMode < 2) {
					logLandNG($id, $name, $comName, '현재 개발 기간 중이어서 ');
					return 0;
				} elsif($island->{'fight_id'} != $tIsland->{'id'}) {
					# 대전 상대가 아닌 경우
					logLandNG($id, $name, $comName, '목표가 대전 상대가 아니어서 ');
					return 0;
				}
			} elsif(($HuseDeWar> 1) && !$HarmisticeTurn && !$HsurvivalTurn) {
				my $warflag = chkWarIsland($id, $target);
				if(!$warflag) {
					logLandNG($id, $name, $comName, '선전포고를 하지 않아서 ');
					return 0;
				} elsif(($warflag == 1) && ($HuseDeWar == 3)) {
					logLandNG($id, $name, $comName, '유예 기간 중이어서 ');
					return 0;
				}
			} elsif($tIsland->{'event'}[0]) {
				if(($tIsland->{'event'}[1] - $HnoticeTurn < $HislandTurn) && ($HislandTurn < $tIsland->{'event'}[1])) {
					logLandNG($id, $name, $comName, '현재 이벤트 준비 기간 중이어서 ');
					return 0;
				} elsif(($tIsland->{'event'}[6] == 1) && ($HislandTurn> $tIsland->{'event'}[1])) {
					# 이벤트유형이서바이벌
					logLandNG($id, $name, $comName, '서바이벌 개최 중이 아니어서 ');
					return 0;
				}
			}
		}

		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}

		# 값이 0이면 공격 중인 대상만
		$arg = 10000 if($arg == 0);

		# 미사일 발사
		require('./hako-missile.cgi');
		return 0 unless(missileFire($target, $island, $tIsland, $x, $y, $kind, $arg, $cost));
		if (!$HcomTurn[$kind] && ($HmissileSpecial[$kind - $HcomMissile[0]] & 0x1)) {
			# 다음 명령이 ST 미사일 또는 ST 괴수 파견이 아니면 턴 소비 없음
			$HflagST = 1 if($HattackST);
			return 0 if (!($STcheck{$comArray->[0]->{'kind'}}) &&
				 ($comArray->[0]->{'kind'} != $HcomSendMonsterST));
		}
		return $HcomTurn[$kind];

	} elsif(($kind == $HcomSendMonster) ||
		($kind == $HcomSendMonsterST)) {
		# 괴수 파견
		return if((!$HuseSendMonster && ($kind == $HcomSendMonster)) || (!$HuseSendMonsterST && ($kind == $HcomSendMonsterST)) || $Htournament);
		if((($HflagCommand += $HflagST)>= int($island->{'itemAbility'}[6])) && ($kind == $HcomSendMonsterST)) {
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
			};
			return 1;
		}
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);


		if ($id != $target) {
			# 다른 섬으로 공격
			if($HoceanMode && $HnotuseMonsterSend) {
				my($fw) = $island->{'wmap'};
				my($tw) = $tIsland->{'wmap'};
				if($HislandConnect[$fw->{'x'}][$fw->{'y'}] == $HislandConnect[$tw->{'x'}][$tw->{'y'}]) {
					logLandNG($id, $name, $comName, '해역이 접속하고 있어서 ');
					return 0;
				}
			}

			my(%amityFlag);
			my($amity) = $island->{'amity'};
			foreach (@$amity) {
				$amityFlag{$_} = 1;
			}
			# 개발 기간이면 명령 무시
			if (
				($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn || $amityFlag{$target})) ||
				($HsurvivalTurn && ($HislandTurn <= $HsurvivalTurn))
				) {
				# 공격이 허가되어 있지 않음
				logNotAvail($id, $name, $comName);
				return 0;
			} elsif (($HislandTurn - $island->{'birthday'} <= $HdevelopTurn) ||
				($HislandTurn - $tIsland->{'birthday'} <= $HdevelopTurn)) {
				logDevelopTurnFail($id, $name, $comName);
				return 0;
			} elsif(!$HforgivenAttack && $tIsland->{'predelete'}) {
				logLandNG($id, $name, $comName, '현재 [관리자 보관] 상태이므로 ');
				return 0;

			} elsif($Htournament) {
				if($HislandFightMode < 2) {
					logLandNG($id, $name, $comName, '현재 개발 기간 중이어서 ');
					return 0;
				} elsif($island->{'fight_id'} != $tIsland->{'id'}) {
					# 대전 상대가 아닌 경우
					logLandNG($id, $name, $comName, '목표가 대전 상대가 아니어서 ');
					return 0;
				}
			} elsif(($HuseDeWar> 1) && !$HarmisticeTurn && !$HsurvivalTurn) {
				my $warflag = chkWarIsland($id, $target);
				if(!$warflag) {
					logLandNG($id, $name, $comName, '선전포고를 하지 않아서 ');
					return 0;
				} elsif(($warflag == 1) && ($HuseDeWar == 3)) {
					logLandNG($id, $name, $comName, '유예 기간 중이어서 ');
					return 0;
				}
			} elsif($tIsland->{'event'}[0]) {
				if(($tIsland->{'event'}[1] - $HnoticeTurn < $HislandTurn) && ($HislandTurn < $tIsland->{'event'}[1])) {
					logLandNG($id, $name, $comName, '현재 이벤트 준비 기간 중이어서 ');
					return 0;
				} elsif(($tIsland->{'event'}[6] == 1) && ($HislandTurn> $tIsland->{'event'}[1])) {
					# 이벤트유형이서바이벌
					logLandNG($id, $name, $comName, '서바이벌 개최 중이 아니어서 ');
					return 0;
				}
			}
		}

		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}

		# 메시지
		if ($kind == $HcomSendMonsterST) {
			logMonsSendST($id, $target, $name, $tName);
		} else {
			logMonsSend($id, $target, $name, $tName);
		}


		my $huge = 0;
		if($arg>= 50 && ($HsendHugeMonsterNumber>= 0) && $HhugeMonsterAppear) {
			$huge = 1;
			$arg -= 50;
			$arg = $HsendHugeMonsterNumber if($arg> $HsendHugeMonsterNumber);
			$cost = ($kind == $HcomSendMonsterST) ? $HhugeMonsterCostST[$arg] : $HhugeMonsterCost[$arg];
		} else {
			$arg = $HsendMonsterNumber if($arg> $HsendMonsterNumber);
			$cost = ($kind == $HcomSendMonsterST) ? $HmonsterCostST[$arg] : $HmonsterCost[$arg];
		}
		# 메카이노라를 보내는
		bringMonster($tIsland, ($kind == $HcomSendMonsterST) ? 0 : $id, $arg, $huge);

		$island->{'money'} -= $cost;
		$island->{'ext'}[1] += $cost; # 공헌도
		$tIsland->{'ext'}[1] += $cost; # 공헌도

		if (!$HcomTurn[$kind] && ($kind == $HcomSendMonsterST)) {
			# 다음 명령이 ST 미사일 또는 ST 괴수 파견이 아니면 턴 소비 없음
			$HflagST = 1 if($HattackST);
			return 0 if (!($STcheck{$comArray->[0]->{'kind'}}) &&
				 ($comArray->[0]->{'kind'} != $HcomSendMonsterST));
		}
		return $HcomTurn[$kind];

	} elsif (($HcomNavy[0] <= $kind) && ($kind <= $HcomNavy[$#HnavyName])) {
		# 해군건조
		return 0 unless (buildNavy($island, $comName, $kind - $HcomNavy[0], $arg, $x, $y));

		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif (($kind == $HcomNavyMove) || ($kind == $HcomNavySend) || ($kind == $HcomNavyReturn)) {
		# 함대 이동(파견·귀환)

		my($ftarget, $ttarget);
		if($kind == $HcomNavyMove) {
			# 함대 이동
			($ftarget, $ttarget) = ($target, $target2);
		} elsif($kind == $HcomNavySend) {
			# 함대 파견
			($ftarget, $ttarget) = ($id, $target);
		} else {
			# 함대 귀환
			($ftarget, $ttarget) = ($target, $id);
		}
		$comName = ($id == $ttarget) ? '함대 귀환' : '함대 파견';
		# 함대 이동원래대상 가져오기
		my($fn) = $HidToNumber{$ftarget};
		if($fn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		my($fromIsland) = $Hislands[$fn];

		# 함대 이동 대상대상 가져오기
		my($tn) = $HidToNumber{$ttarget};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		my($toIsland) = $Hislands[$tn];
		if($HoceanMode && $HnotuseNavyMove) {
			my($fw) = $fromIsland->{'wmap'};
			my($tw) = $toIsland->{'wmap'};
			if($HislandConnect[$fw->{'x'}][$fw->{'y'}] == $HislandConnect[$tw->{'x'}][$tw->{'y'}]) {
				logLandNG($id, $name, $comName, '해역이 접속하고 있어서 ');
				return 0;
			}
		}

		if ($id != $ttarget) {
			# 다른 섬으로 공격
			# 개발 기간이면 명령 무시
			if (
				($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn)) ||
				($HsurvivalTurn && ($HislandTurn <= $HsurvivalTurn))
				) {
				# 공격이 허가되어 있지 않음
				logNotAvail($id, $name, $comName);
				return 0;
			} elsif (($HislandTurn - $island->{'birthday'} <= $HdevelopTurn) ||
				($HislandTurn - $toIsland->{'birthday'} <= $HdevelopTurn)) {
				logDevelopTurnFail($id, $name, $comName);
				return 0;
			} elsif(!$HforgivenAttack && $toIsland->{'predelete'}) {
				logLandNG($id, $name, $comName, '현재 [관리자 보관] 상태이므로 ');
				return 0;
			} elsif($HnofleetNotAvail && !$toIsland->{'field'} && !$toIsland->{'ships'}[4]) {
				logLandNG($id, $name, $comName, "함대를 보유하지 않은 $AfterName이기 때문에");
				return 0;

			} elsif($Htournament) {
				if($HislandFightMode < 2) {
					logLandNG($id, $name, $comName, '현재 개발 기간 중이어서 ');
					return 0;
				} elsif($island->{'fight_id'} != $toIsland->{'id'}) {
					# 대전 상대가 아닌 경우
					logLandNG($id, $name, $comName, '목표가 대전 상대가 아니어서 ');
					return 0;
				}
			} elsif(($HuseDeWar> 1) && !$toIsland->{'field'} && !$HarmisticeTurn && !$HsurvivalTurn) {
				my(%amityFlag);
				my($amity) = $island->{'amity'};
				foreach (@$amity) {
					$amityFlag{$_} = 1;
				}
				if(!$amityFlag{$ttarget}) {
					my $warflag = chkWarIsland($id, $ttarget);
					if(!$warflag) {
						logLandNG($id, $name, $comName, '선전포고를 하지 않아서 ');
						return 0;
					} elsif(($warflag == 1) && ($HuseDeWar == 3)) {
						logLandNG($id, $name, $comName, '유예 기간 중이어서 ');
						return 0;
					}
				}

			} elsif($toIsland->{'event'}[0]) {
				my $level = 2 ** gainToLevel($island->{'gain'});
				if(($toIsland->{'event'}[1] - $HnoticeTurn < $HislandTurn) && ($HislandTurn < $toIsland->{'event'}[1])) {
					logLandNG($id, $name, $comName, '현재 이벤트 준비 기간 중이어서 ');
					return 0;
				} elsif($toIsland->{'event'}[3] && ($toIsland->{'event'}[3] <= $island->{"invade$ttarget"})) {
					logLandNG($id, $name, $comName, '파견 가능한 함정 수를 초과했기 때문에');
					return 0;
				} elsif($HmaxComNavyLevel && !($toIsland->{'event'}[5] & (2 ** gainToLevel($island->{'gain'})))) {
					logLandNG($id, $name, $comName, '파견 가능한 레벨이 아니어서 ');
					return 0;
				} elsif((!$toIsland->{'event'}[11]) && ($HislandTurn> $toIsland->{'event'}[1])) {
					# 추가 파견을 허가 안 함
					logLandNG($id, $name, $comName, '이벤트 개최 중이 아니어서 ');
					return 0;
				}

			} elsif($island->{'NavyAttack_flag'}[$arg - 1]) {
				# 명령을 허가 안 함
				logLandNG($id, $name, $comName, '전투상태에있어서 ');
				return 0;
			}
		}


		# 4함대만
		$arg--;
		if ($arg < 0) {
			$arg = 0;
		} elsif ($arg> 3) {
			$arg = 3;
		}

		# 함대를 이동하다
		return 0 unless (moveFleet($island, $fromIsland, $toIsland, $arg));
		$island->{'money'} -= $cost;
		if($id != $ttarget) {
			$island->{'ext'}[1] += $cost; # 공헌도
			$toIsland->{'ext'}[1] += $cost; # 공헌도
			$island->{'NavyMove_flag'}[$arg] = 1; # 이동플래그를 설립하고 있는
		}
		return $HcomTurn[$kind];

	} elsif ($kind == $HcomNavyForm) {
		# 함대 편성
		if ($landKind != $HlandNavy) {
			# 해군만함대 편성할 수 없
			logNavyFormFail($id, $name, $point, $landName);
			return 0;
		}

		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		my $nSpecial = $HnavySpecial[$nKind];
		if (($nSpecial & 0x8) || ($nId != $id)) {
			# 항구, 잔해, 다른 섬의 함대, 은함대 편성할 수 없
			logNavyFormFail($id, $name, $point, $landName);
			return 0;
		}

		# 4함대만
		$arg--;
		if ($arg < 0) {
			$arg = 0;
		} elsif ($arg> 3) {
			$arg = 3;
		}
		my $ofname1 = $island->{'fleet'}->[$nNo];
		my $ofname2 = $island->{'fleet'}->[$arg];

		my $nflag = $island->{'itemAbility'}[3];
		if($HfleetMaximum && ($island->{'ships'}[$arg]>= $HfleetMaximum + int($nflag/4))){
			logNavyFormMaxOver($id, $name, $point, $landName, $ofname1, $ofname2);
			return 0;
		}

		$island->{'ships'}[$nNo]--;
		$island->{'ships'}[$arg]++;
		$landValue->[$x][$y] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $arg, $nKind, $nHp);

		logNavyForm($id, $name, $point, $landName, $ofname1, $ofname2);

		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif ($kind == $HcomNavyExpell) {
		# 함정 소속 해제(함정 소속 해제)
		if ($landKind != $HlandNavy) {
			# 해군만 대상으로 지정할 수 있습니다
			logNavyTargetFail($id, $name, $point, $landName);
			return 0;
		}

		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		my $nSpecial = $HnavySpecial[$nKind];
		if (($nSpecial & 0x8) || ($nId != $id)) {
			# 항구와 다른 섬의 함대는 소속 해제할 수 없습니다
			logNavyTargetFail($id, $name, $point, $landName);
			return 0;
		}

		#$landValue->[$x][$y] = navyPack(0, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp); # 소속 섬 없음로
		$landValue->[$x][$y] = navyPack(0, $nTmp, 0, $nSea, $nExp, $nFlag, 0, $nKind, $nHp); # 소속 섬 없음(일반)로

		logNavyTarget($id, $name, $point, $landName);

		$island->{'money'} -= $cost;
		$island->{'shipk'}[$nKind]--;
		$island->{'ships'}[$nNo]--;
		$island->{'ships'}[4]--;
		# 서바이벌
		$island->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
		return $HcomTurn[$kind];

	} elsif ($kind == $HcomNavyDestroy) {
		# 함정 폐기
		if ($landKind != $HlandNavy) {
			# 해군만폐기할 수 없
			logNavyDestroyFail($id, $name, $point, $landName);
			return 0;
		}

		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		my $nSpecial = $HnavySpecial[$nKind];
		if (($nSpecial & 0x8) || ($nId != $id)) {
			# 항구와 다른 섬의 함대는 폐기할 수 없
			logNavyDestroyFail($id, $name, $point, $landName);
			return 0;
		}

		$land->[$x][$y] = $HlandSea; # 바다로
		$landValue->[$x][$y] = 0;

		logNavyDestroy($id, $name, $point, $landName);

		$island->{'money'} -= $cost;
		$island->{'shipk'}[$nKind]--;
		$island->{'ships'}[$nNo]--;
		$island->{'ships'}[4]--;
		# 서바이벌
		$island->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
		return $HcomTurn[$kind];

	} elsif ($kind == $HcomNavyWreckRepair) {
		# 잔해 수리
		if ($landKind != $HlandNavy) {
			# 해군만 수리할 수 없
			logNavyWreckRepairFail($id, $name, $point, $landName);
			return 0;
		}

		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		my $nSpecial = $HnavySpecial[$nKind];
		unless ($nFlag & 1) {
			# 잔해이외는 수리할 수 없
			logNavyWreckRepairFail($id, $name, $point, $landName);
			return 0;
		}
		$cost = int($HnavyCost[$nKind] * ($nExp / 100.0) * $cflag);
		if ($island->{'money'} < $cost) {
			#자금이 부족하음
			logNoMoney($id, $name, $comName);
			return 0;
		}

		# 4함대만
		$arg--;
		if ($arg < 0) {
			$arg = 0;
		} elsif ($arg> 3) {
			$arg = 3;
		}

		my $ofname = $island->{'fleet'}->[$arg];

		# 보유 가능 함정 수 확인
		my $nflag = int($island->{'itemAbility'}[3]);
		my $nflagk = (!$#HnavyName) ? 1 : int($nflag/$#HnavyName);
		$nflagk = 1 if($nflag && ($nflagk < 1));
		if($HnavyMaximum && ($island->{'ships'}[4]>= $HnavyMaximum + $nflag)) {
			logNavyMaxOver($id, $name, $comName);
			return 0;
		} elsif($HportRetention && ($island->{'ships'}[4]>= $island->{'navyPort'} * $HportRetention + $nflag)) {
			logFleetMaxOver($id, $name, $comName, "1군항주변");
			return 0;
		} elsif($HfleetMaximum && ($island->{'ships'}[$arg]>= $HfleetMaximum + int($nflag/4))) {
			logNavyWreckRepairMaxOver($id, $name, $point, $landName, "${ofname}함대");
			return 0;
		} elsif($HnavyKindMax[$nKind] && ($island->{'shipk'}[$nKind]>= $HnavyKindMax[$nKind] + $nflagk)) {
			logNavyKindMaxOver($id, $name, $comName);
			return 0;
		}
		$landValue->[$x][$y] = navyPack($id, $nTmp, $nStat, $nSea, 0, 0, $arg, $nKind, $HnavyHP[$nKind]);
		$island->{'shipk'}[$nKind]++;
		$island->{'ships'}[$arg]++;
		$island->{'ships'}[4]++;

		# 이동 완료로
		$HnavyMove[$id][$x][$y] = 2;

		logNavyWreckRepair($id, $name, $point, $landName, $cost, "${ofname}함대");

		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif ($kind == $HcomNavyWreckSell) {
		# 잔해 매각
		if ($landKind != $HlandNavy) {
			# 해군만매각할 수 없
			logNavyWreckSellFail($id, $name, $point, $landName);
			return 0;
		}

		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		my $nSpecial = $HnavySpecial[$nKind];
		unless ($nFlag& 1) {
			# 잔해이외는 매각할 수 없
			logNavyWreckSellFail($id, $name, $point, $landName);
			return 0;
		}

		# 매각 가격은'잔해의 값 값 × 시세(50%~100%)'
		$cost = int($HnavyCost[$nKind] * (1.0 - $nHp / 100.0) * ((rand(6) + 5) / 10.0));

		$land->[$x][$y] = $HlandSea; # 바다가 됨
		$landValue->[$x][$y] = 0;

		if (rand(100) < $HnavyProbWreckGold) {
			my $cost = int(rand(10) + 1) * 100; # 100억~1000억 엔
			logNavyWreckSellLucky($id, $name, $point, $landName, $cost);
			$island->{'money'} += $cost;
		} elsif($HitemRest && $HitemGetDenominator3 && (random($HitemGetDenominator3) < $island->{'gain'})) {
			#아이템 획득 판정
			my $num = @Hitem;
			$num = random($num);
			push(@{$island->{'item'}}, $Hitem[$num]);
			$HitemGetId[$Hitem[$num]]{$id} = 1;
			$HitemRest--;
			logItemGetLucky2($id, $name, $point, $HitemName[$Hitem[$num]], "$landName 을끌어올렸더니");
			splice(@Hitem, $num, 1);
		}

		logNavyWreckSell($id, $name, $point, $landName, $cost);

		$island->{'money'} += $cost;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomMoveTarget) {
		# 기함(파견괴수)를 이동
		return if(!$HuseFlag);

		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		my($tIsland) = $Hislands[$tn];
		my($tId) = $tIsland->{'id'};
		my($tName) = islandName($tIsland);
		my($tLand) = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		my($tL) = $tLand->[$x][$y];

		my $sFlag = 0;
		if(($tL != $HlandNavy) && ($tL != $HlandMonster)) {
			if($tL == $HlandHugeMonster) {
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($tLandValue->[$x][$y]);
				$sFlag = ($HhugeMonsterSpecial[$mKind] & 0x80);
				if(!$sFlag) {
					logMoveFail($id, $tName, $point, "조종할 수 없는 지형이어서,");
					return 0;
				} elsif($mHflag != 0) {
					logMoveFail($id, $tName, $point, "코어가 아니어서,");
					return 0;
				}
			} else {
				logMoveFail($id, $tName, $point, "조종할 수 없는 지형이어서,");
				return 0;
			}
		} elsif($tL == $HlandNavy) {
			$sFlag = ($HnavySpecial[(navyUnpack($tLandValue->[$x][$y]))[7]] & 0x80);
			if(!$sFlag) {
				logMoveFail($id, $tName, $point, "조종할 수 없는 지형이어서,");
				return 0;
			}
		} elsif($tL == $HlandMonster) {
			$sFlag = ($HmonsterSpecial[(monsterUnpack($tLandValue->[$x][$y]))[5]] & 0x80);
			if(!$sFlag) {
				logMoveFail($id, $tName, $point, "조종할 수 없는 지형이어서,");
				return 0;
			}
		}

		my($sx, $sy, $via, $via1, $via2, $viaflag1, $viaflag2, $moveflag);
		if($arg> 6) { # 2칸 이동의1칸메
		# 경유점을 조사하기
			$sFlag = 0;
			$via1 = int(($arg - 5) / 2);
			$via2 = $via1 + (($arg - 5) % 2);
			$via2 = 1 if($via2> 6);
			$viaflag1 = random(1); # 두 가지 후보 방향이 있으면 무작위로 시도
			$viaflag2 = ($viaflag1 + 1) % 2;
			$via = ($via1, $via2)[$viaflag1];
			$sx = $x + $ax[$via];
			$sy = $y + $ay[$via];
			# 행 기준 위치 조정
			$sx-- if(!($sy % 2) && ($y % 2));
			$sx = $correctX[$sx + $#an];
			$sy = $correctY[$sy + $#an];
			$via += 2; # $pre(선 줄 이동플래그)와 겸용하기 위해 +2
			if($tL == $HlandNavy) {
				$sFlag = ($HnavySpecial[(navyUnpack($tLandValue->[$x][$y]))[7]] & 0x3);
				if(moveNavy($id, $tIsland, $x, $y, $via)) {# 이동성공
					if(($tLand->[$sx][$sy] == $HlandNavy) && ((navyUnpack($tLandValue->[$sx][$sy]))[8]> 0)) {
						$x = $sx;
						$y = $sy;
						$arg = ($via1, $via2)[$viaflag2];
						$moveflag = 1;
					} else {# 이동 시 문제?
					# 비용을 인쿠
						logMoveFail($id, $tName, "($sx, $sy)", "문제가 발생해서,");
						$island->{'money'} -= $cost;
						return $HcomTurn[$kind];
					}
				} else {# 별도루와 를시도
					$via = ($via1, $via2)[$viaflag2];
					$sx = $x + $ax[$via];
					$sy = $y + $ay[$via];
					# 행 기준 위치 조정
					$sx-- if(!($sy % 2) && ($y % 2));
					$sx = $correctX[$sx + $#an];
					$sy = $correctY[$sy + $#an];
					$via += 2; # $pre(선 줄 이동플래그)와 겸용하기 위해
					if(moveNavy($id, $tIsland, $x, $y, $via)) {# 이동성공
						if(($tLand->[$sx][$sy] == $HlandNavy) && ((navyUnpack($tLandValue->[$sx][$sy]))[8]> 0)) {
							$x = $sx;
							$y = $sy;
							$arg = ($via1, $via2)[$viaflag1];
							$moveflag = 1;
						} else {# 이동 시 문제?
							logMoveFail($id, $tName, "($sx, $sy)", "문제가 발생해서,");
							$island->{'money'} -= $cost;
							return $HcomTurn[$kind];
						}
					} else {#어느 방향으로도 이동할 수 없음
						logMoveFail($id, $tName, $point, "이동할 수 없어서,");
						$HnavyMove[$tId][$x][$y] = 2;
						return 0;
					}
				}
			} elsif($tL == $HlandMonster) {
				$sFlag = ($HmonsterSpecial[(monsterUnpack($tLandValue->[$x][$y]))[5]] & 0x3);
				if(moveMonster($id, $tIsland, $x, $y, $via, 0)) {# 이동성공
					if($tLand->[$sx][$sy] == $HlandMonster) {
						$x = $sx;
						$y = $sy;
						$arg = ($via1, $via2)[$viaflag2];
						$moveflag = 1;
					} else {# 이동 시 문제?
						logMoveFail($id, $tName, "($sx, $sy)", "문제가 발생해서,");
						$island->{'money'} -= $cost;
						return $HcomTurn[$kind];
					}
				} else {# 별도루와 를시도
					$via = ($via1, $via2)[$viaflag2];
					$sx = $x + $ax[$via];
					$sy = $y + $ay[$via];
					# 행 기준 위치 조정
					$sx-- if(!($sy % 2) && ($y % 2));
					$sx = $correctX[$sx + $#an];
					$sy = $correctY[$sy + $#an];
					$via += 2; # $pre(선 줄 이동플래그)와 겸용하기 위해
					if(moveMonster($id, $tIsland, $x, $y, $via, 0)) {# 이동성공
						if($tLand->[$sx][$sy] == $HlandMonster) {
							$x = $sx;
							$y = $sy;
							$arg = ($via1, $via2)[$viaflag1];
							$moveflag = 1;
						} else {# 이동 시 문제?
							logMoveFail($id, $tName, "($sx, $sy)", "문제가 발생해서,");
							$island->{'money'} -= $cost;
							return $HcomTurn[$kind];
						}
					} else {#어느 방향으로도 이동할 수 없음
						logMoveFail($id, $tName, $point, "이동할 수 없어서,");
						$HmonsterMove[$tId][$x][$y] = 2;
						return 0;
					}
				}
			} elsif($tL == $HlandHugeMonster) {
				$sFlag = ($HhugeMonsterSpecial[(monsterUnpack($tLandValue->[$x][$y]))[5]] & 0x3);
				if(moveMonster($id, $tIsland, $x, $y, $via, 1)) {# 이동성공
					my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($tLandValue->[$sx][$sy]);
					if(($tLand->[$sx][$sy] == $HlandHugeMonster) && ($mHflag == 0)) {
						$x = $sx;
						$y = $sy;
						$arg = ($via1, $via2)[$viaflag2];
						$moveflag = 1;
					} else {# 이동 시 문제?
						logMoveFail($id, $tName, "($sx, $sy)", "문제가 발생해서,");
						$island->{'money'} -= $cost;
						return $HcomTurn[$kind];
					}
				} else {# 별도루와 를시도
					$via = ($via1, $via2)[$viaflag2];
					$sx = $x + $ax[$via];
					$sy = $y + $ay[$via];
					# 행 기준 위치 조정
					$sx-- if(!($sy % 2) && ($y % 2));
					$sx = $correctX[$sx + $#an];
					$sy = $correctY[$sy + $#an];
					$via += 2; # $pre(선 줄 이동플래그)와 겸용하기 위해
					if(moveMonster($id, $tIsland, $x, $y, $via, 1)) {# 이동성공
						my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($tLandValue->[$sx][$sy]);
						if(($tLand->[$sx][$sy] == $HlandHugeMonster) && ($mHflag == 0)) {
							$x = $sx;
							$y = $sy;
							$arg = ($via1, $via2)[$viaflag1];
							$moveflag = 1;
						} else {# 이동 시 문제?
							logMoveFail($id, $tName, "($sx, $sy)", "문제가 발생해서,");
							$island->{'money'} -= $cost;
							return $HcomTurn[$kind];
						}
					} else {#어느 방향으로도 이동할 수 없음
						logMoveFail($id, $tName, $point, "이동할 수 없어서,");
						$HmonsterMove[$tId][$x][$y] = 2;
						return 0;
					}
				}
			}
		}

		$sx = $x + $ax[$arg];
		$sy = $y + $ay[$arg];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		$arg += 2; # $pre(선 줄 이동플래그)와 겸용하기 위해
		if($tL == $HlandNavy) {
			if($sFlag && moveNavy($id, $tIsland, $x, $y, $arg)) {
				$HnavyMove[$tId][$sx][$sy] = 2;
			} else {
				$HnavyMove[$tId][$x][$y] = 2;
				logMoveFail($id, $tName, "($x, $y)", "이동할 수 없어서,");
				return ($moveflag ? $HcomTurn[$kind] : 0);
			}
		} elsif($tL == $HlandMonster) {
			if($sFlag && moveMonster($id, $tIsland, $x, $y, $arg, 0)) {
				$HmonsterMove[$tId][$sx][$sy] = 2;
			} else {
				$HmonsterMove[$tId][$x][$y] = 2;
				logMoveFail($id, $tName, "($x, $y)", "이동할 수 없어서,");
				return ($moveflag ? $HcomTurn[$kind] : 0);
			}
		} elsif($tL == $HlandHugeMonster) {
			if($sFlag && moveMonster($id, $tIsland, $x, $y, $arg, 1)) {
				$HmonsterMove[$tId][$sx][$sy] = 2;
			} else {
				$HmonsterMove[$tId][$x][$y] = 2;
				logMoveFail($id, $tName, "($x, $y)", "이동할 수 없어서,");
				return ($moveflag ? $HcomTurn[$kind] : 0);
			}
		}
		# 비용을 인쿠
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomNavyMission) {
		# 함정의 지령을 변경

		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		my($tIsland) = $Hislands[$tn];
		my($tLand) = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		my($fNo, $mNo) = (int($arg / 10), $arg % 10);
		if(($fNo> 4) || ($mNo> 3)) {
			# 숫자값 지정 이동
			logChangeMissionFail($id, $target, $name, islandName($tIsland));
			return 0;
		}
		if($fNo == 0) {
			# 일 함정의 지령을 변경
			my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($tLandValue->[$x][$y]);
			my $nSpecial = $HnavySpecial[$nKind];
			if(($tLand->[$x][$y] != $HlandNavy) || ($nFlag & 1) || ($nSpecial & 0x8) || ($nId != $id)) {
				# 해군이 아니거나, 잔해·군항·자기 섬 소속 함정이 아니면 실패
				logChangeMissionFail($id, $target, $name, islandName($tIsland));
				return 0;
			}
			$tLandValue->[$x][$y] = navyPack($nId, $nTmp, $mNo, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
			logChangeMission($id, $target, $name, islandName($tIsland), $point, $nStat, $mNo);
		} else {
			# 대상의 섬에 있는 함대모두로의 지령을 변경
			my($i, $j, $sx, $sy);
			$fNo--;
			my $ofname = $island->{'fleet'}->[$fNo];
			$j = 0;
			foreach $i (0..$island->{'pnum'}) {
				$sx = $tIsland->{'rpx'}[$i];
				$sy = $tIsland->{'rpy'}[$i];
				next if($tLand->[$sx][$sy] != $HlandNavy);
				my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($tLandValue->[$sx][$sy]);
				next if(($nFlag & 1) || ($nSpecial & 0x8) || ($nId != $id));
				$tLandValue->[$sx][$sy] = navyPack($nId, $nTmp, $mNo, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) if($nNo == $fNo);
				$j++;
			}
			if($j> 0) {
				logChangeMissionFleet($id, $target, $name, islandName($tIsland), $ofname, $mNo);
			} else {
				logChangeMissionFail($id, $target, $name, islandName($tIsland));
				return 0;
			}
		}
		# 비용을 인쿠
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomMoveMission) {
		# 함대에 대한 목표 지점으로의 이동 지령
		return if(!$HoceanMode);
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		my($tIsland) = $Hislands[$tn];
		my($flg, $fNo) = (int($arg / 10), $arg % 10);
		if($fNo < 1) {
			$fNo = 1;
		} elsif($fNo> 4) {
			$fNo = 4;
		}
		$fNo--;
		my $ofname = $island->{'fleet'}->[$fNo];
		if($flg) {
			undef $island->{'move'}[$fNo];
			logMoveMissionFleetLift($id, $target, $name, islandName($tIsland), $point, $ofname);
		} else {
			if($Hroundmode) {
				my($wx, $wy) = ($island->{'wmap'}->{'x'}, $island->{'wmap'}->{'y'});
				my($tWx, $tWy) = ($tIsland->{'wmap'}->{'x'}, $tIsland->{'wmap'}->{'y'});
				if(abs($tWx - $wx)> $HoceanSizeX/2) {
					$x = ($tWx> $wx) ? $x - ($HoceanSizeX * $HislandSizeX) : $x + ($HoceanSizeX * $HislandSizeX);
				}
				if(abs($tWy - $wy)> $HoceanSizeY/2) {
					$y = ($tWy> $wy) ? $y - ($HoceanSizeY * $HislandSizeY) : $y + ($HoceanSizeY * $HislandSizeY);
				}
			}
			$island->{'move'}[$fNo] = "$x,$y";
			logMoveMissionFleet($id, $target, $name, islandName($tIsland), $point, $ofname);
		}
		# 비용을 인쿠
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomNavyTarget) {
		# 일제 공격 명령
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		my($tIsland) = $Hislands[$tn];
		my($tLand) = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		my($mission) = $island->{"mission,$target,$x,$y"};
		if(defined $mission) {
			logNavyMission($id, $target, $name, islandName($tIsland), $point, landName($tLand->[$x][$y], $tLandValue->[$x][$y]), $mission);
		} else {
			logNavyMissionFail($id, $target, $name, islandName($tIsland), $point, landName($tLand->[$x][$y], $tLandValue->[$x][$y]));
		}
		# 비용을 인쿠
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomAmity) {
		# 우호국 설정·해제
		# 대상 가져오기
		return if(!$HuseAmity || $HarmisticeTurn || $Htournament);
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		# 주둔보류상황조사
		my(%invade);
		if($HamityDisarm) {
			foreach (@{$island->{'fkind'}}) {
				my($eId, $nFlag, $nKind) = (navyUnpack(hex($_)))[0,5,7];
				next if(($HnavySpecial[$nKind] & 0x8) || ($nFlag & 1)); # 군항·잔해는 제외
				if(($eId != $id) && (defined $HidToNumber{$eId})) {
					$invade{$eId}++;
				}
			}
		}
		my $amity = $island->{'amity'};
		my @newamity = ();
		my $ami;
		if($target == $id) {
			if($$amity[0] eq '') {
				if(!$HamityMax || $islandNumber < $HamityMax) {
					my $i;
					foreach $i (0..$islandNumber) {
						next if($Hislands[$i]->{'id'} == $id);
						push(@newamity, $Hislands[$i]->{'id'});
					}
					logAmity($id, $name, $target, "모두의${AfterName}");
				} else {
					logAmityMaxOver($id, $name, "모두의${AfterName}");
				}
			} else {
				@newamity = keys %invade;
				my($str);
				$str = '함대 파견 중에서 없는' if($HamityDisarm);
				logAmityEnd($id, $name, $target, "우호국이었던 모든 ${str}${AfterName}");
			}
			$island->{'amity'} = \@newamity;
			# 비용을 인쿠
			$island->{'money'} -= $cost;
			return 0;
		}
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);
		my $flag = 0;
		foreach $ami (@$amity) {
			if(!(defined $HidToNumber{$ami})) {
			} elsif($ami == $target) {
				$flag = 1;
			} else {
				push(@newamity, $ami);
			}
		}
		my $amiNum = @newamity;
		if($flag) {
			if($HamityDisarm && $invade{$target}) {
				push(@newamity, $target);
				logAmityEndFail($id, $name, $target, $tName);
			} else {
				logAmityEnd($id, $name, $target, $tName);
			}
		} else {
			if(!$HamityMax || $amiNum < $HamityMax) {
				push(@newamity, $target);
				logAmity($id, $name, $target, $tName);
			} else {
				logAmityMaxOver($id, $name, $tName);
			}
		}
		$island->{'amity'} = \@newamity;

		# 비용을 인쿠
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif($kind == $HcomAlly) {
		# 동맹 가입·탈퇴
		# 대상 가져오기
		return if(!$HallyUse || !$HallyJoinComUse || $HarmisticeTurn || $Htournament);
		my($tn) = $HidToNumber{$target};
		my($tan) = $HidToAllyNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		} elsif($tan eq '') {
			$tan = $HidToAllyNumber{$Hislands[$tn]->{'allyId'}[0]};
		}
		if($tan eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}

		my $tName = islandName($Hislands[$tn]);
		if(defined $HidToAllyNumber{$id}) {
			logLeaderAlready($id, $name, $tName, $comName);
			return;
		}
		my $ally = $Hally[$tan];
		if($HallyJoinOne && ($island->{'allyId'}[0] ne '') && ($island->{'allyId'}[0] != $ally->{'id'})) {
			logOtherAlready($id, $target, islandName($island), $ally->{'name'});
			return;
		}
		my(%vetoID);
		foreach(@{$ally->{'vetoId'}}) {
			$vetoID{$_} = 1;
		}
		if((!$ally->{'vkind'} && $vetoID{$id}) || ($ally->{'vkind'} && !$vetoID{$id})) {
			logAllyVeto($id, $target, islandName($island), $ally->{'name'});
			return;
		}
		my $allyMember = $ally->{'memberId'};
		my @newAllyMember = ();
		my $flag = 0;
		foreach (@$allyMember) {
			if(!(defined $HidToNumber{$_})) {
			} elsif($_ == $id) {
				$flag = 1;
			} else {
				push(@newAllyMember, $_);
			}
		}
		my $allyNum = @newAllyMember;
		if($flag) {
			logAllyEnd($id, $target, islandName($island), $ally->{'name'});
			my @newAlly = ();
			foreach (@{$island->{'allyId'}}) {
				if($_ != $ally->{'id'}) {
					push(@newAlly, $_);
				}
			}
			$island->{'allyId'} = \@newAlly;
			$ally->{'score'} -= $island->{$HrankKind} if(!$island->{'predelete'});
			$ally->{'number'}--;
		} else {
			if(!$HallyMax || $allyNum < $HallyMax) {
				logAlly($id, $target, islandName($island), $ally->{'name'});
				push(@newAllyMember, $id);
				push(@{$island->{'allyId'}}, $ally->{'id'});
				$ally->{'score'} += $island->{$HrankKind} if(!$island->{'predelete'});
				$ally->{'number'}++;
			} else {
				# 화면 출력
				logAllyMaxOver($id, $target, islandName($island), $ally->{'name'});
				return;
			}
		}
		$ally->{'memberId'} = \@newAllyMember;
		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];

	} elsif(($kind == $HcomDeWar) || ($kind == $HcomCeasefire)) {
		# 선전포고·정전
		# 대상 가져오기
		return if(!$HuseDeWar || $HarmisticeTurn || $HsurvivalTurn || $Htournament);
		return 0 if($target == $id);
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);
		# 개발 기간이면 명령 무시
		if (($HislandTurn - $island->{'birthday'} <= $HdevelopTurn) ||
			($HislandTurn - $tIsland->{'birthday'} <= $HdevelopTurn)) {
			logDevelopTurnFail($id, $name, $comName);
			return 0;
		} elsif(!$HforgivenAttack && $tIsland->{'predelete'}) {
			logLandNG($id, $name, $comName, '현재 [관리자 보관] 상태이므로 ');
			return 0;
		} elsif($HnofleetNotAvail) {
			if(!$tIsland->{'ships'}[4]) {
				logLandNG($id, $name, $comName, "함대를 보유하지 않은 $AfterName이기 때문에");
				return 0;
			} elsif(!$island->{'ships'}[4]) {
				logLandNG($id, $name, $comName, "함대를 보유하고 있지 않아서 ");
				return 0;
			}
		}
		$name = "${HtagName_}${name}${H_tagName}";
		$tName = "${HtagName_}${tName}${H_tagName}";
		my($wname) = "$name${HtagDisaster_} VS ${H_tagDisaster}$tName";
		# 우호국
		my(%amityFlag);
		my($amity) = $island->{'amity'};
		foreach (@$amity) {
			$amityFlag{$_} = 1;
		}
		if(chkWarIsland($id, $target)){
			# 정전 교섭
			for($i=0;$i < $#HwarIsland;$i+=4){
				my($id1, $id2) = ($HwarIsland[$i+1], $HwarIsland[$i+2]);
				my($tn1) = $HidToNumber{$id1};
				next if($tn1 eq '');
				my($tn2) = $HidToNumber{$id2};
				next if($tn2 eq '');
				my $turn = $HwarIsland[$i];
				if(($id1 == $id) && ($id2 == $target)){
					# 정전 교섭1(선전포고한측)
					if($kind == $HcomDeWar){
						if($HwarIsland[$i+3] % 10 == 1){
							$HwarIsland[$i+3] = 0;
							logOut("${name}이${tName}에제안했던 정전을 철회하고 전쟁을 계속하겠다고 통보했습니다.",$id, $target);
						} elsif($HwarIsland[$i+3] % 10 == 2){
							$HwarIsland[$i+3] = 0;
							logOut("${name}이${tName}와의 정전 교섭을 폐기하고 전쟁을 계속하겠다고 통보했습니다.",$id, $target);
						}
					} elsif($HwarIsland[$i+3] % 10 == 2){
						# 정전확정
						if($HwarIsland[$i]> $HislandTurn){
							# 전쟁사지난번회피
							logOut("${name}와 ${tName}의 전쟁은 회피되었습니다.",$id, $target);
						} else {
							# 전쟁정전
							if($HceasefireAutoNavyReturn) {
								islandCeasefire($Hislands[$tn1], $id2);
								islandCeasefire($Hislands[$tn2], $id1);
							}
							logOut("${name}와 ${tName}의 정전 합의로<B>턴${turn}</B>부터 계속된 전쟁은 종료되었습니다.",$id, $target);
							logHistory("${HtagName_}${wname}${H_tagName}전쟁(턴 ${turn}~${HislandTurn})은 종료되었습니다.");
						}
						splice(@HwarIsland,$i,4);
					} else {
						# 상대대기치
						$HwarIsland[$i+3] = $HislandTurn * 10 + 1;
						logOut("${name}이${tName}에<b>정전 의사</b>을 타진했습니다.",$id, $target);
					}
					last;
				} elsif(($id1 == $target) && ($id2 == $id)) {
					# 정전 교섭2
					if($kind == $HcomDeWar) {
						if($HwarIsland[$i+3] % 10 == 2){
							$HwarIsland[$i+3] = 0;
							logOut("${name}이${tName}에제안했던 정전을 철회하고 전쟁을 계속하겠다고 통보했습니다.",$id, $target);
						} elsif($HwarIsland[$i+3] % 10 == 1){
							$HwarIsland[$i+3] = 0;
							logOut("${name}이${tName}와의 정전 교섭을 폐기하고 전쟁을 계속하겠다고 통보했습니다.",$id, $target);
						}
					} elsif($HwarIsland[$i+3] % 10 == 1) {
						# 정전확정
						if($HwarIsland[$i]> $HislandTurn){
							# 전쟁사지난번회피
							logOut("${name}와 ${tName}의 전쟁은 회피되었습니다.",$id, $target);
						}else{
							# 전쟁정전
							if($HceasefireAutoNavyReturn) {
								islandCeasefire($Hislands[$tn1], $id2);
								islandCeasefire($Hislands[$tn2], $id1);
							}
							logOut("${name}와 ${tName}의 정전 합의로<B>턴${turn}</B>부터 계속된 전쟁은 종료되었습니다.",$id, $target);
							logHistory("${HtagName_}${wname}${H_tagName}전쟁(턴 ${turn}~${HislandTurn})은 종료되었습니다.");
						}
						splice(@HwarIsland,$i,4);
					} else {
						# 상대대기치
						$HwarIsland[$i+3] = $HislandTurn * 10 + 2;
						logOut("${name}이${tName}에<B>정전 의사</B>을 타진했습니다.",$id, $target);
					}
					last;
				}
			}
		} elsif($kind == $HcomCeasefire) {
			# 정전은 무효
			return 0;
		} else {
			# 선전포고
			if($amityFlag{$target}){
				logOut("${name}에서 $tName 에 대한 ${HtagComName_}$comName${H_tagComName}은, $tName 이<B>우호국이기 때문에</B>, 중지되었습니다.",$id);
				return 0;
			}
			if($HmatchPlay) { # 일대일 모드
				my $oId = chkWarIslandOR($id, $target);
				if($oId) {
					my $oName = islandName($Hislands[$HidToNumber{$oId}]);
					$oName = "${HtagName_}${oName}${H_tagName}";
					$otName = (chkWarIslandOR($id, $id)) ? $name : $tName;
					logOut("${name}에서 $tName 에 대한 ${HtagComName_}$comName${H_tagComName}은, $otName 이 $oName와 <B>교전 중이 아니기 때문에</B>, 중지되었습니다.",$id);
					return 0;
				}
			}
		#	$arg = ($arg < $HdeclareTurn) ? $HislandTurn + $HdeclareTurn : $HislandTurn + $arg;
			$arg = $HislandTurn + $HdeclareTurn;
			push(@HwarIsland, ($arg, $id, $target, 0));
			if($HdeclareTurn> 0) {
				logOut("${name}이${tName}에${HtagDisaster_}선전포고!!${H_tagDisaster}(<B>${arg}턴에 개전</B>)",$id, $target);
			} else {
				my($wname) = "$name${HtagDisaster_} VS ${H_tagDisaster}$tName";
				logOut("${name}이${tName}에${HtagDisaster_}선전포고!!${H_tagDisaster}${wname}전쟁 발발!!",$id, $target);
				logHistory("${wname}전쟁 발발!!");
			}
		}

		$island->{'money'} -= $cost;
		return $HcomTurn[$kind];


	} elsif($kind == $HcomSell) {
		# 수출량 결정
		$arg = 1 if(!$arg);
		my($value) = min($arg * (-$HcomCost[$kind]), $island->{'food'});

		# 수출 로그
		logSell($id, $name, $comName, $value);
		$island->{'food'} -= int($value);
		$island->{'money'} += ($value / 10);
		return $HcomTurn[$kind];

	} elsif($kind == $HcomBuy) {
		# 수입량결정
		$arg = 1 if(!$arg);
		my($value) = min($arg * $HcomCost[$kind], $island->{'money'});
		$value *= 10;

		# 수입 로그
		logBuy($id, $name, $comName, $value);
		$island->{'food'} += $value;
		$island->{'money'} -= int($value / 10);
		return $HcomTurn[$kind];

	} elsif(($kind == $HcomFood) || ($kind == $HcomMoney)) {
		# 지원계

		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);

		my(%amityFlag);
		my($amity) = $island->{'amity'};
		foreach (@$amity) {
			$amityFlag{$_} = 1;
		}
		# 다른 진영에는 지원할 수 없
		if ($HarmisticeTurn && $HcampAidOnly && !$amityFlag{$target}) {
			logAidFail($id, $target, $name, $tName, $comName);
			return 0;
		}
		# 개발 기간이면 명령 무시
		if ($HislandTurn - $island->{'birthday'} <= $HdevelopTurn) {
			logDevelopTurnFail($id, $name, $comName);
			return 0;
		}

		# 무역 능력이 있는 함정이 파견되어 있지 않은 섬에는 지원 명령을 사용할 수 없음
		if ($HtradeAbility) {
			my $tradeFlag = 1;
			my($fkind) = $island->{'fkind'};
			my @flist = @$fkind;
			foreach (@flist) {
				my($eId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack(hex($_));
				my $special = $HnavySpecial[$nKind];
				next if ($special & 0x8); # 군항은 제외
				if(($eId == $target) && ($special & 0x20000)) {
					$tradeFlag = 0;
					last;
				}
			}
			if($tradeFlag) {
				logTradeFail($id, $name, $comName);
				return 0;
			}
		}

		# 지원량 결정
		$arg = 1 if(!$arg);

		my($value, $str);
		if($HcomCost[$kind] < 0) {
			$value = min($arg * (-$HcomCost[$kind]), $island->{'food'});
			$str = "${HtagFood_}$value$HunitFood${H_tagFood}";
		} else {
			$value = min($arg * $HcomCost[$kind], $island->{'money'});
			$str = "${HtagMoney_}$value$HunitMoney${H_tagMoney}";
		}

		# 지원 로그
		logAid($id, $target, $name, $tName, $comName, $str);

		if($HcomCost[$kind] < 0) {
			$island->{'food'} -= $value;
			$tIsland->{'food'} += $value;
			$island->{'ext'}[1] += int($value/10); # 공헌도
			$tIsland->{'ext'}[1] -= int($value/10); # 공헌도
			#$tIsland->{'ext'}[1] = 0 if($tIsland->{'ext'}[1] < 0);
		} else {
			$island->{'money'} -= $value;
			$tIsland->{'money'} += $value;
			$island->{'ext'}[1] += $value; # 공헌도
			$tIsland->{'ext'}[1] -= $value; # 공헌도
			#$tIsland->{'ext'}[1] = 0 if($tIsland->{'ext'}[1] < 0);
		}
		return $HcomTurn[$kind];

	} elsif($kind == $HcomPropaganda) {
		# 이주 홍보
		logPropaganda($id, $name, $comName);
		$island->{'propaganda'} = 1;
		$island->{'money'} -= $cost;

		# 횟수 지정이면, 명령을 되돌림
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg,
				'target2' => $target2
			};
		}
		return $HcomTurn[$kind];

	} elsif($kind == $HcomGiveup) {
		# 포기
		logGiveup($id, $name);
		$island->{'dead'} = 1;
		if($island->{'field'}) {
			$island->{'field'} = 0;
			$HbfieldNumber--;
		}
		return $HcomTurn[$kind];
	}

	return 1;
}

sub moveFleet {
	my($island, $fIsland, $tIsland, $no) = @_;

	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($name) = islandName($island);

	my($fId) = $fIsland->{'id'};
	my($fLand) = $fIsland->{'land'};
	my($fLandValue) = $fIsland->{'landValue'};
	my($fName) = islandName($fIsland);

	my($tId) = $tIsland->{'id'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tName) = islandName($tIsland);
	my(%amityFlag);
	if($HmineSelfDamage) {
		$amityFlag{$tId} = 1;
		if($HmineSelfDamage == 2) {
			foreach (@{$tIsland->{'amity'}}) {
				$amityFlag{$_} = 1;
			}
		}
	}
	# 이벤트발생 섬으로의 파견
	my($kNew, %kindFlag, $eMax);
	if(($id != $tId) && $tIsland->{'event'}[0] && ($tIsland->{'event'}[1] <= $HislandTurn)) {
		$kNew = ($tIsland->{'event'}[4] & (2 ** 0));
		foreach (1..$#HnavyName) {
			$kindFlag{$_} = 1 unless($tIsland->{'event'}[4] & (2 ** $_));
		}
		if($tIsland->{'event'}[3]) {
			$eMax = $tIsland->{'event'}[3] - $island->{"invade$tId"};
		}
	}
	# 함대를 검색
	my(@fleet);
	my($i, $x, $y, $fLv);
	my $fSend = ($fId == $tId) ? '로 이동' : ($id == $tId) ? '에서 귀환' : '로 파견';
	my $fSname = ($fId == $tId) ? $tName : ($id == $tId) ? $fName : $tName;
	foreach $i (0..$fIsland->{'pnum'}) {
		$x = $fIsland->{'rpx'}[$i];
		$y = $fIsland->{'rpy'}[$i];
		$fLv = $fLandValue->[$x][$y];

		# 해군을 탐색
		next unless ($fLand->[$x][$y] == $HlandNavy);

		# 이동 함정까요?
		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($fLv);
		next if (($nId != $id) || ($nNo != $no));

		# 항구이면 무시
		my $nSpecial = $HnavySpecial[$nKind];
		next if ($nSpecial & 0x8);
		# 이벤트발생 섬의 파견 가능 함정판정
		next if ($kindFlag{$nKind} || ($kNew && $nExp));

		# 함정을 기억
		push(@fleet, { x => $x, y => $y });

		# 이벤트발생 섬의 파견 가능 함정 수판정
		last if(--$eMax == 0);
	}

	$i = $#fleet + 1;
	my $ofname = $Hislands[$HidToNumber{$id}]->{'fleet'}->[$no];
	if(($id != $fId) && ($id != $tId)) {
		$no = "${HtagName_}${fName}${H_tagName}에 파견 중인 $ofname 함대";
	} else {
		$no = "$ofname 함대";
	}
	if ($i < 1) {
		# 함대없음
		logNavySendNone($id, $name, $tName, $no, $fSend);
		return 0;
	}

	# 함대 이동
	my $sendshipStr = '';
	my($tx, $ty, $tLv);
	foreach $i (0..$tIsland->{'pnum'}) {
		$tx = $tIsland->{'rpx'}[$i];
		$ty = $tIsland->{'rpy'}[$i];
		$tLv = $tLandValue->[$tx][$ty];

		# 깊은 바다, 기뢰를 탐색
		next unless ( (($tLand->[$tx][$ty] == $HlandSea) && (!$tLv || $HnavyMoveAsase)) ||
						(!$amityFlag{$id} && ($tLand->[$tx][$ty] == $HlandSeaMine)) );

		# 함정의 정보를 가져옴
		($x, $y) = ($fleet[0]->{x}, $fleet[0]->{y});
		$fLv = $fLandValue->[$x][$y];
		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($fLv);
		# 함정을 이동
		if($tLand->[$tx][$ty] == $HlandSeaMine) {
			# 자기 섬의 기뢰 피해를 받을지 여부(안전 확인용)
			next if($amityFlag{$nId});
			# 기뢰이면 내구력감소
			$nHp -= $tLandValue->[$tx][$ty];
			# 로그 출력
			my $nName = landName($fLand->[$x][$y], $fLv);
			if($nHp> 0) {
				logSeaMineDamage($tId, $tName, $nId, "($tx, $ty)", $nName);
			} else {
				logSeaMineDestroy($tId, $tName, $nId, "($tx, $ty)", $nName);
			}
		}

		if($nHp> 0) {
			$tLand->[$tx][$ty] = $fLand->[$x][$y];
			$tLandValue->[$tx][$ty] = navyPack($nId, $nTmp, $nStat, ($tLand->[$tx][$ty] == $HlandSea ? $tLv : 0), $nExp, $nFlag, $nNo, $nKind, $nHp);
		} elsif($nHp == 0) {
			# 잔해가 됨
			$tLand->[$tx][$ty] = $fLand->[$x][$y];
			$tLandValue->[$tx][$ty] = navyPack(0, $nTmp, $nStat, ($tLand->[$tx][$ty] == $HlandSea ? $tLv : 0), int(rand(90)) + 10, 1, 0, $nKind, 0);
			$island->{'shipk'}[$nKind]--;
			$island->{'ships'}[$nNo]--;
			$island->{'ships'}[4]--;
			# 서바이벌
			$island->{'epoint'}{$tId} = $HislandTurn if($tIsland->{'event'}[6] == 1);
		} else {
			# 침몰
			$tLand->[$tx][$ty] = $HlandSea;
			$tLandValue->[$tx][$ty] = 0;
			$island->{'shipk'}[$nKind]--;
			$island->{'ships'}[$nNo]--;
			$island->{'ships'}[4]--;
			# 서바이벌
			$island->{'epoint'}{$tId} = $HislandTurn if($tIsland->{'event'}[6] == 1);

		}
		$fLand->[$x][$y] = $HlandSea;
		$fLandValue->[$x][$y] = $nSea;
		$HlandMove[$fId][$x][$y] = 1;
		$HnavyAttackTarget{"$id,$x,$y"} = undef;

		# 이동 완료로
		$HnavyMove[$tId][$tx][$ty] = 2;
		$island->{'ext'}[8]++;
		$tIsland->{'ext'}[9]++;
		if($HallyNumber) {
			foreach (@{$island->{'allyId'}}) {
				$Hally[$HidToAllyNumber{$_}]->{'ext'}[3]++;
			}
			foreach (@{$tIsland->{'allyId'}}) {
				$Hally[$HidToAllyNumber{$_}]->{'ext'}[4]++;
			}
		}
		# 로그를 출스
		$sendshipStr.= " <B>$HnavyName[$nKind]</B>${HtagName_}($tx, $ty)${H_tagName}";
		shift @fleet;
		last if(!@fleet);
	}
	my $restshipStr = '<BR>--- 남음보류부부대 ⇒ ';
	if(@fleet> 0) {
		my(%restShip);
		foreach (@fleet) {
			# 함정의 정보를 가져옴
			($x, $y) = ($_->{x}, $_->{y});
			$fLv = $fLandValue->[$x][$y];
			my($nKind) = (navyUnpack($fLv))[7];
			$restShip{$nKind}++;
		}
		foreach (keys %restShip) {
			$restshipStr.= " <B>$HnavyName[$_]</B>${HtagName_}($restShip{$_}함)${H_tagName}"
		}
	}
	if($sendshipStr eq '') {
		# 전개에리아없음
		logNavySendNoArea($id, $name, $tName, $no, $fSend, $restshipStr);
	} elsif(@fleet> 0) {
		# 전개에리아부족
		$sendshipStr.= $restshipStr;
		$island->{'epoint'}{$tId} = 0 if($tIsland->{'event'}[0]);
		logNavySendShip($id, $tId, $sendshipStr, substr($fSend, -4));
		logNavySend($id, $fId, $tId, $name, $fSname, $no, $fSend);
	} else {
		# 전개성공
		$island->{'epoint'}{$tId} = 0 if($tIsland->{'event'}[0] && !(defined $island->{'epoint'}{$tId}));
		logNavySendShip($id, $tId, $sendshipStr, substr($fSend, -4));
		logNavySend($id, $fId, $tId, $name, $fSname, $no, $fSend);
	}
	return 1;
}

# 섬포기된 경우의 함대 처리
sub islandDeadNavy {
	my($island) = @_;

	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($name) = islandName($island);

	# 파견 중인 함대가 있는지 조사
	my(%fleet, $i, $n, $x, $y, $lv);
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		$lv = $landValue->[$x][$y];

		if($HautoKeeper) {
			# 괴수와 거대괴수를 바다로
			if(($land->[$x][$y] == $HlandMonster) || ($land->[$x][$y] == $HlandHugeMonster)) {
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
				if ($mFlag & 2) {
					$land->[$x][$y] = $HlandSea;
					$landValue->[$x][$y] = $mSea;
				} else {
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}
				next;
			}
		}

		# 해군을 탐색
		next unless ($land->[$x][$y] == $HlandNavy);

		# 자기 섬의 함정과 무소속의 함정은 무시
		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		$n = $HidToNumber{$nId};
		if ($nId == $id) {
			# 자기 섬의 함정은 무시
			$island->{'stayNavyExp'} += $nExp if($HmatchPlay> 3);
			next;
		} elsif(!(defined $n) || !$nId) {
			# 이미 포기한 섬의 함정과 무소속 함정
			if($HautoKeeper) {
				# 바다로
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = $nSea;
				$HnavyAttackTarget{"$id,$x,$y"} = undef;
			} else {
				# 무시
				next;
			}
			next;
		}

		# 함대 정보를 기억
		$fleet{$n}[$nNo]++;
		$Hislands[$n]->{'sendNavyExp'} += $nExp if($HmatchPlay> 3);
	}

	# 파견됨하고 있는 함대를 귀환하게 함
	foreach $n (keys %fleet) {
		foreach $i (0..3) {
			next unless ($fleet{$n}[$i]);
			moveFleet($Hislands[$n], $island, $Hislands[$n], $i);
		}
	}

	# 우호국해제
	if($HuseAmity && !$HautoKeeper) {
		foreach $i (0..$islandNumber) {
			my @newamity = ();
			foreach (@{$Hislands[$i]->{'amity'}}) {
				next if(($_ eq $id) || !(defined $HidToNumber{$_}));
				push(@newamity, $_);
			}
			$Hislands[$i]->{'amity'} = \@newamity;
		}
	}
	# 교전 상태해제
	if(chkWarIslandOR($id, $id)) {
		for($i=0;$i < $#HwarIsland;$i+=4){
			my($wid1) = $HwarIsland[$i+1];
			my($wid2) = $HwarIsland[$i+2];
			my($tn1) = $HidToNumber{$wid1};
			my($tn2) = $HidToNumber{$wid2};
			if(($wid1 == $id) || ($wid2 == $id) || ($tn1 eq '') || ($tn2 eq '')){
				splice(@HwarIsland,$i,4);
				$i -= 4;
			}
		}
	}
	# 파견 함정·파견괴수의 처리플래그
	$HautoKeepID{$id} = 1 if($HautoKeeper || $island->{'delete'});
	# 동맹 score 처리
	islandDeadAlly($island) if($HallyNumber);
}

# 정전 합의 시의 함대 처리($island에 파견된 $tId 의 함정을 귀환하게 함)
sub islandCeasefire {
	my($island, $tId) = @_;

	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 파견 중인 함대가 있는지 조사
	my(%fleet, $i, $x, $y, $lv);
	my $t = $HidToNumber{$tId};
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		$lv = $landValue->[$x][$y];
		# 해군을 탐색
		next unless ($land->[$x][$y] == $HlandNavy);
		# 자기 섬의 함정과 무소속의 함정은 무시
		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		if ($nId == $id) {
			# 자기 섬의 함정은 무시
			$island->{'stayNavyExp'} += $nExp if($HmatchPlay> 3);
		} elsif($nId == $tId) {
			# 함대 정보를 기억
			$fleet{$nNo}++;
			$Hislands[$t]->{'sendNavyExp'} += $nExp if($HmatchPlay> 3);
		}
	}
	# 파견됨하고 있는 함대를 귀환하게 함
	foreach $i (keys %fleet) {
		moveFleet($Hislands[$t], $island, $Hislands[$t], $i);
	}
}

# 이벤트 시의 함대 확인
sub islandEventNavy {
	my($island, $type) = @_;

	# 기간 안에서  코어 괴멸에 따른 강제 종료 설정이 없을 시, 또는, 코어가 있음
	my($continueflag) = (($island->{'event'}[2] && ($island->{'event'}[1] + $island->{'event'}[2]> $HislandTurn)) && (!$island->{'event'}[23] || $island->{'core'})) ? 1 : 0;
	# 추가 파견이 있는 경우, 기간 안은 판정하지 않음(코어 괴멸에 따른 강제 종료 설정이 없을 시, 또는, 코어가 있을 시)
	return 0 if(!$HeventLog && $island->{'event'}[11] && $continueflag);

	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 파견 중인 함대가 있는지 조사
	my(%epoint, $x, $y, $n, %fleet, $i);
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		my $lv = $landValue->[$x][$y];
		# 해군을 탐색
		next if ($land->[$x][$y] != $HlandNavy);

		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		$n = $HidToNumber{$nId};
		my $special = $HnavySpecial[$nKind];
		# 항구?잔해?이미 포기한 섬의 함정과 무소속 함정
		next if (!(defined $n) || !$nId || ($special & 0x8) || ($nFlag & 1));
		# 함대 정보를 기억
		$fleet{$n}[$nNo]++;
	}
	foreach (keys %fleet) {
		# epoint
		$epoint{$Hislands[$_]->{'id'}} = $Hislands[$_]->{'epoint'}{$id};
	}
	# 승자판정
	my(@winnertmp, @winner, $wno);
	@winnertmp = sort { $epoint{$b} <=> $epoint{$a} } keys %epoint;
	foreach (@winnertmp) {
		next if($Hislands[$HidToNumber{$_}]->{'dead'} || $Hislands[$HidToNumber{$_}]->{'delete'} || $Hislands[$HidToNumber{$_}]->{'predelete'});
		push(@winner, $_);
	}
	$wno = @winner;
	if(!$wno) {
		return -1;
	} elsif(($type == 1) && ($wno != 1)) {
		# 서바이벌
		return 0;
	} elsif(!$HeventLog && ($type != 1) && ($wno != 1) && ($epoint{$winner[0]} == $epoint{$winner[1]})) {
		# 함정 경험치 획득, 함정 격침, 괴수 퇴치, 상금 처리
		return 0 if((!$island->{'event'}[23] || $island->{'core'}));
	}
	# 함정이 있으므로, 기간 안은 판정하지 않음(코어 괴멸에 따른 강제 종료 설정이 없을 시, 또는, 코어가 있을 시)
	my $eventLog = 0;
	if($continueflag |= (($type != 1) && ($wno != 1) && ($epoint{$winner[0]} == $epoint{$winner[1]}))) {
		if(!$HeventLog) {
			return 0;
		} elsif($type != 1) {
			$eventLog = 1;
		}
	}
	if($type == 1) {
		my(%lpoint);
		foreach (0..$islandNumber) {
			next if($Hislands[$_]->{'dead'} || $Hislands[$_]->{'delete'} || $Hislands[$_]->{'predelete'});
			$lpoint{$Hislands[$_]->{'id'}} = $Hislands[$_]->{'epoint'}{$id} if($Hislands[$_]->{'epoint'}{$id});
		}
		$lpoint{$winner[0]} = $HislandTurn + 1;
		my @loser = sort { $lpoint{$b} <=> $lpoint{$a} } keys %lpoint;
		%epoint = %lpoint;
		@winner = @loser;
	}
	my $detail = '';
	my $dcount = ($epoint{$winner[0]} == $epoint{$winner[1]}) ? 1 : 0;
	foreach (0..$#winner) {
		my $lIsland =$Hislands[$HidToNumber{$winner[$_]}];
		my $lName =islandName($lIsland);
		$dcount = $_ + 1 if(($_ < 1) || (!$eventLog && ($_ < 3)) || ($epoint{$winner[$_]} != $epoint{$winner[($_-1)]}));
		if(!$eventLog) {
			if($dcount == 1) {
				$detail.= "<BR>--- <B>우승:</B>";
			} elsif($dcount == 2) {
				$detail.= "<BR>--- <B>준우승:</B>";
			} else {
				$detail.= "<BR>--- <B>제$dcount 위:</B>";
			}
		} else {
			$detail.= "<BR>--- <B>제$dcount 위:</B>";
		}
		$detail.= "${HtagName_}${lName}${H_tagName}";
		if($type == 1) {
			$detail.= "(턴${HtagNumber_}". int($epoint{$winner[$_]})."${H_tagNumber})" if($_);
		} elsif($type == 5) {
			$detail.= '('. int($epoint{$winner[$_]}). $HunitMoney. ')';
		} else {
			$detail.= '('. int($epoint{$winner[$_]}).'점)';
		}
	}
	my $typeName = $HeventName[$island->{'event'}[6]];
	my $name = islandName($island);
	# 기간 안의 로그 출력
	if($eventLog) {
		logOut("${HtagDisaster_}$typeName${H_tagDisaster}(턴${HtagNumber_}$island->{'event'}[1]${H_tagNumber}~:에서·${HtagName_}${name}${H_tagName})<B>경과 보고</B>$detail", $id);
		return 0 if($continueflag);
	}
	my $tIsland = $Hislands[$HidToNumber{$winner[0]}];
	my $tName = islandName($tIsland);
	# 보상
	my $money = $island->{'event'}[7];
	my $food = $island->{'event'}[8];
	my $present = $island->{'event'}[9];
	my @item = split(' *', $island->{'event'}[10]);
	my($prize);
	if($money) {
		$prize = "$money$HunitMoney";
		$tIsland->{'money'} += $money;
		$tIsland->{'prizemoney'} += $money;
	}
	if($food) {
		$prize.= " + " if($money);
		$prize.= "$food$HunitFood";
		$tIsland->{'food'} += $food;
	}
	if($present) {
		$prize.= " + " if($money || $food);
		$prize.= "관리자선물";
	}
	if($island->{'event'}[10]) {
		$prize.= " + " if($money || $food || $present);
		my(%newItem);
		foreach (@{$tIsland->{'item'}}) {
			$newItem{$_} = 1;
		}
		foreach (1..$#HitemName) {
			if($item[$_]) {
				$prize.= "<span class=\"check\"><img src=\"${HimageDir}/$HitemImage[$_]\" title=\"$HitemName[$_]\"></span>";
				$newItem{$_} = 1;
			}
		}
		my @newi = keys %newItem;
		$tIsland->{'item'} = \@newi;
	}
	$prize = '없음' if($prize eq '');
	my($coreless);
	$coreless = "(${HtagDisaster_}$HlandName[$HlandCore][0]괴멸에 한강제종료${H_tagDisaster})" if(($island->{'event'}[2] && ($island->{'event'}[1] + $island->{'event'}[2]> $HislandTurn)) && $island->{'event'}[23] && !$island->{'core'});
	logOut("${HtagName_}${name}${H_tagName}로 턴${HtagNumber_}$island->{'event'}[1]${H_tagNumber}에서개최되어 있었습니다${HtagDisaster_}$typeName${H_tagDisaster}데${HtagName_}${tName}${H_tagName}이<B>승리</B>했습니다!$coreless(보상:<B>$prize</B>)$detail", $id, $winner[0]);

	# 자동귀환 처리
	if($island->{'event'}[18]) {
		foreach $n (keys %fleet) {
			foreach $i (0..3) {
				next unless ($fleet{$n}[$i]);
				moveFleet($Hislands[$n], $island, $Hislands[$n], $i);
			}
		}
	}

	return $winner[0];

}

# 선 줄 처리
sub doPreEachHex {
	my($island) = @_;

	# 도출 값
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 루프
	my($x, $y, $i);
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		my($landKind) = $land->[$x][$y];
		my($lv) = $landValue->[$x][$y];

		if($landKind == $HlandMonster) {
			# 괴수
			moveMonster(0, $island, $x, $y, 1, 0);
		} elsif($landKind == $HlandHugeMonster) {
			# 거대괴수
			my($mHflag) = (monsterUnpack($lv))[1];
			moveMonster(0, $island, $x, $y, 1, 1) if(!$mHflag);
		} elsif ($landKind == $HlandNavy) {
			# 해군
			my($nStat) = (navyUnpack($lv))[2];
			moveNavy(0, $island, $x, $y, 1) if($nStat < 3);
		}
	}
}

# 성장 및 단일 헥스 재해
sub doEachHex {
	my($island) = @_;
	# 도출 값
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 늘어나면인구의 타네 값
	my(@addpop) = @Haddpop;

	if($Htournament && ($HislandTurn <= $HyosenTurn)) { # 토너먼트
		# 연속자금 조달 또는 생산시설 부족이 없는 경우 중단
		@addpop = (0) x @Haddpop if(($island->{'absent'}>= $HstopAddPop) || $island->{'down'});
	} elsif($HsurvivalTurn) { # 서바이벌
		if($HislandTurn <= $HsurvivalTurn){
			@addpop = @HaddpopSD;# 개발 기간
		} else {
			@addpop = @HaddpopSA; # 전투 기간
		}
	}
	if($island->{'food'} < 0) {
		# 식량 부족
		@addpop = @HreductionPop;
	} elsif($island->{'propaganda'} == 1) {
		# 이주 홍보 중
		@addpop = (!$HsurvivalTurn) ? @HaddpopPropa : ($HislandTurn <= $HsurvivalTurn) ? @HaddpopSDpropa : @HaddpopSApropa;
	}

	# 루프
	my($x, $y, $i);
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		my($landKind) = $land->[$x][$y];
		my($lv) = $landValue->[$x][$y];
		if($landKind == $HlandTown) {
			# 마을 계열
			my $rank = 0;
			foreach (reverse(0..$#HlandTownValue)) {
				if($HlandTownValue[$_] <= $lv) {
					$rank = $_;
					last;
				}
			}
			if($addpop[$rank] < 0) {
				# 부족
				$lv -= (random(-$addpop[$rank]) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					next;
				}
			} else {
				# 성장
				next if($HsurvivalTurn && $island->{'absent'});
				if($addpop[$rank]) {
					$lv += random($addpop[$rank]) + 1;
				}
			}
			$lv = $HvalueLandTownMax if($lv> $HvalueLandTownMax);
			$landValue->[$x][$y] = $lv;
		} elsif($landKind == $HlandPlains) {
			# 평지
			next if($HsurvivalTurn && $island->{'absent'});
			my $tflag = ($island->{'field'}) ? 1 : countGrow($island, $x, $y);
			my $rflag = (!$HsurvivalTurn) ? !($HtownGlow>= random(100)) : (($HislandTurn <= $HsurvivalTurn) ? random(3) : random(11));
			if(!$rflag && $tflag) {
				# 주변에 농장, 읍이 있다면, 여기도 마을이 됨
				$land->[$x][$y] = $HlandTown;
				$landValue->[$x][$y] = 1;
			}
		} elsif($landKind == $HlandForest) {
			# 숲
			if($lv < 200) {
			# 나무가 늘어남
				$landValue->[$x][$y] += $HtreeGrow;
			}
		} elsif($landKind == $HlandDefence) {
			if(int($lv / 100)> 0) {
				# 방위 시설 자폭
				my($lName) = &landName($landKind, $lv);

				# 광역 피해 루틴
				wideDamage($id, $name, $island, $x, $y);
				logBombFire($id, $name, $lName, "($x, $y)");
				$island->{'dbase'}--;
			}
		} elsif($landKind == $HlandOil) {
			# 해저 유전
			my($value, $str, $lName);
			$lName = landName($landKind, $lv);
			$value = $HoilMoney;
			if($HoilMoneyMin) {
				$value -= random($HoilMoney - $HoilMoneyMin + 1);
			}
			$island->{'money'} += $value;
			$island->{'oilincome'} += $value;
			$str = "$value$HunitMoney";

			# 수입 로그
			#logOilMoney($id, $name, $lName, "($x, $y)", $str, "수익");

			# 고갈판정
			if(!$HnoDisFlag && random(1000) < $HoilRatio) {
				# 고갈
				logOilEnd($id, $name, $lName, "($x, $y)");
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 0;
			}
		} elsif($landKind == $HlandWaste) {
			# 황무지(BattleField)
			if(!random(3) && $island->{'field'}) {
				if(!$landValue->[$x][$y]) {
					$land->[$x][$y] = $HlandPlains;
				} else {
					$landValue->[$x][$y]--;
				}
			}
		} elsif($landKind == $HlandComplex) {
			# 복합 지형
			my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($lv);
			if($HcomplexTPCmax[$cKind]) {
				# 턴 플래그갱신
				if($cTurn < $HcomplexTPCmax[$cKind]) {
					$cTurn++;
					$landValue->[$x][$y] = landPack($cTmp, $cKind, $cTurn, $cFood, $cMoney);
				}
			}
			my $attr = $HcomplexAttr[$cKind];
			if($attr & 0x1000) {
				# 무작위 수입
				my $value = $HcomplexRinMoney[1] - $HcomplexRinMoney[0] + 1;
				$value = $HcomplexRinMoney[0] + random($value);
				$island->{'rinmoney'}[$cKind] += $value;
				$island->{'money'} += $value;
			}
			if($attr & 0x2000) {
				# 무작위 수확
				my $value = $HcomplexRinFood[1] - $HcomplexRinFood[0] + 1;
				$value = $HcomplexRinFood[0] + random($value);
				$island->{'rinfood'}[$cKind] += $value;
				$island->{'food'} += $value;
			}
			if($attr & 0x10) {
				# 역장
				my($i, $sx, $sy);
				for($i = 1; $i < $an[$HcomplexFieldHex]; $i++) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					# 행 기준 위치 조정
					$sx-- if(!($sy % 2) && ($y % 2));
					$sx = $correctX[$sx + $#an];
					$sy = $correctY[$sy + $#an];
					# 범위 밖
					next if(($sx < 0) || ($sy < 0));
					if($land->[$sx][$sy] == $HlandMonster || $land->[$sx][$sy] == $HlandHugeMonster){
						# 주변 1Hex에 다른 괴수가 있으면 그 괴수를 공격

						# 대상이 되는 괴수각 요소 꺼내기
						my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($landValue->[$sx][$sy]);
						my $mName = ($land->[$sx][$sy] == $HlandMonster) ? $HmonsterName[$mKind] : $HhugeMonsterName[$mKind];

						if(!$mHflag) {
							if($land->[$sx][$sy] == $HlandHugeMonster) {
								my($j, $ssx, $ssy);
								foreach $j (1..6) {
									next if($HhugeMonsterImage[$mKind][$j] eq '');
									$ssx = $sx + $ax[$j];
									$ssy = $sy + $ay[$j];
									# 행 기준 위치 조정
									$ssx-- if(!($ssy % 2) && ($sy % 2));
									$ssx = $correctX[$ssx + $#an];
									$ssy = $correctY[$ssy + $#an];
									# 범위 밖
									next if(($ssx < 0) || ($ssy < 0));

									next unless($land->[$ssx][$ssy] == $HlandHugeMonster);
									# 각 요소 꺼내기
									my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1, 2, 4];
									if ($mFlag2 & 2) {
										# 바다에있었음
										$land->[$ssx][$ssy] = $HlandSea;
										$landValue->[$ssx][$ssy] = $mSea2;
									} else {
										# 육지에있었음
										$land->[$ssx][$ssy] = $HlandWaste;
										$landValue->[$ssx][$ssy] = 0;
									}
									$HlandMove[$id][$ssx][$ssy] = 1;
								}
							}
							logIslpnt($id, $name, "($sx, $sy)", $mId, "의 <B>$mName</B>이 강력한 역장에 눌려 파괴되었습니다.");
						} else {
							logIslpnt($id, $name, "($sx, $sy)", $mId, "의<B>$mName</B>이강력나역장에서 체의 일부를 실패지금했습니다.");
						}
						# 대상의 괴수가 처치됨
						if ($mFlag & 2) {
							# 바다에있었음
							$land->[$sx][$sy] = $HlandSea;
							$landValue->[$sx][$sy] = $mSea;
						} else {
							# 육지에있었음
							$land->[$sx][$sy] = $HlandWaste;
							$landValue->[$sx][$sy] = 0;
						}
						$HlandMove[$id][$sx][$sy] = 1;
					}
				}
			}
		} elsif($landKind == $HlandMonster) {
			# 괴수
			moveMonster(0, $island, $x, $y, 0, 0);
		} elsif($landKind == $HlandHugeMonster) {
			# 거대괴수
			my($mHflag) = (monsterUnpack($lv))[1];
			moveMonster(0, $island, $x, $y, 0, 1) if(!$mHflag);
		} elsif ($landKind == $HlandNavy) {
			# 해군
			my($nStat) = (navyUnpack($lv))[2];
			moveNavy(0, $island, $x, $y, 0) if($nStat < 3);
		}

		# 화재판정
		if((($landKind == $HlandTown) && ($lv> 30)) ||
			(($landKind == $HlandComplex) && ($HcomplexAfter[my $cKind = (landUnpack($lv))[1]]->{'fire'}[0] ne '')) ||
			($landKind == $HlandHaribote) ||
			($landKind == $HlandFactory)) {
			if(!$HnoDisFlag && (random(1000) < $HdisFire * $island->{'itemAbility'}[22])) {
				# 주변의 숲과 기념비를 흡수 가능
				if(!(countAround($island, $x, $y, $an[1], $HlandForest, $HlandMonument)) &&
					!(countAroundComplex($island, $x, $y, $an[1], 0x2))) {
					# 없어진 경우 화재로 괴멸
					logFire($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), "($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					if($landKind == $HlandComplex) {
						# 복합 지형이면 설정 지형
#						my $cKind = (landUnpack($lv))[1];
						$land->[$x][$y] = $HcomplexAfter[$cKind]->{'fire'}[0];
						$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'fire'}[1];
						$island->{'complex'}[$cKind]--;
					}
				}
			}
		}
	}
}

# 괴수의 이동(
# $tId 추가→괴수의 이동에는 사용하지 않음(0에서 요이)
# $pre가 2 이상이면 '이동 조종'(이동 방향$arg = $pre - 2)
# $huge 이1이면거대괴수
sub moveMonster {
	my($tId, $island, $x, $y, $pre, $huge) = @_;
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	my $flagmove = 0;
	my $arg = $pre - 2;
	if($arg < 0) {
		# 괴수의 이동라면$flagmove 을1로
		$flagmove = 1;
	} elsif(!$arg) {
		# 괴수조작에서 대기의 경우
		$HmonsterMove[$id][$x][$y] = 2;
		return 1;
	}

	# 이미 이동했는가?
	return if ($HmonsterMove[$id][$x][$y] == 2);

	# 각 요소 꺼내기
	my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($landValue->[$x][$y]);
	my $mName = landName($land->[$x][$y], $landValue->[$x][$y]);
	my $special = $HmonsterSpecial[$mKind];
	$special = $HhugeMonsterSpecial[$mKind] if($huge);

	if($flagmove) {
		# 괴수의 이동의 경우
		if($pre) {
			# 선 줄 이동
			my $mm = $HidToNumber{$mId};
			if(!($special & 0x10)) {
				# 능력이 없음
				return;
			} elsif(defined $mm) {
				# 능력이 있음소속 섬이 있음
				# 명령 확인(이동 조종을 할지)
				my($mIsland) = $Hislands[$mm];
				my($comArray, $c, $tflag, $ctflag);
				$comArray = $mIsland->{'command'};
				$tflag = 0;
				$ctflag = int($mIsland->{'itemAbility'}[6]);
				for($c = 0; $c < $HcommandMax; $c++) {
					my($ck) = $comArray->[$c]->{'kind'};
					my($ct) = $comArray->[$c]->{'target'};
					my($cx) = $comArray->[$c]->{'x'};
					my($cy) = $comArray->[$c]->{'y'};
					return if(($ck == $HcomMoveTarget) && ($ct == $id) && ($cx == $x) && ($cy == $y));
					$tflag += $HcomTurn[$ck];
					last if($tflag>= $ctflag);
				}
			}
		} elsif($special & 0x10) {
			# 선 줄 이동에서 없는 에능력이 있음
			return;
		}
	} else {
		# 이동 조종의 경우
		return if($mId != $tId); # 자기 섬의 파견괴수?
		return if (!($special & 0x80)); # 능력이 없음
	}

	# 경화상태를 변경
	if (($special & 0x4) && (rand(1) <.50)) { # 50%
		$mFlag ^= 1;
		$landValue->[$x][$y] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
	}

	# 육상에서 경화 중?
	return if (($mFlag & 1) && !($mFlag & 2));

	# 공격 목표를 포착하면 미사일로 공격하는 특수 능력
	if($special & 0x100) {
		require('./hako-mons-attack.cgi');
		# 경화 중이 아니면 공격 대상을 탐색
		searchMonsterTarget($island, $x, $y, $huge) unless($mFlag & 1);
		# 공격예정이 있음?
		my $target = $HmonsterAttackTarget{"$id,$x,$y"};
		if (defined $target) {
			# 공격!
			($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterAttack($island, $x, $y, $target->{x}, $target->{y}, $huge);
			$HmonsterAttackTarget{"$id,$x,$y"} = undef;
		}

		return if (($land->[$x][$y] == $HlandWaste) || ($land->[$x][$y] == $HlandSea));
	}

	my($sx, $sy, $d, $ssx, $ssy, $d2, $dmove, $rebody, @bodyHp);
	# 거대괴수의 코어 이외를 일반 지형으로 되돌림
	if($huge) {
		foreach $i (1..6) {
			next if($HhugeMonsterImage[$mKind][$i] eq '');
			$ssx = $x + $ax[$i];
			$ssy = $y + $ay[$i];
			# 행 기준 위치 조정
			$ssx-- if(!($ssy % 2) && ($y % 2));
			$ssx = $correctX[$ssx + $#an];
			$ssy = $correctY[$ssy + $#an];
			# 범위 밖의 경우
			next if(($ssx < 0) || ($ssy < 0));

			if($land->[$ssx][$ssy] != $HlandHugeMonster) {
				$rebody.= "$i";
				next;
			}
			# 각 요소 꺼내기
			my($mHflag2, $mSea2, $mFlag2, $mHp2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1, 2, 4, 6];
			next if($mHflag2 != $i);
			$bodyHp[$i] = $mHp2;
			if ($mFlag2 & 2) {
				# 바다에있었음
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = $mSea2;
			} else {
				# 육지에있었음
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			}
			$HlandMove[$id][$ssx][$ssy] = 1;
		}
	}
	if(($mHp < 1) && ($special & 0x100)) {
		if ($mFlag & 2) {
			# 바다에있었음
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = $mSea2;
		} else {
			# 육지에있었음
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
		}
		$HlandMove[$id][$x][$y] = 1;
		return 0;
	}

	# 이동 방향을 결정
	my $dnavy = 0;
	if($flagmove) { # 괴수의 이동
		my(@dir);
		if ($special & 0x20) {
			# 유린 이동
			my $kind;
			# 주변을 시야 확인
			# (별로 광이범위를 탐색사없도록 해 주세요. 불필요한서버 부하가 됩니다)
			if ($d = searchTarget(0, $island, $x, $y, $an[3], $HlandHaribote, $HlandDefence, $HlandOil, $HlandSbase, $HlandBase, $HlandFarm, $HlandFactory, $HlandComplex, $HlandTown, $HlandNavy)) { # 3헥스
				# 목표가시야 사용했음
				push(@dir, $d);
			}
		}

		for ($i = $#dir + 1; $i < 3; $i++) {
			push(@dir, random(6) + 1);
		}

		while ($d = shift @dir) {
			$sx = $x + $ax[$d];
			$sy = $y + $ay[$d];
			# 행 기준 위치 조정
			$sx-- if(!($sy % 2) && ($y % 2));
			$sx = $correctX[$sx + $#an];
			$sy = $correctY[$sy + $#an];
			# 범위 밖
			next if(($sx < 0) || ($sy < 0));
			if($HoceanMode) {
				# 미지의 해역으로 이동할 수 없
				next if(!$HlandID[$sx][$sy]);
				if($HlandID[$sx][$sy] != $id) {
					# 설정의 있을 시, 전장이면 임의로 이동것은 같은 섬의 안
					next if($HfieldMonster && $island->{'field'});
					# 설정의 있을 시, 전장에는 포함하지 않음
					next if($HfieldUnconnect && ($Hislands[$HisToNumber{$HlandID[$sx][$sy]}]->{'field'} || $island->{'field'}));
				}
			}
			$dmove = 0;
			if($huge) {
				foreach $i (0..6) {
					next if(($HhugeMonsterImage[$mKind][$i] eq ''));
					$d2 = ($d + 3) % 6;
					$d2 = 6 if($d2 == 0);
					next if($i == $d2);
					$ssx = $sx + $ax[$i];
					$ssy = $sy + $ay[$i];
					# 행 기준 위치 조정
					$ssx-- if(!($ssy % 2) && ($sy % 2));
					$ssx = $correctX[$ssx + $#an];
					$ssy = $correctY[$ssy + $#an];

					# 범위 밖 판정
					if(($ssx < 0) || ($ssy < 0)) {
						$dmove = 1;
						next;
					}
					if($HoceanMode) {
						# 미지의 해역으로 이동할 수 없
						if(!$HlandID[$ssx][$ssy]) {
							$dmove = 1;
							next;
						}
						if($HlandID[$ssx][$ssy] != $id) {
							# 설정의 있을 시, 전장이면 임의로 이동것은 같은 섬의 안
							if($HfieldMonster && $island->{'field'}) {
								$dmove = 1;
								next;
							}
							# 설정의 있을 시, 전장에는 포함하지 않음
							if($HfieldUnconnect && ($Hislands[$HisToNumber{$HlandID[$ssx][$ssy]}]->{'field'} || $island->{'field'})) {
								$dmove = 1;
								next;
							}
						}
					}
					if($land->[$ssx][$ssy] == $HlandNavy) {
						next if((navyUnpack($landValue->[$ssx][$ssy]))[8] < 2);
						$dnavy = 1;
						next;
					}
					# 괴수, 거대괴수, 산, 기념비, 코어이면 이동할 수 없
					if(($land->[$ssx][$ssy] == $HlandMountain) ||
						($land->[$ssx][$ssy] == $HlandMonument) ||
						($land->[$ssx][$ssy] == $HlandCore) ||
						(($land->[$ssx][$ssy] == $HlandComplex) && ($HcomplexAfter[(landUnpack($landValue->[$ssx][$ssy]))[1]]->{'move'}[0] eq '')) ||
						($land->[$ssx][$ssy] == $HlandHugeMonster) ||
						($land->[$ssx][$ssy] == $HlandMonster)) {
						$dmove = 1;
						next;
					}
				}
				next if($dmove);
			} else {
				# 괴수, 거대괴수, 산, 기념비, 코어이면 이동할 수 없
				if(($land->[$sx][$sy] == $HlandMountain) ||
					($land->[$sx][$sy] == $HlandMonument) ||
					($land->[$sx][$sy] == $HlandCore) ||
					(($land->[$sx][$sy] == $HlandComplex) && ($HcomplexAfter[(landUnpack($landValue->[$sx][$sy]))[1]]->{'move'}[0] eq '')) ||
					($land->[$sx][$sy] == $HlandHugeMonster) ||
					($land->[$sx][$sy] == $HlandMonster)) {
					next;
				}
			}

			# 이동할 수 있는 지형
			last;
		}

		# 이동불생겼습니다?
		unless(defined $d) {
			$HmonsterMove[$id][$x][$y] = 2;
			if($huge) {
				$dmove = 1;
			} else {
				return;
			}
		}

	} else { # 괴수조작
		$dmove = 0;
		$arg %= 7;
		$sx = $x + $ax[$arg];
		$sy = $y + $ay[$arg];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];

		# 범위 밖 판정
		if(($sx < 0) || ($sy < 0)) {
			$HmonsterMove[$id][$x][$y] = 2;
			return;
		}
		if($HoceanMode && ($HlandID[$sx][$sy] != $id)) {
			# 자기 섬에서 없는 경우
			my $mn = $HidToNumber{$HlandID[$sx][$sy]};
			my $comName = $HcomName[$HcomMoveTarget];
			my $mflag = 0;
			if(defined $mn) {
				my $tIsland = $Hislands[$mn];
				my(%amityFlag);
				my($amity) = $mIsland->{'amity'};
				foreach (@$amity) {
					$amityFlag{$_} = 1;
				}
				if (
					($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn || $amityFlag{$tIsland->{'id'}})) ||
					($HsurvivalTurn && ($HislandTurn <= $HsurvivalTurn))
					) {
					# 공격이 허가되어 있지 않음
					logNotAvail($mId, $name, $comName);
					$mflag = 1;
				} elsif (($HislandTurn - $nIsland->{'birthday'} <= $HdevelopTurn) ||
					($HislandTurn - $tIsland->{'birthday'} <= $HdevelopTurn)) {
					logDevelopTurnFail($mId, $name, $comName);
					$mflag = 1;
				} elsif(!$HforgivenAttack && $tIsland->{'predelete'}) {
					logLandNG($mId, $name, $comName, '현재 [관리자 보관] 상태이므로 ');
					$mflag = 1;
				} elsif($HfieldUnconnect && $tIsland->{'field'}) {
					logLandNG($mId, $name, $comName, '해역이 접속하지 않음');
					$mflag = 1;

				} elsif($Htournament) {
					if($HislandFightMode < 2) {
						logLandNG($mId, $name, $comName, '현재 개발 기간 중이어서 ');
						$mflag = 1;
					} elsif($mIsland->{'fight_id'} != $tIsland->{'id'}) {
						# 대전 상대가 아닌 경우
						logLandNG($mId, $name, $comName, '목표가 대전 상대가 아니어서 ');
						$mflag = 1;
					}
				} elsif(($HuseDeWar> 1) && !$tIsland->{'field'} && !$HarmisticeTurn && !$HsurvivalTurn) {
					if(!$amityFlag{$tIsland->{'id'}}) {
						my $warflag = chkWarIsland($mId, $tIsland->{'id'});
						if(!$warflag) {
							logLandNG($mId, $name, $comName, '선전포고를 하지 않아서 ');
							$mflag = 1;
						} elsif(($warflag == 1) && ($HuseDeWar == 3)) {
							logLandNG($mId, $name, $comName, '유예 기간 중이어서 ');
							$mflag = 1;
						}
					}
				} elsif($tIsland->{'event'}[0]) {
					my $level = 2 ** gainToLevel($island->{'gain'});
					if(($tIsland->{'event'}[1] - $HnoticeTurn < $HislandTurn) && ($HislandTurn < $tIsland->{'event'}[1])) {
						logLandNG($mId, $name, $comName, '현재 이벤트 준비 기간 중이어서 ');
						$mflag = 1;
					} elsif((!$tIsland->{'event'}[11]) && ($HislandTurn> $tIsland->{'event'}[1])) {
						# 추가 파견을 허가 안 함
						logLandNG($mId, $name, $comName, '이벤트 개최 중이 아니어서 ');
						$mflag = 1;
					}
				}
			} else {
				# 섬이 없는 해역으로는 이동하지 않음
				logLandNG($mId, $name, $comName, '미지의 해역에서 있어서 ');
				$mflag = 1;
			}
			if($mflag == 1) {
				$HmonsterMove[$id][$x][$y] = 2;
				return 0;
			}
		}

		if($huge) {
			foreach $i (0..6) {
				next if(($HhugeMonsterImage[$mKind][$i] eq ''));
				$d2 = ($arg + 3) % 6;
				$d2 = 6 if($d2 == 0);
				next if($i == $d2);
				$ssx = $sx + $ax[$i];
				$ssy = $sy + $ay[$i];
				# 행 기준 위치 조정
				$ssx-- if(!($ssy % 2) && ($sy % 2));
				$ssx = $correctX[$ssx + $#an];
				$ssy = $correctY[$ssy + $#an];

				# 범위 밖 판정
				if(($ssx < 0) || ($ssy < 0)) {
					$dmove = 1;
					last;
				}
				if($HoceanMode) {
					# 미지의 해역으로 이동할 수 없
					if(!$HlandID[$ssx][$ssy]) {
						$dmove = 1;
						last;
					}
					if($HlandID[$ssx][$ssy] != $id) {
						# 설정의 있을 시, 전장이면 임의로 이동것은 같은 섬의 안
						if($HfieldMonster && $island->{'field'}) {
							$dmove = 1;
							last;
						}
						# 설정의 있을 시, 전장에는 포함하지 않음
						if($HfieldUnconnect && ($Hislands[$HisToNumber{$HlandID[$ssx][$ssy]}]->{'field'} || $island->{'field'})) {
							$dmove = 1;
							last;
						}
					}
				}
				if($land->[$ssx][$ssy] == $HlandNavy) {
					next if((navyUnpack($landValue->[$ssx][$ssy]))[8] < 2);
					$dnavy = 1;
					next;
				}
				# 괴수, 거대괴수, 산, 기념비, 코어이면 이동할 수 없
				if(($land->[$ssx][$ssy] == $HlandMountain) ||
					($land->[$ssx][$ssy] == $HlandMonument) ||
					($land->[$ssx][$ssy] == $HlandCore) ||
					(($land->[$ssx][$ssy] == $HlandComplex) && ($HcomplexAfter[(landUnpack($landValue->[$ssx][$ssy]))[1]]->{'move'}[0] eq '')) ||
					($land->[$ssx][$ssy] == $HlandHugeMonster) ||
					($land->[$ssx][$ssy] == $HlandMonster)) {
					$dmove = 1;
					last;
				}
			}
		} else {
			# 괴수, 거대괴수, 산, 기념비, 코어이면 이동할 수 없
			if(($land->[$sx][$sy] == $HlandMountain) ||
				($land->[$sx][$sy] == $HlandMonument) ||
				($land->[$sx][$sy] == $HlandCore) ||
				(($land->[$sx][$sy] == $HlandComplex) && ($HcomplexAfter[(landUnpack($landValue->[$sx][$sy]))[1]]->{'move'}[0] eq '')) ||
				($land->[$sx][$sy] == $HlandHugeMonster) ||
				($land->[$sx][$sy] == $HlandMonster)) {
				$HmonsterMove[$id][$x][$y] = 2;
				return;
			}
		}
	}

	# 이동 대상의 지형에보안 되지
	my($l) = $land->[$sx][$sy];
	my($lv) = $landValue->[$sx][$sy];
	my($lName) = landName($l, $lv);
	my($point) = "($sx, $sy)";

	if ($l == $HlandNavy) {
		# 해군
		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		my $nSpecial = $HnavySpecial[$nKind];
		unless (($nSpecial & 0x8) || ($nFlag & 1)) {
			# 항구도 잔해도 없음
			if ($nHp> 1) {
				# 내구력을 감하게 함
				$landValue->[$sx][$sy] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp - 1);

				logMonsAttackNavy($id, $name, $lName, $point, $mName, $mId);
				$HmonsterMove[$id][$x][$y] = 2;
				if($huge) {
					$dmove = 1;
				} else {
					return 1;
				}
			}
		}
	}

	# 거대괴수가 이동불가능한 경우, 코어이외를 복원
	if($huge && ($dmove || $dnavy)) {
		foreach $i (1..6) {
			next if(($HhugeMonsterImage[$mKind][$i] eq ''));
			$ssx = $x + $ax[$i];
			$ssy = $y + $ay[$i];
			# 행 기준 위치 조정
			$ssx-- if(!($ssy % 2) && ($y % 2));
			$ssx = $correctX[$ssx + $#an];
			$ssy = $correctY[$ssy + $#an];
			# 범위 밖
			next if(($ssx < 0) || ($ssy < 0));
			# 이동할 수 없음 지형이면 복원하지 않음
			next if(((($land->[$ssx][$ssy] == $HlandDefence) && $HdBaseAuto)) ||
				($land->[$ssx][$ssy] == $HlandMountain) ||
				($land->[$ssx][$ssy] == $HlandMonument) ||
				($land->[$ssx][$ssy] == $HlandCore) ||
				(($land->[$ssx][$ssy] == $HlandComplex) && ($HcomplexAfter[(landUnpack($landValue->[$ssx][$ssy]))[1]]->{'move'}[0] eq '')) ||
				($land->[$ssx][$ssy] == $HlandHugeMonster) ||
				($land->[$ssx][$ssy] == $HlandMonster));

			my($mSea2, $mFlag2);
			my $mHp2 = $bodyHp[$i];
			$mHp2 = $mHp if(!$mHp2);

			if ($land->[$ssx][$ssy] == $HlandSea) {
				# 바다
				$mFlag2 |= 2;
				$mSea2 = $landValue->[$ssx][$ssy];
			} elsif (($land->[$ssx][$ssy] == $HlandSbase) || ($land->[$ssx][$ssy] == $HlandOil) || ($land->[$ssx][$ssy] == $HlandBouha) || ($land->[$ssx][$ssy] == $HlandSeaMine)) {
				# 바다의 시설을 파괴
				$mFlag2 |= 2;
				$mSea2 = 0;
				if($l == $HlandBouha) {
					$mSea2 = 1;
					$island->{'bouha'}--;
				}
			} elsif ($land->[$ssx][$ssy] == $HlandNavy) {
				my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($landValue->[$ssx][$ssy]);
				my $nSpecial = $HnavySpecial[$nKind];
				my $n = $HidToNumber{$nId};
				$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
				$mFlag2 |= 2;
				if($nSpecial & 0x8) {
					$mSea2 = 1;
					$Hislands[$n]->{'navyPort'}-- if(defined $n);
				} else {
					$mSea2 = 0;
					if(defined $n) {
						$Hislands[$n]->{'ships'}[$nNo]--;
						$Hislands[$n]->{'ships'}[4]--;
						# 서바이벌
						$Hislands[$n]->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
					}
					$HnavyAttackTarget{"$id,$ssx,$ssy"} = undef;
				}
			} elsif ($land->[$ssx][$ssy] == $HlandComplex) {
				my $cKind = (landUnpack($landValue->[$ssx][$ssy]))[1];
				my $cFlag = $HcomplexAfter[$cKind]->{'move'}[0];
				if($cFlag) { # 바다계
					$mFlag2 |= 2;
					$mSea2 = $HcomplexAfter[$cKind]->{'move'}[1];
				} else { # 육계
					$mFlag2 &= ~2;
					$mSea2 = 0;
				}
				$island->{'complex'}[$cKind]--;
			} elsif ($land->[$ssx][$ssy] == $HlandWaste) {
				# 황무지
				$mFlag2 &= ~2;
				$mSea2 = 0;
			}
			if($rebody =~ /$i/) {
				next if(($special & 0x20000) && (random(100)>= $HpRebody));
				logMonsRebody($id, $name, "($ssx, $ssy)", $mName, $mId);
			}
			$land->[$ssx][$ssy] = $HlandHugeMonster;
			$landValue->[$ssx][$ssy] = monsterPack($mId, $i, $mSea2, $mExp, $mFlag2, $mKind, $mHp2);
#			undef $HlandMove[$id][$ssx][$ssy];
		}
		return if(!$dnavy);
		foreach $i (1..6) {
			next if($HhugeMonsterImage[$mKind][$i] eq '');
			$ssx = $sx + $ax[$i];
			$ssy = $sy + $ay[$i];
			# 행 기준 위치 조정
			$ssx-- if(!($ssy % 2) && ($sy % 2));
			$ssx = $correctX[$ssx + $#an];
			$ssy = $correctY[$ssy + $#an];
			# 범위 밖
			next if(($ssx < 0) || ($ssy < 0));
			next if ($land->[$ssx][$ssy] != $HlandNavy);

			# 이동 대상의 지형에보안 되지
			$lName2 = landName($land->[$ssx][$ssy], $landValue->[$ssx][$ssy]);
			$point2 = "($ssx, $ssy)";

			my($mSea2);
			# 해군
			my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($landValue->[$ssx][$ssy]);
			my $nSpecial = $HnavySpecial[$nKind];
			if ($nHp> 1) {
				# 내구력을 감하게 함
				$landValue->[$ssx][$ssy] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp - 1);
				logMonsAttackNavy($id, $name, $lName2, $point2, $mName, $mId);
			} else {
				my $n = $HidToNumber{$nId};
				$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
				if($nSpecial & 0x8) {
					$mSea2 = 1;
					$Hislands[$n]->{'navyPort'}-- if(defined $n);
				} else {
					$mSea2 = 0;
					if(defined $n) {
						$Hislands[$n]->{'ships'}[$nNo]--;
						$Hislands[$n]->{'ships'}[4]--;
						# 서바이벌
						$Hislands[$n]->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
					}
					$HnavyAttackTarget{"$id,$ssx,$ssy"} = undef;
				}
				logMonsBreakSea($id, $name, $lName2, $point2, $mName, $mId);
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = $mSea2;
			}
		}
		return;
	}

	if ($mFlag & 2) {
		# 바다에있었음
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = $mSea;
	} else {
		# 육지에있었음
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
	}
	$HlandMove[$id][$x][$y] = 1;

	# 이동
	my $dm = ($flagmove ? $d : $arg);
	if ($l == $HlandSea) {
		# 바다를 이동
		$mFlag |= 2;
		$mSea = $lv;
		logMonsMoveSea($id, $name, $lName, $point, $mName, $mId) if($huge == 0);
	} elsif (($l == $HlandSbase) || ($l == $HlandOil) || ($l == $HlandBouha)) {
		# 바다의 시설을 파괴
		$mFlag |= 2;
		$mSea = 0;
		if($l == $HlandBouha) {
			$mSea = 1;
			$island->{'bouha'}--;
		}
		logMonsBreakSea($id, $name, $lName, $point, $mName, $mId);
	} elsif ($l == $HlandNavy) {
		# 해군을 파괴
		$mFlag |= 2;
		my($nId, $nNo, $nKind) = (navyUnpack($lv))[0, 6, 7];
		my $nSpecial = $HnavySpecial[$nKind];
		my $n = $HidToNumber{$nId};
		$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
		if($nSpecial & 0x8) {
			$mSea = 1;
			$Hislands[$n]->{'navyPort'}-- if(defined $n);
		} else {
			$mSea = 0;
			if(defined $n) {
				$Hislands[$n]->{'ships'}[$nNo]--;
				$Hislands[$n]->{'ships'}[4]--;
				# 서바이벌
				$Hislands[$n]->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
			}
			$HnavyAttackTarget{"$id,$sx,$sy"} = undef;
		}
		logMonsBreakSea($id, $name, $lName, $point, $mName, $mId);
	} elsif ($l == $HlandSeaMine) {
		# 기뢰이면 생명력감소
		$mHp -= $landValue->[$sx][$sy];
		$mFlag |= 2;
		$mSea = 0;
		# 로그 출력
		if($mHp < 1) {
			logMonsSeaMineDestroy($id, $name, $lName, $point, $mName, $mId);
		} else {
			logMonsSeaMineDamage($id, $name, $lName, $point, $mName, $mId);
		}
	} elsif($l == $HlandComplex) {
		# 복합 지형이면 설정 지형
		my $cKind = (landUnpack($lv))[1];
		my $cFlag = $HcomplexAfter[$cKind]->{'move'}[0];
		if($cFlag) { # 바다계
			$mFlag |= 2;
			$mSea = $HcomplexAfter[$cKind]->{'move'}[1];
			logMonsBreakSea($id, $name, $lName, $point, $mName, $mId);
		} else { # 육계
			$mFlag &= ~2;
			$mSea = 0;
			logMonsMove($id, $name, $lName, $point, $mName, $mId);
		}
		$island->{'complex'}[$cKind]--;
	} elsif($l == $HlandHugeMonster) {
		($mSea, $mFlag) = (monsterUnpack($lv))[2, 4];
	} else {
		# 육지를 이동
		$mFlag &= ~2;
		$mSea = 0;
		logMonsMove($id, $name, $lName, $point, $mName, $mId) if(!$huge || ($HhugeMonsterImage[$mKind][$dm] eq ''));
	}

	if($mHp < 1) {
		# 이동 시에기뢰에서 살상
		$land->[$sx][$sy] = $HlandSea;
		$landValue->[$sx][$sy] = 0;
		$huge = 0;
		$HlandMove[$id][$sx][$sy] = 1;
	} elsif(!$HdBaseAuto || ($l != $HlandDefence)) {
		$land->[$sx][$sy] = ($huge) ? $HlandHugeMonster : $HlandMonster;
		$landValue->[$sx][$sy] = monsterPack($mId, 0, $mSea, $mExp, $mFlag, $mKind, $mHp);
	}

	my $dflag = 0;
	my($l2, $lv2, $lName2, $point2);
	if($huge && ($mHp> 0)) {
		foreach $i (1..6) {
			next if($HhugeMonsterImage[$mKind][$i] eq '');
			$ssx = $sx + $ax[$i];
			$ssy = $sy + $ay[$i];
			# 행 기준 위치 조정
			$ssx-- if(!($ssy % 2) && ($sy % 2));
			$ssx = $correctX[$ssx + $#an];
			$ssy = $correctY[$ssy + $#an];
			# 범위 밖
			next if(($ssx < 0) || ($ssy < 0));

			# 이동 대상의 지형에보안 되지
			$l2 = $land->[$ssx][$ssy];
			$lv2 = $landValue->[$ssx][$ssy];
			$lName2 = landName($land->[$ssx][$ssy], $landValue->[$ssx][$ssy]);
			$point2 = "($ssx, $ssy)";

			my($mSea2, $mFlag2);
			my $mHp2 = $bodyHp[$i];
			$mHp2 = $mHp if(!$mHp2);
			my $navyFlag = 0;

			if($rebody =~ /$i/) {
				next if(($special & 0x20000) && (random(100)>= $HpRebody));
				logMonsRebody($id, $name, "($ssx, $ssy)", $mName, $mId);
			}
			if ($l2 == $HlandSea) {
				# 바다를 이동
				$mFlag2 |= 2;
				$mSea2 = $lv2;
				logMonsMoveSea($id, $name, $lName2, $point2, $mName, $mId) if($i == $dm);
			} elsif (($l2 == $HlandSbase) || ($l2 == $HlandOil) || ($l2 == $HlandBouha)) {
				# 바다의 시설을 파괴
				$mFlag2 |= 2;
				$mSea2 = 0;
				if($l2 == $HlandBouha) {
					$mSea2 = 1;
					$island->{'bouha'}--;
				}
				logMonsBreakSea($id, $name, $lName2, $point2, $mName, $mId);
			} elsif ($l2 == $HlandNavy) {
				# 해군
				my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv2);
				my $nSpecial = $HnavySpecial[$nKind];
				if ($nHp> 1) {
					# 내구력을 감하게 함
					$navyFlag = 1;
					$landValue->[$ssx][$ssy] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp - 1);
					logMonsAttackNavy($id, $name, $lName2, $point2, $mName, $mId);
				} else {
					$mFlag2 |= 2;
					my $n = $HidToNumber{$nId};
					$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
					if($nSpecial & 0x8) {
						$mSea2 = 1;
						$Hislands[$n]->{'navyPort'}-- if(defined $n);
					} else {
						$mSea2 = 0;
						if(defined $n) {
							$Hislands[$n]->{'ships'}[$nNo]--;
							$Hislands[$n]->{'ships'}[4]--;
							# 서바이벌
							$Hislands[$n]->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
						}
						$HnavyAttackTarget{"$id,$ssx,$ssy"} = undef;
					}
					logMonsBreakSea($id, $name, $lName2, $point2, $mName, $mId);
					# 서바이벌
				}
			} elsif ($l2 == $HlandSeaMine) {
				# 기뢰이면 생명력감소
				$mHp2 -= $lv2;
				$mFlag2 |= 2;
				$mSea2 = 0;
				# 로그 출력
				if($mHp2 < 1) {
					logMonsSeaMineDestroy($id, $name, $lName2, $point2, $mName, $mId);
				} else {
					logMonsSeaMineDamage($id, $name, $lName2, $point2, $mName, $mId);
				}
			} elsif($l2 == $HlandComplex) {
				# 복합 지형이면 설정 지형
				my $cKind = (landUnpack($lv2))[1];
				my $cFlag = $HcomplexAfter[$cKind]->{'move'}[0];
				if($cFlag) { # 바다계
					$mFlag2 |= 2;
					$mSea2 = $HcomplexAfter[$cKind]->{'move'}[1];
					logMonsBreakSea($id, $name, $lName2, $point2, $mName, $mId);
				} else { # 육계
					$mFlag2 &= ~2;
					$mSea2 = 0;
					logMonsMove($id, $name, $lName2, $point2, $mName, $mId);
				}
				$island->{'complex'}[$cKind]--;
#			} elsif($land->[$ssx][$ssy] == $HlandHugeMonster) {
#				($mSea2, $mFlag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[2, 4];
			} elsif (($l2 == $HlandDefence) && $HdBaseAuto) {
				# 방위 시설을 밟습니다
				$dflag = 1;
				last;
			} else {
				# 육지를 이동
				$mFlag2 &= ~2;
				$mSea2 = 0;
				logMonsMove($id, $name, $lName2, $point2, $mName, $mId) if(($l2 != $HlandWaste) || ($i == $dm));
			}
			next if($navyFlag);
			if($mHp2 < 1) {
				# 기뢰에서 체의 일부가 삭제 가능
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = $mSea2;
			} else {
				$land->[$ssx][$ssy] = $HlandHugeMonster;
				$landValue->[$ssx][$ssy] = monsterPack($mId, $i, $mSea2, $mExp, $mFlag2, $mKind, $mHp2);
#				undef $HlandMove[$id][$ssx][$ssy];
			}
		}
	}

	# 이동 완료 플래그
	if ($special & 0x2) {
		# 매우속이괴수
		# 이동 완료 플래그가 설정되어 있지 않음
	} elsif ($special & 0x1) {
		# 속이괴수
		$HmonsterMove[$id][$sx][$sy] = $HmonsterMove[$id][$x][$y] + 1;
	} else {
		# 일반 괴수
		$HmonsterMove[$id][$sx][$sy] = 2;
	}
#	undef $HlandMove[$id][$sx][$sy];

	if ((($l == $HlandDefence) || ($dflag)) && $HdBaseAuto) {
		($lName, $point, $sx, $sy) = ($lName2, $point2, $ssx, $ssy) if($dflag);
		# 방위 시설을 밟습니다
		# 광역 피해 루틴
		wideDamage($id, $name, $island, $sx, $sy);
		logMonsMoveDefence($id, $name, $lName, $point, $mName, $mId);
		$island->{'dbase'}--;
	}
	return 1;
}

# 해군의 보급 처리
sub supplyNavy {
	my($island) = @_;

	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	my $flag;
	my($i, $x, $y, $lv, $hp);
	my(%amityFlag, %repairShip, %failShip);
	my($amity) = $island->{'amity'};
	$amityFlag{$id} = 1;
	if(!$HamityInvalid || !$island->{'field'}) {
		foreach (@$amity) {
			$amityFlag{$_} = 1;
		}
	}
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		$lv = $landValue->[$x][$y];

		# 해군을 탐색
		next unless ($land->[$x][$y] == $HlandNavy);

		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
		my $special = $HnavySpecial[$nKind];
		my $tn = $HidToNumber{$nId};
		if (defined $tn) {
			# 존재하는 섬의 함정이면
			my $tIsland = $Hislands[$tn];
			$flag = 0;
			#자금을 소비하다
			my $mflag = $tIsland->{'itemAbility'}[14];
			my $nMoney = int($HnavyMoney[$nKind] * $mflag); # 유지비
			if ($tIsland->{'money'}>= $nMoney) {
				$tIsland->{'money'} -= $nMoney;
				if($nMoney>= 0) {
					$tIsland->{'upkeepMoney'} += $nMoney;
				} else {
					$tIsland->{'upkeepMoneyPlus'} -= $nMoney;
				}
				$flag |= 1;
			} else {
				$nExp -= 10;
				$nExp = 0 if ($nExp < 0);
			}
			# 식량을 소비하다
			my $fflag = $tIsland->{'itemAbility'}[13];
			my $nFood = int($HnavyFood[$nKind] * $fflag); # 유지 식량
			if ($tIsland->{'food'}>= $nFood) {
				$tIsland->{'food'} -= $nFood;
				if($nFood>= 0) {
					$tIsland->{'upkeepFood'} += $nFood;
				} else {
					$tIsland->{'upkeepFoodPlus'} -= $nFood;
				}
				$flag |= 2;
			} else {
				$nExp -= 10;
				$nExp = 0 if ($nExp < 0);
			}
			my @tAmity = (!$HamityInvalid || !$island->{'field'}) ? @{$tIsland->{'amityBy'}} : ();
			my $sflag = ($tIsland->{'itemAbility'}[1] && (!$HitemInvalid || !$island->{'field'})) ? 1 : 0;
			if ($HnavySupplyFlag || ($amityFlag{$nId} == 1) || $sflag ||
				countAroundNavySpecial($island, $x, $y, 0x10000, $an[$HnavySupplyRange[$nKind]], $nId, @tAmity)) {
				# $HnavySupplyFlag 이0의 시는, 자기 섬 or 우호국의 함대라면 or
				# 주변($HnavySupplyRange 에서 설정)에자기 섬 or 나를 우호국으로 설정한 섬의 보급함(특수 능력)이 있던라

				my $point = "($x, $y)";

				if ($flag == 3) {
					# 충분히 보급 가능

					# 내구력을 회복하다
					$hp = $HnavyMaxHP[$nKind] - $HnavyHP[$nKind];
					$hp = ($HmaxExpNavy> 0) ? $HnavyHP[$nKind] + int($hp * ($nExp / $HmaxExpNavy)) : $HnavyHP[$nKind];
					$hp += $HnavyMaxHpPlus[int((expToLevel($HlandNavy, $nExp) - 1)/2)];
					$hp = 15 if($hp> 15);
					if ($nHp < $hp) {
						# 내구력 +1
						$nHp++;
						$repairShip{$nId}.= " <B>$HnavyName[$nKind]</B>${HtagName_}${point}${H_tagName}";
					}
				} else {
					# 보급불생겼습니다
					$failShip{$nId}.= " <B>$HnavyName[$nKind]</B>${HtagName_}${point}${H_tagName}";
				}
			}
			$landValue->[$x][$y] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
		} else {
			if ($nFlag & 1) {
				# 잔해이면 파괴율 상승
				$nExp += int(rand(10) + 1); # 1%~10%
				if ($nExp>= 100) {
					# 파괴율이 100%가 되면 소멸
					$land->[$x][$y] = $HlandSea;
					$landValue->[$x][$y] = 0;
				} else {
					$landValue->[$x][$y] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
				}
			}
		}

		# 공격 목표를 탐색
		if(!($special & 0x1000000) && !($nFlag & 1) && ($nStat < 2)) {
			# 잔해이외라면
			searchNavyTarget($island, $x, $y);
		}
	}
	# 보급상황
	my @ids;
	foreach (keys %repairShip) {
		push(@ids, $_);
		logNavyShipRepairM($id, $_, $repairShip{$_});
	}
	foreach (keys %failShip) {
		push(@ids, $_);
		logNavyShipSupplyFailM($id, $_, $failShip{$_});
	}
	my $idstr = join('-', @ids);
	logNavyShipRepair($id, $name, $idstr) if($idstr ne '');
}

# 해군의 이동·이동 조종
# $tId 추가→해군의 이동에는 사용하지 않음(0에서 요이)
# $pre가 2 이상이면 '이동 조종'(이동 방향$arg = $pre - 2)
sub moveNavy {
	my($tId, $island, $x, $y, $pre) = @_;
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	my $flagmove = 0;
	my $arg = $pre - 2;
	if($arg < 0) {
		# 해군의 이동라면$flagmove 을1로
		$flagmove = 1;
	} elsif(!$arg) {
		# 이동 조종에서 대기의 경우
		$HnavyMove[$id][$x][$y] = 2;
		return 1;
	}
	# 이미 이동했는가?
	return if ($HnavyMove[$id][$x][$y] == 2);

	# 각 요소 꺼내기
	my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($landValue->[$x][$y]);
	my $nn = $HidToNumber{$nId};
	my($nIsland);
	$nIsland = $Hislands[$nn] if(defined $nn);
	my $nName = landName($land->[$x][$y], $landValue->[$x][$y]);
	my $special = $HnavySpecial[$nKind];

	# 함대 이동(파견·귀환)플래그가타하고 있는 경우, 이동하지 않음
	return if($nIsland->{'NavyMove_flag'}[$nNo]);

	if($flagmove) {
		# 해군의 이동의 경우
		if($pre) {
			# 선 줄 이동
			if(!($special & 0x10)) {
				# 능력이 없음
				return;
			} elsif(defined $nn) {
				# 능력이 있음소속 섬이 있음
				# 명령 확인(이동 조종을 할지)
				my($comArray, $c, $tflag, $ctflag);
				$comArray = $nIsland->{'command'};
				$tflag = 0;
				$ctflag = int($nIsland->{'itemAbility'}[6]);
				for($c = 0; $c < $HcommandMax; $c++) {
					my($ck) = $comArray->[$c]->{'kind'};
					my($ct) = $comArray->[$c]->{'target'};
					my($cx) = $comArray->[$c]->{'x'};
					my($cy) = $comArray->[$c]->{'y'};
					return if(($ck == $HcomMoveTarget) && ($ct == $id) && ($cx == $x) && ($cy == $y));
					$tflag += $HcomTurn[$ck];
					last if($tflag>= $ctflag);
				}
			}
		} elsif($special & 0x10) {
			# 선 줄 이동에서 없는 에능력이 있음
			return;
		}
	} else {
		# 이동 조종의 경우
		return if($nId != $tId); # 자기 섬의 함정?
		return if (!($special & 0x80)); # 능력이 없음
	}

	# 잔해?
	return if ($nFlag & 1);

	# 잠수상태를 변경
	if ($special & 0x4) {
		if (random(100) < $HsubmarineSurface[$nKind]) { # 부상확률:20%
			# 부상
			$nFlag &= ~2;
		} else {
			# 잠수
			$nFlag |= 2;
		}
		$landValue->[$x][$y] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
	}

	# 해저 탐사능력
	if ($special & 0x8000) {
		# 조사 비용 없음!
		if(defined $nn) {
			$nIsland->{'money'} -= ($Hoilp[$nKind] * $HcomCost[$HcomDestroy]);
			$nIsland->{'upkeepMoneyProbe'} += ($Hoilp[$nKind] * $HcomCost[$HcomDestroy]);
		}
		# 침몰판정
		if (random(10000) < $Hoilp[$nKind]) { # 확률0.02%(유전 발견확률의0.1배)
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = $nSea;
			if(defined $nn) {
				$nIsland->{'shipk'}[$nKind]--;
				$nIsland->{'ships'}[$nNo]--;
				$nIsland->{'ships'}[4]--;
				# 서바이벌
				$nIsland->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
			}
			logProbeDestroy($id, $name, $nId, "($x, $y)", $nName);
			if(random(10000) < $Hoilp[$nKind]) { # 확률0.02%(유전 발견확률의0.1배)
				# 마지막에 수수께끼의 함정이 나타났을 시 처리(^^
				$land->[$x][$y] = $HlandNavy;
				$landValue->[$x][$y] = navyPack(0, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
				$HnavyMove[$id][$x][$y] = 2;
				logNavyCome($id, $name, $nName, "($x, $y)", "$nName 이소숨을 절대했음부근");
			}
			$HnavyMove[$id][$x][$y] = 2;
			return;
		}
	}

	# 공격 목표를 탐색(목표보정능력)
	if(($special & 0x1000000) && !$HnavyMoveCount[$id][$x][$y] && !($nFlag & 1) && ($nStat < 2)) {
		# 잔해이외라면
		searchNavyTarget($island, $x, $y);
	}
	# 공격예정이 있음?
	my $target = $HnavyAttackTarget{"$id,$x,$y"};
	if (defined $target) {
		# 공격!
		($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyAttack($island, $x, $y, $target->{x}, $target->{y}, $target->{special});
		$HnavyAttackTarget{"$id,$x,$y"} = undef;
	}

	# 잔해?또는 바다(격침)?
	return if (($nFlag & 1) || ($land->[$x][$y] == $HlandSea));

	# 항구?
	return if ($special & 0x8);

	# 자기 섬의 기뢰 피해를 받을지 여부
	my(%amityFlag);
	if($HmineSelfDamage) {
		$amityFlag{$id} = 1;
		if($HmineSelfDamage == 2) {
			foreach (@{$island->{'amity'}}) {
				$amityFlag{$_} = 1;
			}
		}
	}

	# 함정의 우호국 설정을 확인
	my(%nAmityFlag);
	if($HnavySafetyZone) {
		$nAmityFlag{$nId} = 1;
		if(defined $nn && $HnavySafetyZone == 2) {
			foreach (@{$nIsland->{'amity'}}) {
				$nAmityFlag{$_} = 1;
			}
		}
	}

	my($i, $sx, $sy);
	# 이동 방향을 결정
	if($flagmove) { # 해군의 이동
		my $mvotherisl = 0;
		my(@dir, $d);
		if($HoceanMode && (defined $nn) && (defined $nIsland->{'move'}[$nNo])) {
			my($tx, $ty) = split(/,/, $nIsland->{'move'}[$nNo]);
			# 이동 방향을 계산
			my $dy = ($ty> $y) ? 2 : ($ty < $y) ? 0 : 1;
			if ($tx < $x) {
				$d = (6, 5, 4)[$dy];
				push(@dir, $d);
				if($dy != 1) {
					$d = (6, 5, 4)[1];
					push(@dir, $d);
				}
			} elsif ($tx> $x) {
				$d = (1, 2, 3)[$dy];
				push(@dir, $d);
				if($dy != 1) {
					$d = (1, 2, 3)[1];
					push(@dir, $d);
				}
			} else {
				my $r = rand(1);
				$d = (($r <.5 ? 1 : 6), 0, ($r <.5 ? 3 : 4))[$dy];
				push(@dir, $d);
				if($dy != 1) {
					$d = (($r>=.5 ? 1 : 6), 0, ($r>=.5 ? 3 : 4))[$dy];
					push(@dir, $d);
				}
			}
			$mvotherisl = 1 if(@dir);
		} elsif ($special & 0x800) {
			# 유린 이동(자신이 소속한 함대의 기함을 목표하고 이동)
			# 주변을 시야 확인
			if ($d = searchTarget($id, $island, $x, $y, $an[$HnavyTowardRange[$nKind]], $HlandNavy)) {
				# 기함이시야 사용했음
				push(@dir, $d);
			}
		}
		for ($i = $#dir; $i < 3; $i++) {
			push(@dir, random(6) + 1);
		}

		$mvotherisl = (!(defined $nn)); # 소속 불명은 자유 이동
		while ($d = shift @dir) {
			$sx = $x + $ax[$d];
			$sy = $y + $ay[$d];
			# 행 기준 위치 조정
			$sx-- if(!($sy % 2) && ($y % 2));
			$sx = $correctX[$sx + $#an];
			$sy = $correctY[$sy + $#an];
			# 범위 밖
			next if(($sx < 0) || ($sy < 0));
			if($HoceanMode) {
				# 미지의 해역으로 이동할 수 없
				next if(!$HlandID[$sx][$sy]);
				if($HlandID[$sx][$sy] != $id) {
					# 이동 지령이 없거나 소속 불명이 아니면 임의 이동은 같은 섬 안에서만 수행
					next if(!$mvotherisl);
					# 설정의 있을 시, 전장이면 임의로 이동것은 같은 섬의 안
					next if($HfieldNavy && $island->{'field'});
					# 설정의 있을 시, 전장에는 포함하지 않음
					next if($HfieldUnconnect && ($Hislands[$HisToNumber{$HlandID[$sx][$sy]}]->{'field'} || $island->{'field'}));
				}
			}
			my($l) = $land->[$sx][$sy];
			my($lv) = $landValue->[$sx][$sy];
			# 깊은 바다, 기뢰외이면 이동할 수 없
			my($tId, $tTmp, $tStat, $tSea, $tExp, $tFlag, $tNo, $tKind, $tHp) = navyUnpack($lv) if($l == $HlandNavy);
			# unless 의안에 이동할 수 있는 지형을 기술
			next unless (
				(($l == $HlandSea) && (!$lv || $HnavyMoveAsase)) || # 바다
				(($l == $HlandSeaMine) && !$amityFlag{$nId}) || # 기뢰
				(($l == $HlandNavy) && # 해군에서
					(($HsuicideAbility || !$nId) && ($special & 0x2000000) && !$nAmityFlag{$tId}) # 몸통박치기
				) ||
				(($l == $HlandWaste) && ($special & 0x80000)) # 굴착
			);

			# 이동할 수 있는 지형
			last;
		}

		# 이동불생겼습니다?
		return unless (defined $d);

	} else { # 이동 조종
		$arg %= 7;
		$sx = $x + $ax[$arg];
		$sy = $y + $ay[$arg];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];

		# 범위 밖 판정
		if(($sx < 0) || ($sy < 0)) {
			$HnavyMove[$id][$x][$y] = 2;
			return;
		}
		if($HoceanMode && ($HlandID[$sx][$sy] != $id)) {
			# 자기 섬에서 없는 경우
			my $mn = $HidToNumber{$HlandID[$sx][$sy]};
			my $comName = $HcomName[$HcomMoveTarget];
			my $mflag = 0;
			if(defined $mn) {
				my $tIsland = $Hislands[$mn];
				if (
					($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn)) ||
					($HsurvivalTurn && ($HislandTurn <= $HsurvivalTurn))
					) {
					# 공격이 허가되어 있지 않음
					logNotAvail($nId, $name, $comName);
					$mflag = 1;
				} elsif (($HislandTurn - $nIsland->{'birthday'} <= $HdevelopTurn) ||
					($HislandTurn - $tIsland->{'birthday'} <= $HdevelopTurn)) {
					logDevelopTurnFail($nId, $name, $comName);
					$mflag = 1;
				} elsif(!$HforgivenAttack && $tIsland->{'predelete'}) {
					logLandNG($nId, $name, $comName, '현재 [관리자 보관] 상태이므로 ');
					$mflag = 1;
				} elsif($HfieldUnconnect && $tIsland->{'field'}) {
					logLandNG($nId, $name, $comName, '해역이 접속하지 않음');
					$mflag = 1;
				} elsif($HnofleetNotAvail && !$tIsland->{'field'} && !$tIsland->{'ships'}[4]) {
					logLandNG($nId, $name, $comName, "함대를 보유하지 않은 $AfterName이기 때문에");
					$mflag = 1;
				} elsif($Htournament) {
					if($HislandFightMode < 2) {
						logLandNG($nId, $name, $comName, '현재 개발 기간 중이어서 ');
						$mflag = 1;
					} elsif($nIsland->{'fight_id'} != $tIsland->{'id'}) {
						# 대전 상대가 아닌 경우
						logLandNG($nId, $name, $comName, '목표가 대전 상대가 아니어서 ');
						$mflag = 1;
					}
				} elsif(($HuseDeWar> 1) && !$tIsland->{'field'} && !$HarmisticeTurn && !$HsurvivalTurn) {
					my(%amityFlag);
					my($amity) = $nIsland->{'amity'};
					foreach (@$amity) {
						$amityFlag{$_} = 1;
					}
					if(!$amityFlag{$tIsland->{'id'}}) {
						my $warflag = chkWarIsland($nId, $tIsland->{'id'});
						if(!$warflag) {
							logLandNG($nId, $name, $comName, '선전포고를 하지 않아서 ');
							$mflag = 1;
						} elsif(($warflag == 1) && ($HuseDeWar == 3)) {
							logLandNG($nId, $name, $comName, '유예 기간 중이어서 ');
							$mflag = 1;
						}
					}
				} elsif($tIsland->{'event'}[0]) {
					my $level = 2 ** gainToLevel($island->{'gain'});
					if(($tIsland->{'event'}[1] - $HnoticeTurn < $HislandTurn) && ($HislandTurn < $tIsland->{'event'}[1])) {
						logLandNG($nId, $name, $comName, '현재 이벤트 준비 기간 중이어서 ');
						$mflag = 1;
					} elsif($tIsland->{'event'}[3] && ($tIsland->{'event'}[3] <= $nIsland->{"invade$tIsland->{'id'}"})) {
						logLandNG($nId, $name, $comName, '파견 가능한 함정 수를 초과했기 때문에');
						$mflag = 1;
					} elsif($HmaxComNavyLevel && !($tIsland->{'event'}[5] & (2 ** gainToLevel($nIsland->{'gain'})))) {
						logLandNG($nId, $name, $comName, '파견 가능한 레벨이 아니어서 ');
						$mflag = 1;
					} elsif((!$tIsland->{'event'}[11]) && ($HislandTurn> $tIsland->{'event'}[1])) {
						# 추가 파견을 허가 안 함
						logLandNG($nId, $name, $comName, '이벤트 개최 중이 아니어서 ');
						$mflag = 1;
					}
				} elsif($nIsland->{'NavyAttack_flag'}[$nNo]) {
					# 명령을 허가 안 함
					logLandNG($nId, $name, $comName, '전투상태에있어서 ');
					$mflag = 1;
				}
			} else {
				# 섬이 없는 해역으로는 이동하지 않음
				logLandNG($nId, $name, $comName, '미지의 해역에서 있어서 ');
				$mflag = 1;
			}
			if($mflag == 1) {
				$HnavyMove[$id][$x][$y] = 2;
				return 0;
			}
		}

		my($l) = $land->[$sx][$sy];
		my($lv) = $landValue->[$sx][$sy];
		my($tId, $tTmp, $tStat, $tSea, $tExp, $tFlag, $tNo, $tKind, $tHp) = navyUnpack($lv) if($l == $HlandNavy);
		# unless 의안에 이동할 수 있는 지형을 기술
		unless (
			(($l == $HlandSea) && (!$lv || $HnavyMoveAsase)) || # 바다
			(($l == $HlandSeaMine) && !$amityFlag{$nId}) || # 기뢰
			(($l == $HlandNavy) && # 해군에서
				(($special & 0x2000000) && !$nAmityFlag{$tId}) # 몸통박치기
			) ||
			(($l == $HlandWaste) && ($special & 0x80000)) # 굴착
		) {
			$HnavyMove[$id][$x][$y] = 2;
			return;
		}

		# 이동 대상의 지형에보안 되지(이동 조종 시)
		my($lName) = landName($l, $lv);
		my($point) = "($sx, $sy)";
		logNavyMoveSea($id, $name, $lName, $point, $nName, $nId) if($land->[$sx][$sy] != $HlandWaste && $land->[$sx][$sy] != $HlandNavy);
	}

	if($land->[$sx][$sy] == $HlandWaste) {
		logNavyMoveDestroy($id, $name, landName($land->[$sx][$sy], $landValue->[$sx][$sy]), "($sx, $sy)", $nName, $nId, $landValue->[$sx][$sy]);
		if(!$landValue->[$sx][$sy]) {
			# 이동하지 않음
			$landValue->[$sx][$sy] = 1;
			$HnavyMove[$id][$x][$y] = 2;
			return 1;
		}
		$HnavyMove[$id][$sx][$sy] = 2;
	} elsif($land->[$sx][$sy] == $HlandNavy) {
		my($tId, $tTmp, $tStat, $tSea, $tExp, $tFlag, $tNo, $tKind, $tHp) = navyUnpack($landValue->[$sx][$sy]);
		logNavyMoveAttack($id, $name, $nId, "($x, $y)", $nName, $tId, "($sx, $sy)", landName($land->[$sx][$sy], $landValue->[$sx][$sy]));
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = $nSea;
		$land->[$sx][$sy] = $HlandSea;
		$landValue->[$sx][$sy] = $tSea;
		$HnavyAttackTarget{"$id,$sx,$sy"} = undef;
		$HnavyMove[$id][$x][$y] = 2;
		$HnavyMove[$id][$sx][$sy] = 2;
		return 1;
	}
	# 이동 대상의 지형에보안 되지
#	my($l)	 = $land->[$sx][$sy];
#	my($lv)	= $landValue->[$sx][$sy];
#	my($lName) = landName($l, $lv);
#	my($point) = "($sx, $sy)";

	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = $nSea;
	$HlandMove[$id][$x][$y] = 1;
	# 이동
# 이동 로그는 답답함도하므로 코멘트에했습니다
#	logNavyMoveSea($id, $name, $lName, $point, $nName, $nId);

	# 해저 탐사능력
	if ($special & 0x8000) {
		my(@x, @y);
		if($HedgeReclaim) {
			my($map) = $island->{'map'};
			@x = @{$map->{'x'}};
			@y = @{$map->{'y'}};
		}
		if (random(1000) < $Hoilp[$nKind]) { # 확률0.2%
			# 유전 발견!
			$land->[$x][$y] = $HlandOil;
			$landValue->[$x][$y] = 0;
			my $str = $Hoilp[$nKind] * $HcomCost[$HcomDestroy];
			logOilFound($id, $name, "($x, $y)", "해저 탐사", "$str$HunitMoney");
		} elsif(random(2000) < $Hoilp[$nKind]) { # 확률0.1%(유전 발견확률의0.5배)
			# 보물 발견!
			my $value = ($Hoilp[$nKind] * $HcomCost[$HcomDestroy]); # 원래금보증(^^
			$value += random(10 * $Hoilp[$nKind] * $HcomCost[$HcomDestroy]); # 운영명의 루레와(^인^)
			if(defined $nn) {
				$nIsland->{'money'} += $value ;
				logTansaku($id, $name, $nId, $nName, "($x, $y)", "$value$HunitMoney");
			}
		} elsif((random(4000) < $Hoilp[$nKind]) && (!$HedgeReclaim ||
			($HedgeReclaim && !(($x < $HedgeReclaim) || ($x> $x[$#x] - $HedgeReclaim) || ($y < $HedgeReclaim) || ($y> $y[$#y] - $HedgeReclaim))) # 섬의 가장 바깥쪽을 매립 불가로 설정한 경우
			)) { # 확률0.05%(유전 발견확률의0.25배)
			# 해저불 산분화
			my($landKind, $lv, $point);
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			$point = "($x, $y)";
			$land->[$x][$y] = $HlandMountain;
			$landValue->[$x][$y] = 0;
			if(defined $nn) {
				$nIsland->{'shipk'}[$nKind]--;
				$nIsland->{'ships'}[$nNo]--;
				$nIsland->{'ships'}[4]--;
				# 서바이벌
				$nIsland->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
			}

			foreach $i (1..6) {
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];
				# 행 기준 위치 조정
				$sx-- if(!($sy % 2) && ($y % 2));
				$sx = $correctX[$sx + $#an];
				$sy = $correctY[$sy + $#an];
				# 범위 밖
				next if(($sx < 0) || ($sy < 0));

				# 범위 안의 경우
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandSea) || ($landKind == $HlandOil)) {
					# 바다, 유전의 경우
					if(!$lv || ($HedgeReclaim && (($sx < $HedgeReclaim) || ($sx> $x[$#x] - $HedgeReclaim) || ($sy < $HedgeReclaim) || ($sy> $y[$#y] - $HedgeReclaim)))) {
						logEruptionSea($id, $name, landName($landKind, $lv), $point);
						$land->[$sx][$sy] = $HlandSea;
						$landValue->[$sx][$sy] = 1;
						next;
					} else {
						# 얕은 바다
						logEruptionSea1($id, $name, landName($landKind, $lv), $point);
					}
				} elsif(($landKind == $HlandSeaMine) || ($landKind == $HlandSbase) ||
					(($landKind == $HlandCore) && (int($lv / 10000) == 2))) {
					# 기뢰, 바다 기준, 해저코어의 경우
					logEruptionSea($id, $name, landName($landKind, $lv), $point);
					$land->[$sx][$sy] = $HlandSea;
					$landValue->[$sx][$sy] = 1;
					next;
				} elsif(($landKind == $HlandMountain) || ($landKind == $HlandWaste)) {
					next;
				} elsif($landKind == $HlandComplex) {
					# 복합 지형이면 설정 지형
					my $cKind = (landUnpack($lv))[1];
					next if($HcomplexAfter[$cKind]->{'eruption'}[0] eq '');
					$land->[$sx][$sy] = $HcomplexAfter[$cKind]->{'eruption'}[0];
					$landValue->[$sx][$sy] = $HcomplexAfter[$cKind]->{'eruption'}[1];
					$island->{'complex'}[$cKind]--;
					logEruptionNormal($id, $name, landName($landKind, $lv), $point);
					next;
				} elsif(($landKind == $HlandMonster) || ($landKind == $HlandHugeMonster)) {
					my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
					if((($mFlag & 2) && !$mSea) || ($HedgeReclaim && (($sx < $HedgeReclaim) || ($sx> $x[$#x] - $HedgeReclaim) || ($sy < $HedgeReclaim) || ($sy> $y[$#y] - $HedgeReclaim)))) {
						logEruptionSea3($id, $name, landName($landKind, $lv), $point);
						$mSea = 1;
					} else {
						logEruptionSea2($id, $name, landName($landKind, $lv), $point);
						$mFlag &= ~2;
						$mSea = 0;
					}
					$landValue->[$sx][$sy] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
					next;
				} elsif($landKind == $HlandNavy) {
					my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
					my $nSpecial = $HnavySpecial[$nKind];
					my $n = $HidToNumber{$nId};
					$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
					if ($nSpecial & 0x8) {
						# 항구는 육지
						logEruptionSea1($id, $name, landName($landKind, $lv), $point);
						$land->[$sx][$sy] = $HlandWaste;
						$landValue->[$sx][$sy] = 0;
						$Hislands[$n]->{'navyPort'}-- if(defined $n);
					} else {
						if(!$nSea || ($HedgeReclaim && (($sx < $HedgeReclaim) || ($sx> $x[$#x] - $HedgeReclaim) || ($sy < $HedgeReclaim) || ($sy> $y[$#y] - $HedgeReclaim)))) {
							# 기타는 얕은 바다
							logEruptionSea($id, $name, landName($landKind, $lv), $point);
							$land->[$sx][$sy] = $HlandSea;
							$landValue->[$sx][$sy] = 1;
						} else {
							# 얕은 바다는 육지
							logEruptionSea1($id, $name, landName($landKind, $lv), $point);
							$land->[$sx][$sy] = $HlandWaste;
							$landValue->[$sx][$sy] = 0;
						}
						if(defined $n) {
							$Hislands[$n]->{'ships'}[$nNo]--;
							$Hislands[$n]->{'ships'}[4]--;
						}
						$HnavyAttackTarget{"$id,$sx,$sy"} = undef;
					}
					next;
				} else {
					# 그 외의 경우
					logEruptionNormal($id, $name, landName($landKind, $lv), $point);
				}
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
			}
			logEruption($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), "($x, $y)");
			$HnavyMove[$id][$x][$y] = 2;
			return;
		}
	}

	if($land->[$sx][$sy] == $HlandSeaMine) {
	# 기뢰이면 내구력감소
		$nHp -= $landValue->[$sx][$sy];
		# 로그 출력
		if($nHp> 0) {
			logSeaMineDamage($id, $name, $nId, "($sx, $sy)", $nName);
#		} elsif($nHp == 0) {
#			logSeaMineDestroy($id, $name, $nId, "($sx, $sy)", $nName);
		} else {
			logSeaMineDestroy($id, $name, $nId, "($sx, $sy)", $nName);
		}
	} elsif($land->[$sx][$sy] == $HlandSea) {
		$nSea = $landValue->[$sx][$sy];
	} elsif($land->[$sx][$sy] == $HlandWaste) {
		$nSea = 1;
	}

	if($nHp> 0) {
		# 해적 능력
		if ((defined $nn) && ($special & 0x40000) && ($id != $nId)) {
			my($i, $j, $ssx, $ssy);
			my $nPoint = "($sx, $sy)";
			for($j = 0; $j < $HpiratesHex[$nKind]; $j++) {
				for($i = $an[$j]; $i < $an[$j+1]; $i++) {
					$ssx = $sx + $ax[$i];
					$ssy = $sy + $ay[$i];
					# 행 기준 위치 조정
					$ssx-- if(!($ssy % 2) && ($sy % 2));
					$ssx = $correctX[$ssx + $#an];
					$ssy = $correctY[$ssy + $#an];
					# 범위 밖
					next if(($ssx < 0) || ($ssy < 0));

					my($landKind, $lv, $point, $value);
					$landKind = $land->[$ssx][$ssy];
					$lv = $landValue->[$ssx][$ssy];
					$point = "($ssx, $ssy)";

					# 범위 안의 경우
					if($landKind == $HlandFarm) {
						$value = int($lv * 10 / 2); # 규것절반의 식량
						next if(random(100)>= 50 - ($j * 20)); # 1Hex 내50%,2Hex30%,3Hex10%
						$nIsland->{'food'} += $value;
						$island->{'food'} -= $value;
						logPirates($id, $name, $point, $nId, $nName, $nPoint, "${HtagFood_}$value$HunitFood${H_tagFood}");
					} elsif($landKind == $HlandFactory) {
						$value = int($lv / 2); # 규것절반의자금
						next if(random(100)>= 50 - ($j * 20)); # 1Hex 내50%,2Hex30%,3Hex10%
						$nIsland->{'money'} += $value;
						$island->{'money'} -= $value;
						logPirates($id, $name, $point, $nId, $nName, $nPoint, "${HtagMoney_}$value$HunitMoney${H_tagMoney}");
					} elsif($landKind == $HlandComplex) {
						my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($lv);
						if($cFood && (random(100)>= 50 - ($j * 20))) { # 1Hex 내50%,2Hex30%,3Hex10%
							my $food = $HcomplexFPplus[$cKind] * $cFood + $HcomplexFPbase[$cKind];
							$food = int($food / 2); # 규것절반의 식량
							$nIsland->{'food'} += $food;
							$island->{'food'} -= $food;
							logPirates($id, $name, $point, $nId, $nName, $nPoint, "${HtagFood_}$food$HunitFood${H_tagFood}");
						} elsif($cMoney && (random(100)>= 50 - ($j * 20))) { # 1Hex 내50%,2Hex30%,3Hex10%
							my $money = $HcomplexMPplus[$cKind] * $cMoney + $HcomplexMPbase[$cKind];
							$money = int($money / 2); # 규것절반의자금
							$nIsland->{'money'} += $money;
							$island->{'money'} -= $money;
							logPirates($id, $name, $point, $nId, $nName, $nPoint, "${HtagMoney_}$money$HunitMoney${H_tagMoney}");
						}
					}
				}
			}
		}
		$land->[$sx][$sy] = $HlandNavy;
		$landValue->[$sx][$sy] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
	} elsif($nHp == 0) {
	# 잔해가 됨
		$land->[$sx][$sy] = $HlandNavy;
		$landValue->[$sx][$sy] = navyPack(0, $nTmp, $nStat, $nSea, int(rand(90)) + 10, 1, 0, $nKind, 0);
		if(defined $nn) {
			$nIsland->{'shipk'}[$nKind]--;
			$nIsland->{'ships'}[$nNo]--;
			$nIsland->{'ships'}[4]--;
		}
	} else {
	# 침몰
		$land->[$sx][$sy] = $HlandSea;
		$landValue->[$sx][$sy] = $nSea;
		$HlandMove[$id][$sx][$sy] = 1;
		$HnavyAttackTarget{"$id,$sx,$sy"} = undef;
		if(defined $nn) {
			$nIsland->{'shipk'}[$nKind]--;
			$nIsland->{'ships'}[$nNo]--;
			$nIsland->{'ships'}[4]--;
			# 서바이벌
			$nIsland->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
		}
	}

	# 이동 완료 플래그
	if ($special & 0x2) {
		# 매우속이 이동
		# 이동 완료 플래그가 설정되어 있지 않음
	} elsif ($special & 0x1) {
		# 속이 이동
		$HnavyMove[$id][$sx][$sy] = $HnavyMove[$id][$x][$y] + 1;
	} else {
		# 일반 이동
		$HnavyMove[$id][$sx][$sy] = 2;
	}
	$HnavyMoveCount[$id][$sx][$sy] = 1;
#	undef $HlandMove[$id][$sx][$sy];
	return 1;
}

# 가장 가까운 목표 지형의 방향을 계산
sub searchTarget {
	my($id, $island, $x, $y, $range, @kind) = @_;

	# 범위 안의 목표 지형을 탐색
	my($land, $landValue) = ($island->{'land'}, $island->{'landValue'});
	my($tx, $ty) = ($x, $y);
	my($i, $sx, $sy, %kflag);
	foreach (@kind) {
		$kflag{$_} = 1;
	}
	my $rn = $range - 1;
	foreach $i (0..$rn) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖
		next if(($sx < 0) || ($sy < 0));

		# 범위 안의 경우
		if ($kflag{$land->[$sx][$sy]}) {
			if($id != 0){
				# 각 요소 꺼내기
				my($nId, $nNo, $nKind) = (navyUnpack($landValue->[$x][$y]))[0, 6, 7];
				my $special = $HnavySpecial[$nKind];

				# 자기 섬의 함정?
				next if($nId != $id);

				# 기함이 아님?
				next if(!($special & 0x80));
			}
			$tx = $sx;
			$ty = $sy;
			last;
		}
	}

	# 이동 방향을 계산
	my $dy = ($ty> $y) ? 2 : ($ty < $y) ? 0 : 1;

	if ($tx < $x) {
		return (6, 5, 4)[$dy];
	} elsif ($tx> $x) {
		return (1, 2, 3)[$dy];
	} else {
		return ((rand(1) <.5 ? 1 : 6), 0, (rand(1) <.5 ? 3 : 4))[$dy];
	}
}

# 해군 공격 목표를 탐색
sub searchNavyTarget {
	my($island, $x, $y) = @_;

	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($lv) = $landValue->[$x][$y];

	my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
	my $nNum = $HidToNumber{$nId};
	my($nIsland, $n, $targetMission, %mission);
	if(defined $nNum) {
		$nIsland = $Hislands[$nNum];
		# 일제 공격준비
		my($comArray) = $nIsland->{'command'};
		my($cflag) = 0;
		my($p) = 1;
		for($n = 0; $n < $HcommandMax; $n++) {
			my($command) = $comArray->[$n];
#HdebugOut("[for] ($command->{'kind'} == $HcomNavyTarget) && ($command->{'target'} == $id)\n");
			if(($command->{'kind'} == $HcomNavyTarget) && ($command->{'target'} == $id)) {
				$mission{"$command->{'x'},$command->{'y'}"} = $p;
#HdebugOut("[if] mission,$id,$command->{'x'},$command->{'y'}\n");
			}
			last if($HcomTurn[$command->{'kind'}]);
			$p++;
		}
	}
	my(%amityFlag);
	$amityFlag{$nId} = 1;
	my $nSpecial = $HnavySpecial[$nKind];
	my $rflag = ((defined $nNum) && (!$HitemInvalid || !$island->{'field'})) ? $nIsland->{'itemAbility'}[4] : 0;
	$rflag += $HnavyFireBF[2] if($island->{'field'});
	my $tmp = $HnavyFireRange[$nKind] + $rflag;
	$tmp = ($tmp> 8) ? 8 : ($tmp <= 0) ? 1 : int($tmp);
	my $range = $an[$tmp];
	my @HmyPriority = @Hpriority;
	my($amity, $mypri);
	if(defined $nNum) {
		if(!$HamityInvalid || !$island->{'field'}) {
			$amity = $Hislands[$nNum]->{'amity'};
			foreach (@$amity) {
				$amityFlag{$_} = 1;
			}
		}
		$mypri = $Hislands[$nNum]->{'priority'};
		@HmyPriority = @Hpriority[split(/\-/, $mypri->[$nNo])];
	}
	my(%targetTmp);

	# 범위 안의 목표 지형을 탐색
	my($i, $j, $sx, $sy, $kind, $tId, $tLv);
	my $rn = $range - 2;
	my(@order) = randomArray($rn);
	my($missionflag) = 0;
	foreach $j (0..$rn) {
		if($Hnearfar == 1) {
			$i = $range - 1 - $j;
		} elsif($Hnearfar == 2) {
			$i = $order[$j] + 1;
		} else {
			$i = $j + 1;
		}
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖
		next if(($sx < 0) || ($sy < 0));

		# 범위 안의 경우
		$tKind = $land->[$sx][$sy];
		$tLv = $landValue->[$sx][$sy];

		my $target = { 'x' => $sx, 'y' => $sy };

		next if(($tKind != $HlandMonster) && ($tKind != $HlandHugeMonster) && ($nStat> 1));

		if ($nSpecial & 0x100) {
			# 대잠 공격
			$target->{special} = 0x100;
			if($mission{"$sx,$sy"} && (!$missionflag || ($missionflag> $mission{"$sx,$sy"}))) {
				# 일제 공격 가능
				$targetTmp{'Mission'} = $target;
				$missionflag = $mission{"$sx,$sy"};
			}
			if ($tKind == $HlandNavy) {
				# 해군
				($tId, $nFlag) = (navyUnpack($tLv))[0, 5];
				# 우호국
				if(!$amityFlag{$tId}) {
					# 해당 함정에서는 없음
					if (($nFlag & 2) && !($nFlag & 1)) {
						# 잠수안의 잔해이외
						# 공격 목표 설정
						$targetTmp{'Navy'} = $target;
						next;
					}
				}
			} elsif ($tKind == $HlandCore) { # 코어
				if(!$amityFlag{$id}) {
					# 해당 시설에서는 없음
					# 공격 목표 설정
					if(int($tLv / 10000)>= 1) {
						$targetTmp{($HcoreHide ? 'Other' : 'Arm')} = $target;
						next;
					}
				}
			} elsif (($tKind == $HlandSbase) || # 해저 기지
					($tKind == $HlandOil)) { # 해저 유전
				if(!$amityFlag{$id}) {
					# 해당 시설에서는 없음
					# 공격 목표 설정
					$targetTmp{($tKind == $HlandSbase ? 'Arm' : 'Money')} = $target;
					next;
				}
			} elsif($tKind == $HlandComplex) { # 복합 지형
				if(!$amityFlag{$id}) {
					# 해당 시설에서는 없음
					my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($tLv);
					if($HcomplexAttr[$cKind] & 0x100) {
						$targetTmp{'Food'} = $target if($HcomplexFPplus[$cKind] * $HcomplexFPCmax[$cKind] + $HcomplexFPbase[$cKind]);
						$targetTmp{'Money'} = $target if($HcomplexMPplus[$cKind] * $HcomplexMPCmax[$cKind] + $HcomplexMPbase[$cKind]);
						next;
					}
				}
			} elsif (($tKind == $HlandMonster) || ($tKind == $HlandHugeMonster)) {
				# 괴수
				($tId, $nFlag) = (monsterUnpack($tLv))[0, 4];
				# 우호국
				if(!$amityFlag{$tId}) {
					# 해당 파견괴수에서는 없음
					if ($nFlag & 2) {
						# 바다에 있는지
						# 공격 목표 설정
						$targetTmp{($tKind == $HlandMonster ? 'Monster' : 'HugeMonster')} = $target;
						next;
					}
				}
			}
		}

		if ($nSpecial & 0x200) {
			# 대함 공격
			$target->{special} = 0x200;
			if($mission{"$sx,$sy"} && (!$missionflag || ($missionflag> $mission{"$sx,$sy"}))) {
				# 일제 공격 가능
				$targetTmp{'Mission'} = $target;
				$missionflag = $mission{"$sx,$sy"};
			}
			if ($tKind == $HlandNavy) {
				# 해군
				($tId, $nFlag) = (navyUnpack($tLv))[0, 5];
				# 우호국
				if(!$amityFlag{$tId}) {
					# 해당 함정에서는 없음
					if (!($nFlag & 2) && !($nFlag & 1)) {
						# 부상안의 잔해이외
						# 공격 목표 설정
						$targetTmp{'Navy'} = $target;
						next;
					}
				}
			} elsif ($tKind == $HlandCore) { # 코어
				if(!$amityFlag{$id}) {
					# 해당 시설에서는 없음
					# 공격 목표 설정
					if(int($tLv / 10000) == 1) {
						$targetTmp{($HcoreHide ? 'Other' : 'Arm')} = $target;
						next;
					}
				}
			} elsif ($tKind == $HlandOil) { # 해저 유전
				# 우호국
				if(!$amityFlag{$id}) {
					# 해당 시설에서는 없음
					# 공격 목표 설정
					$targetTmp{'Money'} = $target;
					next;
				}
			} elsif($tKind == $HlandComplex) {
				if(!$amityFlag{$id}) {
					# 해당 시설에서는 없음
					my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($tLv);
					if($HcomplexAttr[$cKind] & 0x200) {
						$targetTmp{'Food'} = $target if($HcomplexFPplus[$cKind] * $HcomplexFPCmax[$cKind] + $HcomplexFPbase[$cKind]);
						$targetTmp{'Money'} = $target if($HcomplexMPplus[$cKind] * $HcomplexMPCmax[$cKind] + $HcomplexMPbase[$cKind]);
						next;
					}
				}
			} elsif ($tKind == $HlandHugeMonster) {
				# 거대괴수
				($tId, $nFlag) = (monsterUnpack($tLv))[0, 4];
				# 우호국
				if(!$amityFlag{$tId}) {
					if ($nFlag & 2) {
						# 바다에 있는지
						# 공격 목표 설정
						$targetTmp{'HugeMonster'} = $target;
						next;
					}
				}
			}
		}

		if ($nSpecial & 0x400) {
			# 대지 공격
			$target->{special} = 0x400;
			if($mission{"$sx,$sy"} && (!$missionflag || ($missionflag> $mission{"$sx,$sy"}))) {
				# 일제 공격 가능
				$targetTmp{'Mission'} = $target;
				$missionflag = $mission{"$sx,$sy"};
			}
			if (($tKind == $HlandTown) || # 마을 계열
				($tKind == $HlandForest) || # 숲
				($tKind == $HlandFarm) || # 농장
				($tKind == $HlandFactory) || # 공장
				($tKind == $HlandComplex) || # 복합 지형
				($tKind == $HlandBase) || # 미사일 기지
				($tKind == $HlandDefence) || # 방위 시설
				($tKind == $HlandMonument) || # 기념비
				($tKind == $HlandHaribote)) { # 가짜 시설
				# 우호국
				if(!$amityFlag{$id}) {
					# 해당 시설에서는 없음
					# 공격 목표 설정
					if($tKind == $HlandTown) {
						$targetTmp{'Pop'} = $target;
						next;
					} elsif($tKind == $HlandFarm) {
						$targetTmp{'Food'} = $target;
						next;
					} elsif($tKind == $HlandFactory) {
						$targetTmp{'Money'} = $target;
						next;
					} elsif($tKind == $HlandComplex) {
						my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($tLv);
						if($HcomplexAttr[$cKind] & 0x400) {
							$targetTmp{'Food'} = $target if($HcomplexFPplus[$cKind] * $HcomplexFPCmax[$cKind] + $HcomplexFPbase[$cKind]);
							$targetTmp{'Money'} = $target if($HcomplexMPplus[$cKind] * $HcomplexMPCmax[$cKind] + $HcomplexMPbase[$cKind]);
							next;
						}
					} elsif(($tKind == $HlandBase) || ($tKind == $HlandHaribote) || (!$HdBaseHide && ($tKind == $HlandDefence))) {
						$targetTmp{'Arm'} = $target;
						next;
					} else {
						$targetTmp{'Other'} = $target;
						next;
					}
				}
			} elsif ($tKind == $HlandCore) { # 코어
				if(!$amityFlag{$id}) {
					# 해당 시설에서는 없음
					# 공격 목표 설정
					if(!(int($tLv / 10000))) {
						$targetTmp{($HcoreHide ? 'Other' : 'Arm')} = $target;
						next;
					}
				}
			} elsif (($tKind == $HlandMonster) || ($tKind == $HlandHugeMonster)) {
				# 괴수
				($tId, $nFlag) = (monsterUnpack($tLv))[0, 4];
				# 우호국
				if(!$amityFlag{$tId}) {
					# 육에 있는 까요?
					unless ($nFlag & 2) {
						# 공격 목표 설정
						$targetTmp{($tKind == $HlandMonster ? 'Monster' : 'HugeMonster')} = $target;
						next;
					}
				}
			}
		}
	} # for
	return if((keys %targetTmp) eq ());
	foreach ('Mission', @HmyPriority) {
		if(defined $targetTmp{$_}) {
			$HnavyAttackTarget{"$id,$x,$y"} = $targetTmp{$_};
			$nIsland->{"mission,$id,$targetTmp{$_}->{'x'},$targetTmp{$_}->{'y'}"}.= " <B>$HnavyName[$nKind]</B>${HtagName_}($x, $y)${H_tagName}" if((defined $nNum) && ($_ eq 'Mission'));
#			$nIsland->{"missionset,$id,$x,$y"} = 1 if((defined $nNum) && ($_ eq 'Mission'));
#			HdebugOut("====> missionset,$id,$x,$y\n") if((defined $nNum) && ($_ eq 'Mission'));
			return;
		}
	}
	$HnavyAttackTarget{"$id,$x,$y"} = undef;
	return;
}

# 해군 공격
sub navyAttack {
	my($island, $x, $y, $tx, $ty, $tSpecial) = @_;

	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($tLandName) = landName($land->[$tx][$ty], $landValue->[$tx][$ty]);
	$tLandName = ($HlandMove[$id][$tx][$ty]) ? "${HtagName2_}${tLandName}${H_tagName2}" : "${HtagName_}${tLandName}${H_tagName}";
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];

	my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
	my $nn = $HidToNumber{$nId};
	my $nSpecial = $HnavySpecial[$nKind];
	my $nName = landName($landKind, $lv);
	my $nPoint = "($x, $y)";
	my $tPoint = "($tx, $ty)";
	my($nIsland, %amityFlag, @noDefenceIds);
	if(defined $nn) {
		$nIsland = $Hislands[$nn];
		if($HnavySafetyZone) {
			$amityFlag{$nId} = 1;
			if(($HnavySafetyZone == 2) && (!$HamityInvalid || !$island->{'field'})) {
				foreach (@{$nIsland->{'amity'}}) {
					$amityFlag{$_} = 1;
				}
			}
		}
		if($HdBaseSelfNoDefenceNV == 1) {
			@noDefenceIds = ($nId);
		} elsif($HdBaseSelfNoDefenceNV == 2) {
			@noDefenceIds = ($nId, @{$nIsland->{'amityBy'}});
		} elsif($HdBaseSelfNoDefenceNV == 3) {
			@noDefenceIds = ($nId, @{$nIsland->{'amity'}});
		} elsif($HdBaseSelfNoDefenceNV == 4) {
			@noDefenceIds = ($nId, @{$nIsland->{'amity'}}, @{$nIsland->{'amityBy'}});
		} else {
			@noDefenceIds = (0);
		}
	}
	# 난민의 수
	my($boat) = 0;

	# 병사기구선택
	my @arms;
	my $n;
	if ($tSpecial & 0x100) {
		# 대잠 공격
		$n = 0x1000;
	} elsif ($tSpecial & 0x200) {
		# 대함 공격
		push(@arms, 0x1000) if ($nSpecial & 0x1000);
		push(@arms, 0x2000) if ($nSpecial & 0x2000);
		push(@arms, 0x4000) if ($nSpecial & 0x4000);
		$n = $arms[int(rand($#arms + 1))];
	} elsif ($tSpecial & 0x400) {
		# 대지 공격
		push(@arms, 0x2000) if ($nSpecial & 0x2000);
		push(@arms, 0x4000) if ($nSpecial & 0x4000);
		$n = $arms[int(rand($#arms + 1))];
	}

	# 공격오차
	my $rflag = $HnavyFireHex[$nKind] + $HnavyFireBF[1];
	$rflag = ($rflag> $#an) ? $#an : ($rflag < 0) ? 0 : int($rflag);
	my $rpflag = 0;
	my $err1 = $an[$rflag];
	my $err2;
	if($rflag) {
	 	$err2 = $an[$rflag - 1];
		if($nSpecial & 0x4000000) {
			$rpflag = $Hfirehexp[$nKind];
		} elsif(!$HitemInvalid || !$island->{'field'}) {
			$rpflag = $nIsland->{'itemAbility'}[5];
		}
	}
	# 공격 횟수
	my $nFirePlus = $HnavyFirePlus[int((expToLevel($HlandNavy, $nExp))/2)];
	my $nFire = $HnavyFire[$nKind] + $nFirePlus;
	my $fflag = ((defined $nn) && (!$HitemInvalid || !$island->{'field'})) ? $nIsland->{'itemAbility'}[11] : 1;
	$nFire *= $fflag;
	$nFire += $HnavyFireBF[0] if($island->{'field'});
	$nFire = int($nFire);
	$nFire = 1 if($nFire < 1);
	# 파괴력
	my $damage = $HnavyDamage[$nKind];
	if(($nSpecial & 0x10000000) && (rand(100) < $Hdamagep[$nKind])) {
		$damage = int(rand($HdamageMax[$nKind]) + 1);
	}
	$damage += $HnavyFireBF[3] if($island->{'field'});
	if((defined $nn) && (!$HitemInvalid || !$island->{'field'})) {
		$damage *= $nIsland->{'itemAbility'}[12];
		$damage += $nIsland->{'itemAbility'}[24];
	}
	$damage = int($damage + 0.5);
	$damage = 1 if($damage < 1);
	# 착탄 지점의 확장 분산 범위
	my $range = 0;

	# 일제 공격
#	if($nIsland->{"missionset,$id,$x,$y"}) {
#HdebugOut("[fire] missionset,$id,$x,$y => mission,$id,$tx,$ty\n");
#		$nIsland->{"mission,$id,$tx,$ty"}.= " <B>$HnavyName[$nKind]</B>${HtagName_}($x, $y)${H_tagName}";
#	}

	# 공격
	my($r, $err, $xx, $yy, $fx, $fy, $fPoint, $fName, $fKind, $fLv, @pointErr, @terrorPnt);
	my(%damageId);
	my $loopflag = 0;
	my $fire = 0;
	while ($fire < $nFire) {
		last if($loopflag); # 비용 부족 또는 잔해에서 공격 종료

		# 착탄 지점 산출
		if($rpflag && (rand(100) < $rpflag)) {
			$err = $err2;
		} else {
			$err = $err1;
		}
		$r = int(rand($err));
		$xx = $tx + $ax[$r];
		$yy = $ty + $ay[$r];
		# 행 기준 위치 조정
		$xx-- if(!($yy % 2) && ($ty % 2));
		$xx = $correctX[$xx + $#an];
		$yy = $correctY[$yy + $#an];
		if(!$HnavySelfAttack && ($xx == $x) && ($yy == $y)) {
			$r += int(1 + rand($err-1));
			$r -= $err if($r>= $err);
			# 행 기준 위치 조정
			$xx = $tx + $ax[$r];
			$yy = $ty + $ay[$r];
			$xx-- if(!($yy % 2) && ($ty % 2));
			$xx = $correctX[$xx + $#an];
			$yy = $correctY[$yy + $#an];
		}

		if($nSpecial & 0x20000000) {
			if (($xx < 0) || ($yy < 0)) {
				# 범위 밖의 경우, 융단 폭격하지 않음
				$range = 0;
			} else {
				push(@terrorPnt, "($xx, $yy)");
				$range = $an[$HnavyTerrorHex[$nKind]] - 1;
			}
		}
		my(@order) = randomArray($range + 1);
		foreach my $loop (0..$range) {

			($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($landValue->[$x][$y]);
			# 잔해 또는 바다가 되면, 공격 종료(자폭을 허가한 경우, 필요)
			#return ($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) if($nHp == 0);
			if($nHp == 0) {
				$loopflag = 1;
				last;
			}

			# 기존정 공격 횟수종료
			last if($fire>= $nFire);

			# 탄약비용을 인쿠
			if(defined $nn) {
				$nIsland->{'money'} -= $HnavyShellCost[$nKind];
				if ( ($nIsland->{'money'} < 0) &&
					(($HnavyUnknown && ($nId != 0)) || !$HnavyUnknown) ) {
					# 탄약비용이 부족함
					$nIsland->{'money'} = 0;
					$nIsland->{'shellMoney'} -= $nIsland->{'money'};
					logNavyNoShell($id, $nId, $name, $nPoint, $nName);
					$loopflag = 1;
					last;
				} else {
					$nIsland->{'shellMoney'} += $HnavyShellCost[$nKind];
				}
				$nIsland->{'ext'}[1] += $HnavyShellCost[$nKind]; # 공헌도
				$nIsland->{'ext'}[6]++;
				if($HallyNumber) {
					foreach (@{$nIsland->{'allyId'}}) {
						$Hally[$HidToAllyNumber{$_}]->{'ext'}[0]++;
					}
					foreach (@{$island->{'allyId'}}) {
						$Hally[$HidToAllyNumber{$_}]->{'ext'}[1]++;
					}
				}
			}

			$fire++;
			# 착탄 지점 산출
			$fx = $xx + $ax[$order[$loop]];
			$fy = $yy + $ay[$order[$loop]];
			# 행 기준 위치 조정
			$fx-- if(!($fy % 2) && ($yy % 2));
			$fx = $correctX[$fx + $#an];
			$fy = $correctY[$fy + $#an];

			$fPoint = "($fx, $fy)";
			if (($fx < 0) || ($fy < 0)) {
				# 범위 밖의 경우
				push(@pointErr, { 'OB' => $fPoint });
				$island->{'ext'}[5]++; # 피해를 받을 미사일의 수
				next;
			}
			$fKind = $land->[$fx][$fy];
			$fLv = $landValue->[$fx][$fy];
			$fName = landName($fKind, $fLv);

			# 방위 시설 판정
			my($defence) = 0;
			my($defflag) = 1;
			# 미판정영역
			if (($fKind == $HlandDefence) || countAroundComplex($island, $fx, $fy, $an[0], 0x40) ||
				countAroundNavySpecial($island, $fx, $fy, 0x40, $an[0], 0)) {
				# 방위 시설에 명중
				if ($fKind == $HlandDefence) { # 방위 시설에서
					if($amityFlag{$id}) { # 무해화
						if(random(100) < $HnavySafetyInvalidp) {
							# 일정 확률로 오폭
							push(@pointErr, { 'SS' => $fPoint });
						} else {
							push(@pointErr, { 'SZ' => $fPoint });
							next;
						}
					}
					# 방위 시설의 내구력을 높이기
					$defflag = ($fLv % 100) - $damage;
					$fLv -= $damage;
					if($defflag < 0) {
						$island->{'dbase'}--;
						$nIsland->{'ext'}[2]++ if(defined $nn); # 파괴한 방위 시설의 수
					}
				}
			} elsif (countAroundDef($id, $island, $fx, $fy, 0x40, @noDefenceIds)) {
				# 방위 범위
				$defence = 1;
			}

			if ($defence) {
				# 방어되었습니다
				if ($n == 0x1000) {
					# 어뢰 (대잠, 대함)
					# 바다에서는 방위하지 않음
# 방어했을 시는 코멘트를 출력하지 않음
#					push(@pointErr, { 'DF' => $fPoint });
#					$island->{'ext'}[7]++;
#					next;
				} elsif ($n == 0x2000) {
					# 함포 (대함, 대지)
					push(@pointErr, { 'DF' => $fPoint });
					$island->{'ext'}[7]++;
					next;
				} elsif ($n == 0x4000) {
					# 함재기(대함, 대지)
					push(@pointErr, { 'DF' => $fPoint });
					$island->{'ext'}[7]++;
					next;
				}
			}

			# 효과가 없는 지형
			if ($n == 0x1000) {
				# 어뢰 (대잠, 대함)
				if (($fKind == $HlandSea) || # 바다
					($fKind == $HlandWaste) || # 황무지
					($fKind == $HlandPlains) || # 평지
					($fKind == $HlandTown) || # 마을 계열
					($fKind == $HlandForest) || # 숲
					($fKind == $HlandFarm) || # 농장
					($fKind == $HlandFactory) || # 공장
					($fKind == $HlandBase) || # 미사일 기지
					($fKind == $HlandDefence) || # 방위 시설
					($fKind == $HlandMountain) || # 산
					($fKind == $HlandMonument) || # 기념비
					($fKind == $HlandHaribote)) { # 가짜 시설
					push(@pointErr, { 'ND' => $fPoint });
					$island->{'ext'}[5]++;
					next;
				}
			} elsif ($n == 0x2000) {
				# 함포 (대함, 대지)
				if (($fKind == $HlandSea) || # 바다
					($fKind == $HlandMountain) || # 산
					($fKind == $HlandWaste) || # 황무지
					($fKind == $HlandSbase)) { # 해저 기지
					push(@pointErr, { 'ND' => $fPoint });
					$island->{'ext'}[5]++;
					next;
				}
			} elsif ($n == 0x4000) {
				# 함재기(대함, 대지)
				if (($fKind == $HlandSea) || # 바다
					($fKind == $HlandMountain) || # 산
					($fKind == $HlandWaste) || # 황무지
					($fKind == $HlandSbase)) { # 해저 기지
					push(@pointErr, { 'ND' => $fPoint });
					$island->{'ext'}[5]++;
					next;
				}
			}

			# 해군, 괴수, 거대괴수이외의 무해화
			if($amityFlag{$id} && $fKind != $HlandNavy && $fKind != $HlandMonster && $fKind != $HlandHugeMonster) {
				if(random(100) < $HnavySafetyInvalidp) {
					# 일정 확률로 오폭
					push(@pointErr, { 'SS' => $fPoint });
				} else {
					push(@pointErr, { 'SZ' => $fPoint });
					next;
				}
			}

			# 특별한 지형
			if ($fKind == $HlandComplex) { # 복합 지형
				$island->{'ext'}[5]++;
				my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($fLv);
				# 효과가 있는 지형
				if( (defined $HcomplexAfter[$cKind]->{'attack'}[0]) &&
					( (($n == 0x1000) && ($HcomplexAttr[$cKind] & 0x300)) || # 어뢰 (대잠, 대함)
					(($n == 0x2000) && ($HcomplexAttr[$cKind] & 0x600)) || # 함포 (대함, 대지)
					(($n == 0x4000) && ($HcomplexAttr[$cKind] & 0x600)) ) # 함재기(대함, 대지)
				 ) {
					if($HcomplexAfter[$cKind]->{'stepdown'}) {
						$cFood -= $damage * $HcomplexAfter[$cKind]->{'stepdown'};
						$cMoney -= $damage * $HcomplexAfter[$cKind]->{'stepdown'};
						if($cFood>= 0 || $cMoney>= 0) {
							$cFood = 0 if($cFood < 0);
							$cMoney = 0 if($cMoney < 0);
							$landValue->[$fx][$fy] = landPack($cTmp, $cKind, $cTurn, $cFood, $cMoney);
							logNavyNormalDefence($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
							next;
						}
					}
					# 공격후의 지형로
					# 복합 지형이면 설정 지형
					$land->[$fx][$fy] = $HcomplexAfter[$cKind]->{'attack'}[0];
					$landValue->[$fx][$fy] = $HcomplexAfter[$cKind]->{'attack'}[1];
					$island->{'complex'}[$cKind]--;
					$HlandMove[$id][$fx][$fy] = 1;

					if ($n == 0x1000) {
						# 어뢰 (대잠, 대함)
						logNavyTorpedoNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
					} elsif (($n == 0x2000) || ($n == 0x4000)) {
						# 함포 (대함, 대지)함재기(대함, 대지)
						logNavyNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
					}
					next;
				}
				# 효과가 없는 지형
				push(@pointErr, { 'ND' => $fPoint });
				next;
			} elsif ($fKind == $HlandMonster) { # 괴수
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($fLv);
				my $mName = landName($fKind, $fLv);
				my $mn = $HidToNumber{$mId};
				if(defined $mn) {
					my $mIsland = $Hislands[$mIsland];
					$mIsland->{'ext'}[5]++ if(defined $mIsland);
				}
				# 잠수안?
				if ($mFlag & 2) {
					# 잠수안
					if (($n == 0x2000) || ($n == 0x4000)) {
						# 함포 (대함, 대지) 함재기(대함, 대지)
						push(@pointErr, { 'MS' => $fPoint });
						next;
					}
				} else {
					# 잠수안에서 없는
					if ($n == 0x1000) {
						# 어뢰 (대잠, 대함)
						push(@pointErr, { 'MS' => $fPoint });
						next;
					}
				}

				# 경화 중?
				if ($mFlag & 1) {
					# 경화 중
					push(@pointErr, { 'MH' => $fPoint });
					next;
				} else {
					# 경화 중이 아님
					if($amityFlag{$mId}) { # 무해화
						if(random(100) < $HnavySafetyInvalidp) {
							# 일정 확률로 오폭
							push(@pointErr, { 'SS' => $fPoint });
						} else {
							push(@pointErr, { 'SZ' => $fPoint });
							next;
						}
					}
					$damageId{$mId} = 1 if($mId && ($mId != $id) && ($mId != $nId));
					if ($mHp <= $damage) {
						# 괴수를 처치했습니다
						# 경험치
						$nExp += $HmonsterExp[$mKind];
						$nExp = $HmaxExpNavy if ($nExp> $HmaxExpNavy);
						$landValue->[$x][$y] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
						if(defined $nn) {
							$nIsland->{'gain'} += $HmonsterExp[$mKind];
							if($island->{'event'}[1] <= $HislandTurn) {
								if($island->{'event'}[6] == 2) {
									# 함정 경험치 획득
									$nIsland->{'epoint'}{$id} += $HmonsterExp[$mKind];
								} elsif($island->{'event'}[6] == 4) {
									# 괴수 퇴치
									$nIsland->{'epoint'}{$id}++;
								} elsif($island->{'event'}[6] == 5) {
									# 상금 처리
									$nIsland->{'epoint'}{$id} += $HmonsterValue[$mKind];
								}
							}
						}

						if ($n == 0x1000) {
							# 어뢰 (대잠, 대함)
							if ($mFlag & 2) {
								# 잠수안
								logNavyTorpedoMonKill($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $mName, $fPoint);
							}
						} elsif (($n == 0x2000) || ($n == 0x4000)) {
							# 함포 (대함, 대지)함재기(대함, 대지)
							logNavyMonKill($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $mName, $fPoint);
						}
						$HlandMove[$id][$fx][$fy] = 1;


						if (defined $nn) {
							# 수입
							my($value) = $HmonsterValue[$mKind];
							if ($value> 0) {
								$nIsland->{'money'} += $value;
								logMonMoney($nId, $mName, $value);
							}
							# 수상 관계
							my($prize) = $nIsland->{'prize'};
							$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
							my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
							$monsters |= (2 ** $mKind);
							$nIsland->{'prize'} = "$flags,$monsters,$hmonsters,$turns";
							# 괴수 퇴치 수
							$nIsland->{'monsterkill'}++;
							#아이템 획득 판정
							if($HitemRest && $HitemGetDenominator2 && (random($HitemGetDenominator2) < $nIsland->{'gain'})) {
								my $num = @Hitem;
								$num = random($num);
								push(@{$nIsland->{'item'}}, $Hitem[$num]);
								$HitemGetId[$Hitem[$num]]{$nId} = 1;
								$HitemRest--;
								logItemGetLucky2($nId, $name, $fPoint, $HitemName[$Hitem[$num]], "$mName 의체내에서");
								splice(@Hitem, $num, 1);
							}
						}

					} else {
						# 괴수살아하고 있는
						logNavyMonster($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $mName, $fPoint);

						# HP가 1 감소
						#$landValue->[$fx][$fy] -= $damage;
						$mHp -= $damage;
						if($mHp> 0) {
							$landValue->[$fx][$fy] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
							next;
						}
						next;
					}
				}
			} elsif ($fKind == $HlandHugeMonster) { # 거대괴수
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($fLv);
				my $mName = landName($fKind, $fLv);
				my $mn = $HidToNumber{$mId};
				if(defined $mn) {
					my $mIsland = $Hislands[$mIsland];
					$mIsland->{'ext'}[5]++ if(defined $mIsland);
				}
				# 잠수안?
				if ($mFlag & 2) {
					# 잠수안
# 거대괴수는 바다에 있어도 함포·함재기로 공격할 수 있습니다. 불가한 경우 코멘트를 표시하지 않습니다.
#					if (($n == 0x2000) || ($n == 0x4000)) {
#						# 함포 (대함, 대지) 함재기(대함, 대지)
#						push(@pointErr, { 'MS' => $fPoint });
#						next;
#					}
				} else {
					# 잠수안에서 없는
					if ($n == 0x1000) {
						# 어뢰 (대잠, 대함)
						push(@pointErr, { 'MS' => $fPoint });
						next;
					}
				}

				# 경화 중?
				if ($mFlag & 1) {
					# 경화 중
					push(@pointErr, { 'MH' => $fPoint });
					next;
				} else {
					# 경화 중이 아님
					if($amityFlag{$mId}) { # 무해화
						if(random(100) < $HnavySafetyInvalidp) {
							# 일정 확률로 오폭
							push(@pointErr, { 'SS' => $fPoint });
						} else {
							push(@pointErr, { 'SZ' => $fPoint });
							next;
						}
					}
					$damageId{$mId} = 1 if($mId && ($mId != $id) && ($mId != $nId));
					if (($mHp <= $damage) && ($mHflag == 0)) {
						# 괴수를 처치했습니다
						# 거대괴수 처리
						my($j, $ssx, $ssy);
						my $deflag = 0;
						foreach $j (1..6) {
							next if($HhugeMonsterImage[$mKind][$j] eq '');
							$ssx = $fx + $ax[$j];
							$ssy = $fy + $ay[$j];
							# 행 기준 위치 조정
							$ssx-- if(!($ssy % 2) && ($fy % 2));
							$ssx = $correctX[$ssx + $#an];
							$ssy = $correctY[$ssy + $#an];
							# 범위 밖
							next if(($ssx < 0) || ($ssy < 0));

							next if($land->[$ssx][$ssy] != $HlandHugeMonster);
							# 각 요소 꺼내기
							my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1, 2, 4];
							next if($mHflag2 != $j);
							# 코어의 주변이남겨 둔 것 경우 공격무효
							if($HhugeMonsterSpecial[$mKind] & 0x10000) {
								$deflag = 1;
								push(@pointErr, { 'DF' => $fPoint });
								last;
							} elsif ($mFlag2 & 2) {
								# 바다에있었음
								$land->[$ssx][$ssy] = $HlandSea;
								$landValue->[$ssx][$ssy] = $mSea2;
							} else {
								# 육지에있었음
								$land->[$ssx][$ssy] = $HlandWaste;
								$landValue->[$ssx][$ssy] = 0;
							}
							$HlandMove[$id][$ssx][$ssy] = 1;
						}
						next if($deflag);

						# 경험치
						$nExp += $HhugeMonsterExp[$mKind];
						$nExp = $HmaxExpNavy if ($nExp> $HmaxExpNavy);
						$landValue->[$x][$y] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
						if(defined $nn) {
							$nIsland->{'gain'} += $HhugeMonsterExp[$mKind];
							if($island->{'event'}[1] <= $HislandTurn) {
								if($island->{'event'}[6] == 2) {
									# 함정 경험치 획득
									$nIsland->{'epoint'}{$id} += $HhugeMonsterExp[$mKind];
								} elsif($island->{'event'}[6] == 4) {
									# 괴수 퇴치
									$nIsland->{'epoint'}{$id}++;
								} elsif($island->{'event'}[6] == 5) {
									# 상금 처리
									$nIsland->{'epoint'}{$id} += $HhugeMonsterValue[$mKind];
								}
							}
						}

						if ($n == 0x1000) {
							# 어뢰 (대잠, 대함)
							if ($mFlag & 2) {
								# 잠수안
								logNavyTorpedoMonKill($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $mName, $fPoint);
							}
						} elsif (($n == 0x2000) || ($n == 0x4000)) {
							# 함포 (대함, 대지)함재기(대함, 대지)
							logNavyMonKill($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $mName, $fPoint);
						}
						$HlandMove[$id][$fx][$fy] = 1;


						if (defined $nn) {
							# 수입
							my($value) = $HhugeMonsterValue[$mKind];
							if ($value> 0) {
								$nIsland->{'money'} += $value;
								logMonMoney($nId, $mName, $value);
							}
							# 수상 관계
							my($prize) = $nIsland->{'prize'};
							$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
							my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
							$hmonsters |= (2 ** $mKind);
							$nIsland->{'prize'} = "$flags,$monsters,$hmonsters,$turns";
							# 괴수 퇴치 수
							$nIsland->{'monsterkill'}++;
							#아이템 획득 판정
							if($HitemRest && $HitemGetDenominator && (random($HitemGetDenominator) < $nIsland->{'gain'})) {
								my $num = @Hitem;
								$num = random($num);
								push(@{$nIsland->{'item'}}, $Hitem[$num]);
								$HitemGetId[$Hitem[$num]]{$nId} = 1;
								$HitemRest--;
								logItemGetLucky2($nId, $name, $fPoint, $HitemName[$Hitem[$num]], "$mName 의체내에서");
								splice(@Hitem, $num, 1);
							}
						}

					} else {
						# 괴수살아하고 있는
						my($j, $ssx, $ssy);
						my $deflag = 0;
						foreach $j (1..6) {
							next if($HhugeMonsterImage[$mKind][$j] eq '');
							$ssx = $fx + $ax[$j];
							$ssy = $fy + $ay[$j];
							# 행 기준 위치 조정
							$ssx-- if(!($ssy % 2) && ($fy % 2));
							$ssx = $correctX[$ssx + $#an];
							$ssy = $correctY[$ssy + $#an];
							# 범위 밖
							next if(($ssx < 0) || ($ssy < 0));

							next unless($land->[$ssx][$ssy] == $HlandHugeMonster);
							# 각 요소 꺼내기
							my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1, 2, 4];
							next if($mHflag2 != $j);
							# 코어의 주변이남겨 둔 것 경우 공격무효
							if($HhugeMonsterSpecial[$mKind] & 0x10000) {
								$deflag = 1;
								push(@pointErr, { 'DF' => $fPoint });
								last;
							}
						}
						next if($deflag);
						# HP 이감루
						$mHp -= $damage;
						logNavyMonster($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $mName, $fPoint);
						if($mHp> 0) {
							# 괴수살아하고 있는
							$landValue->[$fx][$fy] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
							next;
						}
					}
					# 체의 일부가 삭제 가능
					if ($mFlag & 2) {
						# 바다에있었음
						$land->[$fx][$fy] = $HlandSea;
						$landValue->[$fx][$fy] = $mSea;
					} else {
						# 육지에있었음
						$land->[$fx][$fy] = $HlandWaste;
						$landValue->[$fx][$fy] = 0;
					}
					$HlandMove[$id][$fx][$fy] = 1;
					next;
				}
			} elsif ($fKind == $HlandNavy) { # 해군
				my($nId2, $nTmp2, $nStat2, $nSea2, $nExp2, $nFlag2, $nNo2, $nKind2, $nHp2) = navyUnpack($fLv);
				my $nSpecial2 = $HnavySpecial[$nKind2];
				my $nName2 = landName($fKind, $fLv);
				my $nn2 = $HidToNumber{$nId2};
				my($nIsland2);
				$nIsland2 = $Hislands[$nn2] if (defined $nn2);

				if ($nFlag2 & 2) {
					# 잠수안
					if (($n == 0x2000) || ($n == 0x4000)) {
						# 함포 (대함, 대지) 함재기(대함, 대지)
						push(@pointErr, { 'FS' => $fPoint });
						next;
					}
				}

				# 잔해?
				if ($nFlag2 & 1) {
					logNavyWreckDestroy($id, $name, $nId, $nPoint, $nName, $tPoint, $nName2, $fPoint);

					# 바다가 됨
					$land->[$fx][$fy] = $HlandSea;
					$landValue->[$fx][$fy] = $nSea2;
					$HlandMove[$id][$fx][$fy] = 1;
					next;
				}

				if($amityFlag{$nId2}) { # 무해화
					if(random(100) < $HnavySafetyInvalidp) {
						# 일정 확률로 오폭
						push(@pointErr, { 'SS' => $fPoint });
					} else {
						push(@pointErr, { 'SZ' => $fPoint });
						next;
					}
				}

				if(defined $nn2) {
					if ($nId == $nId2) {
						# 아군을 공격한 경우 공헌도 감소(피해를 받을 미사일의 수는 카운트하지 않음)
						$nIsland2->{'ext'}[1] -= $HnavyShellCost[$nKind]; # 공헌도
						#$nIsland2->{'ext'}[1] = 0 if($nIsland2->{'ext'}[1] < 0);
					} else {
						# 적을 공격한 경우 공헌도 증가
						$nIsland2->{'ext'}[1] += $HnavyShellCost[$nKind]; # 공헌도
						$nIsland2->{'ext'}[5]++;
					}
				}

				$damageId{$nId2} = 1 if($nId2 && ($nId2 != $id) && ($nId2 != $nId));
				if ($nHp2 <= $damage) {
					# 격침

					# 경험치
					$nExp += $HnavyExp[$nKind2];
					$nExp = $HmaxExpNavy if ($nExp> $HmaxExpNavy);
					$landValue->[$x][$y] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
					if(defined $nn) {
						$nIsland->{'gain'} += $HnavyExp[$nKind2];
						if($island->{'event'}[1] <= $HislandTurn) {
							if($island->{'event'}[6] == 2) {
								# 함정 경험치 획득
								$nIsland->{'epoint'}{$id} += $HnavyExp[$nKind2];
							} elsif($island->{'event'}[6] == 3) {
								# 함정 격침
								$nIsland->{'epoint'}{$id}++;
							}
						}
						#아이템탈취판정
						if($HitemSeizeDenominator && $nIsland2->{'itemNumber'}) {
							if(($nIsland2->{'ships'}[4] + $nIsland2->{'navyPort'}) == 1) {
								foreach(shift @{$nIsland2->{'item'}}) {
									push(@{$nIsland->{'item'}}, $_);
									$HitemGetId[$_]{$nId2} = undef;
									$HitemGetId[$_]{$nId} = 1;
								}
								$nIsland->{'itemNumber'} += $nIsland2->{'itemNumber'};
								$nIsland2->{'itemNumber'} = 0;
								my $name2 = islandName($nIsland2);
								logItemGetLucky2($nId, $name, $fPoint, "${HtagName_}${name2}${H_tagName}이보유하고 있었음모두의$HitemName[0]", "침몰간 시의$nName2에서");
							} elsif(random($HitemSeizeDenominator) < $nExp) {
								my $num = random($nIsland2->{'itemNumber'});
								push(@{$nIsland->{'item'}}, $nIsland2->{'item'}[$num]);
								$HitemGetId[$num]{$nId2} = undef;
								$HitemGetId[$num]{$nId} = 1;
								$nIsland->{'itemNumber'}++;
								$nIsland2->{'itemNumber'}--;
								logItemGetLucky2($nId, $name, $fPoint, $HitemName[$nIsland2->{'item'}[$num]], "침몰간 시의$nName2에서");
								splice(@{$nIsland2->{'item'}}, $num, 1);
							}
						}
						$nIsland->{'ext'}[10]++;
						if($nId2 != $nId) {
							$nIsland->{'sink'}[$nKind2]++;
						} else {
							$nIsland->{'sinkself'}[$nKind2]++;
						}
					}

					if(defined $nn2) {
						$nIsland2->{'shipk'}[$nKind2]--;
						# 서바이벌
						$nIsland2->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
					}
					if ($nSpecial2 & 0x8) {
						# 군항괴멸
						logNavyPortDestroy($id, $name, $nId, $nPoint, $nName, $tPoint, $nId2, $nName2, $fPoint);

						# 얕은 바다가 됨
						$land->[$fx][$fy] = $HlandSea;
						$landValue->[$fx][$fy] = 1;
						$nIsland2->{'navyPort'}--;
					} else {
						# 함정 격침
						logNavyShipDestroy($id, $name, $nId, $nPoint, $nName, $tPoint, $nId2, $nName2, $fPoint);

						if (rand(100) < $HnavyProbWreck[$nKind2]) {
							# 잔해가 됨
							$landValue->[$fx][$fy] = navyPack(0, $nTmp2, $nStat2, $nSea2, int(rand(90)) + 10, 1, 0, $nKind2, 0);
						} else {
							# 바다가 됨
							$land->[$fx][$fy] = $HlandSea;
							$landValue->[$fx][$fy] = $nSea2;
							$HnavyAttackTarget{"$id,$fx,$fy"} = undef;
						}
						if(defined $nn2) {
							$nIsland2->{'ships'}[$nNo2]--;
							$nIsland2->{'ships'}[4]--;
						}
					}
					$HlandMove[$id][$fx][$fy] = 1;
					next;
				} else {
					# 피격
					logNavyDamage($id, $name, $nId, $nPoint, $nName, $tPoint, $nId2, $nName2, $fPoint);

					# HP 이감루
					#$landValue->[$fx][$fy] -= $damage;
					$nHp2 -= $damage;
					if($nHp2> 0) {
						$landValue->[$fx][$fy] = navyPack($nId2, $nTmp2, $nStat2, $nSea2, $nExp2, $nFlag2, $nNo2, $nKind2, $nHp2);
					} else {
						$land->[$fx][$fy] = $HlandSea;
						$landValue->[$fx][$fy] = $nSea2;
					}
					next;
				}
			} elsif($fKind == $HlandSeaMine) {
				# 기뢰
				logNavySeaMine($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);

				$land->[$fx][$fy] = $HlandSea; # 깊은 바다
				$landValue->[$fx][$fy] = 0;
				$HlandMove[$id][$fx][$fy] = 1;
				$island->{'ext'}[5]++;
				next;
			} elsif (($fKind == $HlandDefence) && ($defflag>= 0)) {
				# 방위 시설(내구력이남겨 둔 것)
				logNavyNormalDefence($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
			} elsif ($fKind == $HlandCore) {
				# 코어
				my($lFlag, $lLv) = (int($fLv / 10000), ($fLv % 10000));
				if( !(($n == 0x1000) && ($lFlag>= 1)) && !((($n == 0x2000) || ($n == 0x4000)) && ($lFlag <= 1)) ) {
					push(@pointErr, { 'ND' => $fPoint });
					$island->{'ext'}[5]++;
					next;
				}
				# 내구력을 높이기
				my $coreflag = $lLv - $damage;
				$fLv -= $damage;
				# 코어폭격 수, 코어파괴수
				$nIsland->{'epoint'}{$id}++ if((defined $nn) && ($island->{'event'}[6] == 6) || (($coreflag < 0) && ($island->{'event'}[6] == 7)) && ($island->{'event'}[1] <= $HislandTurn));
				if($coreflag>= 0) {
					$land->[$fx][$fy] = $HlandCore;
					$landValue->[$fx][$fy] = $fLv;
					logNavyNormalDefence($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
				} else {
					$island->{'core'}--;
					$island->{'slaughterer2'} = $nId if($HcorelessDead && (defined $nn) && !$island->{'core'}); # 파괴한 섬 ID를 기록
					if ($n == 0x1000) {
						# 어뢰 (대잠, 대함)
						logNavyTorpedoNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
					} elsif (($n == 0x2000) || ($n == 0x4000)) {
						# 함포 (대함, 대지)함재기(대함, 대지)
						logNavyNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
					}
					if(!$lFlag) {
						$land->[$fx][$fy] = $HlandWaste; # 황무지(착탄 지점)
						$landValue->[$fx][$fy] = 1;
					} else {
						$land->[$fx][$fy] = $HlandSea; # 바다
						$landValue->[$fx][$fy] = 2 - $lFlag;
					}
					$HlandMove[$id][$fx][$fy] = 1;
				}
				next;
			} elsif ($fKind == $HlandTown) {
				# 도시계
				$island->{'ext'}[5]++;
				my $sLv = 0;
				my $rank = 0;
				if($HtownStepDown) {
					foreach (reverse(0..$#HlandTownValue)) {
						if($HlandTownValue[$_] <= $fLv) {
							$rank = $_;
							last;
						}
					}
					$rank -= $damage;
					$rank = 0 if($rank < 0);
					$sLv = $HlandTownValue[$rank];
				}
				$nExp += int(($fLv - $sLv) / 20);
				$nExp = $HmaxExpNavy if ($nExp> $HmaxExpNavy);
				$landValue->[$x][$y] = navyPack($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp);
				if(defined $nn) {
					$nIsland->{'gain'} += int(($fLv - $sLv) / 20) if($HsurvivalTurn);
					if(($island->{'event'}[6] == 2) && ($island->{'event'}[1] <= $HislandTurn)) {
						# 함정 경험치 획득
						$nIsland->{'epoint'}{$id} += int(($fLv - $sLv) / 20);
					}
				}
				$boat += ($fLv - $sLv); # 난민에플러스
				if($rank) {
					$landValue->[$fx][$fy] = $sLv;
					logNavyNormalTown($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint, $HlandTownName[$rank]);
				} else {
					$island->{'slaughterer'} = $nId if(defined $nn); # 도시계를 파괴한 섬 ID를 기록
					logNavyNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
					$land->[$fx][$fy] = $HlandWaste; # 황무지(착탄 지점)
					$landValue->[$fx][$fy] = 1;
					$HlandMove[$id][$fx][$fy] = 1;
				}
				next;
			} else {
				# 기타의 지형
				if ($n == 0x1000) {
					# 어뢰 (대잠, 대함)
					logNavyTorpedoNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
				} elsif (($n == 0x2000) || ($n == 0x4000)) {
					# 함포 (대함, 대지)함재기(대함, 대지)
					logNavyNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
				}
				$island->{'ext'}[5]++;

				if ($fKind == $HlandBase && (defined $nn)) {
					$nIsland->{'ext'}[3]++; # 격파했습니다 미사일 기지의 수
				}
			}

			# 공격후의 지형로
			if ($n == 0x1000) {
				# 어뢰 (대잠, 대함)
				$land->[$fx][$fy] = $HlandSea; # 깊은 바다
				$landValue->[$fx][$fy] = 0;
				$landValue->[$fx][$fy] = 1 if($fKind == $HlandBouha);
			} elsif (($n == 0x2000) || ($n == 0x4000)) {
				# 함포 (대함, 대지)함재기(대함, 대지)
				if ($fKind == $HlandOil) { # 해저 유전
					$land->[$fx][$fy] = $HlandSea; # 깊은 바다
					$landValue->[$fx][$fy] = 0;
				} elsif(($fKind == $HlandDefence) && ($defflag>= 0)) {
					# 내구력이 남은 방위시설이라면 내구 가능
					$land->[$fx][$fy] = $HlandDefence;
					$landValue->[$fx][$fy] = $fLv;
					next;
				} elsif($fKind == $HlandBouha) {
					# 방파제라면 얕은 바다
					$land->[$fx][$fy] = $HlandSea;
					$landValue->[$fx][$fy] = 1;
					$island->{'bouha'}--;
				} else {
					$land->[$fx][$fy] = $HlandWaste; # 황무지(착탄 지점)
					$landValue->[$fx][$fy] = 1;
				}
			}
			$HlandMove[$id][$fx][$fy] = 1;
		} #foreach
	} #while

	if($fire) {
		my $l;
		my @pKey = ('OB', 'DF', 'ND', 'MS', 'MH', 'FS', 'SZ', 'SS');
		my @pName = ('권역외', '방위', '무효', '괴수 잠수', '경화', '함잠수', '무해', '오폭');
		my $str = '';
		my $pntStr = '<BR>--- ';
		my @cntErr = (0, 0, 0, 0, 0, 0, 0, 0, 0);
		foreach $l (0..7) {
			my $pflag = 1;
			my @pointOut = ();
			my $p;
			foreach $p (@pointErr) {
				my $pnt = $p->{$pKey[$l]};
				next if($pnt eq '');
				$cntErr[$l]++;
				$cntErr[8]++;
				foreach (@pointOut) {
					$pflag = 0 if($_ eq $pnt);
				}
				push(@pointOut, $pnt) if($pflag);
			}
			if($cntErr[$l]) {
				$str.= " $pName[$l]\:". $cntErr[$l];
				$pntStr.= "$pName[$l] ⇒ ". join(',', @pointOut). " " if($l);
			}
		}
		$pntStr = '' if(!$cntErr[8] || ($cntErr[8] == $cntErr[0]));
		$pntStr.= '[유폭 중심 ⇒ '. join(',', @terrorPnt).']' if(@terrorPnt);
		$str = '(명중:'. ($fire - $cntErr[8]). $str.')';
		$str.= '[파괴력:'. $damage. ']' if($damage> 1);
		my $kind;
		if ($n == 0x1000) {
			# 어뢰 (대잠, 대함)
			$kind = ($HnavyFireName[$nKind][0] ne '') ? $HnavyFireName[$nKind][0] : '어뢰발사';
		} elsif ($n == 0x2000) {
			# 함포 (대함, 대지)
			$kind = ($HnavyFireName[$nKind][1] ne '') ? $HnavyFireName[$nKind][1] : '함포사격';
		} elsif ($n == 0x4000) {
			# 함재기(대함, 대지)
			$kind = ($HnavyFireName[$nKind][2] ne '') ? $HnavyFireName[$nKind][2] : '함재기 폭격';
		}
		logNavyMatome($id, $name, $nId, $nPoint, $nName, $tPoint, $tLandName, $kind, $str, $pntStr, join('-', (keys %damageId)));
	}
	# 난민판정
	$boat = int($boat / 2) if(!$HsurvivalTurn);
	if(($boat> 0) && (defined $nn)) {
		# 난민표착
		my($achive) = boatAchive($nIsland, $boat); # 도달난민

		if ($achive> 0) {
			# 조금이라도 도착한 경우 로그를 출력
			my $name = islandName($nIsland);
			logMsBoatPeople($nId, $name, $achive);
			$nIsland->{'ext'}[4] += int($achive); # 구출한 난민의 합계인구

			# 난민의 수가일정수이상라면, 평화상의 가능성있음
			if ($achive>= 200) {
				$nIsland->{'achive'} += $achive;
			}
		}
	}
	# 공격 플래그가 설정되어 있는(공격한 함대는 함대 이동, 파견, 귀환 처리를 하지 않음)
	$nIsland->{'NavyAttack_flag'}[$nNo] = 1 if(defined $nn);
	if($land->[$x][$y] == $HlandNavy) {
		return navyUnpack($landValue->[$x][$y]);
	} else {
		return ($nId, $nTmp, $nStat, $nSea, $nExp, 1, $nNo, $nKind, $nHp);
	}
}

# 난민도달 처리
sub boatAchive {
	my($island, $boat) = @_;
	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};

	my($i, $x, $y, $kind, $lv, $achive);
	for ($i = 0; ($i <= $island->{'pnum'} && $boat> 0); $i++) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		$kind = $land->[$x][$y];
		$lv = $landValue->[$x][$y];

		if($kind == $HlandTown) {
			# 읍의 경우
			foreach (reverse(0..$#HlandTownValue)) {
				if($HlandTownValue[$_] <= $lv) {
					if ($boat> $HachiveValueMax[$_]) {
						$lv += $HachiveValueMax[$_];
						$achive += $HachiveValueMax[$_];
						$boat -= $HachiveValueMax[$_];
					} else {
						$lv += $boat;
						$achive += $boat;
						$boat = 0;
					}
					if ($lv> $HvalueLandTownMax) {
						$lv = $HvalueLandTownMax;
						$achive -= ($lv - $HvalueLandTownMax);
						$boat += ($lv - $HvalueLandTownMax);
					}
					last;
				}
			}
			$landValue->[$x][$y] = $lv;

		} elsif ($bKind == $HlandPlains) {
			# 평지의 경우
			$land->[$x][$y] = $HlandTown;;
			if ($boat> $HachivePlainsMax) {
				$landValue->[$x][$y] = $HachivePlainsMax - $HachivePlainsLoss;
				$achive += $HachivePlainsMax - $HachivePlainsLoss;
				$boat -= $HachivePlainsMax;
			} elsif ($boat> 5) {
				$landValue->[$x][$y] = $boat - $HachivePlainsLoss;
				$achive += $boat - $HachivePlainsLoss;
				$boat = 0;
			}
		}

		last if($boat <= 0);
	}

	return $achive;
}
# 주변의 읍, 농장이 있는 지반정
sub countGrow {
	my($island, $x, $y) = @_;
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($i, $sx, $sy);
	foreach $i (1..6) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖
		next if(($sx < 0) || ($sy < 0) || ($HoceanMode && ($HlandID[$sx][$sy] != $id)));

		# 범위 안의 경우
		if(($land->[$sx][$sy] == $HlandTown) || ($land->[$sx][$sy] == $HlandFarm)) {
			if($landValue->[$sx][$sy]) {
				return 1;
			}
		} elsif($land->[$sx][$sy] == $HlandComplex) {
			my $cKind = (landUnpack($landValue->[$sx][$sy]))[1];
			if($HcomplexAttr[$cKind] & 0x1) {
				return 1;
			}
		}
	}
	return 0;
}

# 섬 전체
sub doIslandProcess {
	my($island) = @_;

	# 도출 값
	my($name) = islandName($island);;
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my $disdown = 1;
	if($HallyDisDown && ($island->{'allyId'}[0] ne '')) {
		$disdown = $HallyDisDown;
	}
	# 수입 로그(정리해서 로그 출력)
	logOilMoney($id, $name, "유전", "", "총액$island->{'oilincome'}${HunitMoney}", "수익") if($island->{'oilincome'}> 0);
	foreach (0..$#HcomplexComName) {
		my $income = $HcomplexComTFInCome[$_];
		next if($income->{'log'} ne 'matome');
		my $incomeValue = $island->{'cIncome'}[$_];
		logOilMoney($id, $name, $HcomplexName[$HcomplexComKind[$_]], "", "총액$incomeValue${HunitMoney}", $income->{'logstr'}) if($incomeValue> 0);
	}
	foreach (0..$#HcomplexName) {
		# 무작위
		$island->{'randommoney'} += $island->{'rinmoney'}[$_];
		$island->{'randomfood'} += $island->{'rinfood'}[$_];
		logOilMoney($id, $name, $HcomplexName[$_], "", "총액$island->{'rinmoney'}[$_]${HunitMoney}", "수익") if($island->{'rinmoney'}[$_]> 0);
		logOilMoney($id, $name, $HcomplexName[$_], "", "총량$island->{'rinfood'}[$_]${HunitFood}", "수확") if($island->{'rinfood'}[$_]> 0);
	}
	# 지진판정
	if(($HpunishInfo{$id}->{punish} == 1) || (!$HnoDisFlag && (random(1000) < (($island->{'prepare2'} + 1) * $HdisEarthquake * $disdown * $island->{'itemAbility'}[17])))) {
		# 지진발생

		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$island->{'pnum'}) {
			$x = $island->{'rpx'}[$i];
			$y = $island->{'rpy'}[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if((($landKind == $HlandTown) && ($lv>= 100)) ||
				(($landKind == $HlandComplex) && ($HcomplexAfter[my $cKind = (landUnpack($lv))[1]]->{'earthquake'}[0] ne '')) ||
				($landKind == $HlandHaribote) ||
				($landKind == $HlandBouha) ||
				($landKind == $HlandFactory)) {
				# 1/4에서 괴멸
				if(random(4) == 0) {
					logEQDamage($id, $name, landName($landKind, $lv), "($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;

					if($landKind == $HlandBouha) {
						# 방파제라면 얕은 바다
						$land->[$x][$y] = $HlandSea;
						$landValue->[$x][$y] = 1;
						$island->{'bouha'}--;
					} elsif($landKind == $HlandComplex) {
						# 복합 지형이면 설정 지형
#						my $cKind = (landUnpack($lv))[1];
						$land->[$x][$y] = $HcomplexAfter[$cKind]->{'earthquake'}[0];
						$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'earthquake'}[1];
						$island->{'complex'}[$cKind]--;
					}
				}
			}
		}
		logEarthquake($id, $name);
	}

	# 식량 부족
	if(($island->{'food'} <= 0) && !$island->{'field'}) {
		# 부족 메시지
		logStarve($id, $name);
		$island->{'food'} = 0;

		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$island->{'pnum'}) {
			$x = $island->{'rpx'}[$i];
			$y = $island->{'rpy'}[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) ||
				($landKind == $HlandFactory) ||
				(($landKind == $HlandComplex) && ($HcomplexAfter[my $cKind = (landUnpack($lv))[1]]->{'starve'}[0] ne '')) ||
				($landKind == $HlandBase) ||
				($landKind == $HlandDefence)) {
				# 1/4에서 괴멸
				if(random(4) == 0) {
					logSvDamage($id, $name, landName($landKind, $lv), "($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					if($landKind == $HlandComplex) {
						# 복합 지형이면 설정 지형
#						my $cKind = (landUnpack($lv))[1];
						$land->[$x][$y] = $HcomplexAfter[$cKind]->{'starve'}[0];
						$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'starve'}[1];
						$island->{'complex'}[$cKind]--;
					} elsif($landKind == $HlandDefence) {
						$island->{'dbase'}--;
					}
				}
			}
		}
	}

	# 쓰나미판정
	my $tsunamiFlag = $HdisTsunami * $disdown * $island->{'itemAbility'}[23];
	if($HnoDisFlag) {
		$tsunamiFlag = 0;
	} elsif($HdisTsunamiFsea) {
		if($island->{'sea'} < $HdisTsunamiFsea) {
			$tsunamiFlag *= 10;
		} elsif($island->{'pnum'} + 1 - 8*8 - $HdisTsunamiFsea> 0) {
 			my $flag = ($island->{'pnum'} + 1 - 8*8 - $island->{'sea'})/($island->{'pnum'} + 1 - 8*8 - $HdisTsunamiFsea);
			if($flag> 0) {
				$tsunamiFlag *= (1 + int($flag * 4));
			}
		}
	}
	my($wflag);
	$wflag = ($island->{'weather'}[5]>= 90) ? 10 * $island->{'weather'}[5] : ($island->{'weather'}[3]>= 45) ? 5 * $island->{'weather'}[3] : 0 if($HuseWeather);
	if(($HpunishInfo{$id}->{punish} == 2) || (random(1000 - $wflag) < $tsunamiFlag)) {
		# 쓰나미발생
		$island->{'weather'}[5] = 0;
		$island->{'weather'}[3] = 0;
		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$island->{'pnum'}) {
			$x = $island->{'rpx'}[$i];
			$y = $island->{'rpy'}[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandTown) ||
			($landKind == $HlandFarm) ||
			($landKind == $HlandFactory) ||
			(($landKind == $HlandComplex) && ($HcomplexAfter[my $cKind = (landUnpack($lv))[1]]->{'tsunami'}[0] ne '')) ||
			($landKind == $HlandBase) ||
			($landKind == $HlandNavy) || # 군항와 선박
			($landKind == $HlandSeaMine) ||
			($landKind == $HlandDefence) ||
			($landKind == $HlandHaribote)) {
				next if(countAround($island, $x, $y, $an[2], $HlandBouha));
				next if(countAroundNavyBouha($island, $x, $y));
				# 1d12 <= (주변의 바다 - 1) 데붕괴
				if(random(12) < (countAround($island, $x, $y, $an[1], $HlandNavy, $HlandSeaMine, $HlandOil, $HlandSbase, $HlandSea) - 1)) {
					if($landKind == $HlandNavy){
						my $fDamage = random($HdisTsunamiDmax) + 1; # 피해1에서10
						my ($nId, $nSea, $nNo, $nKind, $nHp) = (navyUnpack($lv))[0, 3, 6, 7, 8];
						my $nSpecial = $HnavySpecial[$nKind];
						my $n = $HidToNumber{$nId};
						$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
						if($nSpecial & 0x8) { # 항구
							logTsunamiDamage($id, $name, landName($landKind, $lv), "($x, $y)");
						 	$land->[$x][$y] = $HlandSea;
							$landValue->[$x][$y] = 1;
							$Hislands[$n]->{'navyPort'}-- if(defined $n);
						} elsif(!($nHp> $fDamage)) { # 또는 피해가 내구력을 초과하는지
							logTsunamiDamageNavyDestroy($id, $name, landName($landKind, $lv), "($x, $y)");
						 	$land->[$x][$y] = $HlandSea;
							$landValue->[$x][$y] = $nSea;
							if(defined $n) {
								$Hislands[$n]->{'ships'}[$nNo]--;
								$Hislands[$n]->{'ships'}[4]--;
								# 서바이벌
								$Hislands[$n]->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
							}
						} else {
							logTsunamiDamageNavy($id, $name, landName($landKind, $lv), "($x, $y)");
							$landValue->[$x][$y] -= $fDamage;
						}

					} else {
						logTsunamiDamage($id, $name, landName($landKind, $lv), "($x, $y)");
						$land->[$x][$y] = $HlandWaste;
						$landValue->[$x][$y] = 0;
						if($landKind == $HlandSeaMine) {
							# 기뢰라면 바다
							$land->[$x][$y] = $HlandSea;
						} elsif($landKind == $HlandComplex) {
							# 복합 지형이면 설정 지형
#							my $cKind = (landUnpack($lv))[1];
							$land->[$x][$y] = $HcomplexAfter[$cKind]->{'tsunami'}[0];
							$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'tsunami'}[1];
							$island->{'complex'}[$cKind]--;
						} elsif($landKind == $HlandDefence) {
							$island->{'dbase'}--;
						}
					}
				}
			}
		}
		logTsunami($id, $name);

	}

	# 괴수판정
	my($r, $pop);
	if(!$island->{'field'}) {
		$r = (random(10000) < ($HdisMonster * $island->{'area'})) ? 1 : 0;
		$pop = $island->{'pop'};
	} else {
		$r = ($HdisMonsterBF && random(10000) < $HdisMonsterBF) ? 1 : (random(5000) < ($HdisMonster * $island->{'area'})) ? 1 : 0;
		$pop = $HdisMonsBorderMax;
	}
	$r = 0 if ($HnoDisFlag);
	$r = 1 if ($HpunishInfo{$id}->{punish} == 3);
	if($r && ($pop>= $HdisMonsBorderMin)) {
		# 괴수출현
		# 종류를 결하기
		my($kind, @r);
		foreach (0..$#HdisMonsBorder) {
			push(@r, ($_)x$HdisMonsRatio[$_]) if($pop>= $HdisMonsBorder[$_]);
		}
		$kind = $r[random($#r+1)];

		# 괴수출현
		bringMonster($island, 0, $kind, 0);
	}

	# 거대괴수판정
	if(!$island->{'field'}) {
		$r = (random(10000) < ($HdisHuge * $island->{'area'})) ? 1 : 0;
		$pop = $island->{'pop'};
	} else {
		$r = ($HdisHugeBF && random(10000) < $HdisHugeBF) ? 1 : (random(5000) < ($HdisHuge * $island->{'area'})) ? 1 : 0;
		$pop = $HdisHugeBorderMax;
	}
	$r = 0 if ($HnoDisFlag);
	$r = 1 if ($HpunishInfo{$id}->{punish} == 4);
	if($r && ($pop>= $HdisHugeBorderMin) && $HhugeMonsterAppear) {
		# 거대괴수출현
		# 종류를 결하기
		my($kind, @r);
		foreach (0..$#HdisHugeBorder) {
			push(@r, ($_)x$HdisHugeRatio[$_]) if($pop>= $HdisHugeBorder[$_]);
		}
		$kind = $r[random($#r+1)];

		bringMonster($island, 0, $kind, 1);
	}

	# 함정(소속 불명)판정
	if(!$island->{'field'}) {
		$r = (random(10000) < ($HdisNavy * $island->{'area'})) ? 1 : 0;
		$pop = $island->{'pop'};
	} else {
		$r = ($HdisNavyBF && random(10000) < $HdisNavyBF) ? 1 : (random(5000) < ($HdisNavy * $island->{'area'})) ? 1 : 0;
		$pop = $HdisNavyBorderMax;
	}
	$r = 0 if ($HnoDisFlag);
	$r = 1 if ($HpunishInfo{$id}->{punish} == 5);
	if($r && ($pop>= $HdisNavyBorderMin) && $HnavyUnknown) {
		# 함정 출현
		# 종류를 결하기
		my($kind, @r);
		foreach (0..$#HdisNavyRatio) {
			push(@r, ($_)x$HdisNavyRatio[$_]) if($pop>= $HdisNavyBorder[$_]);
		}
		$kind = $r[random($#r+1)];

		bringNavy($island, $kind);
	}
	# 이벤트 섬의 출현판정
	if($island->{'event'}[0] && ($island->{'event'}[1] <= $HislandTurn)) {
		# 괴수
		if($island->{'event'}[13] && !(($HislandTurn - $island->{'event'}[1])%$island->{'event'}[12])) {
			bringMonster($island, 0, random($#HmonsterName+1), 0, $island->{'event'}[13]);
		}
		# 거대괴수
		if($island->{'event'}[15] && !(($HislandTurn - $island->{'event'}[1])%$island->{'event'}[14])) {
			bringMonster($island, 0, random($#HhugeMonsterName+1), 1, $island->{'event'}[15]);
		}
		# 소속 불명 함정
		if($island->{'event'}[17] && !(($HislandTurn - $island->{'event'}[1])%$island->{'event'}[16])) {
			bringNavy($island, random($#HnavyName)+1, $island->{'event'}[17]);
		}
		# 코어
		if($island->{'event'}[20] && !(($HislandTurn - $island->{'event'}[1])%$island->{'event'}[19])) {
			randomBuildCore($island, $island->{'event'}[20], $island->{'event'}[21], $island->{'event'}[22], 1);
		}
	}


	# 지반 침하판정
	$wflag = ($island->{'weather'}[4]>= 90) ? 10 * $island->{'weather'}[4] : 0 if($HuseWeather);
	if(($island->{'area'}> $HdisFallBorder) &&
	 (($HpunishInfo{$id}->{punish} == 6) || (random(1000 - $wflag) < $HdisFalldown))) {
		# 지반 침하발생
		$island->{'weather'}[4] = 0;
		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$island->{'pnum'}) {
			$x = $island->{'rpx'}[$i];
			$y = $island->{'rpy'}[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind != $HlandSea) &&
				($landKind != $HlandSbase) &&
				!(($landKind == $HlandCore) && (int($lv / 10000))) &&
				($landKind != $HlandOil) &&
				($landKind != $HlandSeaMine) &&
				($landKind != $HlandMountain)) {

				if($landKind == $HlandNavy) { # 군항와 선박
					my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
					my $nSpecial = $HnavySpecial[$nKind];
					unless ($nSpecial & 0x8) {
						# 항구 이외는 지반 침하하지 않음
						next;
					}
					my $n = $HidToNumber{$nId};
					$Hislands[$n]->{'navyPort'}-- if(defined $n);
				} elsif($landKind == $HlandComplex) {
					# 복합 지형이면 설정 지형
					my $cKind = (landUnpack($lv))[1];
					next if($HcomplexAfter[$cKind]->{'falldown'}[0] eq '');
					next if(!countAround($island, $x, $y, $an[1], $HlandSea, $HlandSbase, $HlandNavy));
					$land->[$x][$y] = $HcomplexAfter[$cKind]->{'falldown'}[0];
					$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'falldown'}[1];
					$island->{'complex'}[$cKind]--;
					logFalldownLand($id, $name, landName($landKind, $lv), "($x, $y)");
					next;
				} elsif($landKind == $HlandMonster) { # 괴수
					my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);

					# 바다에있었음
					next if ($mFlag2 & 2);
				} elsif($landKind == $HlandHugeMonster) { # 거대괴수는 지반 침하하지 않음
					my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);

					# 바다에있었음
					next if ($mFlag2 & 2);
					# 주변에 바다가 있다면, 육지플래그를 얕은 바다에 변경
					if(countAround($island, $x, $y, $an[1], $HlandSea, $HlandSbase)) {
						logFalldownLand($id, $name, landName($landKind, $lv), "($x, $y)");
						$mFlag |= 2;
						$mSea = 1;
						$landValue->[$x][$y] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
						next;
					}
				}

				# 주변에 바다가 있다면, 값을-1에
				if(countAround($island, $x, $y, $an[1], $HlandSea, $HlandSbase, $HlandNavy)) {
					logFalldownLand($id, $name, landName($landKind, $lv), "($x, $y)");
					$land->[$x][$y] = -1;
					$landValue->[$x][$y] = 0;
				}

			}
		}

		foreach $i (0..$island->{'pnum'}) {
			$x = $island->{'rpx'}[$i];
			$y = $island->{'rpy'}[$i];
			$landKind = $land->[$x][$y];

			if($landKind == -1) {
				# -1에나하고 있는 장소를 얕은 바다에
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
			} elsif ($landKind == $HlandSea) {
				# 얕은 바다는 바다에
				$landValue->[$x][$y] = 0;
			}

		}

		logFalldown($id, $name);
	}

	# 태풍판정
	$wflag = ($island->{'weather'}[3]>= 20) ? 10 * $island->{'weather'}[3] : 0 if($HuseWeather);
	if(($HpunishInfo{$id}->{punish} == 7) || (!$HnoDisFlag && (random(1000 - $wflag) < $HdisTyphoon * $disdown * $island->{'itemAbility'}[18]))) {
		# 태풍발생
		$island->{'weather'}[3] = 0;
		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$island->{'pnum'}) {
			$x = $island->{'rpx'}[$i];
			$y = $island->{'rpy'}[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) ||
				(($landKind == $HlandComplex) && ($HcomplexAfter[my $cKind = (landUnpack($lv))[1]]->{'typhoon'}[0] ne '')) ||
				($landKind == $HlandHaribote)) {

				# 1d12 <= (6 - 주변의 숲) 데붕괴
				if(random(12) < (6 - countAround($island, $x, $y, $an[1], $HlandForest, $HlandMonument)
									- countAroundComplex($island, $x, $y, $an[1], 0x4))
					) {
					logTyphoonDamage($id, $name, landName($landKind, $lv), "($x, $y)");
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					if($landKind == $HlandComplex) {
						# 복합 지형이면 설정 지형
#						my $cKind = (landUnpack($lv))[1];
						$land->[$x][$y] = $HcomplexAfter[$cKind]->{'typhoon'}[0];
						$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'typhoon'}[1];
						$island->{'complex'}[$cKind]--;
					}
				}
			}
		}
		logTyphoon($id, $name);
	}

	my($map) = $island->{'map'};
	my(@x) = @{$map->{'x'}};
	my(@y) = @{$map->{'y'}};

	# 거대운석판정
	if(($HpunishInfo{$id}->{punish} == 8) || (!$HnoDisFlag && (random(1000) < $HdisHugeMeteo * $disdown * $island->{'itemAbility'}[20]))) {
		my($x, $y, $landKind, $lv, $point);

		# 낙하
		$x = $x[0] + random($HislandSizeX);
		$y = $y[0] + random($HislandSizeY);
		if ($HpunishInfo{$id}->{punish} == 8) {
			$x = $HpunishInfo{$id}->{x};
			$y = $HpunishInfo{$id}->{y};
		}
		$landKind = $land->[$x][$y];
		$lv = $landValue->[$x][$y];
		$point = "($x, $y)";

		# 광역 피해 루틴
		wideDamage($id, $name, $island, $x, $y);
		# 메시지
		logHugeMeteo($id, $name, $point);
	}

	# 거대 미사일판정
	while($island->{'bigmissile'}> 0) {
		$island->{'bigmissile'} --;

		my($x, $y, $landKind, $lv, $point);

		# 낙하
		$x = $x[0] + random($HislandSizeX);
		$y = $y[0] + random($HislandSizeY);
		$landKind = $land->[$x][$y];
		$lv = $landValue->[$x][$y];
		$point = "($x, $y)";

		# 광역 피해 루틴
		wideDamage($id, $name, $island, $x, $y);
		# 메시지
		logMonDamage($id, $name, $point);
	}

	# 운석판정
	if(($HpunishInfo{$id}->{punish} == 9) || (!$HnoDisFlag && (random(1000) < $HdisMeteo * $disdown * $island->{'itemAbility'}[19]))) {
		my($x, $y, $landKind, $lv, $point, $first, $pflag);
		$first = 1;
		$pflag = 1;
		while((random(2) == 0) || ($first == 1)) {
			$first = 0;

			# 낙하
			$x = $x[0] + random($HislandSizeX);
			$y = $y[0] + random($HislandSizeY);
			if ($pflag && ($HpunishInfo{$id}->{punish} == 9)) {
				$x = $HpunishInfo{$id}->{x};
				$y = $HpunishInfo{$id}->{y};
				$pflag = 0;
			}
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			$point = "($x, $y)";

			if(($landKind == $HlandSea) && ($lv == 0)){
				# 바다포차
				logMeteoSea($id, $name, landName($landKind, $lv), $point);
			} elsif($landKind == $HlandSeaMine) {
				# 기뢰
				logMeteoMountain($id, $name, landName($landKind, $lv), $point);
			} elsif($landKind == $HlandMountain) {
				# 산파괴
				logMeteoMountain($id, $name, landName($landKind, $lv), $point);
				$land->[$x][$y] = $HlandWaste;
				$landValue->[$x][$y] = 1;
				next;
			} elsif(($landKind == $HlandSbase) ||
					(($landKind == $HlandCore) && (int($lv / 10000) == 2))) {
				logMeteoSbase($id, $name, landName($landKind, $lv), $point);
			} elsif($landKind == $HlandComplex) {
				# 복합 지형이면 설정 지형
				my $cKind = (landUnpack($lv))[1];
				next if($HcomplexAfter[$cKind]->{'meteo'}[0] eq '');
				$land->[$x][$y] = $HcomplexAfter[$cKind]->{'meteo'}[0];
				$landValue->[$x][$y] = $HcomplexAfter[$cKind]->{'meteo'}[1];
				$island->{'complex'}[$cKind]--;
				logMeteoMountain($id, $name, landName($landKind, $lv), $point);
				next;
			} elsif($landKind == $HlandMonster) {
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
				if ($mFlag & 2) {
					logMeteoMonsterSea($id, $name, landName($landKind, $lv), $point);
				} else {
					logMeteoMonster($id, $name, landName($landKind, $lv), $point);
				}
			} elsif($landKind == $HlandHugeMonster) {
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
				if ($mFlag & 2) {
					logMeteoMonsterSea($id, $name, landName($landKind, $lv), $point);
				} else {
					logMeteoMonster($id, $name, landName($landKind, $lv), $point);
				}
				if($mHflag == 0) {
					my($j, $ssx, $ssy);
					foreach $j (1..6) {
						next if($HhugeMonsterImage[$mKind][$j] eq '');
						$ssx = $x + $ax[$j];
						$ssy = $y + $ay[$j];
						# 행 기준 위치 조정
						$ssx-- if(!($ssy % 2) && ($y % 2));
						$ssx = $correctX[$ssx + $#an];
						$ssy = $correctY[$ssy + $#an];
						# 범위 밖
						next if(($ssx < 0) || ($ssy < 0));

						next if($land->[$ssx][$ssy] != $HlandHugeMonster);
						# 각 요소 꺼내기
						my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1, 2, 4];
						next if($mHflag2 != $j);
						if ($mFlag2 & 2) {
							# 바다에있었음
							$land->[$ssx][$ssy] = $HlandSea;
							$landValue->[$ssx][$ssy] = $mSea2;
						} else {
							# 육지에있었음
							$land->[$ssx][$ssy] = $HlandWaste;
							$landValue->[$ssx][$ssy] = 0;
						}
					}
				}
			} elsif(($landKind == $HlandSea) ||
					(($landKind == $HlandCore) && (int($lv / 10000) == 1))) {
				# 얕은 바다
				logMeteoSea1($id, $name, landName($landKind, $lv), $point);
			} elsif($landKind == $HlandNavy) {
				my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
				my $nSpecial = $HnavySpecial[$nKind];
				my $n = $HidToNumber{$nId};
				$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
				if ($nSpecial & 0x8) {
					# 항구
					$Hislands[$n]->{'navyPort'}-- if(defined $n);
					logMeteoNormal($id, $name, landName($landKind, $lv), $point);
				} else {
					# 기타
					if(defined $n) {
						$Hislands[$n]->{'ships'}[$nNo]--;
						$Hislands[$n]->{'ships'}[4]--;
					}
					logMeteoMountain($id, $name, landName($landKind, $lv), $point);
				}
			} else {
				logMeteoNormal($id, $name, landName($landKind, $lv), $point);
			}
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 0;
		}
	}

	# 분화 판정정
	if(($HpunishInfo{$id}->{punish} == 10) || (!$HnoDisFlag && (random(1000) < $HdisEruption * $disdown * $island->{'itemAbility'}[21]))) {
		my($x, $y, $sx, $sy, $i, $landKind, $lv, $point);
		if($HedgeReclaim) { # 섬의 가장 바깥쪽을 매립 불가로 설정한 경우
			$x = $x[0] + random($HislandSizeX - $HedgeReclaim * 2) + $HedgeReclaim;
			$y = $y[0] + random($HislandSizeY - $HedgeReclaim * 2) + $HedgeReclaim;
		} else {
			$x = $x[0] + random($HislandSizeX);
			$y = $y[0] + random($HislandSizeY);
		}
		if ($HpunishInfo{$id}->{punish} == 10) {
			$x = $HpunishInfo{$id}->{x};
			$y = $HpunishInfo{$id}->{y};
		}
		$landKind = $land->[$x][$y];
		$lv = $landValue->[$x][$y];
		$point = "($x, $y)";
		$land->[$x][$y] = $HlandMountain;
		$landValue->[$x][$y] = 0;
		if($landKind == $HlandNavy) {
			my($nId, $nNo) = (navyUnpack($lv))[0, 6];
			my $n = $HidToNumber{$nId};
			if(defined $n) {
				$Hislands[$n]->{'shipk'}[$nKind]--;
				if($special & 0x8) {
					$Hislands[$n]->{'navyPort'}--;
				} else {
					$Hislands[$n]->{'ships'}[$nNo]--;
					$Hislands[$n]->{'ships'}[4]--;
				}
			}
		}

		my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
		# 거대괴수 처리(코어를 야라이 경우만)
		if(($landKind == $HlandHugeMonster) && ($mHflag == 0)) {
			my($j, $ssx, $ssy);
			foreach $j (1..6) {
				next if($HhugeMonsterImage[$mKind][$j] eq '');
				$ssx = $x + $ax[$j];
				$ssy = $y + $ay[$j];
				# 행 기준 위치 조정
				$ssx-- if(!($ssy % 2) && ($y % 2));
				$ssx = $correctX[$ssx + $#an];
				$ssy = $correctY[$ssy + $#an];
				# 범위 밖
				next if(($ssx < 0) || ($ssy < 0));

				next if($land->[$ssx][$ssy] != $HlandHugeMonster);
				# 각 요소 꺼내기
				my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1, 2, 4];
				next if($mHflag2 != $j);
				if ($mFlag2 & 2) {
					# 바다에있었음
					$land->[$ssx][$ssy] = $HlandSea;
					$landValue->[$ssx][$ssy] = $mSea2;
				} else {
					# 육지에있었음
					$land->[$ssx][$ssy] = $HlandWaste;
					$landValue->[$ssx][$ssy] = 0;
				}
			}
		}

		foreach $i (1..6) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];
			# 행 기준 위치 조정
			$sx-- if(!($sy % 2) && ($y % 2));
			$sx = $correctX[$sx + $#an];
			$sy = $correctY[$sy + $#an];
			# 범위 밖
			next if(($sx < 0) || ($sy < 0));

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";

			# 범위 안의 경우
			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";
			my(@x, @y);
			if($HedgeReclaim) {
				my($map) = $island->{'map'};
				@x = @{$map->{'x'}};
				@y = @{$map->{'y'}};
			}
			if(($landKind == $HlandSea) ||
				($landKind == $HlandOil)) {
				# 바다, 유전의 경우
				if(!$lv || ($HedgeReclaim && (($sx < $HedgeReclaim) || ($sx> $x[$#x] - $HedgeReclaim) || ($sy < $HedgeReclaim) || ($sy> $y[$#y] - $HedgeReclaim)))) {
					logEruptionSea($id, $name, landName($landKind, $lv), $point);
					$land->[$sx][$sy] = $HlandSea;
					$landValue->[$sx][$sy] = 1;
					next;
				} else {
					# 얕은 바다
					logEruptionSea1($id, $name, landName($landKind, $lv), $point);
					next if($HedgeReclaim && (($sx < $HedgeReclaim) || ($sx> $x[$#x] - $HedgeReclaim) || ($sy < $HedgeReclaim) || ($sy> $y[$#y] - $HedgeReclaim))); # 섬의 가장 바깥쪽을 매립 불가로 설정한 경우;
				}
			} elsif(($landKind == $HlandSeaMine) ||
				($landKind == $HlandSbase) ||
				(($landKind == $HlandCore) && (int($lv / 10000) == 2))) {
				# 기뢰, 바다 기준, 해저코어의 경우
				logEruptionSea($id, $name, landName($landKind, $lv), $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 1;
				next;
			} elsif(($landKind == $HlandMountain) ||
				($landKind == $HlandWaste)) {
				next;
			} elsif($landKind == $HlandComplex) {
				# 복합 지형이면 설정 지형
				my $cKind = (landUnpack($lv))[1];
				next if($HcomplexAfter[$cKind]->{'eruption'}[0] eq '');
				$land->[$sx][$sy] = $HcomplexAfter[$cKind]->{'eruption'}[0];
				$landValue->[$sx][$sy] = $HcomplexAfter[$cKind]->{'eruption'}[1];
				$island->{'complex'}[$cKind]--;
				logEruptionNormal($id, $name, landName($landKind, $lv), $point);
				next;
			} elsif(($landKind == $HlandMonster) || ($landKind == $HlandHugeMonster)) {
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
				if((($mFlag & 2) && !$mSea) || ($HedgeReclaim && (($sx < $HedgeReclaim) || ($sx> $x[$#x] - $HedgeReclaim) || ($sy < $HedgeReclaim) || ($sy> $y[$#y] - $HedgeReclaim)))) {
					logEruptionSea3($id, $name, landName($landKind, $lv), $point);
					$mSea = 1;
				} else {
					logEruptionSea2($id, $name, landName($landKind, $lv), $point);
					$mFlag &= ~2;
					$mSea = 0;
				}
				$landValue->[$sx][$sy] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
				next;
			} elsif($landKind == $HlandNavy) {
				my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
				my $nSpecial = $HnavySpecial[$nKind];
				my $n = $HidToNumber{$nId};
				$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
				if ($nSpecial & 0x8) {
					# 항구는 육지
					logEruptionSea1($id, $name, landName($landKind, $lv), $point);
					$land->[$sx][$sy] = $HlandWaste;
					$landValue->[$sx][$sy] = 0;
					$Hislands[$n]->{'navyPort'}-- if(defined $n);
				} else {
					if(!$nSea || ($HedgeReclaim && (($sx < $HedgeReclaim) || ($sx> $x[$#x] - $HedgeReclaim) || ($sy < $HedgeReclaim) || ($sy> $y[$#y] - $HedgeReclaim)))) {
						# 기타는 얕은 바다
						logEruptionSea($id, $name, landName($landKind, $lv), $point);
						$land->[$sx][$sy] = $HlandSea;
						$landValue->[$sx][$sy] = 1;
					} else {
						# 얕은 바다는 육지
						logEruptionSea1($id, $name, landName($landKind, $lv), $point);
						$land->[$sx][$sy] = $HlandWaste;
						$landValue->[$sx][$sy] = 0;
					}
					if(defined $n) {
						$Hislands[$n]->{'ships'}[$nNo]--;
						$Hislands[$n]->{'ships'}[4]--;
					}
				}
				next;
			} else {
				# 그 외의 경우
				logEruptionNormal($id, $name, landName($landKind, $lv), $point);
			}
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
		}
		logEruption($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), "($x, $y)");
	}
}

# 섬 전체(estimate 처리)
sub doIslandProcessEstimate {
	my($number, $island) = @_;

	# 도출 값
	my($name) = islandName($island);;
	my($id) = $island->{'id'};

	# 식량이 넘치면 환전
	my $fflag = $island->{'itemAbility'}[7];
	if($island->{'food'}> int($HmaximumFood * $fflag)) {
		$island->{'money'} += int(($island->{'food'} - ($HmaximumFood * $fflag)) / 10);
		$island->{'food'} = int($HmaximumFood * $fflag);
	}

	#자금이 넘치면 잘라냄
	my $mflag = $island->{'itemAbility'}[8];
	if($island->{'money'}> int($HmaximumMoney * $mflag)) {
		$island->{'money'} = int($HmaximumMoney * $mflag) ;
	}

	# 각종의 값을 계산
	estimate($number);

	# 각종훈장장 수상
	$island->{'damage'} = $island->{'oldPop'} - $island->{'pop'};
	my($prize) = $island->{'prize'};
	$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
	my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);

	my($value, $thres, $p);
	my($f) = 1;
	foreach $p (1..$#Hprize) {
		if (!($flags & $f)) {
			$value = (!$Hprize[$p]->{'ptr'} ? $island->{$Hprize[$p]->{'kind'}} : $island->{$Hprize[$p]->{'kind'}}[$Hprize[$p]->{'ptr'}]);
			$thres = $Hprize[$p]->{'threshold'};
			if ($value>= $thres) {
				$flags |= $f; # 수훈장
				$island->{'ext'}[1] += $Hprize[$p]->{'contribution'}; # 공헌도 up
				if($Hprize[$p]->{'money'}) {
					$island->{'prizemoney'} += $Hprize[$p]->{'money'};
					$island->{'money'} += $Hprize[$p]->{'money'};
				}
				logPrize($id, $name, $Hprize[$p]->{'name'}, $Hprize[$p]->{'money'});
			}
		}
		$f *= 2;
	}

	$island->{'prize'} = "$flags,$monsters,$hmonsters,$turns";

}

# 괴수출현
sub bringMonster {
	my($island, $tId, $mKind, $huge, $num) = @_;

	my $id = $island->{'id'};
	my $name = islandName($island);
	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};

	# flag : bit0=경화, bit1=잠수
	my $mHp = (!$huge) ? ($HmonsterBHP[$mKind] + random($HmonsterDHP[$mKind])) : ($HhugeMonsterBHP[$mKind] + random($HhugeMonsterDHP[$mKind]));
	my $mLv = monsterPack($tId, 0, 0, 0, 2, $mKind, $mHp);

	makeRandomIslandPointArray($island);
	my($i, $x, $y, $lv);
	my $count = 0;
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		$lv = $landValue->[$x][$y];

		# 깊은 바다를 탐색(괴수는 깊은 바다에잠수무)
		next unless (($land->[$x][$y] == $HlandSea) && !$lv);

		# 거대괴수의 경우
		if($huge) {
			my($j, $sx, $sy);
			my $dmove = 0;
			foreach $j (1..6) {
				next if($HhugeMonsterImage[$mKind][$j] eq '');
				$sx = $x + $ax[$j];
				$sy = $y + $ay[$j];
				# 행 기준 위치 조정
				$sx-- if(!($sy % 2) && ($y % 2));
				$sx = $correctX[$sx + $#an];
				$sy = $correctY[$sy + $#an];

				# 범위 밖 판정
				if(($sx < 0) || ($sy < 0)) {
					$dmove = 1;
				}
				if($HoceanMode && $HfieldUnconnect && ($HlandID[$sx][$sy] != $id)) {
					my $mn = $HidToNumber{$HlandID[$sx][$sy]};
					$dmove = 1 if(((defined $mn) && $Hislands{$mn}->{'field'}) || $island->{'field'});
				}
				# 바다외이면 출현할 수 없
				if($land->[$sx][$sy] != $HlandSea) {
					$dmove = 1;
				}
			}
			next if($dmove);
		}

		# 지형 이름
		my $lName = landName($HlandSea, $lv);

		# 괴수를 배치
		if($huge) {
			# 거대괴수의 경우
			my($j, $sx, $sy, $mSea, $mFlag);
			foreach $j (0..6) {
				next if($HhugeMonsterImage[$mKind][$j] eq '');
				$sx = $x + $ax[$j];
				$sy = $y + $ay[$j];
				# 행 기준 위치 조정
				$sx-- if(!($sy % 2) && ($y % 2));
				$sx = $correctX[$sx + $#an];
				$sy = $correctY[$sy + $#an];
				# 범위 밖
				next if(($sx < 0) || ($sy < 0));
				if($HoceanMode && $HfieldUnconnect && ($HlandID[$sx][$sy] != $id)) {
					my $mn = $HidToNumber{$HlandID[$sx][$sy]};
					next if(((defined $mn) && $Hislands{$mn}->{'field'}) || $island->{'field'});
				}

				$mSea = $landValue->[$sx][$sy];
				$mFlag |= 2;

				$land->[$sx][$sy] = $HlandHugeMonster;
				$landValue->[$sx][$sy] = monsterPack($tId, $j, $mSea, 0, $mFlag, $mKind, $mHp);
			}
		} else {
			$land->[$x][$y] = $HlandMonster;
			$landValue->[$x][$y] = $mLv;
		}

		# 이동 완료로
		$HmonsterMove[$id][$x][$y] = 2;

		# 괴수 이름
		my $mName = (!$huge) ? $HmonsterName[$mKind] : $HhugeMonsterName[$mKind];

		# 메시지
		logMonsCome($id, $name, $mName, "($x, $y)", $lName);
		last if(++$count>= $num);
	}
}

# 함정 출현
sub bringNavy {
	my($island, $nKind, $num) = @_;

	my $id = $island->{'id'};
	my $name = islandName($island);
	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};

	my $nLv = navyPack(0, 0, 0, 0, 0, 0, 0, $nKind, $HnavyHP[$nKind]);

	makeRandomIslandPointArray($island);
	my($i, $x, $y, $lv);
	my $count = 0;
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		$lv = $landValue->[$x][$y];

		# 깊은 바다를 탐색
		next unless (($land->[$x][$y] == $HlandSea) && !$lv);

		# 지형 이름
		my $lName = landName($HlandSea, $lv);

		# 함정 배치
		$land->[$x][$y] = $HlandNavy;
		$landValue->[$x][$y] = $nLv;

		# 이동 완료로
		$HnavyMove[$id][$x][$y] = 2;

		# 함정 이름
		my $nName = $HnavyName[$nKind];

		# 메시지
		logNavyCome($id, $name, $nName, "($x, $y)", $lName);
		last if(++$count>= $num);
	}
}

# 코어출현
sub randomBuildCore {
	my($island, $num, $lvmin, $lvmax, $log) = @_;

	my $id = $island->{'id'};
	my $name = islandName($island);
	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};

	makeRandomIslandPointArray($island);
	my($i, $x, $y, $l, $lv);
	my $count = 0;
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];
		$l = $land->[$x][$y];
		$lv = $landValue->[$x][$y];

		# 바다, 얕은 바다, 평지, 황무지를 찾음
		next if(($l != $HlandSea) && ($l != $HlandPlains) && ($l != $HlandWaste));

		# 지형 이름
		my $lName = landName($l, $lv);

		# 코어를 배치
		$land->[$x][$y] = $HlandCore;
		$lvmin = $HdurableCore if($lvmin> $HdurableCore);
		$lvmax = $HdurableCore if($lvmax> $HdurableCore);
		$lvmin = $lvmax if($lvmin> $lvmax);
		$landValue->[$x][$y] = $lvmin + random($lvmax - $lvmin + 1);
		if($l == $HlandSea) {
			$landValue->[$x][$y] += (!$lv) ? 20000 : 10000; # 바다, 얕은 바다
		}

		# 코어 이름
		my $nName = landName($land->[$x][$y], $landValue->[$x][$y]);
		my $point = ($HcoreHide) ? "(?, ?)" : "($x, $y)";

		# 메시지
		logCoreRandomBuild($id, $name, $nName, $point, $lName) if($log);
		$island->{'core'}++;
		last if(++$count>= $num);
	}
}

# 복합 지형건설
sub buildComplex {
	my($island, $comName, $kind, $rep, $x, $y) = @_;

	my $id = $island->{'id'};
	my $name = islandName($island);
	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};
	my $point = "($x, $y)";

	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];
	my($landName) = landName($landKind, $lv);

	my($cTmp, $cKind, $cTurn, $cFood, $cMoney);
	my $clflag = 1;
	if($landKind != $HlandComplex) {
		$clflag = 0;
		foreach (@{$HcomplexBefore[$HcomplexComKind[$kind]]}) {
			if(($landKind == $_->[0]) && ($_->[1] <= $lv) && ($lv <= $_->[2])) {
				$clflag = 1;
				last;
			}
		}
	}
	if(!$clflag) {
		# 부적절나 지형
		logLandFail($id, $name, $comName, $landName, $point);
		return 0;
	} elsif($landKind == $HlandComplex) {
		# 이미복합 지형의 경우
		($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($lv);
		my $landCheck = ($HcomplexComKind[$kind] != $cKind) ? 1 : 0;
		foreach (@{$HcomplexBefore2[$HcomplexComKind[$kind]]}) {
			if($cKind == $_) {
				$landCheck = 0;
				last;
			}
		}
		if($landCheck || (!$HcomplexTPCmax[$cKind] && !$HcomplexFPCmax[$cKind] && !$HcomplexMPCmax[$cKind])) {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		if(($HcomplexComKind[$kind] != $cKind) || !($HcomplexComFlag[$kind] & 0x7)) {
			# 대상 위치를 복합 지형에
			if($HcomplexMax[$HcomplexComKind[$kind]] && $island->{'complex'}[$HcomplexComKind[$kind]]>= $HcomplexMax[$HcomplexComKind[$kind]]) {
				# 보유 가능 최대 수 초과
				logOverFail($id, $name, $comName, $point);
				return 0;
			}
			$island->{'complex'}[$cKind]--;
			$land->[$x][$y] = $HlandComplex;
			$cKind = $HcomplexComKind[$kind];
			$island->{'complex'}[$cKind]++;
			($cTurn, $cFood, $cMoney) = (1, 0, 0);
		} else {
			# 식량 플래그 처리
			$cFood += $rep if($HcomplexComFlag[$kind] & 0x2);
			#자금 플래그 처리
			$cMoney += $rep if($HcomplexComFlag[$kind] & 0x4);
			if($HcomplexComFlag[$kind] & 0x1) {
				# 턴 플래그배치환 처리
				my $income = $HcomplexComTFInCome[$kind];
				my $incomeValue = $cTurn * $income->{'ratio'};
				if($income->{'log'} eq 'normal') {
					$island->{$income->{'type'}} += $incomeValue;
					logOilMoney($id, $name, $HcomplexName[$cKind], $point, "$incomeValue${HunitMoney}", $income->{'logstr'});
				} else {
					$island->{'cIncome'}[$kind] += $incomeValue;
				}
				# 턴 플래그 재설정
				if($HcomplexComTFRL[$kind][0] ne '') {
					$land->[$x][$y] = $HcomplexComTFRL[$kind][0];
					$landValue->[$x][$y] = $HcomplexComTFRL[$kind][1];
					return 0;
				} else {
					$cTurn = 0;
				}
			}
		}
	} else {
		if($HcomplexMax[$HcomplexComKind[$kind]] && $island->{'complex'}[$HcomplexComKind[$kind]]>= $HcomplexMax[$HcomplexComKind[$kind]]) {
			# 보유 가능 최대 수 초과
			logOverFail($id, $name, $comName, $point);
			return 0;
		}
		# 대상 위치를 복합 지형에
		$land->[$x][$y] = $HlandComplex;
		$cKind = $HcomplexComKind[$kind];
		$island->{'complex'}[$cKind]++;
		($cTurn, $cFood, $cMoney) = (1, 0, 0);
		if($rep> 1) {
			$cFood += ($rep-1) if($HcomplexComFlag[$kind] & 0x2);
			$cMoney += ($rep-1) if($HcomplexComFlag[$kind] & 0x4);
		}
	}
	$cTurn = $HcomplexTPCmax[$cKind] if($cTurn> $HcomplexTPCmax[$cKind]);
	$cFood = $HcomplexFPCmax[$cKind] if($cFood> $HcomplexFPCmax[$cKind]);
	$cMoney = $HcomplexMPCmax[$cKind] if($cMoney> $HcomplexMPCmax[$cKind]);
	$landValue->[$x][$y] = landPack($cTmp, $cKind, $cTurn, $cFood, $cMoney);
	logLandSuc($id, $name, $comName, $point);
	return 1;
}

# 함정건조(항구도포함무)
sub buildNavy {
	my($island, $comName, $nKind, $nNo, $nx, $ny) = @_;

	my $id = $island->{'id'};
	my $name = islandName($island);
	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};
	my $point = "($nx, $ny)";

	# 4함대만
	$nNo--;
	if ($nNo < 0) {
		$nNo = 0;
	} elsif ($nNo> 3) {
		$nNo = 3;
	}

	# flag : bit0=잔해, bit1=잠수
	my $nLv = navyPack($id, 0, 0, 0, 0, 0, $nNo, $nKind, $HnavyHP[$nKind]);
	my $nSpecial = $HnavySpecial[$nKind];
	my $ofname = $island->{'fleet'}->[$nNo];

	# 건조레벨 확인
	if($HmaxComNavyLevel) {
		my $navyComLevel = gainToLevel($island->{'gain'});
		if($HcomNavyNumber[$navyComLevel-1] < $nKind) {
			logNavyNoExp($id, $name, $comName);
			return 0;
		}
	}
	# 보유 가능 함정 수 확인
	my $nflag = int($island->{'itemAbility'}[3]);
	my $nflagk = (!$#HnavyName) ? 1 : int($nflag/$#HnavyName);
	$nflagk = 1 if($nflag && ($nflagk < 1));
	if($HnavyKindMax[$nKind] && ($island->{'shipk'}[$nKind]>= $HnavyKindMax[$nKind] + $nflagk)) {
		logNavyKindMaxOver($id, $name, $comName);
		return 0;
	}

	my($i, $x, $y, $lv);

	if ($nSpecial & 0x8) {
		# 군항 건설
		if($HedgeReclaim) { # 섬의 가장 바깥쪽을 매립 불가로 설정한 경우
			my($map) = $island->{'map'};
			my(@x) = @{$map->{'x'}};
			my(@y) = @{$map->{'y'}};
			if(($nx < $x[0] + $HedgeReclaim) || ($nx> $x[$#x] - $HedgeReclaim) || ($ny < $y[0] + $HedgeReclaim) || ($ny> $y[$#y] - $HedgeReclaim)) {
				logLandFail($id, $name, $comName, "섬의 가장 바깥쪽", $point);
				return 0;
			}
		}
		# 항구이면 위치지정
		$lv = $landValue->[$nx][$ny];
		if (($land->[$nx][$ny] == $HlandSea) && ($lv == 1)) {
			# 얕은 바다이면 건설
			$land->[$nx][$ny] = $HlandNavy;
			$landValue->[$nx][$ny] = $nLv;
			$island->{'navyPort'}++;
			# 메시지
			logLandSuc($id, $name, $comName, $point);
			return 1;
		} else {
			# 기타는 실패
			my $landKind = $land->[$nx][$ny];
			my $lv = $landValue->[$nx][$ny];
			my $landName = landName($landKind, $lv);
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
	}

	if($HnavyMaximum && ($island->{'ships'}[4]>= $HnavyMaximum + $nflag)) {
		logNavyMaxOver($id, $name, $comName);
		return 0;
	} elsif($island->{'navyPort'} && $HportRetention && ($island->{'ships'}[4]>= $island->{'navyPort'} * $HportRetention + $nflag)) {
		logFleetMaxOver($id, $name, $comName, "1군항주변");
		return 0;
	} elsif($HfleetMaximum && ($island->{'ships'}[$nNo]>= $HfleetMaximum + int($nflag/4))) {
		logFleetMaxOver($id, $name, $comName, "${ofname}함대");
		return 0;
	}

	my($p, $px, $py);
	if($HnavyBuildFlag) {
		($p, $px, $py) = searchNavyPort($island, $nx, $ny, $an[1]);
		if(!$p) {
#		unless(countAroundNavySpecial($island, $nx, $ny, 0x8, $an[1], 0)) {
			# 함정을 건조하려면 군항이 필요
			logNavyNoPort($id, $name, $comName, "($nx, $ny)");
			return 0;
		}

		$lv = $landValue->[$nx][$ny];
		# 깊은 바다가 아니면건조할 수 없
		unless (($land->[$nx][$ny] == $HlandSea) && !$lv) {
			logNavyNoSea($id, $name, $comName, "($nx, $ny)");
			return 0;
		}
		my($pId, $pTmp, $pStat, $pSea, $pExp, $pFlag, $pNo, $pKind, $pHp) = navyUnpack($landValue->[$px][$py]);
		# 군항의 건조레벨 확인
		if($HmaxComPortLevel && ($HcomNavyNumber[(expToLevel($HlandNavy, $pExp) - 1)] < $nKind)) {
			logNavyNoExp($id, $name, $comName, "($nx, $ny)");
			return 0;
		}

		# 함정 배치
		$land->[$nx][$ny] = $HlandNavy;
		$landValue->[$nx][$ny] = $nLv;
		$island->{'shipk'}[$nKind]++;
		$island->{'ships'}[$nNo]++;
		$island->{'ships'}[4]++;

		# 이동 완료로
		$HnavyMove[$id][$nx][$ny] = 2;

		# 함정 이름
		my $nName = $HnavyName[$nKind];

		# 메시지
		logNavyBuild($id, $name, $ofname, $nName, "($nx, $ny)");

		# 군항에경험치
		$pExp += $HnavyBuildExp[$nKind];
		$pExp = $HmaxExpNavy if ($pExp> $HmaxExpNavy);
		$landValue->[$px][$py] = navyPack($pId, $pTmp, $pStat, $pSea, $pExp, $pFlag, $pNo, $pKind, $pHp);

		return 1;
	} else {
		if($island->{'navyPort'} < 1) {
			# 함정을 건조하려면 군항이 필요
			logNavyNoPort($id, $name, $comName);
			return 0;
		}

		# 모라고도근처이군항의 건조레벨 확인
		($p, $px, $py) = searchNavyPort($island, $nx, $ny, 0);
		my($pId, $pTmp, $pStat, $pSea, $pExp, $pFlag, $pNo, $pKind, $pHp) = navyUnpack($landValue->[$px][$py]);
		if($HmaxComPortLevel && ($HcomNavyNumber[(expToLevel($HlandNavy, $pExp) - 1)] < $nKind)) {
			logNavyNoExp($id, $name, $comName, "($nx, $ny)");
			return 0;
		}
		foreach $i (0..$island->{'pnum'}) {
			$x = $island->{'rpx'}[$i];
			$y = $island->{'rpy'}[$i];
			$lv = $landValue->[$x][$y];

			# 깊은 바다를 탐색
			next unless (($land->[$x][$y] == $HlandSea) && !$lv);

			# 함정 배치
			$land->[$x][$y] = $HlandNavy;
			$landValue->[$x][$y] = $nLv;
			$island->{'shipk'}[$nKind]++;
			$island->{'ships'}[$nNo]++;
			$island->{'ships'}[4]++;

			# 이동 완료로
			$HnavyMove[$id][$x][$y] = 2;

			# 함정 이름
			my $nName = $HnavyName[$nKind];

			# 메시지
			logNavyBuild($id, $name, $ofname, $nName, "($x, $y)");

			# 군항에경험치
			$pExp += $HnavyBuildExp[$nKind];
			$pExp = $HmaxExpNavy if ($pExp> $HmaxExpNavy);
			$landValue->[$px][$py] = navyPack($pId, $pTmp, $pStat, $pSea, $pExp, $pFlag, $pNo, $pKind, $pHp);

			return 1;
		}
	}

	# 함정을 배치할 바다가 없음
	logNavyNoSea($id, $name, $comName);
	return 0;
}

# 광역 피해 루틴
sub wideDamage {
	my($id, $name, $island, $x, $y) = @_;
	my($land, $landValue) = ($island->{'land'}, $island->{'landValue'});
	my($sx, $sy, $i, $landKind, $landName, $lv, $point);

	foreach $i (0..18) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖
		next if(($sx < 0) || ($sy < 0));

		$landKind = $land->[$sx][$sy];
		$lv = $landValue->[$sx][$sy];
		$landName = landName($landKind, $lv);
		$point = "($sx, $sy)";

		# 범위에 한분기
		if($i < 7) {
			# 중심 및 1헥스
			if($landKind == $HlandSea) {
				$landValue->[$sx][$sy] = 0;
				next;
			} elsif(($landKind == $HlandSbase) ||
					($landKind == $HlandOil) ||
					(($landKind == $HlandCore) && int($lv / 10000))) {
				logWideDamageSea2($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			} elsif($landKind == $HlandSeaMine) {
				logWideDamageMonster($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			} elsif($landKind == $HlandComplex) {
				# 복합 지형이면 설정 지형
				my $cKind = (landUnpack($lv))[1];
				if($HcomplexAfter[$cKind]->{'wide1'}[0] ne '') {
					$land->[$sx][$sy] = $HcomplexAfter[$cKind]->{'wide1'}[0];
					$landValue->[$sx][$sy] = $HcomplexAfter[$cKind]->{'wide1'}[1];
					$island->{'complex'}[$cKind]--;
					logWideDamageMonster($id, $name, $landName, $point);
				}
			} elsif(($landKind == $HlandMonster) || ($landKind == $HlandHugeMonster)){
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
				$land->[$sx][$sy] = $HlandSea;
				if (($i == 0) || ($mFlag & 2)) {
					# 바다
					$landValue->[$sx][$sy] = 0;
					logWideDamageMonsterSea2($id, $name, $landName, $point);
				} else {
					# 얕은 바다
					$landValue->[$sx][$sy] = 1;
					logWideDamageMonsterSea($id, $name, $landName, $point);
				}
			} elsif($landKind == $HlandNavy) {
				my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
				my $nSpecial = $HnavySpecial[$nKind];
				my $n = $HidToNumber{$nId};
				$land->[$sx][$sy] = $HlandSea;
				$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
				if(($i != 0) && ($nSpecial & 0x8)) {
					# 항구는 얕은 바다
					$landValue->[$sx][$sy] = 1;
					$Hislands[$n]->{'navyPort'}-- if(defined $n);
					logWideDamageSea($id, $name, $landName, $point);
				} else {
					# 기타는 바다
					$landValue->[$sx][$sy] = 0;
					if(defined $n) {
						$Hislands[$n]->{'ships'}[$nNo]--;
						$Hislands[$n]->{'ships'}[4]--;
					}
					logWideDamageMonster($id, $name, $landName, $point);
				}
			} else {
				logWideDamageSea($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				if($i == 0) {
					# 바다
					$landValue->[$sx][$sy] = 0;
				} else {
					# 얕은 바다
					$landValue->[$sx][$sy] = 1;
				}
			}
		} else {
			# 2헥스
			if(($landKind == $HlandSea) ||
				($landKind == $HlandOil) ||
				($landKind == $HlandSeaMine) ||
				($landKind == $HlandWaste) ||
				($landKind == $HlandMountain) ||
				($landKind == $HlandSbase) ||
				(($landKind == $HlandCore) && (int($lv / 10000) == 2))) {
				next;
			} elsif($landKind == $HlandComplex) {
				# 복합 지형이면 설정 지형
				my $cKind = (landUnpack($lv))[1];
				if($HcomplexAfter[$cKind]->{'wide2'}[0] ne '') {
					$land->[$sx][$sy] = $HcomplexAfter[$cKind]->{'wide2'}[0];
					$landValue->[$sx][$sy] = $HcomplexAfter[$cKind]->{'wide2'}[1];
					$island->{'complex'}[$cKind]--;
					logWideDamageMonster($id, $name, $landName, $point);
				}
			} elsif($landKind == $HlandMonster) {
				logWideDamageMonster($id, $name, $landName, $point);
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
				if ($mFlag & 2) {
					$land->[$sx][$sy] = $HlandSea;
				} else {
					$land->[$sx][$sy] = $HlandWaste;
				}
				$landValue->[$sx][$sy] = 0;
			} elsif($landKind == $HlandHugeMonster) {
				logWideDamageMonster($id, $name, $landName, $point);
				my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
				if ($mFlag & 2) {
					$land->[$sx][$sy] = $HlandSea;
				} else {
					$land->[$sx][$sy] = $HlandWaste;
				}
				$landValue->[$sx][$sy] = 0;
				if($mHflag == 0) {
					my($j, $ssx, $ssy);
					foreach $j (1..6) {
						next if($HhugeMonsterImage[$mKind][$j] eq '');
						$ssx = $sx + $ax[$j];
						$ssy = $sy + $ay[$j];
						# 행 기준 위치 조정
						$ssx-- if(!($ssy % 2) && ($sy % 2));
						$ssx = $correctX[$ssx + $#an];
						$ssy = $correctY[$ssy + $#an];
						# 범위 밖
						next if(($ssx < 0) || ($ssy < 0));

						next unless($land->[$ssx][$ssy] == $HlandHugeMonster);
						# 각 요소 꺼내기
						my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1, 2, 4];
						next if($mHflag2 != $j);
						if ($mFlag2 & 2) {
							# 바다에있었음
							$land->[$ssx][$ssy] = $HlandSea;
							$landValue->[$ssx][$ssy] = $mSea2;
						} else {
							# 육지에있었음
							$land->[$ssx][$ssy] = $HlandWaste;
							$landValue->[$ssx][$ssy] = 0;
						}
					}
				}
			} elsif($landKind == $HlandNavy) {
				my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($lv);
				my $nSpecial = $HnavySpecial[$nKind];
				my $n = $HidToNumber{$nId};
				$land->[$sx][$sy] = $HlandSea;
				$Hislands[$n]->{'shipk'}[$nKind]-- if(defined $n);
				if ($nSpecial & 0x8) {
					# 항구는 얕은 바다
					$landValue->[$sx][$sy] = 1;
					$Hislands[$n]->{'navyPort'}-- if(defined $n);
					logWideDamageSea($id, $name, $landName, $point);
				} else {
					# 기타는 바다
					$landValue->[$sx][$sy] = 0;
					if(defined $n) {
						$Hislands[$n]->{'ships'}[$nNo]--;
						$Hislands[$n]->{'ships'}[4]--;
					}
					logWideDamageMonster($id, $name, $landName, $point);
				}
			} elsif(($landKind == $HlandBouha) ||
					(($landKind == $HlandCore) && (int($lv / 10000) == 1))) {
				logWideDamageSea($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 1;
				$island->{'bouha'}--;
			} else {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
			}
		}
	}
}

# 전쟁 상태를 판정(2섬간의 전쟁상태)
sub chkWarIsland {
	my($id, $tId) = @_;
	return 2 if(($id == 0) || ($tId == 0));
	my($i);
	for($i=0;$i < $#HwarIsland;$i+=4){
		my($wid1) = $HwarIsland[$i+1];
		my($wid2) = $HwarIsland[$i+2];
		my($tn1) = $HidToNumber{$wid1};
		my($tn2) = $HidToNumber{$wid2};
		if(($tn1 eq '') || ($tn2 eq '')){
			splice(@HwarIsland,$i,4);
			$i -= 4;
			next;
		}
		if((($wid1 == $id) && ($wid2 == $tId)) || (($wid1 == $tId) && ($wid2 == $id))){
			if($HwarIsland[$i]> $HislandTurn) {
				# 전쟁준비안(유예 기간)
				return 1;
			} else {
				# 전쟁안
				return 2;
			}
		}
	}
	return 0;
}

# 전쟁 상태를 판정(1섬의 전쟁상태)
sub chkWarIslandOR {
	my($id, $tId) = @_;
	return 2 if(($id == 0) || ($tId == 0));
	my($i, %chkFlag);
	for($i=0;$i < $#HwarIsland;$i+=4){
		my($wid1) = $HwarIsland[$i+1];
		my($wid2) = $HwarIsland[$i+2];
# chkWarIsland 의남은 에 사용간은 불필요한 처리
#		my($tn1) = $HidToNumber{$HwarIsland[$i+1]};
#		my($tn2) = $HidToNumber{$HwarIsland[$i+2]};
#		if(($tn1 eq '') || ($tn2 eq '')){
#			splice(@HwarIsland,$i,4);
#			$i -= 4;
#			next;
#		}
		$chkFlag{$wid1} = $wid2;
		$chkFlag{$wid2} = $wid1;
	}
	if($chkFlag{$id}) {
		return $chkFlag{$id};
	} elsif($chkFlag{$tId}) {
		return $chkFlag{$tId};
	}
	return 0;
}

# 로그로 출력
# 제1인 수:메시지
# 제2인 수:당사자
# 제3인 수:상대
# 제4인 수:상대2
# 일반 로그
sub logOut {
	push(@HlogPool,"0,$HislandTurn,$_[1],$_[2],$_[3],$_[0]");
}

# 지연 로그
sub logLate {
	push(@HlateLogPool,"0,$HislandTurn,$_[1],$_[2],$_[3],$_[0]");
}

# 기밀 로그
sub logSecret {
	push(@HsecretLogPool,"1,$HislandTurn,$_[1],$_[2],$_[3],$_[0]");
}

# 기록 로그
sub logHistory {
	push(@HhistoryLogPool,"$HislandTurn,$_[0]\n");
}

# 로그 쓰기
sub logFlush {
	open(LOUT, ">${HdirName}/0$HlogData");
	# 전체를 역순으로 출력
	foreach (reverse(@HlogPool, @HlateLogPool, @HsecretLogPool)) {
		next if($_ eq ',,,,,');
		print LOUT $_. "\n";
	}
	close(LOUT);

	# 기록 로그 쓰기와 조정
	open(HIN, "${HdirName}/hakojima.his");
	my @lines = <HIN>;
	close(HIN);
	@lines = (@lines, @HhistoryLogPool);
	while ($HhistoryMax < @lines) { shift @lines; }
	open(HOUT, ">${HdirName}/hakojima.his");
	print HOUT @lines;
	close(HOUT);

	undef @HsecretLogPool;
	undef @HlateLogPool;
	undef @HlogPool;
	undef @HhistoryLogPool;
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
# 섬포인트지정 로그 템플릿
sub logIslpnt {
	my($id, $name, $point, $tId, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}$str",$id, $tId);
}

#아이템 발견
sub logItemGetLucky {
	my($id, $name, $point, $itemName, $str) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의${str},<B>$itemName</B>을 발견했습니다!",$id);
}

#아이템 발견2
sub logItemGetLucky2 {
	my($id, $name, $point, $itemName, $str) = @_;
	logOut(" --- ${HtagName_}${point}${H_tagName}의${str},${HtagMoney_}${itemName}${H_tagMoney}을 발견했습니다!",$id);
}

#아이템소실
sub logItemLost {
	my($id, $name, $itemName, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}의${str},<B>$itemName</B>이소실했습니다!",$id);
}

# 함정, 해저 탐사안침몰
sub logProbeDestroy {
	my($id, $name, $nId, $nPoint, $nName) = @_;
	logOut("${HtagName_}${name}${nPoint}${H_tagName}의${HtagName_}${nName}${H_tagName}이 해저 탐사안에<B>통신이 도중에 끊겼습니다</B>.<B>$nName</B>은${HtagDisaster_}침몰${H_tagDisaster}한 것 같습니다.",$id, $nId);
}

# 해저 탐색에서 수입
sub logTansaku {
	my($id, $name, $nId, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이 보물을 발견!${HtagMoney_}${str}${H_tagMoney}의 가치가 있는 것으로 확인되었습니다.",$id, $nId);
	logHistory("${HtagName_}${name}${H_tagName}의<B>$lName</B>이 보물을 발견!");
}

# 해적 행위
sub logPirates {
	my($id, $name, $point, $nId, $nName, $nPoint, $str) = @_;
	logOut("${HtagName_}${name}$nPoint${H_tagName}의<B>$nName</B>이${HtagName_}$point${H_tagName}지점에서$str 을<B>략탈취</B>했습니다.",$id, $nId);
}

# 함정, 기뢰에서 침몰
sub logSeaMineDestroy {
	my($id, $name, $nId, $nPoint, $nName) = @_;
	logOut("${HtagName_}${name}${nPoint}${H_tagName}의${HtagName_}${nName}${H_tagName}이<B>기뢰에 접촉시대파괴</B>.<B>$nName</B>은${HtagDisaster_}침몰${H_tagDisaster}했습니다.",$id, $nId);
}

# 함정, 기뢰에서 피해
sub logSeaMineDamage {
	my($id, $name, $nId, $nPoint, $nName) = @_;
	logOut("${HtagName_}${name}${nPoint}${H_tagName}의${HtagName_}${nName}${H_tagName}이<B>기뢰에 접촉</B>.<B>$nName</B>은 검은 연기를 내뿜었습니다.",$id, $nId);
}

# 괴수, 기뢰에서 살상
sub logMonsSeaMineDestroy {
	my($id, $name, $lName, $point, $mName, $mId) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에<B>$mName</B>이접속접촉.<B>$mName</B>은 힘이 다해 해저에 ${HtagDisaster_}가라앉았습니다${H_tagDisaster}.",$id, $mId);
}

# 괴수, 기뢰에서 살상
sub logMonsSeaMineDamage {
	my($id, $name, $lName, $point, $mName, $mId) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에<B>$mName</B>이접속접촉.<B>$mName</B>은 고생할 듯한에포효포효했습니다.",$id, $mId);
}

# 함정 공격, 괴수가 미사일 공격, 기뢰에 명중
sub logNavySeaMine {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은 사라졌습니다.",$id, $nId);
}

#자금 부족
sub logNoMoney {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,자금이 부족해 중지되었습니다.",$id);
}

# 식량 부족
sub logNoFood {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 비축 식량 부족으로 중지되었습니다.",$id);
}

# 개발 기간에 한실패
sub logDevelopTurnFail {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,${AfterName}을 발견 직후의<B>개발 기간</B>이기 때문에 중지되었습니다.",$id);
}

# 개발 기간초과로 인한 실패
sub logDevelopTurnFail2 {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,${AfterName}을 발견 직후의<B>개발 기간을 초과했기 때문에</B> 중지되었습니다.",$id);
}

# 무역능력 함정을 파견하고 있지 않어서 지원 실패
sub logTradeFail {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>지원 가능한 함정이 파견되어 있지 않기 때문에</B> 중지되었습니다.",$id);
}

# 함정 이동, 실패
sub logMoveFail {
	my($id, $name, $point,$str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}지점에 대한 이동 지령은$str 실행되지 않았습니다.",$id);
}

# 일괄 땅고르기
sub logAllPrepare {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}$comName${H_tagComName}이 실행되었습니다.",$id);
}

# 보유 가능 횟수 초과(기뢰·방파제·복합 지형)
sub logOverFail {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 보유 가능 횟수를 초과했기 때문에 중지되었습니다.",$id);
}

# 대상 지형 종류가 맞지 않아 실패
sub logLandFail {
	my($id, $name, $comName, $kind, $point) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName}이<B>$kind</B>이었기 때문에 중지되었습니다.",$id);
}

# 주변에 육지가 없으면 매립 실패
sub logNoLandAround {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName} 주변에 육지가 없었기 때문에 중지되었습니다.",$id);
}

# 군항이 없어서 함정의 건조 실패
sub logNavyNoPort {
	my($id, $name, $comName, $point) = @_;
	if($point eq "") {
		logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 함정이 귀항할 <B>군항이 없기 때문에</B> 중지되었습니다.",$id);
	} else {
		logOut("${HtagName_}${name}$point${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 근처에 <B>군항이 없기 때문에</B> 중지되었습니다.",$id);
	}
}

# 바다가 없어서 함정의 건조 실패
sub logNavyNoSea {
	my($id, $name, $comName, $point) = @_;
	if($point eq "") {
		logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 함정을 배치할 <B>바다가 없기 때문에</B> 중지되었습니다.",$id);
	} else {
		logOut("${HtagName_}${name}$point${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 배치 지점이 <B>깊은 바다가 아니기 때문에</B> 중지되었습니다.",$id);
	}
}

# 경험치가 없어서 함정의 건조 실패
sub logNavyNoExp {
	my($id, $name, $comName, $point) = @_;
	if($point eq "") {
		logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>건조 기술이 부족하기 때문에</B> 중지되었습니다.",$id);
	} else {
		logOut("${HtagName_}${name}$point${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>건조 기술이 부족하기 때문에</B> 중지되었습니다.",$id);
	}
}

# 함정 최대 수 초과로 인한 건조 실패
sub logNavyMaxOver {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>보유 가능 함정 수를 초과할 가능성이 있기 때문에</B> 중지되었습니다.",$id);
}

# 함정 최대 수 초과로 인한 건조 실패
sub logNavyKindMaxOver {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>함정 종류별 보유 가능 횟수를 초과할 가능성이 있기 때문에</B> 중지되었습니다.",$id);
}

# 1함대(군항) 보유 가능 함정 수 초과로 인한 건조 실패
sub logFleetMaxOver {
	my($id, $name, $comName, $nName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>$nName의 보유 가능 함정 수를 초과할 가능성이 있기 때문에</B> 중지되었습니다.",$id);
}

# 탄약 비용이 부족하여 공격 중지
sub logNavyNoShell {
	my($id, $tId, $name, $nPoint, $nName) = @_;
	logOut("${HtagName_}${name}${nPoint}${H_tagName}의${HtagName_}${nName}${H_tagName} 공격은<B>탄약이 부족하기 때문에</B> 중지되었습니다.",$id,$tId);
}

# 개간 계열 성공
sub logLandSuc {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 개간 계열 로그 정리 메시지
sub logLandSucMatome {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.<br> <B>⇒</B> $point",$id);
}

# 유전 발견
sub logOilFound {
	my($id, $name, $point, $comName, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 진행되어,<B>유전이 채굴되었습니다</B>.",$id);
}

# 유전 발견 여부
sub logOilFail {
	my($id, $name, $point, $comName, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 실행되었지만, 유전은 발견되지 않았습니다.",$id);
}

# 유전에서 수입
sub logOilMoney {
	my($id, $name, $lName, $point, $value, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에서 ${HtagMoney_}$value${H_tagMoney}의 $str이 발생했습니다.",$id);
}

# 유전 고갈
sub logOilEnd {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은 고갈된 것 같습니다.",$id);
}

# 방위 시설, 내구력 상승
sub logBombDurableUp {
	my($id, $name, $lName, $point, $num, $hide) = @_;
	if ($hide) {
		logSecret("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>의 내구력이 $num 증가했습니다.",$id);
		logOut("어디선가 ${HtagName_}${name}${H_tagName}의<B>숲</B>이 늘어난 것 같습니다.",$id);
#		logOut("${HtagName_}${name}$point${H_tagName}에서${HtagComName_}벌채${H_tagComName}이 실행되었습니다.",$id);
	} else {
		logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>의 내구력이 $num 증가했습니다.",$id);
	}
}

# 방위 시설, 내구력 증가 없음
sub logBombDurableMax {
	my($id, $name, $lName, $point, $hide) = @_;
	if ($hide) {
		logSecret("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>의 내구력은 이미 최대입니다.",$id);
		logOut("어디선가 ${HtagName_}${name}${H_tagName}의<B>숲</B>이 늘어난 것 같습니다!",$id);
#		logOut("${HtagName_}${name}$point${H_tagName}에서${HtagComName_}벌채${H_tagComName}이 실행되었습니다.",$id);
	} else {
		logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>의 내구력은 이미 최대입니다.",$id);
	}
}

# 방위 시설, 자폭 설정
sub logBombSet {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>의<B>자폭장치가 설정</B>되었습니다.",$id);
}

# 방위 시설, 자폭 작동
sub logBombFire {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>,${HtagDisaster_}자폭장치 작동!!${H_tagDisaster}",$id);
}

# 기념비, 발사
sub logMonFly {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>굉음과 함께 흔들렸습니다</B>.",$id);

}

# 기념비, 낙하
sub logMonDamage {
	my($id, $name, $point) = @_;
	logOut("<B>정체불명의 물체</B>가${HtagName_}${name}$point${H_tagName}지점에 낙하했습니다!!",$id);
}

# 나무 심기 or 미사일 기지
sub logPBSuc {
	my($id, $name, $comName, $point) = @_;
	logSecret("${HtagName_}${name}$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
	logOut("어디선가 ${HtagName_}${name}${H_tagName}의<B>숲</B>이 늘어난 것 같습니다.",$id);
}

# 가짜 시설
sub logHariSuc {
	my($id, $name, $comName, $comName2, $point) = @_;
	logSecret("${HtagName_}${name}$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
	logLandSuc($id, $name, $comName2, $point);

}

# 미사일 발사 또는 괴수 파견 대상이 없음
sub logMsNoTarget {
	my($id, $name, $comName) = @_;
#	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은, 목표 ${AfterName}에 사람이 살지 않기 때문에 중지되었습니다.",$id);
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은, 목표를 찾을 수 없기 때문에 중지되었습니다.",$id);
}

# 함대에 대한 이동 지령
sub logMoveMissionFleet {
	my($id, $tId, $name, $tName, $point, $no) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${no}함대${H_tagName}에 대해 ${HtagName_}${tName}${point}${H_tagName}에서 ${HtagComName_}이동 지령${H_tagComName}을 실행했습니다.",$id, $tId);
}

# 함대에 대한 이동 지령을 해제
sub logMoveMissionFleetLift {
	my($id, $tId, $name, $tName, $point, $no) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${no}함대${H_tagName}에 대해 ${HtagName_}${tName}${point}${H_tagName}에서 ${HtagComName_}이동 지령${H_tagComName}을${HtagDisaster_}해제${H_tagDisaster}했습니다.",$id, $tId);
}

# 함정의 지령을 변경
sub logChangeMission {
	my($id, $tId, $name, $tName, $point, $old, $new) = @_;
	my @status = ('일반', '퇴치', '순항', '정선');
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}에서${HtagComName_}함정 지령 변경${H_tagComName}을 실행했습니다.${HtagComName_}($status[$old]→$status[$new])${H_tagComName}",$id, $tId);
}

# 함대에 대한 지령을 변경
sub logChangeMissionFleet {
	my($id, $tId, $name, $tName, $no, $new) = @_;
	my @status = ('일반', '퇴치', '순항', '정선');
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}${H_tagName}에서${HtagComName_}${no}함대에 대한 지령 변경${H_tagComName}을 실행했습니다.${HtagComName_}(전체 함정$status[$new]모드)${H_tagComName}",$id, $tId);
}

# 함정의 지령을 변경할 수 있도록 했지만 실패
sub logChangeMissionFail {
	my($id, $tId, $name, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}${H_tagName}로 실행한 ${HtagComName_}함정 지령 변경${H_tagComName}은, 암호가 틀렸거나 전송 대상이 함정이 아니어서 실패했습니다.",$id, $tId);
}

# 일제 공격지령
sub logNavyMission {
	my($id, $tId, $name, $tName, $point, $nName, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}의<B>$nName</B>에 대한 ${HtagComName_}일제 공격${H_tagComName}을 명령했습니다.<BR>--- 지령 수 ⇒ $str",$id, $tId);
}

# 일제 공격지령:실패
sub logNavyMissionFail {
	my($id, $tId, $name, $tName, $point, $nName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이 명령한 ${HtagName_}${tName}$point${H_tagName}의<B>$nName</B>에 대한 ${HtagComName_}일제 공격${H_tagComName}은, 실패로 끝났습니다.",$id, $tId);
}

# 함정 공격, 괴수 미사일 공격(정리)
sub logNavyMatome {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $tLname, $kind, $str, $pntStr, $nId2) = @_;
	logOut("${HtagName_}${name}${nPoint}${H_tagName}의${HtagName_}${nName}${H_tagName}이${HtagName_}${tPoint}${H_tagName}지점의${tLname}을 대상으로${HtagComName_}$kind${H_tagComName}을 실행했습니다.${str}${pntStr}",$id, $nId, $nId2);
}

# 어뢰발사, 기타의 지형
sub logNavyTorpedoNormal {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은 잔해가 되어 바다에 가라앉았습니다.",$id, $nId);
}

# 함포사격, 함재기 폭격, 괴수가 미사일 공격, 방위 시설(내구력있음)·코어(내구력있음)·복합시설(규모다운)
sub logNavyNormalDefence {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은 피해를 받았습니다.",$id, $nId);
}

# 함포사격, 함재기 폭격, 도시계
sub logNavyNormalTown {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint, $sName) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$sName</B>이 되었습니다.",$id, $nId);
}

# 함포사격, 함재기 폭격, 기타의 지형
sub logNavyNormal {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중. 일대가 괴멸되었습니다.",$id, $nId);
}

# 어뢰발사, 괴수에 명중, 살상
sub logNavyTorpedoMonKill {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은 힘이 다해 해저에 ${HtagDisaster_}가라앉았습니다${H_tagDisaster}.",$id, $nId, $mId);
}

# 함포사격, 함재기 폭격, 괴수가 미사일 공격, 괴수에 명중, 살상
sub logNavyMonKill {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은 힘이 다해 ${HtagDisaster_}쓰러졌습니다${H_tagDisaster}.",$id, $nId, $mId);
}

# 함정 공격, 잔해에 명중, 바다에 가라앉은 잔해
sub logNavyWreckDestroy {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은 잔해가 되어 바다에 가라앉았습니다.",$id, $nId);
}

# 함정 공격, 괴수가 미사일 공격, 군항에 명중, 괴멸
sub logNavyPortDestroy {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $nId2, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은${HtagDisaster_}괴멸${H_tagDisaster}했습니다.",$id, $nId, $nId2);
}

# 함정 공격, 괴수가 미사일 공격, 함정에 명중, 격침
sub logNavyShipDestroy {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $nId2, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은${HtagDisaster_}침몰${H_tagDisaster}했습니다.",$id, $nId, $nId2);
}

# 함정 공격, 괴수가 미사일 공격, 괴수에 명중, 피해
sub logNavyMonster {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $mId, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은 고통스러운 듯 포효했습니다.",$id, $nId, $mId);
}

# 함정 공격, 괴수가 미사일 공격, 함정에 명중, 피해
sub logNavyDamage {
	my($id, $name, $nId, $nPoint, $nName, $tPoint, $nId2, $fName, $fPoint) = @_;
	logOut(" --- ${HtagName_}${fPoint}${H_tagName}의<B>$fName</B>에 명중.<B>$fName</B>은 검은 연기를 내뿜었습니다.",$id, $nId, $nId2);
}

# 괴수의 시체
sub logMonMoney {
	my($tId, $mName, $value) = @_;
	logOut(" --- <B>$mName</B>의 잔해에는,<B>$value$HunitMoney</B>의 가치가 있었습니다.", $tId);
}

# 난민 도착
sub logMsBoatPeople {
	my($id, $name, $achive) = @_;
	logOut("${HtagName_}${name}${H_tagName}에 어디선가<B>$achive${HunitPop}명의 난민</B>이 표류해 왔습니다.${HtagName_}${name}${H_tagName}은 살기 좋아진 것 같습니다.",$id);
}

# 괴수 파견
sub logMonsSend {
	my($id, $tId, $name, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>인공괴수</B>를 만들었습니다.${HtagName_}${tName}${H_tagName}로 보냈습니다.",$id, $tId);
}

# ST 괴수 파견
sub logMonsSendST {
	my($id, $tId, $name, $tName) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이<B>인공괴수</B>를 만들었습니다.${HtagName_}${tName}${H_tagName}로 보냈습니다.",$id);
	logLate("<B>누군가</B>가<B>인공괴수</B>를 만들었습니다.${HtagName_}${tName}${H_tagName}로 보냈습니다.",$tId);
}

#자금 조달
sub logDoNothing {
	my($id, $name, $comName) = @_;
#	logOut("${HtagName_}${name}${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 우호국 설정
sub logAmity {
	my($id, $name, $tId, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>$tName</B>을${HtagComName_}우호국으로 인정${H_tagComName}했습니다.",$id, $tId);
}

# 우호국해제
sub logAmityEnd {
	my($id, $name, $tId, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>$tName</B>에 대한 ${HtagComName_}우호국 인정을 폐기${H_tagComName}했습니다.",$id, $tId);
}

# 우호국해제실패
sub logAmityEndFail {
	my($id, $name, $tId, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이 <B>$tName</B>에 대한 ${HtagComName_}우호국 인정 해제${H_tagComName}는<B>함대 파견 중이므로 허가되지 않아</B> 실패했습니다.",$id, $tId);
}

# 우호 최대 수 초과
sub logAmityMaxOver {
	my($id, $name, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>$tName</B>에 대한 <B>우호국 인정에 실패</B>했습니다${HtagComName_}(인정 가능 조건 위반)${H_tagComName}.",$id);
}

# 다른 동맹을 결성하고 있는
sub logLeaderAlready {
	my($id, $name, $tName, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagName_}${tName}${H_tagName}의${HtagComName_}${comName}${H_tagComName}은, 이미 자신의 동맹을 결성했기 때문에 중지되었습니다.",$id);
}

# 이미 다른 동맹에 가입한 경우
sub logOtherAlready {
	my($id, $name, $tName, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagName_}${tName}${H_tagName}의${HtagComName_}${comName}${H_tagComName}은, 이미 다른 동맹에 가입되어 있어 중지되었습니다.",$id);
}

# 가입
sub logAlly {
	my($id, $tId, $name, $allyName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이'${HtagName_}${allyName}${H_tagName}'에${HtagNumber_}가입${H_tagNumber}했습니다.", $id, $tId);
}

# 탈퇴
sub logAllyEnd {
	my($id, $tId, $name, $allyName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이'${HtagName_}${allyName}${H_tagName}'에서${HtagDisaster_}탈퇴${H_tagDisaster}했습니다.", $id, $tId);
}

# 가입 가능 최대 수 초과
sub logAllyMaxOver {
	my($id, $tId, $name, $allyName) = @_;
	logOut("${HtagName_}${name}${H_tagName}의'${HtagName_}${allyName}${H_tagName}'에 대한 <B>가입 신청이 폐기</B>되었습니다${HtagComName_}(가입 가능 횟수 초과)${H_tagComName}.", $id, $tId);
}

# 가입 거부
sub logAllyVeto {
	my($id, $tId, $name, $allyName) = @_;
	logOut("${HtagName_}${name}${H_tagName}의'${HtagName_}${allyName}${H_tagName}'에 대한 <B>가입 신청이 폐기</B>되었습니다${HtagComName_}(거부 권한 행사)${H_tagComName}.", $id, $tId);
}

# 수출
sub logSell {
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagFood_}$value$HunitFood${H_tagFood}의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id);
}

# 수입
sub logBuy {
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagFood_}$value$HunitFood${H_tagFood}의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id);
}

# 지원
sub logAid {
	my($id, $tId, $name, $tName, $comName, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}${H_tagName}로$str 의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id, $tId);
}

# 진영 밖 지원(불허)
sub logAidFail {
	my($id, $tId, $name, $tName, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagName_}${tName}${H_tagName}에서 ${HtagComName_}${comName}${H_tagComName}은 허가되어 있지 않아 중지되었습니다.",$id, $tId);
}

# 공격금지
sub logNotAvail {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은 허가되어 있지 않아 중지되었습니다.",$id);
}

# 개발 기간 조건 때문에 실패
sub logLandNG {
	my($id, $name, $comName, $cancel) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>$cancel</B>, 실행할 수 없었습니다.",$id);
END
}

# 이주 홍보
sub logPropaganda {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 포기
sub logGiveup {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}은 포기되어,<B>무인${AfterName}</B>이 되었습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName}, 포기되어 <B>무인${AfterName}</B>이 됩니다.");
}

# 무인화보호
sub logAutoKeep {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}의인구가 감소하여 <B>개발 기간</B>에 들어갔습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName}이<B>개발 기간에 들어감</B>.");
}

# 추방
sub logGiveup_no_do_fight {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}은 규정된 횟수만큼 전투 행위를 하지 않았기 때문에,<B>패배</B>했습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName}, 규정된 횟수만큼 전투 행위를 하지 않았기 때문에,<B>패배</B>.");
}

# 사멸
sub logDead {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 주민이 사라져,<B>무인${AfterName}</B>이 되었습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName}, 주민이 사라져 <B>무인${AfterName}</B>이 됩니다.");
}

# 사멸(서바이벌 모드·토너먼트 모드)
sub logTDead {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}은,<B>침몰</B>시흔적도 없이 사라졌습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName},<B>침몰</B>하다.");
}

# 소멸 회피(진영 모드·서바이벌 모드·토너먼트 모드)
sub logTDead2PD {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}은, 침몰치 수전에<B>전선을 이탈</B>했습니다. 복구에는 시간이 걸릴 듯입니다.[관리자 보관]",$id);
	logHistory("${HtagName_}${name}${H_tagName},<B>전선을 이탈</B>하다.");
}

# 기아
sub logStarve {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}의${HtagDisaster_}식량이 부족${H_tagDisaster}하고 있습니다!!",$id);
}

# 함정(소속 불명) 출현
sub logNavyCome {
	my($id, $name, $nName, $point, $lName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에 소속 불명의<B>$nName</B> 출현!!${HtagName_}$point${H_tagName}의 <B>$lName</B>을 이동하고 있습니다.",$id);
}

# 코어건설(무작위)
sub logCoreRandomBuild {
	my($id, $name, $nName, $point, $lName) = @_;
	if($HcoreHide) {
		logSecret("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에<B>$nName</B> 출현!!",$id);
		logOut("${HtagName_}${name}$point${H_tagName}에<B>$nName</B> 출현!!",$id);
	} else {
		logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에<B>$nName</B> 출현!!",$id);
	}
}

# 괴수 출현
sub logMonsCome {
	my($id, $name, $mName, $point, $lName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에<B>$mName</B> 출현!!${HtagName_}$point${H_tagName}의 <B>$lName</B>을 이동하고 있습니다.",$id);
}

# 괴수 이동
sub logMonsMove {
	my($id, $name, $lName, $point, $mName, $mId) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>$mName</B>에게 짓밟혀 파괴되었습니다.",$id, $mId);
}

# 거대괴수일부재생
sub logMonsRebody {
	my($id, $name, $point, $mName, $mId) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서<B>$mName</B>의 일부가재생했습니다.",$id, $mId);
}

# 괴수 이동(바다)
sub logMonsMoveSea {
	my($id, $name, $lName, $point, $mName, $mId) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>을<B>$mName</B>이 이동하고 있습니다.",$id, $mId);
}

# 괴수, 해군을 습격우
sub logMonsAttackNavy {
	my($id, $name, $lName, $point, $mName, $mId) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>$mName</B>에게 습격당하고 있습니다.",$id, $mId);
}

# 괴수, 바다의 시설을 파괴
sub logMonsBreakSea {
	my($id, $name, $lName, $point, $mName, $mId) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>$mName</B>에게 습격당해 파괴되었습니다.",$id, $mId);
}

# 괴수는 방위 시설을 밟지 않음
sub logMonsMoveDefence {
	my($id, $name, $lName, $point, $mName, $mId) = @_;
	logOut("<B>$mName</B>이${HtagName_}${name}$point${H_tagName}의<B>$lName</B>로 도달,<B>${lName}의 자폭장치가 작동!!</B>",$id, $mId);
}

# 함정 이동
sub logNavyMoveSea {
	my($id, $name, $lName, $point, $mName, $mId) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>을<B>$mName</B>이 항해 중입니다.",$id, $mId);
}

# 함정몸통박치기
sub logNavyMoveAttack {
	my($id, $name, $nId, $nPoint, $nName, $nId2, $fPoint, $fName) = @_;
	logOut("${HtagName_}${name}$nPoint${H_tagName}의${HtagName_}${nName}${H_tagName}이${HtagName_}${fPoint}${H_tagName}지점의${HtagName_}${fName}${H_tagName}에${HtagComName_}몸통박치기!${H_tagComName}<B>$fName</B>까지 ${HtagDisaster_}침몰${H_tagDisaster}했습니다.",$id, $nId, $nId2);
}

# 육지굴착
sub logNavyMoveDestroy {
	my($id, $name, $lName, $point, $mName, $mId, $mode) = @_;
	my $str = '중';
	$str = '' if($mode);
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>을<B>$mName</B>이 굴착 항해를${str}하고 있습니다.",$id, $mId);
}

# 함정건조
sub logNavyBuild {
	my($id, $name, $nNo, $nName, $point) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>${nNo}함대의${nName}</B>을 건조해 ${HtagName_}$point${H_tagName}에 배치했습니다.",$id);
}

# 함대 파견·귀환·이동
sub logNavySend {
	my($id, $fId, $tId, $name, $tName, $fleet, $fSend) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>${fleet}</B>을${HtagName_}${tName}${H_tagName}${fSend}했습니다.",$id, $fId, $tId);
}

# 함대 파견·귀환·이동의 함정 로그
sub logNavySendShip {
	my($id, $tId, $str, $fSend) = @_;
	logOut(" --- ${fSend}지점 ⇒ $str",$id, $tId);
}

# 함대 파견·귀환·이동할 수 있도록 했지만 함정없음
sub logNavySendNone {
	my($id, $name, $tName, $fleet, $fSend) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>${fleet}</B>을${HtagName_}${tName}${H_tagName}${fSend}할 수 있도록 했지만, 실행 가능한 함대가 없었습니다.",$id);
}

# 함대 파견·귀환·이동할 수 있도록 했지만 실패
sub logNavySendNoArea {
	my($id, $name, $tName, $fleet, $fSend, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>${fleet}</B>을${HtagName_}${tName}${H_tagName}${fSend}할 수 있도록 했지만, 실패했습니다.$str",$id);
}

# 함대 편성
sub logNavyForm {
	my($id, $name, $point, $fleet, $old, $new) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>은${old}함대에서${new}함대에 소속이 변경되었습니다.",$id);
}

# 함대 편성할 수 있도록 했지만 실패
sub logNavyFormFail {
	my($id, $name, $point, $fleet) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 함대 편성을 할 수 없습니다.",$id);
}

# 함대 편성 실패: 1함대 주변의 보유 함정 수 초과로 인한 실패
sub logNavyFormMaxOver {
	my($id, $name, $point, $fleet, $old, $new) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의${old}함대 소속<B>${fleet}</B>은 함대를 편성할 수 없었습니다.(${new}함대의 함정 보유 수 초과)",$id);
}

# 함정 소속 해제
sub logNavyTarget {
	my($id, $name, $point, $fleet) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 소속 불명 함정으로 전환했습니다.",$id);
}

# 함정 소속 해제할 수 있도록 했지만 실패
sub logNavyTargetFail {
	my($id, $name, $point, $fleet) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 소속 불명 함정으로 전환할 수 없습니다.",$id);
}

# 함정 폐기
sub logNavyDestroy {
	my($id, $name, $point, $fleet) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 폐기했습니다.",$id);
}

# 함정 폐기할 수 있도록 했지만 실패
sub logNavyDestroyFail {
	my($id, $name, $point, $fleet) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 폐기할 수 없습니다.",$id);
}

# 잔해 수리
sub logNavyWreckRepair {
	my($id, $name, $point, $fleet, $cost, $nName) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을${cost}${HunitMoney}로 수리.<B>$nName</B>에 배치했습니다.",$id);
}

# 잔해 수리할 수 있도록 했지만 실패
sub logNavyWreckRepairFail {
	my($id, $name, $point, $fleet) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 수리할 수 없습니다.",$id);
}

# 잔해 수리 실패: 1함대 주변의 함정 보유 수 초과로 인한 실패
sub logNavyWreckRepairMaxOver {
	my($id, $name, $point, $fleet, $nName) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 수리할 수 없습니다.(${nName}의 함정 보유 수 초과)",$id);
}

# 잔해 매각
sub logNavyWreckSell {
	my($id, $name, $point, $fleet, $cost) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을${cost}${HunitMoney}로 매각했습니다.",$id);
}

# 잔해 매각 중 금괴 발견
sub logNavyWreckSellLucky {
	my($id, $name, $point, $fleet, $cost) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 끌어올렸더니,${cost}${HunitMoney}의<B>금괴</B>가 발견되었습니다!",$id);
}

# 잔해 매각할 수 있도록 했지만 실패
sub logNavyWreckSellFail {
	my($id, $name, $point, $fleet) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>${fleet}</B>을 매각할 수 없습니다.",$id);
}

# 함정 수리
sub logNavyShipRepair {
	my($id, $name, $tId) = @_;
	logOut("<B>수리상황</B>(에서:${HtagName_}${name}${point}${H_tagName})",$id,$id,$tId);
}

# 함정 수리
sub logNavyShipRepairM {
	my($id, $tId, $str) = @_;
	my($name) = islandName($Hislands[$HidToNumber{$tId}]) if (defined $HidToNumber{$tId});
	logOut(" ${HtagName_}${name}${point}${H_tagName}소속 함정 ⇒ $str 이 수리을 실행했습니다.",$id,$tId);
}

# 함정이보급부족
sub logNavyShipSupplyFailM {
	my($id, $tId, $str) = @_;
	my($name) = islandName($Hislands[$HidToNumber{$tId}]) if (defined $HidToNumber{$tId});
	logOut(" ${HtagName_}${name}${point}${H_tagName}소속 함정 ⇒ $str 의보급 물자가 부족합니다.",$id,$tId);
}

# 화재
sub logFire {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이${HtagDisaster_}화재${H_tagDisaster}로${HtagDisaster_}괴멸${H_tagDisaster}했습니다.",$id);
}

# 매장금
sub logMaizo {
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>$value$HunitMoney 상당의 매장금</B>을 발견했습니다.",$id);
}

# 지진발생
sub logEarthquake {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}로 대규모${HtagDisaster_}지진${H_tagDisaster}이 발생!!",$id);
}

# 지진 피해
sub logEQDamage {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은${HtagDisaster_}지진${H_tagDisaster}로${HtagDisaster_}괴멸${H_tagDisaster}했습니다.",$id);
}

# 식량 부족 피해
sub logSvDamage {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에<B>식량을 찾는 주민이 몰려들었습니다</B>.<B>$lName</B>은${HtagDisaster_}괴멸${H_tagDisaster}했습니다.",$id);
}

# 쓰나미발생
sub logTsunami {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}부근에서${HtagDisaster_}쓰나미${H_tagDisaster} 발생!!",$id);
}

# 쓰나미 피해
sub logTsunamiDamage {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은${HtagDisaster_}쓰나미${H_tagDisaster}로 붕괴했습니다.",$id);
}

# 쓰나미 피해(함정에 피해)
sub logTsunamiDamageNavy {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은${HtagDisaster_}쓰나미${H_tagDisaster}로 피해를 입었습니다.",$id);
}

# 쓰나미 피해(함정침몰)
sub logTsunamiDamageNavyDestroy {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은${HtagDisaster_}쓰나미${H_tagDisaster}로${HtagDisaster_}침몰${H_tagDisaster}했습니다.",$id);
}

# 태풍발생
sub logTyphoon {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}에${HtagDisaster_}태풍${H_tagDisaster} 상륙!!",$id);
}

# 태풍 피해
sub logTyphoonDamage {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은${HtagDisaster_}태풍${H_tagDisaster}으로 날아갔습니다.",$id);
}

# 운석, 바다
sub logMeteoSea {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하했습니다.",$id);
}

# 운석, 산
sub logMeteoMountain {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하,<B>$lName</B>은 사라졌습니다.",$id);
}

# 운석, 해저 기지
sub logMeteoSbase {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하,<B>$lName</B>은 붕괴했습니다.",$id);
}

# 운석, 괴수
sub logMeteoMonster {
	my($id, $name, $lName, $point) = @_;
	logOut("<B>$lName</B>이 있던${HtagName_}${name}$point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 육지는<B>$lName</B>째로 수몰되었습니다.",$id);
}

# 운석, 괴수(잠수안)
sub logMeteoMonsterSea {
	my($id, $name, $lName, $point) = @_;
	logOut("<B>$lName</B>이 있던${HtagName_}${name}$point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 수안에있었음<B>$lName</B>은 사라졌습니다.",$id);
}

# 운석, 얕은 바다
sub logMeteoSea1 {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 해저가 깎였습니다.",$id);
}

# 운석, 기타
sub logMeteoNormal {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}지점의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 일대가 수몰되었습니다.",$id);
}

# 운석, 기타
sub logHugeMeteo {
	my($id, $name, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}지점에${HtagDisaster_}거대운석${H_tagDisaster}이 낙하!!",$id);
}

# 분화
sub logEruption {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}지점에서${HtagDisaster_}화산이 분화${H_tagDisaster},<B>산</B>이 생겼습니다.",$id);
}

# 분화, 괴수(깊은 바다)
sub logEruptionSea3 {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}지점의<B>$lName</B>이 있던 <B>바다</B>는,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 해저가 융기하여, 얕은 바다가 되었습니다.",$id);
}

# 분화, 괴수(얕은 바다)
sub logEruptionSea2 {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 해저가 융기하여, 해상에 출현했습니다.",$id);
}

# 분화, 얕은 바다
sub logEruptionSea1 {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 육지가 되었습니다.",$id);
}

# 분화, 바다 or 바다 기준
sub logEruptionSea {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 해저가 융기하여, 얕은 바다가 되었습니다.",$id);
}

# 분화, 기타
sub logEruptionNormal {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로${HtagDisaster_}괴멸${H_tagDisaster}했습니다.",$id);
}

# 지반 침하발생
sub logFalldown {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagDisaster_}지반 침하${H_tagDisaster}가 발생했습니다!!",$id);
}

# 지반 침하 피해
sub logFalldownLand {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은 바다의 안로 침몰봄했습니다.",$id);
}

# 광역 피해, 수몰
sub logWideDamageSea {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은<B>수몰</B>했습니다.",$id);
}

# 광역 피해, 바다의 건설
sub logWideDamageSea2 {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은 흔적도 없이 사라졌습니다.",$id);
}

# 광역 피해, 괴수수몰
sub logWideDamageMonsterSea {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의 육지는<B>$lName</B>째로 수몰되었습니다.",$id);
}

# 광역 피해, 괴수수몰(잠수안)
sub logWideDamageMonsterSea2 {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName} 수안에있었음<B>$lName</B>은 사라졌습니다.",$id);
}

# 광역 피해, 괴수
sub logWideDamageMonster {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은 사라졌습니다.",$id);
}

# 광역 피해, 황무지
sub logWideDamageWaste {
	my($id, $name, $lName, $point) = @_;
	logOut(",,, ${HtagName_}$point${H_tagName}의<B>$lName</B>은 한순간에 <B>황무지</B>가 되었습니다.",$id);
}

# 수상
sub logPrize {
	my($id, $name, $pName, $money) = @_;
	my $str = ($money) ? "(상금:${money}${HunitMoney})" : "";
	logOut("${HtagName_}${name}${H_tagName}이<B>$pName$str</B>을 수상했습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName},<B>$pName$str</B>을 수상");
}

# 진영소멸
sub logCampDelete {
	my($name) = @_;
	logHistory("${HtagName_}${name}${H_tagName}은, 멸망했습니다.");
}

# 진영소멸(소멸 회피)
sub logCampPreDelete {
	my($name) = @_;
	logHistory("${HtagName_}${name}${H_tagName}은, 완료 전체에침몰침묵했습니다.");
}

# 인구기타의 값을 산출
sub estimate {
	my($number) = $_[0];
	my($island, $fkind);

	# 지형을 가져옴
	$island = $Hislands[$number];
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($map) = $island->{'map'};

	# 초기화
	$island->{'pop'} = 0;
	$island->{'area'} = 0;
	$island->{'farm'} = 0;
	$island->{'factory'} = 0;
	$island->{'mountain'} = 0;
	$island->{'navyPort'} = 0;
	$island->{'oil'} = 0;
	$island->{'sea'} = 0;
	$island->{'mine'} = 0;
	foreach (0..$#HcomplexName) {
		$island->{'complex'}[$_] = 0;
	}

	# 수 가능
	my($x, $y, $kind, $value);
	foreach $y (@{$map->{'y'}}) {
		foreach $x (@{$map->{'x'}}) {
			$kind = $land->[$x][$y];
			$value = $landValue->[$x][$y];
			if(($kind != $HlandSea) &&
				($kind != $HlandBouha) &&
				($kind != $HlandSeaMine) &&
				($kind != $HlandSbase) &&
				($kind != $HlandOil)){
				$island->{'area'}++;
				if($kind == $HlandTown) {
					# 읍
					$island->{'pop'} += $value;
				} elsif($kind == $HlandFarm) {
					# 농장
					$island->{'farm'} += $value;
				} elsif($kind == $HlandFactory) {
					# 공장
					$island->{'factory'} += $value;
				} elsif($kind == $HlandMountain) {
					# 산
					$island->{'mountain'} += $value;
				} elsif($kind == $HlandComplex) {
					# 복합 지형
					my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($value);
					$island->{$HcomplexTPkind[$cKind]} += $cTurn * $HcomplexTPrate[$cKind] if(defined $HcomplexTPkind[$cKind]);
					$island->{$HcomplexFPkind[$cKind]} += $HcomplexFPplus[$cKind] * $cFood + $HcomplexFPbase[$cKind];
					$island->{$HcomplexMPkind[$cKind]} += $HcomplexMPplus[$cKind] * $cMoney + $HcomplexMPbase[$cKind];
					$island->{'complex'}[$cKind]++;
					$island->{'area'}-- if($HcomplexAttr[$cKind] & 0x300);
				} elsif(($kind == $HlandMonster) || ($kind == $HlandHugeMonster)) {
					# 바다에 있는 괴수는 육지로 카운트하지 않음
					my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($value);
					$island->{'area'}-- if ($mFlag & 2);
				} elsif ($kind == $HlandNavy) {
					my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($value);
					my $nSpecial = $HnavySpecial[$nKind];
					my $n = $HidToNumber{$nId};
					$Hislands[$n]->{'shipk'}[$nKind]++ if(defined $n);
					if ($nSpecial & 0x8) {
						# 항구
						$island->{'navyPort'}++;
					} else {
						if(!($nFlag & 1)) {
							if(defined $n) {
								$Hislands[$n]->{'ships'}[$nNo]++;
								$Hislands[$n]->{'ships'}[4]++;
								$Hislands[$n]->{"invade$id"}++;
							}
						}
						# 함정이면 육지로 카운트하지 않음
						$island->{'area'}--;
					}
				} elsif($kind == $HlandDefence) {
					$island->{'dbase'}++;
				} elsif($kind == $HlandCore) {
					$island->{'core'}++;
					$island->{'area'}-- if(int($value / 10000)>= 1);
				}
			} elsif($kind == $HlandBouha) {
				$island->{'bouha'}++; # 방파제를 카운트
			} elsif($kind == $HlandSeaMine) {
				$island->{'mine'}++; # 기뢰를 카운트
			} elsif($kind == $HlandOil) {
				$island->{'oil'}++; # 유전을 카운트(발견 확률을 높이기)
			} elsif($kind == $HlandSea && !$value) {
				$island->{'sea'}++; # 깊은 바다를 카운트
			}
		}
	}

}

# 포인트 산출
sub calcPoint {
	my($number) = @_;

	$island = $Hislands[$number];
	my $point = 0;
	my $value;
	foreach (keys %HpointRatio) {
		$value = ($island->{$_} * $HpointRatio{$_});
		$point += $value;
	}
	foreach (0..$#HpointRatioNavy) {
		$value = ($island->{'navy'}[$_] * $HpointRatioNavy[$_]);
		$point += $value;
	}
	$point /= $HpointRatioDenominator if($HpointRatioDenominator);

	$island->{'point'} = int($point);
}

# 범위 안의 지형을 수 가능
sub countAround {
	my($island, $x, $y, $range, @kind) = @_;
	my($land) = $island->{'land'};
	my($sea, $count, $sx, $sy, @list);
	foreach (@kind){
		$list[$_] = 1;
	}
	$sea = 0;
	$count = 0;
	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];

		if(($sx < 0) || ($sy < 0)){
			# 범위 밖의 경우
			# 바다에가 산
			$sea++;
		} elsif($list[$land->[$sx][$sy]]) {
			# 범위 안의 경우
			$count++;
		}
	}
	$count += $sea if($list[$HlandSea]); # 바다이면 가 산
	return $count;
}

# 범위 안의 복합 지형(속성)을 수 가능
sub countAroundComplex {
	my($island, $x, $y, $range, $attr) = @_;
	my($land, $landValue) = ($island->{'land'}, $island->{'landValue'});
	my($count, $sx, $sy);
	$count = 0;
	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖
		next if(($sx < 0) || ($sy < 0));

		# 범위 안의 경우
		if($land->[$sx][$sy] == $HlandComplex) {
			my $cKind = (landUnpack($landValue->[$sx][$sy]))[1];
			if($HcomplexAttr[$cKind] & $attr) {
				$count++;
			}
		}
	}
	return $count;
}

# 범위 안의 방위 시설, 함정을 미붙이기
sub countAroundDef {
	my($id, $island, $x, $y, $special, @oId, $cflag) = @_;
	my($land, $landValue) = ($island->{'land'}, $island->{'landValue'});
	my($range, $sx, $sy, %idFlag);
	# @oId 에들어 있습니다 ID(공격측 ID)은 무시
	foreach (@oId) {
		$idFlag{$_} = 1;
	}

	my($count) = 0;
	$range = ($HdefLevelUp) ? $an[3] : $an[2];
	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖의 경우
		next if(($sx < 0) || ($sy < 0));

		if($_ < $an[2]) { # 2헥스 방위
			if($land->[$sx][$sy] == $HlandNavy) {
				my($dId, $dKind) = (navyUnpack($landValue->[$sx][$sy]))[0, 7];
				my $nSpecial = $HnavySpecial[$dKind];
				next if($idFlag{$dId} || !($nSpecial & $special));
				if(!$cflag) {
					return 1;
				} else {
					$count++;
				}
			} elsif(!$idFlag{$id}) {
				if($land->[$sx][$sy] == $HlandComplex) {
					my $cKind = (landUnpack($landValue->[$sx][$sy]))[1];
					next if(!($HcomplexAttr[$cKind] & $special));
					if(!$cflag) {
						return 1;
					} else {
						$count++;
					}
				} elsif($land->[$sx][$sy] == $HlandDefence) {
					if(!$cflag) {
						return 1;
					} else {
						$count++;
					}
				}
			}
		} elsif((!$idFlag{$id}) && ($land->[$sx][$sy] == $HlandDefence)) { # 3헥스 방위의 방위 시설
			next if($landValue->[$sx][$sy] < $HdefLevelUp - 1);
			if(!$cflag) {
				return 1;
			} else {
				$count++;
			}
		}
	}
	return $count;
}

# 범위 안의 해상에 있는 괴수를 수 가능
sub countAroundMonster {
	my($island, $x, $y, $range) = @_;
	my($land, $landValue) = ($island->{'land'}, $island->{'landValue'});
	my($count, $sx, $sy);
	$count = 0;
	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖의 경우
		next if(($sx < 0) || ($sy < 0));

		if(($land->[$sx][$sy] == $HlandMonster) || ($land->[$sx][$sy] == $HlandHugeMonster)) {
			my $nFlag = (monsterUnpack($landValue->[$sx][$sy]))[4];
			$count++ if($nFlag & 2);
		}
	}
	return $count;
}

# 범위 안의 함정을 수 가능
sub countAroundNavy {
	my($island, $x, $y, $range) = @_;
	my($land, $landValue) = ($island->{'land'}, $island->{'landValue'});
	my($count, $sx, $sy);
	$count = 0;
	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖의 경우
		next if(($sx < 0) || ($sy < 0));

		if($land->[$sx][$sy] == $HlandNavy) {
			my($nKind) = (navyUnpack($landValue->[$sx][$sy]))[7];
			my $nSpecial = $HnavySpecial[$nKind];
			$count++ unless ($nSpecial & 0x8);
		}
	}
	return $count;
}

# 범위 안의 특수 함정을 수 가능
sub countAroundNavySpecial {
	my($island, $x, $y, $special, $range, @id) = @_;
	# @id 만 카운트($id에 '0'이 있는 경우 모두 카운트)
	my($land, $landValue) = ($island->{'land'}, $island->{'landValue'});
	my($count, $sx, $sy, %idFlag);
	foreach (@id) {
		$idFlag{$_} = 1;
	}
	$count = 0;

	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖의 경우
		next if(($sx < 0) || ($sy < 0));

		if($land->[$sx][$sy] == $HlandNavy) {
			my($nId, $nKind) = (navyUnpack($landValue->[$sx][$sy]))[0, 7];
			my $nSpecial = $HnavySpecial[$nKind];
			$count++ if(($nSpecial & $special) && ($idFlag{'0'} || $idFlag{$nId}));
		}
	}
	return $count;
}

# 범위 안의 방파 능력 함정을 수 가능
sub countAroundNavyBouha {
	my($island, $x, $y) = @_;
	my($land, $landValue) = ($island->{'land'}, $island->{'landValue'});
	my($count, $sx, $sy);
	$count = 0;

	my $range = $an[3];
	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];
		# 범위 밖의 경우
		next if(($sx < 0) || ($sy < 0));

		if($land->[$sx][$sy] == $HlandNavy) {
			my($nId, $nKind) = (navyUnpack($landValue->[$sx][$sy]))[0, 7];
			my $special = $HnavySpecial[$nKind];
			return 1 if(($special & 0x8000000) && ($_ < $an[$HbouhaHex[$nKind]]));
		}
	}
	return 0;
}

# 0에서(n - 1)까지의 숫자가한 번씩출해 옵니다 수열을 만들기
sub randomArray {
	my($n) = @_;
	my(@list, $i);

	# 초기 값
	$n = 1 if($n <= 0);
	@list = (0..$n-1);

	# 셔터 전체
	for ($i = $n; --$i; ) {
		my($j) = int(rand($i+1));
		next if($i == $j);
		@list[$i,$j] = @list[$j,$i];
	}

	return @list;
}

#------------------------------------------------
# 토너먼트 모드
#------------------------------------------------
# 대전 기록 로그
sub fightlog {
	# 저장 디렉터리의 확인
	if(!opendir(DIN, "${HfightdirName}/")) {
		mkdir("${HfightdirName}", $HdirMode);
	} else {
		closedir(DIN);
	}

	# 라운드 수수대입 결승전의 경우99로
	my $fTurn = ($HislandFightMode == 9) ? 99 : (!$HislandFightMode) ? 0 : $HislandFightCount;

	my($f,@offset);
	if($fTurn) {
		if(!open(FIN, "<${HfightdirName}/${Hfightlog}")) {
			rename("${HfightdirName}/fight.tmp", "${HfightdirName}/${Hfightlog}");
			if(!open(FIN, "<${HfightdirName}/${Hfightlog}")) {
				return;
			}
		}
		while($f = <FIN>){
			chomp($f);
			push(@offset,"$f\n");
		}
		close(FIN);
	}
	open(FOUT, ">${HfightdirName}/fight.tmp");
	print FOUT "<${fTurn}>\n";

	foreach (@HfightLogPool) {
		print FOUT $_. "\n";
	}
	print FOUT @offset if($fTurn);
	close(FOUT);

	unlink("${HfightdirName}/${Hfightlog}") if(-e "${HfightdirName}/${Hfightlog}");
	rename("${HfightdirName}/fight.tmp","${HfightdirName}/${Hfightlog}");
}

# 승리 로그
sub logWin {
	my($id, $name, $str, $money, $ino) = @_;
	my $fTurn = $HislandFightCount + 1;
	if($ino <= 2) {
		$fTurn = '결승전';
	} elsif($ino <= 4) {
		$fTurn = '준결승';
	} else {
		$fTurn.= '회전';
	}
	if($ino < 2) {
		logOut("${HtagName_}${name}${H_tagName}${str}시,<B>우승!!</B>",$id);
		logHistory("${HtagName_}${name}${H_tagName},<B>우승!!</B>");
	} elsif($money == 0) {
		logOut("${HtagName_}${name}${H_tagName}${str}시,<B>$fTurn 진출!</B>",$id);
	} else {
		logOut("${HtagName_}${name}${H_tagName}${str}시,<B>$fTurn 진출! $money$HunitMoney</B>의 보상금이 지급되었습니다.",$id);
	}
}

# 패배
sub logLose {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName},<B>패배</B>.",$id);
}

# 예선 탈락
sub logLoseOut {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName},<B>예선 탈락</B>.",$id);
	logHistory("${HtagName_}${name}${H_tagName},<B>예선 탈락</B>.");
}

# 침몰 시의 대전 상대 데이터 처리
sub fightNoFight {
	my($island, $rno) = @_;
	my $delflag = 0;
	my($tIsland, $tId);
	my $tn = $HidToNumber{$island->{'fight_id'}};
	if($tn ne '') {
		$tIsland = $Hislands[$tn];
		$tId = $tIsland->{'id'};
		$delflag = $tIsland->{'delete'};
		$delflag = 1 if(!$tIsland->{'pop'});
	} else {
		$delflag = 1;
	}

	if(!$delflag) {
		my $rest_turn;
		if($HislandFightMode == 2) {
			my $reward = $tIsland->{'subExt'}[12];
			if(int($HfightTurn / 2) <= ($HislandChangeTurn - $HislandTurn)) {
				$rest_turn = ($HnofightTurn + $HislandFightCount * $HnofightUp) - ($HfightTurn - ($HislandChangeTurn - $HislandTurn));
				island_load($tIsland, -1);
				$tIsland->{'fight_id'} = -1;
			} else {
				$tIsland->{'money'} += $reward;
				$tIsland->{'prizemoney'} += $reward;
				my $fightIslandNumber = 0;
				my $winIslandNumber = 0;
				foreach $i ($HbfieldNumber..$rno){
					$island = $Hislands[$i];
					if($island->{'fight_id'} < 0) {
						$winIslandNumber++;
					} elsif($island->{'fight_id'}> 0) {
						$fightIslandNumber++;
					}
				}
				$winIslandNumber += int(($fightIslandNumber + 1)/2);
				logWin($tIsland->{'id'}, islandName($tIsland), "압승!", $reward, $winIslandNumber);
				$tIsland->{'fight_id'} = -2;
			}
			# 각종의 값을 계산
			estimate($tn);
		} else {
			# 결승이면 어차피 상대가 승리하므로, 회전의 개발 정지 처리
			$rest_turn = $HnofightTurn + $HislandFightCount * $HnofightUp;
			$tIsland->{'fight_id'} = -1;
		}
		$tIsland->{'rest'} += $rest_turn if($rest_turn> 0);
	}
	$island->{'fight_id'} = 0;
	$island->{'delete'} = 1;
	my $flag = 0;
	if($rno <= $HbfieldNumber + 2) {
		$HislandFightMode = 9;
		$tIsland->{'rest'} = 0;
		my(@text);
		my(@iext) = @{$island->{'subExt'}};
		foreach (0..$#iext) {
			$iext[$_] = $island->{'ext'}[$_] - $island->{'subExt'}[$_];
			$iext[$_] = -$iext[$_] if($iext[$_] < 0);
			$text[$_] = $tIsland->{'ext'}[$_] - $tIsland->{'subExt'}[$_];
			$text[$_] = -$text[$_] if($text[$_] < 0);
		}
		push(@HfightLogPool, "$HislandFightCount,$tIsland->{'id'},". islandName($tIsland). ",$tIsland->{$HrankKind},". join('-', @text). ",-2,". islandName($island). ",'',". join('-', @iext). ",") if(!$delflag);
		$flag = 3;
	}
	#push(@delete_log, $tIsland->{'id'});


	return $flag;
}

1;
