#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 모형정원 바다전쟁 JS ver7.xx
# 게임 설정모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 각종 설정 값
# 아래 설정 값을 서버 환경에 맞게 변경해 주세요.
#----------------------------------------------------------------------

# 승리한 섬 이름(진영 이름) 앞에 붙일 명칭 번호(종료 턴·진영 모드·서바이벌 모드·토너먼트 모드 공통 설정)
# 명칭번호
@HwinnerTitle = (
	'COMPLETE!', #아이템컴플리트용
	'바다전쟁패권자',
	);
# 표시
@HwinnerMark = ( # 이미지의 경우
	'trophy2[gold].gif', #아이템컴플리트용
	'king[yellow].gif',
	); # 요시의 소재도음 http://homepage2.nifty.com/yoshi-m/sozai/
#@HwinnerMark = ( # 텍스트의 경우
#	'[COMPLETE!]', #아이템컴플리트용
#	'[승자!]'
#	);
# 표시를 1개만 보이게 할까요?(0:사용 안 함,1:사용)
$HviewMarkOne = 0;

# 새 섬을 탐색하게 함것은 관리자만?(0:아니오,1:예)
# (관리자만의 경우 $HjoinGiveupTurn 을작게해 주세요)
$HadminJoinOnly = 0;

# 새로 등록된 섬의 개발 기간
# (개발 기간에는 다른 섬으로 지원하거나 다른 섬을 공격하는 것이 금지됩니다)
$HdevelopTurn = 10;

# 포기 명령 자동 입력 턴 수(개발 기간)
$HdevelopGiveupTurn = 4;

# 포기 명령 자동 입력 턴 수
$HgiveupTurn = 24;

# 새 섬을 찾은 직후의 방치 턴 수(몇 턴 동안 방치된 것으로 볼지)
$HjoinGiveupTurn = $HgiveupTurn - 1;

# 새 섬을 찾은 시의 코멘트란
$HjoinComment = '(미 등록)';
# 코멘트란이 발견 당시 그대로인 경우 관리자 보관 처리?(0:사용 안 함)
$HjoinCommentPenalty = 0; # 1이면 발견 턴의 다음 턴 갱신 시에판정.2 이상이면 유예를 둘 수 있습니다.
# 이기능을 설정 목 화면에 표시할까요?
# 하지 않은 경우,""
# 설정 예: "원본 규칙으로 인정하지 않음", "<a href='~'>게시판</a>에서 접수", "<a href="mailto:~>메일</a>로 접수" 등
#$HjoinCommentPenaltyStr = "받을 수 없습니다. 발견다음제,<B> 섬을 삭제</B>합니다."; # '관리자 보관 해제의 뢰는'(여기에 들어갈 말)''
$HjoinCommentPenaltyStr = "";

# 무인화자동회피·사멸판정회피기능 사용(0:사용하지 않음,1:사멸판정회피,2~:무인화자동회피)
#'섬 포기'이외에서는 사멸 처리를 하지 않음.
# 타 섬에 파견 중인 함정이나 자기 섬(처리 대상 섬)에 출현 중인 괴수·거대괴수는 바다가 되어 소멸합니다.
# 타 섬에서 자기 섬으로 파견되어 있는 함대는 귀환 처리됩니다.
# 1:사멸판정회피의 경우
# 관리자 보관 상태입니다.
# 2~:무인화자동회피의 경우
# 초기 설정의 인구에서 개발 기간이 됨('진영 모드''서바이벌 모드''토너먼트 모드'에서는 사용 불가)
# 단, 인구가0인 경우, 황무지나 평지가 아니면 침몰해 버림.
$HautoKeeper = 1; # 인구가이 설정 값을 밑돌면 발동

# 사멸판정회피에 한'관리자 보관'의자동 해제 턴 수?(0:무기한,1~99999998:턴 수)
$HautoKeeperSetTurn = 24;

# '관리자 보관' 상태라도 첫 번째 명령이 '섬 포기'라면 사멸 처리를 할까요?(0:아니오,1:예)
$HforgivenGiveUp = 1;

# '관리자 보관'의 섬으로 공격(함대 파견·괴수 파견·미사일 공격)을 허가할까요?(0:아니오,1:예)
$HforgivenAttack = 0;

# 사멸 처리로 삭제되는 섬 데이터를 토너먼트 패자기 섬으로 취급해 저장할까요?(0:아니오, 1:예, 2:강제 삭제도 저장)
$HdeadToSaveAsLose = 2;

#----------------------------------------
# 코어
#----------------------------------------
# 건설 명령을 사용할까요?(0:금지)
$HuseCore = 0;

# 건설 가능한 기간은 새로 등록된 섬의 개발 기간만?(0:제한 없음,1:새로 등록된 섬의 개발 기간만)
$HuseCoreLimit = 0;

# 보유 가능 횟수를 지정
$HcoreMax = 0; # 0:무제한

# 내구력 설정
$HdurableCore = 3; # 최댓값(0이면 일반, 최대에서99까지)

# 코어를 위장할까요?(1:하다,0:사용 안 함)
$HcoreHide = 0;

# 코어를 보유하지 않은 섬을 침몰 처리할까요?(주!새로 등록된 섬의 개발 기간은 침몰하지 않습니다.)
$HcorelessDead = 0; # 0:침몰하지 않음,1:침몰함,2:사멸 판정 회피 기능 발동(자동 해제 턴 수는 $HautoKeeperSetTurn 에서 설정)

# 이미지 파일은 hako-init.cgi 에서 설정

#----------------------------------------
# 게임의 진행야 파일등
#----------------------------------------
# 메인 페이지에 표시할 섬의 수
# (이보다 늘어나면 여러 페이지로 분할됩니다)
$HviewIslandCount = 10;

# 백업을 몇 턴오키에취는 가
$HbackupTurn = 12;

# 백업을 몇 회분 남음습니까
$HbackupTimes = 4;

# 발견 로그 유지 줄 수(10보다 크면 표시가 깨집니다. 아래의 수치에서 조정해 주세요)
$HhistoryMax = 100;
# 글 표시부의 최대의 고사.
# height 지정값을 초과하면 스크롤 막대가 표시됩니다.
$HdivHeight = 120; # <DIV style="overflow:auto; height:${HdivHeight}px;">

# 실시간 사용(0:사용하지 않음,1:사용함)
$Hrealtimer = 1;

# 개발 화면에서 팝업 내비게이션을 표시할까요?(0:사용하지 않음,1:사용함)
$HpopupNavi = 0;

# 역대 순위를 기록할까요?(상세 설정은 hako-reki.cgi에서 할 수 있습니다)
$HuseRekidai = 1;

# 함정 주변을 매립할 수 있는 문제(버그)를 수정할까요?(0:사용 안 함,1:사용)
$HnavyReclaim = 1;

# 바다에 있는 괴수 주변을 매립할 수 있는 문제(버그)를 수정할까요?(0:사용 안 함,1:사용)
$HmonsterReclaim = 1;

# ST 괴수 파견·ST 미사일 발사 관련 문제(버그)를 수정할까요?(0:사용 안 함,1:사용)
$HattackST = 1;

# 섬의 가장 바깥쪽을 매립 불가로 설정할까요?(0:사용 안 함,1:사용)
# 일부 좌표가 ($HedgeReclaim - 1) 이하 또는 ($HislandSizeX(orY) - $HedgeReclaim) 이상인 지점은 매립할 수 없게 합니다.
# 주!분화에서 육지가 되는 것은 있습니다.
$HedgeReclaim = 2; # $HislandSizeX(orY)/2보다도작은 양의 정수를 설정

# 착탄 지점을 지도에 표시할까요?(0:사용 안 함,1:사용)
$HmlogMap = 1;

# 다른 사람이자금을 볼 수 없게 할지
# 0 보이지 않음
# 1 표시 가능
# 2 100의 위에서 반올림
$HhideMoneyMode = 2;

# 개간 계열 로그의 정리메에좌표도출력하다?(0:사용 안 함 1:하다)
# 개간·땅고르기·매립·굴착·벌채
$HoutPoint = 1;

# 각 섬 수입·지출 로그(기밀)을 출력하다?(0:사용 안 함 1:하다)
$HbalanceLog = 1;

# JavaScript 의 일부를 외부 파일화할까요?(0:사용 안 함 1:하다)
$HextraJs = 0;

#----------------------------------------------------------------------
# 명령 관련 설정
#----------------------------------------------------------------------
# 복합 지형계(복합 지형와 중복하다기능의 지형이 있는 경우의 금지 설정)
#-------------------------------------------------------------
# '공장 건설'을 사용할까요?(0:금지)
$HuseFactory = 1;

# '농장 건설'를사용할까요?(0:금지)
$HuseFarm = 1;

# '채굴장 건설'를사용할까요?(0:금지)
$HuseMountain = 1;

# '나무 심기·벌채'를사용할까요?(0:금지)
$HusePlantSellTree = 1;

# 고속계(턴 소비 없음)
#-----------------------
# 벌채를 턴 소비 없이 실행할까요?(0:사용 안 함,1:사용)
$HnoturnSellTree = 1;

# '고속매립'을 사용할까요?(0:금지)
$HuseFastReclaim = 1;

# '고속굴착'을 사용할까요?(0:금지)
$HuseFastDestroy = 1;

# '고속 공장 건설'을 사용할까요?(0:금지)
$HuseFastFactory = 1;

# '고속 농장 건설'를사용할까요?(0:금지) 참고: 토너먼트 모드에서 사용.
$HuseFastFarm = 1;

# '일괄 땅고르기'를사용할까요?(0:금지) 참고: 서바이벌 모드에서 사용.
$HusePrepare3 = 1;
# 일괄 자동 땅고르기용
$precheap = 10; # 몇 번째 황무지부터 할인할지(이 수 다음의 황무지부터)
$precheap2 = 8; # 그 시의 할인률(8로 설정하면 20% 할인이라는 뜻입니다)
#----------------------------------------
# 섬의 신규 등록 시의 설정
#----------------------------------------
# 섬의 면적을 통일할까요?
$HnewIslandSetting = 0;

# 통일 시의 설정
$HcountLandArea = 32; # 육지의 수(일반:32) 주!16보다 작은 값으로 해도 최소 16입니다.
$HcountLandSea = 16; # 바다(얕은 바다)의 수(일반:16)

$HcountLandWaste = 8; # 황무지의 수(일반:8)
$HcountLandForest = 4; # 숲의 수(일반:4)
$HcountLandTown = 2; # 읍의 수:무인화 회피 기능에도 유효(일반:2 서바이벌:10)
$HcountLandMountain = 1; # 산의 수(일반:1 서바이벌:0)
$HcountLandPort = 0; # 군항의 수(일반:0 서바이벌:0)
$HcountLandBase = 0; # 기지의 수(일반:1 서바이벌:0 주!사용할 때만)

# 규것 설정(통일하고만약없어도유효)
$HvalueLandForest = 5; # 숲의 규모(일반:5 서바이벌:10)
$HvalueLandTown = 5; # 읍의 규모(일반:5 서바이벌:100)
$HvalueLandMountain = 0; # 산(채굴장)의 규모(일반:0)
#주·숲나 채굴장은 복합 지형에서는 없습니다!
#----------------------------------------
#자금, 식량등의 설정 값와 단위
#----------------------------------------
# '자금 조달' 수입(일반은, 노멀:10, 서바이벌:100)
$HdoNothingMoney = 10;

# 최대자금
$HmaximumMoney = 99999;

# 최대식량
$HmaximumFood = 9999;

#자금의 단위
$HunitMoney = '억 엔';

# 식량의 단위
$HunitFood = '00톤';

# 인구의 단위
$HunitPop = '00인';

# 면적의 단위
$HunitArea = '00만 평';

# 나무 수의 단위
$HunitTree = '00본';

# 목재 단위당 판매 수입
$HtreeValue = 5;

# 1턴에서 늘어나는 나무 수(단위당거나)일반은1
$HtreeGrow = 1;

# 이름 변경의 비용
$HcostChangeName = 500;

# 인구 1단위당 식량 소비량
$HeatenFood = 0.2;

# 괴수의 수의 단위
$HunitMonster = '마리';

# 난이도조정(식량·자금 수입배율:일반레와 에 대한 배율)
$HincomeRate = 1;

#----------------------------------------
# 미사일 관련
#----------------------------------------
# 미사일 기지를 사용할까요?(0:금지)
# (바다전쟁의 균형을 가능하면 사용하지 않는 것을 권장합니다)
$HuseBase = 0;

# 해저 기지를 사용할까요?(0:금지)
# (바다전쟁의 균형을 가능하면 사용하지 않는 것을 권장합니다)
$HuseSbase = 0;

# 기지의 경험치
#----------------------------------------
# 경험치의 최댓값
$HmaxExpPoint = 200; # 단, 최대 255까지

# 레벨의 최댓값
$maxBaseLevel = 5; # 미사일 기지
$maxSBaseLevel = 3; # 해저 기지

# 경험치가 몇 점이면 레벨업할지
@baseLevelUp = (20, 60, 120, 200); # 미사일 기지
@sBaseLevelUp = (50, 200); # 해저 기지

my($num, $cno);
#----------------------------------------
# 미사일
#----------------------------------------
# ST 미사일을 사용할까요?(0:금지)
$HuseMissileST = 0;

# 사거리 안에 괴수·거대괴수가 없으면, 미사일 발사를 중지할까요?(0:사용 안 함,1:사용)
$HtargetMonster = 0;

# 미사일에 피격된 함정이나 지형이 자기 섬인 경우 무해화할까요?(0:사용 안 함, 1:사용, 2:우호국도 무해화)
$HmissileSafetyZone = 2;
# 무해화가 무효화될 확률(%) 참고: 무해화 기능이 발동하는 상황에서 판정
$HmissileSafetyInvalidp = 0;

# 미사일 종류(최대10종류)
### 미사일
$num = 0; # 배열번호
$HmissileName[$num] = '미사일'; # 이름
$HmissileMsgs[$num] = '오차2'; # 미사일의 설명
$HmissileCost[$num] = 20; # 발사비용
$HmissileTurn[$num] = 1; # 턴 소비(ST 의 연속은 불가)
$HmissileDamage[$num] = 0; # 파괴력(명중 시의 피해) 참고: 내구력이 있는 지형이 대상. 설정하지 않으면 1이므로, 2 이상의 수치를 설정하는 경우에 사용.
$HmissileErr[$num] = 2; # 오차(Hex)
$HmissileSpecial[$num] = 0x0; # 속성
# 0x0 없음
# 0x1 ST(스텔스 미사일)발사한 섬 이름으로 화면에 표시되지 않습니다.
# 0x2 육지파괴(산→황무지(육계 지형)→얕은 바다(바다계 지형)→바다)
# 0x4 융단 폭격(첫 탄의 착탄 지점의 주변 여러 헥스를 공격)
# 0x10 경화무효(대괴수·거대괴수)
# 0x20 잠수무효(대괴수·거대괴수·잠수능력보유함·기뢰·해저시설)

#'융단 폭격'주변 몇 Hex 대상입니까?참고: 1~2을 설정.
$HmissileTerrorHex[$num] = 0;# 전체 범위에 융단 폭격을 하려면 1Hex는 7발, 2Hex는 19발이 필요합니다. 결과적으로 공격 오차가 커집니다.

### PP 미사일
$num = 1; # 배열번호
$HmissileName[$num] = 'PP 미사일'; # 이름
$HmissileMsgs[$num] = '오차1'; # 설명
$HmissileCost[$num] = 50; # 발사비용
$HmissileTurn[$num] = 1; # 턴 소비
$HmissileDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmissileErr[$num] = 1; # 오차(Hex)
$HmissileSpecial[$num] = 0x0; # 속성
$HmissileTerrorHex[$num] = 0; #'융단 폭격'Hex

### ST 미사일
$num = 2; # 배열번호
$HmissileName[$num] = 'ST 미사일'; # 이름
$HmissileMsgs[$num] = '오차2, 의미 없이 공격하는 것은 피하세요'; # 설명
$HmissileCost[$num] = 50; # 발사비용
$HmissileTurn[$num] = 0; # 턴 소비
$HmissileDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmissileErr[$num] = 2; # 오차(Hex)
$HmissileSpecial[$num] = 0x1; # 속성
$HmissileTerrorHex[$num] = 0; #'융단 폭격'Hex

### 육지 파괴탄
$num = 3; # 배열번호
$HmissileName[$num] = '육지 파괴탄'; # 이름
$HmissileMsgs[$num] = '오차2, 육파괴(산→황무지→얕은 바다→바다)'; # 설명
$HmissileCost[$num] = 100; # 발사비용
$HmissileDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmissileTurn[$num] = 1; # 턴 소비
$HmissileErr[$num] = 2; # 오차(Hex)
$HmissileSpecial[$num] = 0x2; # 속성
$HmissileTerrorHex[$num] = 0; #'융단 폭격'Hex

### 확장분 산 미사일
#$num = 4; # 배열번호
#$HmissileName[$num] = '확장분 산 미사일'; # 이름
#$HmissileMsgs[$num] = '오차2, 착탄 지점의 주변 1Hex 을파괴. 비용은1발주변에서7발이상의 발사능력와 설정이필요'; # 설명
#$HmissileCost[$num] = 100; # 발사비용
#$HmissileTurn[$num] = 1; # 턴 소비
#$HmissileDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
#$HmissileErr[$num] = 2; # 오차(Hex)
#$HmissileSpecial[$num] = 0x4; # 속성
#$HmissileTerrorHex[$num] = 1; #'융단 폭격'Hex

#----------------------------------------
# 방위 시설
#----------------------------------------
# 보유 가능 횟수를 지정
$HdBaseMax = 1; # 0:무제한

# 괴수에게 밟힘된 시자폭할까요?(1:하다,0:사용 안 함)
$HdBaseAuto = 1;

# 방위 시설을 숲에위장할까요?(1:하다,0:사용 안 함)
$HdBaseHide = 1;

# 자기 섬 공격은 자기 섬의 방위권역(타 섬의 방위 권역이 아닌 지점)에 착탄하게 할까요?참고: 즉방위하지 않음라는 것.(방위의 무효화)
# (0:착탄하지 않음(방위한다는 뜻),1:자기 섬 공격만 착탄,2:나를 우호국으로 설정한 섬 공격도 착탄,3:내가 우호국으로 설정한 섬 공격도 착탄,4:내가 우호국으로 설정한 섬 공격도, 나를 우호국으로 설정한 섬 공격도 착탄)
$HdBaseSelfNoDefenceNV = 1; # 함대 공격
$HdBaseSelfNoDefenceMS = 1; # 미사일 공격
$HdBaseSelfNoDefenceMA = 1; # 괴수의 미사일 공격

# 내구력 설정
$HdurableDef = 3; # 최댓값(0이면 일반, 최대98)
$HdefLevelUp = 2; # 내구력이 이 설정값 이상이 되면 방위 범위가 3헥스가 됩니다.
# 주!이를 설정하고 있을 시에, 자폭하게싶을 경우수량'99'을지정해나 합니다.
# 0모1모내구력의 최댓값은1이지만,0이면추가건설에서 자폭,1이면'99'로 자폭입니다.
$HdefExplosion = 99; # 자폭 수량을 '99'이외로 설정한 경우에 변경.100 이상으로 하면 자폭이 불가능해집니다.
#----------------------------------------
# 재해
#----------------------------------------
# 일반 재해 발생률(확률은0.1%단위)
$HdisEarthquake = 5; # 지진
$HdisTyphoon = 20; # 태풍
$HdisMeteo = 15; # 운석
$HdisHugeMeteo = 5; # 거대운석
$HdisEruption = 10; # 분화
$HdisFire = 10; # 화재
$HdisMaizo = 10; # 매장금

# 쓰나미
$HdisTsunami = 15; # 발생률
$HdisTsunamiDmax = 3; # 쓰나미가 해군에부여 가능 피해의 최댓값
$HdisTsunamiFsea = 20; # 바다 면적 플래그: 이 값을 밑돌면 쓰나미 발생 확률이 크게 증가.

# 지반 침하
$HdisFallBorder = 90; # 안정 전체한계의 면적(Hex 수)
$HdisFalldown = 30; # 그 면적를 초과한 경우 확률

#----------------------------------------
# 방파제·기뢰
#----------------------------------------
# 방파제를 사용할까요?(0:금지) 참고: 사이 경우,bouha.gif 이필요입니다.
$HuseBouha = 1; # 보유 가능 횟수를 지정

# 기뢰를 사용할까요?(0:금지) 참고: 사이 경우,seamine.gif 이필요입니다.
$HuseSeaMine = 1; # 설치 가능 여부를 지정
# 파괴력의 최댓값
$HmineDamageMax = 2;
# 자기 섬의 기뢰에서 피해를 받을까요?(0:받음,1:받지 않음,2:우호국도 받지 않음)
$HmineSelfDamage = 2;

#----------------------------------------
# 유전
#----------------------------------------
# 유전 수입
$HoilMoney = 1000;

# 유전 수입을 무작위로(0:사용 안 함,1~:최소값을 설정합니다.$HoilMoney 이 최댓값이 됨)
$HoilMoneyMin = 0;

# 유전의 고갈확률
$HoilRatio = 40;

#----------------------------------------
# 도시계 설정
#----------------------------------------
# 명칭
#@HlandTownName = ('마을', '읍', '도시', '대 도시', '거대 도시', '초과 거대 도시');
@HlandTownName = ('마을', '읍', '도시');

# 이미지
#@HlandTownImage = ('land3.gif', 'land4.gif', 'land5.gif', 'land41.gif', 'land42.gif', 'land43.gif');
@HlandTownImage = ('land3.gif', 'land4.gif', 'land5.gif');

# 랭크업에 필요한 지형 값의 최소값(지형 값이 이 값 이상이면 랭크업)
#@HlandTownValue = ( 0, 30, 100, 200, 300, 400);
@HlandTownValue = ( 0, 30, 100);

# 난민 수용의 상한(난민 수용 후 도시 규모가 아니라 수용 인원의 기준이 되는 숫자 값)
#@HachiveValueMax = ( 50, 50, 50, 50, 50, 50); # 이미 도시계의 경우
@HachiveValueMax = ( 50, 50, 50); # 이미 도시계의 경우
$HachivePlainsMax = 10; # 평지 수용 상한(일반:10)
$HachivePlainsLoss = 5; # 평지 수용 시의 로스(일반:5)
# 주!Max10,Loss5에서 실제 평지 수용은 최대5입니다. 난민 수용에서 평지가 도시 계열이 될 시마다 난민이 5 감소합니다.

# 성장의 최댓값(지형 값 Max:1000000000)
#$HvalueLandTownMax = 500; # 일반 200(20000인)
$HvalueLandTownMax = 200;

# 인구의 증가폭(10이면 최대1000명)
#@Haddpop = ( 10, 10, 10, 10, 10, 0); # 일반(마을, 읍, 도시)=(10, 10, 0)
#@HaddpopPropa = ( 30, 30, 20, 20, 20, 10); # 이주 홍보 중 일반(마을, 읍, 도시)=(30, 30, 10)
#@HaddpopSD = ( 40, 40, 20, 20, 20, 0); # 서바이벌개발 기간 일반(40, 40, 0)
#@HaddpopSDpropa = ( 60, 60, 30, 30, 30, 10); # 서바이벌개발 기간 이주 홍보 중(60, 60, 10)
#@HaddpopSA = ( 5, 5, 5, 5, 5, 0); # 서바이벌전투 기간 일반(5, 5, 0)
#@HaddpopSApropa = ( 10, 10, 10, 10, 10, 3); # 서바이벌전투 기간 이주 홍보 중(10, 10, 3)
@Haddpop = ( 10, 10, 0);
@HaddpopPropa = ( 30, 30, 10);
@HaddpopSD = ( 40, 40, 0);
@HaddpopSDpropa = ( 60, 60, 10);
@HaddpopSA = ( 5, 5, 0);
@HaddpopSApropa = ( 10, 10, 3);

# 식량 부족의 경우의 인구감소 값(마이너스의 값)
@HreductionPop = ( -30,-30,-30,-30,-30,-30); # 일반 -30

# 팝업 내비게이션설명 부분(설정에 따라치환할 필요있음)
$HnaviExp.=<<"END";
TOWN0 = ""; // 마을
TOWN1 = ""; // 읍
TOWN2 = ""; // 도시
TOWN3 = ""; // 대 도시
TOWN4 = ""; // 거대 도시
TOWN5 = ""; // 초과 거대 도시
END

# 마을 의 발생률(%)
$HtownGlow = 20; # 일반 20 토너먼트 25

# 함정 공격·미사일 공격명중 시, 일격으로 황무지 여부와 도시 랭크 하락을 적용할까요?(1:하다,0:사용 안 함)
$HtownStepDown = 0;
# 랭크 2까지(마을·읍)는 일격으로 파괴됩니다.
#----------------------------------------
# 복합 지형
#----------------------------------------
# 복합 지형을 사용할까요?(0:금지)
$HuseComplex = 0;

# 턴 갱신 시속성
# '무작위 수입'최소 값와 최댓값
@HcomplexRinMoney = (10, 100);
# '무작위 수확'최소 값와 최댓값
@HcomplexRinFood = (10, 100);
# '역장능력'주변 몇 Hex 의 괴수·거대괴수를 즉사할까요?
$HcomplexFieldHex = 1;

# 복합 지형의 지형 설정(최대32종류)
#-------------------------------
### 농장
#$num = 0; # 배열번호

# 명칭
#$HcomplexName[$num] = '농장';

# 복합 지형의 이미지 파일
#$HcomplexImage[$num] = 'land7.gif';

# 보유(건설) 가능 최대 수(0:무제한)
#$HcomplexMax[$num] = 0;

# 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
#$HcomplexPretend[$num] = 0;
#$HcomplexPretendName[$num] = ''; # 3의 시의 이름
#$HcomplexPretendImage[$num] = ''; # 3의 시의 이미지
#$HcomplexPretendNavi[$num] = ''; # 팝업 내비게이션설명 'SEA0'등'FOREST'등

# 랭크업 설정
#$HcomplexLevelKind[$num] = 'food'; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
#$HcomplexLevelValue[$num] = [0, 20, 40]; # 랭크업에 필요한플래그 값의 최소 값
#$HcomplexSubName[$num] = ['농장(Lv1)', '농장(Lv2)', '농장(Lv3)'];# 명칭
#$HcomplexSubImage[$num] = ['land7.gif', 'land7.gif', 'land7.gif'];# 이미지

# 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
#$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore2[$num] = []; # 복합 지형을 건설 가능한'별도종의 복합 지형($HlandComplex)' 종류(복수의 경우,[1, 3]처럼쉼표에서 구분하는) 참고: 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요

# 턴 플래그 설정:건설 시를1로서 턴 갱신마다+1됩니다 값
#$HcomplexTPCmax[$num] = 0; # 최대값(Max500)
#$HcomplexTPname[$num] = ''; # 명칭.. 예를 들어,'나무 수','대 도시'
#$HcomplexTPrate[$num] = 0; # 표시배율 플래그에 이 배율을 곱한 값이 표시값
#$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름. 예를 들어,'00본',"$HunitPop"
#$HcomplexTPkind[$num] = ''; # 가 산 종류($island->{KIND}의 KIND 부분).. 예를 들어,'','pop' 주의: 단위를 작게 설정할 수 있음!
#$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)

# 식량 플래그 설정
#$HcomplexFPbase[$num] = 10; # 초기 값 ($HunitPop x 10 규모)
#$HcomplexFPplus[$num] = 2; # 추가 값 ($HunitPop x 10 규모)
#$HcomplexFPCmax[$num] = 20; # 추가 가능 횟수 Max50(최종값은 초기값 + 추가값 x 추가 가능 횟수입니다)
#$HcomplexFPkind[$num] = 'farm'; # 가 산 종류($island->{KIND}의 KIND 부분).. 예를 들어,'','pop' 주의: 단위를 작게 설정할 수 있음!

#자금 플래그 설정
#$HcomplexMPbase[$num] = 0; # 초기 값 ($HunitPop x 10 규모)
#$HcomplexMPplus[$num] = 0; # 추가 값 ($HunitPop x 10 규모)
#$HcomplexMPCmax[$num] = 0; # 추가 가능 횟수 Max50(최종값은 초기값 + 추가값 x 추가 가능 횟수입니다)
#$HcomplexMPkind[$num] = ''; # 가 산 종류($island->{KIND}의 KIND 부분).. 예를 들어,'','pop' 주의: 단위를 작게 설정할 수 있음!

# 턴 갱신 시속성
#$HcomplexAttr[$num] = 0x401;
# 0x1 주변의 평지에 마을이 생성됨(countGrow 판정:농장(읍)으로 카운트됩니다)
# 0x2 화재의 피해를 방어합니다효과(숲나 기념비와 동일등)
# 0x4 태풍의 피해를 방어합니다효과(숲나 기념비와 동일등)
# 0x10 역장발생:괴수·거대괴수를 누름시츠부시즉사하다
# 0x20 주변 2Hex 미사일 방어(방위 시설과 동일한 기능)
# 0x40 주변 2Hex 의 함대 공격 방어(방위 시설과 동일한 기능)
# 0x100 대잠 공격 공격 대상이 됨
# 0x200 대함 공격 공격 대상이 됨
# 0x400 대지 공격 공격 대상이 됨
# 0x1000 무작위 수입
# 0x2000 무작위 수확

### 이하3항목은 개별적으로 설정불가
# '무작위 수입'최소 값와 최댓값
# '무작위 수확'최소 값와 최댓값
# '역장능력'주변 몇 Hex 의 괴수·거대괴수를 즉사할까요?


# 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
# prepare:개간·땅고르기후, reclaim:매립후, destroy:굴착후,
# attack:해군(괴수)공격후,
# stepdown: 피격 시 한 번에 파괴하지 않고 랭크를 낮춥니다. (피해) x (stepdown)을 추가 규모에서 감산 처리합니다.
# move: 괴수 이동 후 플래그. 주의![지형(0:육지, 1:바다), 지형 값(0:깊은 바다, 1:얕은 바다)],
# earthquake:지진후, typhoon:태풍후, fire:화재후, tsunami:쓰나미후, starve:폭동후
# falldown: 지반 침하 후, eruption: 분화 후(중심은 반드시 산이므로 주변부 설정), meteo: 운석 후,
# wide1:광역재해(방위 시설 자폭·거대 미사일·거대운석)후1Hex 주변
# wide2:광역재해(방위 시설 자폭·거대 미사일·거대운석)후2Hex 주변
# !여기에기재되지 않은 경우, 파괴할 수 없(되지 않는)!
#$HcomplexAfter[$num] = { # 농장
#	'prepare' => [$HlandPlains, 0],
#	'reclaim' => '',
#	'destroy' => [$HlandSea, 1],
#	'attack' => [$HlandWaste, 1],
#	'stepdown' => 0,
#	'move' => [0, 0],
#	'earthquake' => '',
#	'typhoon' => [$HlandPlains, 0],
#	'fire' => '',
#	'tsunami' => [$HlandWaste, 0],
#	'starve' => [$HlandWaste, 0],
#	'falldown' => [$HlandSea, 1],
#	'eruption' => [$HlandWaste, 0],
#	'meteo' => [$HlandSea, 0],
#	'wide1' => [$HlandSea, 1],
#	'wide2' => [$HlandWaste, 0],
#};

# 팝업 내비게이션설명 부분(''의간에기술. 설정에 따라치환할 필요있음)
#$HnaviExp.= "COMPLEX$num = '';\n";

### 공장
#$num = 0; # 배열번호
#$HcomplexName[$num] = '공장'; # 명칭
#$HcomplexImage[$num] = 'land8.gif';# 복합 지형의 이미지 파일
#$HcomplexMax[$num] = 0; # 보유(건설) 가능 최대 수(0:무제한)
## 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
#$HcomplexPretend[$num] = 0;
#$HcomplexPretendName[$num] = ''; # 명칭
#$HcomplexPretendImage[$num] = ''; # 이미지
#$HcomplexPretendNavi[$num] = ''; # 내비게이션
## 랭크업 설정
#$HcomplexLevelKind[$num] = 'money'; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
#$HcomplexLevelValue[$num] = [0, 50, 80]; # 랭크업에 필요한플래그 값의 최소 값
#$HcomplexSubName[$num] = ['공장(Lv1)', '공장(Lv2)', '공장(Lv3)'];# 명칭
#$HcomplexSubImage[$num] = ['land8.gif', 'land8.gif', 'land8.gif'];# 이미지
## 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
#$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 200]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore2[$num] = []; # 복합 지형을 별도종만배열번호에서 지정(복수의 경우,[1, 3]처럼쉼표에서 구분하는). 동종의 복합 지형은 기술불필요
## 턴 플래그 설정
#$HcomplexTPCmax[$num] = 0; # 최댓값
#$HcomplexTPname[$num] = ''; # 명칭
#$HcomplexTPrate[$num] = 0; # 표시배율
#$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
#$HcomplexTPkind[$num] = ''; # 가 산 종류
#$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
## 식량 플래그 설정
#$HcomplexFPbase[$num] = 0; # 초기 값
#$HcomplexFPplus[$num] = 0; # 추가 값
#$HcomplexFPCmax[$num] = 0; # 추가 가능 횟수 Max50
#$HcomplexFPkind[$num] = ''; # 가 산 종류
##자금 플래그 설정
#$HcomplexMPbase[$num] = 30; # 초기 값
#$HcomplexMPplus[$num] = 10; # 추가 값
#$HcomplexMPCmax[$num] = 7; # 추가 가능 횟수 Max50
#$HcomplexMPkind[$num] = 'factory'; # 가 산 종류
## 턴 갱신 시속성
#$HcomplexAttr[$num] = 0x400;
## 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
#$HcomplexAfter[$num] = {
#	'prepare' => [$HlandPlains, 0],
#	'reclaim' => '',
#	'destroy' => [$HlandSea, 1],
#	'attack' => [$HlandWaste, 1],
#	'stepdown' => 0,
#	'move' => [0, 0],
#	'earthquake' => [$HlandWaste, 0],
#	'typhoon' => '',
#	'fire' => [$HlandWaste, 0],
#	'tsunami' => [$HlandWaste, 0],
#	'starve' => [$HlandWaste, 0],
#	'falldown' => [$HlandSea, 1],
#	'eruption' => [$HlandWaste, 0],
#	'meteo' => [$HlandSea, 0],
#	'wide1' => [$HlandSea, 1],
#	'wide2' => [$HlandWaste, 0],
#};
#$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분

### 채굴장
#$num = 2; # 배열번호
#$HcomplexName[$num] = '채굴장'; # 명칭
#$HcomplexImage[$num] = 'land15.gif';# 복합 지형의 이미지 파일
#$HcomplexMax[$num] = 0; # 보유(건설) 가능 최대 수(0:무제한)
## 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
#$HcomplexPretend[$num] = 0;
#$HcomplexPretendName[$num] = ''; # 명칭
#$HcomplexPretendImage[$num] = ''; # 이미지
#$HcomplexPretendNavi[$num] = ''; # 내비게이션
## 랭크업 설정
#$HcomplexLevelKind[$num] = ''; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
#$HcomplexLevelValue[$num] = ''; # 랭크업에 필요한플래그 값의 최소 값
#$HcomplexSubName[$num] = '';# 명칭
#$HcomplexSubImage[$num] = '';# 이미지
## 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
#$HcomplexBefore[$num] = [[$HlandMountain, 0, 200]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore2[$num] = [4]; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
## 턴 플래그 설정
#$HcomplexTPCmax[$num] = 0; # 최댓값
#$HcomplexTPname[$num] = ''; # 명칭
#$HcomplexTPrate[$num] = 0; # 표시배율
#$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
#$HcomplexTPkind[$num] = ''; # 가 산 종류
#$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
## 식량 플래그 설정
#$HcomplexFPbase[$num] = 0; # 초기 값
#$HcomplexFPplus[$num] = 0; # 추가 값
#$HcomplexFPCmax[$num] = 0; # 추가 가능 횟수 Max50
#$HcomplexFPkind[$num] = ''; # 가 산 종류
##자금 플래그 설정
#$HcomplexMPbase[$num] = 5; # 초기 값
#$HcomplexMPplus[$num] = 5; # 추가 값
#$HcomplexMPCmax[$num] = 39; # 추가 가능 횟수 Max50
#$HcomplexMPkind[$num] = 'mountain'; # 가 산 종류
## 턴 갱신 시속성
#$HcomplexAttr[$num] = 0x0;
## 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
#$HcomplexAfter[$num] = {
#	'prepare' => '',
#	'reclaim' => '',
#	'destroy' => [$HlandWaste, 0],
#	'attack' => '',
#	'stepdown' => 0,
#	'move' => '',
#	'earthquake' => '',
#	'typhoon' => '',
#	'fire' => '',
#	'tsunami' => '',
#	'starve' => '',
#	'falldown' => '',
#	'eruption' => '',
#	'meteo' => [$HlandWaste, 1],
#	'wide1' => [$HlandSea, 1],
#	'wide2' => '',
#};
#$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분

### 숲
#$num = 0; # 배열번호
#$HcomplexName[$num] = '숲'; # 명칭
#$HcomplexImage[$num] = 'land6.gif';# 복합 지형의 이미지 파일
#$HcomplexMax[$num] = 0; # 보유(건설) 가능 최대 수(0:무제한)
## 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
#$HcomplexPretend[$num] = 0;
#$HcomplexPretendName[$num] = ''; # 명칭
#$HcomplexPretendImage[$num] = ''; # 이미지
#$HcomplexPretendNavi[$num] = ''; # 내비게이션
## 랭크업 설정
#$HcomplexLevelKind[$num] = ''; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
#$HcomplexLevelValue[$num] = ''; # 랭크업에 필요한플래그 값의 최소 값
#$HcomplexSubName[$num] = '';# 명칭
#$HcomplexSubImage[$num] = '';# 이미지
## 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
#$HcomplexBefore[$num] = [[$HlandPlains, 0, 0]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore2[$num] = []; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
## 턴 플래그 설정
#$HcomplexTPCmax[$num] = 500; # 최댓값
#$HcomplexTPname[$num] = '나무 수'; # 명칭
#$HcomplexTPrate[$num] = 1; # 표시배율
#$HcomplexTPunit[$num] = '00본'; # 나머지에 붙일 이름
#$HcomplexTPkind[$num] = ''; # 가 산 종류
#$HcomplexTPhide[$num] = 1; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
## 식량 플래그 설정
#$HcomplexFPbase[$num] = 0; # 초기 값
#$HcomplexFPplus[$num] = 0; # 추가 값
#$HcomplexFPCmax[$num] = 0; # 추가 가능 횟수 Max50
#$HcomplexFPkind[$num] = ''; # 가 산 종류
##자금 플래그 설정
#$HcomplexMPbase[$num] = 0; # 초기 값
#$HcomplexMPplus[$num] = 0; # 추가 값
#$HcomplexMPCmax[$num] = 0; # 추가 가능 횟수 Max50
#$HcomplexMPkind[$num] = ''; # 가 산 종류
## 턴 갱신 시속성
#$HcomplexAttr[$num] = 0x406;
## 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
#$HcomplexAfter[$num] = {
#	'prepare' => [$HlandPlains, 0],
#	'reclaim' => '',
#	'destroy' => [$HlandSea, 1],
#	'attack' => [$HlandWaste, 1],
#	'stepdown' => 0,
#	'move' => [0, 0],
#	'earthquake' => '',
#	'typhoon' => '',
#	'fire' => '',
#	'tsunami' => '',
#	'starve' => '',
#	'falldown' => [$HlandSea, 1],
#	'eruption' => [$HlandWaste, 0],
#	'meteo' => [$HlandSea, 0],
#	'wide1' => [$HlandSea, 1],
#	'wide2' => [$HlandWaste, 0],
#};
#$HnaviExp.= "COMPLEX$num = '1${HunitTree}주변${HtreeValue}${HunitMoney}';\n"; # 팝업 내비게이션설명 부분

### 건조 산
#$num = 0; # 배열번호
#$HcomplexName[$num] = '건조 산'; # 명칭
#$HcomplexImage[$num] = 'land11.gif';# 복합 지형의 이미지 파일
#$HcomplexMax[$num] = 0; # 보유(건설) 가능 최대 수(0:무제한)
## 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
#$HcomplexPretend[$num] = 0;
#$HcomplexPretendName[$num] = ''; # 명칭
#$HcomplexPretendImage[$num] = ''; # 이미지
#$HcomplexPretendNavi[$num] = ''; # 내비게이션
## 랭크업 설정
#$HcomplexLevelKind[$num] = ''; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
#$HcomplexLevelValue[$num] = ''; # 랭크업에 필요한플래그 값의 최소 값
#$HcomplexSubName[$num] = '';# 명칭
#$HcomplexSubImage[$num] = '';# 이미지
## 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
#$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore2[$num] = [2]; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
## 턴 플래그 설정
#$HcomplexTPCmax[$num] = 0; # 최댓값
#$HcomplexTPname[$num] = ''; # 명칭
#$HcomplexTPrate[$num] = 0; # 표시배율
#$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
#$HcomplexTPkind[$num] = ''; # 가 산 종류
#$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
## 식량 플래그 설정
#$HcomplexFPbase[$num] = 0; # 초기 값
#$HcomplexFPplus[$num] = 0; # 추가 값
#$HcomplexFPCmax[$num] = 0; # 추가 가능 횟수 Max50
#$HcomplexFPkind[$num] = ''; # 가 산 종류
##자금 플래그 설정
#$HcomplexMPbase[$num] = 0; # 초기 값
#$HcomplexMPplus[$num] = 0; # 추가 값
#$HcomplexMPCmax[$num] = 1; # 추가 가능 횟수 Max50
#$HcomplexMPkind[$num] = ''; # 가 산 종류
## 턴 갱신 시속성
#$HcomplexAttr[$num] = 0x6;
## 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
#$HcomplexAfter[$num] = {
#	'prepare' => '',
#	'reclaim' => '',
#	'destroy' => [$HlandWaste, 0],
#	'attack' => '',
#	'stepdown' => 0,
#	'move' => '',
#	'earthquake' => '',
#	'typhoon' => '',
#	'fire' => '',
#	'tsunami' => '',
#	'starve' => '',
#	'falldown' => '',
#	'eruption' => '',
#	'meteo' => [$HlandWaste, 1],
#	'wide1' => [$HlandSea, 1],
#	'wide2' => '',
#};
#$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분

### S농장
$num = 0; # 배열번호
$HcomplexName[$num] = 'S농장'; # 명칭
$HcomplexImage[$num] = 'farm3.gif';# 복합 지형의 이미지 파일
$HcomplexMax[$num] = 10; # 보유(건설) 가능 최대 수(0:무제한)
# 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
$HcomplexPretend[$num] = 1;
$HcomplexPretendName[$num] = ''; # 명칭
$HcomplexPretendImage[$num] = ''; # 이미지
$HcomplexPretendNavi[$num] = ''; # 내비게이션
# 랭크업 설정
$HcomplexLevelKind[$num] = 'food'; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
$HcomplexLevelValue[$num] = [0, 20, 30, 40, 50]; # 랭크업에 필요한플래그 값의 최소 값
$HcomplexSubName[$num] = ['S농장(Lv1)', 'S농장(Lv2)', 'S농장(Lv3)', 'S농장(Lv4)', 'S농장(Lv5)'];# 명칭
$HcomplexSubImage[$num] = ['farm3.gif', 'farm3.gif', 'farm3.gif', 'farm3.gif', 'farm3.gif'];# 이미지
# 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199], [$HlandFarm, 0, 50]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199]];# 복합 지형($HlandComplex)이외
$HcomplexBefore2[$num] = [1, 3]; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
# 턴 플래그 설정
$HcomplexTPCmax[$num] = 0; # 최댓값
$HcomplexTPname[$num] = ''; # 명칭
$HcomplexTPrate[$num] = 0; # 표시배율
$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
$HcomplexTPkind[$num] = ''; # 가 산 종류
$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
# 식량 플래그 설정
$HcomplexFPbase[$num] = 10; # 초기 값
$HcomplexFPplus[$num] = 2; # 추가 값
$HcomplexFPCmax[$num] = 20; # 추가 가능 횟수 Max50
$HcomplexFPkind[$num] = 'farm'; # 가 산 종류
#자금 플래그 설정
$HcomplexMPbase[$num] = 0; # 초기 값
$HcomplexMPplus[$num] = 0; # 추가 값
$HcomplexMPCmax[$num] = 0; # 추가 가능 횟수 Max50
$HcomplexMPkind[$num] = ''; # 가 산 종류
# 턴 갱신 시속성
$HcomplexAttr[$num] = 0x403;
# 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
$HcomplexAfter[$num] = {
	'prepare' => [$HlandPlains, 0],
	'reclaim' => '',
	'destroy' => [$HlandSea, 1],
	'attack' => [$HlandWaste, 1],
	'stepdown' => 1,
	'move' => [0, 0],
	'earthquake' => '',
	'typhoon' => [$HlandPlains, 0],
	'fire' => '',
	'tsunami' => [$HlandWaste, 0],
	'starve' => [$HlandWaste, 0],
	'falldown' => [$HlandSea, 1],
	'eruption' => [$HlandWaste, 0],
	'meteo' => [$HlandSea, 0],
	'wide1' => [$HlandSea, 1],
	'wide2' => [$HlandWaste, 0],
};
$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분

### S공장
$num = 1; # 배열번호
$HcomplexName[$num] = 'S공장'; # 명칭
$HcomplexImage[$num] = 'factory1.gif';# 복합 지형의 이미지 파일
$HcomplexMax[$num] = 10; # 보유(건설) 가능 최대 수(0:무제한)
# 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
$HcomplexPretend[$num] = 2;
$HcomplexPretendName[$num] = ''; # 명칭
$HcomplexPretendImage[$num] = ''; # 이미지
$HcomplexPretendNavi[$num] = ''; # 내비게이션
# 랭크업 설정
$HcomplexLevelKind[$num] = 'money'; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
$HcomplexLevelValue[$num] = [0, 50, 70, 90, 100]; # 랭크업에 필요한플래그 값의 최소 값
$HcomplexSubName[$num] = ['S공장(Lv1)', 'S공장(Lv2)', 'S공장(Lv3)', 'S공장(Lv4)', 'S공장(Lv5)'];# 명칭
$HcomplexSubImage[$num] = ['factory1.gif', 'factory1.gif', 'factory1.gif', 'factory1.gif', 'factory1.gif'];# 이미지
# 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199], [$HlandFactory, 0, 100]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199]];# 복합 지형($HlandComplex)이외
$HcomplexBefore2[$num] = [0, 4]; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
# 턴 플래그 설정
$HcomplexTPCmax[$num] = 0; # 최댓값
$HcomplexTPname[$num] = ''; # 명칭
$HcomplexTPrate[$num] = 0; # 표시배율
$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
$HcomplexTPkind[$num] = ''; # 가 산 종류
$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
# 식량 플래그 설정
$HcomplexFPbase[$num] = 0; # 초기 값
$HcomplexFPplus[$num] = 0; # 추가 값
$HcomplexFPCmax[$num] = 0; # 추가 가능 횟수 Max50
$HcomplexFPkind[$num] = ''; # 가 산 종류
#자금 플래그 설정
$HcomplexMPbase[$num] = 30; # 초기 값
$HcomplexMPplus[$num] = 10; # 추가 값
$HcomplexMPCmax[$num] = 7; # 추가 가능 횟수 Max50
$HcomplexMPkind[$num] = 'factory'; # 가 산 종류
# 턴 갱신 시속성
$HcomplexAttr[$num] = 0x404;
# 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
$HcomplexAfter[$num] = {
	'prepare' => [$HlandPlains, 0],
	'reclaim' => '',
	'destroy' => [$HlandSea, 1],
	'attack' => [$HlandWaste, 1],
	'stepdown' => 1,
	'move' => [0, 0],
	'earthquake' => [$HlandWaste, 0],
	'typhoon' => '',
	'fire' => [$HlandWaste, 0],
	'tsunami' => [$HlandWaste, 0],
	'starve' => [$HlandWaste, 0],
	'falldown' => [$HlandSea, 1],
	'eruption' => [$HlandWaste, 0],
	'meteo' => [$HlandSea, 0],
	'wide1' => [$HlandSea, 1],
	'wide2' => [$HlandWaste, 0],
};
$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분

### S채굴장
$num = 2; # 배열번호
$HcomplexName[$num] = 'S채굴장'; # 명칭
$HcomplexImage[$num] = 'mountain1.gif';# 복합 지형의 이미지 파일
$HcomplexMax[$num] = 10; # 보유(건설) 가능 최대 수(0:무제한)
# 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
$HcomplexPretend[$num] = 0;
$HcomplexPretendName[$num] = ''; # 명칭
$HcomplexPretendImage[$num] = ''; # 이미지
$HcomplexPretendNavi[$num] = ''; # 내비게이션
# 랭크업 설정
$HcomplexLevelKind[$num] = ''; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
$HcomplexLevelValue[$num] = ''; # 랭크업에 필요한플래그 값의 최소 값
$HcomplexSubName[$num] = '';# 명칭
$HcomplexSubImage[$num] = '';# 이미지
# 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
$HcomplexBefore[$num] = [[$HlandMountain, 0, 200]];# 복합 지형($HlandComplex)이외
$HcomplexBefore2[$num] = [5]; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
# 턴 플래그 설정
$HcomplexTPCmax[$num] = 0; # 최댓값
$HcomplexTPname[$num] = ''; # 명칭
$HcomplexTPrate[$num] = 0; # 표시배율
$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
$HcomplexTPkind[$num] = ''; # 가 산 종류
$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
# 식량 플래그 설정
$HcomplexFPbase[$num] = 0; # 초기 값
$HcomplexFPplus[$num] = 0; # 추가 값
$HcomplexFPCmax[$num] = 0; # 추가 가능 횟수 Max50
$HcomplexFPkind[$num] = ''; # 가 산 종류
#자금 플래그 설정
$HcomplexMPbase[$num] = 5; # 초기 값
$HcomplexMPplus[$num] = 5; # 추가 값
$HcomplexMPCmax[$num] = 39; # 추가 가능 횟수 Max50
$HcomplexMPkind[$num] = 'mountain'; # 가 산 종류
# 턴 갱신 시속성
$HcomplexAttr[$num] = 0x4;
# 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
$HcomplexAfter[$num] = {
	'prepare' => '',
	'reclaim' => '',
	'destroy' => [$HlandWaste, 0],
	'attack' => '',
	'stepdown' => 0,
	'move' => '',
	'earthquake' => '',
	'typhoon' => '',
	'fire' => '',
	'tsunami' => '',
	'starve' => '',
	'falldown' => '',
	'eruption' => '',
	'meteo' => [$HlandWaste, 1],
	'wide1' => [$HlandSea, 1],
	'wide2' => '',
};
$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분

### 대 농장
$num = 3; # 배열번호
$HcomplexName[$num] = '대 농장'; # 명칭
$HcomplexImage[$num] = 'land21.gif';# 복합 지형의 이미지 파일
$HcomplexMax[$num] = 3; # 보유(건설) 가능 최대 수(0:무제한)
# 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
$HcomplexPretend[$num] = 0;
$HcomplexPretendName[$num] = ''; # 명칭
$HcomplexPretendImage[$num] = ''; # 이미지
$HcomplexPretendNavi[$num] = ''; # 내비게이션
# 랭크업 설정
$HcomplexLevelKind[$num] = 'food'; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
$HcomplexLevelValue[$num] = [0, 200, 300, 400, 500]; # 랭크업에 필요한플래그 값의 최소 값
$HcomplexSubName[$num] = ['대 농장(Lv1)', '대 농장(Lv2)', '대 농장(Lv3)', '대 농장(Lv4)', '대 농장(Lv5)'];# 명칭
$HcomplexSubImage[$num] = ['land21.gif', 'land21.gif', 'land21.gif', 'land21.gif', 'land21.gif'];# 이미지
# 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199], [$HlandFarm, 0, 50]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199]];# 복합 지형($HlandComplex)이외
$HcomplexBefore2[$num] = [0, 1]; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
# 턴 플래그 설정
$HcomplexTPCmax[$num] = 0; # 최댓값
$HcomplexTPname[$num] = ''; # 명칭
$HcomplexTPrate[$num] = 0; # 표시배율
$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
$HcomplexTPkind[$num] = ''; # 가 산 종류
$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
# 식량 플래그 설정
$HcomplexFPbase[$num] = 100; # 초기 값
$HcomplexFPplus[$num] = 20; # 추가 값
$HcomplexFPCmax[$num] = 20; # 추가 가능 횟수 Max50
$HcomplexFPkind[$num] = 'farm'; # 가 산 종류
#자금 플래그 설정
$HcomplexMPbase[$num] = 0; # 초기 값
$HcomplexMPplus[$num] = 0; # 추가 값
$HcomplexMPCmax[$num] = 0; # 추가 가능 횟수 Max50
$HcomplexMPkind[$num] = ''; # 가 산 종류
# 턴 갱신 시속성
$HcomplexAttr[$num] = 0x2425;
# 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
$HcomplexAfter[$num] = {
	'prepare' => [$HlandPlains, 0],
	'reclaim' => '',
	'destroy' => [$HlandSea, 1],
	'attack' => [$HlandWaste, 1],
	'stepdown' => 1,
	'move' => [0, 0],
	'earthquake' => '',
	'typhoon' => [$HlandPlains, 0],
	'fire' => '',
	'tsunami' => [$HlandWaste, 0],
	'starve' => [$HlandWaste, 0],
	'falldown' => [$HlandSea, 1],
	'eruption' => [$HlandWaste, 0],
	'meteo' => [$HlandSea, 0],
	'wide1' => [$HlandSea, 1],
	'wide2' => [$HlandWaste, 0],
};
$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분

### 대 공장
$num = 4; # 배열번호
$HcomplexName[$num] = '대 공장'; # 명칭
$HcomplexImage[$num] = 'land22.gif';# 복합 지형의 이미지 파일
$HcomplexMax[$num] = 3; # 보유(건설) 가능 최대 수(0:무제한)
# 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타)
$HcomplexPretend[$num] = 0;
$HcomplexPretendName[$num] = ''; # 명칭
$HcomplexPretendImage[$num] = ''; # 이미지
$HcomplexPretendNavi[$num] = ''; # 내비게이션
# 랭크업 설정
$HcomplexLevelKind[$num] = 'money'; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
$HcomplexLevelValue[$num] = [0, 500, 700, 900, 1000]; # 랭크업에 필요한플래그 값의 최소 값
$HcomplexSubName[$num] = ['대 공장(Lv1)', '대 공장(Lv2)', '대 공장(Lv3)', '대 공장(Lv4)', '대 공장(Lv5)'];# 명칭
$HcomplexSubImage[$num] = ['land22.gif', 'land22.gif', 'land22.gif', 'land22.gif', 'land22.gif'];# 이미지
# 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199], [$HlandFactory, 0, 100]];# 복합 지형($HlandComplex)이외
#$HcomplexBefore[$num] = [[$HlandPlains, 0, 0], [$HlandTown, 0, 199]];# 복합 지형($HlandComplex)이외
$HcomplexBefore2[$num] = [0, 1]; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
# 턴 플래그 설정
$HcomplexTPCmax[$num] = 0; # 최댓값
$HcomplexTPname[$num] = ''; # 명칭
$HcomplexTPrate[$num] = 0; # 표시배율
$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
$HcomplexTPkind[$num] = ''; # 가 산 종류
$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
# 식량 플래그 설정
$HcomplexFPbase[$num] = 0; # 초기 값
$HcomplexFPplus[$num] = 0; # 추가 값
$HcomplexFPCmax[$num] = 0; # 추가 가능 횟수 Max50
$HcomplexFPkind[$num] = ''; # 가 산 종류
#자금 플래그 설정
$HcomplexMPbase[$num] = 300; # 초기 값
$HcomplexMPplus[$num] = 100; # 추가 값
$HcomplexMPCmax[$num] = 7; # 추가 가능 횟수 Max50
$HcomplexMPkind[$num] = 'factory'; # 가 산 종류
# 턴 갱신 시속성
$HcomplexAttr[$num] = 0x1450;
# 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
$HcomplexAfter[$num] = {
	'prepare' => [$HlandPlains, 0],
	'reclaim' => '',
	'destroy' => [$HlandSea, 1],
	'attack' => [$HlandWaste, 1],
	'stepdown' => 1,
	'move' => [0, 0],
	'earthquake' => [$HlandWaste, 0],
	'typhoon' => '',
	'fire' => [$HlandWaste, 0],
	'tsunami' => [$HlandWaste, 0],
	'starve' => [$HlandWaste, 0],
	'falldown' => [$HlandSea, 1],
	'eruption' => [$HlandWaste, 0],
	'meteo' => [$HlandSea, 0],
	'wide1' => [$HlandSea, 1],
	'wide2' => [$HlandWaste, 0],
};
$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분

### 대채굴장
$num = 5; # 배열번호
$HcomplexName[$num] = '대채굴장'; # 명칭
$HcomplexImage[$num] = 'land23.gif';# 복합 지형의 이미지 파일
$HcomplexMax[$num] = 10; # 보유(건설) 가능 최대 수(0:무제한)
# 위장 설정(0:위장 없음,1:숲인 척,2:바다인 척,3:기타 육지계,4:기타 바다계,)
$HcomplexPretend[$num] = 0;
$HcomplexPretendName[$num] = ''; # 명칭
$HcomplexPretendImage[$num] = ''; # 이미지
$HcomplexPretendNavi[$num] = ''; # 내비게이션
# 랭크업 설정
$HcomplexLevelKind[$num] = ''; # 랭크업의 원래가 됨플래그 종류('turn' 또는 'food' 또는 'money')
$HcomplexLevelValue[$num] = ''; # 랭크업에 필요한플래그 값의 최소 값
$HcomplexSubName[$num] = '';# 명칭
$HcomplexSubImage[$num] = '';# 이미지
# 복합 지형을 건설할 수 있는 지형을 변수에 기술([지형, 지형 값 min, 지형 값 max], [지형, 지형 값 min, 지형 값 max],...) 참고: $HlandComplex는 기술할 필요 없음)
$HcomplexBefore[$num] = [[$HlandMountain, 0, 200]];# 복합 지형($HlandComplex)이외
$HcomplexBefore2[$num] = [2]; # 복합 지형을 별도종만배열번호에서 지정. 동종의 복합 지형은 기술불필요
# 턴 플래그 설정
$HcomplexTPCmax[$num] = 0; # 최댓값
$HcomplexTPname[$num] = ''; # 명칭
$HcomplexTPrate[$num] = 0; # 표시배율
$HcomplexTPunit[$num] = ''; # 나머지에 붙일 이름
$HcomplexTPkind[$num] = ''; # 가 산 종류
$HcomplexTPhide[$num] = 0; # 관광객에서 보이지 않게 할지(0:사용 안 함,1:사용)
# 식량 플래그 설정
$HcomplexFPbase[$num] = 0; # 초기 값
$HcomplexFPplus[$num] = 0; # 추가 값
$HcomplexFPCmax[$num] = 0; # 추가 가능 횟수 Max50
$HcomplexFPkind[$num] = ''; # 가 산 종류
#자금 플래그 설정
$HcomplexMPbase[$num] = 50; # 초기 값
$HcomplexMPplus[$num] = 50; # 추가 값
$HcomplexMPCmax[$num] = 39; # 추가 가능 횟수 Max50
$HcomplexMPkind[$num] = 'mountain'; # 가 산 종류
# 턴 갱신 시속성
$HcomplexAttr[$num] = 0x6;
# 파괴되었을 시의 지형을 변수에서 기술('파괴 종류' => [지형, 지형 값])
$HcomplexAfter[$num] = {
	'prepare' => '',
	'reclaim' => '',
	'destroy' => [$HlandWaste, 0],
	'attack' => '',
	'stepdown' => 0,
	'move' => '',
	'earthquake' => '',
	'typhoon' => '',
	'fire' => '',
	'tsunami' => '',
	'starve' => '',
	'falldown' => '',
	'eruption' => '',
	'meteo' => [$HlandWaste, 1],
	'wide1' => [$HlandSea, 1],
	'wide2' => '',
};
$HnaviExp.= "COMPLEX$num = '';\n"; # 팝업 내비게이션설명 부분


# 복합 지형 명령 설정(최대50종류)
#---------------------------------
### 농장 건설
$cno = 0; # 배열번호

# 복합 지형 개발 명령
$HcomplexComName[$cno] = '농장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '식량 생산 시설입니다. 최대 5만 명 규모까지 확장할 수 있습니다. (복수 가능)'; # 설명
$HcomplexComKind[$cno] = 0; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 20; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x2; # 대상이 되는 플래그
# 0x0:건설(설치)만
# 0x1:턴 재설정
# 0x2:식량추가
# 0x4:자금추가

# 턴 재설정 시(플래그가0에이 경우)의 처리
# 지형변화
# 변화후의 지형와 지형 값
# 또한, 턴 플래그 최댓값이0의 경우무효이므로''이면 됩니다
$HcomplexComTFRL[$cno] = ["", ""]; # 변화가 없는 경우''이면 됩니다(0은 안 됨.)
# 수입·수확 처리(플래그숫자 값에 대한 배율)
# type:식량 food,자금 money 의중 하나
# ratio:배율 설정(food 이 경우$HunitFood 에 대한 배율,money 이 경우$HunitMoney 에 대한 배율)
# log:로그 출력 설정 일반출력 normal, 정리메출력 matome,
# logstr:로그 출력보조 설정 '수확','수익'등
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' };

### 고속 농장 건설
$cno = 0; # 배열번호
$HcomplexComName[$cno] = '고속 농장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '턴을 소비하지 않는 농장 건설입니다. (복수 가능)'; # 설명
$HcomplexComKind[$cno] = 0; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 500; # 명령비용
$HcomplexComTurn[$cno] = 0; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x2; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 공장 건설
$cno = 0; # 배열번호
$HcomplexComName[$cno] = '공장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '자금 생산 시설입니다. 최대 10만 명 규모까지 확장할 수 있습니다. (복수 가능)'; # 설명
$HcomplexComKind[$cno] = 1; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 100; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 고속 공장 건설
$cno = 0; # 배열번호
$HcomplexComName[$cno] = '고속 공장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '턴을 소비하지 않는 공장 건설입니다. (복수 가능)'; # 설명
$HcomplexComKind[$cno] = 1; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 2500; # 명령비용
$HcomplexComTurn[$cno] = 0; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 채굴장 건설
$cno = 0; # 배열번호
$HcomplexComName[$cno] = '채굴장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '자금 생산 시설입니다. 재해에 강하며 최대 20만 명 규모까지 확장할 수 있습니다. (복수 가능)'; # 설명
$HcomplexComKind[$cno] = 2; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 300; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 나무 심기
$cno = 0; # 배열번호
$HcomplexComName[$cno] = '나무 심기'; # 명칭
$HcomplexComMsgs[$cno] = '평지와 마을 계열 지형에서 실행 가능합니다.'; # 설명
$HcomplexComKind[$cno] = 3; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 50; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x0; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 벌채
$cno = 0; # 배열번호
$HcomplexComName[$cno] = '벌채'; # 명칭
$HcomplexComMsgs[$cno] = '숲에서 실행하면 평지로 바뀌며 자금화됩니다.'; # 설명
$HcomplexComKind[$cno] = 3; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 0; # 명령비용
$HcomplexComTurn[$cno] = 0; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x1; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = [$HlandPlains, 0]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => 'money', 'ratio' => 5, 'log' => 'normal', 'logstr' => '수익' }; # 수입·수확 처리

### 건조 산
$cno = 0; # 배열번호
$HcomplexComName[$cno] = '건조 산'; # 명칭
$HcomplexComMsgs[$cno] = '평지나 도시 계열을 산으로 만듭니다.'; # 설명
$HcomplexComKind[$cno] = 4; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 3000; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x0; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### S농장 건설
$cno = 0; # 배열번호
$HcomplexComName[$cno] = 'S농장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '식량 생산 시설입니다. 최대 5만 명 규모까지 확장할 수 있습니다. (복수 가능)'; # 설명
$HcomplexComKind[$cno] = 0; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 22; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x2; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 변화가 없는 경우''이면 됩니다(0은 안 됨.)
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' };

### 고속S농장 건설
$cno = 1; # 배열번호
$HcomplexComName[$cno] = '고속S농장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '턴을 소비하지 않는 S농장 건설.(복수 가능)'; # 설명
$HcomplexComKind[$cno] = 0; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 550; # 명령비용
$HcomplexComTurn[$cno] = 0; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x2; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### S공장 건설
$cno = 2; # 배열번호
$HcomplexComName[$cno] = 'S공장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '자금 생산 시설입니다. 최대 10만 명 규모까지 확장할 수 있습니다. (복수 가능)'; # 설명
$HcomplexComKind[$cno] = 1; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 110; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 고속S공장 건설
$cno = 3; # 배열번호
$HcomplexComName[$cno] = '고속S공장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '턴을 소비하지 않는 S공장 건설.(복수 가능)'; # 설명
$HcomplexComKind[$cno] = 1; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 2750; # 명령비용
$HcomplexComTurn[$cno] = 0; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### S채굴장 건설
$cno = 4; # 배열번호
$HcomplexComName[$cno] = 'S채굴장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '자금 생산 시설입니다. 재해에 강하며 최대 20만 명 규모까지 확장할 수 있습니다. (복수 가능)'; # 설명
$HcomplexComKind[$cno] = 2; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 330; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 대농장 건설
$cno = 5; # 배열번호
$HcomplexComName[$cno] = '대농장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '식량원이 되는 시설. 최대 50만 명.(복수 가능)'; # 설명
$HcomplexComKind[$cno] = 3; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 200; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x2; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 변화가 없는 경우''이면 됩니다(0은 안 됨.)
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' };

### 고속대농장 건설
$cno = 6; # 배열번호
$HcomplexComName[$cno] = '고속대농장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '턴을 소비하지 않는 대농장 건설.(복수 가능)'; # 설명
$HcomplexComKind[$cno] = 3; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 5000; # 명령비용
$HcomplexComTurn[$cno] = 0; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x2; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 대공장 건설
$cno = 7; # 배열번호
$HcomplexComName[$cno] = '대공장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '자금원이 되는 시설. 최대 100만 명(복수 가능)'; # 설명
$HcomplexComKind[$cno] = 4; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 1000; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 고속대공장 건설
$cno = 8; # 배열번호
$HcomplexComName[$cno] = '고속대공장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '턴을 소비하지 않는 대공장 건설.(복수 가능)'; # 설명
$HcomplexComKind[$cno] = 4; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 25000; # 명령비용
$HcomplexComTurn[$cno] = 0; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

### 대채굴장 건설
$cno = 9; # 배열번호
$HcomplexComName[$cno] = '대채굴장 건설'; # 명칭
$HcomplexComMsgs[$cno] = '자금원이 되는 시설. 재해에 강함. 최대 200만 명(복수 가능).'; # 설명
$HcomplexComKind[$cno] = 5; # 대상이 되는 복합 지형 종류
$HcomplexComCost[$cno] = 3000; # 명령비용
$HcomplexComTurn[$cno] = 1; # 턴 소비(0:없고,1:있음)
$HcomplexComFlag[$cno] = 0x4; # 대상이 되는 플래그
$HcomplexComTFRL[$cno] = ["", ""]; # 턴 재설정 시의 처리
$HcomplexComTFInCome[$cno] = { 'type' => '', 'ratio' => 0, 'log' => '', 'logstr' => '' }; # 수입·수확 처리

#----------------------------------------
# 해군
#----------------------------------------
# 경험치의 최댓값
$HmaxExpNavy = 250; # 단, 최대 255까지

# 레벨의 최댓값
$maxNavyLevel = 10; # 해군
# 경험치가 몇 점이면 레벨업할지
# Lv2 3 4 5 6 7 8 9 10
@navyLevelUp = (20, 32, 48, 68, 92, 120, 152, 188, 228);
# Lv2 4 6 8 10
@HnavyFirePlus = ( 0, 1, 3, 5, 7, 10); # 증가 공격 횟수(짝수 레벨에서 상승)
# Lv1 3 5 7 9
@HnavyMaxHpPlus = ( 0, 1, 2, 3, 5); # 증가 내구력(홀수 레벨에서 상승)

# 잔해 매각 시 금괴가 발생할 확률
$HnavyProbWreckGold = 20; # 20%

# 함대를 보유하지 않은 섬에는 함대 파견을 불가능하게 함?(0:사용 안 함,1:사용)
# !선전포고를 사용 설정의 경우, 선전포고도 불가능해집니다
$HnofleetNotAvail = 0;

# 타 섬에 파견 중인 함대도 보급할까요?(0:사용 안 함,1:사용)
# (0이면자신의 섬에 있는 함대만보급하다 or 파견선의 섬이자기 섬을 내가 우호국으로 설정한 경우보급하다)
$HnavySupplyFlag = 1;

# 공격한 함정 자신이 사거리 범위에 있는 경우 자폭(피격)도 허용할까요?(0:없음, 1:있음)
$HnavySelfAttack = 0;

# 함정 공격에 피격된 함정이나 지형이 자기 섬인 경우 무해화할까요?(0:사용 안 함, 1:사용, 2:우호국도 무해화)
$HnavySafetyZone = 2;
# 무해화가 무효화될 확률(%) 참고: 무해화 기능이 발동하는 상황에서 판정
$HnavySafetyInvalidp = 0;

# 사거리 안 지형 공격 우선순위(기본값)
@Hpriority = ('Navy', 'Monster', 'HugeMonster', 'Arm', 'Pop', 'Food', 'Money', 'Other');
@HpriStr = ('해군', '괴수', '거대괴수', '군시설', '도시', '식량 생산', '자금 생산', '기타');
# Navy:해군 Monster:괴수 HugeMonster:거대괴수
# Arm:해저 기지, 미사일 기지, 가짜 시설, 방위 시설(의장하지 않은 경우)
# Pop:마을 계열 Food:농장 Money:해저 유전, 공장 Other:숲, 기념비
# 주!이 설정을 비워 두면 공격할 수 없게 됩니다.
$Hnearfar = 2; # 0:최소근처이 지형에서 목표를 탐색 1:최소멀리이 지형에서 목표를 탐색 2:사거리 안를 무작위로목표를 탐색

# 색적 순서(공격의 우선순위)의 변경을 허가할까요?(0:사용 안 함,1:사용)
$HusePriority = 1;

# '일제 공격' 명령을 사용할까요?(0:금지)
# 참고: 지정지점을 사거리 안에 둔 함정 공격 대상으로 설정하는 명령입니다.
$HuseTarget = 1;

# 자기 섬 이외에 있는 함대의 내구력을 표시할까요?(0:없음, 1:있음)
$HnavyShowInfo = 0;

# 보유 가능 함정 수(설정하지 않은 경우0)
$HnavyMaximum = 15;
# 1함대 주변의 보유 가능 함정 수(설정하지 않은 경우0)
$HfleetMaximum = 5; # 설정하는 경우 편성 가능한 수와의 균형을 고려해, 4배한 값이 $HnavyMaximum을 초과하지 않도록 합니다
# 군항항구 1개주변의 보유 가능 함정 수(설정하지 않은 경우0)
$HportRetention = 5; # 군항을 추가해도 보유 가능 함정 수를 초과한 것은 없음
#----------------------------------------
# 함정
#----------------------------------------
# 건조(경험치)레벨 설정
$HmaxComNavyLevel = 10; # 레벨의 최댓값(사용하지 않은 경우0로)
# 아래의 설정을 그대로 사이 경우, 상의'레벨의 최댓값'은10합니다.
# 2 3 4 5 6 7 8 9 10
@HcomNavyBorder = (10, 20, 40, 80, 160, 320, 640, 1280, 2560); # 필요한총 획득 경험치(각레벨의 최소 값. 레벨1은'0')
# 레벨 1 2 3 4 5 6 7 8 9 10
@HcomNavyNumber = (1, 2, 2, 3, 3, 4, 4, 5, 5, 5); # 건조 가능한 함정번호의 최댓값
# 건조 시 군항의 경험치 레벨도 필요할까요?(0:사용 안 함,1:사용)
# '군항에인접한깊은 바다에서 건조 가능'의 설정을 하지 않은 경우, 모라고도근처이군항의 레벨을 확합니다.
$HmaxComPortLevel = 0;

# 군항에 인접한 깊은 바다에서만 함정을 건조할 수 있음(0:사용 안 함,1:사용)
$HnavyBuildFlag = 1;

# 얕은 바다에도 이동 가능＆파견 가능.(0:사용 안 함,1:사용)
$HnavyMoveAsase = 1;

# 잔해이미지 파일
$HnavyImageZ = 'land18.gif';

# 특수 능력 관련 설정
#'무역능력'무역 능력이 있는 함정이 파견되어 있지 않은 섬에서는 지원 명령을 사용할 수 없게 할까요?(0:사용 안 함,1:사용)
$HtradeAbility = 0;
#'몸통박치기'기함·이동 조종 상태가 아니어도 몸통박치기할까요?(0:사용 안 함,1:사용)
$HsuicideAbility = 0;

# 함정 설정(최대32종류)
#---------------------------------
### 군항
$num = 0; # 배열번호
# 이름
$HnavyName[$num] = '군항';
# 능력
$HnavyKindMax[$num] = 0; # 보유 가능 횟수(설정하지 않은 경우 0)
$HnavyHP[$num] = 10; # 초기내구력
$HnavyMaxHP[$num] = 10; # 최종 내구력(Max15) 레벨업으로 증가하는 내구력의 최댓값을 고려하여 설정해 주세요.
$HnavyDamage[$num] = 0; # 파괴력(명중 시의 피해) 참고: 내구력이 있는 지형이 대상. 설정하지 않으면 1이므로,2 이상의 정수를 설정하는 경우에 사용.
$HnavyFire[$num] = 1; # 공격 수 레벨업으로 증가하는 공격 횟수의 최댓값을 고려하여 설정해 주세요.
$HnavyFireHex[$num] = 1; # 공격범위(오차)
$HnavyFireRange[$num] = 3; # 사거리거리(재밍 삭제범위)
$HnavyExp[$num] = 10; # 경험치
$HnavyBuildExp[$num] = 0; # 함정건조에서 군항이획득하는 경험치
$HnavyCost[$num] = 500; # 건조비용
$HnavyShellCost[$num] = 0; # 탄약1발의 비용
$HnavyMoney[$num] = 5; # 유지비용
$HnavyFood[$num] = 5; # 유지 식량
$HnavyProbWreck[$num] = 0; # 격침 시 잔해가 남을 확률(%) 군항의 설정은 무효가 됩니다
$HnavySpecial[$num] = 0x8; # 특수 능력
# 특수 능력의 내용은,
# 0x0 특별히 없음
# 0x1 이동 가능(최대2칸 이동)
# 0x2 고속 이동 가능(최대 몇 칸 이동하는지 불명)
# 0x4 잠수하다
# 0x8 항구
# 0x10 선 줄 이동(섬 명령 실행 전에 이동)
# 0x20 주변 2Hex 미사일 방어(방위 시설과 동일한 기능)
# 0x40 주변 2Hex 의 함대 공격 방어(방위 시설과 동일한 기능)
# 0x80 기함·이동 조종(섬주가 이동을 지시)
# 0x100 대잠 공격
# 0x200 대함 공격
# 0x400 대지 공격
# 0x800 유린 이동(자신이 소속한 함대의 기함을 목표하고 이동)
# 0x1000 어뢰계 (대잠, 대함)참고: $HnavyFireName 에서 함정마다의 명칭 변경 가능
# 0x2000 함포계 (대함, 대지)참고: $HnavyFireName 에서 함정마다의 명칭 변경 가능
# 0x4000 함재기계(대함, 대지)참고: $HnavyFireName 에서 함정마다의 명칭 변경 가능
# 0x8000 해저 탐사(보물, 유전 발견, 유지비와 별도로 고액의 조사비, 침몰 있음, 해저 화산 분화 있음)
# 유전이찾기에서 없는 경우그절반 확률로 보물 발견, 추가 로그절반 확률로 해저불 산분화.
# 조사비는 매 턴'굴착비용×발견확률'. 침몰확률은 발견확률의10분의1.
# 0x10000 보급 능력(다른 섬에 파견 중, 주변 1헥스의 자기 섬(or 우호국)함정과 자신에게 보급함)참고: 자기 섬(or 우호국)함정 이외에는 보급할 수 없는 설정에서 사용
# 0x20000 무역능력(지원 명령을 사용 섬으로 파견)참고: 아래의 설정을'1:하다'설정의 경우에 사용.
# 0x40000 해적 능력 참고: 파견했습니다 섬의, 농장에서 식량, 공장에서자금을 탈취우.1Hex 내50%,2Hex30%,3Hex10%
# 0x80000 육지 굴착 능력(황무지(착탄 지점)로 이동 가능. 이동 후에는 얕은 바다에. 일반 황무지로 이동할 수 있도록 한 경우착탄 지점으로)
# 0x100000
# 0x200000
# 0x400000
# 0x800000
# 0x1000000 목표보정능력(공격전에책적을 다시 시도)
# 0x2000000 함정에 들이받는 능력($HsafetyZone 의 설정에서 자함, 우호국함에도 들이받습니다)
# 0x4000000 명중률 UP:공격오차를 일정 확률로1Hex 축소
# 0x8000000 방파 능력:주변을 쓰나미 피해에서 보호
# 0x10000000 파괴력:무작위(명중 시의 피해) 참고: 난수 발생 확률과 최대파괴력을 별도로 설정. 난수가 발생하지 않을 시는, 파괴력의 능력 설정 또는 1.
# 0x20000000 융단 폭격 (첫 탄의 착탄 지점의 주변 여러 헥스를 공격)
# 0x40000000
# 0x80000000

# 특수 능력 관련 설정
# '어뢰계''함포계''함재기계'해군 공격 이름
# ['0x1000의 명칭', '0x2000의 명칭', '0x4000의 명칭'] (능력의 없는 경우빈칸에서 요이)
# '~을 실행했습니다'라는 로그가 됩니다.
$HnavyFireName[$num] = ['방위어뢰발사', '함포사격', '함재기 폭격'];
#'잠수하다'이동 시에부상하다확률(1%단위)
$HsubmarineSurface[$num] = 0;
#'유린 이동'기함을 탐색범위 반경3칸(별로 광이범위를 탐색사없도록 해 주세요. 불필요한서버 부하가 됩니다)
$HnavyTowardRange[$num] = 3;
#'해저 탐사'유전 발견확률(0.1%단위)
$Hoilp[$num] = 2;
#'보급 능력'보급함의 유효범위 반경3칸(별로 광이범위를 탐색사없도록 해 주세요. 불필요한서버 부하가 됩니다)
$HnavySupplyRange[$num] = 3;
#'해적 능력'주변 몇 Hex 내의 농장, 공장에 대해 해적 행위를 실행합니까. 참고: 1~3을 설정.4이상에는 할 수 없습니다.
$HpiratesHex[$num] = 2;
#'명중률 UP'1Hex 축소 확률(%단위)
$Hfirehexp[$num] = 50;
#'방파 능력'주변 몇 Hex 을쓰나미에서 보호합니까. 참고: 1~3을 설정.4이상에는 할 수 없습니다.
$HbouhaHex[$num] = 2;
#'파괴력:무작위'난수 발생 확률과 최대파괴력
$HdamageMax[$num] = 1; # 최대파괴력
$Hdamagep[$num] = 0; # 난수발생확률(1%단위)
#'융단 폭격'주변 몇 Hex 대상입니까?참고: 1~2을 설정.
$HnavyTerrorHex[$num] = 0; # 전체 범위에 융단 폭격을 하려면 1Hex는 7발, 2Hex는 19발이 필요합니다. 결과적으로 공격 오차가 커집니다.

# 팝업 내비게이션설명 부분(''의간에기술. 설정에 따라치환할 필요있음)
$HnaviExp.= "NAVY$num = ' 인접하다깊은 바다에서<BR>함정건조 가능'\n";

# 해군의 이미지 파일
$HnavyImage[$num] = 'navy0.gif';
$HnavyImage2[$num] = ''; # 잠수안

### 구축함
$num = 1; # 배열번호
$HnavyName[$num] = '구축함';# 이름
$HnavyKindMax[$num] = 0; # 보유 가능 횟수
$HnavyHP[$num] = 2; # 초기내구력
$HnavyMaxHP[$num] = 4; # 최종 내구력(Max15)
$HnavyDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HnavyFire[$num] = 2; # 공격 수
$HnavyFireHex[$num] = 1; # 공격범위(오차)
$HnavyFireRange[$num] = 2; # 사거리거리(재밍 삭제범위)
$HnavyExp[$num] = 5; # 경험치
$HnavyBuildExp[$num] = 1; # 함정건조에서 군항이획득하는 경험치
$HnavyCost[$num] = 100; # 건조비용
$HnavyShellCost[$num] = 1; # 탄약1발의 비용
$HnavyMoney[$num] = 1; # 유지비용
$HnavyFood[$num] = 1; # 유지 식량
$HnavyProbWreck[$num] = 50; # 격침 시 잔해가 남을 확률(%)
#$HnavySpecial[$num] = 0x1302; # 특수 능력
$HnavySpecial[$num] = 0x1392; # 특수 능력
$HnavyFireName[$num] = ['어뢰발사', '함포사격', '함재기 폭격'];
$HsubmarineSurface[$num] = 0; #'잠수하다'이동 시에부상하다확률(1%단위)
$HnavyTowardRange[$num] = 3; #'유린 이동'기함을 탐색범위(Hex)
$Hoilp[$num] = 2; #'해저 탐사'유전 발견확률(0.1%단위)
$HnavySupplyRange[$num] = 3; #'보급 능력'보급함의 유효범위(Hex)
$HpiratesHex[$num] = 2; #'해적 능력'해적 행위를 실행 범위(Hex)
$Hfirehexp[$num] = 50; #'명중률 UP'1Hex 축소 확률(%단위)
$HbouhaHex[$num] = 2; #'방파 능력'쓰나미에서 보호 범위(Hex)
$HdamageMax[$num] = 1; #'파괴력:무작위'최대파괴력
$Hdamagep[$num] = 0; #'파괴력:무작위'난수발생확률(1%단위)
$HnavyTerrorHex[$num] = 0; #'융단 폭격'Hex
$HnaviExp.= "NAVY$num = ' 어뢰에서 대잠·대함 공격<BR>${HnavyFire[$num]}FIRE:${HnavyFireRange[$num]}RANGE:${HnavyFireHex[$num]}ERROR<BR>고속 이동 가능'\n";# 팝업 내비게이션설명 부분
$HnavyImage[$num] = 'navy1.gif';# 해군의 이미지 파일
$HnavyImage2[$num] = ''; # 잠수안

### 순양함
$num = 2; # 배열번호
$HnavyName[$num] = '순양함';# 이름
$HnavyKindMax[$num] = 0; # 보유 가능 횟수
$HnavyHP[$num] = 4; # 초기내구력
$HnavyMaxHP[$num] = 6; # 최종 내구력(Max15)
$HnavyDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HnavyFire[$num] = 4; # 공격 수
$HnavyFireHex[$num] = 1; # 공격범위(오차)
$HnavyFireRange[$num] = 2; # 사거리거리(재밍 삭제범위)
$HnavyExp[$num] = 10; # 경험치
$HnavyBuildExp[$num] = 1; # 함정건조에서 군항이획득하는 경험치
$HnavyCost[$num] = 400; # 건조비용
$HnavyShellCost[$num] = 2; # 탄약1발의 비용
$HnavyMoney[$num] = 2; # 유지비용
$HnavyFood[$num] = 2; # 유지 식량
$HnavyProbWreck[$num] = 50; # 격침 시 잔해가 남을 확률(%)
#$HnavySpecial[$num] = 0x2601; # 특수 능력
$HnavySpecial[$num] = 0x2681; # 특수 능력
$HnavyFireName[$num] = ['어뢰발사', '함포사격', '함재기 폭격'];
$HsubmarineSurface[$num] = 0; #'잠수하다'이동 시에부상하다확률(1%단위)
$HnavyTowardRange[$num] = 3; #'유린 이동'기함을 탐색범위(Hex)
$Hoilp[$num] = 2; #'해저 탐사'유전 발견확률(0.1%단위)
$HnavySupplyRange[$num] = 3; #'보급 능력'보급함의 유효범위(Hex)
$HpiratesHex[$num] = 2; #'해적 능력'해적 행위를 실행 Hex
$Hfirehexp[$num] = 50; #'명중률 UP'1Hex 축소 확률(%단위)
$HbouhaHex[$num] = 2; #'방파 능력'쓰나미에서 보호 범위(Hex)
$HdamageMax[$num] = 1; #'파괴력:무작위'최대파괴력
$Hdamagep[$num] = 0; #'파괴력:무작위'난수발생확률(1%단위)
$HnavyTerrorHex[$num] = 0; #'융단 폭격'Hex
$HnaviExp.= "NAVY$num = ' 함포에서 대함·대지 공격<BR>${HnavyFire[$num]}FIRE:${HnavyFireRange[$num]}RANGE:${HnavyFireHex[$num]}ERROR<BR>이동 가능'\n";# 팝업 내비게이션설명 부분
$HnavyImage[$num] = 'navy2.gif';# 해군의 이미지 파일
$HnavyImage2[$num] = ''; # 잠수안

### 전함
$num = 3; # 배열번호
$HnavyName[$num] = '전함';# 이름
$HnavyKindMax[$num] = 0; # 보유 가능 횟수
$HnavyHP[$num] = 8; # 초기내구력
$HnavyMaxHP[$num] = 10; # 최종 내구력(Max15)
$HnavyDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HnavyFire[$num] = 6; # 공격 수
$HnavyFireHex[$num] = 2; # 공격범위(오차)
$HnavyFireRange[$num] = 3; # 사거리거리(재밍 삭제범위)
$HnavyExp[$num] = 15; # 경험치
$HnavyBuildExp[$num] = 3; # 함정건조에서 군항이획득하는 경험치
$HnavyCost[$num] = 800; # 건조비용
$HnavyShellCost[$num] = 3; # 탄약1발의 비용
$HnavyMoney[$num] = 3; # 유지비용
$HnavyFood[$num] = 3; # 유지 식량
$HnavyProbWreck[$num] = 50; # 격침 시 잔해가 남을 확률(%)
#$HnavySpecial[$num] = 0x2600; # 특수 능력
$HnavySpecial[$num] = 0x2680; # 특수 능력
$HnavyFireName[$num] = ['어뢰발사', '함포사격', '함재기 폭격'];
$HsubmarineSurface[$num] = 0; #'잠수하다'이동 시에부상하다확률(1%단위)
$HnavyTowardRange[$num] = 3; #'유린 이동'기함을 탐색범위(Hex)
$Hoilp[$num] = 2; #'해저 탐사'유전 발견확률(0.1%단위)
$HnavySupplyRange[$num] = 3; #'보급 능력'보급함의 유효범위(Hex)
$HpiratesHex[$num] = 2; #'해적 능력'해적 행위를 실행 Hex
$Hfirehexp[$num] = 50; #'명중률 UP'1Hex 축소 확률(%단위)
$HbouhaHex[$num] = 2; #'방파 능력'쓰나미에서 보호 범위(Hex)
$HdamageMax[$num] = 1; #'파괴력:무작위'최대파괴력
$Hdamagep[$num] = 0; #'파괴력:무작위'난수발생확률(1%단위)
$HnavyTerrorHex[$num] = 0; #'융단 폭격'Hex
$HnaviExp.= "NAVY$num = ' 함포에서 대함·대지 공격<BR>${HnavyFire[$num]}FIRE:${HnavyFireRange[$num]}RANGE:${HnavyFireHex[$num]}ERROR'\n";# 팝업 내비게이션설명 부분
$HnavyImage[$num] = 'navy3.gif';# 해군의 이미지 파일
$HnavyImage2[$num] = ''; # 잠수안

### 항공모함
$num = 4; # 배열번호
$HnavyName[$num] = '항공모함';# 이름
$HnavyKindMax[$num] = 0; # 보유 가능 횟수
$HnavyHP[$num] = 7; # 초기내구력
$HnavyMaxHP[$num] = 10; # 최종 내구력(Max15)
$HnavyDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HnavyFire[$num] = 10; # 공격 수
$HnavyFireHex[$num] = 3; # 공격범위(오차)
$HnavyFireRange[$num] = 4; # 사거리거리(재밍 삭제범위)
$HnavyExp[$num] = 20; # 경험치
$HnavyBuildExp[$num] = 5; # 함정건조에서 군항이획득하는 경험치
$HnavyCost[$num] = 2400; # 건조비용
$HnavyShellCost[$num] = 5; # 탄약1발의 비용
$HnavyMoney[$num] = 10; # 유지비용
$HnavyFood[$num] = 10; # 유지 식량
$HnavyProbWreck[$num] = 50; # 격침 시 잔해가 남을 확률(%)
#$HnavySpecial[$num] = 0x4600; # 특수 능력
$HnavySpecial[$num] = 0x4680; # 특수 능력
$HnavyFireName[$num] = ['어뢰발사', '함포사격', '함재기 폭격'];
$HsubmarineSurface[$num] = 0; #'잠수하다'이동 시에부상하다확률(1%단위)
$HnavyTowardRange[$num] = 3; #'유린 이동'기함을 탐색범위(Hex)
$Hoilp[$num] = 2; #'해저 탐사'유전 발견확률(0.1%단위)
$HnavySupplyRange[$num] = 3; #'보급 능력'보급함의 유효범위(Hex)
$HpiratesHex[$num] = 2; #'해적 능력'해적 행위를 실행 Hex
$Hfirehexp[$num] = 50; #'명중률 UP'1Hex 축소 확률(%단위)
$HbouhaHex[$num] = 2; #'방파 능력'쓰나미에서 보호 범위(Hex)
$HdamageMax[$num] = 1; #'파괴력:무작위'최대파괴력
$Hdamagep[$num] = 0; #'파괴력:무작위'난수발생확률(1%단위)
$HnavyTerrorHex[$num] = 0; #'융단 폭격'Hex
$HnaviExp.= "NAVY$num = ' 함재기에서 대함·대지폭격<BR>${HnavyFire[$num]}FIRE:${HnavyFireRange[$num]}RANGE:${HnavyFireHex[$num]}ERROR'\n";# 팝업 내비게이션설명 부분
$HnavyImage[$num] = 'navy4.gif';# 해군의 이미지 파일
$HnavyImage2[$num] = ''; # 잠수안

### 잠수함
$num = 5; # 배열번호
$HnavyName[$num] = '잠수함';# 이름
$HnavyKindMax[$num] = 0; # 보유 가능 횟수
$HnavyHP[$num] = 2; # 초기내구력
$HnavyMaxHP[$num] = 4; # 최종 내구력(Max15)
$HnavyDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HnavyFire[$num] = 2; # 공격 수
$HnavyFireHex[$num] = 1; # 공격범위(오차)
$HnavyFireRange[$num] = 2; # 사거리거리(재밍 삭제범위)
$HnavyExp[$num] = 5; # 경험치
$HnavyBuildExp[$num] = 2; # 함정건조에서 군항이획득하는 경험치
$HnavyCost[$num] = 800; # 건조비용
$HnavyShellCost[$num] = 2; # 탄약1발의 비용
$HnavyMoney[$num] = 4; # 유지비용
$HnavyFood[$num] = 4; # 유지 식량
$HnavyProbWreck[$num] = 50; # 격침 시 잔해가 남을 확률(%)
#$HnavySpecial[$num] = 0x1304; # 특수 능력
$HnavySpecial[$num] = 0x1384; # 특수 능력
$HnavyFireName[$num] = ['어뢰발사', '함포사격', '함재기 폭격'];
$HsubmarineSurface[$num] = 20; #'잠수하다'이동 시에부상하다확률(1%단위)
$HnavyTowardRange[$num] = 3; #'유린 이동'기함을 탐색범위(Hex)
$Hoilp[$num] = 2; #'해저 탐사'유전 발견확률(0.1%단위)
$HnavySupplyRange[$num] = 3; #'보급 능력'보급함의 유효범위(Hex)
$HpiratesHex[$num] = 2; #'해적 능력'해적 행위를 실행 Hex
$Hfirehexp[$num] = 50; #'명중률 UP'1Hex 축소 확률(%단위)
$HbouhaHex[$num] = 2; #'방파 능력'쓰나미에서 보호 범위(Hex)
$HdamageMax[$num] = 1; #'파괴력:무작위'최대파괴력
$Hdamagep[$num] = 0; #'파괴력:무작위'난수발생확률(1%단위)
$HnavyTerrorHex[$num] = 0; #'융단 폭격'Hex
$HnaviExp.= "NAVY$num = ' 어뢰에서 대잠·대함 공격<BR>${HnavyFire[$num]}FIRE:${HnavyFireRange[$num]}RANGE:${HnavyFireHex[$num]}ERROR<BR>잠수하다'\n";# 팝업 내비게이션설명 부분
$HnavyImage[$num] = 'navy5.gif'; # 해군의 이미지 파일
$HnavyImage2[$num] = 'land17.gif';# 잠수안


# 소속 불명 함정
#------------
# 소속 불명 함정이 출현할까요?(0:사용 안 함,1:사용)
$HnavyUnknown = 1;

# 단위 면적 주변의 출현율(0.01%단위)
$HdisNavy = 3;

# 소속 불명 함정 출현의 기준
@HdisNavyBorder = ( 0, 1000, 1000, 2500, 4000, 4000);

# 소속 불명 함정 출현 비율
@HdisNavyRatio = ( 0, 1, 1, 1, 1, 1); # 가중치(0으로 하면 출현하지 않음. 군항 계열은 0으로 하세요d(*⌒▽⌒*)b)
# 출현율판정($HdisNavy)로 출현하는 것이결정했던 것을 치, 인구 기준($HdisNavyBorder)을 지우기하고 있는
# 함정의 안에서 상의 비율($HdisNavyRatio)로 함정을 선택부

#----------------------------------------
# 괴수
#----------------------------------------
# 종류(최대32종류)
$HmonsterNumber = 8;

# 단위 면적 주변의 출현율(0.01%단위)
$HdisMonster = 3;

# 괴수 파견을 사용할까요?(0:금지)
$HuseSendMonster = 1;

# ST 괴수 파견을 사용할까요?(0:금지)
$HuseSendMonsterST = 0;

# 파견 가능한괴수의 번호의 최댓값
$HsendMonsterNumber = 7;

# 공격한 괴수 자신이 사거리 범위에 있는 경우 자폭(피격)도 허용할까요?(0:없고,1:있음)
$HmonsterSelfAttack = 0;

# '공격 능력'에 피격된 함정이나 지형이 자기 섬인 경우 무해화할까요?(0:사용 안 함, 1:사용, 2:우호국도 무해화)
$HmonsterSafetyZone = 2;
# 무해화가 무효화될 확률(%) 참고: 무해화 기능이 발동하는 상황에서 판정
$HmonsterSafetyInvalidp = 0;

# '공격 능력' 공격 횟수 상한(빈사 상태가 되면 공격 횟수가 폭발적으로 증가하므로)(0:설정 없음)
$HmonsterFireMax = 0;

# 괴수출현의 기준
@HdisMonsBorder = ( 0, 1000, 1000, 2500, 2500, 2500, 4000, 4000);

# 괴수출현 비율
@HdisMonsRatio = ( 0, 1, 1, 1, 1, 1, 1, 1); # 가중치(0으로 하면 출현하지 않음)
# 출현율판정($HdisMonster)로 출현하는 것이결정했던 것을 치, 인구 기준($HdisMonsBorder)을 지우기하고 있는
# 괴수의 안에서 상의 비율($HdisMonsRatio)로 괴수를 선택부

# 잠수안이미지 파일(공통 설정)
$HmonsterImageUnderSea = 'land17.gif';

# 괴수 설정(최대32종류)
#----------------------
### 메카이노라
$num = 0; # 배열번호
# 이름
$HmonsterName[$num] = '메카이노라';
# 능력
$HmonsterBHP[$num] = 2; # 최소체력
$HmonsterDHP[$num] = 0; # 체력의 폭 주!체력의 최댓값은31
$HmonsterExp[$num] = 5; # 경험치
$HmonsterValue[$num] = 0; # 시체의 가격
$HmonsterCost[$num] = 3000; # 파견 명령비용
$HmonsterCostST[$num] = 6000; # ST 파견 명령비용
$HmonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HmonsterFire[$num] = 0; # '공격 능력'공격 수
$HmonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HmonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HmonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmonsterSpecial[$num] = 0x20; # 특수 능력
# 특수 능력의 내용은,
# 0x0 특별히 없음
# 0x1 빠른 이동(최대 2걸음)
# 0x2 2족 보행이지만 속도는 알 수 없음(최대 몇 칸 이동하는지 불명)
# 0x4 무작위 경화
# 0x10 선 줄 이동(섬 명령 실행 전에 이동)
# 0x20 유린 이동(읍등을 목표하고 이동)
# 0x80 이동 조종(섬주가 이동을 컨트롤)
# 0x100 공격 능력(공격 목표를 포착하면 공격)
# 0x200 융단 폭격 (첫 탄의 착탄 지점의 주변 여러 헥스를 공격) 참고: 미사일 공격 능력이 필요

#'융단 폭격'주변 몇 Hex 대상입니까?참고: 1~2을 설정.
$HmonsterTerrorHex[$num] = 0; # 전체 범위에 융단 폭격을 하려면 1Hex는 7발, 2Hex는 19발이 필요합니다. 결과적으로 공격 오차가 커집니다.

# 팝업 내비게이션설명 부분(''의간에기술. 설정에 따라치환할 필요있음)
$HnaviExp.="MONSTER$num = ' 인공괴수<br> 읍등을 목표하고 이동하다'\n";

# 이미지 파일
$HmonsterImage[$num] = 'monster7.gif';
$HmonsterImage2[$num] = ''; # 경화 중

### 이노라
$num = 1; # 배열번호
$HmonsterName[$num] = '이노라'; # 이름
$HmonsterBHP[$num] = 1; # 최소체력
$HmonsterDHP[$num] = 2; # 체력의 폭 주!체력의 최댓값은31
$HmonsterExp[$num] = 5; # 경험치
$HmonsterValue[$num] = 400; # 시체의 가격
$HmonsterCost[$num] = 3400; # 파견 명령비용
$HmonsterCostST[$num] = 6400; # ST 파견 명령비용
$HmonsterFireName[$num] = '이노라 공격'; # '공격 능력'공격명칭
$HmonsterFire[$num] = 0; # '공격 능력'공격 수
$HmonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HmonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HmonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmonsterSpecial[$num] = 0x2; # 특수 능력
$HmonsterTerrorHex[$num] = 0; # '융단 폭격'주변 몇 Hex
$HnaviExp.="MONSTER$num = ' 최대 몇 칸 이동하는지 불명'\n";# 팝업 내비게이션
$HmonsterImage[$num] = 'monster0.gif'; # 이미지 파일
$HmonsterImage2[$num] = ''; # 경화 중

### 산지라
$num = 2; # 배열번호
$HmonsterName[$num] = '산지라'; # 이름
$HmonsterBHP[$num] = 1; # 최소체력
$HmonsterDHP[$num] = 2; # 체력의 폭 주!체력의 최댓값은31
$HmonsterExp[$num] = 7; # 경험치
$HmonsterValue[$num] = 500; # 시체의 가격
$HmonsterCost[$num] = 3500; # 파견 명령비용
$HmonsterCostST[$num] = 6500; # ST 파견 명령비용
$HmonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HmonsterFire[$num] = 0; # '공격 능력'공격 수
$HmonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HmonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HmonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmonsterSpecial[$num] = 0x4; # 특수 능력
$HmonsterTerrorHex[$num] = 0; # '융단 폭격'주변 몇 Hex
$HnaviExp.="MONSTER$num = ' 무작위 경화'\n";# 팝업 내비게이션
$HmonsterImage[$num] = 'monster5.gif'; # 이미지 파일
$HmonsterImage2[$num] = 'monster4.gif'; # 경화 중

### 레드이노라
$num = 3; # 배열번호
$HmonsterName[$num] = '레드이노라'; # 이름
$HmonsterBHP[$num] = 3; # 최소체력
$HmonsterDHP[$num] = 2; # 체력의 폭 주!체력의 최댓값은31
$HmonsterExp[$num] = 12; # 경험치
$HmonsterValue[$num] = 1000; # 시체의 가격
$HmonsterCost[$num] = 4000; # 파견 명령비용
$HmonsterCostST[$num] = 7000; # ST 파견 명령비용
$HmonsterFireName[$num] = '레도 공격'; # '공격 능력'공격명칭
$HmonsterFire[$num] = 0; # '공격 능력'공격 수
$HmonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HmonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HmonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmonsterSpecial[$num] = 0x0; # 특수 능력
$HmonsterTerrorHex[$num] = 1; # '융단 폭격'주변 몇 Hex
$HnaviExp.="MONSTER$num = ''\n";# 팝업 내비게이션
$HmonsterImage[$num] = 'monster1.gif'; # 이미지 파일
$HmonsterImage2[$num] = ''; # 경화 중

### 다크이노라
$num = 4; # 배열번호
$HmonsterName[$num] = '다크이노라'; # 이름
$HmonsterBHP[$num] = 2; # 최소체력
$HmonsterDHP[$num] = 2; # 체력의 폭 주!체력의 최댓값은31
$HmonsterExp[$num] = 12; # 경험치
$HmonsterValue[$num] = 800; # 시체의 가격
$HmonsterCost[$num] = 3800; # 파견 명령비용
$HmonsterCostST[$num] = 6800; # ST 파견 명령비용
$HmonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HmonsterFire[$num] = 0; # '공격 능력'공격 수
$HmonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HmonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HmonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmonsterSpecial[$num] = 0x1; # 특수 능력
$HmonsterTerrorHex[$num] = 0; # '융단 폭격'주변 몇 Hex
$HnaviExp.="MONSTER$num = ' 최대 2칸 이동'\n";# 팝업 내비게이션
$HmonsterImage[$num] = 'monster2.gif'; # 이미지 파일
$HmonsterImage2[$num] = ''; # 경화 중

### 이노라 고스트
$num = 5; # 배열번호
$HmonsterName[$num] = '이노라 고스트'; # 이름
$HmonsterBHP[$num] = 1; # 최소체력
$HmonsterDHP[$num] = 0; # 체력의 폭 주!체력의 최댓값은31
$HmonsterExp[$num] = 10; # 경험치
$HmonsterValue[$num] = 300; # 시체의 가격
$HmonsterCost[$num] = 3300; # 파견 명령비용
$HmonsterCostST[$num] = 6300; # ST 파견 명령비용
$HmonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HmonsterFire[$num] = 0; # '공격 능력'공격 수
$HmonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HmonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HmonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmonsterSpecial[$num] = 0x12; # 특수 능력
$HmonsterTerrorHex[$num] = 0; # '융단 폭격'주변 몇 Hex
$HnaviExp.="MONSTER$num = ' 섬 명령 실행 전에 이동<br> 최대 몇 칸 이동하는지 불명'\n";# 팝업 내비게이션
$HmonsterImage[$num] = 'monster8.gif'; # 이미지 파일
$HmonsterImage2[$num] = ''; # 경화 중

### 고래
$num = 6; # 배열번호
$HmonsterName[$num] = '고래'; # 이름
$HmonsterBHP[$num] = 4; # 최소체력
$HmonsterDHP[$num] = 2; # 체력의 폭 주!체력의 최댓값은31
$HmonsterExp[$num] = 20; # 경험치
$HmonsterValue[$num] = 1500; # 시체의 가격
$HmonsterCost[$num] = 4500; # 파견 명령비용
$HmonsterCostST[$num] = 7500; # ST 파견 명령비용
$HmonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HmonsterFire[$num] = 0; # '공격 능력'공격 수
$HmonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HmonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HmonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmonsterSpecial[$num] = 0x4; # 특수 능력
$HmonsterTerrorHex[$num] = 0; # '융단 폭격'주변 몇 Hex
$HnaviExp.="MONSTER$num = ' 무작위 경화'\n";# 팝업 내비게이션
$HmonsterImage[$num] = 'monster6.gif'; # 이미지 파일
$HmonsterImage2[$num] = 'monster4.gif'; # 경화 중

### 킹 이노라
$num = 7; # 배열번호
$HmonsterName[$num] = '킹 이노라'; # 이름
$HmonsterBHP[$num] = 5; # 최소체력
$HmonsterDHP[$num] = 2; # 체력의 폭 주!체력의 최댓값은31
$HmonsterExp[$num] = 30; # 경험치
$HmonsterValue[$num] = 2000; # 시체의 가격
$HmonsterCost[$num] = 5000; # 파견 명령비용
$HmonsterCostST[$num] = 8000; # ST 파견 명령비용
$HmonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HmonsterFire[$num] = 0; # '공격 능력'공격 수
$HmonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HmonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HmonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HmonsterSpecial[$num] = 0x0; # 특수 능력
$HmonsterTerrorHex[$num] = 0; # '융단 폭격'주변 몇 Hex
$HnaviExp.="MONSTER$num = ''\n";# 팝업 내비게이션
$HmonsterImage[$num] = 'monster3.gif'; # 이미지 파일
$HmonsterImage2[$num] = ''; # 경화 중

#----------------------------------------
# 거대괴수
#----------------------------------------
# 종류(최대32종류)
$HhugeMonsterNumber = 3;

# 거대 괴수가 출현할까요?(0:사용 안 함,1:사용)
$HhugeMonsterAppear = 1;

# 단위 면적 주변의 출현율(0.01%단위)
$HdisHuge = 1;

# 파견 가능한거대괴수의 번호의 최댓값
$HsendHugeMonsterNumber = 0; # -1에서 파견불가

# 특수 능력
# '개체 재생을 무작위로 실행' 능력의 재생 확률(%)
$HpRebody = 100;

# 거대괴수출현의 기준
@HdisHugeBorder = ( 10000, 10000, 20000);

# 거대괴수출현 비율
@HdisHugeRatio = ( 1, 1, 1); # 가중치(0으로 하면 출현하지 않음)
# 출현율판정($HdisHuge)로 출현하는 것이결정했던 것을 치, 인구 기준($HdisHugeBorder)을 지우기하고 있는
# 거대괴수의 안에서 상의 비율($HdisHugeRatio)로 거대괴수를 선택부

# 거대괴수 설정(최대32종류)
#----------------------------------------
### 도지라
$num = 0; # 배열번호
# 이름
$HhugeMonsterName[$num] = '도지라';
# 능력
$HhugeMonsterBHP[$num] = 6; # 최소체력
$HhugeMonsterDHP[$num] = 3; # 체력의 폭 주!체력의 최댓값은31
$HhugeMonsterExp[$num] = 20; # 경험치
$HhugeMonsterValue[$num] = 2000; # 시체의 가격
$HhugeMonsterCost[$num] = 32000; # 파견 명령비용
$HhugeMonsterCostST[$num] = 62000; # ST 파견 명령비용
$HhugeMonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HhugeMonsterFire[$num] = 0; # '공격 능력'공격 수
$HhugeMonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HhugeMonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HhugeMonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HhugeMonsterSpecial[$num] = 0x20; # 특수 능력
# 특수 능력의 내용은,
# 0x0 특별히 없음
# 0x1 빠른 이동(최대 2걸음)
# 0x2 2족 보행이지만 속도는 알 수 없음(최대 몇 칸 이동하는지 불명)
# 0x4 무작위 경화
# 0x10 선 줄 이동(섬 명령 실행 전에 이동)
# 0x20 유린 이동(읍등을 목표하고 이동)
# 0x80 이동 조종(섬주가 이동을 컨트롤)
# 0x100 공격 능력(공격 목표를 포착하면 공격)
# 0x200 융단 폭격 (첫 탄의 착탄 지점의 주변 여러 헥스를 공격) 참고: 미사일 공격 능력이 필요
# 0x10000 코어방위(주변모두를 지우지 않는 한 코어로 공격이 무효)
# 0x20000 개체 재생을 무작위로 실행

#'융단 폭격'주변 몇 Hex 대상입니까?참고: 1~2을 설정.
$HhugeMonsterTerrorHex[$num] = 0; # 전체 범위에 융단 폭격을 하려면 1Hex는 7발, 2Hex는 19발이 필요합니다. 결과적으로 공격 오차가 커집니다.

# 팝업 내비게이션설명 부분(설정에 따라치환할 필요있음)
$HnaviExp.="HUGEMONSTER$num = ' 읍등을 목표하고 이동하다'\n";

# 이미지 파일(육상)
$HhugeMonsterImage[$num] = ['gojira.gif', 'gojira6.gif', 'gojira7.gif', 'gojira8.gif', 'gojira9.gif', 'gojira10.gif', 'gojira11.gif'];
# 이미지 파일그2(육에서 경화 중)
$HhugeMonsterImage2[$num] = ['gojira.gif', 'gojira6.gif', 'gojira7.gif', 'gojira8.gif', 'gojira9.gif', 'gojira10.gif', 'gojira11.gif'];
# 이미지 파일그3(바다에 있는)
$HhugeMonsterImage3[$num] = ['gojira.gif', 'gojira0.gif', 'gojira1.gif', 'gojira2.gif', 'gojira3.gif', 'gojira4.gif', 'gojira5.gif'];
# 이미지 파일그4(바다에서 경화)
$HhugeMonsterImage4[$num] = ['gojira.gif', 'gojira0.gif', 'gojira1.gif', 'gojira2.gif', 'gojira3.gif', 'gojira4.gif', 'gojira5.gif'];
# 이미지 파일(메인 페이지 표시용)
$HhugeMonsterImageS[$num] = 'gojira.gif';

### 한질라
$num = 1; # 배열번호
$HhugeMonsterName[$num] = '한질라'; # 이름
$HhugeMonsterBHP[$num] = 3; # 최소체력
$HhugeMonsterDHP[$num] = 6; # 체력의 폭 주!체력의 최댓값은31
$HhugeMonsterExp[$num] = 10; # 경험치
$HhugeMonsterValue[$num] = 1000; # 시체의 가격
$HhugeMonsterCost[$num] = 31000; # 파견 명령비용
$HhugeMonsterCostST[$num] = 61000; # ST 파견 명령비용
$HhugeMonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HhugeMonsterFire[$num] = 0; # '공격 능력'공격 수
$HhugeMonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HhugeMonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HhugeMonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HhugeMonsterSpecial[$num] = 0x20; # 특수 능력
$HhugeMonsterTerrorHex[$num] = 0; #'융단 폭격'Hex
$HnaviExp.="HUGEMONSTER$num = ' 읍등을 목표하고 이동하다'\n"; # 팝업 내비게이션
# 이미지 파일(육상)
$HhugeMonsterImage[$num] = ['gojira.gif', '', 'gojira7.gif', '', 'gojira9.gif', '', 'gojira11.gif'];
# 이미지 파일그2(육에서 경화 중)
$HhugeMonsterImage2[$num] = ['gojira.gif', '', 'gojira7.gif', '', 'gojira9.gif', '', 'gojira11.gif'];
# 이미지 파일그3(바다에 있는)
$HhugeMonsterImage3[$num] = ['gojira.gif', '', 'gojira1.gif', '', 'gojira3.gif', '', 'gojira5.gif'];
# 이미지 파일그4(바다에서 경화)
$HhugeMonsterImage4[$num] = ['gojira.gif', '', 'gojira1.gif', '', 'gojira3.gif', '', 'gojira5.gif'];
# 이미지 파일(메인 페이지 표시용)
$HhugeMonsterImageS[$num] = 'gojira.gif';

### 방위이노라
$num = 2; # 배열번호
$HhugeMonsterName[$num] = '방위이노라'; # 이름
$HhugeMonsterBHP[$num] = 2; # 최소체력
$HhugeMonsterDHP[$num] = 1; # 체력의 폭 주!체력의 최댓값은31
$HhugeMonsterExp[$num] = 40; # 경험치
$HhugeMonsterValue[$num] = 4000; # 시체의 가격
$HhugeMonsterCost[$num] = 34000; # 파견 명령비용
$HhugeMonsterCostST[$num] = 64000; # ST 파견 명령비용
$HhugeMonsterFireName[$num] = '미사일 공격'; # '공격 능력'공격명칭
$HhugeMonsterFire[$num] = 0; # '공격 능력'공격 수
$HhugeMonsterFireHex[$num] = 0; # '공격 능력'공격범위(오차)
$HhugeMonsterFireRange[$num] = 0; # 사거리거리(재밍 삭제범위)
$HhugeMonsterDamage[$num] = 0; # 파괴력 참고: 설정하지 않으면 1
$HhugeMonsterSpecial[$num] = 0x30000; # 특수 능력
$HhugeMonsterTerrorHex[$num] = 0; #'융단 폭격'Hex
$HnaviExp.="HUGEMONSTER$num = ' 코어방위·무작위재생능력을 가진'\n"; # 팝업 내비게이션
# 이미지 파일(육상)
$HhugeMonsterImage[$num] = ['monster0.gif', 'monster0.gif', '', 'monster0.gif', '', 'monster0.gif', ''];
# 이미지 파일그2(육에서 경화 중)
$HhugeMonsterImage2[$num] = ['monster0.gif', 'monster0.gif', '', 'monster0.gif', '', 'monster0.gif', ''];
# 이미지 파일그3(바다에 있는)
$HhugeMonsterImage3[$num] = ['monster00.gif', 'monster00.gif', '', 'monster00.gif', '', 'monster00.gif', ''];
# 이미지 파일그4(바다에서 경화)
$HhugeMonsterImage4[$num] = ['monster00.gif', 'monster00.gif', '', 'monster00.gif', '', 'monster00.gif', ''];
# 이미지 파일(메인 페이지 표시용)
$HhugeMonsterImageS[$num] = 'monster00.gif';

#----------------------------------------
# 기념비
#----------------------------------------
# 몇종류있는 지
$HmonumentNumber = 3;

# 이름
@HmonumentName = (
	'모노리스',
	'평화기념비',
	'전쟁이의 비석',
);

# 팝업 내비게이션설명 부분(설정에 따라치환할 필요있음)
$HnaviExp.=<<"END";
MONIMENT0 = "";
MONIMENT1 = "";
MONIMENT2 = "";
END

# 이미지 파일
@HmonumentImage = (
	'monument0.gif',
	'monument1.gif',
	'monument2.gif',
);

# 기념비발사를 사용할까요?(0:금지)
$HuseBigMissile = 0;

#----------------------------------------
#아이템
#----------------------------------------
#아이템을 사용할까요?(0:금지)
$HuseItem = 1;

# 모든 동맹원이 '키아이템'을 획득하면 게임을 종료할까요?(0:사용 안 함 1:하다)
$HallyItemComplete = 1;

# 이름
@HitemName = (
	'크리스탈', # 총명칭
	'그린 크리스탈',
	'레드 크리스탈',
	'옐로 크리스탈',
	'블루 크리스탈',
	'실버 크리스탈',
	'화이트 크리스탈',
	'다크 크리스탈',

	'루나',
	'샐러맨더',
	'운디네',
	'도리아도',
	'진',
	'노무',
	'위스푸',
);
#@HitemName = (
#	'페어리 스톤', # 총명칭
#	'루나',
#	'샐러맨더',
#	'운디네',
#	'도리아도',
#	'진',
#	'노무',
#	'위스푸',
#	'셰이도'
#);

# 특수 능력 설정
# ['key item',
#	 '다른 섬에도 보급 가능', '재밍 삭제', '보유 가능 함정 수+α', '사거리 확장 Hex 수', '공격오차를1Hex 축소 확률',
#	 '명령 실행횟수', '식량 최댓값배율', '자금 최댓값배율', '수확배율', '수입배율', '함정 공격 횟수배율', '파괴력배율'
#	 '함정유지 식량배율', '함정유지비배율', '식량소비배율', '명령비배율', '파괴력증가'
# ]
@HitemSpecial = (
# 키, 보급, 지소, 보유, 사거리, 축소률, 코회, 식 max, 금 max, 수확, 수입, 공격 수, 파괴배, 유지식, 유지비, 식소, 코비, 지진, 태풍, 운석, 거대운석, 분화, 화재, 쓰나미, 파괴+
	[ 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0], # 다미(변경불가:아이템을 보유하지 않은 섬의 설정에 사용)
	[ 1, 0, 0, 0, 0, 0, 1, 10, 1, 2, 1, 1, 1, 0.5, 1, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 0],
	[ 1, 0, 0, 0, 0, 0, 1, 1, 10, 1, 2, 1, 1, 1, 0.5, 1, 0.5, 1, 1, 1, 1, 1, 1, 1, 0],
	[ 1, 0, 0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.5, 1, 1, 1, 1, 1, 1, 1, 0],
	[ 1, 0, 0, 10, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
	[ 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
	[ 1, 0, 1, 0, 0, 90, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
	[ 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],

	[ 1, 0, 0, 0, 0, 0, 1, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0],
	[ 1, 0, 0, 0, 0, 0, 1, 1, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0],
	[ 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 0, 0],
	[ 1, 0, 0, -5, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0],
	[ 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0],
	[ 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0],
	[ 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 0, 1, 1, 1, 1, 0],
);
# 0:key item(이속성을 보유츠아이템을 모두도음하기와 게임종료)[0:속성없고,1:속성있음]
# 1:다른 섬에도 보급 가능[0:속성없고,1:속성있음]
# 2:재밍가 삭제 가능(재밍·모드유효 시에만 효과 있음)[0:속성없고,1:속성있음]
# 3:보유 가능 함정 수를 늘릴[0:일반, 보유 가능 함정 수의 설정 값에주의해서 정수를 설정하는 것]
# 4:사거리 증가 Hex 수[0:일반, 함정의 능력 설정 값에주의해서 정수를 설정하는 것]
# 5:함정의 명중률 UP:함정 공격오차를 일정 확률로1Hex 축소[0:일반,1~100:%단위에서 지정]
# 6:1턴에실행하다 명령 수[1:일반, 물론정정수, 주의 하고 설정하는 것]
# 7:식량의 최댓값의 배율[1:일반,(양의 정수 지정:1보다 크게 하면 플러스 아이템, 작게 하면 마이너스 아이템)]
# 8:자금의 최댓값의 배율[1:일반,(양의 정수 지정:1보다 크게 하면 플러스 아이템, 작게 하면 마이너스 아이템)]
# 9:수확(식량)의 배율[1:일반,(양의 정수 지정:1보다 크게 하면 플러스 아이템, 작게 하면 마이너스 아이템)]
# 10:수입(자금)의 배율[1:일반,(양의 정수 지정:1보다 크게 하면 플러스 아이템, 작게 하면 마이너스 아이템)]
# 11:사용정 공격 횟수의 배율[1:일반,(정수 지정:1보다 크게 하면 플러스 아이템)]
# 12:함정의 파괴력의 배율[1:일반,(정수 지정:1보다 크게 하면 플러스 아이템)]
# 13:함정의 유지 식량의 배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 14:함정의 유지자금의 배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 15:식량의 소비의 배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 16:명령의 비용의 배율[1:일반,(정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 17:지진발생배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 18:태풍발생배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 19:운석발생배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 20:거대운석발생배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 21:분화발생배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 22:화재발생배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 23:쓰나미발생배율[1:일반,(양의 정수 지정:1보다 크게 하면 마이너스 아이템, 작게 하면 플러스 아이템)]
# 24:함정의 파괴력플러스[0:일반,(정수 지정:0보다크게 하면 플러스 아이템)]
#아이템을 복수 보유하는 경우,1~6,24은 가장 높은 값이 유효,7~23은 모든 배율을 곱한 값이 됩니다.

# 이미지 파일
@HitemImage = (
	'item0.gif', # 다미
	'item1.gif',
	'item2.gif',
	'item3.gif',
	'item4.gif',
	'item5.gif',
	'item6.gif',
	'item7.gif',
	'runa3.gif',
	'saramanda2.gif',
	'undhine3.gif',
	'doriado2.gif',
	'zin2.gif',
	'nomu2.gif',
	'wiruowisupu2.gif',
);
#@HitemImage = (
#	'yousei2.gif',
#	'runa3.gif',
#	'saramanda2.gif',
#	'undhine3.gif',
#	'doriado2.gif',
#	'zin2.gif',
#	'nomu2.gif',
#	'wiruowisupu2.gif',
#	'sheido2.gif'
#);

#아이템획득·탈취 확률(총 획득 경험치÷하에 설정한숫자 값)
# 획득: 거대 괴수 퇴치 시(0:판정하지 않음)
$HitemGetDenominator = 1000;

# 획득: 괴수 퇴치 시(0:판정하지 않음)
$HitemGetDenominator2 = 10000;

# 획득: 잔해 매각 시(0:판정하지 않음)
$HitemGetDenominator3 = 1000;

# 탈취:아이템유지 섬의 함정 격침 시(0:판정하지 않음 1:마지막 함정 1척(또는 항구 1개)을 파괴했을 시에모두탈취)
$HitemSeizeDenominator = 100;

# 매 턴 상위 섬부터 순서대로 핵심아이템을 하나씩 지급할지 설정합니다(크리스탈 쟁탈전용).
$HitemGivePerTurn = 0; # 0:부여에없고,1:부여 가능(상위의 섬에서),2:부여 가능(하위의 섬에서)

#----------------------------------------
# Battle Field 전용 설정
#----------------------------------------
# 소속 불명 함정의 출현율(0.01% 단위이며 면적과는 관계 없습니다. 0으로 하면 단위 면적 주변 플레이어 섬의 2배)
$HdisNavyBF = 0;

# 괴수 출현율(0.01% 단위이며 면적과는 관계 없습니다. 0으로 하면 단위 면적 주변 플레이어 섬의 2배)
$HdisMonsterBF = 0;

# 거대괴수 출현율(0.01% 단위이며 면적과는 관계 없습니다. 0으로 하면 단위 면적 주변 플레이어 섬의 2배)
$HdisHugeBF = 0;

# 우호국 설정을 무효로?(0:사용 안 함 1:하다) 참고: 함정의 보급·색인적·공격만우호국 설정을 무효화합니다
$HamityInvalid = 1;

#아이템의 능력을 무효로?(0:사용 안 함 1:하다) 참고: 공격 횟수2배·사거리 확장·전체 섬 보급 가능·명중률 UP·파괴력2배만 무효화합니다
$HitemInvalid = 1;

# 함정의 능력을 올릴까요?(0:사용 안 함 n:플러스 또는 마이너스 수치 지정)
@HnavyFireBF = ( 0, 0, 0, 0); # 공격 수 Fire 공격범위(오차)FireHex 사거리 범위 FireRange 파괴력 damage

#----------------------------------------
# 날씨
#----------------------------------------
# 날씨를 사용할까요?(0:금지)
$HuseWeather = 1;

@HweatherName = (
	'날씨', # 총명칭
	'쾌청',
	'맑음',
	'흐림',
	'짙은 안개',
	'비',
	'호우',
);

# 날씨비율(%로 배분하지 않아도 됩니다. 단, 배열의 첫 번째 요소는, 반드시0으로 둘 것.)
@HweatherRatio = ( 0, 3, 6, 3, 2, 5, 1);

# 특수 능력
@HweatherSpecial = ( 0, 0x3dc, 0x4cb, 0xa07, 0x970, 0xd24, 0xe11);
# 특수 능력의 내용은,!주(0:0, 1:-7, 2:-6, 3:-5, 4:-4, 5:-3, 6:-2, 7:-1, 8:0, 9:+1, a:+2, b:+3, c:+4, d:+5, e:+6, f:+7)
# 0x1~0xF 기온변화
$HweatherSpecialRatio[0] = 1; # 기온변화숫자 값의 배율
$HrKion = 2; # 무작위요소(+-)
# 0x10~0xF0 기압변화
$HweatherSpecialRatio[1] = 5; # 기압변화숫자 값의 배율
$HrKiatu = 50; # 무작위요소(+-)
# 0x100~0xF00 습도변화
$HweatherSpecialRatio[2] = 2; # 습도변화숫자 값의 배율
$HrSitudo = 15; # 무작위요소(+-)

# 이미지 파일
@HweatherImage = (
	'weather0.gif', # 다미
	'weather1.gif',
	'weather2.gif',
	'weather3.gif',
	'weather4.gif',
	'weather5.gif',
	'weather6.gif',
);

#----------------------------------------
# 수상 관계(최대32종류)
#----------------------------------------
# 턴잔을 몇 매 턴출습니까
$HturnPrizeUnit = 100;

# 상의 이름
# kind: 도의 요소에서 되는지(턴잔은 상위 몇 섬까지 수상할 섬 수를 숫자로 지정)
# ptr: ext 영역의 경우, 몇번째의 요소에서 되는지
# threshold: ptr 표시 값이 몇 개일 시 수상할지
# money: 상금
# name: 상의 이름
$Hprize[0] = { 'name' => '턴잔', 'kind' => '1', 'ptr' => 0, 'threshold' => 0, 'contribution' => 0, 'money' => 300 };
$Hprize[1] = { 'name' => '번영상', 'kind' => 'pop', 'ptr' => 0, 'threshold' => 3000, 'contribution' => 0, 'money' => 3000 };
$Hprize[2] = { 'name' => '초과 번영상', 'kind' => 'pop', 'ptr' => 0, 'threshold' => 5000, 'contribution' => 0, 'money' => 5000 };
$Hprize[3] = { 'name' => '궁극번영상', 'kind' => 'pop', 'ptr' => 0, 'threshold' => 10000, 'contribution' => 0, 'money' => 10000 };
$Hprize[4] = { 'name' => '평화상', 'kind' => 'achive', 'ptr' => 0, 'threshold' => 200, 'contribution' => 0, 'money' => 200 };
$Hprize[5] = { 'name' => '초과 평화상', 'kind' => 'achive', 'ptr' => 0, 'threshold' => 500, 'contribution' => 0, 'money' => 500 };
$Hprize[6] = { 'name' => '궁극평화상', 'kind' => 'achive', 'ptr' => 0, 'threshold' => 800, 'contribution' => 0, 'money' => 800 };
$Hprize[7] = { 'name' => '재난상', 'kind' => 'damage', 'ptr' => 0, 'threshold' => 500, 'contribution' => 0, 'money' => 500 };
$Hprize[8] = { 'name' => '초과 재난상', 'kind' => 'damage', 'ptr' => 0, 'threshold' => 1000, 'contribution' => 0, 'money' => 1000 };
$Hprize[9] = { 'name' => '궁극재난상', 'kind' => 'damage', 'ptr' => 0, 'threshold' => 2000, 'contribution' => 0, 'money' => 2000 };
$Hprize[10] = { 'name' => '구조국훈장장', 'kind' => 'ext', 'ptr' => 1, 'threshold' => 20000, 'contribution' => 0, 'money' => 0 };
$Hprize[11] = { 'name' => '우수등구조국훈장장', 'kind' => 'ext', 'ptr' => 1, 'threshold' => 50000, 'contribution' => 0, 'money' => 0 };
$Hprize[12] = { 'name' => '돌진격훈장장', 'kind' => 'ext', 'ptr' => 2, 'threshold' => 5, 'contribution' => 500, 'money' => 0 };
$Hprize[13] = { 'name' => '우수등돌진격훈장장', 'kind' => 'ext', 'ptr' => 2, 'threshold' => 10, 'contribution' => 1000, 'money' => 0 };
$Hprize[14] = { 'name' => '기마사훈장장', 'kind' => 'ext', 'ptr' => 3, 'threshold' => 10, 'contribution' => 500, 'money' => 0 };
$Hprize[15] = { 'name' => '우수등기마사훈장장', 'kind' => 'ext', 'ptr' => 3, 'threshold' => 20, 'contribution' => 1000, 'money' => 0 };
$Hprize[16] = { 'name' => '놀이격훈장장', 'kind' => 'ext', 'ptr' => 10, 'threshold' => 50, 'contribution' => 1000, 'money' => 0 };
$Hprize[17] = { 'name' => '우수등놀이격훈장장', 'kind' => 'ext', 'ptr' => 10, 'threshold' => 100, 'contribution' => 5000, 'money' => 0 };
$Hprize[18] = { 'name' => '십글자훈장장', 'kind' => 'ext', 'ptr' => 4, 'threshold' => 1000, 'contribution' => 500, 'money' => 0 };
$Hprize[19] = { 'name' => '우수등십글자훈장장', 'kind' => 'ext', 'ptr' => 4, 'threshold' => 2000, 'contribution' => 1000, 'money' => 0 };
$Hprize[20] = { 'name' => '제어방패훈장장', 'kind' => 'ext', 'ptr' => 5, 'threshold' => 50, 'contribution' => 200, 'money' => 0 };
$Hprize[21] = { 'name' => '감투 훈장', 'kind' => 'ext', 'ptr' => 6, 'threshold' => 50, 'contribution' => 200, 'money' => 0 };
$Hprize[22] = { 'name' => '철벽훈장장', 'kind' => 'ext', 'ptr' => 7, 'threshold' => 30, 'contribution' => 1000, 'money' => 0 };

#----------------------------------------------------------------------
# 기타 확장용 설정(기본적으로 변경 불가)
#----------------------------------------------------------------------
# ext[0] 승리 플래그
# ext[1] 공로 실적 point(=공헌도x10)
# ext[2] 파괴한 방위 시설의 수
# ext[3] 파괴한 미사일 기지의 수
# ext[4] 구출한 난민의 합계인구
# ext[5] 피해를 받을 미사일 수
# ext[6] 발사한 미사일 수
# ext[7] 방위 시설에서 장전된 미사일 수
# ext[8] 파견한 함정의 수
# ext[9] 파견된 함정의 수
# ext[10] 파괴한 함정의 수
#----------------------------------------
# 입력문자 수의 제한(전체 문자 수에서 지정)
#----------------------------------------
# 문자제한을 초과 했습니다 시, 처리를 안판단할까요?(0:사용 안 함 1:하다)
$HlengthAlert = 1;

$HlengthIslandName = 15; # 섬 이름
$HlengthOwnerName = 15; # 섬의 소유자의 이름
$HlengthMessage = 40; # 메인 페이지에 표시되는 각 섬의 코멘트
$HlengthLbbsName = 15; # '관광 게시판'의 게시글자 이름
$HlengthLbbsMessage = 60; # '관광 게시판'의 게시글
$HlengthFleetName = 10; # 함대의 이름
$HlengthAllyName = 15; # 동맹 이름
$HlengthAllyComment = 40; # '각 동맹 상황' 화면에 표시되는 맹주의 코멘트
$HlengthAllyTitle = 30; # '동맹 정보'란 화면에 표시되는 맹주 메시지 제목
$HlengthAllyMessage = 1500; # '동맹 정보'란 화면에 표시되는 맹주 메시지
$HlengthPresentLog = 100; # 관리자 선물 지급 모드의 메시지
#----------------------------------------
# 화면 표시 관련
#----------------------------------------
# <BODY>태그의 옵션, 제목은 hako-init.cgi 로 이동했습니다

# 태그
# 제목문자
$HtagTitle_ = '<div class="title">';
$H_tagTitle = '</div>';

# 큰 글자
$HtagBig_ = '<span class="big">';
$H_tagBig = '</span>';

# 섬 이름 등
$HtagName_ = '<span class="islName">';
$H_tagName = '</span>';

# 숨김 처리하지 않은 섬 이름
$HtagName2_ = '<span class="islName2">';
$H_tagName2 = '</span>';

# 순위 번호 등
$HtagNumber_ = '<span class="number">';
$H_tagNumber = '</span>';

# 순위표 머리글
$HtagTH_ = '<span class="head">';
$H_tagTH = '</span>';

# 개발 계획의 이름
$HtagComName_ = '<span class="command">';
$H_tagComName = '</span>';

# 개발 계획의 이름 턴 소비 있음 (입력완료 명령란)
$HtagComName1_ = '<span class="command1">';
$HcomNameColor1 = '#A08000'; # CSS 의색와 소로 가능분이이가지 않음도
# 개발 계획의 이름 턴 소비 없음 (입력완료 명령란)
$HtagComName2_ = '<span class="command2">';
$HcomNameColor2 = '#0080A0'; # CSS 의색와 소로 가능분이이가지 않음도

# 재해
$HtagDisaster_ = '<span class="disaster">';
$H_tagDisaster = '</span>';

# 로컬 게시판, 관광객의 표시 문자
$HtagLbbsSS_ = '<span class="lbbsSS">';
$H_tagLbbsSS = '</span>';

# 로컬 게시판, 섬주의 표시 문자
$HtagLbbsOW_ = '<span class="lbbsOW">';
$H_tagLbbsOW = '</span>';

#자금
$HtagMoney_ = '<span class="money">';
$H_tagMoney = '</span>';

# 식량
$HtagFood_ = '<span class="food">';
$H_tagFood = '</span>';

# 일반 문자색
$HnormalColor_ = '<span class="normal">';
$H_normalColor = '</span>';

# 순위표, 셀의 속성
$HbgTitleCell = 'class=TitleCell'; # 순위표 머리글시
$HbgNumberCell = 'class=NumberCell'; # 순위표순위
$HbgNameCell = 'class=NameCell'; # 순위표 섬 이름
$HbgInfoCell = 'class=InfoCell'; # 순위표 섬의 정보
$HbgCommentCell = 'class=CommentCell'; # 순위표코멘트란
$HbgInputCell = 'class=InputCell'; # 개발 계획양식
$HbgMapCell = 'class=MapCell'; # 개발 계획지도
$HbgCommandCell = 'class=CommandCell'; # 개발 계획입력완료미계획

# 최근의 날씨의 색속성
$headNameCellcolor = 'class=headNameCellcolor'; # 최근의 날씨의 헤더 부분의 셀색
$pointCellcolor = 'class=pointCellcolor'; # 최근의 날씨의 날씨 부분의 셀색
$pointCellcolor2 = 'class=pointCellcolor2'; # 최근의 날씨의 기상숫자 값의 셀색
$nameCellcolor = 'class=nameCellcolor'; # 최근의 날씨의 섬 이름의 표시 부분의 셀색

$tomorrowColor = 'class=TomorrowColor'; # 최근의 날씨의 명확일이후의 문자색
$todayColor = 'class=TodayColor'; # 최근의 날씨의 지금일의 문자색
$yesterdayColor = 'class=YesterdayColor'; # 최근의 날씨의 어제일이전의 문자색

#----------------------------------------------------------------------
# 아래쪽 스크립트는 변경을 전제로 하지 않습니다.
# 그래도 문제는 없습니다.
# 명령 이름과 가격 등은 알아보기 쉽게 두는 편이 좋습니다.
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 각종 상수
#----------------------------------------------------------------------
# 명령

# 계획 번호 설정
# 0 내정(개발)
$HcomPrepare = 1; # 개간
$HcomPrepare2 = 2; # 땅고르기
$HcomPrepare3 = 3; # 일괄 땅고르기
$HcomReclaim = 4; # 매립
$HcomReclaim2 = 5; # 고속매립
$HcomDestroy = 6; # 굴착
$HcomDestroy2 = 7; # 고속굴착
$HcomSellTree = 11; # 벌채
$HcomPlant = 12; # 나무 심기

# 1 내정(건설)
$HcomFarm = 21; # 농장 건설
$HcomFastFarm = 22; # 고속 농장 건설
$HcomFactory = 23; # 공장 건설
$HcomFastFactory = 24; # 고속 공장 건설
$HcomMountain = 25; # 채굴장 건설
$HcomMonument = 31; # 기념비 건조
$HcomBouha = 32; # 방파제 설치

@HcomComplex = (); # 복합시설
if(!$HuseComplex) { # 사용하지 않는 경우의 처리
	@HcomplexName = ();
	@HcomplexComName = ();
}
foreach (0..$#HcomplexComName) {
	$HcomComplex[$_] = 41 + $_; # 41~
}
$HcomComplex[0] = 40 if($HcomComplex[0] eq '');

# 2 내정(운영)
$HcomDoNothing = 91; # *자금 조달
$HcomSell = 92; # *식량 수출
$HcomBuy = 93; # *식량 수입
$HcomPropaganda = 94; # *이주 홍보
$HcomGiveup = 95; # *섬 포기

# 3 해군(건조)
@HcomNavy = ();
foreach (0..$#HnavyName) {
	$HcomNavy[$_] = 101 + $_; # 101~132
}
$HcomNavy[0] = 100 if($HcomNavy[0] eq '');

# 4 해군(지령)
$HcomNavyMove = 201; # 함대 이동(파견·귀환을 통합)
$HcomNavySend = 202; # 함대 파견
$HcomNavyReturn = 203; # 함대 귀환
$HcomNavyForm = 211; # 함대 편성
$HcomNavyExpell = 212; # 함정 소속 해제(함정을 소속 불명으로 전환)구'함정 소속 해제'
$HcomNavyDestroy = 213; # 함정 폐기
$HcomNavyWreckRepair = 214; # 잔해 수리
$HcomNavyWreckSell = 215; # 잔해 매각
$HcomMoveTarget = 216; # 이동 조종 구'기함·괴수조작'
$HcomMoveMission = 217; # 이동 지령
$HcomNavyMission = 218; # 함정 지령 변경
$HcomNavyTarget = 219; # 일제 공격

# 5 외교
$HcomMoney = 301; # *자금 지원
$HcomFood = 302; # *식량 지원
$HcomAmity = 311; # *우호국속성 변경
$HcomAlly = 312; # *동맹가입·탈퇴
$HcomDeWar = 321; # *선전포고
$HcomCeasefire = 322; # *정전 제안

# 6 군사(건설)
$HcomDbase = 331; # 방위 시설 건설
$HcomHaribote = 332; # 가짜 기지 건설
$HcomSeaMine = 333; # 기뢰 설치
$HcomCore = 340; # 코어 설치
$HcomBase = 341; # 미사일 기지 건설
$HcomSbase = 342; # 해저 기지 건설

# 7 군사(공격)
@HcomMissile = ();
foreach (0..$#HmissileName) {
	$HcomMissile[$_] = 351 + $_; # 351~360
}
if($HcomMissile[0] eq '') {
	$HcomMissile[0] = 350;
} else {
	foreach (0..$#HmissileName) { # ST 속성 확인
		$STcheck{$HcomMissile[$_]} = 1 if($HmissileSpecial[$_] & 0x1);
	}
}
$HcomSendMonster = 361; # 괴수 파견
$HcomSendMonsterST = 362; # ST 괴수 파견

# 8 자동 입력
$HcomAutoPrepare = 401; # 전체 개간
$HcomAutoPrepare2 = 402; # 전체땅고르기
$HcomAutoDelete = 403; # 전체 명령 삭제
$HcomAutoReclaim = 404; # 매립
$HcomAutoDestroy = 405; # 굴착
$HcomAutoSellTree = 406; # 벌채
$HcomAutoForestry = 407; # 벌채와 나무 심기

# 순서
my @comList = (
	# 0 내정(개발)
	 $HcomPrepare, $HcomPrepare2, $HcomPrepare3,
	 $HcomReclaim, $HcomReclaim2, $HcomDestroy, $HcomDestroy2,
	# 1 내정(건설)
	 $HcomFarm, $HcomFastFarm, $HcomFactory, $HcomFastFactory, $HcomMountain,
	 $HcomMonument, $HcomBouha, @HcomComplex,
	# 2 내정(운영)
	 $HcomSell, $HcomBuy, $HcomSellTree, $HcomPlant,
	 $HcomDoNothing, $HcomPropaganda, $HcomGiveup,
	# 3 해군(건조)
	 @HcomNavy,
	# 4 해군(지령)
	 $HcomNavyMove, $HcomNavySend, $HcomNavyReturn,
	 $HcomNavyForm, $HcomNavyExpell, $HcomNavyDestroy,
	 $HcomNavyWreckRepair, $HcomNavyWreckSell,
	 $HcomMoveTarget, $HcomMoveMission, $HcomNavyMission, $HcomNavyTarget,
	# 5 외교
	 $HcomMoney, $HcomFood, $HcomAmity, $HcomAlly, $HcomDeWar, $HcomCeasefire,
	# 6 군사(건설)
	 $HcomCore,
	 $HcomBase, $HcomDbase, $HcomSbase, $HcomHaribote, $HcomSeaMine,
	# 7 군사(공격)
	 @HcomMissile,
	 $HcomSendMonster, $HcomSendMonsterST,
	# 8 자동 입력
	 $HcomAutoReclaim, $HcomAutoDestroy, $HcomAutoSellTree, $HcomAutoForestry,
	 $HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoDelete
	);

#-------------------------------------------------------------------------
# 플래그 확인(변경불필요)
	my $flagcheck = 0;
	$HuseFlag = 0;
	foreach(@HnavySpecial) {
		if($_ & 0x80) {
			$flagcheck = 1;
		} elsif(!$HsuicideAbility && ($_ & 0x2000000)) {
			$_ |= 0x80; # 기함·이동 조종이 아니면몸통박치기하지 않은 경우, 능력 누락을 보정
		}
	}
	foreach(@HmonsterSpecial, @HhugeMonsterSpecial) {
		if($_ & 0x80) {
			$flagcheck = 1;
			last;
		}
	}
	$HuseFlag = $flagcheck; # 능력이 있어도 기함·이동 조종을 사용하지 않는 경우 $flagcheck를 0으로 설정.
	if($HcomNavy[0] == 100) {
		$HcountLandPort = 0;
		$HuseFlag = 0;
		$HusePriority = 0;
		$HnavyUnknown = 0;
		$HdisNavyBF = 0;
	}
# 플래그 확인여기까지
#-------------------------------------------------------------------------
# 명령 목록 생성(변경불필요)
@HcomList = ();
foreach (@comList) {
	next if (($_ == $HcomAlly) && (!$HallyUse || !$HallyJoinComUse || $HarmisticeTurn || $Htournament));
	next if (($_ == $HcomAmity) && (!$HuseAmity || $HarmisticeTurn || $Htournament));
	next if ((($_ == $HcomDeWar) ||
			($_ == $HcomCeasefire)
			) && (!$HuseDeWar || $HarmisticeTurn || $HsurvivalTurn || $Htournament));
	next if (($_ == $HcomBase) && !$HuseBase);
	next if (($_ == $HcomSbase) && (!$HuseSbase || $Htournament));
	next if (($_ == $HcomBouha) && !$HuseBouha);
	next if (($_ == $HcomSeaMine) && !$HuseSeaMine);
	next if ((($HcomMissile[0] <= $_) && ($_ <= $HcomMissile[$#HmissileName])
			) && !$HuseBase && !$HuseSbase);
	next if ($STcheck{$_} && (!$HuseMissileST || $Htournament));
	next if (($_ == $HcomSendMonster) && (!$HuseSendMonster || $Htournament));
	next if (($_ == $HcomSendMonsterST) && (!$HuseSendMonsterST || $Htournament));
	next if (($_ == $HcomMoveTarget) && !$HuseFlag);
	next if (($_ == $HcomNavyTarget) && !$HuseTarget);
	next if (($_ == $HcomPrepare3) && !$HusePrepare3);
	next if (($_ == $HcomFastFarm) && !$HuseFastFarm);
	next if (($_ == $HcomFastFactory) && !$HuseFastFactory);
	next if (($_ == $HcomReclaim2) && !$HuseFastReclaim);
	next if (($_ == $HcomDestroy2) && !$HuseFastDestroy);
	next if ((($_ == $HcomMonument) ||
			($_ == $HcomFood) ||
			($_ == $HcomMoney) ||
			($_ == $HcomPropaganda)
			) && $Htournament);
	next if (($HcomNavy[0] == 100) && (201 <= $_) && ($_ <= 220));
	next if (($_ == $HcomFarm) && !$HuseFarm);
	next if (($_ == $HcomFactory) && !$HuseFactory);
	next if (($_ == $HcomMountain) && !$HuseMountain);
	next if ((($_ == $HcomPlant) || ($_ == $HcomSellTree)) && !$HusePlantSellTree);
	next if (($_ == $HcomCore) && !$HuseCore);
#	next if ((($_ == $HcomNavyMove) ||
#			($_ == $HcomNavySend) ||
#			($_ == $HcomNavyReturn)
#			) && $HoceanMode && $HnotuseNavyMove);
	next if (($_ == $HcomMoveMission) && !$HoceanMode);
	push(@HcomList, $_);
}
$HcommandTotal = $#HcomList + 1; # 명령 종류
foreach (@HcomList) {
	$HcomUse{$_} = 1;
}

# 명령 분할
# 이 명령 분할만은, 자동 입력 명령은 설정하지 마세요.
@HcommandDivido = (
	'내정(개발),0,20', # 개발지도
	'내정(건설),21,40', # 개발지도
	"내정(건설),$HcomComplex[0],$HcomComplex[$#HcomplexComName]", # 개발지도
	'내정(운영),91,100',
	"해군(건조),$HcomNavy[0],$HcomNavy[$#HcomNavy]", # 개발지도
	'해군(지령),201,220', # 개발지도 목표지도
	'외교,301,330',
	'군사(건설),331,350', # 개발지도
	'군사(공격),351,370', # 목표지도
);
$HcommandAuto = '자동 입력,401,410';

# 주의:공백은 넣지 않도록
# ○→	'개발,0,10', # 계획번호00~10
# ×→	'개발, 0,10 ', # 계획번호00~10

# 계획의 이름과 간이설명, 비용, 턴 소비
$HcomName[$HcomPrepare] = '개간';
$HcomMsgs[$HcomPrepare] = '황무지와 건설물 계열 지형을 평지로 만듭니다.';
$HcomCost[$HcomPrepare] = 5;
$HcomTurn[$HcomPrepare] = 1;
$HcomName[$HcomPrepare2] = '땅고르기';
$HcomMsgs[$HcomPrepare2] = '턴을 소비하지 않는 개간입니다. 많이 실행할수록 지진 확률이 상승합니다.';
$HcomCost[$HcomPrepare2] = 100;
$HcomTurn[$HcomPrepare2] = 0;
$HcomName[$HcomPrepare3] = '일괄 땅고르기';
$HcomMsgs[$HcomPrepare3] = '이 명령 하나로 모든 황무지를 땅고르기합니다.';
$HcomCost[$HcomPrepare3] = "황무지 수x${HcomCost[$HcomPrepare2]}";
$HcomTurn[$HcomPrepare3] = 0;
$HcomName[$HcomReclaim] = '매립';
$HcomMsgs[$HcomReclaim] = '바다→얕은 바다→황무지. 육지 주변에서만 가능합니다.';
$HcomCost[$HcomReclaim] = 150;
$HcomTurn[$HcomReclaim] = 1;
$HcomName[$HcomReclaim2] = '고속매립';
$HcomMsgs[$HcomReclaim2] = '턴을 소비하지 않는 매립입니다.';
$HcomCost[$HcomReclaim2] = 3000;
$HcomTurn[$HcomReclaim2] = 0;
$HcomName[$HcomDestroy] = '굴착';
$HcomMsgs[$HcomDestroy] = '황무지→얕은 바다→바다. 바다에서 수량을 지정하면 유전을 탐사합니다.';
$HcomCost[$HcomDestroy] = 200;
$HcomTurn[$HcomDestroy] = 1;
$HcomName[$HcomDestroy2] = '고속굴착';
$HcomMsgs[$HcomDestroy2] = '턴을 소비하지 않는 굴착입니다.';
$HcomCost[$HcomDestroy2] = 4000;
$HcomTurn[$HcomDestroy2] = 0;
$HcomName[$HcomSellTree] = '벌채';
$HcomMsgs[$HcomSellTree] = '숲에서 실행하면 평지로 바뀌며 자금화됩니다.';
$HcomCost[$HcomSellTree] = 0;
$HcomTurn[$HcomSellTree] = 1 - $HnoturnSellTree;
$HcomName[$HcomPlant] = '나무 심기';
$HcomMsgs[$HcomPlant] = '평지와 마을 계열 지형에서 실행 가능합니다.';
$HcomCost[$HcomPlant] = 50;
$HcomTurn[$HcomPlant] = 1;

$HcomName[$HcomFarm] = '농장 건설';
$HcomMsgs[$HcomFarm] = '식량 생산 시설입니다. 최대 5만 명 규모까지 확장할 수 있습니다. (복수 가능)';
$HcomCost[$HcomFarm] = 20;
$HcomTurn[$HcomFarm] = 1;
$HcomName[$HcomFastFarm] = '고속 농장 건설';
$HcomMsgs[$HcomFastFarm] = '턴을 소비하지 않는 농장 건설입니다. (복수 가능)';
$HcomCost[$HcomFastFarm] = 500;
$HcomTurn[$HcomFastFarm] = 0;
$HcomName[$HcomFactory] = '공장 건설';
$HcomMsgs[$HcomFactory] = '자금 생산 시설입니다. 최대 10만 명 규모까지 확장할 수 있습니다. (복수 가능)';
$HcomCost[$HcomFactory] = 100;
$HcomTurn[$HcomFactory] = 1;
$HcomName[$HcomFastFactory] = '고속 공장 건설';
$HcomMsgs[$HcomFastFactory] = '턴을 소비하지 않는 공장 건설입니다. (복수 가능)';
$HcomCost[$HcomFastFactory] = 2500;
$HcomTurn[$HcomFastFactory] = 0;

foreach (0..$#HcomplexComName) {
	$HcomName[$HcomComplex[$_]] = $HcomplexComName[$_];
	$HcomMsgs[$HcomComplex[$_]] = $HcomplexComMsgs[$_];
	$HcomCost[$HcomComplex[$_]] = $HcomplexComCost[$_];
	$HcomTurn[$HcomComplex[$_]] = $HcomplexComTurn[$_];
}
$HcomName[$HcomBase] = '미사일 기지 건설';
$HcomMsgs[$HcomBase] = '미사일 발사에 필요합니다.';
$HcomCost[$HcomBase] = 300;
$HcomTurn[$HcomBase] = 1;
$HcomName[$HcomMonument] = '기념비 건조';
$HcomMsgs[$HcomMonument] = "$AfterName의 상징입니다. 추가로 건설할 수 있습니다.";
$HcomCost[$HcomMonument] = 9999;
$HcomTurn[$HcomMonument] = 1;
$HcomName[$HcomCore] = '코어 설치';
$HcomMsgs[$HcomCore] = "$AfterName의 코어입니다.";
$HcomCost[$HcomCore] = 9999;
$HcomTurn[$HcomCore] = 1;
$HcomName[$HcomHaribote] = '가짜 기지 건설';
$HcomMsgs[$HcomHaribote] = '겉보기에는 방위 시설이지만 위장 효과 외에는 의미가 없습니다.';
$HcomCost[$HcomHaribote] = 1;
$HcomTurn[$HcomHaribote] = 1;
$HcomName[$HcomBouha] = '방파제 설치';
$HcomMsgs[$HcomBouha] = '주변 2칸을 쓰나미 피해에서 보호합니다.';
$HcomCost[$HcomBouha] = 500;
$HcomTurn[$HcomBouha] = 1;
$HcomName[$HcomDbase] = '방위 시설 건설';
$HcomMsgs[$HcomDbase] = '주변 2칸의 미사일을 방어합니다(자신은 제외).';
$HcomCost[$HcomDbase] = 3000;
$HcomTurn[$HcomDbase] = 1;
$HcomName[$HcomMountain] = '채굴장 건설';
$HcomMsgs[$HcomMountain] = '자금 생산 시설입니다. 재해에 강하며 최대 20만 명 규모까지 확장할 수 있습니다. (복수 가능)';
$HcomCost[$HcomMountain] = 300;
$HcomTurn[$HcomMountain] = 1;
$HcomName[$HcomSeaMine] = '기뢰 설치';
$HcomMsgs[$HcomSeaMine] = '바다에 설치합니다. 이미 있으면 제거합니다. 수량으로 파괴력을 지정합니다.';
$HcomCost[$HcomSeaMine] = 300;
$HcomTurn[$HcomSeaMine] = 1;
$HcomName[$HcomSbase] = '해저 기지 건설';
$HcomMsgs[$HcomSbase] = '바다에 미사일 기지를 건설합니다.';
$HcomCost[$HcomSbase] = 8000;
$HcomTurn[$HcomSbase] = 1;

foreach (0..$#HmissileName) {
	$HcomName[$HcomMissile[$_]] = $HmissileName[$_]. '발사';
	$HcomMsgs[$HcomMissile[$_]] = $HmissileMsgs[$_];
	$HcomCost[$HcomMissile[$_]] = $HmissileCost[$_];
	$HcomTurn[$HcomMissile[$_]] = $HmissileTurn[$_];
}

$HcomName[$HcomSendMonster] = '괴수 파견';
$HcomMsgs[$HcomSendMonster] = '괴수를 출현시킵니다.';
$HcomCost[$HcomSendMonster] = '@종류별 비용';
$HcomTurn[$HcomSendMonster] = 1;
$HcomName[$HcomSendMonsterST] = 'ST 괴수 파견';
$HcomMsgs[$HcomSendMonsterST] = '괴수를 출현시킵니다. 의미 없는 출현은 피하세요.';
$HcomCost[$HcomSendMonsterST] = '@종류별 비용';
$HcomTurn[$HcomSendMonsterST] = 0; # ST 의 연속은 불가

foreach (0..$#HnavyName) {
	$HcomName[$HcomNavy[$_]] = $HnavyName[$_]. (($HnavySpecial[$_] & 0x8) ? '건설' : '건조');
	$HcomMsgs[$HcomNavy[$_]] = $HnavyName[$_]. '을/를 '. (($HnavySpecial[$_] & 0x8) ? '건설' : '건조');
	$HcomCost[$HcomNavy[$_]] = $HnavyCost[$_];
	$HcomTurn[$HcomNavy[$_]] = 1;
}

$HcomName[$HcomNavyMove] = '함대 이동';
$HcomMsgs[$HcomNavyMove] = "$AfterName에서 다른 $AfterName으로 함대를 파견 또는 귀환 구분 없이 이동합니다.";
$HcomCost[$HcomNavyMove] = 0;
$HcomTurn[$HcomNavyMove] = 1;
$HcomName[$HcomNavySend] = '함대 파견';
$HcomMsgs[$HcomNavySend] = '함대를 파견합니다.';
$HcomCost[$HcomNavySend] = 0;
$HcomTurn[$HcomNavySend] = 1;
$HcomName[$HcomNavyReturn] = '함대 귀환';
$HcomMsgs[$HcomNavyReturn] = '파견 함대를 귀환시킵니다.';
$HcomCost[$HcomNavyReturn] = 0;
$HcomTurn[$HcomNavyReturn] = 1;
$HcomName[$HcomNavyForm] = '함대 편성';
$HcomMsgs[$HcomNavyForm] = '수량 지정으로 함정의 소속 함대를 변경합니다.';
$HcomCost[$HcomNavyForm] = 0;
$HcomTurn[$HcomNavyForm] = 0;
$HcomName[$HcomNavyExpell] = '함정 소속 해제';
$HcomMsgs[$HcomNavyExpell] = '함정을 소속 불명으로 전환합니다.';
$HcomCost[$HcomNavyExpell] = 0;
$HcomTurn[$HcomNavyExpell] = 0;
$HcomName[$HcomNavyDestroy] = '함정 폐기';
$HcomMsgs[$HcomNavyDestroy] = '함정을 폐기합니다.';
$HcomCost[$HcomNavyDestroy] = 0;
$HcomTurn[$HcomNavyDestroy] = 0;
$HcomName[$HcomNavyWreckRepair] = '잔해 수리';
$HcomMsgs[$HcomNavyWreckRepair] = '수리한 함정은 함대에 편입됩니다.';
$HcomCost[$HcomNavyWreckRepair] = '@실비';
$HcomTurn[$HcomNavyWreckRepair] = 1;
$HcomName[$HcomNavyWreckSell] = '잔해 매각';
$HcomMsgs[$HcomNavyWreckSell] = '매각 시 금괴를 발견할 수 있습니다.';
$HcomCost[$HcomNavyWreckSell] = '@시가';
$HcomTurn[$HcomNavyWreckSell] = 1;
$HcomName[$HcomMoveTarget] = '이동 조종';
$HcomMsgs[$HcomMoveTarget] = '기함에 이동 방향을 지시할 수 있습니다.';
$HcomCost[$HcomMoveTarget] = 0;
$HcomTurn[$HcomMoveTarget] = 0;
$HcomName[$HcomMoveMission] = '이동 지령';
$HcomMsgs[$HcomMoveMission] = '함대에 이동 목표를 지시할 수 있습니다. 해제할 때까지 유효합니다. 1의 자리는 함대 번호이며, 10의 자리에 9를 붙이면 해제됩니다.';
$HcomCost[$HcomMoveMission] = 0;
$HcomTurn[$HcomMoveMission] = 0;
$HcomName[$HcomNavyMission] = '함정 지령 변경';
$HcomMsgs[$HcomNavyMission] = '일반(0)·순항(1)·퇴치(2)·정선(3)으로 전환합니다. 10의 자리로 함대를 지정할 수 있습니다';
$HcomCost[$HcomNavyMission] = 0;
$HcomTurn[$HcomNavyMission] = 0;
$HcomName[$HcomNavyTarget] = '일제 공격';
$HcomMsgs[$HcomNavyTarget] = '지정한 지점을 사거리 안에 둔 함정을 공격 대상으로 지정합니다.';
$HcomCost[$HcomNavyTarget] = 1000;
$HcomTurn[$HcomNavyTarget] = 1;

$HcomName[$HcomAmity] = '우호국 설정·해제';
$HcomMsgs[$HcomAmity] = "설정한 $AfterName에는 함정이 공격하지 않습니다.";
$HcomCost[$HcomAmity] = 0;
$HcomTurn[$HcomAmity] = 0;
$HcomName[$HcomAlly] = '동맹 가입·탈퇴';
$HcomMsgs[$HcomAlly] = "맹주 또는 동맹 소속 $AfterName을 지원합니다.";
$HcomCost[$HcomAlly] = 0;
$HcomTurn[$HcomAlly] = 1;
$HcomName[$HcomDeWar] = '선전포고';
$HcomMsgs[$HcomDeWar] = '교전국으로 지정하는 명령입니다.';
$HcomCost[$HcomDeWar] = 0;
$HcomTurn[$HcomDeWar] = 0;
$HcomName[$HcomCeasefire] = '정전 제안';
$HcomMsgs[$HcomCeasefire] = '교전 상태를 해제하려면 합의가 필요합니다';
$HcomCost[$HcomCeasefire] = 0;
$HcomTurn[$HcomCeasefire] = 0;

$HcomName[$HcomSell] = '식량 수출';
$HcomMsgs[$HcomSell] = '식량을 자금으로 바꿉니다.';
$HcomCost[$HcomSell] = -100;
$HcomTurn[$HcomSell] = 0;
$HcomName[$HcomBuy] = '식량 수입';
$HcomMsgs[$HcomBuy] = '자금을 식량으로 바꿉니다.';
$HcomCost[$HcomBuy] = 100;
$HcomTurn[$HcomBuy] = 0;
$HcomName[$HcomMoney] = '자금 지원';
$HcomMsgs[$HcomMoney] = '지원량을 수량으로 지정합니다.';
$HcomCost[$HcomMoney] = 100;
$HcomTurn[$HcomMoney] = 0;
$HcomName[$HcomFood] = '식량 지원';
$HcomMsgs[$HcomFood] = '지원량을 수량으로 지정합니다.';
$HcomCost[$HcomFood] = -100;
$HcomTurn[$HcomFood] = 0;
$HcomName[$HcomPropaganda] = '이주 홍보';
$HcomMsgs[$HcomPropaganda] = '인구가 증가합니다.';
$HcomCost[$HcomPropaganda] = 1000;
$HcomTurn[$HcomPropaganda] = 1;
$HcomName[$HcomGiveup] = "${AfterName} 포기";
$HcomMsgs[$HcomGiveup] = '섬을 포기합니다.';
$HcomCost[$HcomGiveup] = 0;
$HcomTurn[$HcomGiveup] = 1;
$HcomName[$HcomDoNothing] = '자금 조달';
$HcomMsgs[$HcomDoNothing] = "$HdoNothingMoney$HunitMoney 입금됩니다. 자동 포기에 주의하세요!";
$HcomCost[$HcomDoNothing] = 0;
$HcomTurn[$HcomDoNothing] = 1; # 0으로 해도 1입니다. 의미 없습니다(^^)V

$HcomName[$HcomAutoPrepare] = '개간 자동 입력';
$HcomMsgs[$HcomAutoPrepare] = '현재 있는 모든 황무지에 개간을 설정';
$HcomCost[$HcomAutoPrepare] = 0;
$HcomTurn[$HcomAutoPrepare] = 0;
$HcomName[$HcomAutoPrepare2] = '땅고르기 자동 입력';
$HcomMsgs[$HcomAutoPrepare2] = '현재 있는 모든 황무지에 땅고르기를 설정';
$HcomCost[$HcomAutoPrepare2] = 0;
$HcomTurn[$HcomAutoPrepare2] = 0;
$HcomName[$HcomAutoDelete] = '전체 계획 삭제';
$HcomMsgs[$HcomAutoDelete] = '입력된 전체 계획을 삭제할 시 사용';
$HcomCost[$HcomAutoDelete] = 0;
$HcomTurn[$HcomAutoDelete] = 0;
$HcomName[$HcomAutoReclaim] = '매립 자동 입력';
$HcomMsgs[$HcomAutoReclaim] = '현재 있는 모든 얕은 바다에 매립을 설정';
$HcomCost[$HcomAutoReclaim] = 0;
$HcomTurn[$HcomAutoReclaim] = 0;
$HcomName[$HcomAutoDestroy] = '굴착 자동 입력';
$HcomMsgs[$HcomAutoDestroy] = '현재 있는 모든 얕은 바다에 굴착을 설정';
$HcomCost[$HcomAutoDestroy] = 0;
$HcomTurn[$HcomAutoDestroy] = 0;
$HcomName[$HcomAutoSellTree] = '벌채 자동 입력';
$HcomMsgs[$HcomAutoSellTree] = '수량(100그루 단위)보다 적은 숲이 대상입니다.';
$HcomCost[$HcomAutoSellTree] = 0;
$HcomTurn[$HcomAutoSellTree] = 0;
$HcomName[$HcomAutoForestry] = '벌채 및 나무 심기 자동 입력';
$HcomMsgs[$HcomAutoForestry] = '수량의 수(단위백)보다적으면 숲을 벌채시, 신타에나무 심기시또한스.';
$HcomCost[$HcomAutoForestry] = 0;
$HcomTurn[$HcomAutoForestry] = 0;

1;
