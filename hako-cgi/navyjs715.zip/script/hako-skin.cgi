#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 모형정원 스킨·모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 모형정원 스킨의 설정
#----------------------------------------------------------------------
# 메인
sub hakoSkinMain {

	my($Hskinflag);
	if($HskinName eq '' || $HskinName eq "${HcssDir}/$HcssDefault"){
		$Hskinflag = '<span class=attention>미설정</span>';
	} elsif($HskinName =~ /${HcssDir}\/([^\)]*)/ ) {
		$Hskinflag = $HcssFile{$1};
	} else {
		$Hskinflag = '<span class=attention>미설정</span>';
	}

	my $select_list;
	foreach (keys %HcssFile) {
		my $s = ($_ eq $HcssDefault) ? ' selected' : '';
		$select_list.= "<OPTION value='$_'$s>$HcssFile{$_}\n";
	}


	# 화면 출력
	unlock();

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='hakoSkin'>
<H1>모형정원 스킨의 설정</H1>
<table border width=50%><tr><td class='N'>
 모형정원 스킨을 변경해 원하는 인터페이스로 사용하세요!<br>
 기분 전환용으로 이용해 주세요. m(_ _)m
</td></tr></table>
<table border=0 width=50%><tr><td class="M">
현재 설정<B>[</b> ${Hskinflag} <B>]</B>
<form action=$HthisFile method=POST>
<SELECT NAME="SKIN">$select_list</SELECT>
<INPUT TYPE="submit" VALUE="설정" name=SKINSET>
</form>

<form action=$HthisFile method=POST>
<INPUT TYPE=hidden NAME="SKIN" value="del">
<INPUT TYPE="submit" VALUE="설정 해제" name=SKINSET>
</form>
</td></tr></table>
</DIV>
END
}

1;

###----------###
### 도입방법 ###
###----------###
### 주!본체의 HTML 출력 부분에스타일시트의 class 야 id 을 설정하지 않으면
### 도입할 의미가 없습니다(^^;;

### 행 앞부분의 #을 포함해 복사해 붙여넣으세요. ###은 도입 설명용 주석이므로 복사할 필요가 없습니다


### 설정 부분에추가
## CSS 을배치할 디렉터리
#$HcssDir = "$HbaseDir";
## 기본값 CSS 파일의 이름
#$HcssDefault = 'style.css';
#
## 모형정원 스킨의 설정
#%HcssFile = (
#	"$HcssDefault" => 'Default', # 'CSS 파일 이름' => '스킨 이름'로 추가.','를 붙이는 것을 잊지 않도록 주의
#);

### 메인 모드분기 부분에추가
#} elsif($HmainMode eq 'hakoskin') {
#	# 모형정원 스킨의 설정
#	require('./hako-skin.cgi');
#	hakoSkinMain();

### CGI 읽기 부분에추가 sub cgiInput 내의 main mode 의가져오기 부분
#	} elsif($getLine =~ /Skin=([0-9]*)/) {
#		$HmainMode = 'hakoskin';

### CGI 읽기 부분에추가 sub cgiInput 내
#	if($line =~ /SKIN=([^\&]*)\&/) {
#		my($flag) = $1;
#		if(($flag eq 'del') || ($flag eq '')){
#			$flag = "${HcssDir}/$HcssDefault";
#		} else {
#			$flag = "${HcssDir}/". $flag;
#		}
#		$HskinName = $flag;
#	}

### cookie 입력에추가
#	if($cookie =~ /${HthisFile}SKIN=\(([^\)]*)\)/) {
#		$HskinName = $1;
#	}

### cookie 출력에추가
#	if($HskinName) {
#		$cookie.= "Set-Cookie: ${HthisFile}SKIN=($HskinName) $info";
#	}

### 헤더에추가 sub tempHeader 내의 print(out)처리이전(참고: 있다면 sub tempHeaderJava 에도추가)
#	if($HskinName ne '' ){
#		$baseSKIN = $HskinName;
#	} else {
#		$baseSKIN = "${HcssDir}/$HcssDefault";
#	}

### 헤더에추가 sub tempHeader 내의 BASE HREF 의하주변에추가(참고: 있다면 sub tempHeaderJava 에도추가)
#<link rel="stylesheet" type="text/css" href="${baseSKIN}">

### 헤더나 메인 페이지의 링크 부분에추가
#	out(qq|[<A href="$HthisFile?Skin=0">모형정원 스킨의 설정</A>] |);
### out 을사용하지 않아도해도,[<A href="$HthisFile?Skin=0">모형정원 스킨의 설정</A>]이 HTML 안에 기술되도록 하면 됩니다
