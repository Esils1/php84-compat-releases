#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 모형정원 바다전쟁 JS ver7.xx
# 각종 목록모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 우호국 설정 목록
#----------------------------------------------------------------------
sub amityInfo() {
	# 화면 출력
	unlock();
	my($title) = '';
	$title = '우호국' if($HuseAmity);
	if($HuseDeWar) {
		$title.= '·' if($HuseAmity);
		$title.= '교전국';
	}

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='campInfo'>
<H1>$title 목록</H1>
<span class='number'>◎</span>:친구좋음(상대상호)
<span class='number'>○</span>:친구좋음
${HtagDisaster_}X${H_tagDisaster}:교전쟁(선전포고)
${HtagDisaster_}x${H_tagDisaster}:교전쟁(피선전포고)
-:안설립
<TABLE BORDER><TR>
<TH $HbgTitleCell>${HtagTH_}$title${H_tagTH}</TH>
END

	my($number, $island, $name, $i, %warFlag);
	for($i=0;$i < $#HwarIsland;$i+=4){
		my($id1) = $HwarIsland[$i+1];
		my($id2) = $HwarIsland[$i+2];
		my($tn1) = $HidToNumber{$id1};
		my($tn2) = $HidToNumber{$id2};
		next if(($tn1 eq '') || ($tn2 eq ''));
		$warFlag{"$id1,$id2"} = 1;
	}
	foreach ($HbfieldNumber..$islandNumber) {
		$number = $_;
		$island = $Hislands[$number];
		$name = islandName($island);
		out(<<END);
<TD class='T'>$name</TD>
END
	}
	my $aStr = ($HarmisticeTurn) ? '진영' : '동맹';
	out("<TH $HbgTitleCell>${HtagTH_}${aStr}${H_tagTH}</TH>\n") if($HallyNumber);
	out("</TR>\n");
	foreach ($HbfieldNumber..$islandNumber) {
		$island = $Hislands[$_];
		$name = islandName($island);
		my($id, $amity, %amityFlag, $aId);
		$id = $island->{'id'};
		$amity = $island->{'amity'};
		foreach (@$amity) {
			$amityFlag{$_} = 1;
		}
		out("<TR>\n<TH $HbgTitleCell>$name</TH>\n");
		foreach $number ($HbfieldNumber..$islandNumber) {
			$aId = $Hislands[$number]->{'id'};
			my($tAmity, %tAmityFlag);
			$tAmity = $Hislands[$number]->{'amity'};
			foreach (@$tAmity) {
				$tAmityFlag{$_} = 1;
			}
			if($id == $aId) {
				out("<TD align='center'>=</TD>\n");
			} elsif($amityFlag{$aId}) {
				if($tAmityFlag{$id}) {
					out("<TD align='center'><span class='number'>◎</span></TD>\n");
				} else {
					out("<TD align='center'><span class='number'>○</span></TD>\n");
				}
			} elsif($warFlag{"$id,$aId"}) {
				out("<TD align='center'>${HtagDisaster_}X${H_tagDisaster}</TD>\n");
			} elsif($warFlag{"$aId,$id"}) {
				out("<TD align='center'>${HtagDisaster_}x${H_tagDisaster}</TD>\n");
			} else {
				out("<TD align='center'>-</TD>\n");
			}
		}
		my $AllyInfo;
		if($HallyNumber){
			my $aNo = random(100);
			$aNo *= 10;
			for ($i = 0; $i < $HallyNumber; $i++) {
				my $ally = $Hally[$i];
				my $member = $Hally[$i]->{'memberId'};
				my $flag = 1;
				foreach (@$member) {
					if($island->{'id'} == $_) {
						$flag = 0;
						last;
					}
				}
				next if($flag);
				my $allyId = $ally->{'id'};
				my $allyName = $ally->{'name'};
				$allyName =~ s/[승자!]//g;
				$AllyInfo.= "<A style=\"text-decoration:none\" href=\"$HthisFile?AmiOfAlly=${allyId}\"><FONT COLOR=\"$ally->{'color'}\"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}</A>&nbsp;&nbsp;";
			}
			out("<TD align='left'>$AllyInfo</TD>\n");
		}
		out("\n</TR>\n");
	}
	out(<<END);
</TABLE>
</DIV>
END
}

#----------------------------------------------------------------------
#아이템 획득 현황
#----------------------------------------------------------------------
sub ItemInfo() {
	# 화면 출력
	unlock();

	out(<<"END");
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='islandInfo'>
<H1>${HitemName[0]} 획득 현황</H1>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell colspan='2'>${HtagTH_}${HitemName[0]}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}보유 $AfterName 이름${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}총 획득 경험치${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}능력${H_tagTH} ★은키아이템</TH>
</TR>
END

	my($island, $name, $navyComLevel, $totalExp);
	my @sptext = ('<span class=check>[★]</span>', '<span class=check>[전체 섬 보급 가능]</span>', '<span class=check>[지형 차단/차폐 무효]</span>', '<span class=check>[보유 함정', '<span class=check>[사거리 UP ', '<span class=check>[명중률 UP ', '<span class=check>[명령 횟수 x',
					'<span class=check>[식량 Max x', '<span class=check>[자금 Max x', '<span class=check>[수확 x', '<span class=check>[수입 x', '<span class=check>[공격 횟수 x', '<span class=check>[파괴력 x', '<span class=check>[유지 식량 x', '<span class=check>[유지자금 x', '<span class=check>[식량소비 x', '<span class=check>[명령비용 x',
					'<span class=check>[지진 x', '<span class=check>[태풍 x', '<span class=check>[운석 x', '<span class=check>[거대운석 x', '<span class=check>[분화 x', '<span class=check>[화재 x', '<span class=check>[쓰나미 x',
					'<span class=check>[파괴력 '
					);
	my @sptextafter = ('', '', '', ']</span>', 'Hex]</span>', '%]</span>', ']</span>',
						']</span>', ']</span>', ']</span>', ']</span>', ']</span>', ']</span>', ']</span>', ']</span>', ']</span>', ']</span>',
						']</span>', ']</span>', ']</span>', ']</span>', ']</span>', ']</span>', ']</span>',
						']</span>'
					);
	my @pm = (' ', ' +');
	foreach (1..$#HitemName){
		my($i, $special);
		foreach $i (0..2) {
			$special.= $sptext[$i] if($HitemSpecial[$_][$i] != 0);
		}
		$special.= $sptext[3]. $pm[($HitemSpecial[$_][3]> 0)]. $HitemSpecial[$_][3]. $sptextafter[3] if($HitemSpecial[$_][3] != 0);
		foreach $i (4..5) {
			$special.= $sptext[$i]. $HitemSpecial[$_][$i]. $sptextafter[$i] if($HitemSpecial[$_][$i] != 0);
		}
		foreach $i (6..23) {
			$special.= $sptext[$i]. $HitemSpecial[$_][$i]. $sptextafter[$i] if($HitemSpecial[$_][$i] != 1);
		}
		$special.= $sptext[24]. (($HitemSpecial[$_][24]> 0) ? '+' : ''). $HitemSpecial[$_][24]. $sptextafter[24] if($HitemSpecial[$_][24] != 0);
		my @getId = keys %{$HitemGetId[$_]};
		my $ng = @getId;
		my($rspan);
		$rspan = " rowspan='$ng'" if($ng> 1);
		out(<<"END");
<TR $HbgInfoCell>
<TD align='right'${rspan}><img src='$HitemImage[$_]'></TD>
<TH${rspan}>$HitemName[$_]</TH>
END
		if(!$ng) {
			out(<<"END");
<TD $HbgNameCell align=left><DIV align='center'>-</DIV></TD>
<TD $HbgInfoCell align=right>-</TD>
<TD $HbgInfoCell align=left>$special</TD>
</TR>
END
		} else {
			my $c = 0;
			my $gId;
			foreach $gId (@getId) {
				my $n = $HidToNumber{$gId};
				if(defined $n) {
					$island = $Hislands[$n];
					$name = islandName($island);
					if($island->{'field'}) {
						$name = "${HtagNumber_}${name}${H_tagNumber}";
					} elsif($island->{'absent'} == 0) {
						$name = "${HtagName_}${name}${H_tagName}";
					} else {
						$name = "${HtagName2_}${name}($island->{'absent'})${H_tagName2}";
					}
					$name.= "${HtagDisaster_}★${H_tagDisaster}" if ($HislandTurn - $island->{'birthday'} <= $HdevelopTurn);
					if($island->{'predelete'}) {
						my $rest = ($island->{'predelete'} != 99999999) ? "<small>(남은$island->{'predelete'}턴)</small>" : '';
						$name = "${HtagDisaster_}[관리자 보관]$rest${H_tagDisaster}<BR>". $name;
					}
					$name = "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=$island->{'id'}\">${name}</A>";
					$navyComLevel = gainToLevel($island->{'gain'});
					$totalExp = $island->{'gain'};
					$totalExp.= "(Lv.${navyComLevel})" if($HmaxComNavyLevel);
				} else {
					$name = "<DIV align='center'>-</DIV>";
					$totalExp = '-';
				}
				out("<TR $HbgInfoCell>") if($c);
				out(<<"END");
<TD $HbgNameCell align=left>$name</TD>
<TD $HbgInfoCell align=right>$totalExp</TD>
END
				out("<TD class='N' align=left${rspan}>$special</TD>") if(!$c);
				out("</TR>");
				$c++;
			}
		}
	}
	out(<<"END");
</TABLE>
</DIV>
END
}

#----------------------------------------------------------------------
# 함정 보유 목록
#----------------------------------------------------------------------
sub fleetInfo {
	# 화면 출력
	unlock();
	my($col, $row);
	if(!$HinfoMode) {
		$col = 2; $row = (!$HnavySafetyZone || $HnavySafetyInvalidp) ? 3 : 2;
	} else {
		$col = 1; $row = 1;
	}
	my $title = ('전체 데이터', '보유 수', '격침 수', '자폭 수')[$HinfoMode];
	my $rowstr = ($HinfoMode < 2) ? ' rowspan=2' : '';
	out(<<"END");
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='islandInfo'>
<H1>함정 보유 목록</H1>
END
	out(qq|[<A href="$HthisFile?Fleet=0">전체 데이터</A>] |);
	out(qq|[<A href="$HthisFile?Fleet=1">보유 수</A>] |);
	out(qq|[<A href="$HthisFile?Fleet=2">격침 수</A>] |);
	out(qq|[<A href="$HthisFile?Fleet=3">자폭 수</A>] |) if(!$HnavySafetyZone || $HnavySafetyInvalidp);
	out(<<"END");
<TABLE BORDER>
<TR>
<TH colspan=$col>$title</TH>
END
	foreach (0..$#HnavyName) {
		out("<TD class='T'>${HtagTH_}$HnavyName[$_]${H_tagTH}<BR><img src=\"$HnavyImage[$_]\"></TD>");
	}
	out("<TD class='T'$rowstr>${HtagTH_}합계${H_tagTH}</TD>");
	out("<TD class='T'$rowstr>${HtagTH_}보유 함정<BR>유지비${H_tagTH}</TD>");
	out("<TD class='T'$rowstr>${HtagTH_}보유 함정<BR>유지 식량${H_tagTH}</TD>");
	out("</TR>");
	if($HinfoMode < 2) {
		out("<TR><TH colspan=$col>보유 가능 횟수</TH>");
		foreach (0..$#HnavyName) {
			if($HnavyKindMax[$_]) {
				out("<TH>$HnavyKindMax[$_]</TH>");
			} else {
				out("<TH>무제한</TH>");
			}
		}
		out("</TR>");
	}
	my($island, $id, $name, $fkind, $kind, @ids, $islands, $kindNavy, $money, $food);
	foreach ($HbfieldNumber..$islandNumber) {
		$island = $Hislands[$_];
		$island->{'totalnavy'} = 0;
		$island->{'upkeepMoney'} = 0;
		$island->{'upkeepFood'} = 0;
		$island->{'totalsink'} = 0;
		$island->{'totalsinkself'} = 0;
		foreach (0..$#HnavyName) {
			$kind = "navykind$_";
			$island->{$kind} = 0; # 보유 수의 초기화
			$kind = "sinkkind$_";
			$island->{$kind} = 0; # 격침 수의 초기화
			$island->{$kind} += $island->{'sink'}[$_] + $island->{'sinkself'}[$_]; # 격침 수
			$island->{'totalsink'} += $island->{$kind};
			$kind = "sinkself$_";
			$island->{$kind} = 0; # 자폭 수의 초기화
			$island->{$kind} += $island->{'sinkself'}[$_]; # 자폭 수
			$island->{'totalsinkself'} += $island->{$kind};
		}
		$fkind = $island->{'fkind'};
		foreach (@$fkind) {
			my($eId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack(hex($_));
			$kind = "navykind${nKind}";
			$island->{$kind}++; # 보유 수
			$island->{'upkeepMoney'} += $HnavyMoney[$nKind]; # 유지비
			$island->{'upkeepFood'} += $HnavyFood[$nKind]; # 유지 식량
			next if ($HnavySpecial[$nKind] & 0x8); # 군항은 합계에 포함하지 않음
			$island->{'totalnavy'}++;
		}
	}
	$islands = islandSort('totalnavy');
	$ids{'totalnavy'} = $islands->{'id'};
	$islands = islandSort('upkeepMoney');
	$ids{'upkeepMoney'} = $islands->{'id'};
	$islands = islandSort('upkeepFood');
	$ids{'upkeepFood'} = $islands->{'id'};
	$islands = islandSort('totalsink');
	$ids{'totalsink'} = $islands->{'id'};
	$islands = islandSort('totalsinkself');
	$ids{'totalsinkself'} = $islands->{'id'};
	foreach (0..$#HnavyName) {
		$kind = "navykind$_";
		$islands = islandSort($kind);
		$ids{$kind} = $islands->{'id'};
		$kind = "sinkkind$_";
		$islands = islandSort($kind);
		$ids{$kind} = $islands->{'id'};
		$kind = "sinkself$_";
		$islands = islandSort($kind);
		$ids{$kind} = $islands->{'id'};
	}
	foreach ($HbfieldNumber..$islandNumber) {
		$island = $Hislands[$_];
		$name = islandName($island);
		$id = $island->{'id'};

		out("<TR>\n<TH $HbgTitleCell rowspan=$row>$name</TH>\n");

		my $upkeepInfo = '';
		if($island->{'upkeepMoney'} < 0) {
			$money = "<span class='Money'>수입". - $island->{'upkeepMoney'}. "${HunitMoney}";
		} elsif($island->{'upkeepMoney'} == 0) {
			$money = '-';
		} else {
			$money = $island->{'upkeepMoney'}. "${HunitMoney}";
		}
		1 while $money =~ s/(.*\d)(\d\d\d)/$1,$2/;
		if($id == $ids{'upkeepMoney'}) {
			$upkeepInfo.= "<TD $HbgInfoCell rowspan=$row align=right>${HtagTH_}$money${H_tagTH}</TD>";
		} else {
			$upkeepInfo.= "<TD $HbgInfoCell rowspan=$row align=right>$money</TD>";
		}
		if($island->{'upkeepFood'} < 0) {
			$food = "<span class='Food'>수확". - $island->{'upkeepFood'}. "${HunitFood}";
		} elsif($island->{'upkeepFood'} == 0) {
			$food = '-';
		} else {
			$food = $island->{'upkeepFood'}. "${HunitFood}";
		}
		1 while $food =~ s/(.*\d)(\d\d\d)/$1,$2/;
		if($id == $ids{'upkeepFood'}) {
			$upkeepInfo.= "<TD $HbgInfoCell rowspan=$row align=right>${HtagTH_}$food${H_tagTH}</TD>";
		} else {
			$upkeepInfo.= "<TD $HbgInfoCell rowspan=$row align=right>$food</TD>";
		}

		out("<TH $HbgTitleCell>${HtagTH_}보유 수${H_tagTH}</TH>\n") if(!$HinfoMode);
		if(!$HinfoMode || $HinfoMode == 1) {
			foreach (0..$#HnavyName) {
				$kind = "navykind$_";
				$kindNavy = $island->{$kind}; # 보유 수
				$kindNavy.= ($HnavySpecial[$_] & 0x8) ? '항구' : '함';
				if($id == $ids{$kind}) {
					out("<TD $HbgInfoCell align=right>${HtagTH_}$kindNavy${H_tagTH}</TD>");
				} else {
					out("<TD $HbgInfoCell align=right>$kindNavy</TD>");
				}
			}
			if($id == $ids{'totalnavy'}) {
				out("<TD $HbgInfoCell align=right>${HtagTH_}$island->{'totalnavy'}함${H_tagTH}</TD>");
			} else {
				out("<TD $HbgInfoCell align=right>$island->{'totalnavy'}함</TD>");
			}
			out("$upkeepInfo");
			out("\n</TR><TR>\n") if(!$HinfoMode);
		}

		out("<TH $HbgTitleCell>${HtagTH_}격침 수${H_tagTH}</TH>\n") if(!$HinfoMode);;
		if(!$HinfoMode || $HinfoMode == 2) {
			foreach (0..$#HnavyName) {
				$kind = "sinkkind$_";
				$kindNavy = $island->{$kind}; # 격침 수
				$kindNavy.= ($HnavySpecial[$_] & 0x8) ? '항구' : '함';
				if($id == $ids{$kind}) {
					out("<TD $HbgInfoCell align=right>${HtagTH_}$kindNavy${H_tagTH}</TD>");
				} else {
					out("<TD $HbgInfoCell align=right>$kindNavy</TD>");
				}
			}
			if($id == $ids{'totalsink'}) {
				out("<TD $HbgInfoCell align=right>${HtagTH_}$island->{'totalsink'}함${H_tagTH}</TD>");
			} else {
				out("<TD $HbgInfoCell align=right>$island->{'totalsink'}함</TD>");
			}
			out("$upkeepInfo") if($HinfoMode == 2);
			out("\n</TR><TR>\n") if(!$HinfoMode);
		}

		if((!$HnavySafetyZone || $HnavySafetyInvalidp) && (!$HinfoMode || $HinfoMode == 3)) {
			out("<TH $HbgTitleCell>${HtagTH_}자폭 수${H_tagTH}</TH>\n") if(!$HinfoMode);
			foreach (0..$#HnavyName) {
				$kind = "sinkself$_";
				$kindNavy = $island->{$kind}; # 자폭 수
				$kindNavy.= ($HnavySpecial[$_] & 0x8) ? '항구' : '함';
				if($id == $ids{$kind}) {
					out("<TD $HbgInfoCell align=right>${HtagTH_}$kindNavy${H_tagTH}</TD>");
				} else {
					out("<TD $HbgInfoCell align=right>$kindNavy</TD>");
				}
			}
			if($id == $ids{'totalsinkself'}) {
				out("<TD $HbgInfoCell align=right>${HtagTH_}$island->{'totalsinkself'}함${H_tagTH}</TD>");
			} else {
				out("<TD $HbgInfoCell align=right>$island->{'totalsinkself'}함</TD>");
			}
			out("$upkeepInfo") if($HinfoMode == 3);
		}
	}
	out(<<END);
</TR></TABLE></DIV>
END

}

#------------------------------------------------
# 토너먼트 모드
#------------------------------------------------
# 대전갱신 시간
sub TimeTableMain {
	my $tournament = "";
	my $sec = ($HyosenTime % 60);
	$sec = ($sec ? "$sec 초" : '');
	my $min = ($HyosenTime % 3600);
	$min = ($min ? "$min 분" : '');
	my $hour = int($HyosenTime / 3600);
	$hour = ($hour ? "$hour시간" : '');
	my $yosenTime = "$hour$min$sec";
	$sec = ($HdevelopeTime % 60);
	$sec = ($sec ? "$sec 초" : '');
	$min = ($HdevelopeTime % 3600);
	$min = ($min ? "$min 분" : '');
	$hour = int($HdevelopeTime / 3600);
	$hour = ($hour ? "$hour시간" : '');
	my $developeTime = "$hour$min$sec";
	$sec = ($HinterTime % 60);
	$sec = ($sec ? "$sec 초" : '');
	$min = ($HinterTime % 3600);
	$min = ($min ? "$min 분" : '');
	$hour = int($HinterTime / 3600);
	$hour = ($hour ? "$hour시간" : '');
	my $interTime = "$hour$min$sec";
	$sec = ($HfightTime % 60);
	$sec = ($sec ? "$sec 초" : '');
	$min = ($HfightTime % 3600);
	$min = ($min ? "$min 분" : '');
	$hour = int($HfightTime / 3600);
	$hour = ($hour ? "$hour시간" : '');
	my $fightTime = "$hour$min$sec";


	# 토너먼트 턴 갱신 시간표 빠른 보기
	out(<<"END");
<STYLE type="text/css">
<!--
#list { display:none; }
-->
</STYLE>
<SCRIPT LANGUAGE="JavaScript">
<!--
function textcopy(mapdata){
	window.clipboardData.setData("text",mapdata);
}
function searchID(url){
	if(document.getElementById){
		return document.getElementById(url);
	} else if(document.all){
		return document.all(url);
	} else if(document.layers){
		return document.layers[url];
	}
}
//-->
</SCRIPT>
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='FightLog'>
<H1>대전타이무테이블</H1>
END
	my $round = $HislandFightCount;
	my $flag = 0;
	my $pNumber = @HpreDeleteID;
	my $iNumber = $HislandNumber - $pNumber - $HbfieldNumber;
	if($round && $iNumber> $Htournament) {
		$iNumber = $Htournament;
	}
	my $fturn = 0;
	my $nofight = 0;
	if($HislandFightMode == 1) {
		$fturn = $HislandChangeTurn - $HyosenTurn - $HdevelopeTurn;
	} elsif($HislandFightMode == 2) {
		$HfightTurn = $HfinalTurn if($iNumber <= 2);
		$fturn = $HislandChangeTurn - $HyosenTurn - $HdevelopeTurn - $HfightTurn;
		foreach ($HbfieldNumber..$islandNumber) {
			$nofight++ if($Hislands[$_]->{'fight_id'} < 0);
		}
	}
	$tournament.= "턴\t$AfterName 수\t진행상태\t갱신 시간\n";
	my $end = 0;
	if($iNumber> 1) {
		out("<TABLE BORDER=0><TR $HbgTitleCell><TH colspan=2>${HtagTH_}종류별${H_tagTH}</TH><TH>${HtagTH_}남은 섬${H_tagTH}</TH><TH colspan=2>${HtagTH_}턴${H_tagTH}</TH><TH>${HtagTH_}기간${H_tagTH}</TH><TH>${HtagTH_}부전승 시<BR>개발 정지<BR>턴 수${H_tagTH}</TH></TR>");
	} else {
		$end =1;
	}
	while($iNumber> 1){
		if($HislandTurn < $HyosenTurn) {
			# 예선
			$HislandFightMode = 0;
			$HislandLastTime += ($HflexTimeSet) ? 3600 * $HtmTime1[($HislandTurn % ($#HtmTime1 + 1))] : $HyosenTime;
			$timeString = timeToString($HislandLastTime);
			foreach(1..$HyosenRepCount){
				$HislandTurn++;
				$tournament.= "$HislandTurn\t$iNumber\t예선\t$timeString\n";
				if(!$flag) {
					$flag = 1;
					out("<TR class='InfoCellT'><TH colspan=2><span class='lbbsOW'>예선</span></TH><TD align='right'>$iNumber$AfterName</TD><TD align='right'><B>$yosenTime</B>마다 1회 <B>$HyosenRepCount 턴 갱신</B>, <B>전체 $HyosenTurn 턴</B></TD><TD align='right'>~$HyosenTurn</TD>");
					out("<TD>${timeString}~");
				}
				last if($HislandTurn == $HyosenTurn);
			}
			if($HislandTurn == $HyosenTurn) {
				out("${HtagTH_}${timeString}${H_tagTH}</TD><TD align='center'>-</TD></TR>");
				$flag = 0;
			}
		} elsif($HislandTurn < $HyosenTurn + $HdevelopeTurn + $fturn) {
			# 개발
			$iNumber = $Htournament if(($HislandFightMode == 0) && ($iNumber> $Htournament));
			$HislandFightMode = 1;
			$HislandLastTime += ($HflexTimeSet) ? 3600 * $HtmTime2[($HislandTurn % ($#HtmTime2 + 1))] : $HdevelopeTime;
			$timeString = timeToString($HislandLastTime);
			$HfightTurn = $HfinalTurn if($iNumber <= 2);
			foreach(1..$HdeveRepCount){
				$HislandTurn++;
				$tournament.= "$HislandTurn\t$iNumber\t개발\t$timeString\n";
				if(!$flag) {
					$round++;
					$flag = 1;
					my $endturn = $HyosenTurn + $HdevelopeTurn + $fturn;
					if($iNumber + $nofight <= 2) {
						out("<TR $HbgInfoCell><TH>결 승</TH>");
					} elsif($iNumber + $nofight <= 4) {
						out("<TR $HbgInfoCell><TH>준결승</TH>");
					} else {
						out("<TR $HbgInfoCell><TH>제${round}회전</TH>");
					}
					out("<TD><span class='lbbsSS'>개발 기간</span></TD><TD align='right'>$iNumber$AfterName</TD><TD align='right'><B>$developeTime</B>마다 1회 <B>$HdeveRepCount 턴 갱신</B>, <B>전체 $HdevelopeTurn 턴</B></TD><TD align='right'>$HislandTurn~$endturn</TD>");
					out("<TD>${timeString}~");
				}
				last if($HislandTurn == $HyosenTurn + $HdevelopeTurn + $fturn);
			}
			if($HislandTurn == $HyosenTurn + $HdevelopeTurn + $fturn) {
				out("<B>${timeString}</B></TD><TD align='center'>-</TD></TR>");
				$flag = 0;
			}
		}elsif($HislandTurn < $HyosenTurn + $HdevelopeTurn + $HfightTurn + $fturn){
			# 전투
			$HislandFightMode = 2;
			$HislandLastTime += ($HflexTimeSet) ? 3600 * $HtmTime3[($HislandTurn % ($#HtmTime3 + 1))] : $HfightTime;
			$timeString = timeToString($HislandLastTime);
			#$tournament.= "$HislandTurn\t$iNumber\t전투♪\t$timeString\t$HfightRepCount\n";
			foreach(1..$HfightRepCount){
				$HislandTurn++;
				$tournament.= "$HislandTurn\t$iNumber\t전투♪\t$timeString\n";
				if(!$flag) {
					$flag = 1;
					my $endturn = $HyosenTurn + $HdevelopeTurn + $HfightTurn + $fturn;
					if($iNumber + $nofight <= 2) {
						out("<TR class='InfoCellT'><TH>결 승</TH>");
					} elsif($iNumber + $nofight <= 4) {
						out("<TR class='InfoCellT'><TH>준결승</TH>");
					} else {
						out("<TR class='InfoCellT'><TH>제${round}회전</TH>");
					}
					out("<TD><span class='lbbsOW'>전투 기간</span></TD><TD align='right'>$iNumber$AfterName</TD><TD align='right'><B>$fightTime</B>마다 1회 <B>$HfightRepCount 턴 갱신</B>, <B>전체 $HfightTurn 턴</B></TD><TD align='right'>$HislandTurn~$endturn</TD>");
					out("<TD>${timeString}~");
				}
				last if($HislandTurn == $HyosenTurn + $HdevelopeTurn + $HfightTurn + $fturn);
			}
			if($HislandTurn == $HyosenTurn + $HdevelopeTurn + $HfightTurn + $fturn) {
				my $nofight = $round * $HnofightUp + $HnofightTurn. "턴";
				$nofight = '-' if($iNumber <= 2);
				out("${HtagTH_}${timeString}${H_tagTH}</TD><TD align='center'>$nofight</TD></TR>");
				$flag = 0;
			}
		} else {
			$HislandLastTime += ($HflexTimeSet) ? 3600 * $HtmTime2[($HislandTurn % ($#HtmTime2 + 1))] : ($HislandTurn == $HyosenTurn + $HdevelopeTurn + $HfightTurn + $fturn) ? $HinterTime : $HdevelopeTime;
			if($HislandFightMode == 2) {
				$iNumber = int(($iNumber + $nofight) / 2 + 0.5);
				$iNumber++ if(($iNumber> 2) && (($iNumber % 2) != 0) && ($HconsolationMatch));
				$nofight = 0;
			}
			$HislandFightMode = 1;
			$timeString = timeToString($HislandLastTime);
			$fturn += $HdevelopeTurn + $HfightTurn;
			last if(!$fturn); # 무한루프회피
			$HfightTurn = $HfinalTurn if($iNumber <= 2);
			if($iNumber> 1) {
				foreach(1..$HdeveRepCount){
					$HislandTurn++;
					$tournament.= "$HislandTurn\t$iNumber\t개발\t$timeString\n";
					if(!$flag) {
						$round++;
						$flag = 1;
						my $endturn = $HyosenTurn + $HdevelopeTurn + $fturn;
						if($iNumber + $nofight <= 2) {
							out("<TR $HbgInfoCell><TH>결 승</TH>");
						} elsif($iNumber + $nofight <= 4) {
							out("<TR $HbgInfoCell><TH>준결승</TH>");
						} else {
							out("<TR $HbgInfoCell><TH>제${round}회전</TH>");
						}
						out("<TD><span class='lbbsSS'>개발 기간</span></TD><TD align='right'>$iNumber$AfterName</TD><TD align='right'><B>$developeTime</B>마다 1회 <B>$HdeveRepCount 턴 갱신</B>, <B>전체 $HdevelopeTurn 턴</B></TD><TD align='right'>$HislandTurn~$endturn</TD>");
						out("<TD>${timeString}~");
					}
					last if($HislandTurn == $HyosenTurn + $HdevelopeTurn + $fturn);
				}
				if($HislandTurn == $HyosenTurn + $HdevelopeTurn + $fturn) {
					out("<B>${timeString}</B></TD><TD align='center'>-</TD></TR>");
					$flag = 0;
				}
			}
		}
	}
	unlock();

	if(!$end) {
		out("</TABLE><BR>");
		my $con = ('', '참고: 전투 종료 후 남은 수(부전승이 발생할 예정 없음)인 경우 패배한 섬 중 최상위 섬을 <B>패자부활</B> 처리합니다.<BR>')[$HconsolationMatch];
		my $halffight = int($HfightTurn/2);
		my $halffinal = int($HfinalTurn/2);

		out(<<END);
<blockquote>
참고: 자금 조달 횟수가<B>$HstopAddPop 회</B>이 되면 인구 증가가 중단됩니다.<BR>
 또한예선에서는, 실업자 수가<B>$Hno_work$HunitPop</B>을 초과 해서도, 인구 증가가 중단합니다<BR>
참고: 대전 상대가 없는 경우, 또는 개발 기간 안에'상대가 없는 경우'는<B>부전승 처리</B>으로 됩니다.<BR>
 부전승의 경우,<B>(라운드 수×${HnofightUp}+${HnofightTurn})턴</B>의 개발 정지가 됩니다.<BR>
참고: 전투 기간의 절반($halffight 턴·결승은$halffinal 턴)이 경과할 시까지,'상대가 없는 경우'및<BR>
 '상대의<B>전투 행위 횟수가$do_fight 회에 미달했습니다</B>(또는,<B>상대가 한 번도 함대를 파견하지 않았습니다</B>)경우'는<B>부전승 처리</B>으로 됩니다.<BR>
 이 경우, 전투 시작 시의 섬의 상태로 복구되고, 개발 정지가 됩니다. 정지 기간은,<B>(라운드 수×${HnofightUp}+${HnofightTurn})- 경과 턴 수</B>입니다.<BR>
$con
</blockquote></DIV>
END
	} else {
		out("게임이 종료되었습니다.");
	}
#	out(<<END);
#<DIV id='hyo'><INPUT TYPE="button" VALUE="토너먼트 갱신 시간표 빠른 보기를 클립보드에 복사" onClick="textcopy(searchID('ALIST').value);"></DIV>
#<DIV id='list'><textarea NAME="ALIST" cols="100" rows="0">$tournament</textarea></DIV>
#END
}

# 대전 기록
sub FightViewMain {

	my %rankKind = (
		'pop' => '인구',
		'gain' => '총 획득 경험치',
		'money' => '자금',
		'food' => '식량',
		'area' => '면적',
		'farm' => '농장 규모',
		'factory' => '공장 규모',
		'mountain' => '채굴장 규모',
		'monsterkill' => '괴수 퇴치 수',
		'itemNumber' => "$HitemName[0] 획득 수",
		'point' => "$HpointName",
	);
	my %rankAfter = (
		'pop' => "$HunitPop",
		'gain' => '',
		'money' => "$HunitMoney",
		'food' => "$HunitFood",
		'area' => "$HunitArea",
		'farm' => "0$HunitPop",
		'factory' => "0$HunitPop",
		'mountain' => "0$HunitPop",
		'monsterkill' => "$HunitMonster",
		'itemNumber' => '',
		'point' => "$HpointAfter",
	);

	TimeTableMain() if($HplayNow && $Htournament);
	if(!open(IN, "${HfightdirName}/${Hfightlog}")){
		unlock();
#		out ("${HtagBig_}데이터 없습니다!${H_tagBig}$HtempBack\n");
		return;
	}
	my @lines = <IN>;
	close(IN);
	unlock();

#	out ("${HtagTitle_}대전 기록${H_tagTitle}<BR><DIV ALIGN=right>*패자의 섬  이름을 클릭하면 패전 당시의 상황을 볼 수 있습니다</DIV>\n");
#	out ("<DIV align='center'>$HtempBack</DIV><BR>\n");
	out("<HR>") if($HplayNow && $Htournament);
	out(<<END);
<DIV ID='FightLog'>
<H1>대전 기록</H1>
*패자의${AfterName} 이름을 클릭하면 패전 당시의 상황을 볼 수 있습니다.
END

	my $lineflag = 0;
	chomp(@lines);
	foreach $line (@lines) {
		if($line =~ /<[0-9]*>/) {
			$line =~ s/<|>//g;
			$lineflag = $line;
			my $msg = (!$line) ? "예선 탈락" : ($line == 99) ? "결승전" : $line."회전";
			out("</TABLE>\n") if($line < 99);
			out("<HR><DIV ID='fightlogS'><H1>${HtagHeader_}$msg${H_tagHeader}</H1></DIV>");
			# 테이블헤더
			if($lineflag == 0) {
				out(<<END);
<TABLE BORDER>
<TR>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}${AfterName}${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}$rankKind{$HrankKind}${H_tagTH}</NOBR></TH></TR>
END

			} else {

				my $mStr1;
				if($HuseBase || $HuseSbase) {
					$mStr1 = "<TH $HbgTitleCell>${HtagTH_}미격${H_tagTH}</TH>";
				}
				my $col = ($HuseBase || $HuseSbase) ? 10 : 9;
				out(<<END);
<TABLE BORDER>
<TR><TH colspan=3></TH><TH $HbgTitleCell colspan=$col>${HtagTH_}승자${H_tagTH}</TH><TH colspan=1></TH>
<TH $HbgTitleCell colspan=$col>${HtagTH_}패자${H_tagTH}</TH></TR>
<TR>
<TH $HbgTitleCell>${HtagTH_}승자${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}패자${H_tagTH}</TH>
<TH $HbgTitleCell width=15> </TH>
<TH $HbgTitleCell>${HtagTH_}$rankKind{$HrankKind}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}방어격${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell>${HtagTH_}민구조${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}탄비${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}탄발${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}탄 방어${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}함파${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}함정 피격${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}함정 파괴${H_tagTH}</TH>
<TH $HbgTitleCell width=15> </TH>
<TH $HbgTitleCell>${HtagTH_}$rankKind{$HrankKind}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}방어격${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell>${HtagTH_}민구조${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}탄비${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}탄발${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}탄 방어${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}함파${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}함정 피격${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}함정 파괴${H_tagTH}</TH>
</tr>
END

			}

		} elsif($lineflag == 0) {
			# 예선결과
			my($count, $id, $name, $score, $data, $tId, $tName, $tScore, $tData, $reward) = split(/\,/,$line);
			if(-e "${HfightdirName}/${id}_lose.${HsubData}") {
				$name = "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?LoseMap=${id}\">${HtagName2_}$name${H_tagName2}</A>";
			} else {
				$name = "${HtagName2_}$name${H_tagName2}";
			}
			out(<<END);
<TR><TD $HbgInfoCell align=right>${HtagName_}${name}${H_tagName}</TD>
<TD $HbgInfoCell align=center><B>${score}$rankAfter{$HrankKind}</B></TD></TR>
END

		} else {
			# 토너먼트결과
			my($count, $id, $name, $score, $data, $tId, $tName, $tScore, $tData, $reward) = split(/\,/,$line);
			my(@subExt) = split(/-/,$data);
			my(@tSubExt) = split(/-/,$tData);
#			$tName = "<A STYlE=\"text-decoration:none\" HREF=\"".$HthisFile."?LoseMap=".$id."\">".
#						$HtagName2_.$tName.$H_tagName2."</A>";
			$tPop.= ${HunitPop};
			$score.= $rankAfter{$HrankKind};
			if($tId == -1) {
				$tName = "${HtagName2_}- 부전승 -${H_tagName2}";
				$tScore = "-";
			} elsif($tId == -2) {
				$tName = "${HtagName2_}- 압승! -${H_tagName2}";
				$tScore = "-";
			} else {
				if(-e "${HfightdirName}/${tId}_lose.${HsubData}") {
					$tName = "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?LoseMap=${tId}\">${HtagName2_}$tName${H_tagName2}</A>";
				} else {
					$tName = "${HtagName2_}$tName${H_tagName2}";
				}
				$tScore.= $rankAfter{$HrankKind};
			}
			if($tId != -9) {
				my(@after) = ('', '', '기준', '기준', "$HunitPop", '발', '발', '발', '함', '함', '함');
				foreach (2..$#subExt){
					$subExt[$_] = $subExt[$_] ? "${subExt[$_]}${after[$_]}" : '없음';
					$tSubExt[$_] = ($tScore == '-') ? '-' : ($tSubExt[$_] ? "${tSubExt[$_]}${after[$_]}" : '없음');
				}
				my($mStr1, $mStr2) = ('', '');
				if($HuseBase || $HuseSbase) {
					$mStr1 = "<TD $HbgInfoCell align=center>$subExt[3]</TD>";
					$mStr2 = "<TD $HbgInfoCell align=center>$tSubExt[3]</TD>";
				}
				out(<<END);
<TR><TD $HbgInfoCell align=right>${HtagName_}${name}${H_tagName}</TD>
<TD $HbgInfoCell align=center>${tName}</TD>
<TD $HbgInfoCell> </TD>
<TH $HbgInfoCell>${score}</TH>
<TD $HbgInfoCell align=center>$subExt[2]</TD>
$mStr1
<TD $HbgInfoCell align=center>$subExt[4]</TD>
<TD $HbgInfoCell align=center>$subExt[5]</TD>
<TD $HbgInfoCell align=center>$subExt[6]</TD>
<TD $HbgInfoCell align=center>$subExt[7]</TD>
<TD $HbgInfoCell align=center>$subExt[8]</TD>
<TD $HbgInfoCell align=center>$subExt[9]</TD>
<TD $HbgInfoCell align=center>$subExt[10]</TD>
<TD $HbgInfoCell> </TD>
<TH $HbgInfoCell>${tScore}</TH>
<TD $HbgInfoCell align=center>$tSubExt[2]</TD>
$mStr2
<TD $HbgInfoCell align=center>$tSubExt[4]</TD>
<TD $HbgInfoCell align=center>$tSubExt[5]</TD>
<TD $HbgInfoCell align=center>$tSubExt[6]</TD>
<TD $HbgInfoCell align=center>$tSubExt[7]</TD>
<TD $HbgInfoCell align=center>$tSubExt[8]</TD>
<TD $HbgInfoCell align=center>$tSubExt[9]</TD>
<TD $HbgInfoCell align=center>$tSubExt[10]</TD>
</TR>
END
			} else {
				out("<TR><TD class='M' colspan=6 align=right>${HtagName_}${name}${H_tagName},<B>패자부활!</B></TD></TR>\n");
			}
		}

	}
	out("</TABLE>\n") if(@lines != ());
	out("</DIV>\n");

}

#----------------------------------------------------------------------
# 초기 설정 확인
#----------------------------------------------------------------------
sub setupValue{
	my $mode = 1;
	my $admin;

	if(checkSpecialPassword($HdefaultPassword)) {
		$admin = 1 ;
		$mode = 0;
	}
	if($mode) {
		if(-e "${HefileDir}/setup.html") {
			out("<meta HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=${efileDir}/setup.html\">");
		}
	}

	my($src);

	unlock();

	my $unitTime = ($HarmisticeTurn || $HsurvivalTurn) ? $HarmTime : $HunitTime;
	my $sec = ($unitTime % 60);
	$sec = ($sec ? "$sec 초" : '');
	my $min = ($unitTime % 3600);
	$min = ($min ? "$min 분" : '');
	my $hour = int($unitTime / 3600);
	$hour = ($hour ? "$hour시간" : '');

	my $repeatTurn = ($HarmisticeTurn || $HsurvivalTurn) ? $HarmRepeatTurn : $HrepeatTurn;

	my @switchStr = ('OFF', 'ON');
	my $jsLocalImg1 = '';
	my $jsLocalImg2 = '';

	$jsLocalImg1 =<<"END";
<script language="JavaScript">
<!--
ckary = new Array();
gifhref = '';
skinhref = '';

function getck(){
	ckary = document.cookie;
	ckstr = "";

	i = 0;
	while (ckary[i]){
		num = ckary[i].indexOf("KAISEN_JS=");
		if (num != -1){
			cookp = ckary[i].split("=");
			cook = cookp[1].split("<>");
			gifhref = cook[8];
			skinhref = cook[9];
			break;
		}
		i++;
	}
}
getck();
if (skinhref == '') {
	skinhref = '${HcssDir}/${HcssDefault}';
}
//if (gifhref == '') {
//	gifhref = '$HimageDir';
//}
//document.write('<BASE HREF="' + gifhref + '/">\\n');
document.write('<link rel="stylesheet" type="text/css" href="' + skinhref + '">\\n');
// -->
</script>
END

	$src = <<"END" if($mode);
<HTML>
<HEAD>
<META http-equiv="Content-Style-Type" content="text/css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$HtitleTag
</TITLE>
$jsLocalImg1
</HEAD>
$Body
<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
$Hheader
</DIV>
<HR>
END

	$src.= <<"END";
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='setupValue'>
<a name='top'><H1> 설정 목록</H1></a>
END

$src.= "<a href='#admin' style='text-decoration=none'>관재설정</a> / ";
$src.= "<a href='#basic' style='text-decoration=none'>기본 설정</a> / ";
$src.= "<a href='#ocean' style='text-decoration=none'>해역 모드</a> / ";
$src.= "<a href='#autokeep' style='text-decoration=none'>무인(사멸)회피</a> / ";
$src.= "<a href='#survival' style='text-decoration=none'>서바이벌</a> / ";
$src.= "<a href='#imperial' style='text-decoration=none'>진영전쟁(제국국 바다전쟁)</a> / ";
$src.= "<a href='#tournament' style='text-decoration=none'>토너먼트</a> / ";
$src.= "<a href='#amity' style='text-decoration=none'>우호국 설정</a> / ";
$src.= "<a href='#ally' style='text-decoration=none'>동맹시스템</a> / ";
$src.= "<a href='#dewar' style='text-decoration=none'>선전포고시스템</a> / ";
$src.= "<a href='#event' style='text-decoration=none'>이벤트시스템</a>";
$src.= "<BR>";
$src.= "<a href='#usecom' style='text-decoration=none'>지형·명령 설정</a> / ";
$src.= "<a href='#town' style='text-decoration=none'>도시계 설정</a> / ";
$src.= "<a href='#complex' style='text-decoration=none'>복합 지형</a> / ";
$src.= "<a href='#core' style='text-decoration=none'>코어</a> / ";
$src.= "<a href='#navy' style='text-decoration=none'>해군</a> / ";
$src.= "<a href='#def' style='text-decoration=none'>방위 시설</a> / ";
$src.= "<a href='#base' style='text-decoration=none'>기지·미사일</a> / ";
$src.= "<a href='#weather' style='text-decoration=none'>날씨</a> / ";
$src.= "<a href='#disaster' style='text-decoration=none'>재해</a> / ";
$src.= "<a href='#monster' style='text-decoration=none'>괴수</a> / ";
$src.= "<a href='#hmonster' style='text-decoration=none'>거대괴수</a> / ";
$src.= "<a href='#item' style='text-decoration=none'>아이템</a> / ";
$src.= "<a href='#monument' style='text-decoration=none'>기념비</a> / ";
$src.= "<a href='#prize' style='text-decoration=none'>턴 보너스·수상</a> / ";
$src.= "<a href='#command' style='text-decoration=none'> 명령 목록</a>";

	my @adminStr = ('관리자 외에도 탐색하게 함', '관리자만 탐색하게 함(메일 또는 게시판 등으로 등록을 의뢰해 주세요)');
	my @doStr = ('하지 않음', '하다');
	my %rankKind = (
		'pop' => '인구',
		'gain' => '총 획득 경험치',
		'money' => '자금',
		'food' => '식량',
		'area' => '면적',
		'farm' => '농장',
		'factory' => '공장',
		'mountain' => '채굴장',
		'monsterkill' => '괴수 퇴치 수',
		'itemNumber' => "$HitemName[0] 획득 수",
		'point' => "$HpointName",
	);
	my @useStr = ('사용하지 않음', '사용');
	my @useableStr = ('사용 불가', '사용 가능');
	my @seeStr = ('보이지 않음', '표시 가능', '100의 위에서 반올림');
	my @pointStr = ('하지 않음', '좌표있음', '좌표없음');
	my @axesStr = ('와 라없음', '개발 화면에 들어갈 시 오류가 발생한 경우', '개발 화면에 들어갈 시', '메인 페이지에 접속했을 시', '개발 화면에 들어갈 시 + 메인 페이지에 접속했을 시');
	my $topAxes = ($HtopAxes> 4) ? 4 : $HtopAxes;
	my @selectStr = (
		"$AfterName 수가 가장 적고, 순위가 최하위의 진영",
		"무작위(\"합계의$AfterName 수/진영의 수\"를 초과하지 않음)",
		"선택 가능(\"합계의$AfterName 수/진영의 수\"를 초과하지 않음)"
	);
	my @anStr = ('없음', '있음');
	my @selfStr = ('받음', '받지 않음', '우호국도 받지 않음');
	my $useDeWar = ('', "<BR>참고: 공격 제한은 없습니다. '선전포고' 없이 공격할 수 있습니다.", "<BR>참고: '선전포고'하지 않은 $AfterName에 대한 공격은 허가되지 않습니다. '선전포고' 직후에서 공격할 수 있습니다.", "<BR>참고: '선전포고'하지 않은 $AfterName에 대한 공격은 허가되지 않습니다. 유예 턴 종료 후 전쟁 중에만 공격할 수 있습니다.")[$HuseDeWar];
	my @hide = ('표시 가능', '숨기기');
	my @ox = ('○', '-');
	my @turnStr = ($HtagComName2_, $HtagComName1_);
	my @saftyStr = ('하지 않음', '하다', '우호국도 무해화');
	my @nodefStr = ('하지 않음', "자기 $AfterName 공격만 착탄", "나를 우호국으로 설정한 $AfterName 공격도 착탄", "내가 우호국으로 설정한 $AfterName 공격도 착탄", "내가 우호국으로 설정한$AfterName 공격도, 나를 우호국으로 설정한 $AfterName 공격도 착탄");
	my @nearfar = ('가장 <B>가까운</B> 지형부터 순서대로 목표 탐색', '가장 <B>먼</B> 지형부터 순서대로 목표 탐색', '사거리 안에서 <B>무작위</B>로 목표 탐색');

# 관리용 데이터
#------------------

	$src.= <<"END";
<HR>
<a name='admin'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 관재설정</H3></a>
END

	if($admin) {
		$src.= <<"END";
관리자 이름 <B>$HadminName</B><BR>
관리자의 메일 주소 <B><a href=\"mailto:$Hemail\">$Hemail</a></B><BR>
게시판 주소 <B><a href=\"$Hbbs\">$Hbbs</a></B><BR>
홈페이지 주소 <B><a href=\"$Htoppage\">$Htoppage</a></B><BR>
이미지 경로 설정의 설명페이지 <B><a href=\"$imageExp\">$imageExp</a></B><BR>
로컬 설정용이미지압축 파일 <B><a href=\"$localImg\">$localImg</a></B><BR>
END

		$src.= <<"END";
<BR>
디버그 모드 <B>$switchStr[$Hdebug]</B><BR>
설치폴더 <B>$HbaseDir</B><BR>
이미지폴더 <B>$HimageDir</B><BR>
CSS,JS 폴더 <B>$efileDir</B><BR>
GMT 에 대한 JST 의 시차 <B>${Hjst}초</B><BR>
gzip을 사용해 압축 전송할까요? <B>$doStr[$Hgzip]</B><BR>
gzip 설치 경로 <B>$HpathGzip</B><BR>
<BR>
실시간 사용 <B>$useStr[$Hrealtimer]</B><BR>
메인 페이지의 레이아웃을 tempTop.html에서 지정할지 <B>$doStr[$HlayoutTop]</B><BR>
메인 페이지에 표시하다${AfterName}의 수 <B>$HviewIslandCount</B><BR>
로그 파일 유지 턴 수 <B>$HlogMax 턴</B><BR>
'최근 사건'에 표시할 로그의 턴 수 <B>$HtopLogTurn 턴</B><BR>
'최근 사건'을 HTML로 만들지 여부 <B>$doStr[$HhtmlLogMake]</B><BR>
END

		$src.= <<"END" if($HhtmlLogMake);
'최근 사건'에 표시할 로그의 턴 수(HTML) <B>$HhtmlLogTurn 턴</B><BR>
메인 페이지의 '최근 사건'을 HTML에 링크할지 <B>$doStr[$HhtmlLogMode]</B><BR>
END

		$src.= <<"END";
<BR>
개발 화면에서 팝업 내비게이션을 표시할지 <B>$doStr[$HpopupNavi]</B><BR>
자$AfterName(개발 화면)의'최근 소식'을 history.cgi 에서 표시할지 <B>$doStr[$HuseHistory1]</B><BR>
타$AfterName(관광 화면 등)의'최근 소식'을 history.cgi 에서 표시할지 <B>$doStr[$HuseHistory2]</B><BR>
백업을 몇 턴오키에취는 가 <B>$HbackupTurn 턴</B><BR>
백업을 몇 회분 남음습니까 <B>$HbackupTimes 회분</B><BR>
발견 로그 유지 줄 수 <B>$HhistoryMax 줄</B><BR>
로컬 게시판 사용 <B>$useStr[$HuseLbbs]</B><BR>
외부 간이 게시판을 사용할지 <B>$useStr[$HuseExlbbs]</B><BR>
END

		if($HuseExlbbs) {
			$src.= "외부 간이 게시판의 주소 <B><A href='$HlbbsDir/view.cgi?admin=$HviewPass'>$HlbbsDir</A></B><BR>";
		}

		$src.= <<"END";
<BR>
착탄 지점을 지도에 표시할까요? <B>$doStr[$HmlogMap]</B><BR>
다른 사람에게자금이 보이지 않게 할까요? <B>$seeStr[$HhideMoneyMode]</B><BR>
개간 로그의 정리메에좌표도출력할까요? <B>$pointStr[$HoutPoint]</B><BR>
각$AfterName의 수입·지출 로그(기밀)을 출력할까요? <B>$doStr[$HbalanceLog]</B><BR>
JavaScript 의 일부를 외부 파일화할까요? <B>$doStr[$HextraJs]</B><BR>
플레이어의 비밀번호를 암호화함까요? <B>$doStr[$cryptOn]</B><BR>
<BR>
비밀번호 오류 화면에 경고문을 표시할까요? <B>$doStr[$HpassError]</B><BR>
접속 로그를 남길지? <B>$axesStr[$topAxes]</B><BR>
최대 기록 건수 <B>$HaxesMax 건</B><BR>
부하를 측정할까요? <B>$doStr[$Hperformance]</B><BR>
<BR>
END
	}

	$src.= <<"END";
새 ${AfterName}은 <B>$adminStr[$HadminJoinOnly]</B><BR>
END
	if($HuseLbbs) {
	}

	$src.= <<"END";
<BR>
COOKIE를 이용한 ID 확인을 할까요? <B>$doStr[$checkID]</B><BR>
COOKIE를 이용해 '이미지 경로 설정'도 확인할까요? <B>$doStr[$checkImg]</B><BR>
END
	my @freepassName;
	my $i;
	if($freepass[0] eq '') {
		@freepassName = ('없음') ;
	} else {
		foreach $i (@freepass) {
			next unless(defined $HidToNumber{$i});
			push(@freepassName, "$HidToName{$i}${AfterName}");
		}
	}
	$src.= "COOKIE 확인(위 2개 설정)을 면제하다$AfterName의 ID <B>@freepassName</B><BR>" if($checkId || $checkImg);

	if($HjoinCommentPenaltyStr ne '') {
		$src.= <<"END";
<BR>
코멘트란이 발견 당시 그대로인 경우 관리자 보관 처리할까요? <B>$doStr[($HjoinCommentPenalty> 0)]</B><BR>
END
		$src.= "참고: 섬 발견후,<B>$HjoinCommentPenalty 턴</B>내에코멘트이아니면, 관리자 보관이 됩니다. 해제의 뢰는$HjoinCommentPenaltyStr<BR>" if($HjoinCommentPenalty);
	}
	$src.= "<BR>'관리자 보관' 상태라도 첫 번째 명령이 '섬 포기'라면 사멸 처리를 할까요? <B>$doStr[$HforgivenGiveUp]</B><BR>";
	$src.= "<BR>'관리자 보관'의 섬으로 공격(함대 파견·괴수 파견·미사일 공격)을 허가할까요? <B>$doStr[$HforgivenAttack]</B><BR>";

# 기본 설정
#------------------

	my $doNothingMoney = "$HdoNothingMoney$HunitMoney";
	1 while $doNothingMoney =~ s/(.*\d)(\d\d\d)/$1,$2/;

	$src.= <<"END";
<HR>
<a name='basic'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 기본 설정</H3></a>
${AfterName}최대 수 <B>$HmaxIsland</B><BR>
${AfterName}의 대크기 <B>${HislandSizeX}x${HislandSizeY}</B><BR>
명령 입력 한계 수 <B>$HcommandMax</B><BR>
1턴이 몇 초인지 <B>${unitTime}초 ( $hour$min$sec )</B><BR>
1회의 갱신마다 몇 턴 진행할지 <B>$repeatTurn 턴</B><BR>
게임종료 턴 수 <B>$HgameLimitTurn 턴</B><BR>
순위의 원래가 됨요소 <B>$rankKind{$HrankKind}</B><BR>
<BR>
'자금 조달' 수입 <B>$doNothingMoney</B><BR>
<BR>
새로 등록된 ${AfterName}의 개발 기간 <B>$HdevelopTurn 턴</B><BR>
포기 명령 자동 입력 턴 수(개발 기간) <B>$HdevelopGiveupTurn 턴</B><BR>
포기 명령 자동 입력 턴 수 <B>$HgiveupTurn 턴</B><BR>
새 $AfterName을찾은 직후의 방치 턴 수 <B>$HjoinGiveupTurn 턴</B><BR>
END

	if($HuseLbbs) {
		my $lbbsMoneyPublic = "$HlbbsMoneyPublic$HunitMoney";
		1 while $lbbsMoneyPublic =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my $lbbsMoneySecret = "$HlbbsMoneySecret$HunitMoney";
		1 while $lbbsMoneySecret =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$src.= <<"END";
<BR>
로컬 게시판의 표시 줄 수 <B>$HlbbsViewMax</B><BR>
로컬 게시판의 저장 줄 수 <B>$HlbbsMax</B><BR>
로컬 게시판의 익명 발언을 허가할까요? <B>$doStr[$HlbbsAnon]</B><BR>
로컬 게시판에 발언자 이름을 표시할까요? <B>$doStr[$HlbbsSpeaker]</B><BR>
로컬 게시판에서 자동 링크를 사용할까요? <B>$doStr[($HlbbsAutolinkSymbol ne '')]</B>(표시 <B>$HlbbsAutolinkSymbol</B>)<BR>
다른 $AfterName의 로컬 게시판에 글을 쓸 시 필요한 비용 공개 <B>$lbbsMoneyPublic</B> 극비 <B>$lbbsMoneySecret</B><BR>
END
	}

#자금, 식량등의 설정 값
#-------------------------

	my $initialMoney = "$HinitialMoney$HunitMoney";
	1 while $initialMoney =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $maximumMoney = "$HmaximumMoney$HunitMoney";
	1 while $maximumMoney =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $costChangeName = "$HcostChangeName$HunitMoney";
	1 while $costChangeName =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $treeValue = "$HtreeValue$HunitMoney";
	1 while $treeValue =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $initialFood = "$HinitialFood$HunitFood";
	1 while $initialFood =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $maximumFood = "$HmaximumFood$HunitFood";
	1 while $maximumFood =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $oilMoney = "$HoilMoney$HunitMoney";
	1 while $oilMoney =~ s/(.*\d)(\d\d\d)/$1,$2/;
	if($HoilMoneyMin) {
		my $oilMoney2 = "$HoilMoneyMin$HunitMoney";
		1 while $oilMoney2 =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$oilMoney = "무작위 수입 ($oilMoney2~$oilMoney)";
	}
	$oilRatio = $HoilRatio/10;
	$src.= <<"END";
<BR><TABLE>
<TR $HbgInfoCell><TH rowspan=2>${HtagTH_}초기자금 / 최대자금${H_tagTH}${H_tagTH}</TH><TH rowspan=2>${HtagTH_}초기 식량 / 최대식량${H_tagTH}</TH><TH colspan=5>${HtagTH_}최소단위${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TH>${HtagTH_}자금${H_tagTH}</TH><TH>${HtagTH_}식량${H_tagTH}</TH><TH>${HtagTH_}인구${H_tagTH}</TH><TH>${HtagTH_}면적${H_tagTH}</TH><TH>${HtagTH_}나무 수${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TD align='center'>$initialMoney / $maximumMoney</TD><TD align='center'>$initialFood / $maximumFood</TD><TD align='right'>1$HunitMoney</TD><TD align='right'>1$HunitFood</TD><TD align='right'>1$HunitPop</TD><TD align='right'>1$HunitArea</TD><TD align='right'>1$HunitTree</TD></TR>
</TABLE></B><BR>
이름 변경의 비용 <B>$costChangeName</B><BR>
목의1$HunitTree 당거나의 판매 수입 <B>$treeValue</B><BR>
1턴에서 늘어나는 나무 수(숲1Hex 주변) <B>${HtreeGrow}$HunitTree</B><BR>
인구1$HunitPop 주변의 식량소비량 <B>${HeatenFood}x1$HunitFood</B><BR>
괴수의 수의 단위 <B>$HunitMonster</B><BR>
<BR>
유전 발견확률 <B>(굴착수량 - 발견완료미유전 수 x 25)%</B><BR>
유전 고갈확률 <B>$oilRatio%</B><BR>
유전 수입 <B>$oilMoney</B><BR>
<BR>
난이도조정(식량·자금 수입배율:일반레와 에 대한 배율) <B>${HincomeRate}배</B><BR>
END

# 해역 모드
#------------------

	$src.= <<"END";
<HR>
<a name='ocean'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 해역 모드</H3></a>
해역 모드 <B>$switchStr[($HoceanMode> 0)]</B>
END
	$src.= " ($AfterName 토$AfterName이하나나가리의 대큰지도가 됩니다)<BR>" if($HoceanMode);

	my(@yesno) = ('아니오', '는이');
	if($HoceanMode> 0) {
		$src.= <<"END";
<blockquote>
${AfterName}의 배치 수 <B>${HoceanSizeX}x${HoceanSizeY}</B><BR><BR>
해역 지도를 표시할까요? <B>$doStr[$HuseOceanMap]</B><BR>
END
		if($HuseOceanMap) {
			$src.= <<"END";
<TABLE>
<TR $HbgInfoCell><TH colspan='2'>해역 지도 지형</TH></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HoceanImage[0]'></TD><TH>미지의 해역</TH></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HoceanImage[1]'></TD><TH>자신의$AfterName</TH></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HoceanImage[2]'></TD><TH>일반$AfterName</TH></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HoceanImage[3]'></TD><TH>전장</TH></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HoceanImage[4]'></TD><TH>관리자 보관</TH></TR>
</TABLE>
 지구 모드일 시, 대상 섬이 지도 중앙에 오도록 할까요? <B>$doStr[$HadjustMap]</B><BR>
 해역 지도 아래에상세지도를 표시할까요? <B>$doStr[($HshowWorld> 0)]</B><BR><BR>
END
		}
		$src.= <<"END";
해역이 연결되어 있는 섬끼리에서는, 함대 이동, 파견, 귀환, 괴수 파견 명령을 사용 불가로 할까요?<BR>
 함대 이동, 파견, 귀환(자기 섬에 대한 이동, 파견, 귀환 포함):<B>$useableStr[!$HnotuseNavyMove]</B><BR>
 괴수 파견(자기 섬에 대한 파견은 제외):<B>$useableStr[!$HnotuseMonsterSend]</B><BR><BR>
전장은 해역에 연결하지 않음. <B>$yesno[$HfieldUnconnect]</B><BR>
END
		$src.= <<"END" if($HfieldUnconnect);
전장 내의 함정·괴수 이동 조종이 이외의 해역으로는 나갈 수 없도록 할까요? 함정:<B>$yesno[$HfieldNavy]</B> 괴수:<B>$yesno[$HfieldNavy]</B><BR>
END
		$src.= <<"END";
</blockquote>
END
	}
	$src.= <<"END";
<BR>
지구 모드 <B>$switchStr[($Hroundmode> 0)]</B>
END
	$src.= " (지도의 상하와 좌우가 연결됩니다)<BR>" if($Hroundmode);
# 소멸 회피·무인화회피
#----------------------

	my $autokeep = '';
	if($HautoKeeper> 1) {
		my $autoKeeperPop = "$HautoKeeper$HunitPop";
		1 while $autoKeeperPop =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$autokeep =<<"END";
<B>$autoKeeperPop 에서무인화자동회피기능발동</B><BR>
 참고: '섬 포기'이외에서는 사멸 처리를 하지 않음. 단, 인구가0인 경우, 황무지나 평지가 아니면 침몰해 버림.<BR>
 참고: 타 섬에 파견 중인 함정이나 자기 섬(처리 대상 섬)에 출현 중인 괴수·거대괴수는 바다가 되어 소멸합니다.<BR>
 참고: 타 섬에서 자기 섬으로 파견되어 있는 함대는 귀환 처리됩니다.(인구가 0인 경우, 초기 설정의 인구가 됩니다)<BR>
 참고: 초기 설정의 인구에서 개발 기간에 들어감.
END
	} elsif($HautoKeeper) {
		$autokeep =<<"END";
<B>사멸 판정 회피 기능 발동</B><BR>
 참고: '섬 포기'이외에서는 사멸 처리를 하지 않음.<BR>
 참고: 타 섬에 파견 중인 함정이나 자기 섬(처리 대상 섬)에 출현 중인 괴수·거대괴수는 바다가 되어 소멸합니다.<BR>
 참고: 타 섬에서 자기 섬으로 파견되어 있는 함대는 귀환 처리됩니다.<BR>
 참고: 관리자 보관 상태입니다.(인구가 0인 경우, 보관 해제 시 초기 설정의 인구가 됩니다)<BR>
 주!
END
		$autokeep.= (!$HautoKeeperSetTurn) ? '관리자 보관은 관리자자신의 손에 따라해됩니다.' : "관리자 보관은<B>$HautoKeeperSetTurn 턴 후에자동 해제</B>됩니다.";
	} else {
		$autokeep = '<B>사용 안 함</B>';
	}
	$src.= <<"END";
<HR>
<a name='autokeep'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 무인(사멸)회피</H3></a>
무인화자동회피·사멸판정회피기능 사용 $autokeep<BR><BR>
END

# 서바이벌 모드
#------------------

	$src.= <<"END";
<HR>
<a name='survival'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 서바이벌</H3></a>
서바이벌 모드 <B>$switchStr[($HsurvivalTurn> 0)]</B><BR>
END

	my $sec2 = ($HarmisticeTime % 60);
	$sec2 = ($sec2 ? "$sec2초" : '');
	my $min2 = ($HarmisticeTime % 3600);
	$min2 = ($min2 ? "$min2분" : '');
	my $hour2 = int($HarmisticeTime / 3600);
	$hour2 = ($hour2 ? "$hour2 시간" : '');

	$src.= <<"END" if($HsurvivalTurn> 0);
<blockquote>
휴전 기간 <B>$HsurvivalTurn 턴까지</B><BR>
휴전 기간 중 턴 갱신 간격 <B>${HarmisticeTime}초 ( $hour2$min2$sec2 )</B><BR>
휴전 기간 안1회의 갱신마다 몇 턴 진행할지 <B>$HarmisticeRepeatTurn 턴</B><BR>
몇 턴마다 최하위 ${AfterName}을 멸망시킬지 <B>$HturnDead 턴($HsurvivalTurn 턴이후)</B><BR>
</blockquote>
END

# 진영전쟁 모드
#------------------

	$src.= <<"END";
<HR>
<a name='imperial'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 진영전쟁(제국국 바다전쟁)</H3></a>
진영전쟁 모드 <B>$switchStr[($HarmisticeTurn> 0)]</B><BR>
END

	my $cdr = (!$HcampDeleteRule) ? "" : ($HcampDeleteRule == 1) ? " 참고: 점유율<B>(50÷진영 수)%미만</B>로 소멸" : " 참고: 점유율<B>${HcampDeleteRule}%미만</B>로 소멸";
	my $initialMoney2 = "$HinitialMoney2$HunitMoney";
	1 while $initialMoney2 =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $initialFood2 = "$HinitialFood2$HunitFood";
	1 while $initialFood2 =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$src.= <<"END" if($HarmisticeTurn);
<blockquote>
휴전 기간 <B>$HarmisticeTurn 턴까지</B><BR>
휴전 기간 중 턴 갱신 간격 <B>${HarmisticeTime}초 ( $hour2$min2$sec2 )</B><BR>
휴전 기간 안1회의 갱신마다 몇 턴 진행할지 <B>$HarmisticeRepeatTurn 턴</B><BR>
승리조건 <B>점유율${HfinishOccupation}%</B><BR>
진영 위임 임시 이관 턴 수 <B>$HpreGiveupTurn 턴</B><BR>
'진영 공동 개발'을 허용할까요? <B>$doStr[$HuseCoDevelop]</B><BR>
진영 비밀번호로 비밀번호 변경을 허용할까요? <B>$doStr[$HpassChangeOK]</B><BR>
진영 밖 지원을 허가할까요? <B>$doStr[!$HcampAidOnly]</B><BR>
진영의 선택 방법 <B>$selectStr[$HcampSelectRule]</B><BR>
진영의 소멸이 있는 지? <B>$anStr[($HcampDeleteRule> 0)]</B>$cdr<BR>
진영작전본부 명령 표시 수 <B>${HcampCommandTurnNumber}</B>(× $HrepeatTurn 턴)<BR>
게임 시작 후의 초기자금과 초기 식량: 초기자금 <B>${initialMoney2}</B> / 초기 식량 <B>${initialFood2}</B><BR>
</blockquote>
END

# 토너먼트 모드
#---------------------

	$src.= <<"END";
<HR>
<a name='tournament'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 토너먼트</H3></a>
토너먼트 모드 <B>$switchStr[($Htournament> 0)]</B><BR>
END

	my $tournament = "";
	if($Htournament){
		# 토너먼트 턴 갱신 시간표 빠른 보기
		$tournament = <<"END";
<STYLE type="text/css">
<!--
#list { display:none; }
-->
</STYLE>
<SCRIPT LANGUAGE="JavaScript">
<!--
function textcopy(mapdata){
	window.clipboardData.setData("text",mapdata);
}
function searchID(url){
	if(document.getElementById){
		return document.getElementById(url);
	} else if(document.all){
		return document.all(url);
	} else if(document.layers){
		return document.layers[url];
	}
}
function display() {
 if(document.getElementById){
 var obj1 = document.getElementById('list');
 var obj2 = document.getElementById('hyo');
 if (obj1.style.display == 'block'){
 obj1.style.display='none';
 obj2.style.display='block';
 } else {
 obj1.style.display='block';
 obj2.style.display='none';
 }
 }
}
//-->
</SCRIPT>
<DIV id='hyo'><INPUT TYPE="button" VALUE="토너먼트 갱신 시간표 빠른 보기" onClick="display();"></DIV>
<DIV id='list'><INPUT TYPE="button" VALUE="클립보드에 복사" onClick="textcopy(searchID('ALIST').value);display();"><BR>
<textarea NAME="ALIST" cols="100" rows="5">
END
		my $round = $HislandFightCount;
		my $pno = @HpreDeleteID;
		my $ino = $HislandNumber - $pno - $HbfieldNumber;
		my $itn = $HislandTurn;
		my $ftn = $HfightTurn;
		my $ilt = $HislandLastTime;
		if($round && $ino> $Htournament) {
			$ino = $Htournament;
		}
		my $fturn = 0;
		my $nofight = 0;
		if($HislandFightMode == 1) {
			$fturn = $HislandChangeTurn - $HyosenTurn - $HdevelopeTurn;
		} elsif($HislandFightMode == 2) {
			$ftn = $HfinalTurn if($ino <= 2);
			$fturn = $HislandChangeTurn - $HyosenTurn - $HdevelopeTurn - $ftn;
			foreach ($HbfieldNumber..$islandNumber) {
				$nofight++ if($Hislands[$_]->{'fight_id'} < 0);
			}
		}
		$tournament.= "턴\t$AfterName 수\t진행상태\t갱신 시간\n";
		while($ino> 1){
			if($itn < $HyosenTurn){
				# 예선
				$HislandFightMode = 0;
				$ilt += ($HflexTimeSet) ? 3600 * $HtmTime1[($itn % ($#HtmTime1 + 1))] : $HyosenTime;
				$timeString = timeToString($ilt);
				foreach(1..$HyosenRepCount){
					$itn++;
					$tournament.= "$itn\t$ino\t예선\t$timeString\n";
					last if($itn == $HyosenTurn);
				}
			} elsif($itn < $HyosenTurn + $HdevelopeTurn + $fturn) {
				# 개발
				$ino = $Htournament if(($HislandFightMode == 0) && ($ino> $Htournament));
				$HislandFightMode = 1;
				$ilt += ($HflexTimeSet) ? 3600 * $HtmTime2[($itn % ($#HtmTime2 + 1))] : $HdevelopeTime;
				$timeString = timeToString($ilt);
				$ftn = $HfinalTurn if($ino <= 2);
				foreach(1..$HdeveRepCount){
					$itn++;
					$tournament.= "$itn\t$ino\t개발\t$timeString\n";
					last if($itn == $HyosenTurn + $HdevelopeTurn + $fturn);
				}
			} elsif($itn < $HyosenTurn + $HdevelopeTurn + $ftn + $fturn) {
				# 전투
				$HislandFightMode = 2;
				$ilt += ($HflexTimeSet) ? 3600 * $HtmTime3[($itn % ($#HtmTime3 + 1))] : $HfightTime;
				$timeString = timeToString($ilt);
				#$tournament.= "$itn\t$ino\t전투♪\t$timeString\t$HfightRepCount\n";
				foreach(1..$HfightRepCount){
					$itn++;
					$tournament.= "$itn\t$ino\t전투♪\t$timeString\n";
					last if($itn == $HyosenTurn + $HdevelopeTurn + $ftn + $fturn);
				}
			} else {
				$ilt += ($HflexTimeSet) ? 3600 * $HtmTime2[($itn % ($#HtmTime2 + 1))] : ($itn == $HyosenTurn + $HdevelopeTurn + $ftn + $fturn) ? $HinterTime : $HdevelopeTime;
				if($HislandFightMode == 2) {
					$ino = int(($ino + $nofight) / 2 + 0.5);
					$ino++ if(($ino> 2) && (($ino % 2) != 0) && ($HconsolationMatch));
					$nofight = 0;
				}
				$HislandFightMode = 1;
				$timeString = timeToString($ilt);
				$fturn += $HdevelopeTurn + $ftn;
				$ftn = $HfinalTurn if($ino <= 2);
				if($ino> 1) {
					foreach(1..$HdeveRepCount){
						$itn++;
						$tournament.= "$itn\t$ino\t개발\t$timeString\n";
						last if($itn == $HyosenTurn + $HdevelopeTurn + $fturn);
					}
				}
			}
		}
		$tournament.= "</textarea></DIV>";
		$sec2 = ($HyosenTime % 60);
		$sec2 = ($sec2 ? "$sec2초" : '');
		$min2 = ($HyosenTime % 3600);
		$min2 = ($min2 ? "$min2분" : '');
		$hour2 = int($HyosenTime / 3600);
		$hour2 = ($hour2 ? "$hour2 시간" : '');

		$src.= <<"END";
<blockquote>
예선 통과 섬 수 <B>$Htournament$AfterName</B><BR>
예선 기간 턴 수 <B>$HyosenTurn 턴</B><BR>
예선 기간 안의 턴 갱신 간격 <B>${HyosenTime}초 ( $hour2$min2$sec2 )</B><BR>
예선 기간 안1회의 갱신마다 몇 턴 진행할지 <B>$HyosenRepCount 턴</B><BR><BR>
END

		$sec2 = ($HdevelopeTime % 60);
		$sec2 = ($sec2 ? "$sec2초" : '');
		$min2 = ($HdevelopeTime % 3600);
		$min2 = ($min2 ? "$min2분" : '');
		$hour2 = int($HdevelopeTime / 3600);
		$hour2 = ($hour2 ? "$hour2 시간" : '');

		$src.= <<"END";
개발 기간 턴 수 <B>$HdevelopeTurn 턴</B><BR>
개발 기간 안의 턴 갱신 간격 <B>${HdevelopeTime}초 ( $hour2$min2$sec2 )</B><BR>
개발 기간 안1회의 갱신마다 몇 턴 진행할지 <B>$HdeveRepCount 턴</B><BR><BR>
END

		$sec2 = ($HinterTime % 60);
		$sec2 = ($sec2 ? "$sec2초" : '');
		$min2 = ($HinterTime % 3600);
		$min2 = ($min2 ? "$min2분" : '');
		$hour2 = int($HinterTime / 3600);
		$hour2 = ($hour2 ? "$hour2 시간" : '');

	$src.= <<"END";
개발 기간 종료 후 전투 기간으로 넘어가기까지의 시간 <B>${HinterTime}초 ( $hour2$min2$sec2 )</B><BR><BR>
END

		$sec2 = ($HfightTime % 60);
		$sec2 = ($sec2 ? "$sec2초" : '');
		$min2 = ($HfightTime % 3600);
		$min2 = ($min2 ? "$min2분" : '');
		$hour2 = int($HfightTime / 3600);
		$hour2 = ($hour2 ? "$hour2 시간" : '');
		my $halffight = int($HfightTurn/2);
		my $halffinal = int($HfinalTurn/2);
		my $no_workPop = "$Hno_work$HunitPop";
		1 while $no_workPop =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$src.= <<"END";
전투 기간 턴 수 <B>$HfightTurn 턴</B><BR>
전투 기간 안의 턴 갱신 간격 <B>${HfightTime}초 ( $hour2$min2$sec2 )</B><BR>
전투 기간 안1회의 갱신마다 몇 턴 진행할지 <B>$HfightRepCount 턴</B><BR><BR>
결승전의 전투 기간 턴 수 <B>$HfinalTurn 턴</B><BR>
부전승의 개발 정지 턴 수 <B>(라운드 수)x${HnofightUp}+${HnofightTurn}턴</B><BR>
부전승을 피하기 위해 필요한 전투 행위 횟수 <B>$do_fight 회</B><BR>
참고: 전투 기간의 절반($halffight 턴·결승은$halffinal 턴)이 경과할 시까지,'상대가 없는 경우'및'상대의 전투 행위 횟수가 $do_fight 회에 미달한 경우(상대가 한 번도 함대를 파견하지 않은 경우)'는 부전승으로 처리됩니다.<BR>
 이 경우, 전투 시작 시의 섬의 상태로 복구되고, 개발 정지가 됩니다.<BR>
 정지 기간은,(라운드 수×${HnofightUp}+${HnofightTurn})- 경과 턴 수입니다.<BR>
인구 증가가 중단되는 자금 조달 횟수 <B>$HstopAddPop 회</B><BR>
실업자 수의 테두리라인 <B>$no_workPop</B> 참고: 이 수치를 초과하면, 인구 증가가 중단합니다(예선만)<BR>
'패자부활'을 사용할까요? <B>$doStr[$HconsolationMatch]</B> 참고: 전투 종료 후 남은 수(부전승 발생 예정 없음)인 경우, 패배한 $AfterName 중 최상위 $AfterName을 보충합니다.<BR>
<BR>$tournament</blockquote>
END
	}

# 우호국 설정
#----------------------

	$src.= <<"END";
<HR>
<a name='amity'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 우호국 설정</H3></a>
우호국 설정을 사용할까요? <B>$useStr[$HuseAmity]</B><BR>
END

	if($HuseAmity && !$HarmisticeTurn) {
		if($HamityMax) {
			$src.= "우호국 설정 가능 최대 수 <B>$HamityMax${AfterName}</B><BR>";
		} else {
			$src.= "우호국 설정 가능 최대 수 <B>제한없음</B><BR>";
		}
		if($HamityMoney) {
			my $amityMoney = "$HamityMoney$HunitMoney";
			1 while $amityMoney =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$src.= "우호국1$AfterName 주변의 유지비용 <B>$amityMoney</B><BR>참고: (내가 우호국으로 설정한$AfterName 수)×${amityMoney}이매 턴필요가 됩니다.<BR>";
		}
		if($HamityDisarm) {
			$src.= " 참고: 함대 파견 중인 ${AfterName}에는,<B>우호국 폐기를 할 수 없습니다</B>.(승인은 할 수 있습니다)<BR>";
		}
		if($HamityInvalid) {
			$src.= " 참고: 전장에서는'함정의 보급''색적하지 않음''공격하지 않음'설정이 무효가 됩니다.<BR>";
		}
	}

# 선전포고시스템
#----------------------
	$src.= <<"END";
<HR>
<a name='dewar'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 선전포고시스템</H3></a>
'선전포고''정전 교섭'명령을 사용할까요? <B>$useStr[(($HuseDeWar> 0) && !$HarmisticeTurn && !$HsurvivalTurn && !$Htournament)]</B>$useDeWar<BR>
END

	if(!$HarmisticeTurn && !$HsurvivalTurn && !$Htournament) {
		if($HuseDeWar) {
			my $matchplay = ('<B>사용 안 함</B>', '<B>사용</B>(제한만)', '<B>사용</B>(전쟁 발발 로그 출력과 동시에, 자동으로 두 섬의 확장 데이터의 국가 설정과 지형 저장을 실행)')[$HmatchPlay];
			$src.= <<"END";
선전포고 대상은 한 섬만 가능하도록 할까요? $matchplay<BR>
선전포고유예 턴 <B>$HdeclareTurn 턴</B><BR>
정전 제안 명령에서 정전 합의 한 경우, 자동으로 함대를 귀환할까요? <B>$doStr[$HceasefireAutoNavyReturn]</B><BR>
확장 데이터의 카운터 설정을 플레이어에게 공개할까요? <B>$doStr[$HcounterSetting]</B><BR>
END
		}
	}

# 이벤트시스템
#----------------------

	$src.= <<"END";
<HR>
<a name='event'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 이벤트시스템</H3></a>
이벤트시작전의 공지 턴 수 <B>$HnoticeTurn 턴</B><BR>
<TABLE BORDER>
<TR><TH>${HtagTH_}이벤트 종류${H_tagTH}</TH><TH>${HtagTH_}승리조건등${H_tagTH}</TH></TR>
<TR><TH>서바이벌</TH>
<TD class='N'>
<u>개최 $AfterName에 파견된 다른 $AfterName 소속 함정을 모두 격파하고 마지막까지 살아남은 $AfterName이 우승합니다!</u>
<BR>·소속 불명 함정은 격파하지 않아도 됩니다.
<BR>·종료 턴은 승부가 날 시까지이며, 추가 파견은 할 수 없습니다.
</TD></TR>
<TR><TH>함정 경험치 획득 배틀</TH>
<TD class='N'>
<u>파견된 함정이 종료 턴까지 획득한 경험치의 합계가 가장 높은 $AfterName이 우승!</u>
<BR>·파견된 모든 함정이 개최 기간 중에 획득한 경험치의 합계로 판정합니다.
<BR>·획득 경험치 합계가 같은 $AfterName이 여러 개 있는 경우, 동점으로 처리됩니다.
<BR>·고이경험치를 가진 함정의 파견나 개최 기간 안의 파견이 가능여부는 설정에 한.
</TD></TR>
<TR><TH>함정 격침 배틀</TH>
<TD class='N'>
<u>파견된 함정이 종료 턴까지 침몰시킨 함정 수 합계이 가장 높은$AfterName이우승!</u>
<BR>·파견된 모든 함정이 개최 기간 중에 침몰시킨 함정 수로 판정합니다.
<BR>·침몰시킨 함정 수가 같은 $AfterName이 여러 개 있는 경우, 동점으로 처리됩니다.
<BR>·개최 기간 안의 파견이 가능여부는 설정에 한.
</TD></TR>
<TR><TH>괴수 퇴치 배틀</TH>
<TD class='N'>
<u>파견된 함정이 종료 턴까지 쓰러뜨린 괴수·거대괴수의 합계이 가장 높은$AfterName이우승!</u>
<BR>·파견된 모든 함정이 개최 기간 중에 쓰러뜨린 괴수 수(+ 거대괴수수)로 판정합니다.
<BR>·쓰러뜨린 괴수 수(+ 거대괴수 수)가 같은 $AfterName이 여러 개 있는 경우, 동점으로 처리됩니다.
<BR>·개최 기간 안의 파견이 가능여부는 설정에 한.
</TD></TR>
<TR><TH>상금 획득 배틀</TH>
<TD class='N'>
<u>파견된 함정이 종료 턴까지 획득한 상금 총액이 가장 높은 $AfterName이 우승!</u>
<BR>·파견된 모든 함정이 개최 기간 중에 획득한 괴수 퇴치·거대괴수 퇴치의 상금 총액으로 판정합니다.
<BR>·상금 총액이 같은 $AfterName이 여러 개 있는 경우, 동점으로 처리됩니다.
<BR>·개최 기간 안의 파견이 가능여부는 설정에 한.
</TD></TR>
</TABLE>
참고: 파견 함정이 모두 격침되는 등의 이유로  종료 판정 시 개최 $AfterName에 함정이 없으면 해당 $AfterName은 순위에서 제외됩니다!
END

# 동맹
#----------------------

	my $allyDisDown = '같은';
	if($HallyDisDown) {
		$allyDisDown = $HallyDisDown. '배';
	}
	my $allyMax = (!$HallyMax) ? '무제한' : "$HallyMax$AfterName";
	my $allyAutoBreakup = ('하지 않음', '하다', '함[게시판을 소멸 로그로 이전]')[$HallyAutoBreakup];
	my $costMakeAlly = "$HcostMakeAlly$HunitMoney";
	1 while $costMakeAlly =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $costKeepAlly = "$HcostKeepAlly$HunitMoney";
	1 while $costKeepAlly =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$src.= <<"END";
<HR>
<a name='ally'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 동맹시스템</H3></a>
동맹의 작성을 허가할까요? <B>$doStr[$HallyUse]</B><BR>
END

	$src.= <<"END" if($HallyUse);
하나의 동맹에만 가입할 수 있도록 할까요? <B>$doStr[$HallyJoinOne]</B><BR>
 참고: 이 설정과 관계없이 맹주는 여러 동맹에 가입할 수 없습니다.<BR>
맹주 섬소멸 시  동맹을 자동으로 해산할까요? <B>$allyAutoBreakup</B><BR>
1개 동맹에 가입 가능한 최대 $AfterName 수 <B>$allyMax</B><BR>
동맹에 가입한 경우의 재해발생확률(일반 상태에 대한 비율) <B>$allyDisDown</B><BR>
 참고: 대상이 되는 재해:지진, 쓰나미, 태풍, 운석, 거대운석, 분화<BR><BR>
동맹에걸립니다비용 결성·변경 <B>${costMakeAlly}</B> / 유지비 <B>${costKeepAlly}</B><BR>
END

# 지형·명령 설정
#----------------------
	$src.= <<"END";
<HR>
<a name='usecom'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 지형·명령 설정</H3></a>
<TABLE><TR>
END

	# 바다, 황무지, 평지, 산, 숲, 농장, 공장, 해저 유전, 가짜 시설, 방위 시설, 미사일 기지, 해저 기지, 방파제, 기뢰, 코어
	$src.= "<TD valign='top' class='M'><TABLE><TR $HbgInfoCell><TH colspan='2'>일반 지형</TH></TR><TR $HbgInfoCell><TH>${HtagTH_}지형${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH></TR>";
	foreach ("$HlandSea", "$HlandWaste", "$HlandPlains", "$HlandMountain", "$HlandForest", "$HlandFarm", "$HlandFactory", "$HlandOil", "$HlandHaribote", "$HlandDefence", "$HlandBase", "$HlandSbase", "$HlandBouha", "$HlandSeaMine", "$HlandCore") {
		next if (($_ == $HlandForest) && !$HusePlantSellTree);
		next if (($_ == $HlandFarm) && !$HuseFarm);
		next if (($_ == $HlandFactory) && !$HuseFactory);
		next if (($_ == $HlandMountain) && !$HuseMountain);
		next if (($_ == $HlandBase) && !$HuseBase);
		next if (($_ == $HlandSbase) && (!$HuseSbase || $Htournament));
		next if (($_ == $HlandBouha) && !$HuseBouha);
		next if (($_ == $HlandSeaMine) && !$HuseSeaMine);
		next if (($_ == $HlandCore) && !$HuseCore);
		my @set = @{$HlandName[$_]};
		if(defined $set[0]) {
			pop(@set) if(($_ == $HlandDefence) && (!$HdurableDef || ($HdurableDef < $HdefLevelUp)));
			foreach $i (0..$#set) {
				$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HlandImage[$_][$i]'></TD><TH>$HlandName[$_][$i]</TH></TR>";
			}
		} else {
			$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HlandImage[$_]'></TD><TH>$HlandName[$_]</TH></TR>";
		}
	}
	$src.= "</TABLE></TD>";
	# 도시계
	$src.= "<TD valign='top' class='M'><TABLE><TR $HbgInfoCell><TH colspan='2'><a href='#town' style='text-decoration=none'>도시계</a></TH></TR><TR $HbgInfoCell><TH>${HtagTH_}지형${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH></TR>";
	foreach (0..$#HlandTownName) {
		$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HlandTownImage[$_]'></TD><TH>$HlandTownName[$_]</TH></TR>";
	}
	$src.= "</TABLE></TD>";
	# 기념비
	$src.= "<TD valign='top' class='M'><TABLE><TR $HbgInfoCell><TH colspan='2'><a href='#monument' style='text-decoration=none'>기념비</a></TH></TR><TR $HbgInfoCell><TH>${HtagTH_}지형${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH></TR>";
	foreach (0..$#HmonumentName) {
		$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HmonumentImage[$_]'></TD><TH>$HmonumentName[$_]</TH></TR>";
	}
	$src.= "</TABLE></TD>";
	# 복합 지형
	if($HuseComplex) {
		$src.= "<TD valign='top' class='M'><TABLE><TR $HbgInfoCell><TH colspan='2'><a href='#complex' style='text-decoration=none'>복합 지형</a></TH></TR><TR $HbgInfoCell><TH>${HtagTH_}지형${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH></TR>";
		foreach (0..$#HcomplexName) {
			$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HcomplexImage[$_]'></TD><TH>$HcomplexName[$_]</TH></TR>";
		}
		$src.= "</TABLE></TD>";
	}
	# 해군
	if($HnavyName[0] ne '') {
		$src.= "<TD valign='top' class='M'><TABLE><TR $HbgInfoCell><TH colspan='2'><a href='#navy' style='text-decoration=none'>해군</a></TH></TR><TR $HbgInfoCell><TH>${HtagTH_}지형${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH></TR>";
		foreach (0..$#HnavyName) {
			$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HnavyImage[$_]'></TD><TH>$HnavyName[$_]</TH></TR>";
			next if(!($HnavySpecial[$_] & 0x4));
			$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HnavyImage2[$_]'></TD><TH>$HnavyName[$_]<small>(잠수)</small></TH></TR>";
		}
		$src.= "</TABLE></TD>";
	}
	# 괴수
	$src.= "<TD valign='top' class='M'><TABLE><TR $HbgInfoCell><TH colspan='2'><a href='#monster' style='text-decoration=none'>괴수</a></TH></TR><TR $HbgInfoCell><TH>${HtagTH_}지형${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH></TR>";
	foreach (0..$#HmonsterName) {
		$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HmonsterImage[$_]'></TD><TH>$HmonsterName[$_]</TH></TR>";
		next if(!($HmonsterSpecial[$_] & 0x4));
		$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HmonsterImage2[$_]'></TD><TH>$HmonsterName[$_]<small>(경화)</small></TH></TR>";
	}
	$src.= "<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HmonsterImageUnderSea'></TD><TH>공통 설정<small>(잠수)</small></TH></TR>";
	$src.= "</TABLE></TD>";
	# 거대괴수
	if($HhugeMonsterAppear) {
		$src.= "<TD valign='top' class='M'><TABLE><TR $HbgInfoCell><TH colspan='2'><a href='#hmonster' style='text-decoration=none'>거대괴수</a></TH></TR><TR $HbgInfoCell><TH>${HtagTH_}지형${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH></TR>";
		foreach (0..$#HhugeMonsterName) {
			my(@monImage);
			my $space = "<img src='${HimageDir}/$HlandImage[$HlandWaste][0]' width=16 height=32>";
			foreach $i (0..6) {
				$monImage[$i] = ($HhugeMonsterImage[$_][$i] eq '') ? "${HimageDir}/$HlandImage[$HlandWaste][0]" : "${HimageDir}/$HhugeMonsterImage[$_][$i]";
			}
			$src.= <<"END";
<TR $HbgInfoCell><TD align='right'>
$space<img src='$monImage[6]'><img src='$monImage[1]'>$space<br>
<img src='$monImage[5]'><img src='$monImage[0]'><img src='$monImage[2]'><br>
$space<img src='$monImage[4]'><img src='$monImage[3]'>$space
</TD><TH>$HhugeMonsterName[$_]</TH></TR>
END
		}
		$src.= "</TABLE></TD>";
	}

	$src.= "</TR></TABLE><BR>";

	$src.= "방파제를 사용할까요? <B>$useStr[($HuseBouha> 0)]</B><BR>";
	if($HuseBouha) {
		$src.= " 방파제 보유 가능 횟수 <B>$HuseBouha</B><BR>";
	}

	$src.= "기뢰를 사용할까요? <B>$useStr[($HuseSeaMine> 0)]</B><BR>";
	if($HuseSeaMine) {
		$src.= " 기뢰 설치 가능 여부 <B>$HuseSeaMine</B><BR>";
		$src.= " 자$AfterName의 기뢰에서 피해를 받을까요? <B>$selfStr[$HmineSelfDamage]</B><BR>";
	}
	my $edgeDef = "";
	if($HedgeReclaim> 1) {
		my $edgeSize1 = $HedgeReclaim - 1;
		my $edgeSizeX = $HislandSizeX - $HedgeReclaim;
		my $edgeSizeY = $HislandSizeY - $HedgeReclaim;
		$edgeDef = "<B>${HedgeReclaim}Hex</B>";
		$edgeDef.= "(x좌표 일부가 '$edgeSize1' 이하이거나 '$edgeSizeX' 이상인 지점) 또는 (y좌표 일부가 '$edgeSize1' 이하이거나 '$edgeSizeY' 이상인 지점)" if(!$HoceanMode);
	} elsif($HedgeReclaim) {
		my $edgeSizeX = $HislandSizeX - 1;
		my $edgeSizeY = $HislandSizeY - 1;
		$edgeDef = '<B>1Hex</B>';
		$edgeDef.= "(x좌표 일부가 '0' 또는 '$edgeSizeX'인 지점) 또는 (y좌표 일부가 '0' 또는 '$edgeSizeY'인 지점)" if(!$HoceanMode);
	}

	$src.= <<"END";
<BR>
벌채를 턴 소비 없이 실행할까요? <B>$doStr[$HnoturnSellTree]</B><BR>
함정 주변을 매립할 수 있는 문제(버그)를 수정할까요? <B>$doStr[$HnavyReclaim]</B><BR>
바다에 있는 괴수 주변을 매립할 수 있는 문제(버그)를 수정할까요? <B>$doStr[$HmonsterReclaim]</B><BR>
군항에 인접한 깊은 바다에서만 함정을 건조할 수 있도록 할까요? <B>$doStr[$HnavyBuildFlag]</B><BR>
얕은 바다에도 이동 및 파견이 가능하게 할까요? <B>$doStr[$HnavyMoveAsase]</B><BR>
$AfterName의 가장 바깥쪽${edgeDef}을 매립 불가로 설정할까요? <B>$doStr[($HedgeReclaim> 0)]</B><BR>
END

	$src.= <<"END";
<BR>$AfterName의 면적을 통일할까요? <B>$doStr[$HnewIslandSetting]</B><BR>
END
	$HcountLandArea = 16 if($HcountLandArea < 16);
	$HcountLandPlains = $HcountLandArea - $HcountLandWaste - $HcountLandForest - $HcountLandTown - $HcountLandMountain - $HcountLandPort;
	my $bcol = 6;
	my($bstr1, $bstr2);
	if($HuseBase) {
		$bcol++;
		$bstr1 = "<TH>${HtagTH_}기지의 수${H_tagTH}</TH>";
		$bstr2 = "<TD align='center'>$HcountLandBase</TD>";
		$HcountLandPlains -= $HcountLandBase;
	}

	my $valueLandTownPop = "$HvalueLandTown$HunitPop";
	1 while $valueLandTownPop =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $valueLandMountainPop = "$HvalueLandMountain$HunitPop";
	1 while $valueLandMountainPop =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$src.= <<"END" if($HnewIslandSetting);
<BR>
<TABLE>
<TR $HbgInfoCell><TH colspan=$bcol>${HtagTH_}육지총 수 ${HnormalColor_}${HcountLandArea}${H_normalColor}${H_tagTH}</TH><TH rowspan=2>${HtagTH_}얕은 바다의 수${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TH>${HtagTH_}평지의 수${H_tagTH}</TH><TH>${HtagTH_}황무지의 수${H_tagTH}</TH><TH>${HtagTH_}숲의 수 (나무 수)${H_tagTH}</TH><TH>${HtagTH_}읍의 수 (인구)${H_tagTH}</TH><TH>${HtagTH_}산의 수 (규모)${H_tagTH}</TH>$bstr1<TH>${HtagTH_}군항의 수${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TD align='center'>$HcountLandPlains</TD><TD align='center'>$HcountLandWaste</TD><TD align='right'>${HcountLandForest} ($HvalueLandForest$HunitTree)</TD><TD align='right'>${HcountLandTown} ($valueLandTownPop)</TD><TD align='right'>${HcountLandMountain} ($valueLandMountainPop)</TD>$bstr2<TD align='center'>$HcountLandPort</TD><TD align='center'>$HcountLandSea</TD></TR>
</TABLE></B><BR>
END

# 도시계
#-------------------------
	my $tcol1 = (!$HsurvivalTurn) ? 2 : 4;
	my $tcol2 = (!$HsurvivalTurn) ? 1 : 2;
	my $trow1 = (!$HsurvivalTurn) ? 1 : 2;
	my $trow2 = (!$HsurvivalTurn) ? 2 : 3;

	$src.= <<"END";
<HR>
<a name='town'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 도시계 설정</H3></a>
<TABLE>
<TR $HbgInfoCell>
<TH colspan=3>${HtagTH_}도시계${H_tagTH}</TH>
<TH colspan=$tcol1>${HtagTH_}인구의 증가폭${H_tagTH}</TH>
<TH rowspan=$trow2>${HtagTH_}난민<BR>수용<BR>상한${H_tagTH}</TH>
<TH rowspan=$trow2>${HtagTH_}식량<BR>부족의<BR>인구<BR>감소 값${H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TH colspan=2 rowspan=$trow1>${HtagTH_}명칭${H_tagTH}</TH>
<TH rowspan=$trow1>${HtagTH_}규모${H_tagTH}</TH>
<TH colspan=$tcol2>${HtagTH_}일반${H_tagTH}</TH><TH colspan=$tcol2>${HtagTH_}유도치${H_tagTH}</TH>
</TR>
END
	if($HsurvivalTurn) {
		$src.= "<TR $HbgInfoCell><TH>${HtagTH_}개발${H_tagTH}</TH><TH>${HtagTH_}전투${H_tagTH}</TH><TH>${HtagTH_}개발${H_tagTH}</TH><TH>${HtagTH_}전투${H_tagTH}</TH></TR>";
	}
	foreach $i (0..$#HlandTownName) {
		$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HlandTownImage[$i]'></TD><TH>$HlandTownName[$i]</TH>
END
		my $value = (!$HlandTownValue[$i]) ? '-' : "$HlandTownValue[$i]${HunitPop}이상";
		1 while $value =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$src.= "<TD align='right'>$value</TD>";
		if(!$HsurvivalTurn) {
			my $add1 = (!$Haddpop[$i]) ? '-' : "$Haddpop[$i]${HunitPop}";
			1 while $add1 =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $add2 = (!$HaddpopPropa[$i]) ? '-' : "$HaddpopPropa[$i]${HunitPop}";
			1 while $add2 =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$src.= <<"END";
<TD align='right'>$add1</TD><TD align='right'>$add2</TD>
END
		} else {
			my $add1 = (!$HaddpopSD[$i]) ? '-' : "$HaddpopSD[$i]${HunitPop}";
			1 while $add1 =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $add2 = (!$HaddpopSDpropa[$i]) ? '-' : "$HaddpopSDpropa[$i]${HunitPop}";
			1 while $add2 =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $add3 = (!$HaddpopSA[$i]) ? '-' : "$HaddpopSA[$i]${HunitPop}";
			1 while $add3 =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $add4 = (!$HaddpopSApropa[$i]) ? '-' : "$HaddpopSApropa[$i]${HunitPop}";
			1 while $add4 =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$src.= <<"END";
<TD align='right'>$add1</TD><TD align='right'>$add2</TD>
<TD align='right'>$add3</TD><TD align='right'>$add4</TD>
END
		}
		my $achieve = (!$HachiveValueMax[$i]) ? '-' : "$HachiveValueMax[$i]${HunitPop}";
		1 while $achieve =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my $reduction = (!$HreductionPop[$i]) ? '-' : "$HreductionPop[$i]${HunitPop}";
		1 while $reduction =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$src.= <<"END";
<TD align='right'>$achieve</TD><TD align='right'>$reduction</TD>
END
	}
	my $valueLandTownMaxPop = "$HvalueLandTownMax$HunitPop";
	1 while $valueLandTownMaxPop =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $achivePlainsMaxPop = "$HachivePlainsMax$HunitPop";
	1 while $achivePlainsMaxPop =~ s/(.*\d)(\d\d\d)/$1,$2/;
	my $achivePlainsLossPop = "$HachivePlainsLoss$HunitPop";
	1 while $achivePlainsLossPop =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$src.= <<"END";
</TR></TABLE>
<BR>
인구의 최댓값 <B>$valueLandTownMaxPop</B><BR>
난민의 평지 수용 상한 <B>$achivePlainsMaxPop</B>(수용 시의 로스 <B>$achivePlainsLossPop</B>)<BR>
마을 의 발생률 <B>${HtownGlow}%</B><BR>
함정 공격·미사일 공격명중 시, 일격으로 황무지 여부와 도시 랭크 하락을 적용할까요? <B>$doStr[$HtownStepDown]</B><BR>
 참고: 랭크2까지($HlandTownName[0]·$HlandTownName[1])은 일격으로 파괴됩니다. 또한, 파괴력에 따라 랭크가 하락합니다.
END

# 복합 지형
#-------------------------

		$src.= <<"END";
<HR>
<a name='complex'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 복합 지형</H3></a>
복합 지형을 사용할까요? <B>$useStr[$HuseComplex]</B><BR>
END
	if($HuseComplex) {
		$src.= <<"END";
<TABLE>
<TR $HbgInfoCell><TH rowspan=2>${HtagTH_}복합<BR>지형${H_tagTH}</TH><TH rowspan=2>${HtagTH_}명칭${H_tagTH}</TH>
<TH rowspan=2>${HtagTH_}보유<BR>가능<BR>상한${H_tagTH}</TH><TH rowspan=2>${HtagTH_}설치 가능 지형${H_tagTH}</TH><TH rowspan=2>${HtagTH_}피해규모<BR>/파괴력1${H_tagTH}</TH>
<TH colspan=15>${HtagTH_}파괴되었을 시의 지형${H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TH>${HtagTH_}개간${H_tagTH}</TH><TH>${HtagTH_}매립${H_tagTH}</TH><TH>${HtagTH_}굴착${H_tagTH}</TH>
<TH>${HtagTH_}지진${H_tagTH}</TH><TH>${HtagTH_}태풍${H_tagTH}</TH><TH>${HtagTH_}화재${H_tagTH}</TH><TH>${HtagTH_}쓰나미${H_tagTH}</TH><TH>${HtagTH_}폭동${H_tagTH}</TH>
<TH>${HtagTH_}침몰하${H_tagTH}</TH><TH>${HtagTH_}분화${H_tagTH}</TH><TH>${HtagTH_}운석${H_tagTH}</TH><TH>${HtagTH_}광역<BR>1${H_tagTH}</TH><TH>${HtagTH_}광역<BR>2${H_tagTH}</TH>
<TH>${HtagTH_}공격${H_tagTH}</TH><TH>${HtagTH_}이동${H_tagTH}</TH>
</TR>
END

		foreach $i (0..$#HcomplexName) {
			$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HcomplexImage[$i]'></TD><TH>$HcomplexName[$i]</TH>
END
			if($HcomplexMax[$i]) {
				$src.= "<TD align='right'>$HcomplexMax[$i]</TD>";
			} else {
				$src.= "<TD align='right'>-</TD>";
			}

			$src.= "<TD class='N'>";
			foreach (@{$HcomplexBefore[$i]}) {
				my $lkind = $_->[0];
				my $lvmin = $_->[1];
				my $lvmax = $_->[2];
				my $lname1 = landName($lkind, $lvmin);
				my $lname2 = landName($lkind, $lvmax);
				if($lname1 eq $lname2) {
					$src.= "<span class='check'>$lname1 </span>";
				} else {
					my @set = @{$HlandName[$lkind]};
					my $lname = ($set[0] ne '') ? $set[0] : $HlandName[$lkind];
					$src.= "<span class='check'>$lname($lname1~$lname2) </span>";
				}
			}
			foreach (@{$HcomplexBefore2[$i]}) {
				my $lname = $HcomplexName[$_];
				$src.= "<span class='check'>$lname </span>";
			}
			$src.= "</TD><TD align='center'>";
			my $down = $HcomplexAfter[$i]->{'stepdown'};
			if($down) {
				$src.= $down. '랭크';
			} elsif(defined $HcomplexAfter[$i]->{'attack'}[0]) {
				$src.= "일격으로 괴멸";
			} else {
				$src.= "-";
			}
			$src.= "</TD>";
			my($l, $lv, $lname);
			foreach ('prepare', 'reclaim', 'destroy', 'earthquake', 'typhoon', 'fire', 'tsunami', 'starve', 'falldown', 'eruption', 'meteo', 'wide1', 'wide2', 'attack') {
				$l = $HcomplexAfter[$i]->{$_}[0];
				if(defined $l) {
					$lv =$HcomplexAfter[$i]->{$_}[1];
					$lname = landName($l, $lv);
					my(@limg) = @{$HlandImage[$l]};
					if($limg[0] eq '') {
						$src.= "<TD align='center'><img src='${HimageDir}/$HlandImage[$l]' alt='$lname'></TD>";
					} else {
						$src.= "<TD align='center'><img src='${HimageDir}/$limg[$lv]' alt='$lname'></TD>";
					}
				} else {
					$src.= "<TD align='center'>-</TD>";
				}
			}
			$l = $HcomplexAfter[$i]->{'move'}[0];
			$lv =$HcomplexAfter[$i]->{'move'}[1];
			if(defined $l) {
				if(!$l) {
					$src.= "<TD align='center'><img src='${HimageDir}/$HlandImage[$HlandWaste][0]' alt='$HlandName[$HlandWaste][0]'></TD>";
				} elsif(!$lv) {
					$src.= "<TD align='center'><img src='${HimageDir}/$HlandImage[$HlandSea][1]' alt='$HlandName[$HlandSea][1]'></TD>";
				} else {
					$src.= "<TD align='center'><img src='${HimageDir}/$HlandImage[$HlandSea][0]' alt='$HlandName[$HlandSea][0]'></TD>";
				}
			} else {
				$src.= "<TD align='center'>-</TD>";
			}
			$src.= "</TR>";
		}

		$src.= <<"END";
</TABLE>
 참고: '피해규모/파괴력1'은, 초기 값의 규모, 추가 값의 규모를 각각1랭크와 카운트하고, 식량과 자금 모두에 피해를 계산하는 숫자 값입니다.
<TABLE>
<TR $HbgInfoCell><TH rowspan=2>${HtagTH_}복합<BR>지형${H_tagTH}</TH><TH rowspan=2>${HtagTH_}명칭${H_tagTH}</TH>
<TH colspan=11>${HtagTH_}속성${H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TH>${HtagTH_}주변<BR>에마을<BR>발생${H_tagTH}</TH><TH>${HtagTH_}화재<BR>피해<BR>방지${H_tagTH}</TH><TH>${HtagTH_}태풍<BR>피해<BR>방지${H_tagTH}</TH>
<TH>${HtagTH_}역장<BR>발생${H_tagTH}</TH><TH>${HtagTH_}미사<br>이루<br>방위${H_tagTH}</TH><TH>${HtagTH_}함대<br>공격<br>방위${H_tagTH}</TH>
<TH>${HtagTH_}대잠<BR>공격<BR>대상${H_tagTH}</TH><TH>${HtagTH_}대함<BR>공격<BR>대상${H_tagTH}</TH><TH>${HtagTH_}대지<BR>공격<BR>대상${H_tagTH}</TH>
<TH>${HtagTH_}랜덤<BR>수입${H_tagTH}</TH><TH>${HtagTH_}랜덤<BR>수확${H_tagTH}</TH>
</TR>
END

		foreach $i (0..$#HcomplexName) {
			$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HcomplexImage[$i]'></TD><TH>$HcomplexName[$i]</TH>
END
			foreach (0x1, 0x2, 0x4, 0x10, 0x20, 0x40, 0x100, 0x200, 0x400, 0x1000, 0x2000) {
				$src.= "<TD align='center'>$ox[!($HcomplexAttr[$i] & $_)]</TD>";
			}
			$src.= "</TR>";
		}

		$src.= <<"END";
</TABLE>
<TABLE>
<TR $HbgInfoCell>
<TH rowspan=2>${HtagTH_}복합<BR>지형${H_tagTH}</TH><TH rowspan=2>${HtagTH_}명칭${H_tagTH}</TH>
<TH colspan=5>${HtagTH_}턴 플래그${H_tagTH}</TH>
<TH colspan=4>${HtagTH_}식량 플래그${H_tagTH}</TH>
<TH colspan=4>${HtagTH_}자금 플래그${H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TH>${HtagTH_}가 산<BR>대상${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH><TH>${HtagTH_}증가 값${H_tagTH}</TH><TH>${HtagTH_}최댓값${H_tagTH}</TH><TH>${HtagTH_}관광${H_tagTH}</TH>
<TH>${HtagTH_}가 산<BR>대상${H_tagTH}</TH><TH>${HtagTH_}초기 값${H_tagTH}</TH><TH>${HtagTH_}추가 값${H_tagTH}</TH><TH>${HtagTH_}최댓값${H_tagTH}</TH>
<TH>${HtagTH_}가 산<BR>대상${H_tagTH}</TH><TH>${HtagTH_}초기 값${H_tagTH}</TH><TH>${HtagTH_}추가 값${H_tagTH}</TH><TH>${HtagTH_}최댓값${H_tagTH}</TH>
</TR>
END
		my(@turnmax, @foodmax, @moneymax);
		foreach $i (0..$#HcomplexName) {
			$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HcomplexImage[$i]'></TD><TH>$HcomplexName[$i]</TH>
END
			my($tname, $tkind, $trate, $tmax, $thide);
			if($HcomplexTPCmax[$i]) {
				$tname = $HcomplexTPname[$i];
				$tkind = ($HcomplexTPkind[$i] eq '') ? '-' : $rankKind{$HcomplexTPkind[$i]};
				$trate = $HcomplexTPrate[$i]. $HcomplexTPunit[$i];
				$turnmax[$i] = $HcomplexTPCmax[$i] * $HcomplexTPrate[$i];
				$tmax = $turnmax[$i]. $HcomplexTPunit[$i];
				$thide = $hide[$HcomplexTPhide[$i]];
			} else {
				$tname = '-';
				$tkind = '-';
				$trate = '-';
				$tmax = '-';
				$thide = '-';
			}
			my($fkind, $fbase, $fplus, $fmax, $mkind, $mbase, $mplus, $mmax);
			$foodmax[$i] = $HcomplexFPCmax[$i]*$HcomplexFPplus[$i]+$HcomplexFPbase[$i];
			$moneymax[$i] = $HcomplexMPCmax[$i]*$HcomplexMPplus[$i]+$HcomplexMPbase[$i];
			if($foodmax[$i]) {
				$fkind = $rankKind{$HcomplexFPkind[$i]};
				$fmax = $foodmax[$i]. "0${HunitPop}규모";
				1 while $fmax =~ s/(.*\d)(\d\d\d)/$1,$2/;
				$fbase = $HcomplexFPbase[$i]. "0${HunitPop}규모";
				1 while $fbase =~ s/(.*\d)(\d\d\d)/$1,$2/;
				$fplus = $HcomplexFPplus[$i]. "0${HunitPop}규모";
				1 while $fplus =~ s/(.*\d)(\d\d\d)/$1,$2/;
			} else {
				$fkind = '-';
				$fmax = '-';
				$fbase = '-';
				$fplus = '-';
			}
			if($moneymax[$i]) {
				$mkind = $rankKind{$HcomplexMPkind[$i]};
				$mmax = $moneymax[$i]. "0${HunitPop}규모";
				1 while $mmax =~ s/(.*\d)(\d\d\d)/$1,$2/;
				$mbase = $HcomplexMPbase[$i]. "0${HunitPop}규모";
				1 while $mbase =~ s/(.*\d)(\d\d\d)/$1,$2/;
				$mplus = $HcomplexMPplus[$i]. "0${HunitPop}규모";
				1 while $mplus =~ s/(.*\d)(\d\d\d)/$1,$2/;
			} else {
				$mkind = '-';
				$mmax = '-';
				$mbase = '-';
				$mplus = '-';
			}

			$src.= <<"END";
<TD align='right'>$tkind</TD><TD align='center'>$tname</TD><TD align='right'>$trate</TD><TD align='right'>$tmax</TD><TD align='center'>$thide</TD>
<TD align='right'>$fkind</TD><TD align='right'>$fbase</TD><TD align='right'>$fplus</TD><TD align='right'>$fmax</TD>
<TD align='right'>$mkind</TD><TD align='right'>$mbase</TD><TD align='right'>$mplus</TD><TD align='right'>$mmax</TD>
</TR>
END
		}
		$src.= <<"END";
</TABLE>
END
		my @rankup;
		foreach $i (0..$#HcomplexName) {
			push(@rankup, $i) if(defined $HcomplexLevelValue[$i][0]);
		}
		my $col = $#rankup + 1;
		if(@rankup) {
			$src.= <<"END";
<TABLE><TR $HbgInfoCell><TH colspan=$col>${HtagTH_}플래그 값로 발전하다복합 지형${H_tagTH}</TH></TR><TR>
END
			my $rankflag = { 'turn'=>'턴 플래그', 'food'=>'식량 플래그', 'money'=>'자금 플래그' };
			foreach $i (@rankup) {
				$src.= <<"END";
<TD class='M'><TABLE>
<TR $HbgInfoCell><TH>${HtagTH_}지형${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH><TH>${HtagTH_}대상 플래그${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HcomplexImage[$i]'></TD><TH>$HcomplexName[$i]</TH><TH>$rankflag->{"$HcomplexLevelKind[$i]"}</TH>
END
				my $maxflag = ($HcomplexLevelKind[$i] eq 'turn') ? $turnmax[$i] : ($HcomplexLevelKind[$i] eq 'food') ? $foodmax[$i] : $moneymax[$i];
				my($cflag);
				foreach (0..$#{$HcomplexLevelValue[$i]}) {
					$cflag = $HcomplexLevelValue[$i][$_];
					if($cflag) {
						$cflag.= "0${HunitPop}규모" if($HcomplexLevelKind[$i] ne 'turn');
						$cflag.= "이상" if($HcomplexLevelValue[$i][$_] < $maxflag);
						1 while $cflag =~ s/(.*\d)(\d\d\d)/$1,$2/;
					} else {
						$cflag = '-';
					}
					$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HcomplexSubImage[$i][$_]'></TD><TD align='center'>$HcomplexSubName[$i][$_]</TD><TD align='center'>$cflag</TD>
END
				}
				$src.= <<"END";
</TABLE></TD>
END
			}
			$src.= <<"END";
</TR></TABLE>
참고: 주·발전하고도외관찰와 명칭이변화하다만에서  실제의 기능에특별히변화는 없습니다.
<BR>
END
		}
		$src.= <<"END";
<TABLE>
<TR $HbgInfoCell>
<TH colspan=4>${HtagTH_}복합 지형 개발 명령 ${turnStr[1]}■${H_tagComName}<small>턴을 소비하다</small> ${turnStr[0]}■${H_tagComName}<small>턴을 소비하지 않음</small>${H_tagTH}</TH>
<TH colspan=4>${HtagTH_}대상 플래그${H_tagTH}</TH><TH colspan=3>${HtagTH_}턴 플래그 재설정 시${H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TH>${HtagTH_}명칭${H_tagTH}</TH><TH>${HtagTH_}대상 지형${H_tagTH}</TH><TH>${HtagTH_}비용${H_tagTH}</TH><TH>${HtagTH_}설명${H_tagTH}</TH>
<TH>${HtagTH_}설치만${H_tagTH}</TH><TH>${HtagTH_}턴${H_tagTH}</TH><TH>${HtagTH_}식량${H_tagTH}</TH><TH>${HtagTH_}자금${H_tagTH}</TH>
<TH>${HtagTH_}증가대상${H_tagTH}</TH><TH>${HtagTH_}플래그<BR>의 배율${H_tagTH}</TH><TH>${HtagTH_}처리후<BR>의 지형${H_tagTH}</TH>
</TR>
END

		foreach $i (0..$#HcomplexComName) {
			my $cost = (!$HcomplexComCost[$i]) ? '무료' : "$HcomplexComCost[$i]$HunitMoney";
			1 while $cost =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$src.= <<"END";
<TR $HbgInfoCell><TH>${turnStr[$HcomplexComTurn[$i]]}$HcomplexComName[$i]${H_tagComName}</TH>
<TD align='center'>$HcomplexName[$HcomplexComKind[$i]]</TD><TD align='right'>$cost</TD><TD align='left'>$HcomplexComMsgs[$i]</TD>
END
			my $turn = $HcomplexComFlag[$i] & 0x1;
			my $food = $HcomplexComFlag[$i] & 0x2;
			my $money = $HcomplexComFlag[$i] & 0x4;
			my($bonly);
			$bonly = 1 if(!$turn && !$food && !$money);
			my($lname, $kind, $ratio);
			if($turn) {
				if($HcomplexComTFRL[$i][0] ne '') {
					$lname = landName($HcomplexComTFRL[$i][0], $HcomplexComTFRL[$i][1]);
				} else {
					$lname = $HcomplexName[$HcomplexComKind[$i]];
				}
				my $income = $HcomplexComTFInCome[$i];
				$kind = $rankKind{$income->{'type'}};
				$ratio = $income->{'ratio'};
			} else {
				$lname = '-';
				$kind = '-';
				$ratio = '-';
			}

			$src.= <<"END";
<TD align='center'>$ox[!$bonly]</TD><TD align='center'>$ox[!$turn]</TD><TD align='center'>$ox[!$food]</TD><TD align='center'>$ox[!$money]</TD>
<TD align='center'>$kind</TD><TD align='right'>$ratio</TD><TD align='center'>$lname</TD>
</TR>
END

		}
		$src.= "</TABLE>";
	}

# 코어
#-------------------------

	$src.= <<"END";
<HR>
<a name='core'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 코어</H3></a>
<TABLE>
<TR $HbgInfoCell><TH colspan='2'>${HtagTH_}코어${H_tagTH}</TH><TH>${HtagTH_}설치 지형등${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HlandImage[$HlandCore][0]'></TD><TH>$HlandName[$HlandCore][0]</TH>
<TD align='left'>
<!--- 코어 --->
·평지에 설치. 개간과 굴착이 가능합니다.<BR>
·운석, 분화, 지반 침하, 광역 피해(2Hex)로 파괴됩니다.
</TD></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HlandImage[$HlandCore][1]'></TD><TH>$HlandName[$HlandCore][1]</TH>
<TD align='left'>
<!--- 해상 코어 --->
·얕은 바다에설치. 매립, 굴착이 가능.<BR>
·운석, 분화, 광역 피해(2Hex)로 파괴됩니다.
</TD></TR>
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HlandImage[$HlandCore][2]'></TD><TH>$HlandName[$HlandCore][2]</TH>
<TD align='left'>
<!--- 해저코어 --->
·바다에설치. 매립이 가능.<BR>
·운석, 분화, 광역 피해(1Hex)로 파괴됩니다.
</TD></TR>
</TABLE></TD>
건설 명령을 사용할까요? <B>$useStr[$HuseCore]</B>
END

	if($HuseCore && $HuseCoreLimit) {
		$src.= " (주!건설 가능한 기간은 새로 등록된 $AfterName의 <B>개발 기간만</B>입니다)";
	}
	my $coremax = (!$HcoreMax) ? '무제한' : $HcoreMax;
	my $durablec;
	if($HdurableCore){
		$durablec = "<B>최대$HdurableCore 까지 상승</B>";
	} else {
		$durablec = "<B>없음</B>(일반)";
	}
	my $hidec = '';
	$hidec = "($HlandName[$HlandCore][0] => <B>숲</B>,$HlandName[$HlandCore][1]·$HlandName[$HlandCore][2] => <B>바다</B>)" if($HcoreHide);
	my @coreless = ('침몰하지 않음', '침몰함', '사멸 판정 회피 기능 발동');
	$src.= <<"END";
<BR><BR>
보유 가능 최대 수 <B>$coremax</B><BR>
코어의 내구력 설정? $durablec<BR>
코어를 위장할까요? <B>$doStr[$HcoreHide]</B> $hidec<BR><BR>
코어를 보유하지 않은 섬을 침몰 처리할까요? <B>$coreless[$HcorelessDead]</B> (주의! 설정과 관계없이 새로 등록된 $AfterName의 <B>개발 기간에는 침몰하지 않습니다</B>.)<BR>
END

# 해군
#-------------------------

		$src.= <<"END";
<HR>
<a name='navy'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 해군</H3></a>
END
	if($HnavyName[0] eq '') {
		$src.= "해군은<B>없습니다!</B><BR>";
	} else {
		$src.= "해군(군항및 함정)의 경험치의 최댓값 <B>$HmaxExpNavy</B><BR>";
		$src.= "<TABLE><TR $HbgInfoCell><TH>해군의 레벨</TH>";
		foreach (1..$maxNavyLevel) {
			$src.= "<TD align='center'><B>&nbsp;$_&nbsp;</B></TD>";
		}
		$src.= "</TR><TR $HbgInfoCell><TH>레벨 UP 에필요한경험치</TH><TD align='center'>0</TD>";
		foreach (@navyLevelUp) {
			$src.= "<TD align='center'>$_</TD>";
		}
		$src.= "</TR><TR $HbgInfoCell><TH>공격 횟수</TH>";
		foreach (1..$maxNavyLevel) {
			$src.= "<TD align='center'>+$HnavyFirePlus[int($_/2)]</TD>";
		}
		$src.= "</TR><TR $HbgInfoCell><TH>내구력</TH>";
		foreach (1..$maxNavyLevel) {
			$src.= "<TD align='center'>+$HnavyMaxHpPlus[int(($_ - 1)/2)]</TD>";
		}
		$src.= "</TR></TABLE>";

		$src.= <<"END";
참고: '공격 횟수''내구력'은, 해군의 기본스페쿠에서 미타증가분.<BR>
<BR>
잔해 매각 시 금괴가 발생할 확률 <B>${HnavyProbWreckGold}%</B><BR>
다른 $AfterName에 파견 중인 함대도 보급할까요? <B>$doStr[$HnavySupplyFlag]</B> 참고: 이 설정이 '하지 않음'이면 '보급 능력' 보유 여부가 의미를 가집니다.<BR><BR>
END

		my $priList;
		my $pFlag = 0;
		foreach (@HpriStr) {
			$priList.= "⇒" if($pFlag);
			$pFlag++;
			$priList.= $_;
		}
		my $navyMaximum = (!$HnavyMaximum ? '무제한' : "$HnavyMaximum");
		my $fleetMaximum = (!$HfleetMaximum ? '무제한' : "$HfleetMaximum");
		my $portRetention1 = (!$HportRetention ? ' 군항 수에 한<B>제한없음</B>' : " 군항항구 1개에 관련<B>$HportRetention</B>까지");
		my $portRetention2 = (!$HportRetention ? '무제한' : "$HportRetention");
		my $nCol = 3;
		$nCol++ if($HmaxComNavyLevel);
		$src.= <<"END";
'일제 공격' 명령을 사용할까요? <B>$useStr[$HuseTarget]</B><BR><BR>
자기 $AfterName이외에 있는 함대의 내구력을 표시할까요? <B>$doStr[$HnavyShowInfo]</B><BR>
공격한 함정 자신이 사거리 범위에 있는 경우 자폭(피격)도 허용할까요? <B>$anStr[$HnavySelfAttack]</B><BR>
<BR>함정 공격에 피격된 함정이나 지형이 자기 $AfterName인 경우 무해화할까요? <B>$saftyStr[$HnavySafetyZone]</B><BR>
 무해화가 무효화될 확률 <B>${HnavySafetyInvalidp}%</B>(무해화 기능이 발동하는 상황에서 판정)<BR>
<BR>사거리 안 지형 공격 우선순위(기본값) <B>$priList</B>(${nearfar[$Hnearfar]})</B><BR>
<BR>보유 가능 함정 수 <B>$navyMaximum</B> (1함대주변 <B>$fleetMaximum</B>$portRetention1)
무역 능력이 있는 함정이 파견되어 있지 않은 $AfterName에는 지원 명령을 사용할 수 없게 할까요? <B>$doStr[$HtradeAbility]</B><BR>
<BR>
소속 불명의 함정이 출현할까요? <B>$doStr[$HnavyUnknown]</B><BR>
END

		if($HnavyUnknown) {
			$HdisNavy *= 0.01;# 소속 불명 함정
			$HdisNavyBF *= 0.01;# 소속 불명 함정(Battle Field)
			$HdisNavyBF = $HdisNavy*2 if(!$HdisNavyBF);
			$src.= "단위 면적 주변의 함정 출현율 <B>${HdisNavy}%</B> (전장:<B>${HdisNavyBF}%</B>)<BR>";
		}

		$src.= <<"END";
<TABLE>
<TR $HbgInfoCell><TH colspan='$nCol'>${HtagTH_}해군${H_tagTH}</TH>
END

		$src.= "<TH rowspan=2>${HtagTH_}소속<br>불명함<br>출현인구<br>(비율)${H_tagTH}</TH>" if($HnavyUnknown);

		$src.= <<"END";
<TH>${HtagTH_}보유 가능상한${H_tagTH}</TH><TH colspan=2>${HtagTH_}내구력${H_tagTH}</TH><TH rowspan=2>${HtagTH_}파괴<br>력${H_tagTH}</TH><TH rowspan=2>${HtagTH_}공격<br>수${H_tagTH}</TH><TH rowspan=2>${HtagTH_}공격<br>범위${H_tagTH}</TH><TH rowspan=2>${HtagTH_}사거리<br>범위${H_tagTH}</TH><TH colspan=2>${HtagTH_}경험치${H_tagTH}</TH><TH rowspan=2>${HtagTH_}건조<br>비용${H_tagTH}</TH><TH rowspan=2>${HtagTH_}탄약<br>1발<br>의<br>비용${H_tagTH}</TH><TH rowspan=2>${HtagTH_}유지<br>비용${H_tagTH}</TH><TH rowspan=2>${HtagTH_}유지<br>식량${H_tagTH}</TH><TH rowspan=2>${HtagTH_}잔해<br>확률${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TH>${HtagTH_}자$AfterName${H_tagTH}</TH><TH>${HtagTH_}타$AfterName${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH>
END

		$src.= "<TH>${HtagTH_}건조<br>레벨${H_tagTH}</TH>" if($HmaxComNavyLevel);

		$src.= <<"END";
<TD align='center'>1함대:$fleetMaximum<BR>$portRetention2/항구 1개<BR>합계:$navyMaximum</TD>
<TH>${HtagTH_}초기${H_tagTH}</TH><TH>${HtagTH_}최종${H_tagTH}</TH>
<TH>${HtagTH_}격침<br> 시${H_tagTH}</TH><TH>${HtagTH_}건조<br> 시${H_tagTH}</TH>
</TR>
END

		foreach $i (0..$#HnavyName) {
			$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><span class='myFleetCell'><img src='${HimageDir}/$HnavyImage[$i]' class='myFleet'></span></TD><TD align='right'><img src='${HimageDir}/$HnavyImage[$i]'></TD><TH>$HnavyName[$i]</TH>
END

			my($level, $exp);
			my $maxComNavyLevel = $HmaxComNavyLevel-1;
			my $bExp = $HnavyBuildExp[$i];
			foreach (0..$maxComNavyLevel) {
				if($i <= $HcomNavyNumber[$_]) {
					$level = $_ + 1;
					last;
				}
				$level = '★';
			}
			if($level == 1) {
				$exp = 0;
			} elsif($level ne '★') {
				$exp = $HcomNavyBorder[$level-2];
			} else {
				$exp = '불명';
				$bExp = '-';
			}
			$src.= "<TD align='center'><B>${level}</B><BR>(${exp})</TD>" if($HmaxComNavyLevel);
			if($HnavyUnknown) {
				my $unknownpop = ($HdisNavyBorder[$i]) ? $HdisNavyBorder[$i]. $HunitPop : '-';
				1 while $unknownpop =~ s/(.*\d)(\d\d\d)/$1,$2/;
				my $unknownratio = $HdisNavyRatio[$i];
				$src.= "<TD align='right'>$unknownpop<BR>(${unknownratio})</TD>";
			}
			my $kindMax = (!$HnavyKindMax[$i]) ? '무제한' : $HnavyKindMax[$i];
			my $damage = $HnavyDamage[$i];
			$damage = 1 if(!$damage);
			my $nCost = (!$HnavyCost[$i]) ? "-" : ($HnavyCost[$i]> 0 ? "$HnavyCost[$i]$HunitMoney" : "<DIV class='Money' align=left>수입</DIV>". - $HnavyCost[$i]. "$HunitMoney");
			1 while $nCost =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $sCost = (!$HnavyShellCost[$i]) ? "-" : ($HnavyShellCost[$i]> 0 ? "$HnavyShellCost[$i]$HunitMoney" : "<DIV class='Money' align=left>수입</DIV>". - $HnavyShellCost[$i]. "$HunitMoney");
			1 while $sCost =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $nMoney = (!$HnavyMoney[$i]) ? "-" : ($HnavyMoney[$i]> 0 ? "$HnavyMoney[$i]$HunitMoney" : "<DIV class='Money' align=left>수입</DIV>". - $HnavyMoney[$i]. "$HunitMoney");
			1 while $nMoney =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $nFood = (!$HnavyFood[$i]) ? "-" : ($HnavyFood[$i]> 0 ? "$HnavyFood[$i]$HunitFood" : "<DIV class='Food' align=left>수확</DIV>". - $HnavyFood[$i]. "$HunitFood");
			1 while $nFood =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$src.= <<"END";
<TD align='center'>$kindMax</TD><TD align='right'>$HnavyHP[$i]</TD><TD align='right'>$HnavyMaxHP[$i]</TD><TD align='right'>$damage</TD><TD align='right'>$HnavyFire[$i]</TD><TD align='right'>$HnavyFireHex[$i]</TD><TD align='right'>$HnavyFireRange[$i]</TD><TD align='right'>$HnavyExp[$i]</TD><TD align='right'>$bExp</TD>
<TD align='right'>$nCost</TD><TD align='right'>$sCost</TD><TD align='right'>$nMoney</TD><TD align='right'>$nFood</TD><TD align='right'>$HnavyProbWreck[$i]%</TD>
</TR>
END
		}

		$src.= "</TABLE>";
		if($HmaxComNavyLevel) {
			$src.= " 참고: '레벨'의 괄호 안은 건조에필요한'총 획득 경험치'";
			$src.= "(건조에는,<B>군항의 레벨도건조레벨와 같은 숫자 값이필요</B>이 됩니다)" if($HmaxComPortLevel);
		}

		$src.= <<"END";
<BR><TABLE>
<TR $HbgInfoCell><TH colspan=3>${HtagTH_}해군${H_tagTH}</TH>
<TH colspan=25>${HtagTH_}능력${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TH>${HtagTH_}자$AfterName${H_tagTH}</TH><TH>${HtagTH_}타$AfterName${H_tagTH}</TH><TH>${HtagTH_}명칭${H_tagTH}</TH>
<TH>${HtagTH_}이동<br>이<br>속이${H_tagTH}</TH><TH>${HtagTH_}이동이<br>와 해도<br>속이${H_tagTH}</TH><TH>${HtagTH_}잠수하다<br>(부상률)${H_tagTH}</TH>
<TH>${HtagTH_}선 줄<br>이동${H_tagTH}</TH><TH>${HtagTH_}미사<br>이루<br>방위${H_tagTH}</TH><TH>${HtagTH_}함대<br>공격<br>방위${H_tagTH}</TH><TH>${HtagTH_}이동<BR>조종<BR>(기함)${H_tagTH}</TH>
<TH>${HtagTH_}대잠<br>공격${H_tagTH}</TH><TH>${HtagTH_}대함<br>공격${H_tagTH}</TH><TH>${HtagTH_}대지<br>공격${H_tagTH}</TH><TH>${HtagTH_}유린<br>이동${H_tagTH}</TH>
<TH>${HtagTH_}어뢰계${H_tagTH}</TH><TH>${HtagTH_}함포계${H_tagTH}</TH><TH>${HtagTH_}함재기계${H_tagTH}</TH><TH>${HtagTH_}해저<br>탐색검사<br>능력${H_tagTH}</TH>
<TH>${HtagTH_}보급<br>능력${H_tagTH}</TH><TH>${HtagTH_}무역<br>능력${H_tagTH}</TH><TH>${HtagTH_}바다도적<br>능력${H_tagTH}</TH><TH>${HtagTH_}육지<br>굴착<br>능력${H_tagTH}</TH>
<TH>${HtagTH_}목표<br>보정${H_tagTH}</TH><TH>${HtagTH_}몸통박치기<br>가능${H_tagTH}</TH><TH>${HtagTH_}명중<br>률 UP${H_tagTH}</TH><TH>${HtagTH_}방파<br>능력${H_tagTH}</TH>
<TH>${HtagTH_}파괴력<br>무작위<br>max(률)${H_tagTH}</TH><TH>${HtagTH_}융단<br>폭격${H_tagTH}</TH>
</TR>
END

		foreach $i (0..$#HnavyName) {
			$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><span class='myFleetCell'><img src='${HimageDir}/$HnavyImage[$i]' class='myFleet'></span></TD><TD align='right'><img src='${HimageDir}/$HnavyImage[$i]'></TD><TH>$HnavyName[$i]</TH>
END

			my $submarineSurface = ($HnavySpecial[$i] & 0x4) ? $HsubmarineSurface[$i]. '%' : '';
			my @fireName = ([($HnavyFireName[$i][0] ne '' ? $HnavyFireName[$i][0] : '어뢰발사'),'-'], [($HnavyFireName[$i][1] ne '' ? $HnavyFireName[$i][1] : '함포사격'),'-'], [($HnavyFireName[$i][2] ne '' ? $HnavyFireName[$i][2] : '함재기 폭격'),'-']);
			my($towardhex, $oilp, $supplyhex, $pirateshex, $firehexp, $bouhahex, $damagemaxp, $terrorhexnv);
			$towardhex = "<br>($HnavyTowardRange[$i]Hex)" if($HnavySpecial[$i] & 0x800);
			if($HnavySpecial[$i] & 0x8000) {
				$oilp = '<br>'. $Hoilp[$i] * 0.1. '%';
				my $probecost = int($Hoilp[$i] * $HcomCost[$HcomDestroy]). $HunitMoney;
				1 while $probecost =~ s/(.*\d)(\d\d\d)/$1,$2/;
				$oilp.= "<br><span style='text-decoration: overline;'>". $probecost. '</span>';
			}
			$supplyhex = "<br>($HnavySupplyRange[$i]Hex)" if($HnavySpecial[$i] & 0x10000);
			$pirateshex = "<br>($HpiratesHex[$i]Hex)" if($HnavySpecial[$i] & 0x40000);
			$firehexp = "<br>($Hfirehexp[$i]%)" if($HnavySpecial[$i] & 0x4000000);
			$bouhahex = "<br>($HbouhaHex[$i]Hex)" if($HnavySpecial[$i] & 0x8000000);
			$damagemaxp = "<br>$HdamageMax[$i]($Hdamagep[$i]%)" if($HnavySpecial[$i] & 0x10000000);
			$terrorhexnv = "<br>($HnavyTerrorHex[$i]Hex)" if($HnavySpecial[$i] & 0x20000000);
			$src.= <<"END";
<TD align='center'>$ox[!($HnavySpecial[$i] & 0x1)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x2)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x4)]<BR>$submarineSurface</TD>
<TD align='center'>$ox[!($HnavySpecial[$i] & 0x10)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x20)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x40)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x80)]</TD>
<TD align='center'>$ox[!($HnavySpecial[$i] & 0x100)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x200)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x400)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x800)]$towardhex</TD>
<TD align='center'>$fireName[0][!($HnavySpecial[$i] & 0x1000)]</TD><TD align='center'>$fireName[1][!($HnavySpecial[$i] & 0x2000)]</TD><TD align='center'>$fireName[2][!($HnavySpecial[$i] & 0x4000)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x8000)]$oilp</TD>
<TD align='center'>$ox[!($HnavySpecial[$i] & 0x10000)]$supplyhex</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x20000)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x40000)]$pirateshex</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x80000)]</TD>
<TD align='center'>$ox[!($HnavySpecial[$i] & 0x1000000)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x2000000)]</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x4000000)]$firehexp</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x8000000)]$bouhahex</TD>
<TD align='center'>$ox[!($HnavySpecial[$i] & 0x10000000)]$damagemaxp</TD><TD align='center'>$ox[!($HnavySpecial[$i] & 0x20000000)]$terrorhexnv</TD>
</TR>
END
		}

		$src.= "</TABLE>";
		$src.= " 참고: '해저 탐사능력'은, 이동의 시마다 조사 비용이 듭니다.(유지비로 계산됩니다)<BR>";
		$src.= " 참고: '몸통박치기'는, 내구력과 관계없이 상대까지 침몰시키는 능력입니다.";
		if($HnavySafetyZone == 2) {
			$src.= "단, 자기 섬이나 우호국의 함정에는 무효입니다.<BR>";
		} elsif($HnavySafetyZone == 1) {
			$src.= "단, 자기 섬의 함정만은 무효입니다.<BR>";
		} else {
			$src.= "예에, 자기 섬 함정에도 몸통박치기는 유효합니다.<BR>";
		}
		if($HsuicideAbility) {
			$src.= " 기함·이동 조종을 시없어도 이동 시에진행 방향에 함정이 있으면 임의로 충돌합니다.<BR>";
		} else {
			$src.= " 기함·이동 조종을 하지 않으면 몸통박치기를 하지 않습니다.<BR>";
		}
		$src.= " 참고: '파괴력무작위'는, 률의 비율에서 난수가 발생하면 max에서 설정한 수치를 최대값으로 파괴력이 변경됩니다. 난수가 발생하지 않으면 일반 파괴력을 사용합니다.<BR>";
		$src.= " 참고: '융단 폭격'은, 첫 탄의 착탄 지점의 주변(설정 Hex)에빠짐없이 착탄합니다. 단, 공격 수가 Hex 수가 부족한 경우 일부 지점은 착탄하지 않습니다.<BR>";
	}

# 방위 시설·기지
#-------------------------

	my $dbMax = (!$HdBaseMax) ? '무제한' : $HdBaseMax. '기준';
	my $durable;
	if($HdurableDef){
		$durable = "<B>최대$HdurableDef 까지 상승</B>(자폭은 수량'$HdefExplosion'을지정하고추가건설)";
	} else {
		$durable = "<B>없음</B>(일반)";
	}
	my $defLevelUp = '';
	$defLevelUp = "참고: 내구력이<B>$HdefLevelUp 이상</B>로 강화방위 시설(방위 범위 주변 3Hex)이 됨"if($HdefLevelUp);
	$src.= <<"END";
<HR>
<a name='def'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 방위 시설</H3></a>
방위 시설의 보유 가능 최대 수 <B>$dbMax</B><BR>
방위 시설의 내구력 설정? $durable $defLevelUp<BR>
방위 시설은, 괴수에게 밟힘된 시자폭할까요? <B>$doStr[$HdBaseAuto]</B><BR>
방위 시설을 숲으로 위장할까요? <B>$doStr[$HdBaseHide]</B><BR>
자$AfterName 공격은 자$AfterName의 방위 권역(타$AfterName의 방위 권역에서 없는지점)에 착탄하게 할까요?
<BR>함정 공격:<B>$nodefStr[$HdBaseSelfNoDefenceNV]</B> 미사일 공격:<B>$nodefStr[$HdBaseSelfNoDefenceMS]</B> 괴수의 미사일 공격:<B>$nodefStr[$HdBaseSelfNoDefenceMA]</B><BR>
END

# 기지·미사일
#-------------------------
	$src.= <<"END";
<HR>
<a name='base'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 기지·미사일</H3></a>
미사일 기지를 사용할까요? <B>$useStr[$HuseBase]</B><BR>
해저 기지를 사용할까요? <B>$useStr[$HuseSbase]</B><BR>
END

	if($HuseBase || $HuseSbase) {
		$src.= <<"END";
<BR>
기지의 경험치의 최댓값 <B>$HmaxExpPoint</B><BR>
END

		$src.= "<TABLE><TR><TD class='M'>";
		$src.= "<TABLE><TR $HbgInfoCell><TH>미사일 기지의 레벨</TH>";
		foreach (1..$maxBaseLevel) {
			$src.= "<TD align='center'><B>&nbsp;$_&nbsp;</B></TD>";
		}
		$src.= "</TR><TR $HbgInfoCell><TH>레벨 UP 에필요한경험치</TH><TD align='center'>0</TD>";
		foreach (@baseLevelUp) {
			$src.= "<TD align='center'>$_</TD>";
		}
		$src.= "</TR></TABLE>";
		$src.= "</TD><TD class='M'>";
		$src.= "<TABLE><TR $HbgInfoCell><TH>해저 기지의 레벨</TH>";
		foreach (1..$maxSBaseLevel) {
			$src.= "<TD align='center'><B>&nbsp;$_&nbsp;</B></TD>";
		}
		$src.= "</TR><TR $HbgInfoCell><TH>레벨 UP 에필요한경험치</TH><TD align='center'>0</TD>";
		foreach (@sBaseLevelUp) {
			$src.= "<TD align='center'>$_</TD>";
		}
		$src.= "</TR></TABLE>";
		$src.= "</TD></TR></TABLE>";
		$src.= <<"END";
<BR>
ST 미사일을 사용할까요? <B>$useStr[$HuseMissileST]</B><BR>
<BR>
사거리 안에 괴수·거대괴수가 없으면, 미사일 발사를 중지할까요? <B>$doStr[$HtargetMonster]</B><BR>
미사일에 피격된 함정이나 지형이 자기 $AfterName인 경우 무해화할까요? <B>$saftyStr[$HmissileSafetyZone]</B><BR>
 무해화가 무효화될 확률 <B>${HmissileSafetyInvalidp}%</B>(무해화 기능이 발동하는 상황에서 판정)<BR>
END

		$src.= <<"END";
<TABLE><TR $HbgInfoCell>
<TH rowspan='2'>${HtagTH_}미사일명칭${H_tagTH}</TH><TH rowspan='2'>${HtagTH_}비용${H_tagTH}</TH><TH rowspan='2'>${HtagTH_}턴<BR>소비${H_tagTH}</TH><TH rowspan='2'>${HtagTH_}파괴력${H_tagTH}</TH><TH rowspan='2'>${HtagTH_}오차${H_tagTH}</TH>
<TH colspan='5'>${HtagTH_}속성${H_tagTH}</TH></TR>
<TR $HbgInfoCell>
<TH>${HtagTH_}ST${H_tagTH}</TH><TH>${HtagTH_}육파괴${H_tagTH}</TH><TH>${HtagTH_}융단<br>폭격${H_tagTH}</TH>
<TH>${HtagTH_}경화<br>무효${H_tagTH}</TH><TH>${HtagTH_}잠수<br>무효${H_tagTH}</TH>
</TR>
END
		foreach $i (0..$#HmissileName) {
			next if ($STcheck{$HcomMissile[$i]} && (!$HuseMissileST || $Htournament));
			$src.= <<"END";
<TR $HbgInfoCell><TH>$HmissileName[$i]</TH>
END
			my $mCost = (!$HmissileCost[$i]) ? "-" : "$HmissileCost[$i]$HunitMoney";
			1 while $mCost =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my($terrorhexms);
			$terrorhexms = "<br>($HmissileTerrorHex[$i]Hex)" if($HmissileSpecial[$i] & 0x4);
			my $mdamage = $HmissileDamage[$i];
			$mdamage = 1 if($mdamage <= 0);
			$src.= <<"END";
<TD align='right'>$mCost</TD><TD align='right'>$anStr[$HmissileTurn[$i]]</TD><TD align='right'>$mdamage</TD><TD align='right'>$HmissileErr[$i]Hex</TD>
<TD align='center'>$ox[!($HmissileSpecial[$i] & 0x1)]</TD><TD align='center'>$ox[!($HmissileSpecial[$i] & 0x2)]</TD><TD align='center'>$ox[!($HmissileSpecial[$i] & 0x4)]$terrorhexms</TD>
<TD align='center'>$ox[!($HmissileSpecial[$i] & 0x10)]</TD><TD align='center'>$ox[!($HmissileSpecial[$i] & 0x20)]</TD>
</TR>
END
		}
		$src.= "</TABLE>";
		$src.= " 참고: '융단 폭격'은, 첫 탄의 착탄 지점의 주변(설정 Hex)에빠짐없이 착탄합니다. 단, 기지마다 공격에서 있어서,1츠의 기지에서 공격 수가 Hex 수가 부족한 경우 일부 지점은 착탄하지 않습니다.<BR>";
	}
# 날씨
#-------------------------

	$src.= <<"END";
<HR>
<a name='weather'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 날씨</H3></a>
날씨를 사용할까요? <B>$useStr[$HuseWeather]</B><BR>
END


	$src.= <<"END" if($HuseWeather);
<TABLE>
<TR $HbgInfoCell><TH colspan=4>${HtagTH_}기상요소${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TH>기온</TH><TD align='center'>-10℃ ~ 40℃</TD><TD>0℃이하가 되면 수확량이 절반으로 감소.</TD></TR>
<TR $HbgInfoCell><TH>기압</TH><TD align='center'>900hPa ~ 1,100hPa</TD><TD>950hPa 이하에서 태풍발생확률이10배. 변화할 시 풍속에 영향을 줍니다.</TD></TR>
<TR $HbgInfoCell><TH>습도</TH><TD align='center'>0% ~ 100%</TD><TD>지반에영향을 및보스.</TD></TR>
<TR $HbgInfoCell><TH>풍속</TH><TD align='center'>0m/s ~ 50m/s</TD><TD>20m/s 이상이면 태풍 확률이 상승하고, 40m/s 이상이면 쓰나미 확률이 상승합니다. 파력에도 영향을 줍니다.</TD></TR>
<TR $HbgInfoCell><TH>지반</TH><TD align='center'>0 ~ 100</TD><TD>90 이상이면 지반 침하 확률이 상승하고, 100이면 지반 침하가 발생합니다. 단, 육지 면적이 한계를 초과하지 않으면 발생하지 않습니다.</TD></TR>
<TR $HbgInfoCell><TH>파력</TH><TD align='center'>0 ~ 100</TD><TD>90이상에서 쓰나미 확률상승.100에서 쓰나미발생.</TD></TR>
</TABLE>
<TABLE>
<TR $HbgInfoCell>
<TH colspan=2 rowspan=3>${HtagTH_}$HweatherName[0]${H_tagTH}</TH>
<TH rowspan=3>${HtagTH_}비율${H_tagTH}</TH>
<TH colspan=3>${HtagTH_}이벤트${H_tagTH}</TH></TR>
<TR $HbgInfoCell>
<TH>${HtagTH_}기온변화${H_tagTH}</TH>
<TH>${HtagTH_}기압변화${H_tagTH}</TH>
<TH>${HtagTH_}습도변화${H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TD align='center'>±$HrKion</TD>
<TD align='center'>±$HrKiatu</TD>
<TD align='center'>±$HrSitudo</TD>
</TR>
END

	if($HuseWeather) {
		foreach $i (1..$#HweatherName) {
			my(@wt, $j, $k);
			$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HweatherImage[$i]'></TD>
<TH>$HweatherName[$i]</TH>
<TD align='center'>$HweatherRatio[$i]</TD>
END
			foreach $j (0..2) {
				$wt[$j] = ($HweatherSpecial[$i] & 0xF) - 8;
				$wt[$j] = ($wt[$j] == -8 || !$wt[$j]) ? '-' : $wt[$j]*$HweatherSpecialRatio[$j];
				$wt[$j] = ($wt[$j]> 0) ? "<FONT color=blue>+$wt[$j]</FONT>" : "<FONT color=red>$wt[$j]</FONT>";
				$src.= "<TD align='right'>$wt[$j]</TD>";
				$HweatherSpecial[$i]>>= 4;
			}
			$src.= "</TR>";
		}
		$src.= "</TABLE><BR>";
	}

# 재해
#-------------------------

	$HdisEarthquake *= 0.1; # 지진
	$HdisTsunami *= 0.1; # 쓰나미
	$HdisTyphoon *= 0.1; # 태풍
	$HdisMeteo *= 0.1; # 운석
	$HdisHugeMeteo *= 0.1; # 거대운석
	$HdisEruption *= 0.1; # 분화
	$HdisFire *= 0.1; # 화재
	$HdisMaizo *= 0.1; # 매장금
	$HdisFalldown *= 0.1; # 지반 침하
	$HdisMonster *= 0.01;# 괴수
	$HdisMonsterBF *= 0.01;# 괴수(Battle Field)
	$HdisHuge *= 0.01;# 거대괴수
	$HdisHugeBF *= 0.01;# 거대괴수(Battle Field)
	$HdisMonsterBF = $HdisMonster*2 if(!$HdisMonsterBF);
	$HdisHugeBF = $HdisHuge*2 if(!$HdisHugeBF);

	$src.= <<"END";
<HR>
<a name='disaster'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 재해</H3></a>
<TABLE>
<TR $HbgInfoCell><TH rowspan=2>${HtagTH_}지진${H_tagTH}</TH><TH rowspan=2>${HtagTH_}쓰나미${H_tagTH}</TH><TH rowspan=2>${HtagTH_}태풍${H_tagTH}</TH><TH rowspan=2>${HtagTH_}운석${H_tagTH}</TH><TH rowspan=2>${HtagTH_}거대운석${H_tagTH}</TH><TH rowspan=2>${HtagTH_}분화${H_tagTH}</TH><TH rowspan=2>${HtagTH_}화재${H_tagTH}</TH><TH rowspan=2>${HtagTH_}매장금${H_tagTH}</TH><TH colspan=2>${HtagTH_}지반 침하${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TH>${HtagTH_}안정 전체한계의 면적${H_tagTH}</TH><TH>${HtagTH_}초과한 경우 확률${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TD align='right'>${HdisEarthquake}%</TD><TD align='right'>${HdisTsunami}%</TD><TD align='right'>${HdisTyphoon}%</TD><TD align='right'>${HdisMeteo}%</TD><TD align='right'>${HdisHugeMeteo}%</TD><TD align='right'>${HdisEruption}%</TD><TD align='right'>${HdisFire}%</TD><TD align='right'>${HdisMaizo}%</TD><TD align='right'>$HdisFallBorder$HunitArea(${HdisFallBorder}Hex)</TD><TD align='right'>${HdisFalldown}%</TD></TR>
</TABLE>
쓰나미가 해군에부여 가능 피해의 최댓값 <B>$HdisTsunamiDmax</B><BR>
END

	# 섬의 좌표 수
	$HpointNumber = $HislandSizeX * $HislandSizeY;

	$src.= <<"END";
바다의 면적플래그 <B>$HdisTsunamiFsea</B><BR>
 참고: 바다 면적이 이 값을 밑돌면 쓰나미 발생 확률이 10배가 됩니다.
END
	if($HpointNumber - 8*8 - $HdisTsunamiFsea> 0) {
		my %bai;
		my $pn = $HpointNumber - 8*8;
		foreach ($HdisTsunamiFsea..$pn) {
				my $flag = ($HpointNumber - 8*8 - $_)/($HpointNumber - 8*8 - $HdisTsunamiFsea);
			$flag = 1 + int($flag * 4);
			$bai{$flag} = $_;
		}
		$src.= " ( 주!표준적에는,";
		foreach (sort { $b <=> $a } keys %bai) {
			next if($_ == 1);
			$src.= "$bai{$_}";
			$src.= "이하" if($bai{$_} != $HdisTsunamiFsea);
			$src.= "데$_배 ";
		}
		$src.= ')';
	}
	$src.= '<BR><BR>';

# 괴수
#-------------------------
	$src.= "<HR><a name='monster'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 괴수</H3></a>";

	$src.= <<"END";
<BR>
단위 면적 주변의 괴수출현율 <B>${HdisMonster}%</B> (전장:<B>${HdisMonsterBF}%</B>)<BR>
괴수 파견을 사용할까요? <B>$useStr[$HuseSendMonster]</B><BR>
ST 괴수 파견을 사용할까요? <B>$useStr[$HuseSendMonsterST]</B><BR>
<TABLE>
<TR $HbgInfoCell><TH colspan=2 rowspan=2>${HtagTH_}괴수${H_tagTH}</TH><TH rowspan=2>${HtagTH_}괴수<br>출현인구<br>(비율)${H_tagTH}</TH><TH rowspan=2>${HtagTH_}파견비용<BR>ST 비용${H_tagTH}</TH><TH rowspan=2>${HtagTH_}파견<BR>번호${H_tagTH}</TH><TH colspan=2>${HtagTH_}체력${H_tagTH}</TH><TH rowspan=2>${HtagTH_}경험치${H_tagTH}</TH><TH rowspan=2>${HtagTH_}잔해의 가격${H_tagTH}</TH><TH colspan=8>${HtagTH_}능력${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TH>${HtagTH_}min${H_tagTH}</TH><TH>${HtagTH_}max${H_tagTH}</TH>
<TH>${HtagTH_}빠른<br>이동${H_tagTH}</TH><TH>${HtagTH_}족이<br>와 해도<br>속이${H_tagTH}</TH><TH>${HtagTH_}랜덤<br>경화${H_tagTH}</TH>
<TH>${HtagTH_}선 줄<br>이동${H_tagTH}</TH><TH>${HtagTH_}유린<br>이동${H_tagTH}</TH><TH>${HtagTH_}이동<br>조종${H_tagTH}</TH>
<TH>${HtagTH_}공격 능력${H_tagTH}</TH><TH>${HtagTH_}융단<br>폭격${H_tagTH}</TH>
</TR>
END

	foreach $i (0..$#HmonsterName) {
		my $maxHP = $HmonsterBHP[$i] + $HmonsterDHP[$i] - 1;
		$maxHP++ if(!$HmonsterDHP[$i]);
		my $levelpop = ($HdisMonsBorder[$i]) ? $HdisMonsBorder[$i]. $HunitPop : '-';
		1 while $levelpop =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my $levelratio = $HdisMonsRatio[$i];
		my $monsterValue = $HmonsterValue[$i]. $HunitMoney;
		1 while $monsterValue =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my($mcost, $mcostst, $mno) = ('-', '-', '-');
		if($i <= $HsendMonsterNumber) {
			$mcost = $HmonsterCost[$i]. $HunitMoney if($HuseSendMonster);
			1 while $mcost =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$mcostst = $HmonsterCostST[$i]. $HunitMoney if($HuseSendMonsterST);
			1 while $mcostst =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$mno = $i;
		}
		my @attackName = (($HmonsterFireName[$i] ne '' ? $HmonsterFireName[$i] : '미사일 공격'),'-');
		my($terrorhexma);
		$terrorhexma = "<br>($HmonsterTerrorHex[$i]Hex)" if($HmonsterSpecial[$i] & 0x200);
		$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HmonsterImage[$i]'></TD><TH>$HmonsterName[$i]</TH><TD align='right'>$levelpop<BR>(${levelratio})</TD><TD align='right'>$mcost<BR>$mcostst</TD><TD align='center'>$i</TD><TD align='right'>$HmonsterBHP[$i]</TD><TD align='right'>$maxHP</TD><TD align='right'>$HmonsterExp[$i]</TD><TD align='right'>$monsterValue</TD>
<TD align='center'>$ox[!($HmonsterSpecial[$i] & 0x1)]</TD><TD align='center'>$ox[!($HmonsterSpecial[$i] & 0x2)]</TD><TD align='center'>$ox[!($HmonsterSpecial[$i] & 0x4)]</TD>
<TD align='center'>$ox[!($HmonsterSpecial[$i] & 0x10)]</TD><TD align='center'>$ox[!($HmonsterSpecial[$i] & 0x20)]</TD><TD align='center'>$ox[!($HmonsterSpecial[$i] & 0x80)]</TD>
<TD align='center'>$attackName[!($HmonsterSpecial[$i] & 0x100)]</TD><TD align='center'>$ox[!($HmonsterSpecial[$i] & 0x200)]$terrorhexma</TD>
</TR>
END
	}
	$src.= "</TABLE>";
	$src.= " 참고: '융단 폭격'은, 첫 탄의 착탄 지점의 주변(설정 Hex)에빠짐없이 착탄합니다. 단, 공격 수가 Hex 수가 부족한 경우 일부 지점은 착탄하지 않습니다.<BR>";
	$src.= <<"END";
<BR>
공격한 괴수 자신이 사거리 범위에 있는 경우 자폭(피격)도 허용할까요? <B>$anStr[$HmonsterSelfAttack]</B><BR>
'공격 능력'에 피격된 함정이나 지형이 자기 $AfterName인 경우 무해화할까요? <B>$saftyStr[$HmissileSafetyZone]</B><BR>
 무해화가 무효화될 확률 <B>${HmissileSafetyInvalidp}%</B>(무해화 기능이 발동하는 상황에서 판정)<BR>
END

# 거대괴수
#-------------------------

	$src.= <<"END";
<HR>
<a name='hmonster'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 거대괴수</H3></a>
거대 괴수가 출현할까요? <B>$doStr[$HhugeMonsterAppear]</B><BR>
END

	if($HhugeMonsterAppear) {

		$src.= <<"END";
단위 면적 주변의 거대괴수출현율 <B>${HdisHuge}%</B> (전장:<B>${HdisHugeBF}%</B>)<BR>
개체 재생을 무작위로 실행하는 능력의 재생 확률 <B>${HpRebody}%</B><BR>
<TABLE>
<TR $HbgInfoCell><TH colspan=2 rowspan=2>${HtagTH_}거대괴수${H_tagTH}</TH><TH rowspan=2>${HtagTH_}거대괴수<br>출현인구<br>(비율)${H_tagTH}</TH><TH rowspan=2>${HtagTH_}파견비용<BR>ST 비용${H_tagTH}</TH><TH rowspan=2>${HtagTH_}파견<BR>번호${H_tagTH}</TH><TH colspan=2>${HtagTH_}체력${H_tagTH}</TH><TH rowspan=2>${HtagTH_}경험치${H_tagTH}</TH><TH rowspan=2>${HtagTH_}잔해의 가격${H_tagTH}</TH><TH colspan=10>${HtagTH_}능력${H_tagTH}</TH></TR>
<TR $HbgInfoCell><TH>${HtagTH_}min${H_tagTH}</TH><TH>${HtagTH_}max${H_tagTH}</TH>
<TH>${HtagTH_}빠른<br>이동${H_tagTH}</TH><TH>${HtagTH_}족이<br>와 해도<br>속이${H_tagTH}</TH><TH>${HtagTH_}랜덤<br>경화${H_tagTH}</TH>
<TH>${HtagTH_}선 줄<br>이동${H_tagTH}</TH><TH>${HtagTH_}유린<br>이동${H_tagTH}</TH><TH>${HtagTH_}이동<br>조종${H_tagTH}</TH>
<TH>${HtagTH_}공격 능력${H_tagTH}</TH><TH>${HtagTH_}융단<br>폭격${H_tagTH}</TH>
<TH>${HtagTH_}코어<br>방위${H_tagTH}</TH><TH>${HtagTH_}랜덤<br>재생${H_tagTH}</TH></TR>
END

		foreach $i (0..$#HhugeMonsterName) {
			my $maxHP = $HhugeMonsterBHP[$i] + $HhugeMonsterDHP[$i] - 1;
			$maxHP++ if(!$HhugeMonsterDHP[$i]);
			my $levelpop = ($HdisHugeBorder[$i]) ? $HdisHugeBorder[$i]. $HunitPop : '-';
			1 while $levelpop =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $levelratio = $HdisHugeRatio[$i];
			my $hugeMonsterValue = $HhugeMonsterValue[$i]. $HunitMoney;
			1 while $hugeMonsterValue =~ s/(.*\d)(\d\d\d)/$1,$2/;

			$src.= "<TR $HbgInfoCell><TD align='right'>";
			my($j, @monImage);
			foreach $j (0..6) {
				$monImage[$j] = ($HhugeMonsterImage3[$i][$j] eq '') ? "${HimageDir}/$HlandImage[$HlandSea][0]" : "${HimageDir}/$HhugeMonsterImage3[$i][$j]";
			}
			my($mcost, $mcostst, $mno) = ('-', '-', '-');
			if($i <= $HsendHugeMonsterNumber) {
				$mcost = $HhugeMonsterCost[$i]. $HunitMoney if($HuseSendMonster);
				1 while $mcost =~ s/(.*\d)(\d\d\d)/$1,$2/;
				$mcostst = $HhugeMonsterCostST[$i]. $HunitMoney if($HuseSendMonsterST);
				1 while $mcostst =~ s/(.*\d)(\d\d\d)/$1,$2/;
				$mno = $i + 50;
			}
			my @attackName = (($HhugeMonsterFireName[$i] ne '' ? $HhugeMonsterFireName[$i] : '미사일 공격'),'-');
			my($terrorhexma);
			$terrorhexma = "<br>($HhugeMonsterTerrorHex[$i]Hex)" if($HhugeMonsterSpecial[$i] & 0x200);
			my($space);
			$space = "<img src='${HimageDir}/space.gif'>";
			$src.= <<"END";
$space<img src='$monImage[6]'><img src='$monImage[1]'>$space<br>
<img src='$monImage[5]'><img src='$monImage[0]'><img src='$monImage[2]'><br>
$space<img src='$monImage[4]'><img src='$monImage[3]'>$space
</TD><TH>$HhugeMonsterName[$i]</TH><TD align='right'>$levelpop<BR>(${levelratio})</TD><TD align='right'>$mcost<BR>$mcostst</TD><TD align='center'>$mno</TD><TD align='right'>$HhugeMonsterBHP[$i]</TD><TD align='right'>$maxHP</TD><TD align='right'>$HhugeMonsterExp[$i]</TD><TD align='right'>$hugeMonsterValue</TD>
<TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x1)]</TD><TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x2)]</TD><TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x4)]</TD>
<TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x10)]</TD><TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x20)]</TD><TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x80)]</TD>
<TD align='center'>$attackName[!($HhugeMonsterSpecial[$i] & 0x100)]</TD><TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x200)]$terrorhexma</TD>
<TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x10000)]</TD><TD align='center'>$ox[!($HhugeMonsterSpecial[$i] & 0x20000)]</TD>
</TR>
END
		}
		$src.= <<"END";
</TABLE><BR>
END
	}

#아이템
#-------------------------

	$src.= <<"END";
<HR>
<a name='item'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a>아이템</H3></a>
아이템을 사용할까요? <B>$useStr[$HuseItem]</B><BR>
END

	if($HuseItem) {
		my $itemGet = ($HitemGetDenominator) ? "(총 획득 경험치)<B>/$HitemGetDenominator</B>" : '판정하지 않음';
		my $itemGet2 = ($HitemGetDenominator2) ? "(총 획득 경험치)<B>/$HitemGetDenominator2</B>" : '판정하지 않음';
		my $itemGet3 = ($HitemGetDenominator3) ? "(총 획득 경험치)<B>/$HitemGetDenominator3</B>" : '판정하지 않음';
		my $itemSeize = ($HitemSeizeDenominator) ? "(함정 경험치)<B>/$HitemSeizeDenominator</B>" : '판정하지 않음';
		my $itemGive = (!$HitemGivePerTurn) ? '' : ($HitemGivePerTurn == 1) ? " 참고: 매 턴 <B>상위 $AfterName부터 차례대로</B>'키아이템'이 하나씩 지급됩니다." : " 참고: 매 턴<B>하위 $AfterName부터 차례대로</B>'키아이템'이 하나씩 지급됩니다.";
		$itemGive.= "단, 해군(함정 또는 군항)을 보유하지 않은 $AfterName 은 제외합니다.<BR>";
		my $itemBF = ($HitemInvalid) ? " 참고: 전장에서는'공격 횟수2배''사거리 확장''전체 $AfterName 보급 가능''명중률 UP''파괴력2배' 능력이 무효가 됩니다." : '';
		my $compStr = (!$HallyItemComplete) ? "1개의$AfterName" : (!$HarmisticeTurn) ? "1개의 동맹" : "1개의 진영";

		$src.= <<"END";
 참고: <B>$compStr</B>이 모든 '키아이템'을 획득하면 게임이 종료됩니다.<BR>
$itemGive
<BR>
아이템 획득 판정확률<BR>
 거대괴수 퇴치의 시,$itemGet<BR>
 괴수 퇴치의 시,$itemGet2<BR>
 잔해 매각의 시,$itemGet3<BR><BR>
아이템탈취판정확률<BR>
아이템보유$AfterName의 함정 격침 시,$itemSeize<BR>
 참고: 해군을 소멸시켰을 때는, 모든 아이템이 마지막 함정 1척(또는 항구 1개)을 파괴한 $AfterName 로 이동됩니다.<br>
 참고: 또한, 이유의 같음몇에 관계없이 해군을 소실했습니다 섬은, 모두의아이템(및총 획득 경험치)를 실 있습니다.<br>
<TABLE>
<TR $HbgInfoCell><TH colspan=2 rowspan=2>${HtagTH_}$HitemName[0]${H_tagTH}</TH>
<TH colspan=25>${HtagTH_}능력${H_tagTH}</TH></TR>
<TR $HbgInfoCell>
<TH>${HtagTH_}키<br>아이<br>테무${H_tagTH}</TH>
<TH>${HtagTH_}전체$AfterName<br>보급<br> 가능${H_tagTH}</TH>
<TH>${HtagTH_}지형<br>차단차폐<br>무효${H_tagTH}</TH>
<TH>${HtagTH_}보유<br>함정<br>+α${H_tagTH}</TH>
<TH>${HtagTH_}사거리<br>확대<br>Hex${H_tagTH}</TH>
<TH>${HtagTH_}명중<br>률 UP<br>확률${H_tagTH}</TH>
<TH>${HtagTH_}커맨드<br>횟수<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}식량<br>max<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}자금<br>max<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}수확<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}수입<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}공격<br>횟수<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}파괴<br>력<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}유지<br>식량<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}유지<br>금<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}식량<br>소비<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}커맨드<br>비용<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}지진<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}태풍<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}운석<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}거대<br>운석<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}분화<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}화재<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}쓰나미<br>배율${H_tagTH}</TH>
<TH>${HtagTH_}파괴<br>력<br>+${H_tagTH}</TH>
</TR>
END

		foreach $i (1..$#HitemName) {
			$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HitemImage[$i]'></TD>
<TH>$HitemName[$i]</TH>
END
			foreach (0..2) {
				$src.= "<TD align='center'>$ox[!$HitemSpecial[$i][$_]]</TD>";
			}
			$src.= ($HitemSpecial[$i][3]> 0) ? "<TD align='center'>+$HitemSpecial[$i][3]</TD>" : ($HitemSpecial[$i][3] < 0) ? "<TD align='center'>$HitemSpecial[$i][3]</TD>" : "<TD align='center'>-</TD>";
			$src.= ($HitemSpecial[$i][4] != 0) ? "<TD align='center'>$HitemSpecial[$i][4]Hex</TD>" : "<TD align='center'>-</TD>";
			$src.= ($HitemSpecial[$i][5] != 0) ? "<TD align='center'>$HitemSpecial[$i][5]%</TD>" : "<TD align='center'>-</TD>";
			foreach (6..12) {
				$src.= ($HitemSpecial[$i][$_]> 1) ? "<TD align='center'><FONT color=blue>x$HitemSpecial[$i][$_]</FONT></TD>" : ($HitemSpecial[$i][$_] < 1) ? "<TD align='center'><FONT color=red>x$HitemSpecial[$i][$_]</FONT></TD>" : "<TD align='center'>-</TD>";
			}
			foreach (13..23) {
				$src.= ($HitemSpecial[$i][$_]> 1) ? "<TD align='center'><FONT color=red>x$HitemSpecial[$i][$_]</FONT></TD>" : ($HitemSpecial[$i][$_] < 1) ? "<TD align='center'><FONT color=blue>x$HitemSpecial[$i][$_]</FONT></TD>" : "<TD align='center'>-</TD>";
			}
			$src.= ($HitemSpecial[$i][24]> 0) ? "<TD align='center'>+$HitemSpecial[$i][24]</TD>" : ($HitemSpecial[$i][24] < 0) ? "<TD align='center'>$HitemSpecial[$i][24]</TD>" : "<TD align='center'>-</TD>";
		}
		$src.= <<"END";
</TABLE>
$itemBF<BR>
END
	}

# 기념비
#-------------------------

	$src.= <<"END";
<HR>
<a name='monument'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 기념비</H3></a>
<TABLE>
<TR $HbgInfoCell><TH colspan=2>${HtagTH_}기념비${H_tagTH}</TH></TR>
END

	foreach $i (0..$#HmonumentName) {
		$src.= <<"END";
<TR $HbgInfoCell><TD align='right'><img src='${HimageDir}/$HmonumentImage[$i]'></TD><TH>$HmonumentName[$i]</TH></TR>
END
	}
	$src.= "</TABLE>";
#	$src.= "기념비발사를 사용할까요? <B>$useStr[$HuseBigMissile]</B><BR>";
	$src.= "기념비발사를 사용할까요? <B>내실마리</B><BR>";

# 턴 보너스·수상
#-------------------------

	my $prize = 0;
	my %prizeKind = (
		'pop' => '인구',
		'gain' => '총 획득 경험치',
		'money' => '자금',
		'food' => '식량',
		'area' => '면적',
		'farm' => '농장 규모',
		'factory' => '공장 규모',
		'mountain' => '채굴장 규모',
		'monsterkill' => '괴수 퇴치 수',
		'itemNumber' => "$HitemName[0] 획득 수",
		'point' => "$HpointName",
		'achive' => "구출한 난민(1턴)",
		'damage' => "소실했습니다인구(1턴)",
	);
	my %prizeAfter = (
		'pop' => "$HunitPop",
		'gain' => '',
		'money' => "$HunitMoney",
		'food' => "$HunitFood",
		'area' => "$HunitArea",
		'farm' => "0$HunitPop",
		'factory' => "0$HunitPop",
		'mountain' => "0$HunitPop",
		'monsterkill' => "$HunitMonster",
		'itemNumber' => '',
		'point' => "$HpointAfter",
		'achive' => "$HunitPop",
		'damage' => "$HunitPop",
	);
	my @extKind = ('우승횟수', '공헌도', '파괴한 방위 시설의 수', '파괴한 미사일 기지의 수', '구출한 난민의 합계인구', '피해를 받을탄 수', '발사한 탄 수', '방위 시설에서 방어한탄 수', '파견한 함정의 수', '파견된 함정의 수', '파괴한 함정의 수');
	my @extAfter = ('회', '', '기준', '기준', "$HunitPop", '발', '발', '발', '함', '함', '함');
	foreach $i (0..$#Hprize) {
		$prize += $Hprize[$i]->{'money'};
	}
	my $str = ($prize) ? "<TH>${HtagTH_}상금액${H_tagTH}</TH>" : '';
	$src.= <<"END";
<HR>
<a name='prize'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 턴 보너스·수상</H3></a>
턴잔을 몇 매 턴출습니까 <B>${HturnPrizeUnit}턴</B><BR>

<TABLE>
<TR $HbgInfoCell><TH colspan=2>${HtagTH_}상${H_tagTH}</TH><TH colspan=2>${HtagTH_}수상조건${H_tagTH}</TH>$str</TR>
END

	foreach $i (0..$#Hprize) {
		my($req1, $req2);
		if($Hprize[$i]->{'kind'} eq 'ext') {
			$req1 = $extKind[$Hprize[$i]->{'ptr'}];
			my $threshold = $Hprize[$i]->{'threshold'};
			$threshold /= 10 if($Hprize[$i]->{'ptr'} == 1);
			$req2 = $threshold. $extAfter[$Hprize[$i]->{'ptr'}];
			1 while $req2 =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$req2.= "이상";
		} else {
			$req1 = ($i) ? $prizeKind{$Hprize[$i]->{'kind'}} : "턴잔판정 시(${HturnPrizeUnit}턴마다)";
			if($i) {
				$req2 = $Hprize[$i]->{'threshold'}. $prizeAfter{$Hprize[$i]->{'kind'}};
				1 while $req2 =~ s/(.*\d)(\d\d\d)/$1,$2/;
				$req2.= "이상";
			} else {
				if($Hprize[$i]->{'kind'} == 1) {
					$req2 = '섬랭크제1위';
				} else {
					$req2 = "섬랭크제$Hprize[$i]->{'kind'}위이상";
				}
			}
		}
		my $prizemoney = "$Hprize[$i]->{'money'}$HunitMoney";
		1 while $prizemoney =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$str = ($prize) ? "<TD align='right'>$prizemoney</TD>" : '';
		$src.= <<"END";
<TR $HbgInfoCell><TD align='center'><img src='${HimageDir}/prize${i}.gif'></TD><TH>$Hprize[$i]->{'name'}</TH><TD>$req1</TD><TD align='right'>$req2</TD>$str</TR>
END
	}
	$src.= "</TABLE>";

# 명령 목록
#-------------------------

	$col = 1;
	$src.= <<"END";
<HR>
<a name='command'><H3 class='subtitle'><a style='text-decoration=none' href='#top'><small>▲</small></a> 명령 목록</H3></a>
<TABLE>
<TR $HbgInfoCell><TH colspan=$col>${HtagTH_} 명령 목록${H_tagTH} ${turnStr[1]}■${H_tagComName}턴을 소비하다 ${turnStr[0]}■${H_tagComName}턴을 소비하지 않음</TH></TR>
END

	my %comCheck;
	foreach (@HcomList) {
		$comCheck{$_} = 1;
	}
	my $count = 0;
	foreach $com (@HcommandDivido) {
		$count++;
		my($category, $start, $end) = split(/,/, $com);
		$src.= "<TR>" if($count%$col == 1);
		$src.= <<"END";
<TD valign=top class='M'>
<TABLE width=100%>
<TR $HbgInfoCell><TH colspan=4>${HtagTH_}${category}계${H_tagTH}</TH></TR>
END
		foreach ($start..$end) {
			next if(!$comCheck{$_});
			next if($HmaxComNavyLevel && ($HcomNavy[0] + $HcomNavyNumber[$#HcomNavyNumber] < $_) && ($_ <= $HcomNavy[$#HnavyName]));
			next if($HcomName[$_] eq '');
			my $cost = $HcomCost[$_];
			if($cost eq '0') {
				$cost = '무료';
			} elsif($cost =~ /^\@(.*)$/) {
				$cost = $1;
			} elsif($cost < 0) {
				$cost = - $cost;
				$cost.= $HunitFood;
			} else {
				$cost.= $HunitMoney;
			}
			1 while $cost =~ s/(.*\d)(\d\d\d)/$1,$2/;
			my $turn = $HcomTurn[$_];
			$src.= <<"END";
<TR $HbgInfoCell>
<TH>${turnStr[($turn> 0)]}$HcomName[$_]${H_tagComName}</TH><TD align='right'>$cost</TD>
<TD align='left' width=100%>$HcomMsgs[$_]</TD>
</TR>
END
		}
		$src.= "</TABLE></TD>";
		$src.= "</TR>" if($count%$col == 0);
	}
	$src.= "</TR>" if($count%$col != 0);
	if($HusePrepare3 && $precheap2 != 10) {
		my $discount = 10 - $precheap2;
		$src.= "</TR><TR><TD class='M' colspan=3>참고: ${turnStr[($HcomTurn[$HcomPrepare3]> 0)]}$HcomName[$HcomPrepare3]${H_tagComName}은,<B>$precheap 개</B>의 황무지에서<B>'$discount 할인'</B>이 됩니다.</TD>";
	}
	$src.= <<"END";
</TR></TABLE>
END

	$src.= <<"END" if($mode);
<HR>
<DIV ID='LinkFoot'>
$Hfooter
<DIV align="right">
<HR>
<B>바다전쟁 JS.$versionInfo(based on ver1.3)</B> patchworked by <a style='text-decoration:none;' href='http://no-one.s53.xrea.com/'>neo_otacky</a>
</DIV></DIV></DIV>
</BODY></HTML>
END

#	1 while $src =~ s/(.*\d)(\d\d\d)/$1,$2/;
	if($mode) {
		open(OUT,">${HefileDir}/setup.html");
#		print OUT $src;
		print OUT $src;
		close(OUT);
		chmod(0666, "${HefileDir}/setup.html");

		out("<meta HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=${efileDir}/setup.html\">");
	} else {
		out("$src");
	}
}

1;
