#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 순위모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 모형정원 제도 2nd
#								 v1.5
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							 모형정원 모형정원 바다전쟁
#								 v1.3
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

# 순위 표시 수(기록 수보다 크게 해도 의미 없습니다)
my $Hranking = 10;
# 한 화면에 표시되는 항목 수
my $Hcolum = 2;
# 각부문의 이미지이미지 파일
my @bumonImage = (
	"$HlandTownImage[$#HlandTownImage]", # 인구
	"$HlandImage[$HlandPlains]", # 면적
	"$HlandImage[$HlandFarm]", # 농장
	"$HlandImage[$HlandFactory]", # 직장
	"$HlandImage[$HlandMountain][1]", # 채굴장
	"$HlandImage[$HlandWaste][1]", # 섬격파 수
	'monster7.gif', # 괴수퇴치 수
	'monster0.gif', # 괴수출현 수
	'navy1.gif', # 소속 불명 함정 출현 수
	"$HlandImage[$HlandBase]", # 총 획득 경험치
	'navy2.gif', # 함정 경험치 합계
	'navy3.gif', # 함정 경험치
	'navy0.gif', # 군항 경험치
	"$HnavyImageZ", # 함정 격침 수
);

#----------------------------------------------------------------------
# 필요에 따라 설정하는 항목은 여기까지입니다
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 순위
#----------------------------------------------------------------------
sub rankIslandMain {
	my($i, $monster, $monslive, $monstertype, $hmonstertype, $fkind, $sink, $selfsink);
	# 준비
	foreach $i (0..$islandNumber) {
		my $island = $Hislands[$i];

		$island->{'defeatcount'} = @{$island->{'defeat'}} / 2;

		$monster = $island->{'monsterlive'};
		$monster =~ /([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)/;
		$island->{'monslive'} = $1;
		$island->{'unknownlive'} = $4;

		$sink = $island->{'sink'};
		$sinkself = $island->{'sinkself'};
		foreach (0..$#HnavyName) {
			next if($HnavySpecial[$_] & 0x8); # 군항은 합계에 포함하지 않음
			$island->{'totalSink'} += $island->{'sink'}[$_] + $island->{'sinkself'}[$_];
			$island->{'selfSink'} += $island->{'sinkself'}[$_];
		}

		$fkind = $island->{'fkind'};
		foreach (@$fkind) {
			my($eId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack(hex($_));
			my $kind = 'navy'. $nKind; # 보유 수
			$island->{$kind}++;
			$island->{'totalNavyExp'} += $nExp;
			if($HnavySpecial[$nKind] & 0x8) {
				if($nExp> $island->{'portExp'}) {
					$island->{'portExp'} = $nExp;
					$island->{'maxPortExpValue'} = hex($_);
				}
			} elsif($nExp> $island->{'navyExp'}) {
				$island->{'navyExp'} = $nExp;
				$island->{'maxExpValue'} = hex($_);
			}
		}
	}

	my @elements = ( 'pop', 'area', 'farm', 'factory', 'mountain', 'defeatcount', 'monsterkill', 'monslive', 'unknownlive', 'gain', 'totalNavyExp', 'navyExp', 'portExp', 'totalSink');
	my @bumonName = ('인구', '면적', '농장', '직장', '채굴장', "${AfterName}격파 수", '괴수퇴치 수', '괴수출현 수', '소속 불명 함정 출현 수', '총 획득 경험치', '함정 경험치 합계', '함정 경험치', '군항 경험치', '함정 격침 수');
	my @bAfterName = ("$HunitPop", "$HunitArea","0$HunitPop 규모", "0$HunitPop 규모", "0$HunitPop 규모", "$AfterName", "$HunitMonster", "$HunitMonster", '함', '', '', '', '', '함');
	splice(@elements, -5) if($HnavyName[0] eq '');

	if(!$HnavySafetyZone || $HnavySafetyInvalidp) {
		push(@elements, 'selfSink');
		push(@bumonName, '함정자폭 수');
		push(@bumonImage, 'navy5.gif');
		push(@bAfterName, '함');
	}

	foreach (0..$#HnavyName) {
		last if($HmaxComNavyLevel && ($HcomNavyNumber[$#HcomNavyNumber] < $_));
		my $kind = 'navy'. $_;
		push(@elements, $kind);
		push(@bumonName, "${HnavyName[$_]}보유 수");
		push(@bumonImage, $HnavyImage[$_]);
		my $after = ($_ ? '함' :'항구');
		push(@bAfterName, $after);
	}


	my $rt = "\n";
	my %islands;
	my($id, $f);
	foreach (@elements) {
		@{$islands{$_}} = rankingSort($_);
	}
	# navyExp
	my(@navyLevel, @fKind, @ofname);
	foreach (@{$islands{'navyExp'}}) {
		$id = $_->{'id'};
		push(@navyLevel, expToLevel($HlandNavy, $Hislands[$HidToNumber{$id}]->{'navyExp'}));
		my($eId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($Hislands[$HidToNumber{$id}]->{'maxExpValue'});
		push(@fKind, $nKind);
		push(@ofname, $Hislands[$HidToNumber{$id}]->{'fleet'}[$nNo]);
	}
	# portExp
	my(@portLevel, @pKind, @pfname);
	foreach (@{$islands{'portExp'}}) {
		$id = $_->{'id'};
		push(@portLevel, expToLevel($HlandNavy, $Hislands[$HidToNumber{$id}]->{'portExp'}));
		my($eId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($Hislands[$HidToNumber{$id}]->{'maxPortExpValue'});
		push(@pKind, $nKind);
		push(@pfname, $Hislands[$HidToNumber{$id}]->{'fleet'}[$nNo]);
	}

	# defeat 격파했습니다 섬 목록
	my @dname;
	foreach (@{$islands{'defeatcount'}}) {
		$id = $_->{'id'};
		my @defeat = @{$_->{'defeat'}};
		my($dNameList)= '';
		for($i = 0; $i < $#defeat; $i+=2) {
			$dNameList.= "\n" if($i);
			$dNameList.= $defeat[$i]. '('. $defeat[$i+1]. ')';
			$dNameList =~ s/<FONT COLOR=\"[\w\#]+\"><B>(.*)<\/B><\/FONT>/$1/g;
			$dNameList =~ s/<[^<]*>//g;
		}
		my $defeatname = "<A TITLE=\"$dNameList\" ";
		$dNameList =~ s/$rt/ /g;
		$defeatname.= "onMouseOver='status=\"$dNameList\"; return true;' onMouseOut=\"status = '';\">";
		push(@dname, $defeatname);
	}

	# monsterkill 쓰러뜨린 괴수 목록
	my @mname;
	foreach (@{$islands{'monsterkill'}}) {
		$id = $_->{'id'};
		my $monsterkill = $_->{'prize'};
		$monsterkill =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
		my($flags, $monsters, $hmonsters) = ($1, $2, $3);
		$f = 1;
		my($mNameList) = '';
		for($i = 0; $i < $HmonsterNumber; $i++) {
			if($monsters & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HmonsterName[$i]]";
			}
			$f *= 2;
		}
		$f = 1;
		for($i = 0; $i < $HhugeMonsterNumber; $i++) {
			if($hmonsters & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HhugeMonsterName[$i]]";
			}
			$f *= 2;
		}
		$monsterkill = "<A TITLE=\"$mNameList\" ";
		$mNameList =~ s/$rt//g;
		$monsterkill.= "onMouseOver='status=\"$mNameList\"; return true;' onMouseOut=\"status = '';\">";
		push(@mname, $monsterkill);
	}

	# monslive 출현 중인 괴수 목록
	my @mlive;
	foreach (@{$islands{'monslive'}}) {
		$id = $_->{'id'};
		$monsterlive = $_->{'monsterlive'};
		$monsterlive =~ /([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)/;
		($monslive, $monstertype, $hmonstertype, $unknownlive, $unknowntype) = ($1, $2, $3, $4, $5);
		$f = 1;
		$mNameList = '';
		for($i = 0; $i < $HmonsterNumber; $i++) {
			if($monstertype & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HmonsterName[$i]] ";
			}
			$f *= 2;
		}
		$f = 1;
		for($i = 0; $i < $HhugeMonsterNumber; $i++) {
			if($hmonstertype & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HhugeMonsterName[$i]]";
			}
			$f *= 2;
		}
		$monsterlive = "<A TITLE=\"$mNameList\" ";
		$mNameList =~ s/$rt//g;
		$monsterlive.= "onMouseOver='status=\"$mNameList\"; return true;' onMouseOut=\"status = '';\">";
		push(@mlive, $monsterlive);
	}

	# unknownlive 출현 중인 소속 불명 함정 목록
	my @ulive;
	foreach (@{$islands{'unknownlive'}}) {
		$id = $_->{'id'};
		my $unknlive = $_->{'monsterlive'};
		$unknlive =~ /([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)/;
		($monslive, $monstertype, $hmonstertype, $unknownlive, $unknowntype) = ($1, $2, $3, $4, $5);
		$f = 1;
		$mNameList = '';
		foreach(0..$#HnavyName) {
			if($unknowntype & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HnavyName[$_]] ";
			}
			$f *= 2;
		}
		my $unknownName = "<A TITLE=\"$mNameList\" ";
		$mNameList =~ s/$rt//g;
		$unknownName.= "onMouseOver='status=\"$mNameList\"; return true;' onMouseOut=\"status = '';\">";
		push(@ulive, $unknownName);
	}

	# 화면 출력
	unlock();

	my($reki);
	$reki = "[<A HREF=\"${HthisFile}?Rekidai=0\">역대순위로</A>]" if($HuseRekidai);
	out(<<END);
<DIV ID='Ranking'>
<H1>각부문별도 NO.1 (턴${HislandTurn})</H1>
<P>
목표는 <B>ALL NO.1</B>! ${AfterName} 이름을 클릭하면,<B>관광</B>할 수 있습니다.
</P>
$reki
END
	$Hcolum = 1 if(!$Hcolum);
	foreach (0..$#elements) {
		out("<TABLE ALIGN=\"center\" width=\"100%\"><TR>\n") if(!($_ % $Hcolum));
		out(<<END);
<td width="9%">
<TABLE BORDER=1 width="100%">
<TR><TD ALIGN="left"><img src="$bumonImage[$_]"></TD>
<TD class="RankingCell" colspan=2 ALIGN="center" width="100%"><span class="bumon"><B>${bumonName[$_]}</B></span></TD></TR>
<TR><TH>${HtagTH_}순위${H_tagTH}</TH><TH>${HtagTH_}${AfterName} 이름${H_tagTH}</TH><TH>${HtagTH_}기록${H_tagTH}</TH></TR>
END
		my $max = $HbfieldNumber + ($Hranking - 1);
		foreach my $i ($HbfieldNumber..$max) {
			my $isl = $islands{$elements[$_]}[$i];
			my $id = $isl->{'id'};
			my $name = islandName($isl);
			my $element = $isl->{$elements[$_]};

			my ($Str1, $Str2);
			if(($element ne '') && ($element != 0)) {
				if($elements[$_] eq 'defeatcount') {
					$Str1 = $dname[$i];
					$Str2 = '</A>';
				} elsif($elements[$_] eq 'monsterkill') {
					$Str1 = $mname[$i];
					$Str2 = '</A>';
				} elsif($elements[$_] eq 'monslive') {
					$Str1 = $mlive[$i];
					$Str2 = '</A>';
				} elsif($elements[$_] eq 'unknownlive') {
					$Str1 = $ulive[$i];
					$Str2 = '</A>';
				} elsif($elements[$_] eq 'navyExp') {
					$Str1 = "";
					$Str2 = "<small><small>($ofname[$i]함대 $HnavyName[$fKind[$i]] Lv.$navyLevel[$i])</small></small>";
				} elsif($elements[$_] eq 'portExp') {
					$Str1 = "";
					$Str2 = "<small><small>($pfname[$i]함대 $HnavyName[$pKind[$i]] Lv.$portLevel[$i])</small></small>";
				} else {
					$Str1 = '';
					$Str2 = '';
				}

				my $j = $i + 1 - $HbfieldNumber;
				my $value = "${Str1}${element}${bAfterName[$_]}${Str2}";
				1 while $value =~ s/(.*\d)(\d\d\d)/$1,$2/;
				if($j == 1) {
					out(<<END);
<TR>
<TH ALIGN="right"><H3 style='display:inline'>$j</H3></TD>
<TH><H3 style='display:inline'><A STYlE="text-decoration:none" HREF="${HthisFile}?Sight=${id}" alt="ID=${id}" title="ID=${id}">${HtagName_}${name}${H_tagName}</H3></TD>
<TH><H3 style='display:inline'>$value</H3></TD>
</TR>
END
				} else {
					out(<<END);
<TR>
<TD ALIGN="right">$j</TD>
<TD ALIGN="center"><A STYlE="text-decoration:none" HREF="${HthisFile}?Sight=${id}" alt="ID=${id}" title="ID=${id}">${HtagName_}${name}${H_tagName}</TD>
<TD ALIGN="center">$value</TD>
</TR>
END
				}
			} else {
			out(<<END);
<TR>
<TD ALIGN="right"> - </TD>
<TD ALIGN="center">${HtagName_} - ${H_tagName}</TD>
<TD ALIGN="center"> - </TD>
</TR>
END
			}
		}
		out("</TABLE></TD>\n");
		out("</TR></TABLE>\n") if(!(($_ + 1) % $Hcolum));
	}
	out("</TR></TABLE>\n") if((($#elements + 1) % $Hcolum));
	out("</DIV>\n");
}

# 정렬
sub rankingSort {
	my($kind) = @_;

	my @idx = (0..$#Hislands);
	@idx = sort {
			$Hislands[$b]->{'field'} <=> $Hislands[$a]->{'field'} || # 전장우선
			$Hislands[$b]->{$kind} <=> $Hislands[$a]->{$kind} || # $kind 에서정렬
			$a <=> $b # $kind가 같으면 이전 순서를 유지
		 } @idx;
	return @Hislands[@idx];
}

1;
