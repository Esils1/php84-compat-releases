#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# The Return of Neptune: http://no-one.s53.xrea.com/
# 바다전쟁 JS판용으로 개변
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# 휴대 단말모듈
# $Id: hako-mobile.cgi 60 2005-01-23 07:22:47Z takayama $
#----------------------------------------------------------------------

McgiInput();

tempHeader();

if($HmainMode eq 'turn') {
	# 턴 갱신대기치
	MturnPageMain();
} elsif($HmainMode eq 0) {
	# 관광 화면
	MprintMain(0);
} elsif($HmainMode eq 1) {
	# 사건
	MlogMain();
} elsif($HmainMode eq 2) {
	# 개발 화면 소유자
	MprintMain(1);
} elsif($HmainMode eq 3) {
	# 계획 목록
	McmdMain(0);
} elsif($HmainMode eq 4) {
	# 계획입력
	McmdMain(1);
} elsif($HmainMode eq 5) {
	# 게시판
	MlbbsMain();
} elsif($HmainMode eq 'command') {
	# 계획입력
	McmdInputMain();
} elsif($HmainMode eq 'TimeTable') {
	# 섬 번호 목록
	MlistPageMain();
} elsif($HmainMode eq 'setupv') {
	# 지형 목록
	MhelpPageMain();
} elsif($HmainMode eq 'FightView') {
	# 링크
	MlinkPageMain();
} else {
	MtopPageMain();
}

tempFooter();

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------

# CGI 읽기
sub McgiInput {
	my $getLine = $ENV{'QUERY_STRING'};

	if($getLine =~ /ID=([0-9]+)/){
		$HcurrentID = $1;
	}
	if($getLine =~ /PS=([^\&]*)/){
		$HinputPassword = $1;
	}
	if($getLine =~ /MP=([0-9]+)/){
		$HinputPassword2 = $1;
	}

	if($HmainMode eq 'print') {
		$HmainMode = 0;
	}

	$HinputPassword2 =~ tr/0-9//cd;
}

# 섬의 존재 확인
sub MexistCheck {
	my $mode = shift;
	unlock() if(!$mode);

	$HcurrentNumber = $HidToNumber{$HcurrentID};

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '') {
		tempProblem();
		return 1;
	}

	return 0;
}

# 비밀번호 확인
sub MpassCheck {
	my $island = $Hislands[$HcurrentNumber];

	# 비밀번호
	if(!checkPassword($island,$HinputPassword)) {
		# 비밀번호 오류
		tempWrongPassword();
		return 1;
	}

	return 0;
}

# 지도 모드
sub MprintMain {
	my $mode = shift;

	if(MexistCheck()) {
		return;
	}
	if($mode) {
		if(MpassCheck()) {
			return;
		}
	}

	MislandInfo($mode); # 섬의 정보
	MislandMap($mode); # 섬 지도
}

# 사건
sub MlogMain {
	my $mode = 0;

	if(MexistCheck()) {
		return;
	}

	if($HinputPassword) {
		if(MpassCheck()) {
			return;
		}

		$mode = 1;
	}

	MtoMapLink($mode);

	logFilePrint(0, $HcurrentID, $mode, 2);
}

# 게시판
sub MlbbsMain {
	my $mode = 0;

	if(MexistCheck()) {
		return;
	}

	if($HinputPassword) {
		if(MpassCheck()) {
			return;
		}

		$mode = 1;
	}

	MtoMapLink($mode);

	MlbbsContents($mode);
	unlock();

}

# 로컬 게시판내용
sub MlbbsContents {
	my($mode) = @_;
	my($lbbs, $line, $no);
	$lbbs = readLbbs($HcurrentID);
	$no = @lbbs;
	out(<<END) if($lbbs->[0] ne '0<<0>>' && $lbbs->[0] ne '');
No:[게시일]게시자>내용($AfterName이름)<BR>
=========================<BR>
END

	my($i);
	$HlbbsView = $HlbbsViewMax if(!$HlbbsView);
	for($i = 0; $i < $HlbbsView; $i++) {
		$line = $lbbs->[$i];
		next if($line eq '0<<0>>' || $line eq '');
		if($line =~ /([0-9]*)\<(.*)\<(.*)\>(.*)\>(.*)$/) {
			my($m, $iName, $oda, $tan, $com) = ($1, $2, $3, $4, $5);
			$com =~ s/(http|ftp):\/\/([^\x81-\xFF\s\"\'\(\)\<\>\\\`\[\{\]\}\|]+)/<A href=\"$1:\/\/$2\" onclick=\"location.href=\'${HaxesFile}?$1:\/\/$2\'\; return false\;\" target=\"_blank\">$HlbbsAutolinkSymbol<\/A>/g if($HlbbsAutolinkSymbol ne '');
			my($j) = $i + 1;
			out("<B>$j</B>:");
			my($speaker);
			my($sName, $sID) = split(/,/, $iName);
			my($os, $date, $addr) = split(/,/, $oda);
			my($turn, $name) = split(/:/, $tan);
			$tan = "[${date}]$name";
			my $sNo = $HidToNumber{$sID};
			if($sName ne '') {
				if(defined $sNo){
					$speaker = "(<A HREF=\"$HthisFile?Sight=$sID&MP=$HinputPassword2\">$sName</A>)";
				} else {
					$speaker = "($sName)";
				}
			}
			if($os == 0) {
				# 관광객
				if ($m == 0) {
					# 공개
					if($sID ne '0') {
						out("$tan> ${com} $speaker<BR>");
					} else {
						out("$tan> ${com} $speaker<BR>");
					}
				} else {
					# 극비
					if (!$mode) {
						# 관광객
						out("- 극비 -<BR>");
					} else {
						# 소유자
						out("$tan>(비밀) ${com} $speaker<BR>");
					}
				}
			} else {
				# 섬주
				out("$tan> ${com} $speaker<BR>");
			}
		}
	}
}

# 개발 계획
sub McmdMain {
	my $mode = shift;

	if(MexistCheck() or MpassCheck()) {
		return;
	}

	MtoMapLink(1);
	out("<HR>");
	if($mode == 0) {
		McmdListPageMain($HcommandMax);
	} else {
		McmdInputPageMain();
	}
}

# 개발 계획입력 처리
sub McmdInputMain {
	if(MexistCheck(1) or MpassCheck()) {
		unlock();
		return;
	}

	require('hako-map.cgi');

	my $island = $Hislands[$HcurrentNumber];

	$HcommandPlanNumber--;

	commandAdd($island);

	unlock();

#	$HcommandPlanNumber++;
	MtoMapLink(1);
	out("<HR>");
	McmdInputPageMain();
}

# 섬의 정보
sub MislandInfo {
	my $mode = shift;
	my $island = $Hislands[$HcurrentNumber];

	# 정보 표시
	my $rank = $HcurrentNumber + 1 - $HbfieldNumber;
	my $pop = $island->{'pop'};
	my $area = $island->{'area'};
	my $food = $island->{'food'};
	my $farm = $island->{'farm'};
	my $factory = $island->{'factory'};
	my $mountain = $island->{'mountain'};
	my $name;

	# 인구의 표시
#	$pop = (!$Hhide_town || $mode == 1) ? $island->{'pop'}.$HunitPop : aboutPop($island->{'pop'});

	$pop = ($pop == 0) ? "-" : "${pop}$HunitPop";
	1 while $pop =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$area = ($area == 0) ? "-" : "${area}$HunitArea";
	1 while $area =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$food = ($food == 0) ? "-" : "${food}$HunitFood";
	1 while $food =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$farm = ($farm == 0) ? "-" : "${farm}0$HunitPop";
	1 while $farm =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$factory = ($factory == 0) ? "-" : "${factory}0$HunitPop";
	1 while $factory =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$mountain = ($mountain == 0) ? "-" : "${mountain}0$HunitPop";
	1 while $mountain =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$farm = "기밀" if($Hhide_farm == 2);
	1 while $farm =~ s/(.*\d)(\d\d\d)/$1,$2/;
	$factory = "기밀" if($Hhide_factory == 2);
	1 while $factory =~ s/(.*\d)(\d\d\d)/$1,$2/;

	# 예선 기간, 실업자가상한을 상회라고 있었음라경고
	my $mStr1 = '';
	if($Htournament && ($HislandTurn < $HyosenTurn)) {
		my $tmp = int($island->{'pop'} - ($farm + $factory + $mountain) * 10);
		$tmp = 0 if($tmp < 0);
		$mStr1 = "<FONT COLOR=RED>실업자가".$Hno_work.$HunitPop.
		"이상출하고 있으므로, 인구 증가가 중단합니다. 생산시설을 건설테테하세요.</FONT><br>" if($tmp>= $Hno_work);
		1 while $mStr1 =~ s/(.*\d)(\d\d\d)/$1,$2/;
	}

	my($mStr2) = '';
	if(($HhideMoneyMode == 1) || ($mode == 1)) {
		# 무조건또는 owner 모드
		$mStr2 = "$island->{'money'}$HunitMoney";
	} elsif($HhideMoneyMode == 2) {
		$mStr2 = aboutMoney($island->{'money'});
	}
	1 while $mStr2 =~ s/(.*\d)(\d\d\d)/$1,$2/;

	# 대전 상대의 표시
	my $fight_name = '';
	if($island->{'fight_id'}> 0 && $island->{'pop'}> 0) {
		my $HcurrentNumber = $HidToNumber{$island->{'fight_id'}};
		if($HcurrentNumber ne '') {
			my $tIsland = $Hislands[$HcurrentNumber];
			my $name = '<A HREF="'.$HthisFile."?Sight=$tIsland->{'id'}&MP=$HinputPassword2\">$tIsland->{'name'}$AfterName</A>";
			$fight_name = "상대: $name<br>";
		}
	}

	# 개발 정지의 표시
	my $rest_msg = '';
	if($island->{'rest'}> 0 && $HislandNumber> 1 && $island->{'pop'}> 0) {
		$rest_msg = "부전승으로 개발 정지 중 ";
		$rest_msg.= "남은<FONT COLOR=RED>".$island->{'rest'}."</FONT>턴<br>";
	}

	my $cmd;
	if($mode) {
		$name = "$island->{'name'}$AfterName 개발 화면";
		$cmd = '<br><input type="submit" name="Mobile3" value="계획 목록">';
		$cmd.= '<input type="submit" name="Mobile4" value="계획입력">';
	} else {
		$name = "$island->{'name'}$AfterName 관광 화면";
	}

	out(<<END);
$name<br>
<hr>
순위: $rank<br>
인구: $pop<br>
자금: $mStr2<br>
식량: $food<br>
면적: $area<br>
농장: $farm<br>
공장: $factory<br>
채택채굴: $mountain<br>
$rest_msg
$fight_name
$mStr1
<hr>
<form action="./hako-main.cgi" method="POST">
<input type="hidden" name="ISLANDID" value="$island->{'id'}">
<input type="hidden" name="PASSWORD" value="$HinputPassword">
<input type="hidden" name="PASSWORD2" value="$HinputPassword2">
<input type="submit" name="Mobile1" value="사건">
<input type="submit" name="Mobile5" value="게시판">
$cmd
</form>
<hr>
END
}

# 섬 지도
sub MislandMap {
	my $mode = shift;
	my $island = $Hislands[$HcurrentNumber];

	# 지형, 지형 값을 가져옴
	my($x, $y);
	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};
	my(@mx) = @{$island->{'map'}->{'x'}};
	my(@my) = @{$island->{'map'}->{'y'}};
	my @co = ('0','1','2','3','4','5','6','7','8','9');
	# 좌표(상)을 출력
	foreach $x (@mx) {
		out("$co[($x%10)]");
	}
	out("<br>\n<FONT COLOR=\"#0000FF\">");

	# 각 지형및 줄바꿈을 출력
	foreach $y (@my) {
		# 짝 수번호이면 번호를 출력
		if(!($y % 2)) {
			my $line = ($y>= 10) ? $y-10 : $y;
			out($line);
		}

		# 각 지형을 출력
		foreach $x (@mx) {
			my $l = $land->[$x][$y];
			my $lv = $landValue->[$x][$y];
			MlandString($l, $lv, $x, $y, $mode);
		}

		# 홀 수번호이면 번호를 출력
		if($y % 2) {
			my $line = ($y>= 10) ? $y-10 : $y;
			out($line);
		}

		# 줄바꿈을 출력
		out("<br>\n");
	}

	out("</FONT>\n");
	out("&nbsp;");
	foreach $x (@mx) {
		out("$co[($x%10)]");
	}
	out("<br>\n");
}

# 1헥스
sub MlandString {
	my($l, $lv, $x, $y, $mode) = @_;
	my($point) = "($x,$y)";
	my($alt, $color, $img);

	if(!$mode && $HjammingView) {
		if(($l == $HlandSea) ||
			($l == $HlandSbase) ||
			($l == $HlandSeaMine) ||
			($l == $HlandOil)) {
			$l = $HlandSea;
			$lv = 2;
		} elsif(($l == $HlandWaste) ||
			($l == $HlandPlains) ||
			($l == $HlandForest) ||
			($l == $HlandTown) ||
			($l == $HlandFarm) ||
			($l == $HlandFactory) ||
			($l == $HlandBase) ||
			($l == $HlandDefence) ||
			($l == $HlandBouha) ||
			($l == $HlandHaribote) ||
			($l == $HlandMountain) ||
			($l == $HlandComplex) ||
			($l == $HlandMonument)) {
			$l = $HlandWaste;
			$lv = 2;
		} elsif(($l == $HlandMonster) ||
			($l == $HlandHugeMonster)) {
			my($id, $flag) = (monsterUnpack($lv))[0,4];
			if($flag & 2) {
				$l = $HlandSea;
				$lv = 2;
			} else {
				$l = $HlandWaste;
				$lv = 2;
			}
		} elsif($l == $HlandCore) {
			if(int($lv/10000)) {
				$l = $HlandSea;
				$lv = 2;
			} else {
				$l = $HlandWaste;
				$lv = 2;
			}
		} elsif($l == $HlandNavy) {
			$l = $HlandSea;
			$lv = 2;
		}
	}

	if($l == $HlandSea) {
		if($lv == 1) {
			# 얕은 바다
			$alt = '-';
#			$color = '#0000FF';
		} else {
			# 바다
			$alt = '~';
#			$color = '#0000FF';
		}
	} elsif($l == $HlandWaste) {
		# 황무지
		$alt = '■';
		$color = '#800000';
	} elsif($l == $HlandPlains) {
		# 평지
		$alt = '□';
		$color = '#00F000';
	} elsif($l == $HlandForest) {
		# 숲
		$alt = "숲";
		$color = '#008800';
	} elsif($l == $HlandTown) {
		my $tName;
		foreach (reverse(0..$#HlandTownValue)) {
			if($HlandTownValue[$_] <= $lv) {
				$tName = $HlandTownName[$_];
				last;
			}
		}
		$alt = substr($tName, 0, 2);
		$color = '#996600';
	} elsif($l == $HlandFarm) {
		# 농장
		$alt = "농업";
		$color = '#00FF00';
	} elsif($l == $HlandFactory) {
		# 공장
		$alt = "공사";
		$color = '#606060';
	} elsif($l == $HlandBase) {
		if($mode == 0) {
			# 관광객의 경우
			$alt = '숲';
		} else {
			# 미사일 기지
			$alt = "미";
		}
		$color = '#008800';
	} elsif($l == $HlandSbase) {
		if($mode == 0) {
			# 관광객의 경우
			$alt = '~';
		} else {
			# 미사일 기지
			$alt = "미";
		}
#		$color = '#0000FF';
	} elsif($l == $HlandDefence) {
		# 방위 시설
		if($HdBaseHide && $mode == 0) {
			$alt = '숲';
			$color = '#008800';
		} else {
			$alt = '방어';
			$color = '#FF0000';
		}
	} elsif($l == $HlandBouha) {
		# 방파제
		$alt = "제방";
		$color = '#008800';
	} elsif($l == $HlandSeaMine) {
		# 기뢰
		if($mode == 0) {
			$alt = '~';
		} else {
			$alt = '기계';
		}
#		$color = '#0000FF';
	} elsif($l == $HlandHaribote) {
		# 가짜 시설
		if($mode == 0) {
			# 관광객의 경우 숲인 척
			$alt = '숲';
		} else {
			$alt = '하';
		}
		$color = '#FF0000';
	} elsif($l == $HlandOil) {
		# 해저 유전
		$alt = "기름";
		$color = '#00FF00';
	} elsif($l == $HlandMountain) {
		# 산
		if($lv> 0) {
			$alt = "채택";
		} else {
			$alt = '산';
		}
		$color = '#C03030';
	} elsif($l == $HlandCore) {
		# 코어
		if($HcoreHide && $mode == 0) {
			if(int($lv/10000)) {
				# 바다
				$alt = '~';
#				$color = '#0000FF';
			} else {
				$alt = '숲';
				$color = '#008800';
			}
		} else {
			$alt = '코';
			$color = '#00FF00';
		}
	} elsif($l == $HlandComplex) {
		# 복합 지형
		my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($lv);
		my $cName = $HcomplexName[$cKind];
# UTF-8 환경: 기존 문자 변환 예제는 네이티브 UTF-8 처리로 대합니다.
		$alt = substr($cName, 0, 2);
		$color = '#00FF00';
	} elsif($l == $HlandMonster) {
		# 괴수
		my($id, $hflag, $sea, $exp, $flag, $kind, $hp) = monsterUnpack($lv);
		my $mName = $HmonsterName[$kind];
# UTF-8 환경: 기존 문자 변환 예제는 네이티브 UTF-8 처리로 대합니다.
		$alt = substr($mName, 0, 2);
		$color = '#FF00FF';
	} elsif($l == $HlandHugeMonster) {
		# 거대괴수
		my($id, $hflag, $sea, $exp, $flag, $kind, $hp) = monsterUnpack($lv);
		my $mName = $HhugeMonsterName[$kind];
# UTF-8 환경: 기존 문자 변환 예제는 네이티브 UTF-8 처리로 대합니다.
		$alt = substr($mName, 0, 2);
		$color = '#FF00FF';
	} elsif($l == $HlandNavy) {
		# 해군
		my($id, $tmp, $stat, $sea, $exp, $flag, $no, $kind, $hp) = navyUnpack($lv);
		my $nName = $HnavyName[$kind];
# UTF-8 환경: 기존 문자 변환 예제는 네이티브 UTF-8 처리로 대합니다.
		$alt = substr($nName, 0, 2);
#		$color = '#0000FF';
	}

	if($color ne '' && $HinputPassword2 == 1) {
		$alt = "<font color='$color'>$alt</font>";
	} elsif($color eq '#008800' || $color eq '#FF0000') {
		$alt = "<font color='$color'>$alt</font>";
	}

	out $alt;
}

#----------------------------------------------------------------------
# HTML 출력
#----------------------------------------------------------------------
# 턴 갱신대기치
sub MturnPageMain {
	unlock();

	out("턴 갱신대기치입니다. 잠시 기다렸다가 접속해 주세요.");
}

# 섬 번호 목록
sub MlistPageMain {
	unlock();

	out("[순위] $AfterName 번호: $AfterName이름<hr>");
	for($i = 0; $i < $HislandNumber; $i++) {
		my $j = $i + 1 - $HbfieldNumber;
		$j = 'BF' if($j <= 0);
		my $island = $Hislands[$i];
		out("[$j] $island->{'id'}: $island->{'name'}$AfterName<br>\n");
	}
}

# 계획입력
sub McmdInputPageMain {
	my $island = $Hislands[$HcurrentNumber];

	$HcommandPlanNumber++;
	$HcommandKind = 0 if($HcommandKind eq '');
	$HcommandArg = 0 if($HcommandArg eq '');
	$HcommandX = 0 if($HcommandX eq '');
	$HcommandY = 0 if($HcommandY eq '');
	$HcommandMode = 'insert' if($HcommandMode eq '');

	out(<<END);
<form action="./hako-main.cgi" method="POST">
계획번호(1~$HcommandMax)<br>
[1]<input type="text" name="NUMBER" value="$HcommandPlanNumber" size="2" accesskey="1" istyle="4"><br>
<br>

계획<br>
<select name="COMMAND" accesskey="2">
END

	#명령
	my($kind, $cost);
	for($i = 0; $i < $HcommandTotal; $i++) {
		my $s;
		$kind = $HcomList[$i];
		$cost = $HcomCost[$kind];
		if($cost eq '0') {
			$cost = '무료';
		} elsif($cost =~ /^\@(.*)$/) {
			$cost = $1;
		} elsif($cost < 0) {
			$cost = - $cost;
			$cost.= $HunitFood;
		} else {
			$cost.= $HunitMoney;
		}
		$s = ' selected' if($kind == $HcommandKind);

		out("<option value='$kind'$s>$HcomName[$kind]($cost)\n");
	}

	out(<<END);
</select><br>
<br>
좌표(가로, 세로)<br>
[2]<input type="text" name="POINTX" value="$HcommandX" size="2" accesskey="2" istyle="4">,
[3]<input type="text" NAME="POINTY" value="$HcommandY" size="2" accesskey="3" istyle="4"><br>
<br>

수량(0~49)<br>
[4]<input type="text" name="AMOUNT" value="$HcommandArg" size="2" accesskey="4" istyle="4"><br>
<br>

목표<br>
<select name="TARGETID" accesskey="6">
END
	out(getIslandList($island->{'id'},1,$island->{'fight_id'}));
	out(<<END);
<br>
</select><br>
<br>
동작<br>
<input type="radio" name="COMMANDMODE" value="insert" accesskey="5" checked>[5]삽입<br>
<input type="radio" name="COMMANDMODE" value="write" accesskey="6">[6] 덮어쓰기<br>
<input type="radio" name="COMMANDMODE" value="delete" accesskey="7">[7] 삭제<br>
<br>
<input type="hidden" name="PASSWORD" value="$HinputPassword">
<input type="hidden" name="PASSWORD2" value="$HinputPassword2">
<input type="submit" value="계획 전송" name="CommandButton$island->{'id'}">
</form>
<hr>
END
	McmdListPageMain(int($HcommandMax/2));
}

# 계획 목록
sub McmdListPageMain {
	my $max = shift;

	for($i = 0; $i < $max; $i++) {
		MtempCommand($i, $Hislands[$HcurrentNumber]->{'command'}->[$i]);
	}
}

# 계획 표시
sub MtempCommand {
	my($number, $command) = @_;
	my($kind, $target, $x, $y, $arg, $target2) =
	(
		$command->{'kind'},
		$command->{'target'},
		$command->{'x'},
		$command->{'y'},
		$command->{'arg'},
		$command->{'target2'}
	);
	my $name = "${HcomName[$kind]}";
	my $point = "($x,$y)";

	my($j) = sprintf("[%02d] ", $number + 1);

	out("$j");

	if(($kind == $HcomDoNothing) || ($kind == $HcomAutoPrepare3) || ($kind == $HcomGiveup)) {
		# 명령 이름만(좌표없음)
		out($name);
	} elsif ((($HcomMissile[0] < $kind) && ($kind <= $HcomMissile[$#HmissileName])) || ($kind == $HcomNavyTarget)) { # 미사일 발사
		# 대상 섬있음(좌표 포함)
		$target = $HidToName{$target};
		$target = ($target eq '') ? "무인$AfterName" : "${target}$AfterName";

		$name =~ s/발사//;
		if($arg == 0 || ($kind == $HcomNavyTarget)) {
			out("${name}=>${target}${point}");
		} else {
			out("${name}x$arg=>${target}${point}");
		}
	} elsif(($kind == $HcomAmity) ||
		($kind == $HcomAlly) ||
		($kind == $HcomDeWar) ||
		($kind == $HcomCeasefire) ||
		($kind == $HcomSendMonster) ||
		($kind == $HcomSendMonsterST) ||
		($kind == $HcomNavySend) ||
		($kind == $HcomNavyReturn) ||
		($kind == $HcomMoveTarget) ||
		($kind == $HcomNavyMission)) {
		# 대상 섬있음(좌표없음)
		$target = $HidToName{$target};
		$target = ($target eq '') ? "무인$AfterName" : "${target}$AfterName";

		$name =~ s/발사//;
		if($arg == 0) {
			out("${name}=>${target}");
		} else {
			out("${name}x${arg}=>${target}");
		}
	} elsif($kind == $HcomNavyMove) {
		$target = $HidToName{$target};
		$target = ($target eq '') ? "무인$AfterName" : "${target}$AfterName";
		$target2 = $HidToName{$target2};
		$target2 = ($target2 eq '') ? "무인$AfterName" : "${target2}$AfterName";
		out("${name}=>${target}->${target2}");
	} elsif(($kind == $HcomSell) ||
		($kind == $HcomBuy) ||
		($kind == $HcomPropaganda)) {
		# 횟수 포함
		if($arg == 0) {
			out("$name");
		} else {
			out("${name}x$arg");
		}
	} elsif(($kind == $HcomFarm) ||
		 ($kind == $HcomFastFarm) ||
		 ($kind == $HcomFactory) ||
		 ($kind == $HcomFastFactory) ||
		 ($kind == $HcomDestroy) ||
		 ($kind == $HcomMoveMission) ||
		 (($HcomComplex[0] <= $kind) && ($kind <= $HcomComplex[$#HcomplexComName])) || # 복합 지형건설
		 ($kind == $HcomMountain)) {
		# 좌표·횟수 포함
		if($arg == 0) {
			out("${name}=>${point}");
		} else {
			out("${name}x${arg}=>${point}");
		}
	} else {
		# 좌표 포함
		out("${name}=>${point}");
	}

	out("<br>\n");
}

# 각종링크
sub MlinkPageMain {
#	my $bbTime = get_time((stat($bbsLog))[9], 1, 1);
	unlock();

	out(<<END);
END
#	out(<<END);
#<BR>
#- <A HREF="$toppage">홈</A><br>
#- <A HREF="$bbs">$bbsname</A>$bbTime<br>
#END
}

# 지도도움말
sub MhelpPageMain {
	unlock();

	out(<<END);
<font color="#0000FF">-</font> → 얕은 바다<br>
<font color="#0000FF">~</font> → 바다<br>
<font color="#800000">■</font> → 황무지<br>
<font color="#00F000">□</font> → 평지<br>
<font color="#008800">숲</font> → 숲<br>
<br>
<font color="#00FF00">농업</font> → 농장<br>
<font color="#606060">공사</font> → 공장<br>
<font color="#C03030">채택</font> → 채굴장<br>
<font color="#C03030">산</font> → 산<br>
<font color="#00FF00">기름</font> → 해저 유전<br>
<br>
<font color="#008800">미</font> → 미사일 기지<br>
<font color="#0000FF">미</font> → 해저 기지<br>
<font color="#FF0000">방어</font> → 방위 시설<br>
<font color="#FF0000">하</font> → 가짜 시설<br>
<font color="#008800">제방</font> → 방파제<br>
<font color="#0000FF">기계</font> → 기뢰<br>
<font color="#FF00FF">코</font> → 코어<br>
<br>
END

	out("[도시계]<br>");
	foreach(@HlandTownName) {
		my $alt = substr($_, 0, 2);
		out("<font color=\"#996600\">$alt</font> → $_<br>");
	}
	out("[복합 지형]<br>");
	foreach(@HcomplexName) {
		my $alt = substr($_, 0, 2);
		out("<font color=\"#00FF00\">$alt</font> → $_<br>");
	}
	out("<br>[해군]<br>");
	foreach(@HnavyName) {
		my $alt = substr($_, 0, 2);
		out("<font color=\"#0000FF\">$alt</font> → $_<br>");
	}
	out("<br>[괴수]<br>");
	foreach(@HmonsterName) {
		my $alt = substr($_, 0, 2);
		out("<font color=\"#FF00FF\">$alt</font> → $_<br>");
	}
	out("<br>[거대괴수]<br>");
	foreach(@HhugeMonsterName) {
		my $alt = substr($_, 0, 2);
		out("<font color=\"#FF00FF\">$alt</font> → $_<br>");
	}
}

# 메인 페이지
sub MtopPageMain {
	unlock();

	if($HinputPassword2 ne '') {
		$sL[$HinputPassword2] = ' selected';
	} else {
		$sL[1] = ' selected';
	}

	if($HislandNumber> 1 || $HislandTurn == 0) {
		# 시간 표시
		my($hour, $min, $sec);
		my($now) = time;
		my($showTIME) = ($HislandLastTime + $HunitTime - $now);
		$hour = int($showTIME / 3600);
		$min = int(($showTIME - ($hour * 3600)) / 60);
		$sec = $showTIME - ($hour * 3600) - ($min * 60);
		if ($sec < 0 or $HislandTurnCount> 1){
			out("(턴 갱신대기치입니다. 잠시 기다렸다가 접속해 주세요.)");
		} else {
			if(!$Htime_mode) {
				my($sec2,$min2,$hour2,$mday2,$mon2) = get_time($HislandLastTime + $HunitTime);
				out("다음 갱신일 시 $mon2월$mday2일$hour2 시$min2분<br>남은 $hour시간 $min 분 $sec 초");
			} else {
				out("(다음 턴까지, 남은 $hour시간 $min 분 $sec 초)");
			}
		}
	}

	out(<<END);
<hr>
<form action="./hako-main.cgi" method="POST">
ID:<input type="text" name="ISLANDID" size="3" value="$HcurrentID" istyle="4"><br>
PS:<input type="text" name="PASSWORD" size="6" value="$HinputPassword" istyle="3"><br>
색상 모드:<br>
<select name="PASSWORD2">
<option$sL[0] value="0">표준
<option$sL[1] value="1">전체색상
</select><br>
<input type="submit" name="Mobile2" value="개발">
<input type="submit" name="Mobile0" value="관광">
<input type="submit" name="Mobile1" value="사건">
<input type="submit" name="Mobile5" value="게시판">
</form>

<br>
<a href="./hako-main.cgi?TimeTable=1">$AfterName 번호 목록</a>
END
}

# 지도 화면의 양식 링크
sub MtoMapLink {
	my $mode = shift;

	my $name = ($mode) ? '개발' : '관광';
	my $num = ($mode) ? 2 : 0;

	out(<<END);
<form action="./hako-main.cgi" method="POST">
<input type="hidden" name="ISLANDID" value="$HcurrentID">
<input type="hidden" name="PASSWORD" value="$HinputPassword">
<input type="hidden" name="PASSWORD2" value="$HinputPassword2">
<input type="submit" name="Mobile${num}" value="${name} 화면">
<input type="submit" name="Mobile5" value="게시판">
</form>
END
}

sub get_time {
	my $time = $_[0];
	my($sec,$min,$hour,$mday,$mon) = localtime($time);
	$mon = "0".$mon if($mon++ < 9);
	$mday = "0".$mday if($mday < 10);
	$hour = "0".$hour if($hour < 10);
	$min = "0".$min if($min	< 10);
	if($_[1] == 1) {
		return '' if($time == 1);
		if($time + 60000 < time()) {
			$date = sprintf("</b>%02d/%02d<b>", $mon,$mday);
		} else {
			$date = sprintf("<b>%02d:%02d</b>", $hour,$min);
		}
		return "(${date})";
	}
	return ($sec,$min,$hour,$mday,$mon);
}

1;

