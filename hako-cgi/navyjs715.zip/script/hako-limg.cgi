#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 이미지 경로 설정·모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 이미지 경로 설정
#----------------------------------------------------------------------
# 메인
sub localImgMain {

	my($Himfflag);
	$Himfflag = $HimageDir;
	# 화면 출력
	unlock();

 out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='localImage'>
<H1>이미지 경로 설정</H1>
<table border width=50%><tr><td class='N'>
 이미지를 로컬 PC에서 불러와 서버 부하를 줄이고 표시 속도를 높입니다.<br>
 이미지는<B><a href="$localImg">여기</a></B>에서 다운로드하고,1개의 폴더에압축 해제시, 아래의 설정에서'land0.gif'을지정해 주세요.<br>
 그것만에서 표시됨없는 경우, 인터넷 옵션의 신뢰의 뢰완료미사이트로"${HbaseDir}"을 추가해 주세요.<br>
 자세한 내용은<B><a href="$imageExp">설명의 페이지</a></B>을 확인해 주세요.
</td></tr></table>
<table border=0 width=50%><tr><td class="M">
현재 설정<B>[</b> ${Himfflag} <B>]</B>
<form action=$HthisFile method=POST>
<INPUT TYPE=file NAME="IMGLINE">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET>
</form>

<form action=$HthisFile method=POST>
Mac 사용자용<BR>
<INPUT TYPE=text NAME="IMGLINEMAC">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET><BR>
<FONT SIZE=-1>Mac 사용자는, 여기를 사용해 주세요.</FONT>
</form>

<form action=$HthisFile method=POST>
<INPUT TYPE=hidden NAME="IMGLINE" value="deletemodenow">
<INPUT TYPE="submit" VALUE="설정 해제" name=IMGSET>
</form>
</td></tr></table>
</DIV>
END
}

1;

###----------###
### 도입방법 ###
###----------###

### 행 앞부분의 #을 포함해 복사해 붙여넣으세요. ###은 도입 설명용 주석이므로 복사할 필요가 없습니다

### 메인 모드분기 부분에추가
#} elsif($HmainMode eq 'localimg') {
#	# 이미지 경로 설정
#	require('./hako-limg.cgi');
#	localImgMain();

### CGI 읽기 부분에추가 sub cgiInput 내의 main mode 의가져오기 부분
#	} elsif($getLine =~ /Limg=([0-9]*)/) {
#		$HmainMode = 'localimg';

### CGI 읽기 부분에추가 sub cgiInput 내
#	if($line =~ /IMGLINEMAC=([^&]*)\&/){
#		my($flag) = $1;
#		if($flag eq ''){
#			$flag = $HimageDir;
#		} else {
#			$flag =~ s/ /%20/g;
#			$flag = 'file:///'. $flag;
#		}
#		$HimgLine = $flag;
#	} elsif($line =~ /IMGLINE=([^&]*)\&/){
#		my($flag) = $1;
#		$flag =~ tr/\\/\//;
#		if(($flag eq 'deletemodenow') || ($flag eq '')){
#			$flag = $HimageDir;
#		} else {
#			$flag =~ s/\/[\w\.]+\.gif$//g;
#			$flag = 'file:///'. $flag;
#		}
#		$HimgLine = $flag;
#	}

### cookie 입력에추가
#	if($cookie =~ /${HthisFile}IMGLINE=\(([^\)]*)\)/) {
#		$HimgLine = $1;
#	}

### cookie 출력에추가
#	if($HimgLine) {
#		$cookie.= "Set-Cookie: ${HthisFile}IMGLINE=($HimgLine) $info";
#	}

### 헤더에추가 sub tempHeader 내의 print(out)처리이전(참고: 있다면 sub tempHeaderJava 에도추가)
#	if($HimgLine ne '' ){
#		$baseIMG = $HimgLine;
#	} else {
#		$baseIMG = $HimageDir;
#	}

### 헤더에추가 sub tempHeader 내의 BASE HREF 을 변경(참고: 있다면 sub tempHeaderJava 모 변경)
#<BASE HREF="$baseIMG/">

### 헤더나 메인 페이지의 링크 부분에추가
#	out(qq|[<A href="$HthisFile?Limg=0">이미지 경로 설정</A>] |);
### out 을사용하지 않아도해도,[<A href="$HthisFile?Limg=0">이미지 경로 설정</A>]이 HTML 안에 기술되도록 하면 됩니다
