#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 모형정원 바다전쟁 JS ver7.xx
# 관리 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 관리자가 수행하는 선전포고 점검
#----------------------------------------------------------------------
sub dewarSetupMain() {
	if ($HwsetupMode) {
		# 비밀번호 확인
		if(checkSpecialPassword($HdefaultPassword)) {
			# 특수 비밀번호
			undef @HwarIsland;
			for($i=0;$i < $#HdeWarChange;$i+=4){
				my($turn) = $HdeWarChange[$i];
				my($id1) = $HdeWarChange[$i+1];
				my($id2) = $HdeWarChange[$i+2];
				my($flag) = $HdeWarChange[$i+3];
				if(!$turn || $HdeWarDel{$i} || ($id1 == $id2)) {
				} else {
					push(@HwarIsland, ($turn, $id1, $id2, $flag));
				}
			}
			writeIslandsFile();
			# 변경 성공
		} else {
			# 비밀번호 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
	# 템플릿 출력
	tempDeWarSetupPage();
}

# 선전포고점검페이지
sub tempDeWarSetupPage() {
	# 화면 출력
	unlock();
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<DIV ID='campInfo'>
<H1>선전포고 설정</H1>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="WSetup">
<TABLE BORDER><TR>
<TH $HbgTitleCell colspan=5>${HtagTH_}선전포고 설정${H_tagTH} <INPUT TYPE="submit" VALUE="변경" NAME="WarChangeButton"></TH>
</TR><TR>
<TD align="center">${HtagTH_}삭제${H_tagTH}</TD>
<TD align="center">${HtagTH_}시작 턴${H_tagTH}</TD>
<TD align="center">${HtagTH_}선전포고한${AfterName}${H_tagTH}</TD>
<TD align="center">${HtagTH_}선전포고를 받은${AfterName}${H_tagTH}</TD>
<TD align="center">${HtagTH_}상태${H_tagTH}</TD></TR>
END

	my($i, $j, %warFlag);
	for($i=0;$i < $#HwarIsland;$i+=4){
		my($turn) = $HwarIsland[$i];
		my($id1) = $HwarIsland[$i+1];
		my($id2) = $HwarIsland[$i+2];
		my($flag) = $HwarIsland[$i+3] % 10;
		my($fturn) = int($HwarIsland[$i+3] / 10);

		my $islandList1 = getIslandList($id1, 1, 'yellow');
		my $islandList2 = getIslandList($id2, 1, 'yellow');
		my $turnList = "<OPTION VALUE=\"$turn\" style=\"background:yellow;\" selected>$turn";
		for($j=$turn+1;$j<$turn+100;$j++) {
			$turnList.= "<OPTION VALUE=\"$j\">$j";
		}
		my @s = ('', '', '');
		$s[$flag] = " style=\"background:yellow;\" selected";
		my($t1, $t2);
		$t1 = ($fturn) ? $fturn : $HislandTurn;
		$t1 *= 10;
		$t1++;
		$t2 = $t1 + 1;

		out(<<END);
<TR>
<TD align="center"><input type=checkbox name=del value="$i"></TD>
<TD align="center"><select name=war>$turnList</select></TD>
<TD align="center"><select name=war>$islandList1</select></TD>
<TD align="center"><select name=war>$islandList2</select></TD>
<TD align="center"><select name=war>
<OPTION VALUE="0"$s[0]>교전 중 아님
<OPTION VALUE="$t1"$s[1]>정전 교섭안(선전포고 측)
<OPTION VALUE="$t2"$s[2]>정전 교섭안(피선전포고 측)
</select></TD></TR>
END
	}
	my $turnList = "<OPTION VALUE=\"0\" style=\"background:red;\" selected>추가하지 않음";
	for($j=$HislandTurn+1;$j<$HislandTurn+100;$j++) {
		$turnList.= "<OPTION VALUE=\"$j\">$j";
	}
	my $islandList = getIslandList(0, 1);
	$t1 = $HislandTurn * 10 + 1;
	$t2 = $t1 + 1;
	out(<<END);
<TR>
<TH>신규</TH>
<TH><select name=war>$turnList</select></TH>
<TD align="center"><select name=war>$islandList</select></TD>
<TD align="center"><select name=war>$islandList</select></TD>
<TD align="center"><select name=war>
<OPTION VALUE="0">교전 중 아님
<OPTION VALUE="$t1">정전 교섭안(선전포고 측)
<OPTION VALUE="$t2">정전 교섭안(피선전포고 측)
</select></TD></TR>
</TABLE><INPUT TYPE="hidden" VALUE="dummy" NAME="WarChange"></FORM></DIV>
END
}

#----------------------------------------------------------------------
# 관리자가 수행하는 우호국·동맹(진영) 설정
#----------------------------------------------------------------------
sub amitySetupMain() {
	if ($HasetupMode) {
		# 비밀번호 확인
		if(checkSpecialPassword($HdefaultPassword)) {
			# 특수 비밀번호
			my($id, $aId);
			foreach (0..$islandNumber) {
				undef $Hislands[$_]->{'amity'};
				undef $Hislands[$_]->{'allyId'};
			}
			my $allyNumber = $HallyNumber - 1;
			foreach (0..$allyNumber) {
				undef $Hally[$_]->{'memberId'};
				undef $Hally[$_]->{'number'};
				undef $Hally[$_]->{'score'};
				my $aId = $Hally[$_]->{'id'};
				if(defined $HidToNumber{$aId}) {
					push(@{$Hally[$_]->{'memberId'}}, $Hally[$_]->{'id'});
					$Hally[$_]->{'score'} += $Hislands[$HidToNumber{$aId}]->{$HrankKind} if(!$Hislands[$HidToNumber{$aId}]->{'predelete'});
					push(@{$Hislands[$HidToNumber{$aId}]->{'allyId'}}, $aId);
				}
			}
			foreach (@HamityChange) {
				($id, $aId) = split(/-/, $_);
				push(@{$Hislands[$HidToNumber{$id}]->{'amity'}}, $aId);
			}
			foreach (@HallyChange) {
				($id, $aId) = split(/-/, $_);
				$Hally[$HidToAllyNumber{$aId}]->{'score'} += $Hislands[$HidToNumber{$id}]->{$HrankKind} if(!$Hislands[$HidToNumber{$id}]->{'predelete'});
				next if($id == $aId);
				push(@{$Hally[$HidToAllyNumber{$aId}]->{'memberId'}}, $id);
				push(@{$Hislands[$HidToNumber{$id}]->{'allyId'}}, $aId);
			}
			foreach (0..$allyNumber) {
				$Hally[$_]->{'number'} = @{$Hally[$_]->{'memberId'}};
			}
			allyOccupy();
			allySort();
			writeIslandsFile();
			# 변경 성공
		} else {
			# 비밀번호 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
	# 템플릿 출력
	tempAmitySetupPage();
}

# 우호국 설정 페이지
sub tempAmitySetupPage() {
	# 화면 출력
	unlock();
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<DIV ID='campInfo'>
<H1>우호국·동맹(진영) 설정</H1>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="ASetup">
<TABLE BORDER><TR>
<TH $HbgTitleCell rowspan=2>${HtagTH_}우호국 설정${H_tagTH}<BR><INPUT TYPE="submit" VALUE="변경" NAME="AmityChangeButton"></TH>
END

	my($i, %warFlag);
	for($i=0;$i < $#HwarIsland;$i+=4){
		my($id1) = $HwarIsland[$i+1];
		my($id2) = $HwarIsland[$i+2];
		my($tn1) = $HidToNumber{$id1};
		my($tn2) = $HidToNumber{$id2};
		next if(($tn1 eq '') || ($tn2 eq ''));
		$warFlag{"$id1,$id2"} = 1;
	}
	foreach (0..$islandNumber) {
		$Hislands[$_]->{'ally'} = $Hislands[$_]->{'allyId'}[0];
	}
	my @idx = (0..$#Hislands);
	@idx = sort {
			$Hislands[$b]->{'field'} <=> $Hislands[$a]->{'field'} || # 전장우선
			$Hislands[$b]->{'ally'} <=> $Hislands[$a]->{'ally'} || # 동맹에서 정렬
			$a <=> $b # $kind가 같으면 이전 순서를 유지
		 } @idx;

	my $aStr = ($HarmisticeTurn) ? '진영' : '동맹';
	out("<TH $HbgTitleCell colspan=$HislandNumber>${HtagTH_}${AfterName} 이름${H_tagTH}</TH>\n");
	out("<TH $HbgTitleCell colspan=$HallyNumber>${HtagTH_}${aStr}${H_tagTH}</TH>") if($HallyNumber);
	out("</TR><TR>\n");
	my($number, $island, $name, $ally);
	foreach (0..$islandNumber) {
		$island = $Hislands[$idx[$_]];
		$name = islandName($island);
		out(<<END);
<TD class='T'>$name</TD>
END
	}
	my $allyNumber = $HallyNumber - 1;
	foreach (0..$allyNumber) {
		$ally = $Hally[$_];
		$name = "<FONT COLOR=\"$ally->{'color'}\"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}";
		out(<<END);
<TD class='T'>$name</TD>
END
	}
	out("</TR>\n");
	foreach (0..$islandNumber) {
		$island = $Hislands[$idx[$_]];
		$name = islandName($island);
		my($id, $amity, %amityFlag, $aId);
		$id = $island->{'id'};
		$amity = $island->{'amity'};
		foreach (@$amity) {
			$amityFlag{$_} = 1;
		}
		out("<TR><TH $HbgTitleCell>$name</TH>");
		foreach $number (0..$islandNumber) {
			$aId = $Hislands[$idx[$number]]->{'id'};
			if($id == $aId) {
				out("<TD align=\"center\">=</TD>");
			} elsif($warFlag{"$id,$aId"}) {
				out("<TD align='center'>${HtagDisaster_}X${H_tagDisaster}</TD>\n");
			} elsif($warFlag{"$aId,$id"}) {
				out("<TD align='center'>${HtagDisaster_}x${H_tagDisaster}</TD>\n");
			} elsif($amityFlag{$aId}) {
				out("<TD align=\"center\"><input type=checkbox name=amity value=\"$id-$aId\" CHECKED></TD>");
			} else {
				out("<TD align=\"center\"><input type=checkbox name=amity value=\"$id-$aId\"></TD>");
			}
		}
		for ($i = 0; $i < $HallyNumber; $i++) {
			$ally = $Hally[$i];
			$aId = $ally->{'id'};
			my $member = $Hally[$i]->{'memberId'};
			my $flag = 1;
			foreach (@$member) {
				if($id == $_) {
					$flag = 0;
					last;
				}
			}
			if($flag) {
				out("<TD align=\"center\"><input type=checkbox name=ally value=\"$id-$aId\"></TD>");
			} else {
				out("<TD align=\"center\"><input type=checkbox name=ally value=\"$id-$aId\" CHECKED></TD>");
			}
		}
		out("</TR>\n");
	}
	out(<<END);
</TABLE><INPUT TYPE="hidden" VALUE="dummy" NAME="AmityChange"></FORM></DIV>
END
}

#----------------------------------------------------------------------
# 관리자 선물 지급 모드
#----------------------------------------------------------------------
sub presentMain {
	if (!$HpresentMode) {
		# 화면 출력
		$HislandList = getIslandList($Hislands[$HbfieldNumber]->{'id'}, 1);
		unlock();

		# 템플릿 출력
		tempPresentPage();
	} else {
		# 비밀번호 확인
		if(checkSpecialPassword($HoldPassword)) {
			# 특수 비밀번호

			if (!$HpresentMoney && !$HpresentFood) {
				# 자금과 식량이 모두 없음
				tempPresentEmpty();
				unlock();
				return;
			}

			# id에서 섬을 가져옴
			$HcurrentNumber = $HidToNumber{$HcurrentID};
			my($island) = $Hislands[$HcurrentNumber];
			my($name) = $island->{'name'};

			$island->{'money'} += $HpresentMoney;
			$island->{'money'} = 0 if ($island->{'money'} < 0);
			$island->{'food'} += $HpresentFood;
			$island->{'food'} = 0 if ($island->{'food'} < 0);

			logPresent($HcurrentID, $name, $HpresentLog);

			# 데이터 쓰기
			writeIslandsFile($HcurrentID);
			unlock();

			# 변경 성공
			tempPresentOK($name);
		} else {
			# 비밀번호 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
}

# 선물 모드의 메인 페이지
sub tempPresentPage {
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<H1>참가 ${AfterName}에게 선물 지급</H1>

<FORM action="$HthisFile" method="POST">
<B>선물을 받을 ${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
<BR>
<B>선물의 내용은?(마이너스 값도 가능)</B><BR>
<INPUT TYPE="text" NAME="PRESENTMONEY" VALUE="0" SIZE=16 MAXLENGTH=16>$HunitMoney<BR>
<INPUT TYPE="text" NAME="PRESENTFOOD" VALUE="0" SIZE=16 MAXLENGTH=16>$HunitFood<BR>
<BR>
<B>로그 메시지는?(생략 가능. 선두에${AfterName} 이름이 삽입됩니다)<small>(최대 ${HlengthPresentLog}자)</small></B><BR>
○○${AfterName}<INPUT TYPE="text" NAME="PRESENTLOG" VALUE="" SIZE=128 MAXLENGTH=256><BR>
<BR>
<B>마스터 비밀번호</B><BR>
<INPUT TYPE="password" NAME="OLDPASS" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32 class=f><BR>
<INPUT TYPE="submit" VALUE="선물 지급" NAME="PresentButton"><BR>
</FORM>
END
}

# 선물 지급 완료
sub tempPresentOK {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}에게 선물을 지급했습니다${H_tagBig}$HtempBack
END
}

# 선물 내용 확인
sub tempPresentEmpty {
	out(<<END);
${HtagBig_}선물 내용이 올바르지 않습니다${H_tagBig}$HtempBack
END
}

# 선물
sub logPresent {
	my($id, $name, $log) = @_;
	logHistory("${HtagName_}${name} 섬${H_tagName}$log") if ($log ne '');
}

#----------------------------------------------------------------------
# 관리자가 수행하는 제재 모드
#----------------------------------------------------------------------
sub punishMain {
	if(checkSpecialPassword($HdefaultPassword)) {
		# 특수 비밀번호
		if ($HpunishMode) {
			my(%punish);
			if (open(Fpunish, "<${HdirName}/punish.cgi")) {
				local(@_);
				while (<Fpunish>) {
					chomp;
					@_ = split(',');
					my($obj);
					$obj->{id} = shift;
					$obj->{punish} = shift;
					$obj->{x} = shift;
					$obj->{y} = shift;
					$punish{$obj->{id}} = $obj;
				}
				close(Fpunish);
			}

			if (open(Fpunish, ">${HdirName}/punish.cgi")) {
				{
					my($obj);
					$obj->{id} = $HcurrentID;
					$obj->{punish} = $HpunishID;
					$obj->{x} = $HcommandX;
					$obj->{y} = $HcommandY;
					$punish{$obj->{id}} = $obj;
				}

				my($key, $obj);
				while (($key, $obj) = each %punish) {
					next if ($obj->{punish} == 0);
					print Fpunish
						$obj->{id}. ','.
						$obj->{punish}. ','.
						$obj->{x}. ','.
						$obj->{y}. "\n";
				}
				close(Fpunish);
			}
		}
		$HislandList = getIslandList($Hislands[$HbfieldNumber]->{'id'}, 1);
		unlock();
		# 템플릿 출력
		tempPunishPage();

	} else {
		# 비밀번호 오류
		unlock();
		tempWrongPassword();
		return;
#		# 비밀번호가 일치하지 않으면메인 페이지로
#		require('./hako-top.cgi');
#		unlock();
#		# 템플릿 출력
#		tempTopPage();
	}
}

# 제재 모드의 메인 페이지
sub tempPunishPage {
	my(@punishName) =
		(
		 '없음', # 0
		 '지진', # 1
		 '쓰나미', # 2
		 '괴수(인구 조건 제거 시에만)', # 3
		 '거대괴수(인구 조건 제거 시에만)', # 4
		 '소속 불명 함정(인구 조건 제거 시에만)', # 5
		 '지반 침하(면적 조건 제거 시에만)', # 6
		 '태풍', # 7
		 '거대운석(좌표지정)', # 8
		 '운석', # 9
		 '분화(좌표지정)', # 10
		 );

	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<H1>참가 ${AfterName}에게 제재 적용</H1>

<DL>
<DT>·'규칙을 위반했다'고 판단하기 전에, 해당 규칙이 누구나 읽을 수 있는 곳에 게시되어 있는지 확인하세요.</DT>
<DT>·제재 자체는 쉽지만, 정말 관리자의 입장에서 실행해야 할 일인지 먼저 판단해 주세요.</DT>
<DT>·제재가 필요할 만큼 피해가 큰지도 생각해 주세요. 가벼운 마음으로 공격하는 사람은 언제든 있을 수 있습니다.</DT>
<DT>·<span class=attention>제재의 존재는 비공개로 유지하세요.</span>제재 사실이 공개되면 다른 플레이어와의 신뢰 관계도 무너질 수 있습니다.</DT>
</DL>

<FORM name="lcForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Punish">
<B>제재를 적용할 ${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<INPUT TYPE="button" VALUE="지도를 열기" onclick="printIsland();">
<BR><BR>
<B>좌표는? (좌표 지정이 가능한 제재에서만 유효)</B><BR>
<B>(</B><SELECT NAME=POINTX>
END

	my($i);
	foreach $i (@defaultX) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT><B>, </B><SELECT NAME=POINTY>
END

	foreach $i (@defaultY) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT><B>)</B><BR>
<BR>
<B>제재의 내용은?</B><BR>
<SELECT NAME="PUNISHID">
END

	for($i = 0; $i < $#punishName + 1; $i++) {
		out("<OPTION VALUE=\"$i\">$punishName[$i]\n");
	}

	out(<<END);
</SELECT><BR>
<BR>
<INPUT TYPE="submit" VALUE="제재 적용" NAME="PunishButton"><BR>
</FORM>
<SCRIPT Language="JavaScript">
<!--

function printIsland() {
	var iid;
	with (document.lcForm.ISLANDID) {
		iid = options[selectedIndex].value;
	}
	window.open("$HthisFile?Sight=" + iid + "&ADMINMODE=$HdefaultPassword", "punish", "toolbar=0,location=0,directories=0,menubar=0,status=1,scrollbars=1,resizable=1,width=450,height=630");
}
//-->
</SCRIPT>
END

	if (open(Fpunish, "<${HdirName}/punish.cgi")) {
		out('<HR>');
		out("<TABLE BORDER><TR><TH>${AfterName} 이름</TH><TH>제재내용</TH><TH>좌표</TH></TR>");
		local(@_);
		my($island);
		while (<Fpunish>) {
			chomp;
			@_ = split(',');
			my($obj);
			$obj->{id} = shift;
			$obj->{punish} = shift;
			$obj->{x} = shift;
			$obj->{y} = shift;

			$HcurrentNumber = $HidToNumber{$obj->{id}};
			$island = $Hislands[$HcurrentNumber];

			out("<TR><TD>$island->{'name'}${AfterName}</TD><TD>$punishName[$obj->{punish}]</TD><TD>($obj->{x}, $obj->{y})</TD></TR>");
		}
		out('</TABLE>');
		close(Fpunish);
	}
}

#----------------------------------------------------------------------
# 관리자가 수행하는 지형 변경 모드
#----------------------------------------------------------------------
sub lchangeMain {
	if(checkSpecialPassword($HdefaultPassword)) {
		# 특수 비밀번호
		if ($HlchangeMode) {
			# id에서 섬을 가져옴
			$HcurrentNumber = $HidToNumber{$HcurrentID};
			my($island) = $Hislands[$HcurrentNumber];
			my($land) = $island->{'land'};
			my($landValue) = $island->{'landValue'};

			# 지형 값의 정합성을 확인(확인하지 않은 경우 주석 처리해 주세요)
			if(!landCheck($HlchangeKIND, $HlchangeVALUE)) {
				tempBadValue();
				unlock();
				return;
			}

			$land->[$HcommandX][$HcommandY] = $HlchangeKIND;
			$landValue->[$HcommandX][$HcommandY] = $HlchangeVALUE;

			# 데이터 쓰기
			writeIslandsFile($HcurrentID);
			unlock();

			# 변경 성공
			tempLchangeOK($island->{'name'});
		}
		$HislandList = getIslandList($Hislands[$HbfieldNumber]->{'id'}, 1);
		unlock();
		# 템플릿 출력
		tempLchangePage();
	} else {
		# 비밀번호 오류
		unlock();
		tempWrongPassword();
		return;
#		# 비밀번호가 일치하지 않으면메인 페이지로
#		require('./hako-top.cgi');
#		unlock();
#		# 템플릿 출력
#		tempTopPage();
	}
}

# 지형 변경 모드의 메인 페이지
sub tempLchangePage {

	my($expOption, $hpOption) = ('', '');
	my($i);

	foreach $i (0..250) {
		$expOption.= "<OPTION VALUE=$i>$i\n";
	}
	foreach $i (0..31) {
		$hpOption.= "<OPTION VALUE=$i>$i\n";
	}

	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<H1>참가 ${AfterName}의 지형 데이터를 변경</H1>

<DL>
<DT>·'지형 값'에 대한 지식이 없으면 사용하기 어렵습니다.</DT>
<DT>·특히 '괴수', '해군', '복합 지형' 관련 항목은 지식이 있어도 다루기 어렵습니다.</DT>
<DT>·'지형'에 대해<B>'지형 값'이 적절한지 간이 판정합니다</B>., 주의해 주세요.</DT>
</DL>

<FORM name="lcForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Lchange">
<B>지형을 변경할 ${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<INPUT TYPE="button" VALUE="지도를 열기" onclick="printIsland();">
<BR><BR>
<B>좌표는?</B><BR>
<B>(</B><SELECT NAME=POINTX>
END

	foreach $i (@defaultX) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT><B>, </B><SELECT NAME=POINTY>
END

	foreach $i (@defaultY) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT><B>)</B><BR>
<BR>
<B>지형은?</B><BR>
<SELECT NAME="LCHANGEKIND">
<OPTION VALUE="$HlandSea">$HlandName[$HlandSea][0]
<OPTION VALUE="$HlandWaste">$HlandName[$HlandWaste][0]
<OPTION VALUE="$HlandPlains">$HlandName[$HlandPlains]
<OPTION VALUE="$HlandTown">$HlandName[$HlandTown]
<OPTION VALUE="$HlandForest">$HlandName[$HlandForest]
<OPTION VALUE="$HlandFarm">$HlandName[$HlandFarm]
<OPTION VALUE="$HlandFactory">$HlandName[$HlandFactory]
<OPTION VALUE="$HlandBase">$HlandName[$HlandBase]
<OPTION VALUE="$HlandDefence">$HlandName[$HlandDefence][0]
<OPTION VALUE="$HlandMountain">$HlandName[$HlandMountain][0]
<OPTION VALUE="$HlandMonster">$HlandName[$HlandMonster]
<OPTION VALUE="$HlandSbase">$HlandName[$HlandSbase]
<OPTION VALUE="$HlandOil">$HlandName[$HlandOil]
<OPTION VALUE="$HlandMonument">$HlandName[$HlandMonument]
<OPTION VALUE="$HlandHaribote">$HlandName[$HlandHaribote]
<OPTION VALUE="$HlandNavy">$HlandName[$HlandNavy]
<OPTION VALUE="$HlandBouha">$HlandName[$HlandBouha]
<OPTION VALUE="$HlandSeaMine">$HlandName[$HlandSeaMine]
<OPTION VALUE="$HlandHugeMonster">$HlandName[$HlandHugeMonster]
<OPTION VALUE="$HlandComplex">$HlandName[$HlandComplex]
<OPTION VALUE="$HlandCore">$HlandName[$HlandCore][0]
</SELECT><BR>
<BR>
<B>지형 값은?</B><BR>
<INPUT TYPE="text" SIZE=15 NAME="LCHANGEVALUE" VALUE="0"><BR>
<BR>
<INPUT TYPE="submit" VALUE="변경" NAME="LchangeButton"><BR>
<BR>
<BR>
<B>지원도구</B>
<table>
<tr>
<td rowspan=2>복합<BR>지형</td>
<td>종류</td>
<td>턴 플래그</td>
<td>식량 플래그</td>
<td>자금 플래그</td>
</tr>
<tr>
END

	my($complexKindName, $complexOption1, $complexOption2);
	foreach $i (0..$#HcomplexName) {
		$complexKindName.= "<OPTION VALUE=$i>$HcomplexName[$i]\n";
	}
	foreach $i (0..500) {
		$complexOption1.= "<OPTION VALUE=$i>$i\n";
	}
	foreach $i (0..50) {
		$complexOption2.= "<OPTION VALUE=$i>$i\n";
	}

	out(<<END);
<td><SELECT name=complexKIND onChange=complexPack() onClick=complexPack()>$complexKindName</SELECT></td>
<td><SELECT name=complexTURN onChange=complexPack() onClick=complexPack()>$complexOption1</td>
<td><SELECT name=complexFOOD onChange=complexPack() onClick=complexPack()>$complexOption2</SELECT></td>
<td><SELECT name=complexMONEY onChange=complexPack() onClick=complexPack()>$complexOption2</SELECT></td>
</tr>
</table>
<table>
<tr>
<td rowspan=2>괴수</td>
<td> 섬 ID</td>
<td>얕은 바다플래그</td>
<td>경험치</td>
<td>플래그</td>
<td>종류</td>
<td>내구력</td>
</tr>
<tr>
<td><SELECT name=landID onChange=monsterPack() onClick=monsterPack()>$HislandList<OPTION VALUE=0>소속 섬 없음</SELECT></td>
<td><SELECT name=seaFLAG onChange=monsterPack() onClick=monsterPack()><OPTION value=0>바다<OPTION value=1>얕은 바다</SELECT></td>
<td><SELECT name=landEXP onChange=monsterPack() onClick=monsterPack()>$expOption</SELECT></td>
<td><SELECT name=landFLAG1 onChange=monsterPack() onClick=monsterPack()><OPTION value=0>육상<OPTION value=1>잠수(해상)</SELECT>
<SELECT name=landFLAG2 onChange=monsterPack() onClick=monsterPack()><OPTION value=0>경화 없음<OPTION value=1>경화 중</SELECT></td>
<td><SELECT name=landKIND onChange=monsterPack() onClick=monsterPack()>
END

	for($i = 0; $i < $HmonsterNumber; $i++) {
		out("<OPTION VALUE=$i>$HmonsterName[$i]\n");
	}

	out(<<END);
</SELECT></td>
<td><SELECT name=landHP onChange=monsterPack() onClick=monsterPack()>$hpOption</SELECT></td>
</tr>
</table>
<table>
<tr>
<td rowspan=2>해군</td>
<td> 섬 ID</td>
<td>상태</td>
<td>얕은 바다플래그</td>
<td>경험치</td>
<td>플래그</td>
<td>함대번호</td>
<td>종류</td>
<td>내구력</td>
</tr>
<tr>
<td><SELECT name=navyID onChange=navypack() onClick=navypack()>$HislandList<OPTION VALUE=0>소속 섬 없음</SELECT></td>
<td><SELECT name=status onChange=navypack() onClick=navypack()><OPTION value=0>일반<OPTION value=1>퇴치<OPTION value=2>순항<OPTION value=3>정선</SELECT></td>
<td><SELECT name=seaFLAG2 onChange=navypack() onClick=navypack()><OPTION value=0>바다<OPTION value=1>얕은 바다</SELECT></td>
<td><SELECT name=navyEXP onChange=navypack() onClick=navypack()>
END

	foreach $i (0..$HmaxExpNavy) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT></td>
<td><SELECT name=navyFLAG1 onChange=navypack() onClick=navypack()><OPTION value=0>해상<OPTION value=1>잠수</SELECT>
<SELECT name=navyFLAG2 onChange=navypack() onClick=navypack()><OPTION value=0>정상<OPTION value=1>잔해</SELECT></td>
<td><SELECT name=navyNO>
END

	foreach $i (0..3) {
		my $j = $i + 1;
		out("<OPTION VALUE=$i>제$j함대\n");
	}

	out(<<END);
</SELECT></td>
<td><SELECT name=navyKIND onChange=navypack() onClick=navypack()>
END

	for($i = 0; $i < $#HnavyName + 1; $i++) {
		out("<OPTION VALUE=$i>$HnavyName[$i]\n");
	}

	out(<<END);
</SELECT></td>
<td><SELECT name=navyHP onChange=navypack() onClick=navypack()>
END

	foreach $i (0..15) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT></td>
</tr>
</table>
<table>
<tr>
<td rowspan=2>거대<br>괴수</td>
<td> 섬 ID</td>
<td>거대괴수플래그</td>
<td>얕은 바다플래그</td>
<td>경험치</td>
<td>플래그</td>
<td>종류</td>
<td>내구력</td>
</tr>
<tr>
<td><SELECT name=hlandID onChange=hmonsterPack() onClick=hmonsterPack()>$HislandList<OPTION VALUE=0>소속 섬 없음</SELECT></td>
<td><SELECT name=hugeFLAG onChange=hmonsterPack() onClick=hmonsterPack()><OPTION value=0>코어<OPTION value=1>오른쪽 위<OPTION value=2>오른쪽<OPTION value=3>오른쪽 아래<OPTION value=4>왼쪽 아래<OPTION value=5>왼쪽<OPTION value=6>왼쪽 위</SELECT></td>
<td><SELECT name=hseaFLAG onChange=hmonsterPack() onClick=hmonsterPack()><OPTION value=0>바다<OPTION value=1>얕은 바다</SELECT></td>
<td><SELECT name=hlandEXP onChange=hmonsterPack() onClick=hmonsterPack()>$expOption</SELECT></td>
<td><SELECT name=hlandFLAG1 onChange=hmonsterPack() onClick=hmonsterPack()><OPTION value=0>육상<OPTION value=1>잠수(해상)</SELECT>
<SELECT name=hlandFLAG2 onChange=hmonsterPack() onClick=hmonsterPack()><OPTION value=0>경화 없음<OPTION value=1>경화 중</SELECT></td>
<td><SELECT name=hlandKIND onChange=hmonsterPack() onClick=hmonsterPack()>
END

	for($i = 0; $i < $HhugeMonsterNumber; $i++) {
		out("<OPTION VALUE=$i>$HhugeMonsterName[$i]\n");
	}

	out(<<END);
</SELECT></td>
<td><SELECT name=hlandHP onChange=hmonsterPack() onClick=hmonsterPack()>$hpOption</SELECT></td>
</tr>
</table>
<BR>
<BR>
<B>참고(지형 값)</B>
<ul type="disc">
<li>$HlandName[$HlandSea][0] ======> 0:$HlandName[$HlandSea][0],1:$HlandName[$HlandSea][1]
<li>$HlandName[$HlandWaste][0] ====> 0:$HlandName[$HlandWaste][0],1:$HlandName[$HlandWaste][1]
<li>$HlandName[$HlandMountain][0] ======> 0:$HlandName[$HlandMountain][0],1:$HlandName[$HlandMountain][1]
<li>$HlandName[$HlandDefence][0] ==> 숫자 값+1이 내구력
<li>$HlandName[$HlandCore][0] ==> 숫자 값의 하위 2자리+1이 내구력, 10000 단위가 설치 지형(00000:평지($HlandName[$HlandCore][0]),10000:얕은 바다($HlandName[$HlandCore][1]),20000:바다($HlandName[$HlandCore][2]))
</ul>

END

	out(<<END);
</FORM>
<SCRIPT Language="JavaScript">
<!--

function printIsland() {
	var iid;
	with (document.lcForm.ISLANDID) {
		iid = options[selectedIndex].value;
	}
	window.open("$HthisFile?Sight=" + iid + "&ADMINMODE=$HdefaultPassword", "lcmap", "toolbar=0,location=0,directories=0,menubar=0,status=1,scrollbars=1,resizable=1,width=450,height=630");
}

function complexPack() {
	a = Math.floor(document.lcForm.complexKIND.value);
	b = Math.floor(document.lcForm.complexTURN.value);
	c = Math.floor(document.lcForm.complexFOOD.value);
	d = Math.floor(document.lcForm.complexMONEY.value);

	if(b> 500) b = 500;
	if(c> 50) c = 50;
	if(d> 50) d = 50;

	e = a * Math.pow(2, 21) + b * Math.pow(2, 12) + c * Math.pow(2, 6) + d;

	document.lcForm.LCHANGEVALUE.value = e;
	document.lcForm.LCHANGEKIND.options.value = $HlandComplex;
	return true;
}

function monsterPack() {
	a = Math.floor(document.lcForm.landID.value);
	c = Math.floor(document.lcForm.seaFLAG.value);
	d = Math.floor(document.lcForm.landEXP.value);
	e = Math.floor(document.lcForm.landFLAG1.value);
	f = Math.floor(document.lcForm.landFLAG2.value);
	g = Math.floor(document.lcForm.landKIND.value);
	h = Math.floor(document.lcForm.landHP.value);

	if(d> 250) d = 250;
	if(h> 15) h = 15;

	j = a * Math.pow(2, 24) + c * Math.pow(2, 20) + d * Math.pow(2, 12)
		 + e * Math.pow(2, 11) + f * Math.pow(2, 10) + g * Math.pow(2, 5) + h;

	document.lcForm.LCHANGEVALUE.value = j;
	document.lcForm.LCHANGEKIND.options.value = $HlandMonster;
	return true;
}

function navypack() {
	a = Math.floor(document.lcForm.navyID.value);
	b = Math.floor(document.lcForm.status.value);
	c = Math.floor(document.lcForm.seaFLAG2.value);
	d = Math.floor(document.lcForm.navyEXP.value);
	e = Math.floor(document.lcForm.navyFLAG1.value);
	f = Math.floor(document.lcForm.navyFLAG2.value);
	g = Math.floor(document.lcForm.navyNO.value);
	h = Math.floor(document.lcForm.navyKIND.value);
	i = Math.floor(document.lcForm.navyHP.value);

	if(d> 250) d = 250;
	if(i> 15) i = 15;

	j = a * Math.pow(2, 25) + b * Math.pow(2, 22) + c * Math.pow(2, 21) + d * Math.pow(2, 13) + e * Math.pow(2, 12)
		 + f * Math.pow(2, 11) + g * Math.pow(2, 9) + h * Math.pow(2, 4) + i;

	document.lcForm.LCHANGEVALUE.value = j;
	document.lcForm.LCHANGEKIND.options.value = $HlandNavy;
	return true;
}

function hmonsterPack() {
	a = Math.floor(document.lcForm.hlandID.value);
	b = Math.floor(document.lcForm.hugeFLAG.value);
	c = Math.floor(document.lcForm.hseaFLAG.value);
	d = Math.floor(document.lcForm.hlandEXP.value);
	e = Math.floor(document.lcForm.hlandFLAG1.value);
	f = Math.floor(document.lcForm.hlandFLAG2.value);
	g = Math.floor(document.lcForm.hlandKIND.value);
	h = Math.floor(document.lcForm.hlandHP.value);

	if(d> 250) d = 250;
	if(h> 15) h = 15;

	j = a * Math.pow(2, 24) + b * Math.pow(2, 21) + c * Math.pow(2, 20) + d * Math.pow(2, 12)
		 + e * Math.pow(2, 11) + f * Math.pow(2, 10) + g * Math.pow(2, 5) + h;

	document.lcForm.LCHANGEVALUE.value = j;
	document.lcForm.LCHANGEKIND.options.value = $HlandHugeMonster;
	return true;
}

//-->
</SCRIPT>
END
}

# 지형 변경완료
sub tempLchangeOK {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}의 지형을 변경했습니다${H_tagBig}
<HR>
END
}

# 지형값 이동
sub tempBadValue {
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;
	out(<<END);
${HtagBig_}지형 값이 올바르지 않습니다${H_tagBig}$HtempBack2
END
}

# 지형 값을 확인
sub landCheck {
	my($land, $lv) = @_;
	if($land == $HlandSea) {
		return 0 if(($lv < 0) || ($lv> 1));
	} elsif($land == $HlandWaste) {
		return 0 if(($lv < 0) || ($lv> 1));
	} elsif($land == $HlandPlains) {
		return 0 if($lv != 0);
	} elsif($land == $HlandTown) {
		return 0 if(($lv < 1) || ($lv> $HvalueLandTownMax));
	} elsif($land == $HlandForest) {
		return 0 if(($lv < 1) || ($lv> 200));
	} elsif($land == $HlandFarm) {
		return 0 if(($lv < 10) || ($lv> 50));
#		return if(($lv - 10) % 2 != 0);
	} elsif($land == $HlandFactory) {
		return 0 if(($lv < 30) || ($lv> 100));
#		return if(($lv - 30) % 10 != 0);
	} elsif($land == $HlandBase) {
		return 0 if(($lv < 0) || ($lv> $HmaxExpPoint));
	} elsif($land == $HlandDefence) {
		return 0 if(($lv < 0) || (($lv> $HdurableDef) && ($lv != $HdefExplosion)));
	} elsif($land == $HlandMountain) {
		return 0 if(($lv < 0) || ($lv> 200));
#		return if($lv % 5 != 0);
	} elsif($land == $HlandMonster) {
		my($id, $hflag, $sea, $exp, $flag, $kind, $hp) = monsterUnpack($lv);
		return 0 if(($hp < 0) || ($hp> 31) || ($kind < 0) || ($kind> $#HmonsterName));
	} elsif($land == $HlandHugeMonster) {
		my($id, $hflag, $sea, $exp, $flag, $kind, $hp) = monsterUnpack($lv);
		return 0 if(($hp < 0) || ($hp> 31) || ($kind < 0) || ($kind> $#HhugeMonsterName));
	} elsif($land == $HlandSbase) {
		return 0 if(($lv < 0) || ($lv> $HmaxExpPoint));
	} elsif($land == $HlandOil) {
		return 0 if($lv != 0);
	} elsif($land == $HlandMonument) {
		return 0 if(($lv < 0) || ($lv> 2));
	} elsif($land == $HlandCore) {
		return 0 if(($lv < 0) || ($lv % 10000> $HdurableCore) || (int($lv / 10000)> 2));
	} elsif($land == $HlandHaribote) {
		return 0 if($lv != 0);
	} elsif($land == $HlandNavy) {
		my($id, $tmp, $stat, $sea, $exp, $flag, $no, $kind, $hp) = navyUnpack($lv);
		return 0 if(($hp < 0) || ($hp> 15) || ($kind < 0) || ($kind> $#HnavyName));
	} elsif($land == $HlandComplex) {
		my($tmp, $kind, $turn, $food, $money) = landUnpack($lv);
		return 0 if(($kind < 0) || ($kind> $#HcomplexName));
	} elsif($land == $HlandBouha) {
		return 0 if($lv != 0);
	} elsif($land == $HlandSeaMine) {
		return 0 if($lv != 1);
	}

	return 1;
}

#----------------------------------------------------------------------
# 관리자가 수행하는 보관 모드
#----------------------------------------------------------------------
sub preDeleteMain {
	if(checkSpecialPassword($HdefaultPassword)) {
		# 특수 비밀번호
		if($HpreDeleteMode) {
			my @newID = ();
			my $flag = 0;
			if($HcurrentID) {
				foreach (@HpreDeleteID) {
					my $currentNumber = $HidToNumber{$_};
					if(!(defined $currentNumber)) {
					} elsif($_ == $HcurrentID) {
						$Hislands[$currentNumber]->{'predelete'} = 0;
						$flag = 1;
						my($island) = $Hislands[$currentNumber];
						if(!$island->{'pop'}) {
							my($land) = $island->{'land'};
							my($landValue) = $island->{'landValue'};
							makeRandomIslandPointArray($island);
							foreach (0..$island->{'pnum'}) {
								last if($count>= $HcountLandTown);
								$x = $island->{'rpx'}[$_];
								$y = $island->{'rpy'}[$_];
								# 해당 지점이 평지 또는 황무지라면 마을
								if(($land->[$x][$y] == $HlandPlains) || ($land->[$x][$y] == $HlandWaste)) {
									$land->[$x][$y] = $HlandTown;
									$landValue->[$x][$y] = $HvalueLandTown;
									$island->{'pop'} += $HvalueLandTown;
									$count++;
								}
							}
						}
						if($HcorelessDead) {
							require('./hako-turn.cgi');
							estimate($currentNumber);
							randomBuildCore($island, 1, 0, 0, 0) if(!$island->{'core'});
						}
					} else {
						push(@newID, $_);
					}
				}
				@HpreDeleteID = @newID;
				if(!$flag){
					push(@HpreDeleteID, $HcurrentID);
					$Hislands[$HidToNumber{$HcurrentID}]->{'predelete'} = $HsetTurn;
				}
			} else {
				readIslandsFile(-1);
				require('./hako-turn.cgi') if($HcorelessDead);
				foreach (@HpreDeleteID) {
					my $currentNumber = $HidToNumber{$_};
					$Hislands[$currentNumber]->{'predelete'} = 0;
					if(defined $currentNumber) {
						my($island) = $Hislands[$currentNumber];
						if(!$island->{'pop'}) {
							my($land) = $island->{'land'};
							my($landValue) = $island->{'landValue'};
							makeRandomIslandPointArray($island);
							foreach (0..$island->{'pnum'}) {
								last if($count>= $HcountLandTown);
								$x = $island->{'rpx'}[$_];
								$y = $island->{'rpy'}[$_];
								# 해당 지점이 평지 또는 황무지라면 마을
								if(($land->[$x][$y] == $HlandPlains) || ($land->[$x][$y] == $HlandWaste)) {
									$land->[$x][$y] = $HlandTown;
									$landValue->[$x][$y] = $HvalueLandTown;
									$island->{'pop'} += $HvalueLandTown;
									$count++;
								}
							}
						}
						if($HcorelessDead) {
							estimate($currentNumber);
							randomBuildCore($island, 1, 0, 0, 0) if(!$island->{'core'});
						}
					}
				}
				@HpreDeleteID = ();
			}
			islandSort($HrankKind, 1);
			# 데이터 쓰기
			if(!$HcurrentID) {
				writeIslandsFile(-1);
				tempPreDeleteEnd("전체");
			} else {
				writeIslandsFile($HcurrentID);
				if($flag) {
					tempPreDeleteEnd($Hislands[$HidToNumber{$HcurrentID}]->{'name'});
				} else {
					tempPreDelete($Hislands[$HidToNumber{$HcurrentID}]->{'name'});
				}
			}
		}
		$HislandList = getIslandList($Hislands[$HbfieldNumber]->{'id'}, 1);
		unlock();
		# 템플릿 출력
		tempPdeleteMain();
	} else {
		# 비밀번호 오류
		unlock();
		tempWrongPassword();
		return;
#		# 비밀번호가 일치하지 않으면메인 페이지로
#		require('./hako-top.cgi');
#		unlock();
#		# 템플릿 출력
#		tempTopPage();
	}
}

# 보관 모드의 메인 페이지
sub tempPdeleteMain {
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<H1>참가 ${AfterName}을 관리자 보관 처리</H1>

<DL>
<DT>·보관 처리된 ${AfterName}은 턴 처리(수입 처리·명령 처리·성장·재해·실업자 이민) 대상에서 제외됩니다.</DT>
<DT>·다른 ${AfterName}의 공격은 모두 무효 처리됩니다.</DT>
<DT>·보관 중인 섬이 '포기' 또는 '강제 삭제'된 경우, 보관 ID 데이터는, 다음 보관 처리를 할 때까지 그대로 남습니다.</DT>
</DL>

<FORM name="pdForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Pdelete">
<B>관리자 보관 처리할 ${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
<OPTION VALUE="0">모든 섬을 해제
$HislandList
</SELECT>
<BR>
<B>보관 기간은?</B><BR>
<SELECT NAME="SETTURN" onChange=RestTurnToTime()>
<OPTION VALUE='99999999'>무기한
END
	my($limit);
	$limit = $HgameLimitTurn - $HislandTurn if($HgameLimitTurn);
	$limit = 100 if(($limit < 1) || ($limit> 100));
	foreach (1..$limit) {
		out("<OPTION VALUE='$_'>$_");
	}
	out(<<END);
</SELECT>턴
<ilayer name="PARENT_TURN" width="100%" height="100%">
 <layer name="TURN" width="200"></layer>
 <span id="TURN"></span>
</ilayer>
<BR>
<INPUT TYPE="submit" VALUE="설정·해제" NAME="PdeleteButton"><BR>
<SCRIPT language="JavaScript">
<!--
function RestTurnToTime() {
	var now = new Date();
	var turn = document.pdForm.SETTURN.value;
	var stop = $HislandTurn + Math.floor(turn);
	if(turn == 99999999) {
		stop = ''
	} else {
		stop = ' => <span class="number">턴' + stop +'</span>';
	}
	now.setTime((turn*$HunitTime + $HislandLastTime)*1000);
	var str = '';
	if(stop != '') {
		str = stop + '(';
		str += now.getYear() + '년' + (now.getMonth()+1) + '월' + now.getDate() + '일' + now.getHours() + '시';
		if(now.getMinutes()> 0) {
			str += now.getMinutes() + '분';
			if(now.getSeconds()> 0) {
				str += now.getSeconds() + '초';
			}
		} else if(now.getSeconds()> 0) {
			str += now.getMinutes() + '분' + now.getSeconds() + '초';
		}
		str += ')까지';
	}
	if(document.getElementById){
		document.getElementById("TURN").innerHTML = str;
	} else if(document.all){
		el = document.all("TURN");
		el.innerHTML = str;
	} else if(document.layers) {
		lay = document.layers["PARENT_TURN"].document.layers["TURN"];
		lay.document.open();
		lay.document.write(str);
		lay.document.close();
	}

	return true;
}
RestTurnToTime();
//-->
</SCRIPT>
</FORM>
<TABLE BORDER><TR><TH colspan='2'>보관 중인${AfterName}</TH></TR>
END

	if($HpreDeleteID[0] eq '') {
		out("<TR><TH colspan='2'>관리자 보관의${AfterName} 없습니다!</TH></TR>");
	} else {
		my($name);
		foreach (@HpreDeleteID) {
			next if(!(defined $HidToNumber{$_}));
			$name = $Hislands[$HidToNumber{$_}]->{'name'};
			out("<TR><TH>${HtagName_}${name}${AfterName}${H_tagName}</TH>");
			if($Hislands[$HidToNumber{$_}]->{'predelete'} == 99999999) {
				out("<TD>${HtagTH_}무기한${H_tagTH}</TD>");
			} else {
				my $turn = $HislandTurn + $Hislands[$HidToNumber{$_}]->{'predelete'};
				my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime($Hislands[$HidToNumber{$_}]->{'predelete'}*$HunitTime + $HislandLastTime + $Hjst);
				$mon++;
				$year += 1900;
				my $str = "$year 년$month 월$date 일$hour시";
				if($min) {
					$str.= "$min 분";
					if($sec) {
						$str.= "$sec 초";
					}
				} elsif($sec) {
					$str.= "$min 분$sec 초";
				}
				out("<TD>남은$Hislands[$HidToNumber{$_}]->{'predelete'}턴 => <span class='number'>턴$turn</span>($str)까지</TD>");
			}
			out("</TR>");
		}
	}
	out("</TABLE>");
}

# 관리자 보관 설정
sub tempPreDelete {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}을 관리자 보관 상태로 변경했습니다${H_tagBig}
<HR>
END
}

# 관리자 보관 해제
sub tempPreDeleteEnd {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}의 관리자 보관을 해제했습니다${H_tagBig}
<HR>
END
}

#----------------------------------------------------------------------
# 함정강제귀환
#----------------------------------------------------------------------
sub moveFleetAdmin {
	if (!$HmfleetMode) {
		# 화면 출력
		unlock();
		# 템플릿 출력
		moveFleetAdminTop();
	} else {
		# 비밀번호 확인
		if(checkSpecialPassword($HdefaultPassword)) {
			# 특수 비밀번호
			readIslandsFile(-2);
			my $move = 0;
			if($HfromID == 100) {
				my($i);
				if($HcurrentID == 100) {
					foreach $i (0..$islandNumber) {
						my $fromID = $Hislands[$i]->{'id'};
						foreach (0..$islandNumber) {
							my $id = $Hislands[$_]->{'id'};
							$HtoID = $id if($HtoID);
							next if($HtoID && $HfromID == $id);
							$move += moveFleetForced($fromID, $HtoID, $id, 4, 1);
						}
					}
				} else {
					foreach (0..$islandNumber) {
						my $fromID = $Hislands[$_]->{'id'};
						next if($fromID == $HtoID || $fromID == $HcurrentID);
						$move += moveFleetForced($fromID, $HtoID, $HcurrentID, 4, 1);
					}
				}
				if($move) {
					my($fName);
					if($HcurrentID != 100) {
						my($fIsland) = $Hislands[$HidToNumber{$HcurrentID}];
						$fName = '로 있었던';
						$fName.= (!$HcurrentID) ? '소속 불명' : islandName($fIsland);
					}
					if($HtoID) {
						tempMfleet("<small>모든 섬에 전개 중인$fName 의 전체 함대를 소속 섬으로 귀환시켰습니다.</small>");
					} else {
						tempMfleet("<small>모든 섬에 전개 중인$fName 의 전체 함대를 소멸시켰습니다.</small>");
					}
				} else {
					tempMfleet("<small>조건에 해당하는 함정은 없습니다.</small>");
				}
			} elsif($HcurrentID == 100) {
				my($island) = $Hislands[$HidToNumber{$HfromID}];
				my($name) = islandName($island);
				foreach (0..$islandNumber) {
					my $id = $Hislands[$_]->{'id'};
					$HtoID = $id if($HtoID);
					next if($HfromID == $id);
					$move += moveFleetForced($HfromID, $HtoID, $id, 4, 1);
				}
				if($move) {
					if($HtoID) {
						tempMfleet("<small>$name 에 전개 중인 전체 함대를 소속 섬으로 귀환시켰습니다.</small>");
					} else {
						tempMfleet("<small>$name 에 전개 중인 전체 함대를 소멸시켰습니다.</small>");
					}
				} else {
					tempMfleet("<small>조건에 해당하는 함정은 없습니다.</small>");
				}
			} else {
				$move = moveFleetForced($HfromID, $HtoID, $HcurrentID, $HfleetNo, 0);
			}
			if($move) {
				foreach (0..$islandNumber) {
					undef $Hislands[$_]->{'fkind'};
				}
				foreach (0..$islandNumber) {
					estimateNavy($_);
				}
				writeIslandsFile(-2);
			}
			unlock();
		} else {
			# 비밀번호 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
}

sub moveFleetAdminTop {
	# '돌아가기' 링크 2
	$HislandList = getIslandList($Hislands[$HbfieldNumber]->{'id'}, 1);
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<H1>함대를 강제 이동하다</H1>
<FORM action="$HthisFile" method="POST">
<B>어느 ${AfterName}에 있는 함대?</B>(이동원래)<BR>
<SELECT NAME="FROMID">$HislandList
<OPTION style="background: red;" VALUE=100>모든 ${AfterName}
</SELECT><BR>
참고: '모든 섬'을 선택하면, 소속이 '소속 불명'이 아니면 전체 섬에  파견된 모든 함대가 대상이 되며, 이동 대상이 '전체 함정 소멸'이 아니면 자기 섬으로 귀환합니다.<BR><BR>
<B>어느 ${AfterName}의 함대?</B>(소속)<BR>
<SELECT NAME="ISLANDID">
$HislandList
<OPTION style="background: yellow;" VALUE=0>소속 불명
<OPTION style="background: red;" VALUE=100>모든 ${AfterName}
</SELECT>
<B>제<SELECT NAME="FLEETNUMBER">
<OPTION VALUE=0>1
<OPTION VALUE=1>2
<OPTION VALUE=2>3
<OPTION VALUE=3>4
<OPTION style="background: red;" VALUE=4>전체 함대
</SELECT>함대</B><BR>
참고: '모든 섬'을 선택하면, 이동 대상이'전체 함정 소멸'외이면 전체 함대가자기 섬으로 귀환합니다.<BR><BR>
<B>어느 ${AfterName}로 이동시킬까요?</B>(이동 대상)<BR>
<SELECT NAME="TOID">$HislandList
<OPTION style="background: red;" VALUE=0>전체 함정 소멸
</SELECT><BR><BR>
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Mfleet">
<INPUT TYPE="submit" VALUE="이동" NAME="MoveFleetButton"><BR><BR>
</FORM>
END
}

# 함대강제 이동 로그
sub tempMfleet {
	my($str) = @_;
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR><BR>
${HtagBig_}$str${H_tagBig}
END
}

# 함대강제 이동
sub moveFleetForced {
	my($fromId, $toId, $fId, $no, $logcut) = @_;
	# 이동원래 ID:$fromId, 이동 대상 ID:$toId, 이동하게 함함대의 섬 ID:$fId, 함대 No:$no
	my($island) = $Hislands[$HidToNumber{$fromId}];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($name) = islandName($island);

	my($tIsland) = $Hislands[$HidToNumber{$toId}];
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tName) = islandName($tIsland);

	my($fIsland) = $Hislands[$HidToNumber{$fId}];
	my($fName) = (!$fId) ? '소속 불명' : islandName($fIsland);

	$no = 0 if(!$fId);

	# 함대를 검색
	my(@fleet);
	my($i, $x, $y, $lv);
	# 좌표배열을 만들기
	makeRandomIslandPointArray($island);
	foreach $i (0..$island->{'pnum'}) {
		$x = $island->{'rpx'}[$i];
		$y = $island->{'rpy'}[$i];

		# 해군을 탐색
		next if ($land->[$x][$y] != $HlandNavy);

		# 이동 함정까요?
		my($nId, $nFlag, $nNo, $nKind) = (navyUnpack($landValue->[$x][$y]))[0,5,6,7];
		next if (($nId != $fId) || ($no != 4 && $nNo != $no));

		# 잔해이면 무시
		next if ($nFlag & 1);

		# 항구이면 무시
		my $nSpecial = $HnavySpecial[$nKind];
		next if ($nSpecial & 0x8);

		# 함정을 기억
		push(@fleet, { x => $x, y => $y });
	}

	if (@fleet < 1) {
		# 함대없음
		$no++;
		tempMfleet("<small>$name 에,$fName 제$no 함대는 없습니다!</small>") if(!$logcut);
		return 0;
	}
	if($no != 4) {
		my $ofname = $fIsland->{'fleet'}->[$no];
		$no = "$ofname 함대";
	} else {
		$no = "전체 함대";
	}
	# 함대소멸
	my($tx, $ty, $tLv, $sendshipStr);
	if($toId eq '0') {
		foreach (@fleet) {
			# 함정의 정보를 가져옴
			($x, $y) = ($_->{x}, $_->{y});

			my($nSea, $nKind) = (navyUnpack($landValue->[$x][$y]))[3,7];
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = $nSea;
			# 로그를 출스
			$sendshipStr.= "<BR><B>$HnavyName[$nKind]</B>${HtagName_}($x, $y)${H_tagName}";
		}
		tempMfleet("<small>$name 에 전개 중인의 $fName $no 을 소멸시켰습니다.<small>$sendshipStr</small></small>") if(!$logcut);
		logHistory("${HtagName_}${name}${H_tagName}의${HtagName_}${fName}${H_tagName} <B>$no</B>이, 돌진으로${HtagDisaster_}소멸${H_tagDisaster}했습니다.");
		return 1;
	}

	# 함대 이동
	makeRandomIslandPointArray($tIsland);
	foreach $i (0..$island->{'pnum'}) {
		$tx = $tIsland->{'rpx'}[$i];
		$ty = $tIsland->{'rpy'}[$i];
		$tLv = $tLandValue->[$tx][$ty];

		# 깊은 바다를 탐색
		next if(($tLand->[$tx][$ty] != $HlandSea) || ($tLv && !$HnavyMoveAsase));

		# 함정의 정보를 가져옴
		($x, $y) = ($fleet[0]->{x}, $fleet[0]->{y});
		shift @fleet;

		# 함정을 이동
		my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($landValue->[$x][$y]);
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = $nSea;

		$tLand->[$tx][$ty] = $HlandNavy;
		$tLandValue->[$tx][$ty] = navyPack($nId, $nTmp, $nStat, $tLv, $nExp, $nFlag, $nNo, $nKind, $nHp);
		# 로그를 출스
		$sendshipStr.= "<BR><B>$HnavyName[$nKind]</B>${HtagName_}($tx, $ty)${H_tagName}";

		last if (@fleet < 1);
	}

	tempMfleet("<small>$name 에 전개 중인의 $fName $no 을$tName 로 이동했습니다.<small>$sendshipStr</small></small>") if(!$logcut);
	return 1;
}

# 기록 로그
sub logHistory {
	open(HOUT, ">>${HdirName}/hakojima.his");
	print HOUT "$HislandTurn,$_[0]\n";
	close(HOUT);
}

#----------------------------------------------------------------------
# 이벤트
#----------------------------------------------------------------------
sub setupEvent {
	if($HsetEventMode) {
		# 비밀번호 확인
		if(checkSpecialPassword($HdefaultPassword)) {
			# 특수 비밀번호
			if($HcurrentID || (keys %HeventDel != ())) {
				readIslandsFile();
				if($HsetEventMode == 1) {
					my $island = $Hislands[$HidToNumber{$HcurrentID}];
					if($island->{'event'}[0]) {
						# 비밀번호 오류
						unlock();
						tempEvent("이미 설정되어 있습니다.<BR>다시 설정하려면 기존 설정을 삭제해야 합니다.");
						return;
					} elsif($Htype == 1) {# 서바이벌
						$Haddition = 0; # 추가 파견을 허가 안 함
						$Hturm = 0; # 무기한으로
						$HcoreFlag = 0; # 코어괴멸 시강제종료하지 않음
					} elsif(!$Hturm) {# 함정 경험치 획득 배틀, 함정 격침 배틀, 괴수 퇴치 배틀, 상금 획득 배틀
						# 기간이 무기한은 안 됨
						unlock();
						tempEvent("기간이 설정됨되어 있지 않습니다.");
						return;
					}

					#
					# 0이벤트플래그 1시작 턴 2기간 3함정 수 4함종 5제한 6유형 7보상금 8보상식량 9관리자선물의 유무 10보상 아이템
					my @event = (1, $Hstart, $Hturm, $Hmaxship, $HpermitKind, $Hrestriction, $Htype, $HprizeMoney, $HprizeFood, $HprizePresent, join('', @HprizeItem),
					# 11추가 파견 12괴수 빈도(턴) 13괴수 수(마리) 14거대괴수 빈도(턴) 15거대괴수 수(마리) 16소속 불명 함정 빈도(턴) 17소속 불명 함정 수(함) 18자동귀환 처리 19코어 빈도(턴) 20코어 수(함) 21코어내구력(min) 22코어내구력(max) 23코어플래그
								$Haddition, $HmonsterTurn, $HmonsterNumber, $HhugeMonsterTurn, $HhugeMonsterNumber, $HunkownTurn, $HunkownNumber, $HautoReturn, $HcoreTurn, $HcoreNumber, $HcoreMinHP, $HcoreMaxHP, $HcoreFlag);
					$island->{'event'} = \@event;
					if($Hstart - $HnoticeTurn <= $HislandTurn) {
						my $type = $HeventName[$Htype];
						$island->{'comment'} = "<B>$type 개최!</B>";
						if(!$Haddition) {
							$island->{'comment'}.= "(<span class=attention>주의!</span>파견할 수 있는 기간은<B>턴$Hstart 만</B>입니다)";
						} else {
							$island->{'comment'}.= "(<span class=attention>주의!</span><B>턴 $Hstart부터</B> 파견 가능합니다)";
						}
					}
					writeIslandsFile();
				} else {
					foreach (keys %HeventDel) {
						undef $Hislands[$HidToNumber{$_}]->{'event'};
						undef $Hislands[$HidToNumber{$_}]->{'comment'};
					}
				}
				writeIslandsFile();
			}
		} else {
			# 비밀번호 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
	# 템플릿 출력
	setupEventTop();
}

# 이벤트 로그
sub tempEvent {
	my($str) = @_;
	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR><BR>
${HtagBig_}$str${H_tagBig}
END
}

sub setupEventTop {
#	$HislandList = getIslandList($Hislands[$HbfieldNumber]->{'id'}, 2);
	$HislandList = getIslandList(0, 1);
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	# 화면 출력
	unlock();
	out(<<END);
<DIV align='center'>$HtempBack2</DIV><BR>
<H1>이벤트 설정</H1>
<TABLE BORDER><TR><TD class='M' WIDTH=40%>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Esetup">
<TABLE BORDER><TR>
<TH>어느 ${AfterName}에서?</TH>
<TD><SELECT NAME="ISLANDID">$HislandList</SELECT>
</TR><TR>
<TH>유형은?</TH>
<TD><SELECT NAME='TYPE'>
END
	foreach (1..$#HeventName) {
		out("<OPTION VALUE=$_>$HeventName[$_]\n");
	}
	out(<<END);
</SELECT></TD>
</TR><TR>
<TH>언제부터?</TH>
<TD><SELECT NAME="START">
END
	my $nextturn = $HislandTurn + 1;
	my $minturn = $HislandTurn + $HnoticeTurn;
	my $maxturn = $minturn + 50;
	foreach ($nextturn..$maxturn) {
		if($_> $minturn) {
			out("<OPTION VALUE=$_>$_");
		} elsif($_ < $minturn) {
			out("<OPTION style='background: red;' VALUE=$_>$_");
		} else {
			out("<OPTION VALUE=$_ SELECTED>$_");
		}
	}
	out(<<END);
</SELECT>턴시작</TD>
</TR><TR>
<TH>기간은?</TH>
<TD><SELECT NAME="TURM">
<OPTION VALUE=0>무기한
END
	foreach (1..100) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>턴</TD><BR>
</TR><TR>
<TH>파견 가능 함정 수는?</TH>
<TD><SELECT NAME='MAXSHIP'>
END
	my $max = (!$HnavyMaximum) ? int($HislandSizeX*$HislandSizeY/4) : $HnavyMaximum;
	$max = $HfleetMaximum if($HfleetMaximum);
	out("<OPTION VALUE=0>무제한");
	foreach (1..$max) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>함</TD>
</TR><TR>
<TH>파견 가능함종은?</TH>
<TD class='N'><span class='check'><input type=checkbox name=KIND value="0" CHECKED>${HtagDisaster_}신규 건조 함정(경험치0)만${H_tagDisaster}</span><BR>
END
	foreach (1..$#HnavyName) {
		next if($HnavySpecial[$_] & 0x8);
		out("<span class='check'><input type=checkbox name=KIND value=\"$_\" CHECKED>$HnavyName[$_]</span> ");
	}
	out(<<END);
</TD>
</TR><TR>
<TH>추가 파견은?<BR></TH>
<TD class='N'>
<input type=radio name=ADDITION value="0" checked>허가 안 함
<input type=radio name=ADDITION value="1">허가함
</TD>
</TR><TR>
<TH>레벨제한<BR><small>(섬의 레벨)</small></TH>
<TD class='N'><input type=hidden name=RESTRICTION value="0">
END
	foreach (1..$HmaxComNavyLevel) {
		out("<span class='check'><input type=checkbox name=RESTRICTION value=\"$_\" CHECKED>Lv.$_</span> ");
	}
	out("없음") if(!$HmaxComNavyLevel);
	out(<<END);
</TD>
</TR><TR>
<TH>함대 귀환 처리<BR><small>(이벤트 종료 시)</small></TH>
<TD class='N'>
<input type=radio name=AUTORETURN value="1" checked>귀환하다
<input type=radio name=AUTORETURN value="0">귀환하지 않음
</TD>
</TR><TR>
<TH>괴수출현 빈도</TH>
<TD class='N'><SELECT NAME='MONSTERTURN'>
END
	foreach (1..10) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>턴 후<SELECT NAME='MONSTERNUMBER'>
END
	foreach (0..10) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>마리<BR>
</TD>
</TR><TR>
<TH>거대괴수출현 빈도</TH>
<TD class='N'><SELECT NAME='HUGEMONSTERTURN'>
END
	foreach (1..10) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>턴 후<SELECT NAME='HUGEMONSTERNUMBER'>
END
	foreach (0..10) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>마리<BR>
</TD>
</TR><TR>
<TH>소속 불명 함정 출현 빈도</TH>
<TD class='N'><SELECT NAME='UNKNOWNTURN'>
END
	foreach (1..10) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>턴 후<SELECT NAME='UNKNOWNNUMBER'>
END
	foreach (0..10) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>함<BR>
</TD>
</TR><TR>
<TH>$HlandName[$HlandCore][0]출현 빈도</TH>
<TD class='N'><SELECT NAME='CORETURN'>
END
	foreach (1..100) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>턴 후<SELECT NAME='CORENUMBER'>
END
	foreach (0..10) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT>기준<BR>
내구력:min<SELECT NAME='COREMINHP'>
END
	my $num = min($HdurableCore, 99);
	foreach (0..$num) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT> max<SELECT NAME='COREMAXHP'>
END
	foreach (0..$num) {
		out("<OPTION VALUE=$_>$_");
	}
	out(<<END);
</SELECT><BR>
<span class='check'><input type=checkbox name=COREFLAG value='1'></span>괴멸 시 이벤트${HtagDisaster_}강제종료${H_tagDisaster}<BR>
 <small>(서바이벌을 제외)</small>
</TD>
</TR><TR>
<TH>보상은?</TH>
<TD class='N'><B>자금</B><input type=text style='text-align=right' name=MONEY size=12 value=0>$HunitMoney<BR>
<B>식량</B><input type=text style='text-align=right' name=FOOD size=12 value=0>$HunitFood
<HR><input type=checkbox name=PRESENT value="1"><B>관리자선물</B><BR>
 (게시판등에서 별도도중공지해 주세요)
END

	if($HuseItem) {
		out("<HR>");
		foreach (1..$#HitemName) {
			out("<span class='check'><input type=checkbox name=ITEM value=\"$_\"><img src=\"$HitemImage[$_]\" title=\"$HitemName[$_]\"></span>\n");
		}
	}

	out(<<END);
</TD>
</TR><TR><TH colspan=2>
<INPUT TYPE="submit" VALUE="설정하기" NAME="SetEventButton"><BR>
</TH></TR></TABLE>
</FORM></TD>
<TD class='M' valign='top' WIDTH=60%>
<H3>■이벤트에 대해■</H3>
이 설정은, 전장 대전을 관리하기 위한 설정입니다.<BR><BR>
·시작 턴은,(설정한 턴 + 유예 턴)이후에서 설정 가능합니다.<BR>
 (시작 턴-유예 턴)이 되면 메인 페이지의 코멘트란에 이벤트 발생을 공지하고,
타 섬에서 파견되어 있는 모든 함정을 귀환시킵니다.<BR><BR>
·파견할 수 있는 함정 수나 함정 종류를 설정할 수 있습니다.<BR>
 경험치에 따른 격차를 없애기 위해'신규 건조 함정(경험치0의 함정)'만을 파견 가능하도록 설정할 수도 있습니다.<BR><BR>
<TABLE BORDER WIDTH=100%>
<TR><TH>서바이벌</TH><TD class='N'>파견한 섬이 1섬이 될 때까지 함정끼리 서로 격파하는 방식입니다.<BR>기간은 무기한이며, 시작 턴에만 파견을 받습니다.</TD></TR>
<TR><TH>함정 경험치 획득 배틀</TH><TD class='N'>파견 함정이 기간 안에 획득한 경험치에서 순위를 결정합니다.<BR>기간을 설정하지 않으면 순위에 반영되지 않습니다.</TD></TR>
<TR><TH>함정 격침 배틀</TH><TD class='N'>파견 함정이 기간 안에 격침한 함정 수에서 순위를 결정합니다.<BR>기간을 설정하지 않으면 순위에 반영되지 않습니다.</TD></TR>
<TR><TH>괴수 퇴치 배틀</TH><TD class='N'>파견 함정이 기간 안에 퇴치한 괴수·거대괴수의 수에서 순위를 결정합니다.<BR>기간을 설정하지 않으면 순위에 반영되지 않습니다.</TD></TR>
<TR><TH>상금 획득 배틀</TH><TD class='N'>파견 함정이 기간 안에 획득한 상금 총액으로 순위를 결정합니다.<BR>기간을 설정하지 않으면 순위에 반영되지 않습니다.</TD></TR>
</TABLE>
</TD></TR></TABLE>
<HR>
<H1>이벤트 설정 목록</H1>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Esetup">
<TABLE BORDER><TR>
<TD><INPUT TYPE="submit" VALUE="삭제" NAME="DelEventButton"></TD>
<TH>${AfterName} 이름</TH>
<TH>유형</TH>
<TH>시작<BR>턴</TH>
<TH>기간</TH>
<TH>함정 수</TH>
<TH>함종</TH>
<TH>추가<BR>파견</TH>
<TH>제한</TH>
<TH>괴수</TH>
<TH>거대<BR>괴수</TH>
<TH>소속<BR>불명함</TH>
<TH>$HlandName[$HlandCore][0]</TH>
<TH>보상</TH>
</TR>
END
	my $flag = 0;
	foreach (0..$islandNumber){
		my $island = $Hislands[$_];
		next if(!$island->{'event'}[0]);
		$flag = 1;
		my $id = $island->{'id'};
		my $name = islandName($island);
		my $turn = $island->{'event'}[1];
		my $turm = $island->{'event'}[2];
		$turm = '무기한' if(!$turm);
		$turm.= "<BR><BR><small>${HtagDisaster_}강제종료유${H_tagDisaster}</small>"if($island->{'event'}[23]);
		my $max = $island->{'event'}[3];
		$max = ($max) ? "$max 함" : '무제한';
		my $kind = $island->{'event'}[4];
		my $ship = '';
		foreach (1..$#HnavyName) {
			$ship.= " $HnavyName[$_]" if($kind & (2 ** $_));
		}
		if($ship eq '') {
			$ship = "${HtagDisaster_}없음${H_tagDisaster}";
		} elsif($kind & 1) {
			$ship = "${HtagDisaster_}$ship${H_tagDisaster}";
		}
		my $restriction = $island->{'event'}[5];
		my $addition = ('×', '○')[$island->{'event'}[11]];
		my $limit = '';
		if(!$HmaxComNavyLevel) {
			$limit = '제한없음';
		} else {
			$limit = '<TABLE border=1 cellpadding=1 cellspacing=0><TR>';
			foreach (1..$HmaxComNavyLevel) {
				$limit.= "<TD>Lv.$_</TD>";
			}
			$limit.= '</TR><TR>';
			foreach (1..$HmaxComNavyLevel) {
				if($restriction & (2 ** $_)) {
					$limit.= "<TD align='center'>○</TD>";
				} else {
					$limit.= "<TD align='center'>×</TD>";
				}
			}
			$limit.= '</TR></TABLE>';
		}
		my $type = $HeventName[$island->{'event'}[6]];
		my $money = $island->{'event'}[7];
		my $food = $island->{'event'}[8];
		my $present = $island->{'event'}[9];
		my @item = split(' *', $island->{'event'}[10]);
		my $prize = '';
		$prize = "$money$HunitMoney" if($money);
		if($food) {
			$prize.= " + " if($money);
			$prize.= "$food$HunitFood";
		}
		if($present) {
			$prize.= " + " if($money || $food);
			$prize.= "관리자선물";
		}
		if($island->{'event'}[10]) {
			$prize.= " + " if($money || $food || $present);
			foreach (1..$#HitemName) {
				$prize.= "<span class='check'><img src=\"$HitemImage[$_]\" title=\"$HitemName[$_]\"></span>\n" if($item[$_]);
			}
		}
		$prize = '없음' if($prize eq '');
		my $mons = ($island->{'event'}[13]) ? "${HtagNumber_}$island->{'event'}[12]${H_tagNumber}<small>턴<BR>후</small><BR><B>$island->{'event'}[13]</B><small>마리 출현</small>" : '출현하지 않음';
		my $huemons = ($island->{'event'}[15]) ? "${HtagNumber_}$island->{'event'}[14]${H_tagNumber}<small>턴<BR>후</small><BR><B>$island->{'event'}[15]</B><small>마리 출현</small>" : '출현하지 않음';
		my $unknown = ($island->{'event'}[17]) ? "${HtagNumber_}$island->{'event'}[16]${H_tagNumber}<small>턴<BR>후</small><BR><B>$island->{'event'}[17]</B><small>척 출현</small>" : '출현하지 않음';
		my $core = () ? "${HtagNumber_}$island->{'event'}[19]${H_tagNumber}<small>턴<BR>후</small><BR><B>$island->{'event'}[20]</B><small>기준 출현</small>" : '출현하지 않음';
		if($island->{'event'}[20]) {
			$core = "${HtagNumber_}$island->{'event'}[19]${H_tagNumber}<small>턴<BR>후</small><BR><B>$island->{'event'}[20]</B><small>기준 출현<BR><B>HP</B>:min<B>$island->{'event'}[21]</B>,max<B>$island->{'event'}[22]</B></small>";
		} else {
			$core = '출현하지 않음';
		}
		out(<<END);
<TR>
<TD align='center'><input type=checkbox name=DEL value="$id"></TD>
<TD align='right'>$name</TD>
<TD align='right'>$type</TD>
<TD align='right'>$turn</TD>
<TD align='right'>$turm</TD>
<TD align='right'>$max</TD>
<TD class='N' align='right'>$ship</TD>
<TD align='center'>$addition</TD>
<TD align='right'>$limit</TD>
<TD align='right'>$mons</TD>
<TD align='right'>$huemons</TD>
<TD align='right'>$unknown</TD>
<TD align='right'>$core</TD>
<TD class='N' align='right'>$prize</TD>
</TR>
END
	}
	out("<TR><TH colspan=14>데이터 없습니다!</TH></TR>") if(!$flag);
	out("</TABLE><INPUT TYPE=\"hidden\" VALUE=\"dummy\" NAME=\"EventDelete\"></FORM>");
}

#----------------------------------------------------------------------
# 저장 데이터 목록
#----------------------------------------------------------------------
sub loseIslandAdminTop {
	my($str) = @_;

	$str = "${HtagBig_}$str${H_tagBig}<HR>" if(defined $str);

	# '돌아가기' 링크 2
	my $HtempBack2 = (checkSpecialPassword($HdefaultPassword)) ? "${HtagBig_}<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>${H_tagBig}" : $HtempBack;

	out(<<END);
$str
<DIV align='center'>$HtempBack2</DIV><BR>
<H1>패자의 섬 목록<small>(${HfightdirName}폴더)</small></H1>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Reload">
<BR><BR>
＊패자의${AfterName} 이름을 클릭하면 패전 당시의 상황을 볼 수 있습니다.<BR>
＊$AfterName이름 왼쪽의 버튼을 선택하고'복원'을 클릭하면, 전선에 복구·귀환할 수 있습니다.<BR>
·침몰하지 않는 $AfterName인 경우, ID, $AfterName, 소유자 이름, 비밀번호가 모두 일치하면 데이터가 교체됩니다.<BR>
·그 외의 경우, 새 $AfterName로 ID가 할당됩니다.<BR>
[주]준비 없이 실행하면, 같은 이름의 $AfterName이 여러 개가 되어 혼란의 원인이 됩니다)<BR>
 토너먼트 사용은 동작을 보증할 수 없습니다. 진영전쟁이나 서바이벌에서도 사용을 피하는 편이 좋습니다.<BR>
<TABLE><TR>
<TH><INPUT TYPE=\"submit\" VALUE=\"복원\" NAME=\"ReloadButton\"></TH>
<TH><INPUT TYPE=\"submit\" VALUE=\"삭제\" NAME=\"DeleteButton\"></TH>
<TH $HbgTitleCell>DL</TH>
<TH $HbgTitleCell>${HtagTH_}${AfterName}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}ID${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}소유자${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}면적${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}자금${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}농장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}공장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}채굴장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}총 획득 경험치${H_tagTH}</TH>
</TR>
END

	opendir(DIN, "${HfightdirName}/");
	# 백업 데이터
	my($dn, @suf);
	while($dn = readdir(DIN)) {
		if($dn =~ /^([0-9]+)_lose.${HsubData}/) {
			push(@suf, $1);
		}
	}
	foreach (sort { $a <=> $b } @suf) {
		open(LIN, "${HfightdirName}/${_}_lose.${HsubData}");
		chomp(my @line = <LIN>);
		close(LIN);
		splice(@line, 20);

		my($name, $owner, $id, $money, $food, $pop, $area, $farm, $factory, $mountain, $gain);
		$name = shift @line; # *섬 이름*
		$owner = shift @line; # *소유자의 이름*
		shift @line; # 시작 턴
		$id = shift @line; # *ID 번호*
		shift @line; # 수상
		shift @line; # 연속자금 조달 수, 개발위임위탁(진영보관), 명령 실행 설정
		shift @line; # 코멘트
		shift @line; # 암호화 비밀번호
		$money = shift @line; # *자금*
		$food = shift @line; # *식량*
		$pop = shift @line; # *인구*
		$area = shift @line; # *면적*
		$farm = shift @line; # *농장*
		$factory = shift @line; # *공장*
		$mountain = shift @line; # *채굴장*
		shift @line; # 우호국
		shift @line; # 함대 이름
		shift @line; # 색적 순서
		shift @line; # 보유 함정종류
		$gain = shift @line; # *총 획득 경험치*
		$islandName = $name. $AfterName;
		if(defined $HidToNumber{$_}) {
			$islandName = $HtagName1_. $islandName. $H_tagName1;
		} else {
			$islandName = $HtagName2_. $islandName. $H_tagName2;
		}
		$pop = ($pop == 0) ? "무인" : "$pop$HunitPop";
		1 while $pop =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$area = ($area == 0) ? "해역" : "$area$HunitArea";
		1 while $area =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$money = ($money == 0) ? "자금 없음" : "$money$HunitMoney";
		1 while $money =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$food = ($food == 0) ? "비축제로" : "$food$HunitFood";
		1 while $food =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
		1 while $farm =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
		1 while $factory =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
		1 while $mountain =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my $navyComLevel = gainToLevel($gain);
		my $totalExp = $gain;
		1 while $totalExp =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$totalExp.= "(Lv.${navyComLevel})" if($HmaxComNavyLevel);
		out(<<END);
<TR>
<TD $HbgNumberCell align='center'><input type=radio name=RELOADIDLOSE value=\"${_}\"></TD>
<TD $HbgNumberCell align='center'><input type=checkbox name=DELETEIDLOSE value=\"${_}\"></TD>
<TD $HbgNumberCell align='center'><A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Download=$HdefaultPassword&mode=2&id=${_}\">DL</A></TD>
<TH $HbgNameCell><A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?LoseMap=${_}&ADMINMODELOSE=$HdefaultPassword\" target=\"_blank\">$islandName</A></TH>
<TD $HbgInfoCell align=right><B>$id</B></TD>
<TD $HbgInfoCell align=right>$owner</TD>
<TD $HbgInfoCell align=right>$pop</TD>
<TD $HbgInfoCell align=right>$area</TD>
<TD $HbgInfoCell align=right>$money</TD>
<TD $HbgInfoCell align=right>$food</TD>
<TD $HbgInfoCell align=right>$farm</TD>
<TD $HbgInfoCell align=right>$factory</TD>
<TD $HbgInfoCell align=right>$mountain</TD>
<TD $HbgInfoCell align=right>$totalExp</TD>
</TR>
END
	}
	closedir(DIN);

	out(<<END);
</TABLE>
<HR>
<H1>저장 데이터 목록<small>(${HsavedirName}폴더)</small></H1>
<BR><BR>
＊${AfterName} 이름을 클릭하면 저장 상태를 볼 수 있습니다.<BR>
＊$AfterName이름 왼쪽의 버튼을 선택하고'복원'을 클릭하면, 지형 데이터를 복원할 수 있습니다.<BR>
·ID, $AfterName, 소유자 이름, 비밀번호가 모두 일치하지 않으면 새 $AfterName으로 ID가 할당됩니다.<BR>
·단, 이미 침몰한 섬이라도 저장 데이터가 있다면, 전선에 복구·귀환하게 할 수 있습니다.<BR>
<TABLE><TR>
<TH><INPUT TYPE=\"submit\" VALUE=\"복원\" NAME=\"ReloadButton\"></TH>
<TH><INPUT TYPE=\"submit\" VALUE=\"삭제\" NAME=\"DeleteButton\"></TH>
<TH $HbgTitleCell>DL</TH>
<TH $HbgTitleCell>${HtagTH_}${AfterName}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}ID${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}소유자${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}면적${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}자금${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}농장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}공장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}채굴장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}총 획득 경험치${H_tagTH}</TH>
</TR>
END
	opendir(DIN, "${HsavedirName}/");
	# 백업 데이터
	my($dn, @suf);
	while($dn = readdir(DIN)) {
		if($dn =~ /^([0-9]+)_save.${HsubData}/) {
			push(@suf, $1);
		}
	}
	foreach (sort { $a <=> $b } @suf) {
		open(LIN, "${HsavedirName}/${_}_save.${HsubData}");
		chomp(my @line = <LIN>);
		close(LIN);

		my($name, $owner, $id, $money, $food, $pop, $area, $farm, $factory, $mountain, $gain);
		$name = shift(@line); # *섬 이름*
		$owner = shift(@line); # *소유자의 이름*
		shift(@line); # 시작 턴
		$id = shift(@line); # *ID 번호*
		shift(@line); # 수상
		shift(@line); # 연속자금 조달 수, 개발위임위탁(진영보관), 명령 실행 설정
		shift(@line); # 코멘트
		shift(@line); # 암호화 비밀번호
		$money = shift(@line); # *자금*
		$food = shift(@line); # *식량*
		$pop = shift(@line); # *인구*
		$area = shift(@line); # *면적*
		$farm = shift(@line); # *농장*
		$factory = shift(@line); # *공장*
		$mountain = shift(@line); # *채굴장*
		shift(@line); # 우호국
		shift(@line); # 함대 이름
		shift(@line); # 색적 순서
		shift(@line); # 보유 함정종류
		$gain = shift(@line); # *총 획득 경험치*
		$islandName = $name. $AfterName;
		if(defined $HidToNumber{$_}) {
			$islandName = $HtagName1_. $islandName. $H_tagName1;
		} else {
			$islandName = $HtagName2_. $islandName. $H_tagName2;
		}
		$pop = ($pop == 0) ? "무인" : "$pop$HunitPop";
		1 while $pop =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$area = ($area == 0) ? "해역" : "$area$HunitArea";
		1 while $area =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$money = ($money == 0) ? "자금 없음" : "$money$HunitMoney";
		1 while $money =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$food = ($food == 0) ? "비축제로" : "$food$HunitFood";
		1 while $food =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
		1 while $farm =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
		1 while $factory =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
		1 while $mountain =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my $navyComLevel = gainToLevel($gain);
		my $totalExp = $gain;
		1 while $totalExp =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$totalExp.= "(Lv.${navyComLevel})" if($HmaxComNavyLevel);
		out(<<END);
<TR>
<TD $HbgNumberCell align='center'><input type=radio name=RELOADIDSAVE value=\"${_}\"></TD>
<TD $HbgNumberCell align='center'><input type=checkbox name=DELETEIDSAVE value=\"${_}\"></TD>
<TD $HbgNumberCell align='center'><A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Download=$HdefaultPassword&mode=1&id=${_}\">DL</A></TD>
<TH $HbgNameCell><A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?LoseMap=${_}&ADMINMODESAVE=$HdefaultPassword\" target=\"_blank\">$islandName</A></TH>
<TD $HbgInfoCell align=right><B>$id</B></TD>
<TD $HbgInfoCell align=right>$owner</TD>
<TD $HbgInfoCell align=right>$pop</TD>
<TD $HbgInfoCell align=right>$area</TD>
<TD $HbgInfoCell align=right>$money</TD>
<TD $HbgInfoCell align=right>$food</TD>
<TD $HbgInfoCell align=right>$farm</TD>
<TD $HbgInfoCell align=right>$factory</TD>
<TD $HbgInfoCell align=right>$mountain</TD>
<TD $HbgInfoCell align=right>$totalExp</TD>
</TR>
END
	}
	out("</TABLE><INPUT TYPE='hidden' VALUE='0' NAME='dummy'></FORM>");
	closedir(DIN);
#<FORM action="$HthisFile" method="POST" encType="multipart/form-data">
	out(<<END) if($HuseUpload);
<FORM action="$HuploadFile" method="POST" encType="multipart/form-data">
<HR>
<H1>데이터 업로드</H1>
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Upload">
＊로컬에 저장하고 있는 데이터를 업로드할 수 있습니다.<BR>
·파일 이름이,[ID]_lose.${HsubData}라면${HfightdirName}폴더로,[ID]_save.${HsubData}라면${HsavedirName}폴더로 업로됩니다.<BR>
 ([ID]의 곳은1에서100까지의 중 하나의 숫자)<BR>
·데이터 정합성 확인은 거의 없으므로, 이상한 파일을 업로드하지 않도록 해 주세요.<BR>
<INPUT TYPE="file" NAME="FILE">
<INPUT TYPE="submit" VALUE="추가" NAME=\"UPLOADBUTTON\">
</FORM>
END

	# 화면 출력
	unlock();
}

# 저장 데이터 삭제
sub dataDelete {
	my($mode) = @_;
	if(!checkSpecialPassword($HdefaultPassword)) {
		# 비밀번호 오류
		unlock();
		tempWrongPassword();
		return;
	} elsif(!$mode) {
		unlock();
		tempProblem();
		return;
	}
	if($mode & 1) { # save
		foreach (@HsaveID) {
			unlink("${HsavedirName}/${_}_save.${HsubData}") if(-e "${HsavedirName}/${_}_save.${HsubData}");
		}
	}
	if($mode & 2) { # lose
		foreach (@HloseID) {
			unlink("${HfightdirName}/${_}_lose.${HsubData}") if(-e "${HfightdirName}/${_}_lose.${HsubData}")
		}
	}
	# 화면 출력
	unlock();
	loseIslandAdminTop('삭제했습니다');
	return;
}

# 저장 데이터다운로드
sub dataDownload {
	my($mode) = @_;
	unlock();
	if(!checkSpecialPassword($HdefaultPassword)) {
		# 비밀번호 오류
		unlock();
		tempHeader();
		tempWrongPassword();
		return;
	}

	my $dir = (!($mode % 2)) ? $HfightdirName : $HsavedirName;
	my $file = (!($mode % 2)) ? "${HcurrentID}_lose.${HsubData}" : "${HcurrentID}_save.${HsubData}";
	open(IN, "${dir}/${file}");
	my @line = <IN>;
	close(IN);
 print "Content-Disposition: attachment; filename=$file\n";
 print "Content-type: application/octet-stream\n\n";
 print @line;
 exit;
}

1;
