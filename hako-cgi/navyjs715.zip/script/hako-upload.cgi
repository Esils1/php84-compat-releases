#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

# The Return of Neptune: http://no-one.s53.xrea.com/
# patchworked by neo_otacky. for 바다전쟁 JS
#----------------------------------------------------------------------
# 업로드 모듈
#	섬 데이터를 서버로 올릴까요 위한 기능입니다.
#----------------------------------------------------------------------
BEGIN {
	# Perl 5.004 이상이필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}
#---------------------------------------------------------------------
#	초기 설정
#---------------------------------------------------------------------
# 초기 설정용 파일을 읽기
require './hako-init.cgi';
require './hako-io.cgi';
require './init-game.cgi';

#여기까지-------------------------------------------------------------

if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	close(PIN);
}
&cookieInput();
if(!(&formdecode())){
	&error("전송 오류");
}
if(!checkSpecialPassword($HdefaultPassword)) {
	$HtempBack2 = "<small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>";
	&error("비밀번호 오류");
} else {
	$HtempBack2 = "<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A> <small><A HREF=\"$HthisFile\">맨 위로 돌아가기</A></small>";
}
if(!(&readIslandsFile())){
	&error("메인 데이터 읽기오류");
} else {
	&dataUpload();
}

#종료
exit(0);

# 서브 루틴---------------------------------------------------------
#----------------------------------------------------------------------
# 데코드
#----------------------------------------------------------------------
sub formdecode {
	my($line, $boundary, @params, $param);

	if($HuseUpload && uc($ENV{'REQUEST_METHOD'}) eq 'POST') {
		binmode STDIN;
		read(STDIN, $line, $ENV{'CONTENT_LENGTH'});
	} else {
		return 0;
	}
	if ( $line =~ /^(-+\w+)/ ) {
		$boundary = $1;
		@params = split($boundary, $line);
	}

	foreach $param (@params) {
		if ( $param =~ /^--/ ) { last; }
		$param =~ s/^(\r\n|\r|\n)//;
		$param =~ s/(\r\n|\r|\n)$//;
		if ( $param =~ /^Content-Disposition: form-data; name="([^"]*?)"; filename="([^"]*?)"(\r\n|\r|\n)/ ) {
			$Hfilename = $2; # 업로드된 파일 이름
			if ($Hfilename =~ /\\/) {
				$Hfilename = (split(/\\/, $Hfilename))[-1];
			}
			$param =~ s/^Content-Disposition:(.+?)(\r\n|\r|\n)Content-Type:(.+?)(\r\n\r\n|\r\r|\n\n)//i;
			$param =~ s/(\r\n|\r)/\n/g;
			@Hcontents = split(/\n/, $param); # 파일 본문 데이터
		} elsif ( $param =~ /^Content-Disposition: form-data; name="([^"]*?)"(\r\n|\r|\n)/ ) { #"
			$name = $1;
			$param =~ s/^Content-Disposition:(.+?)(\r\n\r\n|\r\r|\n\n)//i;
			if($name eq 'Upload') {
				$HmainMode = 'upload';
				$HinputPassword = htmlEscape($param);
				$HdefaultPassword = $HinputPassword;
			}
		}
	}
	return ($HmainMode eq 'upload') ? 1 : 0;
}

#----------------------------------------------------------------------
# 업로드
#----------------------------------------------------------------------
sub dataUpload {

	my $kind = '';
	if(checkSpecialPassword($HdefaultPassword)) {
		if($Hfilename =~ /^([0-9]+)_save.${HsubData}/) {
			$HcurrentID = $1;
			$kind = 'save';
			$mode = 1;
		} elsif($Hfilename =~ /^([0-9]+)_lose.${HsubData}/) {
			$HcurrentID = $1;
			$kind = 'lose';
			$mode = 2;
		}
	}
	if($kind eq '') {
		&error("파일에문제가 있습니다.");
	}
	# 내부 ID와의 정합성(차이가 있을 경우 외부 ID로 변경)
	$Hcontents[3] = $HcurrentID if($Hcontents[3] != $HcurrentID);

	my $dir = ($kind eq 'lose') ? $HfightdirName : $HsavedirName;
	my $flag = 0;
	if(open(LIN, "${dir}/${Hfilename}")) {
		# 동일 이름 파일을 읽기 0 섬 이름,1소유자 이름,7 비밀번호를 확인
		chomp(my @line = <LIN>);
		close(LIN);
		if(($line[0] ne $Hcontents[0]) || ($line[1] ne $Hcontents[1]) || ($line[7] ne $Hcontents[7])) {
			# 새 ID 할당
			my($dn, %dnset);
			opendir(DIN, "${dir}/");
			# 백업 데이터
			while($dn = readdir(DIN)) {
				if($dn =~ /^([0-9]+)_${kind}.${HsubData}/) {
					$dnset{$1} = 1;
				}
			}
			closedir(DIN);
			foreach (1..100) {
				if(!$dnset{$_}) {
					$HcurrentID = $_ ;
					last;
				}
			}
			# 내부 ID 의 변경
			if($Hcontents[3] != $HcurrentID) {
				$Hcontents[3] = $HcurrentID
			} else {
				# 할당에 실패
				&error("ID 의할당에 실패했습니다.");
			}
		} else {
			$flag = 1;
		}
	} elsif(!opendir(DIN, "${dir}/")) {
		# 저장 디렉터리의 확인
		mkdir("${dir}", $HdirMode);
	} else {
		closedir(DIN);
	}

	my $file = "${HcurrentID}_${kind}.${HsubData}";
	my $tmpfile = "tmp_${HcurrentID}_${kind}.${HsubData}";

	open(FILE, ">${dir}/${tmpfile}");
	binmode FILE;
	foreach (@Hcontents) {
		print FILE $_. "\n";
	}
	close(FILE);

	# 원래 이름으로
	unlink("${dir}/${file}") if($flag);
	rename("${dir}/${tmpfile}", "${dir}/${file}");

	print "Location: ${HthisFile}?ViewLose=${HdefaultPassword}\n\n";
	exit(0); # 종료
}

#---------------------------------------------------------------------
# 오류출력
#---------------------------------------------------------------------
sub error {
	print qq{Content-type: text/html; charset=UTF-8\n\n};
	print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};

	out(<<END);
<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8"><TITLE>ERROR!</TITLE></HEAD>
$Body<DIV ID='BodySpecial'>
$HtempBack2
<HR>
$_[0]
<HR>
</DIV>
</BODY></HTML>
END
	exit(0);

}

1;
