#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
# 모형정원 모형정원 바다전쟁 JS ver7.xx
# 턴진행보조모듈(ver1.00)
# 미사일 공격
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------

# 미사일 발사
sub missileFire {
	my($target, $island, $tIsland, $x, $y, $kind, $arg, $cost) = @_;

	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($comName) = $HcomName[$kind];
	my($point) = "($x, $y)";

	my($tName) = islandName($tIsland);
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tLandName) = landName($tLand->[$x][$y], $tLandValue->[$x][$y]);
	$tLandName = ($HlandMove[$target][$x][$y]) ? "${HtagName2_}${tLandName}${H_tagName2}" : "${HtagName_}${tLandName}${H_tagName}";

	my($boat) = 0; # 난민의 수
	my($flagbase) = 0;
	my($xx, $yy, $tx, $ty, @pointErr);
	my(%damageId);
	my($mkind) = $kind - $HcomMissile[0];
	my($special) = $HmissileSpecial[$mkind];
	my($err) = $an[$HmissileErr[$mkind]]; # 오차
	my($damage)= int($HmissileDamage[$mkind]);# 파괴력
	$damage = 1 if($damage < 1);

	# 착탄 지점의 확장 분산 범위
	my $range = 0;

	# 사거리 안에 괴수·거대괴수가 없으면, 발사 중지
	if($HtargetMonster &&
		!countAround($tIsland, $x, $y, $err, $HlandMonster, $HlandHugeMonster)) {
		logNoTarget($id, $name, $comName);
		return;
	}

	# 우호국 설정을 확인
	my(%amityFlag, @noDefenceIds);
	if($HmissileSafetyZone) {
		$amityFlag{$id} = 1;
		if(($HmissileSafetyZone == 2) && (!$HamityInvalid || !$island->{'field'})) {
			foreach (@{$island->{'amity'}}) {
				$amityFlag{$_} = 1;
			}
		}
	}
	if($HdBaseSelfNoDefenceMS == 1) {
		@noDefenceIds = ($id);
	} elsif($HdBaseSelfNoDefenceMS == 2) {
		@noDefenceIds = ($id, @{$island->{'amityBy'}});
	} elsif($HdBaseSelfNoDefenceMS == 3) {
		@noDefenceIds = ($id, @{$island->{'amity'}});
	} elsif($HdBaseSelfNoDefenceMS == 4) {
		@noDefenceIds = ($id, @{$island->{'amity'}}, @{$island->{'amityBy'}});
	} else {
		@noDefenceIds = (0);
	}

	#자금이 부족하면 지정수량을 충족하거나 전체 기지 가격에 도달할 시까지 반복
	my($bx, $by, $count, $fire) = (0, 0, 0, 0);
	my($bKind, $bLv, @terrorPnt);
	while (($arg> 0) && ($island->{'money'}>= $cost)) {
		# 기지를 찾을 시까지 반복
		while ($count <= $island->{'pnum'}) {
			$bx = $island->{'rpx'}[$count];
			$by = $island->{'rpy'}[$count];
			$bKind = $land->[$bx][$by];
			$bLv = $landValue->[$bx][$by];

			last if (($bKind == $HlandBase) || ($bKind == $HlandSbase));

			$count++;
		}

		# 찾을 수 없으면 그곳까지
		last if ($count> $island->{'pnum'});

		# 최소하나기지가 있었던이므로,flag 을설립하고 있는
		$flagbase = 1;

		# 기지의 레벨을 산출
		my($level) = expToLevel($bKind, $bLv);


#$level = 14;
#$arg = 14;

		# 기지내에서 루프
		while (($level> 0) && ($arg> 0) && ($island->{'money'}> $cost)) {
			# 기지의 최신상황을 조사하기
			$bKind = $land->[$bx][$by];
			$bLv = $landValue->[$bx][$by];

			# 착탄 지점 산출
			my($r) = random($err);
			$xx = $x + $ax[$r];
			$yy = $y + $ay[$r];
			# 행 기준 위치 조정
			$xx-- if(!($yy % 2) && ($y % 2));
			$xx = $correctX[$xx + $#an];
			$yy = $correctY[$yy + $#an];

			if($special & 0x4) {
				if (($xx < 0) || ($yy < 0)) {
					# 범위 밖의 경우, 융단 폭격하지 않음
					$range = 0;
				} else {
					push(@terrorPnt, "($xx, $yy)");
					$range = $an[$HmissileTerrorHex[$mkind]] - 1;
				}
			}
			my(@order) = randomArray($range + 1);
			foreach my $loop (0..$range) {
				# 명중이 확정이므로, 각 값을 소도
				$level--;
				$arg--;
				last if($level < 0 || $arg < 0 || $island->{'money'} < $cost);
				$fire++;
				$island->{'money'} -= $cost;
				$island->{'shellMoney'} += $cost;

				if(!$STcheck{$kind}) {
					$island->{'ext'}[1] += $cost; # 공헌도
					$island->{'ext'}[6]++; # 발사한 미사일의 수
					if($HallyNumber) {
						foreach (@{$island->{'allyId'}}) {
							$Hally[$HidToAllyNumber{$_}]->{'ext'}[0]++;
						}
					}
				}
				if($HallyNumber) {
					my $allyflag = 0;
					my $ai;
					foreach $ai (@{$island->{'allyId'}}) {
						foreach (@{$tIsland->{'allyId'}}) {
							if($_ == $ai) {
								$allyflag = 1;
								last;
							}
						}
					}
					if($allyflag) {
						# 아군을 공격한 경우 공헌도 감소(피해를 받을 미사일의 수는 카운트하지 않음)
						$tIsland->{'ext'}[1] -= $cost; # 공헌도
					} else {
						# 적을 공격한 경우 공헌도 증가
						$tIsland->{'ext'}[1] += $cost; # 공헌도
						$tIsland->{'ext'}[5]++; # 피해를 받을 미사일의 수
					}
					foreach (@{$tIsland->{'allyId'}}) {
						$Hally[$HidToAllyNumber{$_}]->{'ext'}[1]++;
					}
				}

				# 착탄 지점 산출
				$tx = $xx + $ax[$order[$loop]];
				$ty = $yy + $ay[$order[$loop]];
				# 행 기준 위치 조정
				$tx-- if(!($ty % 2) && ($yy % 2));
				$tx = $correctX[$tx + $#an];
				$ty = $correctY[$ty + $#an];

				# 착탄 지점범위안팎 확인
				if (($tx < 0) || ($ty < 0)) {
					# 범위 밖
					push(@pointErr, { 'OB' => $tPoint });
					next;
				}

				# 착탄 지점의 지형등 산출
				my($tL) = $tLand->[$tx][$ty];
				my($tLv) = $tLandValue->[$tx][$ty];
				my($tLname) = landName($tL, $tLv);
				my($tPoint) = "($tx, $ty)";

				# 방위 시설 판정
				my($defence) = 0;
				my($defflag) = 1;
				# 미판정영역
				if (($tL == $HlandDefence) || countAroundComplex($tIsland, $tx, $ty, $an[0], 0x20) ||
					countAroundNavySpecial($tIsland, $tx, $ty, 0x20, $an[0], 0)){
					# 방위 시설에 명중
					if (($tL == $HlandDefence) && # 방위 시설에서
						!($special & 0x2)) { # 육지 파괴 이외
						if($amityFlag{$target}) { # 무해화
							if(random(100) < $HmissileSafetyInvalidp) {
								# 일정 확률로 오폭
								push(@pointErr, { 'SS' => $tPoint });
							} else {
								push(@pointErr, { 'SZ' => $tPoint });
								next;
							}
						}
						# 방위 시설의 내구력을 높이기
						$defflag = ($tLv % 100) - $damage;
						$tLv -= $damage;
						if($defflag < 0) {
							$tIsland->{'dbase'}--;
							$island->{'ext'}[2]++ if(!$STcheck{$kind}); # 파괴한 방위 시설의 수
						}
					}
				} elsif (countAroundDef($target, $tIsland, $tx, $ty, 0x20, @noDefenceIds)) {
					# 방위 범위
					$defence = 1;
				}

				if ($defence) {
					# 공안폭파
					push(@pointErr, { 'DF' => $tPoint });
					$tIsland->{'ext'}[7]++; # 방위 시설에서 방어한 미사일의 수
					next;
				}

				# '효과 없음' hex를 먼저 판정
				if ((($tL == $HlandSea) && (!$tLv)) || # 깊은 바다
					((($tL == $HlandSea) || # 바다
					((($tL == $HlandSbase) || ($tL == $HlandSbase)) && !($special & 0x20)) || # 해저 기지또는 기뢰에서 잠수무효없음
					($tL == $HlandMountain))) && # 산
					!($special & 0x2)) { # 육지 파괴 이외

					# 무효화
					push(@pointErr, { 'ND' => $tPoint });
					next;
				}

				# 해군, 괴수, 거대괴수이외의 무해화
				if($amityFlag{$target} && $tL != $HlandNavy && $tL != $HlandMonster && $tL != $HlandHugeMonster) {
					if(random(100) < $HmissileSafetyInvalidp) {
						# 일정 확률로 오폭
						push(@pointErr, { 'SS' => $tPoint });
					} else {
						push(@pointErr, { 'SZ' => $tPoint });
						next;
					}
				}

				# 탄 종류에서 분기
				if ($special & 0x2) {
					# 육지 파괴탄
					my $seaflagLD = 1;
					if ($tL == $HlandMountain) {
						# 산(황무지가 됨)
						logMsLDMountain($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});

						# 황무지가 됨
						$tLand->[$tx][$ty] = $HlandWaste;
						$tLandValue->[$tx][$ty] = 0;
						$HlandMove[$target][$tx][$ty] = 1;
						next;

					} elsif ($tL == $HlandComplex) {
						# 복합 지형
						my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($tLv);
						if(!(defined $HcomplexAfter[$cKind]->{'attack'}[0])) {
							# 공격후의 지형이 설정됨되어 있지 않이 경우, 황무지가 됨
							logMsLDMountain($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});

							# 황무지가 됨
							$tLand->[$tx][$ty] = $HlandWaste;
							$tLandValue->[$tx][$ty] = 0;
							$HlandMove[$target][$tx][$ty] = 1;
							next;
						}
						# 기타
						logMsLDLand($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});

					} elsif ($tL == $HlandSbase) {
						# 해저 기지
						$seaflagLD = 0; # 바다가 됨
						logMsLDSbase($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});

					} elsif ($tL == $HlandSeaMine) {
						# 기뢰
						$seaflagLD = 0; # 바다가 됨
						logMsSeaMine($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});

					} elsif ($tL == $HlandMonster) {
						# 괴수
						my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($tLv);
						if($amityFlag{$mId}) { #무해화
							if(random(100) < $HmissileSafetyInvalidp) {
								# 일정 확률로 오폭
								push(@pointErr, { 'SS' => $tPoint });
							} else {
								push(@pointErr, { 'SZ' => $tPoint });
								next;
							}
						}
						if ($mFlag & 2) {
							# 바다에 있는
							$seaflagLD = 0; # 바다가 됨
							logMsLDMonsterSea($id, $target, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
						} else {
							# 육에 있는
							logMsLDMonster($id, $target, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
						}
					} elsif ($tL == $HlandHugeMonster) {
						# 거대괴수
						my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($tLv);
						if($amityFlag{$mId}) { #무해화
							if(random(100) < $HmissileSafetyInvalidp) {
								# 일정 확률로 오폭
								push(@pointErr, { 'SS' => $tPoint });
							} else {
								push(@pointErr, { 'SZ' => $tPoint });
								next;
							}
						}
						my $deflag = 0;
						if($mHflag == 0) {
							my($i, $sx, $sy, $flag);

							foreach $i (1..6) {
								next if($HhugeMonsterImage[$mKind][$i] eq '');
								$sx = $tx + $ax[$i];
								$sy = $ty + $ay[$i];
								# 행 기준 위치 조정
								$sx-- if(!($sy % 2) && ($ty % 2));
								$sx = $correctX[$sx + $#an];
								$sy = $correctY[$sy + $#an];
								# 범위 밖
								next if(($sx < 0) || ($sy < 0));

								next if($tLand->[$sx][$sy] != $HlandHugeMonster);
								my($mId2, $mHflag2, $mSea2, $mExp2, $mFlag2, $mKind2, $mHp2) = monsterUnpack($tLandValue->[$sx][$sy]);
								next if($mHflag2 != $i);
								# 코어의 주변이남겨 둔 것 경우 공격무효
								if($HhugeMonsterSpecial[$mKind] & 0x10000) {
									$deflag = 1;
									push(@pointErr, { 'DF' => $tPoint });
									last;
								} elsif ($mFlag2 & 2) {
									$tLand->[$sx][$sy] = $HlandSea;
									$tLandValue->[$sx][$sy] = $mSea2;
									$HlandMove[$target][$tx][$ty] = 1;
								} else {
									$tLand->[$sx][$sy] = $HlandWaste;
									$tLandValue->[$sx][$sy] = 1;
									$HlandMove[$target][$tx][$ty] = 1;
								}
							}
						}
						next if($deflag);
						if ($mFlag & 2) {
							# 바다에 있는
							logMsLDMonsterSea($id, $target, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
							$seaflagLD = 0; # 바다가 됨
						} else {
							# 육에 있는
							logMsLDMonster($id, $target, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
						}
					} elsif ($tL == $HlandNavy) {
						# 해군
						my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($tLv);
						if($amityFlag{$nId} && !($nFlag & 1)) { #무해화
							if(random(100) < $HmissileSafetyInvalidp) {
								# 일정 확률로 오폭
								push(@pointErr, { 'SS' => $tPoint });
							} else {
								push(@pointErr, { 'SZ' => $tPoint });
								next;
							}
						}
						my $n = $HidToNumber{$nId};
						my $nSpecial = $HnavySpecial[$nKind];
						$island->{'ext'}[10]++;
						$tLname = landName($tL, $tLv);
						if(defined $n) {
							$Hislands[$n]->{'shipk'}[$nKind]--;
							# 서바이벌
							$Hislands[$n]->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
						}
						if ($nSpecial & 0x8) {
							# 항구
							logMsLDNavy($id, $target, $nId, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
							$tIsland->{'navyPort'}--;
						} else {
							# 함정
							if ($nFlag & 2) {
								# 잠수
								logMsLDNavySea2($id, $target, $nId, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
							} else {
								# 수상
								logMsLDNavySea($id, $target, $nId, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
							}
							if(defined $n) {
								$Hislands[$n]->{'ships'}[$nNo]--;
								$Hislands[$n]->{'ships'}[4]--;
								$HnavyAttackTarget{"$id,$tx,$ty"} = undef;
							}
							$seaflagLD = 0; # 바다가 됨
						}
					} elsif ($tL == $HlandSea) {
						# 얕은 바다
						$seaflagLD = 0; # 바다가 됨
						logMsLDSea1($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});

					} elsif ($tL == $HlandCore) {
						# 코어
						my($lFlag, $lLv) = (int($tLv / 10000), ($tLv % 10000));
						$tIsland->{'core'}--;
						$tIsland->{'slaughterer2'} = $id if($HcorelessDead && !$tIsland->{'core'}); # 파괴한 섬 ID를 기록
						if(!$lFlag) {
							logMsLDLand($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
						} else {
							$seaflagLD = 0; # 바다가 됨
							logMsLDSea1($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
						}

					} else {
						# 기타
						logMsLDLand($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});

						# 경험치
						if ($tL == $HlandTown) {
							if (($bKind == $HlandBase) || ($bKind == $HlandSbase)) {
								# 아직 기지인 경우만
								$bLv += int($tLv / 20);
								$bLv = $HmaxExpPoint if ($bLv> $HmaxExpPoint);
								$landValue->[$bx][$by] = $bLv;
								$tIsland->{'slaughterer'} = $id;
							}
						} elsif ($tL == $HlandOil) {
							$seaflagLD = 0; # 바다가 됨
						}
					}

					# 얕은 바다가 됨
					$tLand->[$tx][$ty] = $HlandSea;
					$tIsland->{'area'}--;
					$tLandValue->[$tx][$ty] = $seaflagLD;
					# 유전이라면, 얕은 바다, 해저 기지, 기뢰였으면 바다
					$HlandMove[$target][$tx][$ty] = 1;
				} else {
					# 기타 미사일
					if ($tL == $HlandWaste) {
						# 황무지(피해없음)
						push(@pointErr, { 'ND' => $tPoint });
					} elsif ($tL == $HlandSeaMine) {
						# 기뢰
						logMsSeaMine($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
					} elsif ($tL == $HlandMonster) {
						# 괴수
						my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($tLv);
						if($amityFlag{$mId}) { #무해화
							if(random(100) < $HmissileSafetyInvalidp) {
								# 일정 확률로 오폭
								push(@pointErr, { 'SS' => $tPoint });
							} else {
								push(@pointErr, { 'SZ' => $tPoint });
								next;
							}
						}
						my $mName = landName($tL, $tLv);

						# 잠수안?
						if(($mFlag & 2) && !($special & 0x20)) {
							# 잠수안
							push(@pointErr, { 'MS' => $tPoint });
							next;
						}

						# 경화 중?
						if(($mFlag & 1) && !($special & 0x10)) {
							# 경화 중
							push(@pointErr, { 'MH' => $tPoint });
							next;
						} else {
							# 경화 중이 아님
							$damageId{$mId} = 1 if($mId && ($mId != $id) && ($mId != $target));
							if ($mHp <= $damage) {
								# 괴수를 처치했습니다
								if (($bKind == $HlandBase) || ($bKind == $HlandSbase)) {
									# 경험치
									$bLv += $HmonsterExp[$mKind];
									$island->{'gain'} += $HmonsterExp[$mKind];
									$bLv = $HmaxExpPoint if ($bLv> $HmaxExpPoint);
									$landValue->[$bx][$by] = $bLv;
								}

								logMsMonKill($id, $target, $mId, $name, $tName, $comName, $mName, $point, $tPoint, $STcheck{$kind});
								$HlandMove[$target][$tx][$ty] = 1;

								# 수입
								my($value) = $HmonsterValue[$mKind];
								if ($value> 0) {
									$tIsland->{'money'} += $value;
									logMsMonMoney($id, $target, $mName, $value, $STcheck{$kind});
								}

								# 수상 관계
								my($prize) = $island->{'prize'};
								$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
								my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
								my($v) = 2 ** $mKind;
								$monsters |= $v;
								$island->{'prize'} = "$flags,$monsters,$hmonsters,$turns";
								# 괴수퇴치 수
								$island->{'monsterkill'}++;

							} else {
								# 괴수살아하고 있는
								logMsMonster($id, $target, $mId, $name, $tName, $comName, $mName, $point, $tPoint, $STcheck{$kind});

								# HP가 1 감소
								$tLandValue->[$tx][$ty] -= $damage;
								next;
							}
						}
						# 체의 일부가 삭제 가능
						if ($mFlag & 2) {
							# 바다에있었음
							$tLand->[$tx][$ty] = $HlandSea;
							$tLandValue->[$tx][$ty] = $mSea;
						} else {
							# 육지에있었음
							$tLand->[$tx][$ty] = $HlandWaste;
							$tLandValue->[$tx][$ty] = 1;
						}
						$HlandMove[$target][$tx][$ty] = 1;
						next;
					} elsif ($tL == $HlandHugeMonster) {
						# 거대괴수
						my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($tLv);
						if($amityFlag{$mId}) { #무해화
							if(random(100) < $HmissileSafetyInvalidp) {
								# 일정 확률로 오폭
								push(@pointErr, { 'SS' => $tPoint });
							} else {
								push(@pointErr, { 'SZ' => $tPoint });
								next;
							}
						}
						my $mName = landName($tL, $tLv);

# 코어 이외에 대한 미사일 공격도 유효합니다. 무효인 경우 코멘트를 표시하지 않습니다.(코어 방위 능력을 갖게 한 경우 매우 위험합니다(^^;;;)
#						if($mHflag != 0) {
#							push(@pointErr, { 'ND' => $tPoint });
#							next;
#						}

# 바다에 있는 경우도 미사일이 유효합니다. 무효인 경우 코멘트를 표시하지 않습니다.
						# 잠수안?
						if(($mFlag & 2) && !($special & 0x20)) {
							# 잠수안
							push(@pointErr, { 'MS' => $tPoint });
							next;
						}

						# 경화 중?
						if(($mFlag & 1) && !($special & 0x10)) {
							# 경화 중
							push(@pointErr, { 'MH' => $tPoint });
							next;
						} else {
							# 경화 중이 아님
							$damageId{$mId} = 1 if($mId && ($mId != $id) && ($mId != $target));
							if(($mHp <= $damage) && ($mHflag == 0)) {
								# 괴수를 처치했습니다
								my($i, $sx, $sy, $flag);
								my $deflag = 0;

								foreach $i (0..6) {
									next if($HhugeMonsterImage[$mKind][$i] eq '');
									$sx = $tx + $ax[$i];
									$sy = $ty + $ay[$i];
									# 행 기준 위치 조정
									$sx-- if(!($sy % 2) && ($ty % 2));
									$sx = $correctX[$sx + $#an];
									$sy = $correctY[$sy + $#an];
									# 범위 밖
									next if(($sx < 0) || ($sy < 0));

									next if($tLand->[$sx][$sy] != $HlandHugeMonster);
									my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($tLandValue->[$sx][$sy]))[1, 2, 4];
									next if($mHflag2 != $i);
									# 코어의 주변이남겨 둔 것 경우 공격무효
									if($HhugeMonsterSpecial[$mKind] & 0x10000) {
										$deflag = 1;
										push(@pointErr, { 'DF' => $tPoint });
										last;
									} elsif ($mFlag2 & 2) {
										$tLand->[$sx][$sy] = $HlandSea;
										$tLandValue->[$sx][$sy] = $mSea2;
									} else {
										$tLand->[$sx][$sy] = $HlandWaste;
										$tLandValue->[$sx][$sy] = 1;
									}
									$HlandMove[$target][$sx][$sy] = 1;
								}
								next if($deflag);
								if (($bKind == $HlandBase) || ($bKind == $HlandSbase)) {
									# 경험치
									$bLv += $HhugeMonsterExp[$mKind];
									$island->{'gain'} += $HhugeMonsterExp[$mKind];
									$bLv = $HmaxExpPoint if ($bLv> $HmaxExpPoint);
									$landValue->[$bx][$by] = $bLv;
								}

								logMsMonKill($id, $target, $mId, $name, $tName, $comName, $mName, $point, $tPoint, $STcheck{$kind});
								$HlandMove[$target][$tx][$ty] = 1;

								my($value) = $HhugeMonsterValue[$mKind];
								if ($value> 0) {
									$tIsland->{'money'} += $value;
									logMsMonMoney($id, $target, $mName, $value, $STcheck{$kind});
								}

								# 수상 관계
								my($prize) = $island->{'prize'};
								$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
								my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
								my($v) = 2 ** $mKind;
								$hmonsters |= $v;
								$island->{'prize'} = "$flags,$monsters,$hmonsters,$turns";
								# 괴수퇴치 수
								$island->{'monsterkill'}++;
								next;

							} else {
								# 괴수살아하고 있는
								my($i, $sx, $sy, $flag);
								my $deflag = 0;
								foreach $i (0..6) {
									next if($HhugeMonsterImage[$mKind][$i] eq '');
									$sx = $tx + $ax[$i];
									$sy = $ty + $ay[$i];
									# 행 기준 위치 조정
									$sx-- if(!($sy % 2) && ($ty % 2));
									$sx = $correctX[$sx + $#an];
									$sy = $correctY[$sy + $#an];
									# 범위 밖
									next if(($sx < 0) || ($sy < 0));

									next if($tLand->[$sx][$sy] != $HlandHugeMonster);
									my($mId2, $mHflag2, $mSea2, $mExp2, $mFlag2, $mKind2, $mHp2) = monsterUnpack($tLandValue->[$sx][$sy]);
									my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($tLandValue->[$sx][$sy]))[1, 2, 4];
									next if($mHflag2 != $i);
									# 코어의 주변이남겨 둔 것 경우 공격무효
									if($HhugeMonsterSpecial[$mKind] & 0x10000) {
										$deflag = 1;
										push(@pointErr, { 'DF' => $tPoint });
										last;
									}
								}
								next if($deflag);
								# HP가 1 감소
								$mHp -= $damage;
								logMsMonster($id, $target, $mId, $name, $tName, $comName, $mName, $point, $tPoint, $STcheck{$kind});
								if($mHp> 0) {
									# 괴수살아하고 있는
									$tLandValue->[$tx][$ty] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
									next;
								}
							}
							# 체의 일부가 삭제 가능
							if ($mFlag & 2) {
								# 바다에있었음
								$tLand->[$tx][$ty] = $HlandSea;
								$tLandValue->[$tx][$ty] = $mSea;
							} else {
								# 육지에있었음
								$tLand->[$tx][$ty] = $HlandWaste;
								$tLandValue->[$tx][$ty] = 1;
							}
							$HlandMove[$target][$tx][$ty] = 1;
							next;
						}
					} elsif ($tL == $HlandNavy) {
						# 해군
						my($nId, $nTmp, $nStat, $nSea, $nExp, $nFlag, $nNo, $nKind, $nHp) = navyUnpack($tLv);
						my $n = $HidToNumber{$nId};
						my $nSpecial = $HnavySpecial[$nKind];
						my $nName = landName($tL, $tLv);

						# 잠수안?
						if(($nFlag & 2) && !($special & 0x20)) {
							# 잠수안
							push(@pointErr, { 'FS' => $tPoint });
							next;
						}

						# 잔해?
						if ($nFlag & 1) {
							# 잔해
							logMsNavyWreckDestroy($id, $target, $name, $tName, $comName, $nName, $point, $tPoint, $STcheck{$kind});

							# 바다가 됨
							$tLand->[$tx][$ty] = $HlandSea;
							$tLandValue->[$tx][$ty] = 0;
							$HlandMove[$target][$tx][$ty] = 1;
							next;
						}

						if($amityFlag{$nId}) { #무해화
							if(random(100) < $HmissileSafetyInvalidp) {
								# 일정 확률로 오폭
								push(@pointErr, { 'SS' => $tPoint });
							} else {
								push(@pointErr, { 'SZ' => $tPoint });
								next;
							}
						}

						$damageId{$nId} = 1 if($nId && ($nId != $id) && ($nId != $target));
						if ($nHp <= $damage) {
							# 격침
							if (($bKind == $HlandBase) || ($bKind == $HlandSbase)) {
								# 경험치
								$bLv += $HnavyExp[$nKind];
								$island->{'gain'} += $HnavyExp[$nKind];
								$bLv = $HmaxExpPoint if ($bLv> $HmaxExpPoint);
								$landValue->[$bx][$by] = $bLv;
							}
							$island->{'ext'}[10]++;
							if($nId != $id) {
								$island->{'sink'}[$nKind]++;
							} else {
								$island->{'sinkself'}[$nKind]++;
							}
							if(defined $n) {
								$Hislands[$n]->{'shipk'}[$nKind]--;
								# 서바이벌
								$Hislands[$n]->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
							}
							if ($nSpecial & 0x8) {
								# 군항괴멸
								logMsNavyPortDestroy($id, $target, $name, $tName, $comName, $nName, $point, $tPoint, $STcheck{$kind});

								# 얕은 바다가 됨
								$tLand->[$tx][$ty] = $HlandSea;
								$tLandValue->[$tx][$ty] = 1;
								$HlandMove[$target][$tx][$ty] = 1;
								$Hislands[$n]->{'navyPort'}-- if(defined $n);
							} else {
								# 함정격침
								logMsNavyShipDestroy($id, $target, $nId, $name, $tName, $comName, $nName, $point, $tPoint, $STcheck{$kind});

								if (rand(100) < $HnavyProbWreck[$nKind]) {
									# 잔해가 됨
									$tLandValue->[$tx][$ty] = navyPack(0, $nTmp, $nStat, $nSea, int(rand(90)) + 10, 1, 0, $nKind, 0);
								} else {
									# 바다가 됨
									$tLand->[$tx][$ty] = $HlandSea;
									$tLandValue->[$tx][$ty] = 0;
									$HlandMove[$target][$tx][$ty] = 1;
									$HnavyAttackTarget{"$id,$tx,$ty"} = undef;
								}
								if(defined $n) {
									$Hislands[$n]->{'ships'}[$nNo]--;
									$Hislands[$n]->{'ships'}[4]--;
								}
							}
							next;
						} else {
							# 피격
							logMsNavyDamage($id, $target, $nId, $name, $tName, $comName, $nName, $point, $tPoint, $STcheck{$kind});

							# HP가 1 감소
							$tLandValue->[$tx][$ty] -= $damage;
							next;
						}
					} elsif (($tL == $HlandDefence) && ($tLv>= 0)) {
						# 방위 시설(내구력이남겨 둔 것)
						logMsDefence($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
					} elsif ($tL == $HlandCore) {
						# 코어
						my($lFlag, $lLv) = (int($tLv / 10000), ($tLv % 10000));
						if(($lFlag == 2) && !($special & 0x20)) {
							# 해저시설은 바다인 척
							push(@pointErr, { 'ND' => $tPoint });
							next;
						}
						# 내구력을 높이기
						my $coreflag = $lLv - $damage;
						$tLv -= $damage;
						if($coreflag>= 0) {
							$tLand->[$tx][$ty] = $HlandCore;
							$tLandValue->[$tx][$ty] = $tLv;
							logMsDefence($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
						} else {
							$tIsland->{'core'}--;
							$tIsland->{'slaughterer2'} = $id if($HcorelessDead && !$tIsland->{'core'}); # 파괴한 섬 ID를 기록
							if(!$lFlag) {
								$tLand->[$tx][$ty] = $HlandWaste;
								$tLandValue->[$tx][$ty] = 1; # 착탄 지점
								logMsNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
							} else {
								$tLand->[$tx][$ty] = $HlandSea;
								$tLandValue->[$tx][$ty] = 2 - $lFlag;
								logMsNavyWreckDestroy($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
							}
							$HlandMove[$target][$tx][$ty] = 1;
						}
						next;
					} elsif ($tL == $HlandComplex) {
						# 복합 지형
						my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($tLv);
						if(!(defined $HcomplexAfter[$cKind]->{'attack'}[0])) {
							push(@pointErr, { 'ND' => $tPoint });
							next;
						}
						if($HcomplexAfter[$cKind]->{'stepdown'}) {
							$cFood -= $damage * $HcomplexAfter[$cKind]->{'stepdown'};
							$cMoney -= $damage * $HcomplexAfter[$cKind]->{'stepdown'};
							if($cFood>= 0 || $cMoney>= 0) {
								$cFood = 0 if($cFood < 0);
								$cMoney = 0 if($cMoney < 0);
								$tLandValue->[$tx][$ty] = landPack($cTmp, $cKind, $cTurn, $cFood, $cMoney);
								logMsDefence($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
								next;
							}
						}
						# 공격후의 지형로
						# 복합 지형이면 설정 지형
						$tLand->[$tx][$ty] = $HcomplexAfter[$cKind]->{'attack'}[0];
						$tLandValue->[$tx][$ty] = $HcomplexAfter[$cKind]->{'attack'}[1];
						$island->{'complex'}[$cKind]--;
						$HlandMove[$target][$tx][$ty] = 1;
						logMsNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
						next;
					} elsif ($tL == $HlandTown) {
						# 도시계
						my $sLv = 0;
						my $rank = 0;
						if($HtownStepDown) {
							foreach (reverse(0..$#HlandTownValue)) {
								if($HlandTownValue[$_] <= $tLv) {
									$rank = $_;
									last;
								}
							}
							$rank -= $damage;
							$rank = 0 if($rank < 0);
							$sLv = $HlandTownValue[$rank];
						}
						if (($bKind == $HlandBase) || ($bKind == $HlandSbase)) {
							# 경험치
							$bLv += int(($tLv - $sLv) / 20);
							$bLv = $HmaxExpPoint if ($bLv> $HmaxExpPoint);
							$landValue->[$bx][$by] = $bLv;
						}
						$boat += ($tLv - $sLv); # 난민에플러스
						if($rank) {
							$tLandValue->[$tx][$ty] = $sLv;
							logMsNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $HlandTownName[$rank], $STcheck{$kind});
						} else {
							$tIsland->{'slaughterer'} = $id; # 도시계를 파괴한 섬 ID를 기록
							logMsNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
							$tLand->[$tx][$ty] = $HlandWaste;
							$tLandValue->[$tx][$ty] = 1; # 착탄 지점
							$HlandMove[$target][$tx][$ty] = 1;
						}
						next;
					} else {
						# 일반 지형
						logMsNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $STcheck{$kind});
						$island->{'ext'}[3]++ if (!$STcheck{$kind} && $tL == $HlandBase); # 격파했습니다 미사일 기지의 수
					}

					if (($tL == $HlandOil) ||
						($tL == $HlandSbase) ||
						($tL == $HlandSeaMine)) {
						# 유전이라면, 해저 기지, 기뢰였으면 바다
						$tLand->[$tx][$ty] = $HlandSea;
						$tLandValue->[$tx][$ty] = 0;
						$HlandMove[$target][$tx][$ty] = 1;
					} elsif($tL == $HlandBouha) {
						# 방파제라면 얕은 바다
						$tLand->[$tx][$ty] = $HlandSea;
						$tLandValue->[$tx][$ty] = 1;
						$HlandMove[$target][$tx][$ty] = 1;
					} elsif(($tL == $HlandDefence) && ($tLv>= 0)) {
						# 내구력이 남은 방위시설이라면 내구 가능
						$tLand->[$tx][$ty] = $HlandDefence;
						$tLandValue->[$tx][$ty] = $tLv;
					} else {
						# 황무지가 됨
						$tLand->[$tx][$ty] = $HlandWaste;
						$tLandValue->[$tx][$ty] = 1; # 착탄 지점
						$HlandMove[$target][$tx][$ty] = 1;
					}
				}
			} # foreach
		} # while 기지내에서 루프

		# 카운트 증가
		$count++;
	}

	unless ($flagbase) {
		# 기지가 하나도 없어진 경우
		logMsNoBase($id, $name, $comName);
		return 0;
	}

	if($fire) {
		my $l;
		my @pKey = ('OB', 'DF', 'ND', 'MS', 'MH', 'FS', 'SZ', 'SS');
		my @pName = ('권역외', '방위', '무효', '괴수 잠수', '경화', '함잠수', '무해', '오폭');
		my $str = '';
		my $pntStr = '<BR>--- ';
		my @cntErr = (0, 0, 0, 0, 0, 0, 0, 0, 0);
		foreach $l (0..7) {
			my $pflag = 1;
			my @pointOut = ();
			my $p;
			foreach $p (@pointErr) {
				my $pnt = $p->{$pKey[$l]};
				next if($pnt eq '');
				$cntErr[$l]++;
				$cntErr[8]++;
				foreach (@pointOut) {
					$pflag = 0 if($_ eq $pnt);
				}
				push(@pointOut, $pnt) if($pflag);
			}
			if($cntErr[$l]) {
				$str.= " $pName[$l]\:". $cntErr[$l];
				$pntStr.= "$pName[$l] ⇒ ". join(',', @pointOut). " " if($l);
			}
		}
		$pntStr = '' if(!$cntErr[8] || ($cntErr[8] == $cntErr[0]));
		$pntStr.= '[유폭 중심 ⇒ '. join(',', @terrorPnt).']' if(@terrorPnt);
		$str = '(명중:'. ($fire - $cntErr[8]). $str.')';
		$str.= '[파괴력:'. $damage. ']' if($damage> 1);
		logMsMatome($id, $target, $name, $tName, $comName, $point, $tLandName, $str, $pntStr, join('-', (keys %damageId)), $STcheck{$kind});
	}
	# 난민판정
	$boat = int($boat / 2) if(!$HsurvivalTurn);
	if(($boat> 0) && ($id != $target) && !($STcheck{$kind})) {
		# 난민표착
		my($achive) = boatAchive($island, $boat); # 도달난민

		if ($achive> 0) {
			# 조금이라도 도착한 경우 로그를 출력
			logMsBoatPeople($id, $name, $achive);
			$island->{'ext'}[4] += int($achive); # 구출한 난민의 합계인구

			# 난민의 수가일정수이상라면, 평화상의 가능성있음
			if ($achive>= 200) {
				$island->{'achive'} += $achive;
			}
		}
	}

	return 1;
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
# 사거리 안에 괴수 없음
sub logNoTarget {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 사거리 안에 괴수가 없었기 때문에 중지되었습니다.",$id);
}

# 육지 파괴탄, 산에 명중
sub logMsLDMountain {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 사라지고, 황무지가 되었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 육지 파괴탄, 해저 기지에 명중
sub logMsLDSbase {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}에 착탄한 뒤 폭발, 같은 지점에 있던<B>$tLname</B>은 흔적도 없이 날아갔습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 육지 파괴탄, 괴수에 명중
sub logMsLDMonster {
	my($id, $tId, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}에 착탄해 폭발. 육지는<B>$tLname</B>째로 수몰되었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $mId);
	} else {
		logOut($logstr, $tId, $id, $mId);
	}
}

# 육지 파괴탄, 괴수에 명중(바다)
sub logMsLDMonsterSea {
	my($id, $tId, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}에 착탄한 뒤 폭발. 동일지점에있었음<B>$tLname</B>은 흔적도 없이 날아갔습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $mId);
	} else {
		logOut($logstr, $tId, $id, $mId);
	}
}

# 육지 파괴탄, 거대괴수에 명중
sub logMsLDHugeMonster {
	my($id, $tId, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}에 착탄해 폭발. 육지는<B>$tLname</B>의 일부째로 수몰되었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $mId);
	} else {
		logOut($logstr, $tId, $id, $mId);
	}
}

# 육지 파괴탄, 거대괴수에 명중(바다)
sub logMsLDHugeMonsterSea {
	my($id, $tId, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}에 착탄한 뒤 폭발. 동일지점에있었음<B>$tLname</B>의 일부는 흔적도 없이 날아갔습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $mId);
	} else {
		logOut($logstr, $tId, $id, $mId);
	}
}

# 육지 파괴탄, 해군에 명중
sub logMsLDNavy {
	my($id, $tId, $nId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}에 착탄해 폭발. 육지는<B>$tLname</B>째로 수몰되었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $nId);
	} else {
		logOut($logstr, $tId, $id, $nId);
	}
}

# 육지 파괴탄, 해군에 명중(해상)
sub logMsLDNavySea {
	my($id, $tId, $nId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}에 착탄. 동일지점을 항해 중이던<B>$tLname</B>은 흔적도 없이 날아갔습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $nId);
	} else {
		logOut($logstr, $tId, $id, $nId);
	}
}

# 육지 파괴탄, 해군에 명중(바다안)
sub logMsLDNavySea2 {
	my($id, $tId, $nId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}에 착탄한 뒤 폭발. 동일지점에서 잠수항해하고 있었음<B>$tLname</B>은 흔적도 없이 날아갔습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $nId);
	} else {
		logOut($logstr, $tId, $id, $nId);
	}
}

# 육지 파괴탄, 얕은 바다에 명중
sub logMsLDSea1 {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 해저가 깎였습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 육지 파괴탄, 기타의 지형에 명중
sub logMsLDLand {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 육지가 수몰되었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 미사일, 기뢰에 명중
sub logMsSeaMine {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 사라졌습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 일반 미사일, 괴수에 명중, 피해
sub logMsMonster {
	my($id, $tId, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 고통스러운 듯 포효했습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $mId);
	} else {
		logOut($logstr, $tId, $id, $mId);
	}
}

# 일반 미사일, 괴수에 명중, 살상
sub logMsMonKill {
	my($id, $tId, $mId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 힘이 다해 쓰러졌습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $mId);
	} else {
		logOut($logstr, $tId, $id, $mId);
	}
}

# 일반 미사일, 군항에 명중, 괴멸
sub logMsNavyPortDestroy {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 괴멸되었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 일반 미사일, 함정에 명중, 피해
sub logMsNavyDamage {
	my($id, $tId, $nId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 검은 연기를 내뿜었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $nId);
	} else {
		logOut($logstr, $tId, $id, $nId);
	}
}

# 일반 미사일, 함정에 명중, 격침
sub logMsNavyShipDestroy {
	my($id, $tId, $nId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은<span class='attention'>침몰</span>했습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId, $nId);
	} else {
		logOut($logstr, $tId, $id, $nId);
	}
}

# 일반 미사일, 잔해에 명중, 바다에 가라앉은 잔해
sub logMsNavyWreckDestroy {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 잔해가 되어 바다에 가라앉았습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 일반 미사일 방어 시설에 명중
sub logMsDefence {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 피해를 받았습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 일반 미사일 일반 지형에 명중
sub logMsNormal {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 일반 미사일 도시계에 명중
sub logMsNormalTown {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $sName, $st) = @_;
	my($logstr) = " --- ${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중,<B>$sName</B>이 되었습니다.";
	if($st) {
		logSecret($logstr, $id);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId, $id);
	}
}

# 괴수의 시체
sub logMsMonMoney {
	my($id, $tId, $mName, $value, $st) = @_;
	my($logstr) = " --- <B>$mName</B>의 잔해에는,<B>$value$HunitMoney</B>의 가치가 있었습니다.";
	if($st) {
		logSecret($logstr, $id) if($id == $tId);
		logLate($logstr, $tId);
	} else {
		logOut($logstr, $tId);
	}
}

# 미사일 발사를 시도했지만 기지가 없음
sub logMsNoBase {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은,<B>미사일 설비가 없어</B> 실행할 수 없었습니다.",$id);

}

# 미사일(정리메)
sub logMsMatome {
	my($id, $tId, $name, $tName, $comName, $point, $tLname, $str, $pntStr, $nId, $st) = @_;
	if($st) {
		logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했습니다.${str}${pntStr}",$id);
		logLate("<B>누군가</B>가${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했습니다.${str}${pntStr}",$tId, $nId);
	} else {
		logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했습니다.${str}${pntStr}", $tId, $id, $nId);
	}
}

1;
