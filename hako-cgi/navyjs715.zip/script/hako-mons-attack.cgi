#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 모형정원 바다전쟁 JS ver7.xx
# 턴진행보조모듈(ver1.00)
# 괴수의 능력 미사일 공격
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------

# 괴수의 미사일 공격 목표를 탐색
sub searchMonsterTarget {
	my($island, $x, $y, $huge) = @_;

	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($lv) = $landValue->[$x][$y];

	# 각 요소 꺼내기
	my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($landValue->[$x][$y]);
	my $mName = landName($land->[$x][$y], $landValue->[$x][$y]);
	my $special = ($huge) ? $HhugeMonsterSpecial[$mKind] : $HmonsterSpecial[$mKind];

	return unless($special & 0x100);

	# 난민의 수
	my($boat) = 0;

	my $rtemp = ($huge) ? $HhugeMonsterFireRange[$mKind] : $HmonsterFireRange[$mKind];
	my $range = $an[$rtemp];

	# 범위 안의 목표 지형을 탐색
	my($i, $sx, $sy, $kind, $tId, $tLv, $tFlag);
	# 순서결메
	my $rang = $range - 2;
	my(@order) = randomArray($rang);
	foreach $i (0..$rang) {
		my $j = $order[$i] + 1;
		$sx = $x + $ax[$j];
		$sy = $y + $ay[$j];
		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		$sx = $correctX[$sx + $#an];
		$sy = $correctY[$sy + $#an];

		# 범위 밖의 경우
		next if(($sx < 0) || ($sy < 0));

		# 범위 안의 경우
		$tKind = $land->[$sx][$sy];
		$tLv = $landValue->[$sx][$sy];

		my $target = { x => $sx, y => $sy };

		if ($mFlag & 1) {
			# 경화 중라면, 아무것도 하지 않음
		} elsif ($mFlag & 2) {
			# 경화 중에서 없이, 바다에있었음
			# 대잠, 대함 공격
			if ($tKind == $HlandNavy) {
				# 해군
				($tId, $tFlag) = (navyUnpack($tLv))[0, 5];
				if (($mId != $tId) && !($tFlag & 1)) {
					# 해당 함정에서는 잔해 이외 없음
					# 공격 목표 설정
					$HmonsterAttackTarget{"$id,$x,$y"} = $target;
					last;
				}
			} elsif (($tKind == $HlandSbase) || # 해저 기지
				($tKind == $HlandOil)) { # 해저 유전
				if ($id != $mId) {
					# 해당 시설에서는 없음
					# 공격 목표 설정
					$HmonsterAttackTarget{"$id,$x,$y"} = $target;
					last;
				}
			} elsif($tKind == $HlandComplex) { # 복합 지형
				if ($id != $mId) {
					# 해당 시설에서는 없음
					my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($tLv);
					next if(!($HcomplexAttr[$cKind] & 0x100)); # 대잠
					if($HcomplexFPplus[$cKind] * $HcomplexFPCmax[$cKind] + $HcomplexFPbase[$cKind] || $HcomplexMPplus[$cKind] * $HcomplexMPCmax[$cKind] + $HcomplexMPbase[$cKind]) {
						# 공격 목표 설정
						$HmonsterAttackTarget{"$id,$x,$y"} = $target;
						last;
					}
				}
			} elsif (($tKind == $HlandMonster) || ($tKind == $HlandHugeMonster)) {
				# 괴수
				($tId, $tFlag) = (monsterUnpack($tLv))[0, 4];
				if (($mId != $tId) && !($tFlag & 1) && ($tFlag & 2)) {
					# 경화 중에서 없이, 바다에 있는
					# 공격 목표 설정
					$HmonsterAttackTarget{"$id,$x,$y"} = $target;
					last;
				}
			}
		} elsif (!($mFlag & 2)) {
			# 육에있었음
			# 대함 공격
			if ($tKind == $HlandNavy) {
				# 해군
				($tId, $tFlag) = (navyUnpack($tLv))[0, 5];
				if (($mId != $tId) && !($tFlag & 2) && !($tFlag & 1)) {
					# 해당 함정에서는 없음부상안의 잔해이외
					# 공격 목표 설정
					$HmonsterAttackTarget{"$id,$x,$y"} = $target;
					last;
				}

			# 대지 공격
			} elsif (($tKind == $HlandTown) || # 마을 계열
				($tKind == $HlandForest) || # 숲
				($tKind == $HlandFarm) || # 농장
				($tKind == $HlandFactory) || # 공장
				($tKind == $HlandBase) || # 미사일 기지
				($tKind == $HlandDefence) || # 방위 시설
				($tKind == $HlandMonument) || # 기념비
				($tKind == $HlandHaribote)) { # 가짜 시설
				if ($id != $mId) {
					# 해당 시설에서는 없음
					# 공격 목표 설정
					$HmonsterAttackTarget{"$id,$x,$y"} = $target;
					last;
				}

			} elsif($tKind == $HlandComplex) { # 복합 지형
				if ($id != $mId) {
					# 해당 시설에서는 없음
					my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($tLv);
					next if(!($HcomplexAttr[$cKind] & 0x600)); # 대함·대지
					if($HcomplexFPplus[$cKind] * $HcomplexFPCmax[$cKind] + $HcomplexFPbase[$cKind] || $HcomplexMPplus[$cKind] * $HcomplexMPCmax[$cKind] + $HcomplexMPbase[$cKind]) {
						# 공격 목표 설정
						$HmonsterAttackTarget{"$id,$x,$y"} = $target;
						last;
					}
				}

			} elsif (($tKind == $HlandMonster) || ($tKind == $HlandHugeMonster)) {
				# 괴수
				($tId, $tFlag) = (monsterUnpack($tLv))[0, 4];
				if (($mId != $tId) && !($tFlag & 1) && !($tFlag & 2)) {
					# 경화 중에서 없이, 육에 있는
					# 공격 목표 설정
					$HmonsterAttackTarget{"$id,$x,$y"} = $target;
					last;
				}
			}
		}
	}
}

# 괴수의 미사일 공격
sub monsterAttack {
	my($island, $x, $y, $tx, $ty, $huge) = @_;

	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($tLandName) = landName($land->[$tx][$ty], $landValue->[$tx][$ty]);
	$tLandName = ($HlandMove[$id][$tx][$ty]) ? "${HtagName2_}${tLandName}${H_tagName2}" : "${HtagName_}${tLandName}${H_tagName}";
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];

	my($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp) = monsterUnpack($lv);
	my $mn = $HidToNumber{$mId};
	my($mIsland);
	$mIsland = $Hislands[$mn] if (defined $mn);
	my $special = ($huge) ? $HhugeMonsterSpecial[$mKind] : $HmonsterSpecial[$mKind];
	my $mName = landName($landKind, $lv);
	my $mPoint = "($x, $y)";
	my $tPoint = "($tx, $ty)";

	# 우호국 설정을 확인
	my(%amityFlag, @noDefenceIds);
	if(defined $mn) {
		if($HmonsterSafetyZone) {
			$amityFlag{$mId} = 1;
			if(($HmonsterSafetyZone == 2) && (!$HamityInvalid || !$island->{'field'})) {
				foreach (@{$mIsland->{'amity'}}) {
					$amityFlag{$_} = 1;
				}
			}
		}
		if($HdBaseSelfNoDefenceMA == 1) {
			@noDefenceIds = ($mId);
		} elsif($HdBaseSelfNoDefenceMA == 2) {
			@noDefenceIds = ($mId, @{$mIsland->{'amityBy'}});
		} elsif($HdBaseSelfNoDefenceMA == 3) {
			@noDefenceIds = ($mId, @{$mIsland->{'amity'}});
		} elsif($HdBaseSelfNoDefenceMA == 4) {
			@noDefenceIds = ($mId, @{$mIsland->{'amity'}}, @{$mIsland->{'amityBy'}});
		} else {
			@noDefenceIds = (0);
		}
	}

	# 공격 횟수
	my $rtemp = ($huge) ? $HhugeMonsterFireHex[$mKind] : $HmonsterFireHex[$mKind];
	my $err = $an[$rtemp]; # 오차
	my $mFire = ($huge) ? $HhugeMonsterFire[$mKind] : $HmonsterFire[$mKind];
	$mFire += int($mExp/$mHp) if($mHp); # 공격 횟수(경험치가 올라가 빈사 상태가 되면 증가)
	$mFire = $HmonsterFireMax if($HmonsterFireMax && ($mFire> $HmonsterFireMax));
	# 파괴력
	my $damage = ($huge) ? $HhugeMonsterDamage[$mKind] : $HmonsterDamage[$mKind];
	$damage = int($damage);
	$damage = 1 if($damage < 1);
	# 착탄 지점의 확장 분산 범위
	my $terrorhex = ($huge) ? $HhugeMonsterTerrorHex[$mKind] : $HmonsterTerrorHex[$mKind];
	my $range = 0;

	# 공격
	my($r, $xx, $yy, $fx, $fy, $fPoint, $fKind, $fLv, @pointErr, @terrorPnt);
	my(%damageId);
	my $loopflag = 0;
	my $fire = 0;
	while ($fire < $mFire) {
		last if($loopflag); # 비용 부족 또는 잔해에서 공격 종료

		# 착탄 지점 산출
		$r = int(rand($err));
		$xx = $tx + $ax[$r];
		$yy = $ty + $ay[$r];
		# 행 기준 위치 조정
		$xx-- if(!($yy % 2) && ($ty % 2));
		$xx = $correctX[$xx + $#an];
		$yy = $correctY[$yy + $#an];

		# 자폭을 하지 않은 경우
		if(!$HmonsterSelfAttack && ($xx == $x) && ($yy == $y)) {
			$r += int(1 + rand($err-1));
			$r -= $err if($r>= $err);
			$xx = $tx + $ax[$r];
			$yy = $ty + $ay[$r];
			# 행 기준 위치 조정
			$xx-- if(!($yy % 2) && ($ty % 2));
			$xx = $correctX[$xx + $#an];
			$yy = $correctY[$yy + $#an];
		}

		if($special & 0x200) {
			if (($xx < 0) || ($yy < 0)) {
				# 범위 밖의 경우, 융단 폭격하지 않음
				$range = 0;
			} else {
				push(@terrorPnt, "($xx, $yy)");
				$range = $an[$terrorhex] - 1;
			}
		}
		my(@order) = randomArray($range + 1);
		foreach my $loop (0..$range) {
			# 바다가 되면, 공격 종료(자폭을 허가한 경우, 필요)
			#return ($mId, $mExp, $mFlag, $mKind, $mHp) if($landValue->[$x][$y] == 0);
			if(($land->[$x][$y] != $HlandMonster) && ($land->[$x][$y] != $HlandHugeMonster)) {
				$loopflag = 1;
				last;
			}

			# 기존정 공격 횟수종료
			last if($fire>= $mFire);

#			# 탄약비용을 인쿠
#			if (defined $mn) {
#				$mIsland->{'money'} -= 1;
#				if ($mIsland->{'money'} < 0) {
#					# 탄약비용이 부족함
#					$mIsland->{'money'} = 0;
#					logNavyNoShell($id, $mId, $name, $mPoint, $mName);
#					$loopflag = 1;
#					last;
#				}
#			}

			$fire++;
			# 착탄 지점 산출
			$fx = $xx + $ax[$order[$loop]];
			$fy = $yy + $ay[$order[$loop]];
			# 행 기준 위치 조정
			$fx-- if(!($fy % 2) && ($yy % 2));
			$fx = $correctX[$fx + $#an];
			$fy = $correctY[$fy + $#an];

			$fPoint = "($fx, $fy)";
			if (($fx < 0) || ($fy < 0)) {
				# 범위 밖의 경우
				push(@pointErr, { 'OB' => $fPoint });
				next;
			}
			$fL = $land->[$fx][$fy];
			$fLv = $landValue->[$fx][$fy];
			$fName = landName($fL, $fLv);
			# 방위 시설 판정
			my($defence) = 0;
			# 미판정영역
			if (($fL == $HlandDefence) || countAroundComplex($island, $fx, $fy, $an[0], 0x40) ||
				countAroundNavySpecial($island, $fx, $fy, 0x20, $an[0], 0)){
				# 방위 시설에 명중
				if ($fL == $HlandDefence) { # 방위 시설에서
					if($amityFlag{$id}) { # 무해화
						if(random(100) < $HmonsterSafetyInvalidp) {
							# 일정 확률로 오폭
							push(@pointErr, { 'SS' => $fPoint });
						} else {
							push(@pointErr, { 'SZ' => $fPoint });
							next;
						}
					}
					# 방위 시설의 내구력을 높이기
					$defflag = ($fLv % 100) - $damage;
					$fLv -= $damage;
					if($defflag < 0) {
						$island->{'dbase'}--;
						$island->{'ext'}[2]++ if(defined $mn); # 파괴한 방위 시설의 수
					}
				}
			} elsif (countAroundDef($id, $island, $fx, $fy, 0x20, @noDefenceIds)) {
				# 방위 범위
				$defence = 1;
			}

			if ($defence) {
				if($mFlag & 2) {
					# 바다에 있을 시는 방어되지 않음
				} else {
					# 방어되었습니다
					push(@pointErr, { 'DF' => $fPoint });
					next;
				}
			}

			if (!($mFlag & 2)) {
				# 육지에 있을 시 효과가 없는 지형
				if (($fL == $HlandSea) || # 바다
					($fL == $HlandMountain) || # 산
					($fL == $HlandWaste) || # 황무지
					($fL == $HlandSbase)) { # 해저 기지
					push(@pointErr, { 'ND' => $fPoint });
					next;
				}
			} elsif (($mFlag & 2)) {
				# 바다에 있을 시, 효과가 없는 지형
				if(($fL == $HlandSea) || # 바다
					($fL == $HlandWaste) || # 황무지
					($fL == $HlandPlains) || # 평지
					($fL == $HlandTown) || # 마을 계열
					($fL == $HlandForest) || # 숲
					($fL == $HlandFarm) || # 농장
					($fL == $HlandFactory) || # 공장
					($fL == $HlandBase) || # 미사일 기지
					($fL == $HlandDefence) || # 방위 시설
					($fL == $HlandMountain) || # 산
					($fL == $HlandMonument) || # 기념비
					($fL == $HlandHaribote)) { # 가짜 시설
					push(@pointErr, { 'ND' => $fPoint });
					next;
				}
			}

			# 해군, 괴수, 거대괴수이외의 무해화
			if($amityFlag{$id} && $fL != $HlandNavy && $fL != $HlandMonster && $fL != $HlandHugeMonster) {
				if(random(100) < $HmonsterSafetyInvalidp) {
					# 일정 확률로 오폭
					push(@pointErr, { 'SS' => $fPoint });
				} else {
					push(@pointErr, { 'SZ' => $fPoint });
					next;
				}
			}

			# 특별한 지형
			if ($fL == $HlandComplex) { # 복합 지형
				my($cTmp, $cKind, $cTurn, $cFood, $cMoney) = landUnpack($fLv);
				$island->{'ext'}[5]++;
				# 효과가 있는 지형
				if( (($mFlag & 2) && ($HcomplexAttr[$cKind] & 0x100)) || # 바다에 있을 시(대잠, 대함)
					(!($mFlag & 2) && ($HcomplexAttr[$cKind] & 0x600)) ) { # 육지에 있을 시(대함, 대지)

					if($HcomplexAfter[$cKind]->{'stepdown'}) {
						$cFood -= $damage * $HcomplexAfter[$cKind]->{'stepdown'};
						$cMoney -= $damage * $HcomplexAfter[$cKind]->{'stepdown'};
						if($cFood>= 0 || $cMoney>= 0) {
							$cFood = 0 if($cFood < 0);
							$cMoney = 0 if($cMoney < 0);
							$landValue->[$fx][$fy] = landPack($cTmp, $cKind, $cTurn, $cFood, $cMoney);
							logNavyNormalDefence($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
							next;
						}
					}
					# 공격후의 지형로
					# 복합 지형이면 설정 지형
					$land->[$fx][$fy] = $HcomplexAfter[$cKind]->{'attack'}[0];
					$landValue->[$fx][$fy] = $HcomplexAfter[$cKind]->{'attack'}[1];
					$HlandMove[$id][$fx][$fy] = 1;

					logNavyNormal($id, $name, $mId, $mPoint, $mName, $tPoint, $fName, $fPoint);
					next;
				}
				# 효과가 없는 지형
				push(@pointErr, { 'ND' => $fPoint });
				next;
			} elsif ($fL == $HlandMonster) { # 괴수
				my($fId, $fHflag, $fSea, $fExp, $fFlag, $fKind, $fHp) = monsterUnpack($fLv);
				my $fName = $HmonsterName[$fKind];

				# 바다끼리 또는 육지끼리가 아니면 무효
				if (!($mFlag & 2) && ($fFlag & 2)) {
					push(@pointErr, { 'MS' => $fPoint });
					next;
				} elsif(($mFlag & 2) && !($fFlag & 2)) {
					# 바다에서 육에 있는 괴수를 공격할 수 없
					push(@pointErr, { 'ND' => $fPoint });
					next;
				}

				# 경화 중?
				if ($fFlag & 1) {
					push(@pointErr, { 'MH' => $fPoint });
					next;
				} else {
					# 경화 중이 아님
					if($amityFlag{$fId}) { # 무해화
						if(random(100) < $HmonsterSafetyInvalidp) {
							# 일정 확률로 오폭
							push(@pointErr, { 'SS' => $fPoint });
						} else {
							push(@pointErr, { 'SZ' => $fPoint });
							next;
						}
					}
					$damageId{$fId} = 1 if($fId && ($fId != $id) && ($fId != $mId));
					if ($fHp <= $damage) {
						# 괴수를 처치했습니다
						# 경험치
						$mExp += $HmonsterExp[$fKind]; # 괴수의 경험치는 최고에서255
						$mIsland->{'gain'} += $HmonsterExp[$mKind] if(defined $mn);
						$mExp = 250 if($mExp> 250);
						$landValue->[$x][$y] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);

						logNavyMonKill($id, $name, $mId, $mPoint, $mName, $tPoint, $fId, $fName, $fPoint);

						# 수입
#						if (defined $mn) {
#							my($value) = $HmonsterValue[$mKind];
#							if ($value> 0) {
#								$mIsland->{'money'} += $value;
#								logMsMonMoney($id, $mName, $value);
#							}

							# 수상 관계
#							my($prize) = $mIsland->{'prize'};
#							$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
#							my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
#							my($v) = 2 ** $mKind;
#							$monsters |= $v;
#							$mIsland->{'prize'} = "$flags,$monsters,$hmonsters,$turns";
							# 괴수퇴치 수
#							$mIsland->{'monsterkill'}++;
#						}

					} else {
						# 괴수살아하고 있는
						logNavyMonster($id, $name, $mId, $mPoint, $mName, $tPoint, $fId, $fName, $fPoint);
						# HP가 1 감소
						#$landValue->[$fx][$fy]--;
						$fHp -= $damage;
						if($fHp> 0) {
							$landValue->[$fx][$fy] = monsterPack($fId, $fHflag, $fSea, $fExp, $fFlag, $fKind, $fHp);
							next;
						}
					}
					if ($fFlag & 2) {
						# 바다에있었음
						$land->[$fx][$fy] = $HlandSea;
						$landValue->[$fx][$fy] = $mSea;
					} else {
						# 육지에있었음
						$land->[$fx][$fy] = $HlandWaste;
						$landValue->[$fx][$fy] = 0;
					}
					$HlandMove[$id][$fx][$fy] = 1;
					next;
				}
			} elsif ($fL == $HlandHugeMonster) { # 거대괴수
				my($fId, $fHflag, $fSea, $fExp, $fFlag, $fKind, $fHp) = monsterUnpack($fLv);
				my $fName = $HhugeMonsterName[$fKind];

				# 바다끼리 또는 육지끼리가 아니면 무효
				if (!($mFlag & 2) && ($fFlag & 2)) {
					push(@pointErr, { 'MS' => $fPoint });
					next;
				} elsif(($mFlag & 2) && !($fFlag & 2)) {
					# 바다에서 육에 있는 괴수를 공격할 수 없
					push(@pointErr, { 'ND' => $fPoint });
					next;
				}

				# 경화 중?
				if ($fFlag & 1) {
					push(@pointErr, { 'MH' => $fPoint });
					next;
				} else {
					# 경화 중이 아님
					if($amityFlag{$fId}) { # 무해화
						if(random(100) < $HmonsterSafetyInvalidp) {
							# 일정 확률로 오폭
							push(@pointErr, { 'SS' => $fPoint });
						} else {
							push(@pointErr, { 'SZ' => $fPoint });
							next;
						}
					}
					$damageId{$fId} = 1 if($fId && ($fId != $id) && ($fId != $mId));
					if (($fHp <= $damage) && ($fHflag == 0)) {
						# 괴수를 처치했습니다
						# 거대괴수 처리
						my($j, $ssx, $ssy);
						my $deflag = 0;
						foreach $j (1..6) {
							next if($HhugeMonsterImage[$fKind][$j] eq '');
							$ssx = $sx + $ax[$j];
							$ssy = $sy + $ay[$j];
							# 행 기준 위치 조정
							$ssx-- if(!($ssy % 2) && ($sy % 2));
							$ssx = $correctX[$ssx + $#an];
							$ssy = $correctY[$ssy + $#an];
							# 범위 밖
							next if(($ssx < 0) || ($ssy < 0));

							next if($land->[$ssx][$ssy] != $HlandHugeMonster);
							# 각 요소 꺼내기
							my($mHflag2, $mSea2, $mFlag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1, 2, 4];
							next if($mHflag2 != $j);
							# 코어의 주변이남겨 둔 것 경우 공격무효
							if($HhugeMonsterSpecial[$fKind] & 0x10000) {
								$deflag = 1;
								push(@pointErr, { 'DF' => $fPoint });
								last;
							} elsif ($mFlag2 & 2) {
								# 바다에있었음
								$land->[$ssx][$ssy] = $HlandSea;
								$landValue->[$ssx][$ssy] = $mSea2;
								$HlandMove[$id][$ssx][$ssy] = 1;
							} else {
								# 육지에있었음
								$land->[$ssx][$ssy] = $HlandWaste;
								$landValue->[$ssx][$ssy] = 0;
								$HlandMove[$id][$ssx][$ssy] = 1;
							}
						}
						next if($deflag);
						# 경험치
						$mExp += $HhugeMonsterExp[$fKind]; # 괴수의 경험치는 최고에서255
						$mIsland->{'gain'} += $HhugeMonsterExp[$fKind] if(defined $mn);
						$mExp = 250 if($mExp> 250);
						$landValue->[$x][$y] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);

						logNavyMonKill($id, $name, $mId, $mPoint, $mName, $tPoint, $fId, $fName, $fPoint);

						# 수입
#						if (defined $mn) {
#							my($value) = $HmonsterValue[$mKind];
#							if ($value> 0) {
#								$mIsland->{'money'} += $value;
#								logMsMonMoney($id, $mName, $value);
#							}

							# 수상 관계
#							my($prize) = $mIsland->{'prize'};
#							$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
#							my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
#							my($v) = 2 ** $mKind;
#							$hmonsters |= $v;
#							$mIsland->{'prize'} = "$flags,$monsters,$hmonsters,$turns";
							# 괴수퇴치 수
#							$mIsland->{'monsterkill'}++;
#						}

					} else {
						# 괴수살아하고 있는
						my($j, $ssx, $ssy);
						my $deflag = 0;
						foreach $j (1..6) {
							next if($HhugeMonsterImage[$fKind][$j] eq '');
							$ssx = $sx + $ax[$j];
							$ssy = $sy + $ay[$j];
							# 행 기준 위치 조정
							$ssx-- if(!($ssy % 2) && ($sy % 2));
							$ssx = $correctX[$ssx + $#an];
							$ssy = $correctY[$ssy + $#an];
							# 범위 밖
							next if(($ssx < 0) || ($ssy < 0));
							next if($land->[$ssx][$ssy] != $HlandHugeMonster);
							# 각 요소 꺼내기
							my($mHflag2) = (monsterUnpack($landValue->[$ssx][$ssy]))[1];
							next if($mHflag2 != $j);
							# 코어의 주변이남겨 둔 것 경우 공격무효
							if($HhugeMonsterSpecial[$fKind] & 0x10000) {
								$deflag = 1;
								push(@pointErr, { 'DF' => $fPoint });
								last;
							}
						}
						next if($deflag);
						logNavyMonster($id, $name, $mId, $mPoint, $mName, $tPoint, $fId, $fName, $fPoint);
						# HP가 1 감소
						$fHp -= $damage;
						if($fHp> 0) {
							$landValue->[$fx][$fy] = monsterPack($fId, $fHflag, $fSea, $fExp, $fFlag, $fKind, $fHp);
							next;
						}
					}
					if ($fFlag & 2) {
						# 바다에있었음
						$land->[$fx][$fy] = $HlandSea;
						$landValue->[$fx][$fy] = $mSea;
					} else {
						# 육지에있었음
						$land->[$fx][$fy] = $HlandWaste;
						$landValue->[$fx][$fy] = 0;
					}
					$HlandMove[$id][$fx][$fy] = 1;
					next;
				}
			} elsif ($fL == $HlandNavy) { # 해군
				my($nId2, $nTmp2, $nStat2, $nSea2, $nExp2, $nFlag2, $nNo2, $nKind2, $nHp2) = navyUnpack($fLv);
				my $nSpecial2 = $HnavySpecial[$nKind2];
				my $nName2 = landName($fL, $fLv);

				# 잠수안?
				if (!($mFlag & 2) && ($nFlag2 & 2)) {
					# 괴수가육에있고 함정이잠수안
					push(@pointErr, { 'FS' => $fPoint });
					next;
				}

				# 잔해?
				if ($nFlag2 & 1) {
					logNavyWreckDestroy($id, $name, $mId, $mPoint, $mName, $tPoint, $nName2, $fPoint);
					# 바다가 됨
					$land->[$fx][$fy] = $HlandSea;
					$landValue->[$fx][$fy] = 0;
					$HlandMove[$id][$fx][$fy] = 1;
					next;
				}

				if($amityFlag{$nId2}) { # 무해화
					if(random(100) < $HmonsterSafetyInvalidp) {
						# 일정 확률로 오폭
						push(@pointErr, { 'SS' => $fPoint });
					} else {
						push(@pointErr, { 'SZ' => $fPoint });
						next;
					}
				}

				$damageId{$nId2} = 1 if($nId2 && ($nId2 != $id) && ($nId2 != $mId));
				if ($nHp2 <= $damage) {
					# 격침

					# 경험치
					$mExp += $HnavyExp[$nKind2]; # 괴수의 경험치는 최고에서255
					$mExp = 250 if($mExp> 250);
					$landValue->[$x][$y] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
					if(defined $mn) {
						$mIsland->{'gain'} += $HnavyExp[$nKind2];
						$mIsland->{'ext'}[10]++;
						if($nId2 != $mId) {
							$mIsland->{'sink'}[$nKind]++;
						} else {
							$mIsland->{'sinkself'}[$nKind]++;
						}
					}
					my $n = $HidToNumber{$nId2};
					if(defined $n) {
						$Hislands[$n]->{'shipk'}[$nKind]-- ;
						# 서바이벌
						$Hislands[$n]->{'epoint'}{$id} = $HislandTurn if(($island->{'event'}[6] == 1) && ($island->{'event'}[1] <= $HislandTurn));
					}
					if ($nSpecial2 & 0x8) {
						# 군항괴멸
						logNavyPortDestroy($id, $name, $mId, $mPoint, $mName, $tPoint, $nId2, $nName2, $fPoint);
						# 얕은 바다가 됨
						$land->[$fx][$fy] = $HlandSea;
						$landValue->[$fx][$fy] = 1;
						$HlandMove[$id][$fx][$fy] = 1;
						$Hislands[$n]->{'navyPort'}-- if(defined $n);
					} else {
						# 함정격침
						logNavyShipDestroy($id, $name, $mId, $mPoint, $mName, $tPoint, $nId2, $nName2, $fPoint);

						if (rand(100) < $HnavyProbWreck[$nKind]) {
							# 잔해가 됨
							$landValue->[$fx][$fy] = navyPack(0, $nTmp2, $nStat2, $nSea2, int(rand(90)) + 10, 1, 0, $nKind2, 0);
						} else {
							# 바다가 됨
							$land->[$fx][$fy] = $HlandSea;
							$landValue->[$fx][$fy] = $nSea2;
							$HlandMove[$id][$fx][$fy] = 1;
						}
						if(defined $n) {
							$Hislands[$n]->{'ships'}[$nNo2]--;
							$Hislands[$n]->{'ships'}[4]--;
						}
					}
					next;
				} else {
					# 피격
					logNavyDamage($id, $name, $mId, $mPoint, $mName, $tPoint, $nId2, $nName2, $fPoint);

					# HP가 1 감소
					#$landValue->[$fx][$fy]--;
					$nHp2 -= $damage;
					if($nHp2> 0) {
						$landValue->[$fx][$fy] = navyPack($nId2, $nTmp2, $nStat2, $nSea2, $nExp2, $nFlag2, $nNo2, $nKind2, $nHp2);
					} else {
						$land->[$fx][$fy] = $HlandSea;
						$landValue->[$fx][$fy] = $nSea2;
					}
					next;
				}
			} elsif($fL == $HlandSeaMine) {
				# 기뢰
				logNavySeaMine($id, $name, $mId, $mPoint, $mName, $tPoint, $fName, $fPoint);

				$land->[$fx][$fy] = $HlandSea; # 깊은 바다
				$landValue->[$fx][$fy] = 0;
				$HlandMove[$id][$fx][$fy] = 1;
				next;
			} elsif (($fL == $HlandDefence) && ($fLv>= 0)) {
				# 방위 시설(내구력이남겨 둔 것)
				logNavyNormalDefence($id, $name, $mId, $mPoint, $mName, $tPoint, $fName, $fPoint);
			} elsif ($fL == $HlandCore) {
				# 코어
				my($lFlag, $lLv) = (int($fLv / 10000), ($fLv % 10000));
				if( !(($mFlag & 2) && ($lFlag>= 1)) && !(!($mFlag & 2) && ($lFlag <= 1)) ) {
					push(@pointErr, { 'ND' => $fPoint });
					$island->{'ext'}[5]++;
					next;
				}
				# 내구력을 높이기
				my $coreflag = $lLv - $damage;
				$fLv -= $damage;
				# 코어폭격 수, 코어파괴수
				#$nIsland->{'epoint'}{$id}++ if((defined $nn) && ($island->{'event'}[6] == 6) || (($coreflag < 0) && ($island->{'event'}[6] == 7)) && ($island->{'event'}[1] <= $HislandTurn));
				if($coreflag>= 0) {
					$land->[$fx][$fy] = $HlandCore;
					$landValue->[$fx][$fy] = $fLv;
					logNavyNormalDefence($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
				} else {
					$island->{'core'}--;
					$island->{'slaughterer2'} = $mId if($HcorelessDead && (defined $mn) && !$island->{'core'}); # 파괴한 섬 ID를 기록
					if ($mFlag & 2) {
						# 대잠
						logNavyTorpedoNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
					} else {
						# 대함, 대지
						logNavyNormal($id, $name, $nId, $nPoint, $nName, $tPoint, $fName, $fPoint);
					}
					if(!$lFlag) {
						$land->[$fx][$fy] = $HlandWaste; # 황무지(착탄 지점)
						$landValue->[$fx][$fy] = 1;
					} else {
						$land->[$fx][$fy] = $HlandSea; # 바다
						$landValue->[$fx][$fy] = 2 - $lFlag;
					}
					$HlandMove[$id][$fx][$fy] = 1;
				}
				next;
			} elsif ($fL == $HlandTown) {
				# 도시계
				my $sLv = 0;
				my $rank = 0;
				if($HtownStepDown) {
					foreach (reverse(0..$#HlandTownValue)) {
						if($HlandTownValue[$_] <= $fLv) {
							$rank = $_;
							last;
						}
					}
					$rank -= $damage;
					$rank = 0 if($rank < 0);
					$sLv = $HlandTownValue[$rank];
				}
				$mExp += int($fLv / 20); # 괴수의 경험치는 최고에서255
				$mExp = 250 if($mExp> 250);
				$landValue->[$x][$y] = monsterPack($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, $mHp);
				$boat += ($fLv - $sLv); # 난민에플러스
				if($rank) {
					$landValue->[$fx][$fy] = $sLv;
					logNavyNormalTown($id, $name, $mId, $mPoint, $mName, $tPoint, $fName, $fPoint, $HlandTownName[$rank]);
				} else {
					$island->{'slaughterer'} = $mId if(defined $mn); # 도시계를 파괴한 섬 ID를 기록
					logNavyNormal($id, $name, $mId, $mPoint, $mName, $tPoint, $fName, $fPoint);
					$land->[$fx][$fy] = $HlandWaste;
					$landValue->[$fx][$fy] = 1; # 착탄 지점
					$HlandMove[$id][$fx][$fy] = 1;
				}
				next;
			} else {
				# 기타의 지형
				logNavyNormal($id, $name, $mId, $mPoint, $mName, $tPoint, $fName, $fPoint);
				if ($fKind == $HlandBase && (defined $mn)) {
					$mIsland->{'ext'}[3]++; # 격파했습니다 미사일 기지의 수
				}
			}

			# 공격후의 지형로
			if (($fL == $HlandOil) ||
				($fL == $HlandSeaMine)) {
				# 유전이라면, 기뢰였으면 바다
				$land->[$fx][$fy] = $HlandSea;
				$landValue->[$fx][$fy] = 0;
				$HlandMove[$id][$fx][$fy] = 1;
			} elsif($fL == $HlandBouha) {
				# 방파제라면 얕은 바다
				$land->[$fx][$fy] = $HlandSea;
				$landValue->[$fx][$fy] = 1;
				$HlandMove[$id][$fx][$fy] = 1;
			} elsif(($fL == $HlandDefence) && ($fLv>= 0)) {
				# 내구력이 남은 방위시설이라면 내구 가능
				$land->[$fx][$fy] = $HlandDefence;
				$landValue->[$fx][$fy] = $fLv;
			} else {
				# 황무지가 됨
				$land->[$fx][$fy] = $HlandWaste;
				$landValue->[$fx][$fy] = 1; # 착탄 지점
				$HlandMove[$id][$fx][$fy] = 1;
			}
		} #foreach
	} #while
	if($fire) {
		my $l;
		my @pKey = ('OB', 'DF', 'ND', 'MS', 'MH', 'FS', 'SZ', 'SS');
		my @pName = ('권역외', '방위', '무효', '괴수 잠수', '경화', '함잠수', '무해', '오폭');
		my $str = '';
		my $pntStr = '<BR>--- ';
		my @cntErr = (0, 0, 0, 0, 0, 0, 0, 0, 0);
		foreach $l (0..7) {
			my $pflag = 1;
			my @pointOut = ();
			my $p;
			foreach $p (@pointErr) {
				my $pnt = $p->{$pKey[$l]};
				next if($pnt eq '');
				$cntErr[$l]++;
				$cntErr[8]++;
				foreach (@pointOut) {
					$pflag = 0 if($_ eq $pnt);
				}
				push(@pointOut, $pnt) if($pflag);
			}
			if($cntErr[$l]) {
				$str.= " $pName[$l]\:". $cntErr[$l];
				$pntStr.= "$pName[$l] ⇒ ". join(',', @pointOut). " " if($l);
			}
		}
		$pntStr = '' if(!$cntErr[8] || ($cntErr[8] == $cntErr[0]));
		$pntStr.= '[유폭 중심 ⇒ '. join(',', @terrorPnt).']' if(@terrorPnt);
		$str = '(명중:'. ($fire - $cntErr[8]). $str.')';
		$str.= '[파괴력:'. $damage. ']' if($damage> 1);
		my $attack = ($huge) ? $HhugeMonsterFireName[$mKind] : $HmonsterFireName[$mKind];
		$attack = '미사일 공격' if($attack eq '');
		logNavyMatome($id, $name, $mId, $mPoint, $mName, $tPoint, $tLandName, $attack, $str, $pntStr, join('-', (keys %damageId)));
	}
	# 난민판정
	$boat = int($boat / 2) if(!$HsurvivalTurn);
	if(($boat> 0) && (defined $mn)) {
		# 난민표착
		my($achive) = boatAchive($mIsland, $boat); # 도달난민

		if ($achive> 0) {
			# 조금이라도 도착한 경우 로그를 출력
			my $name = islandName($mIsland);
			logMsBoatPeople($mId, $name, $achive);
			$mIsland->{'ext'}[4] += int($achive); # 구출한 난민의 합계인구

			# 난민의 수가일정수이상라면, 평화상의 가능성있음
			if ($achive>= 200) {
				$mIsland->{'achive'} += $achive;
			}
		}
	}

	if(($land->[$x][$y] == $HlandMonster) || ($land->[$x][$y] == $HlandHugeMonster)) {
		return monsterUnpack($landValue->[$x][$y]);
	} else {
		return ($mId, $mHflag, $mSea, $mExp, $mFlag, $mKind, 0);
	}
}

1;
