#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

# The Return of Neptune: http://no-one.s53.xrea.com/
# patchworked by neo_otacky. for 바다전쟁 JS
# lbbslist.cgi?pass=[마스터 비밀번호]로 접속하면, 게시판도 표시됩니다.
# 게시할 시의 게시 이름은 관리자 이름에서  섬 이름은'관리자'이 됩니다.
# 주!쿠키에 마스터 비밀번호가 저장되어 있는 경우 일반 접속만으로 처리됩니다!
#---------------------------------------------------------------------
#
#	궁극 구상의 모형정원 로컬 게시판을 목록 표시
#
#	작성일 : 2001/10/06 (ver0.10)
#	작성자 : 라스티아 <nayupon@mail.goo.ne.jp>
#
#	관리자가 섬 주민의 발언을 빠짐없이 목록으로 확인하기 위한 기능입니다.
#	lbbslist.cgi?pass=마스터 비밀번호 로 접속하면 극비 통신도 볼 수 있습니다.
#
#	수정이력
#	2001/10/20 V0.20 최근의 발언을 색을변해서 표시할 수 있도록 했습니다.
#	2001/12/31 V0.30 공통 설정부를 config.cgi에서 불러올 수 있도록 했습니다.
#	2002/01/13 V0.31 version4대응
#	2002/02/03 V0.40 CSS 을별도 파일에서 읽어오할 수 있도록 했습니다.
#	2002/04/17 V0.41 부하 표시를 추가. 스크립트를 전체적에재검와 시.
#	2002/07/27 V0.50 극비 통신 대응. 보기 및 기타 항목 개선 등.
#	2002/10/28 V0.60 스타일시트주변을 개량
#
#---------------------------------------------------------------------
#	이 스크립트는 아래 내용을 바탕으로 작성했습니다
#
#	괴수 격퇴 포인트 + 획득 상금 순위 표시
#	작성자 : Watson <watson@catnip.freemail.ne.jp>
#---------------------------------------------------------------------
BEGIN {
	# Perl 5.004 이상이필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}
#---------------------------------------------------------------------
#	초기 설정
#---------------------------------------------------------------------
# 초기 설정용 파일을 읽기
require './hako-init.cgi';
require './hako-io.cgi';
require './init-game.cgi';

# 색을 변해서 표시하다 턴
$kyoutyouturn = 10;

#----------------------------
#	HTML에 관한 설정
#----------------------------
# 브라우저의 제목막대의 명칭
$title = '관광객 통신 목록';

# 모험머리의 메시지(HTML 서식)
$headKill = <<"EOF";
<h1>$Htitle 관광객 통신 목록(관리용)</h1>
EOF

# 화면의'돌아가기'링크선(URL)
$bye = $HthisFile;

# 관리자 외에는 게시란을 표시할까요?
$HpermitPost = 1;

#여기까지-------------------------------------------------------------

if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	close(PIN);
}
&cookieInput;
&cgiInput;
my($mode) = 0;
my $bye2 = '';
my $post = 'SS';
my $del = 'DS';

if($HskinName ne '' ){
	$baseSKIN = $HskinName;
} else {
	$baseSKIN = "${HcssDir}/$HcssDefault";
}
$HmainMode = 'lbbs';
if(!(&readIslandsFile(-4))){
	&htmlHeader;
	&htmlError;
} else {
	if($HdefaultPassword ne '') {
		my $island = $Hislands[$HidToNumber{$defaultID}];
		if($mode = checkPassword($island, $HdefaultPassword)) {
			if($mode == 2) {
				$HdefaultName = $HadminName;
				$defaultID = 0;
				$post = 'AD';
				$del = 'DA';
			} elsif(!$HpermitPost) {
				$mode = 0;
			}
		} else {
			&htmlHeader;
			tempWrongPassword(); # 비밀번호 불일치
			&htmlFooter;
			exit(0);
		}
	}
	$bye2 = ($mode < 2) ? '' : "[<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">관리 화면으로</A>] ";

	&htmlHeader;
	out("<DIV align='center'>");
	out($headKill);
#	out("이 스크립트는, 서버에 부하가 걸릴 수 있어 본체에서는 링크를 제공하지 않습니다.<br>");
#	out("잦은 접속이나 새로고침은 삼가 주세요!<br>");
	out("<B>이 스크립트는, 서버에 큰 부하가 걸릴 수 있으므로, 잦은 접속이나 새로고침은 가능한 한 자제해 주세요!</B><br><br>");
	out("<B>참고: 게시하면, 게시한 섬의 관광 화면에전환됩니다</B><br>") if($mode == 1);
	out("<TABLE BORDER><TR><TD>");
	foreach $i (0..$islandNumber) {
		&tempLbbsContents($i);
	}
	out("<TR><TD colspan=2 class='M'><P align='center'>${AfterName} 이름을 클릭하면, 관광할 수 있습니다.</P></TD></TR>");
	out("</TABLE>");
	out("</DIV>");
}
&htmlFooter;
#종료
exit(0);

# 서브 루틴---------------------------------------------------------
#--------------------------------------------------------------------
#	POST 또는 GET으로 입력된 데이터 가져오기
#--------------------------------------------------------------------
sub cgiInput {
	my($line, $getLine);
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9]{2})/pack(H2, $1)/eg;

	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};

	if($getLine =~ /id=([0-9]+)/) {
		# 처음 시작
		$defaultID = $1;
	}
	if($getLine =~ /pass=([^\&]*)/) {
		# 처음 시작
		$HdefaultPassword = $1;
	}
	if($line =~ /LBBSVIEW=([0-9]+)\&/) {
		$HlbbsView = $1;
	}
}

#---------------------------------------------------------------------
#	함수명 : htmlHeader
#	기계 능 : HTML 의헤더 부분을 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlHeader {
	$baseIMG = $HimageDir;
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${HcssDir}/$HcssDefault";
	}
	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $Hgzip == 1){
		print qq{Content-type: text/html; charset=UTF-8\n};
		print qq{Content-encoding: gzip\n\n};
		open(STDOUT,"| $HpathGzip/gzip -1 -c");
		print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};
	}else{
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">\n\n};
	}
	my $term = '';
	$term = ($HislandTurn < $HarmisticeTurn) ? "(~$HarmisticeTurn <small>휴전 기간</small>)" : ($HislandTurn == $HarmisticeTurn) ? '(<small>다음 턴부터 전투 기간</small>)' : '(<small>전투 기간</small>)' if($HarmisticeTurn);

	out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
<BASE HREF="$baseIMG/">
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$Body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
$Hheader
END

	my $nextturn = '';
	foreach (1..$HrepeatTurn) {
		$nextturn.= '·' if($_ != 1);
		$nextturn.= $HislandTurn + $_;
		last if($HislandTurn + $_ == $HarmisticeTurn || $HislandTurn + $_ == $HsurvivalTurn || $HislandTurn + $_ == $HislandChangeTurn);
	}
	out(<<END) if(defined $HleftTime);
<HR>
<H1 style="display:inline;"><SMALL><B>턴</B> </SMALL>$HislandTurn<SMALL>${term}</SMALL> </H1>
<span ID="REALTIME" class="timer"></span>
<SCRIPT language="JavaScript">
<!--
var leftTime = $HleftTime;
var hour, min, sec;

function showTimeLeft() {
	if (leftTime> 0) {
		setTimeout('showTimeLeft()', 1000);

		hour = Math.floor(leftTime / 3600);
		min = Math.floor(leftTime % 3600 / 60);
		sec = leftTime % 60;
		leftTime--;

		document.all.REALTIME.innerHTML = '다음 갱신(<span class="number">턴$nextturn</span>)까지 남은 ' + hour + '시간 ' + min + '분 ' + sec + '초 ($HnextTime)';
	} else {
		document.all.REALTIME.innerHTML = '턴 갱신 시각이 되었습니다! ($HnextTime)';
	}
}

if ($HplayNow) {
	showTimeLeft();
} else {
	document.all.REALTIME.innerHTML = '게임이 종료되었습니다!';
}
//-->
</SCRIPT>
END

	out(<<END);
<HR></DIV>
${bye2}<A HREF="$bye">[돌아가기]</A><br><br>
END
}
#---------------------------------------------------------------------
#	함수명 : htmlFooter
#	기계 능 : HTML 의푸터 부분을 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlFooter {
	out(<<END);
<HR>
<DIV ID='LinkFoot'>
$Hfooter
<BR></DIV>
END
##### 추가 친분20020307
	if($Hperformance) {
		my($uti, $sti, $cuti, $csti) = times();
		$uti += $cuti;
		$sti += $csti;
		my($cpu) = $uti + $sti;

	#	 로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
	#	 open(POUT,">>cpu-h.log");
	#	 print POUT "CPU($cpu) : user($uti) system($sti)\n";
	#	 close(POUT);

		out(<<END);
<DIV align="right">
<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
</DIV>
END
	}
#####
	out(<<END);
</DIV></BODY>
</HTML>
END
}
#---------------------------------------------------------------------
#	함수명 : htmlError
#	기계 능 : HTML 의오류 메시지의 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlError{
	out("<H2>오류가 발생했습니다</H2>\n");
}

#---------------------------------------------------------------------
#	함수명 : tempLbbsContents
#	기계 능 : 로컬 게시판내용
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub tempLbbsContents {
	my($number) = $_[0];
	my($island) = $Hislands[$number];
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($owner) = $island->{'owner'};
	my($lbbs) = $island->{'lbbs'};
	my $no = @$lbbs;
	my($comment) = $island->{'comment'};
	my($line);
	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$name${H_tagName}";
	} else {
		$name = "${HtagName2_}$name($island->{'absent'})${H_tagName2}";
	}
	$name.= "${HtagDisaster_}★${H_tagDisaster}" if ($HislandTurn - $island->{'birthday'} <= $HdevelopTurn);
	if($island->{'predelete'}) {
		my $rest = ($island->{'predelete'} != 99999999) ? "<small>(남은$island->{'predelete'}턴)</small>" : '';
		$name = "${HtagDisaster_}[관리자 보관]$rest${H_tagDisaster}<BR>". $name;
	}
	out(<<END);
<TR><TH $HbgTitleCell width=5%>${HtagTH_}${AfterName} 이름${H_tagTH}</TH>
<TD $HbgNameCell>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}" TARGET=_blank>
$name
</A>
</TD><TH $HbgTitleCell width=5%>${HtagTH_} 섬주${H_tagTH}</TH>
<TD $HbgInfoCell>$owner</TD></TR>
<TR><TH $HbgTitleCell>${HtagTH_}코멘트${H_tagTH}</TH><TD $HbgCommentCell colspan=3>$comment</TD></TR>
END

	$HlbbsView = $HlbbsViewMax if(!$HlbbsView);
	if($mode) {
		out(<<END);
<TR>
<TD colspan=3>
<FORM action="$HthisFile" method="POST">
name:<INPUT TYPE="text" SIZE=16 NAME="LBBSNAME" VALUE="$HdefaultName">
<INPUT TYPE="hidden" NAME="ISLANDID2" VALUE="$defaultID">
com:<INPUT TYPE="text" SIZE=40 NAME="LBBSMESSAGE">
pass:<INPUT TYPE="password" SIZE=8 MAXLENGTH=16 NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="PUBLIC" CHECKED>공개
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="SECRET"><span class='lbbsST'>극비</span>
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButton$post$id">
END

		out(<<END);
No.
<SELECT NAME=NUMBER>
END
		# 발언번호
		my($j, $i);
		for($i = 0; $i < $HlbbsMax; $i++) {
			$j = $i + 1;
			out("<OPTION VALUE=$i>$j\n");
		}
		out("<OPTION VALUE=-1>전체\n");
		out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButton$del$id">
</TD></FORM><FORM action="$HlbbsFile" method="POST"><TD>
END

		out(<<END);
View
<SELECT NAME=LBBSVIEW>
END
		for($i = $HlbbsViewMax; $i <= $HlbbsMax; $i+=10) {
			if($i != $HlbbsView) {
				out("<OPTION VALUE=$i>$i\n");
			} else {
				out("<OPTION VALUE=$i SELECTED>$i\n");
			}
		}
		out(<<END);
</SELECT><B>/$no</B>
<INPUT TYPE="submit" VALUE="열람" NAME="LbbsButtonView">
</TD></TR>
</FORM>
END
	}

	my($i,$j,$str1,$turn);
	for($i = 0; $i < $HlbbsView; $i++) {
		$line = $lbbs->[$i];
		last if($line eq '0<<0>>');
		if($line =~ /([0-9]*)\<(.*)\<(.*)\>(.*)\>(.*)$/) {
			my($m, $iName, $oda, $tan, $com) = ($1, $2, $3, $4, $5);
			$com =~ s/(http|ftp):\/\/([^\x81-\xFF\s\"\'\(\)\<\>\\\`\[\{\]\}\|]+)/<A href=\"$1:\/\/$2\" onclick=\"location.href=\'${HaxesFile}?$1:\/\/$2\'\; return false\;\" target=\"_blank\">$HlbbsAutolinkSymbol<\/A>/g if($HlbbsAutolinkSymbol ne '');
			$j = $i + 1;
			my($speaker);
			my($sName, $sID) = split(/,/, $iName);
			my($os, $date, $addr) = split(/,/, $oda);
			my($turn, $name) = split(/:/, $tan);
			if($turn>= $HislandTurn - $kyoutyouturn) {
				out("<TR><TD class='RankingCell' align=center><span class='number'>$j</span></TD>");
			} else {
				out("<TR><TD $HbgNameCell align=center><span class='number'>$j</span></TD>");
			}
			$tan = "<A title='[$date]'>턴${turn}</A>:$name";
			my $sNo = $HidToNumber{$sID};
			if($sName ne '') {
				if(defined $sNo){
					$speaker = "<span class='lbbsST'><B><SMALL>(<A STYlE=\"text-decoration:none\" HREF=\"$HthisFile?Sight=$sID\" TARGET=_blank>$sName</A>)</SMALL></B></span>";
				} else {
					$speaker = "<span class='lbbsST'><B><SMALL>($sName)</SMALL></B></span>";
				}
			}
			out("<TD $HbgInfoCell colspan=3>");
			if($os == 0) {
				# 관광객
				if ($m == 0) {
					# 공개
					if($sID ne '0') {
						out("<span class='lbbsSS'>$tan> $com</span> $speaker</TD></TR>");
					} else {
						out("<span class='lbbsAD'>$tan> ${com}</span> $speaker</TD></TR>");
					}
				} else {
					# 극비
					if ($mode < 2) {
						# 관광객
						out("<DIV align='center'><span class='lbbsST'>- 극비 -</span></DIV></TD></TR>");
					} else {
						# 소유자
						out("<span class='lbbsST'>$tan>(비밀) $com</span> $speaker</TD></TR>");
					}
				}
			} else {
				# 섬주
				out("<span class='lbbsOW'>$tan> $com</span> $speaker</TD></TR>");
			}
		}
	}
	out(<<END);
</TD></TR>
END

	out(<<END);
<TR></TR>
<TR></TR>
END
}

