#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# The Return of Neptune: http://no-one.s53.xrea.com/
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 메인 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 모형정원 제도 2nd
#								 v1.5
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							 모형정원 모형정원 바다전쟁
#								 v1.3
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#----------------------------------------------------------------------
# 메인 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {

	# 접속·로그
	axeslog(0) if($HtopAxes> 2);
	# 화면 출력
	unlock();

	# 템플릿 출력
	tempTopPage();
}

# 메인 페이지
sub tempTopPage {
	if($Htournament){
		# 토너먼트
		if($HislandFightMode == 0){
			# 예선
#			@HflexTime = @HtmTime1;
		}elsif($HislandFightMode == 1){
			# 개발
#			@HflexTime = @HtmTime2;
			$HmaxIsland = 0;
		}elsif($HislandFightMode == 2){
			# 전투
#			@HflexTime = @HtmTime3;
			$HmaxIsland = 0;
		}elsif($HislandFightMode == 9){
			# 종료
			$HlastTurn = $HislandTurn;
		}
	}

	$HtopTemplateFile = "tempTop.html" if($HtopTemplateFile eq '');
	if($HlayoutTop && (-e "./$HtopTemplateFile")) {
		open(TEMPLATE, "./$HtopTemplateFile") || &tempProblem;
		while ( <TEMPLATE> ) {
			if($_ =~ /<!--title-->/) {
				# 제목
				out("${HtagTitle_}$Htitle${H_tagTitle}");
				# 디버그 모드에서 쿠키에칸경로(or 특수 비밀번호)저장되어 있으면'턴을 진행하기'버튼
				if($Hdebug == 1 && checkSpecialPassword($HdefaultPassword)) {
					out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
				}
				if(-e "./mente_lock") {
					out("${HtagBig_}<span class='attention'>점검·모드</span>${H_tagBig}");
				}
			} elsif($_ =~ /<!--turn-->/) {
				# 턴·갱신 시간의 정보 표시
				tempTopTurnInfo();
			} elsif($_ =~ /<!--link-->/) {
				# 링크 표시
				tempTopLink();
			} elsif($_ =~ /<!--login-->/) {
				# 로그인
				tempTopLogin();
			} elsif($_ =~ /<!--island-->/) {
				# 섬의 정보 표시 일반
				tempTopIslandView(0);
			} elsif($_ =~ /<!--playerisland-->/) {
				# 섬의 정보 표시 플레이어 섬만
				tempTopIslandView(1);
			} elsif($_ =~ /<!--battlefield-->/) {
				# 섬의 정보 표시 전장만
				tempTopIslandView(2);
			} elsif($_ =~ /<!--alliance-->/) {
				# 진영 정보 표시
				if($HallyNumber){
					allyInfo(-1);
					my $aStr = ($HarmisticeTurn) ? '진영' : '동맹';
					out(" <B>참고: </B>${aStr} 이름을 클릭하면'${aStr}의 정보'란으로");
					out(",${HallyTopName} 섬이라면 '코멘트 변경'란으로") if(!$HarmisticeTurn);
					out("이동합니다.");
				}
			} elsif($_ =~ /<!--history-->/) {
				# 발견 기록
				out(<<END);
<DIV ID='HistoryLog'>
<H1>발견 기록</H1>
<DIV style="overflow:auto; height:${HdivHeight}px;">
END
				historyPrint();
	out(<<END);
</DIV></DIV>
END
			} elsif($_ =~ /<!--recent-->/) {
				# 최근 소식
				my $hFile;
				if(!$HhtmlLogMode || !(-e "${HhtmlDir}/hakolog.html") || $Hgzip) {
					$hFile = "${HbaseDir}/history.cgi?Event=0&Topmode=1";
				} else {
					$hFile = "${htmlDir}/hakolog.html";
				}
				out(<<END);
<iframe width="100%" height="400" src="$hFile" frameborder="0" scrolling="AUTO" name="log">
</iframe>
END
			} elsif($_ =~ /<!--admin-->/) {
				# 관리자만 섬 등록할 수 이 경우의 로그인
				out(<<END) if ($HadminJoinOnly);
<DIV align="right">
<FORM action="$HthisFile" method="POST" style="margin : 2px 0px;">
<INPUT type="hidden" name="Join" value=0>
<INPUT type="password" name="PASSWORD" size=16 maxlength=16 class=f>
<INPUT type="submit" name="submit" value="관리용">
</FORM></DIV>
END
			} elsif($_ =~ /<!--news-->/) {
				# 뉴스
				out("$Hnews");
			} else {
				out("$_");
			}
		}
	} else {
		tempTopPageDefault();
	}
}

#'메인 페이지'기본값
sub tempTopPageDefault {
	# 링크 표시
#	tempTopLink();
#	out("<HR>");

	# 제목
	out("${HtagTitle_}$Htitle${H_tagTitle}");

	# 디버그 모드에서 쿠키에칸경로(or 특수 비밀번호)저장되어 있으면'턴을 진행하기'버튼
	if($Hdebug == 1 && checkSpecialPassword($HdefaultPassword)) {
		out(<<END);
<BR>
<FORM style="display:inline" action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
<FORM style="display:inline" action="$HmenteFile" method="GET">
<INPUT TYPE="hidden" NAME="ADMIN" VALUE="$HdefaultPassword">
<INPUT TYPE="submit" VALUE="관리자실로" NAME="TurnButton">
</FORM>
END
	}

	if(-e "./mente_lock") {
		out("${HtagBig_}<span class='attention'>점검·모드</span>${H_tagBig}");
	}

	# 턴·갱신 시간의 정보 표시
	tempTopTurnInfo();

	# 링크 표시
#	out("<HR>");
#	tempTopLink();

	out(<<END);
<HR>
<TABLE BORDER=0 width="100%">
<TR valign="top">
<TD class="M">
END

	# 로그인
	tempTopLogin();

	# 링크 표시
#	out("</TD><TD width=\"35%\" class=\"M\">");
#	tempTopLink();

	out(<<END);
</TD>
<TD class="M">
<DIV ID='HistoryLog'>
<H1>발견 기록</H1>
<DIV style="overflow:auto; height:${HdivHeight}px;">
END

	historyPrint();

	out(<<END);
</DIV></DIV>
</TD></TABLE>
END

	# 상단 메뉴는 hako-init.cgi 의 $Hheader에서 출력합니다.
	# 기본 화면 중간/하단의 중복 메뉴는 표시하지 않습니다.

	# 진영 정보 표시
	if($HallyNumber){
		out("<HR>");
		allyInfo(-1);
		my $aStr = ($HarmisticeTurn) ? '진영' : '동맹';
		out(" <B>참고: </B>${aStr} 이름을 클릭하면'${aStr}의 정보'란으로");
		out(",${HallyTopName} 섬이라면 '코멘트 변경'란으로") if(!$HarmisticeTurn);
		out("이동합니다.");
	}

	out("<HR>");
	# 섬의 정보 표시
	tempTopIslandView(0);

	out(<<END) if ($HadminJoinOnly);
<HR>
<DIV align="right">
<FORM action="$HthisFile" method="POST" style="margin : 2px 0px;">
<INPUT type="hidden" name="Join" value=0>
<INPUT type="password" name="PASSWORD" size=16 maxlength=16 class=f>
<INPUT type="submit" name="submit" value="관리용">
</FORM></DIV>
END

}

# '메인 페이지'링크
sub tempTopLink {
	out("<DIV ID='LinkTop'>");
	if( $HsurvivalTurn && ($HislandTurn> $HsurvivalTurn) ) {
		out(qq|<B>참고: </B>서바이벌 모드 때문에, 새 ${AfterName}은 탐색할 수 없습니다.<BR>|);
	} elsif($HislandNumber - $HbfieldNumber>= $HmaxIsland) {
		out(qq|[<span class='attention'>정원이 초과되었습니다</span>] |);
	} elsif(!$HadminJoinOnly) {
		out(qq|[<A href="$HthisFile?Join=0">새 ${AfterName}을 탐색</A>] |);
	} else {
		out(qq|<B>참고: </B>새 ${AfterName}을 찾으려는 분은 관리자에게 <B>${AfterName} 이름, 사용자 이름, 비밀번호</B>를 메일로 보내 주세요.<BR>|);
	}
	out(qq|[<A href="$HthisFile?Rename=0">정보 변경</A>] |);
	out(qq|[<A href="$HthisFile?Limg=0">이미지 경로 설정</A>] |);
	out(qq|[<A href="$HthisFile?Skin=0">스킨 설정</A>] |) if($HcssSetting);
	out(qq|[<A href="$HthisFile?ICounter=0">카운터 설정</A>] |) if($HcounterSetting && !$Htournament);
	out(qq|[<A href="$HthisFile?JoinA=0">동맹 설정</A>] |) if($HallyUse && !$HarmisticeTurn && !$Htournament);

	my $sftime = (-M "${HefileDir}/setup.html");
	my @Files = ('hako-main.cgi', 'hako-init.cgi', 'init-game.cgi', 'init-server.cgi', 'hako-table.cgi');
	my $sfFlag = 1;
	foreach (@Files) {
		if($sftime>= (-M "./$_")){
			$sfFlag = 0;
			last;
		}
	}
	if((-e "${HefileDir}/setup.html") && $sfFlag) {
		out("[<A href=\"${efileDir}/setup.html\"> 설정 목록</A>] ");
	} else {
		out("[<A href=\"$HthisFile?SetupV=0\"> 설정 목록</A>] ");
	}
	out("<BR>");
	my($title) = '';
	$title = '우호국' if($HuseAmity);
	if($HuseDeWar) {
		$title.= '·' if($HuseAmity);
		$title.= '교전국';
	}
	out(qq|[<A href="$HthisFile?Amity=0">$title 목록</A>] |) if(($HuseAmity || $HuseDeWar) && !$HarmisticeTurn && !$Htournament);
	out(qq|[<A href="$HthisFile?Fleet=1">함정 보유 목록</A>] |)if($HnavyName[0] ne '');
	out(qq|[<A href="$HthisFile?Item=0">${HitemName[0]} 획득 현황</A>] |) if($HuseItem);
	out(qq|[<A href="$HthisFile?Rank=0">순위</A>] |);
	out(qq|[<A href="$HlbbsFile">관광객 통신 목록</A>] |) if($Hlbbslist);
	if(!$HhtmlLogMode || !(-e "${HhtmlDir}/hakolog.html") || $Hgzip) {
		out(qq|[<A href="${HbaseDir}/history.cgi?Event=0">최근 사건</A>] |);
	} else {
		out(qq|[<A href="${htmlDir}/hakolog.html">최근 사건</A>] |);
	}
	out(qq|</DIV>|);

}

# '메인 페이지'턴·갱신 시간의 정보
sub tempTopTurnInfo {
	# 양식
	my $repeat = (($HrepeatTurn == 1) ? '' : "<B>참고: </B>1회의 갱신에서 $HrepeatTurn 턴 진행합니다.");
	my $armTurn = ($HarmisticeTurn < $HsurvivalTurn) ? $HsurvivalTurn : $HarmisticeTurn;
	if($armTurn && ($HislandTurn < $armTurn) && ($HarmRepeatTurn != $HarmisticeRepeatTurn)) {
		$repeat.= "(전투 기간은,1회 $HarmRepeatTurn 턴)";
	}
	if ($HjavaModeSet eq 'cgi') {
		$radio = "CHECKED"; $radio2 = "";
	}else{
		$radio = ""; $radio2 = "CHECKED";
	}
	# 0제외계산회피
	$HrepeatTurn = 1 if(!$HrepeatTurn);
	$HarmRepeatTurn = 1 if(!$HarmRepeatTurn);
	$HarmisticeRepeatTurn = 1 if(!$HarmisticeRepeatTurn);
	# 종료 턴 수와 종료일 시를 표시
	my($HlastTurnS, $HlimitTime);
	if(!$HgameLimitTurn) {
		$HlastTurnS = "";
	} elsif($HislandTurn < $HgameLimitTurn) {
		my $remainTime = 0;
		if($HflexTimeSet) {
			my $all = 0;
			foreach (@HflexTime) {
				$all += $_;
			}
			my($tsb, $ts, $tsn, $teb, $te, $ten, $i);
			if($HarmisticeTurn || $HsurvivalTurn) {
				if($HislandTurn < $armTurn) {
					$tsb = int($HislandTurn / $HrepeatTurn);
				} else {
					$tsb = int(($HislandTurn - $armTurn) / $HarmRepeatTurn) + int($armTurn / $HarmisticeRepeatTurn);
					$tsb += 1 if(($HislandTurn - $armTurn) % $HarmRepeatTurn);
				}
				$ts = int($tsb / @HflexTime);
				$tsn = $tsb % @HflexTime;
				$teb = int(($HgameLimitTurn - $armTurn) / $HarmRepeatTurn) + int($armTurn / $HarmisticeRepeatTurn);
				$teb += 1 if(($HgameLimitTurn - $armTurn) % $HarmRepeatTurn);
				$teb += 1 if($armTurn % $HarmisticeRepeatTurn);
				$te = int($teb / @HflexTime);
				$ten = $teb % @HflexTime;
			} else {
				$ts = int(($HislandTurn / $HrepeatTurn) / @HflexTime);
				$tsn = int($HislandTurn / $HrepeatTurn) % @HflexTime;
				$te = int(int($HgameLimitTurn / $HrepeatTurn) / @HflexTime);
				$ten = int($HgameLimitTurn / $HrepeatTurn) % @HflexTime;
			}
			$remainTime += $all * ($te - $ts - 1);
			if($tsn) {
				foreach($tsn..$#HflexTime) {
					$remainTime += $HflexTime[$_];
				}
			} else {
				$remainTime += $all;
			}
			if($ten) {
				$nine = $ten - 1;
				foreach(0..$nine) {
					$remainTime += $HflexTime[$_];
				}
			}
#			for($i=$HislandTurn; $i < $HgameLimitTurn; $i++) {
#				$remainTime += $HflexTime[($HislandTurn % ($#HflexTime + 1))];
#			}
			$remainTime *= 3600;
		} else {
			if( (($HarmisticeTurn && ($HislandTurn < $HarmisticeTurn))) ||
				(($HsurvivalTurn && ($HislandTurn < $HsurvivalTurn))) ) {
				my $armTurn = (!$HarmisticeTurn) ? $HsurvivalTurn : $HarmisticeTurn;
				$remainTime = $HunitTime * int(($armTurn - $HislandTurn + ($HrepeatTurn - 1)) / $HrepeatTurn) + $HarmTime * int(($HgameLimitTurn - $armTurn) / $HarmRepeatTurn);
			} else {
				$remainTime = $HunitTime * int(($HgameLimitTurn - $HislandTurn + ($HrepeatTurn - 1)) / $HrepeatTurn);
			}
		}
		$HlimitTime = $HislandLastTime + $remainTime;
		$HlimitTime = sprintf('%d년 %d월 %d일 %d 시', (gmtime($HlimitTime + $Hjst))[5] + 1900, (gmtime($HlimitTime + $Hjst))[4] + 1, (gmtime($HlimitTime + $Hjst))[3,2]);
		$HlastTurnS = "<small>/${HgameLimitTurn}<small>《${HlimitTime}까지》</small></small>";
	} else {
		$HlastTurnS = " (게임이 종료되었습니다)";
	}

	# 다음 갱신 시간 표시
	if($HflexTimeSet) {
		$aaa = $HislandLastTime + 3600 * $HflexTime[(($HislandTurn/$HrepeatTurn) % ($#HflexTime + 1))];
	} else {
		$aaa = $HislandLastTime + $HunitTime;
		if($Htournament && ($HislandTurn>= $HyosenTurn)){
			if($HislandFightMode == 1) {
				if(($HislandTurn> $HyosenTurn) && ($HislandTurn == $HislandChangeTurn - $HdevelopeTurn)){
					$aaa += $HinterTime - $HunitTime;
				} else {
					$aaa += $HdevelopeTime - $HunitTime;
				}
			} elsif($HislandFightMode == 2) {
#				if($HislandTurn == $HislandChangeTurn - $HfightTurn){
#					$aaa += $HdevelopeTime - $HunitTime;
#				} else {
					$aaa += $HfightTime - $HunitTime;
#				}
			}
		}
	}

	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime(time + $Hjst);
	$mon++;
	my($sss) = "${mon}월 ${date}일 ${hour}시 ${min}분 ${sec}초";
	my($sec2, $min2, $hour2, $date2, $mon2, $year2, $day2, $yday2, $dummy2) = gmtime($aaa + $Hjst);
	$mon2++;
	my($bbb) = '';
	if(!$HgameLimitTurn || ($HislandTurn < $HgameLimitTurn)) {
		$bbb = "${mon2}월 ${date2}일 ${hour2}시 ${min2}분";
	} else {
		$bbb = "갱신이 중지되었습니다";
	}
	if (!$HplayNow ||
		$HsurvivalTurn && ($islandNumber == $HbfieldNumber) && ($HislandTurn> $HsurvivalTurn)
	 ) {
		$HlastTurnS = " (게임이 종료되었습니다)";
		$bbb = "갱신이 중지되었습니다";
		$rtStr = " ";
		undef $HleftTime;
	}
	if($HitemComplete) {

		my $cName = islandName($Hislands[$HidToNumber{$HitemComplete}]);
		$HlastTurnS = " Game Over<BR>~세계는<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=${HitemComplete}\">${HtagName_}${cName}${H_tagName}</A>에 의해 하나가 되었습니다~";
	} elsif($HitemCompleteA) {
		my $ally = $Hally[$HidToAllyNumber{$HitemCompleteA}];
		my $aName = "<FONT COLOR=\"$ally->{'color'}\"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}";
		$HlastTurnS = " Game Over<BR>~세계는<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?AmiOfAlly=${HitemCompleteA}\">${HtagName_}${aName}${H_tagName}</A>에 의해 하나가 되었습니다~";
	}
	# 다음 턴까지의 시간 표시
	if (!($HmainMode eq 'turn') && (defined $HleftTime)) {
		if(!$HgameLimitTurn || ($HislandTurn < $HgameLimitTurn)) {
			my $hour2 = int($HleftTime / 3600);
			my $min2 = int(($HleftTime - $hour2 * 3600) / 60);
			my $sec2 = ($HleftTime - $hour2 * 3600 - $min2 * 60);
			my $nextturn = '';
			foreach (1..$HrepeatTurn) {
				$nextturn.= '·' if($_ != 1);
				$nextturn.= $HislandTurn + $_;
				last if($HislandTurn + $_ == $HarmisticeTurn || $HislandTurn + $_ == $HsurvivalTurn || $HislandTurn + $_ == $HislandChangeTurn);
			}
			$rtStr = "다음 갱신 시간<span class='number'>(턴$nextturn)</span>까지 남은 $hour2 시간 $min2분 $sec2초";
		} else {
			$rtStr = " ";
		}
	} else {
		if ($HplayNow) {
			$rtStr = "턴을 갱신했습니다\n";
		} else {
			$rtStr = " ";
		}
	}
	my $mode = '';
	$mode = ($HislandTurn < $HarmisticeTurn) ? "(~$HarmisticeTurn <small>휴전 기간</small>)" : ($HislandTurn == $HarmisticeTurn) ? '(<small>다음 턴부터 전투 기간</small>)' : '(<small>전투 기간</small>)' if($HarmisticeTurn);
	$mode = ($HislandTurn < $HsurvivalTurn) ? "(~$HsurvivalTurn <small>휴전 기간</small>)" : ($HislandTurn == $HsurvivalTurn) ? '(<small>다음 턴부터 전투 기간</small>)' : '(<small>전투 기간</small>)' if($HsurvivalTurn);

	my $eee;
	if($Htournament){
		# 토너먼트
		my($tst);
		my $flog = "[<A href=\"$HthisFile?FightLog=0\" class=\"M\">대전 기록</A>]";
		$HlastTurnS = "";
		if($HislandFightMode == 0){
			# 예선
			if($HislandNumber> $Htournament){
				$tst = $HislandNumber - $Htournament;
				$tst = "<span class=attention>$tst$AfterName 침몰</span>시";
			}
			$tst = "<span class=normal>예선종료후,${tst}개발 기간에이동합니다.</span>";
			$mode = "(~$HislandChangeTurn <small><span class=normal>예선 기간</span> <span class=attention>$Htournament${AfterName}선택빼기</span></small>)";
		}elsif($HislandFightMode == 1){
			# 개발
			$tst = $HislandChangeTurn + 1;
			$tst = "<span class=normal>${tst}턴에서 공격시작</span>";
			$mode = ($HislandTurn == $HislandChangeTurn - $HdevelopeTurn) ? "(<small>다음 턴부터 개발 기간</small>)" : "(~$HislandChangeTurn <small>개발 기간</small>)";
		}elsif($HislandFightMode == 2){
			# 전투
			$mode = ($HislandTurn == $HislandChangeTurn - $HfightTurn) ? "(<small>다음 턴부터 전투 기간</small>)" : "(~$HislandChangeTurn <small>전투 기간</small>)";
		}elsif($HislandFightMode == 9){
			# 종료
			$HlastTurnS = " (게임이 종료되었습니다)";
		}
		$mode.= "<small><small> $tst </small>$flog</small>";
	} elsif($HplayNow) {
		# 갱신빈도 표시
		my $safety = 0;
		my $itn = $HislandTurn;
		my $ddd = $aaa;
		my @ctime;
		while($safety++ < 100) {
			my($sec3, $min3, $hour3, $date3, $mon3, $year3, $day3, $yday3, $dummy3) = gmtime($ddd + $Hjst);
			$mon3++;
			$eee = "${hour3}시";
			$eee.= "${min3}분" if($min3);
			last if($checkTime{$eee});
			push(@ctime, $eee);
			$checkTime{$eee} = $safety;
			if($HflexTimeSet) {
				$itn += $HrepeatTurn;
				$ddd += 3600 * $HflexTime[(($itn/$HrepeatTurn) % ($#HflexTime + 1))];
			} else {
				$ddd += $HunitTime;
			}
		}
		$ddd -= $aaa;
		$ddd /= (3600 * 24);
		if($ddd == 1) {
			@ctime = sort {$a <=> $b} @ctime;
			$ddd = '';
		}
		my $ct = @ctime;
		$eee = "[갱신빈도 ${ct}회/${ddd}일";
		$safety = 0;
		if($ct <= 24) {
			$eee.= ":";
			foreach (@ctime) {
				$eee.= "/" if($safety++);
				if($checkTime{$_} == $ct) {
					$eee.= "<span class='point'>". $_. "</span>";
				} elsif($checkTime{$_} == 1) {
					$eee.= "<span class='number'>". $_. "</span>";
				} else {
					$eee.= $_;
				}
			}
		}
		$eee.= "]";
	}
	out(<<END);
<DIV ID='Turn'>
<H1><SMALL><B>턴</B> </SMALL>$HislandTurn<SMALL>${mode}$HlastTurnS</SMALL></H1>
</DIV>
<DIV class='timer'>$rtStr</DIV>
<DIV ID=nexttime>현재 시간:<b>$sss</b> (다음 갱신 시간:$bbb)</DIV><br>
$repeat
$eee
$Htitler
END

	# 서바이벌 모드 표시
	if($HsurvivalTurn) {
		my($tflag);
		$tflag = int(($HislandTurn - $HsurvivalTurn)/$HturnDead) if($HturnDead);
		$tflag = 0 if($tflag < 0);
		my $turnDead = $HsurvivalTurn + $HturnDead * ($tflag + 1);
		my $sur = ($repeat eq '') ? '<span class=attention>참고: </span>' : '<BR><span class=attention>참고: </span>';
		my $predelNumber = @HpreDeleteID;
		my($rem) = $HislandNumber - $predelNumber - $HbfieldNumber;
		my $ccc = (!$rem) ? 0 : sprintf("%.1f", 50/$rem);
		if($HislandTurn < $HsurvivalTurn) {
			my $sTurn = $HsurvivalTurn + 1;
			$sur.= "${sTurn}턴이후,${HturnDead}턴마다 최하위의 섬이 침몰합니다. 첫 침몰 판정은<span class=attention>$turnDead 턴</span>입니다.<br> (점유율<span class=attention>$ccc%미만</span>라도 침몰합니다)<br>"
		} else {
			$sur.= "${HturnDead}턴마다 최하위의 섬이 침몰합니다. 다음 침몰 판정은<span class=attention>$turnDead 턴</span>입니다.<br> (점유율<span class=attention>$ccc%미만</span>라도 침몰합니다)<br>"
		}
		out("$sur");
	}

}

# '메인 페이지'로그인
sub tempTopLogin {
	my($wNo) = random(1000);
	out(<<END);
<DIV ID='myIsland'>
<H1>자신의 ${AfterName}으로</H1>
<FORM name="Island" action="$HthisFile" method="POST">
내 ${AfterName} 이름은?<BR>
<SELECT NAME="ISLANDID">
<OPTION VALUE="0">-${AfterName}을 선택해 주세요-
$HislandList
</SELECT><BR><BR>
비밀번호 입력<BR>
<INPUT TYPE="hidden" NAME="OwnerButton">
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32 class=f><BR>
<a STYlE="text-decoration:none; color: #000000;" href="javascript: checkOptions(0);">
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $radio2>일반 모드(JS)</a>
<a STYlE="text-decoration:none; color: #000000;" href="javascript: checkOptions(1);">
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi $radio>구 모드</a><BR>
<INPUT TYPE="submit" VALUE="개발 화면으로" onClick="develope()">
<INPUT TYPE="button" VALUE="새 창" onClick="newdevelope()">
</FORM>
<SCRIPT language="JavaScript">
<!--
function checkOptions(i){
	if(document.Island.JAVAMODE[i].checked){
	} else {
		document.Island.JAVAMODE[i].checked = true;
	}
}
function newdevelope(){
//	newWindow$wNo = window.open("", "newWindow$wNo");
	document.Island.target = "newWindow$wNo";
	document.Island.submit();
}
function develope(){
	document.Island.target = "";
}
// -->
</SCRIPT>
</DIV>
END

}

# '메인 페이지'섬의 정보
sub tempTopIslandView {
	my($bfMode) = @_;
	# 0:일반,1:플레이어 섬만,2:전장만

	islandSort($HrankKind, 1);

	out("<DIV ID='islandView' align='center'>");

	out(<<END) if($bfMode < 2);
<A name="View"></A>
<P><H1 style="display:inline;">${AfterName}의 정보</H1>
${AfterName} 이름을 클릭하면,<B>관광</B>할 수 있습니다.
</P>
END

	my($allpop, $island, $j, $pop, $area, $food, $money, $farm, $factory, $mountain, $name, $id, $prize, $ii, $jj, $k);
	my $col = 6;
	my($mapStr)= '';
	if($HoceanMode && $HuseOceanMap) {
		$mapStr1 = "<TH $HbgTitleCell>${HtagTH_}좌표${H_tagTH}</TH>";
		$col++;
	}
	my($sStr1)= '';
	if($HsurvivalTurn) {
		my $predelNumber = @HpreDeleteID;
		my $remainNumber = $islandNumber - $predelNumber;
		foreach $i ($HbfieldNumber..$remainNumber) {
			$allscore += $Hislands[$i]->{$HrankKind};
		}
		$sStr1 = "<TH $HbgTitleCell>${HtagTH_}점유율${H_tagTH}</TH>";
		$col++;
	}
	my($vsith)= '';
	if($Htournament){
		$vsith = "<TH $HbgTitleCell>${HtagTH_}대전 상대${H_tagTH}</TH>";
		$col++;
	}

	my($mStr1) = '';
	if($HhideMoneyMode != 0) {
		$mStr1 = "<TH $HbgTitleCell>${HtagTH_}자금${H_tagTH}</TH>";
		$col++;
	}

	# 주둔보류상황조사
	my(%invade, %shipList);
	my $iFlag = 0;
	foreach $i (0..$islandNumber) {
		my $island = $Hislands[$i];
		my $id = $island->{'id'};
		my $name = islandName($island);
		foreach (@{$island->{'fkind'}}) {
			my($eId, $nFlag, $nNo, $nKind) = (navyUnpack(hex($_)))[0,5..7];
			next if(($HnavySpecial[$nKind] & 0x8) || ($nFlag & 1)); # 군항·잔해는 제외
			if(($eId != $id) && (defined $HidToNumber{$eId})) {
				$invade{"$eId,$id,$nNo"}++;
				$iFlag = 1;
			}
		}
	}
	if($iFlag) {
		foreach (sort { $a cmp $b } keys %invade) {
			my($id,$iId,$iNo) = split(/\,/, $_);
			my $in = $HidToNumber{$iId};
			my $iName = islandName($Hislands[$in]);
			$shipList{$id}.= "<A STYlE=\"text-decoration:none\" href=\"${HthisFile}?Sight=${iId}\" target=\"_blank\">${iName}</A> $Hislands[$in]->{'fleet'}->[$iNo]함대($invade{$_}함)<BR>";
#			$sshipList{$id}.= "${iName} [$Hislands[$in]->{'epoint'}{$id}]\n";
		}
	}

	$HviewIslandCount = 1 if(!$HviewIslandCount);
	$jj = int(($islandNumber + $HviewIslandCount - $HbfieldNumber) / $HviewIslandCount);
	if(($jj> 1) && ($bfMode < 2)) {
		for($ii = 0; $ii < $jj; $ii++) {
			$j = $ii * $HviewIslandCount;
			$k = min($j + $HviewIslandCount, $HislandNumber - $HbfieldNumber);
			$j++;
			$j = "★" if(!$ii && $HbfieldNumber && !$bfMode);

			out(qq|<A href="$HthisFile?View=$ii#View">${HtagNumber_}[$j~$k]${H_tagNumber}</A>&nbsp;|);
		}
	}
	my($pStr1, $nStr1);
	if($HrankKind eq 'point') {
		$pStr1 = "<TH $HbgTitleCell>${HtagTH_}$HpointName${H_tagTH}</TH>";
		$col++;
	}
	if($HnavyName[0] ne '') {
		$nStr1 = "<TH $HbgTitleCell>${HtagTH_}총 획득 경험치${H_tagTH}</TH>";
		$col++;
	}
	out("<TABLE BORDER align='center'>");

	my($head);
	$head = <<"END";
<TR>
<TH $HbgTitleCell>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}${AfterName}${H_tagTH}</TH>
$mapStr1
$sStr1
$vsith
$pStr1
<TH $HbgTitleCell>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}면적${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}농장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}공장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}채굴장 규모${H_tagTH}</TH>
$nStr1
END

	$head.= "<TH $HbgTitleCell>${HtagTH_}타 섬의 파견 함대${H_tagTH}</TH>" if($iFlag);
	$head.= "</TR>";

#	out("$head") if($HbfieldNumber);
	$HviewIslandNumber *= $HviewIslandCount;

	my($start, $end) = ($HviewIslandNumber + $HbfieldNumber, min($HviewIslandNumber + $HviewIslandCount + $HbfieldNumber, $HislandNumber));
	$start = 0 if(!$HviewIslandNumber && $bfMode != 1);
	$end = $HbfieldNumber if($bfMode> 1);

	for($ii = $start; $ii < $end; $ii++) {
		my($tmpHbgNumberCell, $tmpHbgNameCell, $tmpHbgInfoCell, $tmpHbgCommentCell) = ($HbgNumberCell, $HbgNameCell, $HbgInfoCell, $HbgCommentCell);

		$j = $ii + 1 - $HbfieldNumber;
		$island = $Hislands[$ii];
		out("<TR><TH></TH></TR><TR><TH></TH></TR>$head") if(($HbfieldNumber && $j == 1) || ($ii == $start));
		if($Htournament && ($j> $Htournament) || $island->{'predelete'}) {
			($tmpHbgNumberCell, $tmpHbgNameCell, $tmpHbgInfoCell, $tmpHbgCommentCell) = ($HbgNumberCell. 'T', $HbgNameCell. 'T', $HbgInfoCell. 'T', $HbgCommentCell. 'T');
		}
		$id = $island->{'id'};
		$pop = ($island->{'pop'} == 0) ? "무인" : "$island->{'pop'}$HunitPop";
		1 while $pop =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$area = ($island->{'area'} == 0) ? "해역" : "$island->{'area'}$HunitArea";
		1 while $area =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$food = ($island->{'food'} == 0) ? "비축제로" : "$island->{'food'}$HunitFood";
		1 while $food =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$farm = ($island->{'farm'} == 0) ? "보유하지 않음" : "$island->{'farm'}0$HunitPop";
		1 while $farm =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$factory = ($island->{'factory'} == 0) ? "보유하지 않음" : "$island->{'factory'}0$HunitPop";
		1 while $factory =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$mountain = ($island->{'mountain'} == 0) ? "보유하지 않음" : "$island->{'mountain'}0$HunitPop";
		1 while $mountain =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$name = islandName($island);
		if($island->{'field'}) {
			$j = "★";
			$name = "${HtagNumber_}${name}${H_tagNumber}";
		} elsif($island->{'absent'} == 0) {
			$name = "${HtagName_}${name}${H_tagName}";
		} else {
			$name = "${HtagName2_}${name}($island->{'absent'})${H_tagName2}";
		}
		$name.= "${HtagDisaster_}★${H_tagDisaster}" if ($HislandTurn - $island->{'birthday'} <= $HdevelopTurn);
		if($island->{'predelete'}) {
			my $rest = ($island->{'predelete'} != 99999999) ? "<small>(남은$island->{'predelete'}턴)</small>" : '';
			$name = "${HtagDisaster_}[관리자 보관]$rest${H_tagDisaster}<BR>". $name;
		}
		my $event = '';
		if($island->{'event'}[0]) {
			my $type = $HeventName[$island->{'event'}[6]];
			if(($island->{'event'}[1] - $HnoticeTurn <= $HislandTurn) && ($HislandTurn < $island->{'event'}[1])) {
				$event = "${HtagDisaster_}$type${H_tagDisaster}개최!<BR>${HtagNumber_}$island->{'event'}[1]${H_tagNumber}턴~<BR>";
			} elsif($island->{'event'}[1] <= $HislandTurn) {
				my $rest = $island->{'event'}[1] + $island->{'event'}[2] - $HislandTurn;
				if($rest> 0) {
					$rest = "남은${HtagNumber_}${rest}${H_tagNumber}턴";
				} else {
					$rest = 1 - $rest;
					$rest = "동점입니다(${HtagNumber_}${rest}${H_tagNumber})";
				}
				$event = "${HtagDisaster_}$type${H_tagDisaster}개최안!<BR>$rest<BR>";
			}
		}
		$name = $event. $name;
		$prize = $island->{'prize'};
		$prize =~ /([0-9]*),([0-9]*),([0-9]*),(.*)/;
		my($flags, $monsters, $hmonsters, $turns) = ($1, $2, $3, $4);
		$prize = '';

		my($i, $s, $ss);

		#아이템의 표시
		foreach (@{$island->{'item'}}) {
			next if($_ == 0);
			$prize.= "<IMG SRC=\"$HitemImage[$_]\" TITLE=\"$HitemName[$_]\" onMouseOver='status=\"$HitemName[$_]\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16> ";
		}


		# 남은 턴 표시
		$s = '';
		my @turnPrize = reverse(split(/,/, $turns));
		$i = 0;
		foreach (@turnPrize) {
			last if($i> 3);
			$s.= "\n" if($i++);
			$s.= "$_${Hprize[0]->{'name'}}";
		}
		my $tNum = @turnPrize;
		$s.= ($i < $tNum ? "\n타,${tNum}회 수상" : "\n이상${tNum}회 수상") if($tNum);
		$ss = $s;
		my $rt = "\n";
		$ss =~ s/$rt/ /g;
		$prize.= "<IMG SRC=\"prize0.gif\" TITLE=\"${s}\" onMouseOver='status=\"${ss}\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16> " if($s ne '');

		# 섬 이름에 명칭번호를 추가
		my($f) = 2;
		my($max) = -1;
		my($wintitle, $winmark);
		if($HitemComplete == $island->{'id'}) {
			$max = 0;
			$wintitle = "[${HwinnerTitle[0]}]";
			$winmark = "<IMG SRC=\"${HwinnerMark[0]}\" style=\"border-width: 0px;\" TITLE=\"${HwinnerTitle[0]}\" onMouseOver='status=\"${HwinnerTitle[0]}\"; return true;' onMouseOut=\"status = '';\">";
		}
		if($island->{'ext'}[0]) {
			foreach (1..$#HwinnerTitle) {
				if($island->{'ext'}[0] & $f) {
						$max = $_;
						$wintitle.= "\n" if($wintitle ne '');
						$wintitle.= "[${HwinnerTitle[$_]}]";
						$winmark.= "<IMG SRC=\"${HwinnerMark[$_]}\" style=\"border-width: 0px;\" TITLE=\"${HwinnerTitle[$_]}\" onMouseOver='status=\"${HwinnerTitle[$_]}\"; return true;' onMouseOut=\"status = '';\">";
				}
				$f *= 2;
			}
		}
		if($max != -1) {
			if($HviewMarkOne) {
				$winmark = "<IMG SRC=\"${HwinnerMark[$max]}\" style=\"border-width: 0px;\" TITLE=\"${wintitle}\" ";
				$wintitle =~ s/$rt//g;
				$winmark.= "onMouseOver='status=\"${wintitle}\"; return true;' onMouseOut=\"status = '';\">";
			}
			$winmark.= '<BR>';
		}
		# 이름에 순위 표시 문자를 추가
		$f = 1;
		$s = '';
		foreach(1..$#Hprize) {
			if($flags & $f) {
				$s.= "<IMG SRC=\"prize${_}.gif\" TITLE=\"${Hprize[$_]->{'name'}}\" onMouseOver='status=\"${Hprize[$_]->{'name'}}\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16>";
			}
			$f *= 2;
		}
		$prize.= $s;

		# 격파했습니다 섬 이름을 추가
		$s = '';
		my @defeat = @{$island->{'defeat'}};
		for($i = 0; $i < $#defeat; $i+=2) {
			$s.= "\n" if($i);
			$s.= $defeat[$i]. '('. $defeat[$i+1]. ')';
		}
		$s =~ s/<FONT COLOR=\"[\w\#]+\"><B>(.*)<\/B><\/FONT>/$1/g;
		$s =~ s/<[^<]*>//g;
		$ss = $s;
		$ss =~ s/$rt/ /g;
		$f = @defeat / 2;
		$prize.= "<span class='point'><IMG SRC=\"land13.gif\" TITLE=\"${s}\" onMouseOver='status=\"${ss}\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16>$f$AfterName 격파</span> " if($s ne '');

		# 쓰러뜨린 괴수 목록
		$f = 1;
		$s = '';
		$max = -1;
		my($mNameList) = '';
		my $hflag = 0;
		for($i = 0; $i < $HmonsterNumber; $i++) {
			if($monsters & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HmonsterName[$i]]";
				$max = $i;
#				$s.= "<IMG SRC=\"${HmonsterImage[$i]}\" ALT=\"$HmonsterName[$i]\" WIDTH=16 HEIGHT=16> ";
			}
			$f *= 2;
		}
		$f = 1;
		for($i = 0; $i < $HhugeMonsterNumber; $i++) {
			if($hmonsters & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HhugeMonsterName[$i]]";
				$max = $i;
				$hflag = 1;
#				$s.= "<IMG SRC=\"${HhugeMonsterImageS[$i]}\" ALT=\"$HhugeMonsterName[$i]\" WIDTH=16 HEIGHT=16> ";
			}
			$f *= 2;
		}
		if($max != -1) {
			my $image = ($hflag ? $HhugeMonsterImageS[$max] : $HmonsterImage[$max]);
			$s.= " <span class='monsm'><IMG SRC=\"${image}\" TITLE=\"$mNameList\" ";
			$mNameList =~ s/$rt//g;
			$s.= "onMouseOver='status=\"$mNameList\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16>$island->{'monsterkill'}$HunitMonster 퇴치</span> ";

			$prize.= $s;
		}


		# 출현 중인 괴수 목록
		my $monsterlive = $island->{'monsterlive'};
		$monsterlive =~ /([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)/;
		my($monslive, $monstertype, $hmonstertype, $unknownlive, $unknowntype) = ($1, $2, $3, $4, $5);
		$f = 1;
		$s = '';
		$max = -1;
		$mNameList = '';
		$hflag = 0;
		for($i = 0; $i < $HmonsterNumber; $i++) {
			if($monstertype & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HmonsterName[$i]] ";
				$max = $i;
			}
			$f *= 2;
		}
		$f = 1;
		for($i = 0; $i < $HhugeMonsterNumber; $i++) {
			if($hmonstertype & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HhugeMonsterName[$i]]";
				$max = $i;
				$hflag = 1;
			}
			$f *= 2;
		}
		if($max != -1) {
			my $image = ($hflag ? $HhugeMonsterImageS[$max] : $HmonsterImage[$max]);
			$s.= " <span class='unemploy2'><IMG SRC=\"${image}\" TITLE=\"$mNameList\" ";
			$mNameList =~ s/$rt//g;
			$s.= "onMouseOver='status=\"$mNameList\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16>$monslive$HunitMonster 출현안!</span> ";

			$prize.= $s;
		}
		# 소속 불명 함정
		$f = 1;
		$s = '';
		$max = -1;
		$mNameList = '';
		foreach (0..$#HnavyName) {
			if($unknowntype & $f) {
				$mNameList.= "\n" if($mNameList ne '');
				$mNameList.= "[$HnavyName[$_]] ";
				$max = $_;
			}
			$f *= 2;
		}
		if($max != -1) {
			my $image = $HnavyImage[$max];
			$s.= " <span class='unemploy2'><IMG SRC=\"${image}\" TITLE=\"$mNameList\" ";
			$mNameList =~ s/$rt//g;
			$s.= "onMouseOver='status=\"$mNameList\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16>$unknownlive 척 출현 중!</span> ";

			$prize.= $s;
		}
		$prize = ' ' if($prize eq '');

		$mapStr = '';
		if($HoceanMode && $HuseOceanMap) {
			$mapStr1 = "<TD $tmpHbgInfoCell align=right><a href='$HthisFile?OceanMap=$island->{'id'}' style='text-decoration: none;'><B>($island->{'wmap'}->{'x'}, $island->{'wmap'}->{'y'})</B></a></TD>";
		}
		$sStr1 = '';
		if($HsurvivalTurn) {
#			my $occupation = $allscore ? int((100 * $island->{'pop'})/$allscore) : 0;
#			$occupation = 100 if($occupation> 100);
			my $occupation = $allscore ? sprintf("%.1f", (100 * $island->{'pop'})/$allscore) : 0;
			$occupation = "100.0" if($occupation> 100);
			$sStr1 = "<TD $tmpHbgInfoCell align=right>${occupation}%</TD>";
			$sStr1 = "<TD $tmpHbgInfoCell align=right>-</TD>" if($island->{'field'} || $island->{'predelete'});
		}
		my($vsith)= '';
		if($Htournament){
			my $tName = "";
			my $ps = 'center';
			if($island->{'field'}) {
				$tName = "<B>---</B>";
			} elsif($HislandFightMode == 9) {
				$tName = "<B>- 종료 -</B>";
			} elsif($island->{'rest'}) {
				$tName = "<B>부전승</B><small> 개발 정지:남은 </small>${HtagDisaster_}$island->{'rest'}${H_tagDisaster}";
				$ps = 'right';
			} elsif($island->{'fight_id'} == -2) {
				$tName = "<B>- 압승! -</B>";
			} elsif($island->{'fight_id'} == -1) {
				$tName = "<B>- 부전승 -</B>";
			} elsif($island->{'predelete'}) {
				$tName = "<B>- 패배 -</B>";
			} elsif($island->{'fight_id'} == 0) {
				$tName = "<B>- 미정 -</B>";
			} else {
				my $tn = $HidToNumber{$island->{'fight_id'}};
				if($tn eq '') {
					$tName = "<B>- 미정 -</B>";
				} else {
					my $tIsland = $Hislands[$tn];
					$tName = islandName($tIsland);
					$tName = "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=$tIsland->{'id'}\"><B>$tName</B></A>";
					$ps = 'center';
				}
			}
			$vsitd = "<TD $tmpHbgNameCell align=$ps>$tName</TD>";
		}
		 $mStr1 = '';
		if($HhideMoneyMode == 1) {
			$money = ($island->{'money'} == 0) ? "자금 없음" : "$island->{'money'}$HunitMoney";
			1 while $money =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$mStr1 = "<TD $tmpHbgInfoCell align=right>$money</TD>";
		} elsif($HhideMoneyMode == 2) {
			my($mTmp) = aboutMoney($island->{'money'});
			1 while $mTmp =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$mStr1 = "<TD $tmpHbgInfoCell align=right>$mTmp</TD>";
		}
		my $preab = ($island->{'preab'} ? '<br><small><span class=attention>(진영개발 가능)</span></small>' : '');

		out(<<END);
<TR>
<TD $tmpHbgNumberCell ROWSPAN=3 align=center>${HtagNumber_}$j${H_tagNumber}</TD>
<TD $tmpHbgNameCell ROWSPAN=3 align=left>
<A STYlE="text-decoration:none" HREF="${HthisFile}?Sight=${id}" TITLE="ID=${id}">
$winmark$name
</A>$preab
END

		my $ownerName = (($island->{'owner'} eq '') || $island->{'field'}) ? '코멘트' : "<A TITLE='소유자'>$island->{'owner'}</A>";
		my $navyComLevel = gainToLevel($island->{'gain'});
		my $totalExp = $island->{'gain'};
		1 while $totalExp =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$totalExp.= "(Lv.${navyComLevel})" if($HmaxComNavyLevel);
		$pStr1 = '';
		if($HrankKind eq 'point') {
			my $point = $island->{'point'};
			1 while $point =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$pStr1 = "<TD $tmpHbgInfoCell align=right>$point$HpointAfter</TD>";
		}
		$nStr1 = '';
		if($HnavyName[0] ne '') {
			$nStr1 = "<TD $tmpHbgInfoCell align=right>$totalExp</TD>";
		}

		out(<<END);
</TD>
$mapStr1
$sStr1
$vsitd
$pStr1
<TD $tmpHbgInfoCell align=right>$pop</TD>
<TD $tmpHbgInfoCell align=right>$area</TD>
$mStr1
<TD $tmpHbgInfoCell align=right>$food</TD>
<TD $tmpHbgInfoCell align=right>$farm</TD>
<TD $tmpHbgInfoCell align=right>$factory</TD>
<TD $tmpHbgInfoCell align=right>$mountain</TD>
$nStr1
END

		my $slist = ($shipList{$id}) ? $shipList{$id} : ' ';
		out("<TD $tmpHbgInfoCell ROWSPAN=3 align=left valign=top>$slist</TD>") if($iFlag);
#HdebugOut("------- $HislandTurn -------\n$sshipList{$id}\n") if($island->{'event'}[0]);
		out(<<END);
</TR>
<TR>
<TD $tmpHbgCommentCell COLSPAN="$col" align=left>${HtagTH_}$ownerName:${H_tagTH}$island->{'comment'}</TD>
</TR>
<TR>
<TD $tmpHbgCommentCell COLSPAN="$col" align=left>$prize</TD>
</TR>
END
		if($Htournament) {
			my $colT = $col + 2;
			$colT++ if($iFlag);
			if(($j == $Htournament) && ($HislandTurn < $HyosenTurn)) {
				out("<TR><TH colspan=$colT><FONT SIZE=+1 COLOR=#C00000><i>- 예선통과 라인 -</I></FONT></TH></TR>");
				out("$head") if($ii < $end - 1);
			}
		}
	}

	out("</TABLE>");
	out(" <B>참고: </B>새로 발견된 ${AfterName}은 ${AfterName} 이름 오른쪽 끝에 ${HtagDisaster_}★${H_tagDisaster} 표시가 지급됩니다. ${HtagDisaster_}★${H_tagDisaster} 표시가 사라질 시까지는 개발에 전념해 주세요.") if($HdevelopTurn && ($bfMode < 2));
	out("</DIV>");

}

# 기록 파일 표시
sub historyPrint {
	open(HIN, "${HdirName}/hakojima.his");
	my(@line, $l);
	while($l = <HIN>) {
		chomp($l);
		push(@line, $l);
	}
	@line = reverse(@line);

#	my($this, $next);
	foreach $l (@line) {
		$l =~ /^([0-9]*),(.*)$/;
		out("${HtagNumber_}<small>턴</small>${1}${H_tagNumber}:${2}<BR>\n");
#		$next = $1;
#		my($str) = $2;
#		if($this != $next) {
#			out("${HtagNumber_}턴 ${next}${H_tagNumber} ---<BR>\n");
#			$this = $next;
#		}
#		out(" $str<BR>\n");
	}
	close(HIN);
}

# 동맹 정보
sub amityOfAlly() {
	# 화면 출력
	unlock();

	my $ally = $Hally[$HidToAllyNumber{$HallyID}];
	my $allyName = "<FONT COLOR=\"$ally->{'color'}\"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}";

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='campInfo'>
<H1>$allyName 의 정보</H1>
END

	allyInfo($HallyID) if($ally->{'number'});

	my($mStr1) = '';
	my $col = 9;
	if($HhideMoneyMode != 0) {
		$mStr1 = "<TH $HbgTitleCell>${HtagTH_}자금${H_tagTH}</TH>";
		$col++;
	}
	if($ally->{'message'} ne '') {
		my $allyTitle = $ally->{'title'};
		$allyTitle = '맹주의 메시지' if($allyTitle eq '');
		my $allyMessage = $ally->{'message'};
		$allyMessage =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#\%]+)/$1<a href=\"$2\" target='_top'>$2<\/a>/g;
		out(<<END);
<HR>
<TABLE BORDER width=80%>
<TR><TH $HbgTitleCell>${HtagTH_}$allyTitle${H_tagTH}</TH></TR>
<TR><TD $HbgInfoCell><blockquote>$allyMessage</blockquote></TD></TR>
</TABLE>
END
	}

	my($pStr1);
	if($HrankKind eq 'point') {
		$pStr1 = "<TH $HbgTitleCell>${HtagTH_}$HpointName${H_tagTH}</TH>";
		$col++;
	}

	out(<<END);
<HR>
<TABLE BORDER><TR>
<TH $HbgTitleCell>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}${AfterName}${H_tagTH}</TH>
$pStr1
<TH $HbgTitleCell>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}면적${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}농장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}공장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}채굴장 규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}총 획득 경험치${H_tagTH}</TH>
</TR>
END
	out("<TR><TH colspan=$col>소속하고 있는$AfterName 없습니다!</TH></TR>") if(!$ally->{'number'});

	my($id, $number, $island, $pop, $area, $food, $money, $farm, $factory, $mountain, $name, $mStr2, $navyComLevel, $totalExp);
	foreach (@{$ally->{'memberId'}}) {
		$id = $_;
		$number = $HidToNumber{$id};
		$island = $Hislands[$number];
		$number += (1 - $HbfieldNumber);
		$pop = ($island->{'pop'} == 0) ? "무인" : "$island->{'pop'}$HunitPop";
		1 while $pop =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$area = ($island->{'area'} == 0) ? "해역" : "$island->{'area'}$HunitArea";
		1 while $area =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$food = ($island->{'food'} == 0) ? "비축제로" : "$island->{'food'}$HunitFood";
		1 while $food =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$farm = ($island->{'farm'} == 0) ? "보유하지 않음" : "$island->{'farm'}0$HunitPop";
		1 while $farm =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$factory = ($island->{'factory'} == 0) ? "보유하지 않음" : "$island->{'factory'}0$HunitPop";
		1 while $factory =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$mountain = ($island->{'mountain'} == 0) ? "보유하지 않음" : "$island->{'mountain'}0$HunitPop";
		1 while $mountain =~ s/(.*\d)(\d\d\d)/$1,$2/;
		# 섬 이름에 명칭번호를 추가(미사용·$name 의전에$winner 을붙이면 됩니다)
		my($rt) = "\n";
		my($f) = 2;
		my($max) = -1;
		my($wintitle, $winmark);
		if($HitemComplete == $island->{'id'}) {
			$max = 0;
			$wintitle = "[${HwinnerTitle[0]}]";
			$winmark = "<IMG SRC=\"${HwinnerMark[0]}\" style=\"border-width: 0px;\" TITLE=\"${HwinnerTitle[0]}\" onMouseOver='status=\"${HwinnerTitle[0]}\"; return true;' onMouseOut=\"status = '';\">";
		}
		if($island->{'ext'}[0]) {
			foreach (1..$#HwinnerTitle) {
				if($island->{'ext'}[0] & $f) {
						$max = $_;
						$wintitle.= "\n" if($wintitle ne '');
						$wintitle.= "[${HwinnerTitle[$_]}]";
						$winmark.= "<IMG SRC=\"${HwinnerMark[$_]}\" style=\"border-width: 0px;\" TITLE=\"${HwinnerTitle[$_]}\" onMouseOver='status=\"${HwinnerTitle[$_]}\"; return true;' onMouseOut=\"status = '';\">";
				}
				$f *= 2;
			}
		}
		if($HviewMarkOne && ($max != -1)) {
			$winmark = "<IMG SRC=\"${HwinnerMark[$max]}\" style=\"border-width: 0px;\" TITLE=\"${wintitle}\" ";
			$wintitle =~ s/$rt//g;
			$winmark.= "onMouseOver='status=\"${wintitle}\"; return true;' onMouseOut=\"status = '';\">";
		}
		$name = islandName($island);
		if($island->{'field'}) {
			$number = "★";
			$name = "${HtagNumber_}${name}${H_tagNumber}";
		} elsif($island->{'absent'} == 0) {
			$name = "${HtagName_}${name}${H_tagName}";
		} else {
			$name = "${HtagName2_}${name}($island->{'absent'})${H_tagName2}";
		}
		$name.= "${HtagDisaster_}★${H_tagDisaster}" if ($HislandTurn - $island->{'birthday'} <= $HdevelopTurn);
		if($island->{'predelete'}) {
			my $rest = ($island->{'predelete'} != 99999999) ? "<small>(남은$island->{'predelete'}턴)</small>" : '';
			$name = "${HtagDisaster_}[관리자 보관]$rest${H_tagDisaster}<BR>". $name;
		}
		$mStr2 = '';
		if($HhideMoneyMode == 1) {
			$money = ($island->{'money'} == 0) ? "자금 없음" : "$island->{'money'}$HunitMoney";
			1 while $money =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$mStr2 = "<TD $HbgInfoCell align=right>$money</TD>";
		} elsif($HhideMoneyMode == 2) {
			my($mTmp) = aboutMoney($island->{'money'});
			1 while $mTmp =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$mStr2 = "<TD $HbgInfoCell align=right>$mTmp</TD>";
		}
		$navyComLevel = gainToLevel($island->{'gain'});
		$totalExp = $island->{'gain'};
		1 while $totalExp =~ s/(.*\d)(\d\d\d)/$1,$2/;
		$totalExp.= "(Lv.${navyComLevel})" if($HmaxComNavyLevel);
		my($pStr2);
		if($HrankKind eq 'point') {
			my $point = $island->{'point'};
			1 while $point =~ s/(.*\d)(\d\d\d)/$1,$2/;
			$pStr2 = "<TD $HbgInfoCell align=right>$point$HpointAfter</TD>";
			$col++;
		}

	out(<<END);
<TR>
<TD $HbgNumberCell align=center>${HtagNumber_}$number${H_tagNumber}</TD>
<TD $HbgNameCell align=left>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
$name
</A></TD>
$pStr2
<TD $HbgInfoCell align=right>$pop</TD>
<TD $HbgInfoCell align=right>$area</TD>
$mStr2
<TD $HbgInfoCell align=right>$food</TD>
<TD $HbgInfoCell align=right>$farm</TD>
<TD $HbgInfoCell align=right>$factory</TD>
<TD $HbgInfoCell align=right>$mountain</TD>
<TD $HbgInfoCell align=right>$totalExp</TD>
</TR>
END
	}

	my @member = @{$ally->{'memberId'}};
	if(!$HarmisticeTurn && $ally->{'number'} && $HuseAmity) {
		out(<<END);
</TABLE>
<HR>
<span class='number'>◎</span>:친구좋음(상대상호)
<span class='number'>○</span>:친구좋음
${HtagDisaster_}X${H_tagDisaster}:교전쟁(선전포고)
${HtagDisaster_}x${H_tagDisaster}:교전쟁(피선전포고)
-:안설립
<TABLE BORDER><TR>
<TH $HbgTitleCell>${HtagTH_}우호국 설정${H_tagTH}</TH>
END

		foreach (@member) {
			$number = $HidToNumber{$_};
			$island = $Hislands[$number];
			$name = islandName($island);
			out(<<END);
<TD class='T'>$name</TD>
END
		}
		out("</TR>");
		my($i, %warFlag, $id);
		for($i=0;$i < $#HwarIsland;$i+=4){
			my($id1) = $HwarIsland[$i+1];
			my($id2) = $HwarIsland[$i+2];
			my($tn1) = $HidToNumber{$id1};
			my($tn2) = $HidToNumber{$id2};
			next if(($tn1 eq '') || ($tn2 eq ''));
			$warFlag{"$id1,$id2"} = 1;
		}
		foreach $id (@member) {
			$number = $HidToNumber{$id};
			$island = $Hislands[$number];
			$name = islandName($island);
			my($amity, %amityFlag, $aId);
			$amity = $island->{'amity'};
			foreach (@$amity) {
				$amityFlag{$_} = 1;
			}
			out("<TR><TH $HbgTitleCell>$name</TH>\n");
			foreach $aId (@member) {
				my($tAmity, %tAmityFlag);
				$tAmity = $Hislands[$HidToNumber{$aId}]->{'amity'};
				foreach (@$tAmity) {
					$tAmityFlag{$_} = 1;
				}
				if($id == $aId) {
					out("<TD align='center'>=</TD>\n");
				} elsif($amityFlag{$aId}) {
					if($tAmityFlag{$id}) {
						out("<TD align='center'><span class='number'>◎</span></TD>\n");
					} else {
						out("<TD align='center'><span class='number'>○</span></TD>\n");
					}
				} elsif($warFlag{"$id,$aId"}) {
					out("<TD align='center'>${HtagDisaster_}X${H_tagDisaster}</TD>\n");
				} elsif($warFlag{"$aId,$id"}) {
					out("<TD align='center'>${HtagDisaster_}x${H_tagDisaster}</TD>\n");
				} else {
					out("<TD align='center'>-</TD>\n");
				}
			}
			out("</TR>\n");
		}
	}
	out("</TABLE>");

	if(($HallyVetoUse == 2) && !$HarmisticeTurn) {
		my $vetoStr = (!$ally->{'vkind'}) ? '<FONT COLOR="#0000FF">거부</FONT>' : '<FONT COLOR="#FF0000">허가</FONT>';
		my $vetoMark = (!$ally->{'vkind'}) ? '<FONT COLOR="#0000FF">×</FONT>' : '<FONT COLOR="#FF0000">○</FONT>';
		out(<<END);
<HR>
<TABLE BORDER><TR>
<TH $HbgTitleCell>${HtagTH_}이 동맹 가입이 ${vetoStr}된 $AfterName${H_tagTH}</TH>
</TR><TR>
<TD class='C' align=left>
END

		my $flag = 0;
		foreach (@{$ally->{'vetoId'}}) {
			my $n = $HidToNumber{$_};
			next unless(defined $n);
			my $name = islandName($Hislands[$n]);
			out("<span class='check'><B>$vetoMark</B>$name</span> ");
#			out("$name<BR>");
			$flag = 1;
		}
		out("해당하는 $AfterName이 없습니다!") if(!$flag);
		out("</TD></TR></TABLE>");
	}
}

# 동맹의 상황
sub allyInfo() {
	my($num) = @_;

	my %rankKind = (
		'pop' => '총인구',
		'gain' => '총 획득 경험치',
		'money' => '총자금',
		'food' => '총식량',
		'area' => '총면적',
		'farm' => '총 농장 규모',
		'factory' => '총 공장 규모',
		'mountain' => '총채굴장 규모',
		'monsterkill' => '총괴수 퇴치 수',
		'itemNumber' => "총 $HitemName[0] 획득 수",
		'point' => "총$HpointName",
	);
	my %rankAfter = (
		'pop' => "$HunitPop",
		'gain' => '',
		'money' => "$HunitMoney",
		'food' => "$HunitFood",
		'area' => "$HunitArea",
		'farm' => "0$HunitPop",
		'factory' => "0$HunitPop",
		'mountain' => "0$HunitPop",
		'monsterkill' => "$HunitMonster",
		'itemNumber' => '',
		'point' => "$HpointAfter",
	);
	my $aStr = ($HarmisticeTurn) ? '진영' : '동맹';
	if($num == -1) {
		out(<<END);
<DIV ID='campInfo'>
<P><H1 style="display:inline;">각 동맹 정보</H1>
END
	} else {
		out("<P>");
	}

	out(<<END);
점유율은 <B>$rankKind{$HrankKind}</B>을 기준으로 산출됩니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}${aStr}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}표시${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}${AfterName}의 수${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}$rankKind{$HrankKind}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}점유율${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}탄환 발사${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}날아온 탄환${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}함정 파견${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}함정 피격${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}GNP${H_tagTH}</TH>
</TR>
END

	my $allyNumber = $HallyNumber - 1;
	foreach (0..$allyNumber) {
		next if(($num != -1) && ($_ != $HidToAllyNumber{$num}));
		my($n) = $_ + 1;
		my($ally) = $Hally[$_];
		my($score) = ($ally->{'score'} == 0) ? "없음" : "$ally->{'score'}$rankAfter{$HrankKind}";
		1 while $score =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my($missileOut) = ($ally->{'ext'}[0] == 0) ? "없음" : "$ally->{'ext'}[0]발";
		1 while $missileOut =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my($missileIn) = ($ally->{'ext'}[1] == 0) ? "없음" : "$ally->{'ext'}[1]발";
		1 while $missileIn =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my($navyOut) = ($ally->{'ext'}[3] == 0) ? "없음" : "$ally->{'ext'}[3]함";
		1 while $navyOut =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my($navyIn) = ($ally->{'ext'}[4] == 0) ? "없음" : "$ally->{'ext'}[4]함";
		1 while $navyIn =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my($gnp) = "$ally->{'ext'}[2]${HunitMoney}";
		1 while $gnp =~ s/(.*\d)(\d\d\d)/$1,$2/;
		my $owner = $HidToNumber{$ally->{'id'}};
		my $row = 2;
		# 명칭번호를 추가
		my($f) = 2;
		my($max) = -1;
		my($wintitle, $winmark);
		if($ally->{'ext'}[5]) {
			foreach (1..$#HwinnerTitle) {
				if($ally->{'ext'}[5] & $f) {
						$max = $_;
						$wintitle.= "\n" if($wintitle ne '');
						$wintitle.= "[${HwinnerTitle[$_]}]";
						$winmark.= "<IMG SRC=\"${HwinnerMark[$_]}\" style=\"border-width: 0px;\" TITLE=\"${HwinnerTitle[$_]}\" onMouseOver='status=\"${HwinnerTitle[$_]}\"; return true;' onMouseOut=\"status = '';\">";
				}
				$f *= 2;
			}
		}
		if($max != -1) {
			if($HviewMarkOne) {
				$winmark = "<IMG SRC=\"${HwinnerMark[$max]}\" style=\"border-width: 0px;\" TITLE=\"${wintitle}\" ";
				$wintitle =~ s/$rt//g;
				$winmark.= "onMouseOver='status=\"${wintitle}\"; return true;' onMouseOut=\"status = '';\">";
			}
			#$winmark.= '<BR>';
		}
		if(defined $owner) {
			$owner = islandName($Hislands[$owner]);
		} else {
			$row = 1;
		}
		my $name;
		if($num == -1) {
			$name = "<A style=\"text-decoration:none\" href=\"$HthisFile?AmiOfAlly=$ally->{'id'}\">$ally->{'name'}</A>";
		} else {
			$name = $ally->{'name'};
		}
		my $comment = $ally->{'comment'};
		out(<<END);
<TR>
<TD $HbgNumberCell rowspan=$row align=center>${HtagNumber_}$n${H_tagNumber}</TD>
<TD $HbgInfoCell rowspan=$row align=center>$winmark$name</TD>
<TD $HbgInfoCell align=center><B><FONT COLOR="$ally->{'color'}">$ally->{'mark'}</FONT></B></TD>
<TD $HbgInfoCell align=right>$ally->{'number'}${AfterName}</TD>
<TD $HbgInfoCell align=right>$score</TD>
<TD $HbgInfoCell align=right>$ally->{'occupation'}\%</TD>
<TD $HbgInfoCell align=right>$missileOut</TD>
<TD $HbgInfoCell align=right>$missileIn</TD>
<TD $HbgInfoCell align=right>$navyOut</TD>
<TD $HbgInfoCell align=right>$navyIn</TD>
<TD $HbgInfoCell align=right>$gnp</TD>
</TR>
END
		out(<<END) if($row == 2);
<TR>
<TD $HbgCommentCell colspan=9><A style="text-decoration:none" href="$HthisFile?Allypact=$ally->{'id'}">${owner}</A>:$comment</TD>
</TR>
END
	}

	out("</TABLE>");
	out("</DIV>") if($num == -1);
}

1;
