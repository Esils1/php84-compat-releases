동맹 게시판 for Hakoniwa

이'게시판'은 KENT WEB(http://www.kent-web.com/)의 스크립트를 개조한 것이므로, 아래 내용의 이용규정에승낙하다필요합니다.

CGI 스크립트이용규정 http://www.kent-web.com/pubc/kitei.html

참고: 나가네코님(http://ug.1st.to/)의 접속 분석 스크립트를 개조한 것도 동봉되어 있습니다.
 참고로, 나가네코님에서는 재배포에 대해고쾌적승낙있었음다있고 있습니다. 또한,KENT 님에는 재배포할취지메일을 발사완료입니다.

참고: 이스크립트에 관계하고는, 무단재배포를 금지합니다.otacky2000@yahoo.co.jp
