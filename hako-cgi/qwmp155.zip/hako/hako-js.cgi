#----------------------------------------------------------------------
# JAVA ��ũ��Ʈ�� -ver1. 11-
# ��� ����, ��� �������, ���������� Ȯ���� �ּ���.
# �μ��� js-readme.txt�� �о� �ּ���.
#����http://appoh.execweb.cx/hakoniwa/
#----------------------------------------------------------------------
# �������� ���� �� N v1. 54 ��Ƽ��
#----------------------------------------------------------------------

# Ŀ���
$HcommandTotal = 42; # Ŀ����� ����

# Ŀ��� ����
# �� Ŀ��� ���Ҹ���, �ڵ� �Է°��� Ŀ���� �������� ������.�
@HcommandDivido = 
	(
	'����,0,6',   # ��ȹ ��ȣ 0~ 6
	'�Ǽ�,7,30',  # ��ȹ ��ȣ 7~30
	'����,31,40', # ��ȹ ��ȣ 31~40
	'�,41,60'  # ��ȹ ��ȣ 41~60
	);
# ���ǣ������̽��� �� ��  ����
# �ۡ�	'����, 0,10',  # ��ȹ ��ȣ 00~10
# ����	'����, 0  , 10  ',  # ��ȹ ��ȣ 00~10

# ����
@HcomList =
	($HcomPrepare, $HcomSell, $HcomPrepare2, $HcomReclaim, $HcomDestroy,
	$HcomPlant, $HcomFarm, $HcomFarm2, $HcomFactory, $HcomFactory2, $HcomMountain,
	$HcomBase, $HcomDbase, $HcomSbase, $HcomMonument, $HcomArea,
	$HcomSupply, $HcomDraft, $HcomInfantry, $HcomWithdraw, $HcomUnitOrder, $HcomItem, $HcomSoldier, $HcomSoldier2,
	$HcomDeWar, $HcomCeasefire, $HcomMissileNM, $HcomMissilePP, $HcomMissileDM, $HcomMissileHM, $HcomMissileBM,
	$HcomMissileLD, $HcomSendMonster, $HcomDoNothing,
	$HcomMoney, $HcomFood, $HcomPropaganda, $HcomGiveup, $HcomAmity,
	$HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoDelete);

unless($Hnoarmy){
	# ���� ���� ���
	splice(@HcomList,16,8);# ���� �����ϸ� ��߳��Ƿ� ����
	$HcommandTotal -= 8;
}

# ���� ȭ�� ������Ʈ �����̽��
my $r = random(100);
$advice = $HcomMsg[$r];
if($advice eq ""){
	@advice2 = (
	'¡���� �Է� ��, ������ 22�� �����ϸ顸7õ �̻� ��� ¡������ �˴ϴ�. ',
	'�� �����⸦ �Է� ��, ������ 22�� �����ϸ� ��Ȳ���� ��� �� �����⡹�� �˴ϴ�. ',
	'���� Ű�� ���� Ű������ ��9���� �Է��ϸ� ������ ��250���� �˴ϴ�. '
	);
	$advice = "��" . $advice2[random(3)];
}else{
	$advice = "�ء�Ŀ��� ���� ���� ��" . $HcomName[$r] . "��\n$advice";
}
#----------------------------------------------------------------------
# Ja��a��ũ��Ʈ ���� ȭ��
#----------------------------------------------------------------------
# 00�� ���� ��ȹ
sub tempOwnerJava {
	$HjavaMode = 'java' if($HjavaMode eq '' && $HjavaModeSet eq 'java');# ��� ������ ������ ��Ű�κ��� ���
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($id) = $island->{'id'};
	my($i,$x,$y);
	#Ŀ��� ��Ʈ�
	$set_com = "";
	$com_max = "";
	for($i = 0; $i < $HcommandMax; $i++) {
		# �� ����� ����
		my($command) = $island->{'command'}->[$i];
		my($s_kind, $s_target, $s_x, $s_y, $s_arg) = 
		(
		$command->{'kind'},
		$command->{'target'},
		$command->{'x'},
		$command->{'y'},
		$command->{'arg'}
		);
		# Ŀ��� ���
		if($i == $HcommandMax-1){
			$set_com .= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\n";
			$com_max .= "[0,0]";
		}else{
			$set_com .= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\,\n";
			$com_max .= "[0,0],";
		}
	}
	#  ���� Ű�� ����
	$keyName[$HcomPrepare2]	= "(Z)";
	$keyName[$HcomPlant]	= "(S)";
	$keyName[$HcomReclaim]	= "(U)";
	$keyName[$HcomDestroy]	= "(K)";
	$keyName[$HcomFarm]		= "(N)";
	$keyName[$HcomFactory]	= "(F)";
	$keyName[$HcomPresent]	= "(P)";
#	$keyName[$HcomBase]		= "(B)"; # ������� ������ ǥ������ �ʴ´�
	$keyName[$HcomDbase]	= "(D)";
	$keyName[$HcomArea]		= "(R)";
	$keyName[$HcomDraft]	= "(C)";
	$keyName[$HcomInfantry]	= "(G)";
	$keyName[$HcomWithdraw]	= "(T)";
	$keyName[$HcomSupply]	= "(H)";
	$keyName[$HcomMissilePP]= "(M)";

	#Ŀ��� ����Ʈ ��Ʈ
	my($l_kind,$str);
	$set_listcom = "";
	$click_com = "";
	$click_com2 = "";
	$click_com3 = "";
	$click_com4 = "";
	$ItemList = "";
	$ListIx = -1;

	$All_listCom = 0;
	$com_count = @HcommandDivido;
	for($m = 0; $m < $com_count; $m++) {
		($aa,$dd,$ff) = split(/,/,$HcommandDivido[$m]);
		$set_listcom .= "\[ ";
		for($i = 0; $i < $HcommandTotal; $i++) {
			$l_kind = $HcomList[$i];
			$l_cost = $HcomCost[$l_kind];
			if($l_cost == 0) { $l_cost = '����'}
			elsif($l_cost < 0) { $l_cost = - $l_cost; $l_cost .= $HunitFood;}
			else { $l_cost .= $HunitMoney; }
			if($l_kind > $dd-1 && $l_kind < $ff+1) {
				$set_listcom .= "\[$l_kind\,\'$HcomName[$l_kind]\',\'$l_cost\',$HcomTurn[$l_kind]\]\,\n";
				if($l_kind == $HcomItem){
					# ����
				}else{
					if($m != $ListIx){
						$ListIx = $m;
					}
					
					$str = "<a href='javascript:void(0);' onmouseover='StatusMsg($l_kind);return true;' onClick='cominput(myForm,6,$l_kind,0)' class='M' TITLE='$l_cost'>$HcomName[$l_kind]$keyName[$l_kind]</a>";
					if($m == 0){
						$click_com .= "$str<br>\n";
						if($l_kind == $HcomPrepare2){
							$click_com .= "<a href='javascript:void(0);' onmouseover='StatusMsg($l_kind);return true;' onClick='cominput(myForm,8,$l_kind,0)' class='M' TITLE='$l_cost'>Ȳ���� ��� ��������</a><br>\n";
						}
					}elsif($m == 1){
						if($l_kind == $HcomFarm || $l_kind == $HcomFactory){
					#		$click_com2 .= "$str��";
							$click_com2 .= "$str<br>\n";
						}elsif($l_kind == $HcomDraft){
							$click_com2 .= "$str <a href='javascript:void(0);' onmouseover='StatusMsg($l_kind);return true;' onClick='cominput(myForm,8,$l_kind,0)' class='M' TITLE='$l_cost'>(�ѵ���)</a><br>\n";
						}else{
							$click_com2 .= "$str<br>\n";
						}
					}elsif($m == 2){
						$click_com3 .= "$str<br>\n";
					}
				}
				$All_listCom++;
			}
			next if($l_kind < $ff+1);
		}
		$bai = length($set_listcom);
		$set_listcom = substr($set_listcom, 0,$bai-2);
		$set_listcom .= " \],\n";
	}
	$bai = length($set_listcom);
	$set_listcom = substr($set_listcom, 0,$bai-2);
	if($HdefaultKind eq ''){ $default_Kind = 1;}
	else{ $default_Kind = $HdefaultKind; }

	#������ ����Ʈ
	my $im = $island->{'item'};
	if(($im->[1] + $im->[2] + $im->[3] + $im->[4] + $im->[5] + $im->[6] + $im->[7] + $im->[8] + $im->[9] + $im->[10] + $im->[11] + $im->[12] + $im->[13] + $im->[14] + $im->[15]) == 0) {
		$click_com4 .= "�����ƥ�Ϥ���ޤ���<br>\n";
		$ItemList .= "<OPTION VALUE=''> �� �������� �����ϴ�. ��";
	}else{
		$ItemList .= "<OPTION VALUE=''> �� ��� ������ ��� ��� ��";
		my $tmp = "<a href='javascript:void(0);' class='M' onClick='cominput(myForm,6,$HcomItem,";
		for($i = 1; $i < 16; $i++) {
			if($im->[$i] > 0) {
				my $ov = $i + 100;
				$ItemList .= "<OPTION VALUE='$ov'>$FItemName[$i] ($im->[$i])";
				$click_com4 .= "$tmp$i)' TITLE='$FItemMsg[$i]'>$FItemName[$i]</a>($im->[$i])<br>\n";
			}
		}
	}

	#���� ����Ʈ ��Ʈ
	my($set_island) = getJsIslandList();

	#������ ����, �δ��, �̻��� ��ź���غ�
	my($set_owner,$set_resist,$set_missile,$set_DivPw,$set_DivPwC,$set_map,$ownerID) = ("","","","","","",$id);
	my($bx, $by, @baseflg, $distance, $base,$nKind);
	for($y = 0; $y < $HislandSize; $y++) {
		$set_owner .= "[";
		$set_resist .= "[";
		$set_DivPw .= "[";
		$set_DivPwC .= "[";
		$set_map .= "[";
		for($x = 0; $x < $HislandSize; $x++) {
			$nKind = $Hland->[$x][$y];
			if($id != $HlandOwner->[$x][$y] && $nKind == $HlandSbase){
				$set_owner .= "0,"
			}else{
				$set_owner .= "$HlandOwner->[$x][$y],"
			}
			$set_resist .= "$HlandResist->[$x][$y],";
			if($id == $HlandOwner->[$x][$y]){
				$set_map .= ($nKind != $HlandSea || !$HlandValue->[$x][$y]) ? "$nKind," : '-1,';
			}else{
				if($nKind == $HlandBase || $nKind == $HlandDefence || $nKind == $HlandSupply){
					$set_map .= "$HlandForest,";
				}elsif($nKind == $HlandSbase){
					$set_map .= "$HlandSea,";
				}else{
					$set_map .= ($nKind != $HlandSea || !$HlandValue->[$x][$y]) ? "$nKind," : '-1,';
				}
			}
			
			if(($id == $HlandOwner->[$x][$y]) &&
				(($nKind == $HlandBase) ||
				($nKind == $HlandSbase))){
				push(@baseflg, $x*$HislandSize+$y);
			}
			if($HlandDivPw->[$x][$y] > 0){
				$disp = 0;
				@sflg = (1,7,19,37);
				for(1 .. 36){
					# �þߴ� �ִ� 3�� ����
					my($sx, $sy) = ($x + $ax[$_],$y + $ay[$_]);
					$sx-- if(!($sy % 2) && ($y % 2));
					if($Hroundmode){
						$sx = $correct[$sx + 12];
						$sy = $correct[$sy + 12];
					}
					next if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize));
					if( (($_ < $sflg[$FsearchR[$HlandDiv->[$sx][$sy]]]) && ($HlandDivNa->[$sx][$sy] == $id) && ($HlandDivPw->[$sx][$sy] > 0)) ||
						(($_ < 19) && ($HlandOwner->[$sx][$sy] == $id) && ($Hland->[$sx][$sy] == $HlandSupply)) ||
						(($_ < 19) && ($HlandOwner->[$sx][$sy] == $id) && ($Hland->[$sx][$sy] == $HlandMountain))){
						# Ž�� �������� ���밡 �ִ�
						$disp = 1;
						last;
					}
				}
				if(($id == $HlandDivNa->[$x][$y]) || ($id == $HlandOwner->[$x][$y]) || ($disp) || ($Hdebug == 2)){
					my $col = 'enemy';
					$col = $island->{'color'}->[$island->{'HGr'}->[$x][$y] - 1] if($id == $HlandDivNa->[$x][$y]);
					$set_DivPw .= "$HlandDivPw->[$x][$y],";
					$set_DivPwC .= "'$col',";
				}else{
					$set_DivPw .= "0,";
					$set_DivPwC .= "'0',";
				}
			}else{
				$set_DivPw .= "0,";
				$set_DivPwC .= "'',";
			}
		}
		chop($set_owner);
		chop($set_resist);
		chop($set_DivPw);
		chop($set_DivPwC);
		chop($set_map);
		$set_owner .= "],\n";
		$set_resist .= "],\n";
		$set_DivPw .= "],\n";
		$set_DivPwC .= "],\n";
		$set_map .= "],\n";
	}
	substr($set_owner, -2) = '';
	substr($set_resist, -2) = '';
	substr($set_DivPw, -2) = '';
	substr($set_DivPwC, -2) = '';
	substr($set_map, -2) = '';

	# �̻��� ��ź��
	for($y = 0; $y < $HislandSize; $y++) {
		$set_missile .= "[";
		for($x = 0; $x < $HislandSize; $x++) {
			$base = 0;
			# �̻��� ���������� �Ÿ��� ����� �����飫1
			foreach (@baseflg) {
				$bx = int($_ / $HislandSize);
				$by = $_ % $HislandSize;
				#  ���� �Ÿ��� ���
				my($dx, $dy) = (abs($bx - $x), abs($by - $y));
				my($rl) = 0;
				if($x > $bx){
					# ��
					$rl = 1;
				}elsif($x < $bx){
					# ��
					$rl = -1;
				}
				if($Hroundmode){
					if($dx > int($HislandSize / 2)){
						$rl = -$rl;# �ݴ�� �Ѵ�
						$dx = $HislandSize - $dx;
					}
					$dy = $HislandSize - $dy if($dy > int($HislandSize / 2));
				}
				$distance = $dx + $dy;
				$distance -= ($dx >= ($dy / 2)) ? int($dy / 2) : $dx;
#				HdebugOut("���� �Ÿ��� ��� 2��$dx  $dy  �Ÿ�=$distance");
				if(!($by % 2) && ($y % 2)){
					# ������ ¦��, ��ǥ�� Ȧ������ ��� �������̡�1
					$distance-- if($rl == 1);
				}elsif(!($y % 2) && ($by % 2)){
					# ������ Ȧ��, ��ǥ�� ¦������ �������̡�1
					$distance-- if($rl == -1);
				}
				# ������ ������ ����
				my($baseLevel) = expToLevel($Hland->[$bx][$by], $HlandValue->[$bx][$by]);
				if($Hland->[$bx][$by] == $HlandSbase){
					$baseLevel += $HmissileRangeS;
				}else{
					$baseLevel += $HmissileRange;
				}
#				HdebugOut("���� �Ÿ��� ��� 3��$dx  $dy  �Ÿ�=$distance  ����=$baseLevel");
				my($level) = expToLevel2($Hland->[$bx][$by], $HlandValue->[$bx][$by]); # ������ ������ ����
				$base += $level if($baseLevel > $distance);
			}
			$set_missile .= "$base,";
		}
		chop($set_missile);
		$set_missile .= "],\n";
	}
	substr($set_missile, -2) = '';

	# �ֺ� ǥ���� ����
	my $wide = 1;
	if($island->{'custom'} & 1){
		$wide = 0;
	}
	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName}${H_tagName}���� ��ȹ${H_tagBig}<BR><BR>

<FORM name="campform" action="$HthisFile" method="POST" target=_blank>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="${\htmlEscape($HdefaultPassword)}">
<INPUT TYPE=HIDDEN NAME=camp$Hislands[$HcurrentNumber]->{'id'}">
</FORM>
<FORM name="bbsform" action="$HcampbbsPath" method="POST" target=_blank>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="${\htmlEscape($HdefaultPassword)}">
<INPUT TYPE=HIDDEN NAME=campPASS VALUE="$campPass[$Hislands[$HcurrentNumber]->{'ally'}]">
<INPUT TYPE=HIDDEN NAME=campID   VALUE="$Hislands[$HcurrentNumber]->{'ally'}">
</FORM>
<FORM name="chatform" action="$HcampchatPath" method="POST" target=_blank>
<INPUT TYPE=HIDDEN NAME=mode VALUE="top">
<INPUT TYPE=HIDDEN NAME=oNAME VALUE="$Hislands[$HcurrentNumber]->{'ownername'}">
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="${\htmlEscape($HdefaultPassword)}">
<INPUT TYPE=HIDDEN NAME=campPASS VALUE="$campPass[$Hislands[$HcurrentNumber]->{'ally'}]">
<INPUT TYPE=HIDDEN NAME=campID   VALUE="$Hislands[$HcurrentNumber]->{'ally'}">
</FORM>
<FORM name="MapEditor" action="$HthisFile" method="POST" target=_blank>
<INPUT TYPE=HIDDEN NAME=ISLANDID VALUE="$HcurrentID">
<INPUT TYPE=HIDDEN NAME=OLDPASS VALUE="${\htmlEscape($HdefaultPassword)}">
<INPUT TYPE=HIDDEN NAME=MapEditor">
</FORM>

[<A HREF="$HthisFile">ž�� ���ƿ´�</A>]��
END
	
	out("[<A HREF=\"JavaScript:void(0);\" onClick=\"openMEditor();return false;\">�� ������</A>]��") if($HeditorN);
	if($Hallyflg && $HallyDisp){
		out("[<A HREF=\"JavaScript:void(0);\" onClick=\"openCAMP();return false;\">���� ȭ�鿡</A>]��");
		out("[<A HREF=\"JavaScript:void(0);\" onClick=\"openBBS();return false;\">���� �Խ��ǿ�</A>]��") if($Hcampbbs);
		out("[<A HREF=\"JavaScript:void(0);\" onClick=\"openCHAT();return false;\">���� ȸ�ǽǿ�</A>]") if($Hcampchat);
	}
	out(<<END);
</CENTER>
<SCRIPT Language="JavaScript">
<!--
// JAVA ��ũ��Ʈ ���� ȭ�� ������
// -�ϸ������� ����( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(��)
// �� �������� ������.
var xmlhttp;
var str;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];

comlist = [
$set_listcom
];

islname = {
$set_island
};

ownerID = $ownerID;
owner = [
$set_owner
];

resist = [
$set_resist
];

missile = [
$set_missile
];


soldier = $island->{'soldier'};
DivPw = [
$set_DivPw
];

DivPwC = [
$set_DivPwC
];

mapdata = [
$set_map
];

mapcommand = [
"$HcomReclaim,$HcomDestroy,$HcomSbase,$HcomWithdraw",// �ٴ�
"$HcomReclaim,$HcomDestroy,$HcomWithdraw",// ���� ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",// ����
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomInfantry,$HcomWithdraw",// ��
"$HcomMountain,$HcomDestroy,$HcomWithdraw",// Ȳ����
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomSupply,$HcomWithdraw",// ����
"$HcomSupply,$HcomPlant,$HcomFarm,$HcomFarm2,$HcomFactory,$HcomFactory2,$HcomBase,$HcomDbase,$HcomMonument,$HcomDestroy,$HcomWithdraw",//������
"$HcomDraft,$HcomSupply,$HcomPlant,$HcomFarm,$HcomFarm2,$HcomFactory,$HcomFactory2,$HcomBase,$HcomDbase,$HcomMonument,$HcomDestroy,$HcomWithdraw",//  ��
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw",// ����
"$HcomFarm,$HcomFarm2,$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw",// ����
"$HcomFactory,$HcomFactory2,$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw",// �̻��� ����
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw",//  ���� �ü�
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomDbase,$HcomWithdraw",// �ɱһ���
"$HcomInfantry,$HcomSupply,$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw,$HcomItem"//���� ����
]

mapcommand2 = [
"$HcomReclaim,$HcomDestroy,$HcomSbase,$HcomWithdraw",// �ٴ�
"$HcomReclaim,$HcomDestroy,$HcomWithdraw",// ���� ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",// ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",// ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomMountain,$HcomWithdraw",// ��
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw,$HcomPrepare",// Ȳ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomSupply,$HcomBase,$HcomDbase,$HcomMonument,$HcomWithdraw",// ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",// ������
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",// ��
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomFarm,$HcomWithdraw",// ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomFactory,$HcomWithdraw",// ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",// �̻��� ����
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",// ���� �ü�
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",// ��������
]

bgclr = 0;
function init(){
	for(i = 0; i < command.length ;i++) {
		for(s = 0; s < $com_count ;s++) {
		var comlist2 = comlist[s];
		for(j = 0; j < comlist2.length ; j++) {
			if(command[i][0] == comlist2[j][0]) {
				g[i] = [comlist2[j][1], comlist2[j][3]];
			}
		}
		}
	}
	outp();
	str = plchg($HcommandMax);
	str = "<TABLE border=0><TR><TD class='commandjs1'><B>�������� �۽��� ���� ���� ��������</B><br><br>"+str+"<br><B>�������� �۽��� ���� ���� ��������</B></TD></TR></TABLE>";
	disp(str, 1);
	xmlhttp = new_http();
	if(document.layers) {
		document.captureEvents(Event.MOUSEMOVE | Event.MOUSEUP);
	}
	document.onmouseup   = Mup;
	document.onmousemove = Mmove;
	document.onkeydown = Kdown;
	document.ch_numForm.AMOUNT.options.length = 71;
	for(i=0;i<document.ch_numForm.AMOUNT.options.length;i++){
		document.ch_numForm.AMOUNT.options[i].value = i;
		document.ch_numForm.AMOUNT.options[i].text  = i;
		if(i>=50){
			document.ch_numForm.AMOUNT.options[i].value = (i-45) * 10;
			document.ch_numForm.AMOUNT.options[i].text  = (i-45) * 10;
		}
	}
	document.myForm.CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}.disabled = true;
	ns(0);

}
function init2(){
	str = plchg(document.myForm.CMDMAX.value);
	if(bgclr == 1){
		str = "<TABLE border=0><TR><TD class='commandjs1'><B>�������� �۽��� ���� ���� ��������</B><br><br>"+str+"<br><B>�������� �۽��� ���� ���� ��������</B></TD></TR></TABLE>";
		disp(str, 1);
	}else{
		str = "<TABLE border=0><TR><TD class='commandjs2'><B>�����������̼۽�-----</B><br><br>"+str+"<br><B>�����������̼۽�-----</B></TD></TR></TABLE>";
		disp(str, 2);
	}
	ns(0);
}

function cominput(theForm, x, k, pp, z) {
	a = theForm.NUMBER.options[theForm.NUMBER.selectedIndex].value;
	b = theForm.COMMAND.options[theForm.COMMAND.selectedIndex].value;
	c = theForm.POINTX.options[theForm.POINTX.selectedIndex].value;
	d = theForm.POINTY.options[theForm.POINTY.selectedIndex].value;
	e = theForm.AMOUNT.options[theForm.AMOUNT.selectedIndex].value;
	f = theForm.TARGETID.options[theForm.TARGETID.selectedIndex].value;
	var newNs = a;
	if(x == 8){x = 6;e = 22}
	if(x == 1 || x == 2 || x == 6){
		if(x == 6){
			b = k;
			if(pp != 0) {e = pp;}
		}
		if(30 < b && b < 41) f = owner[d][c];
		if(x != 2) {
			for(i = $HcommandMax - 1; i > a; i--) {
				command[i] = command[i-1];
				g[i] = g[i-1];
			}
		}
		for(s = 0; s < $com_count ;s++) {
			var comlist2 = comlist[s];
			for(i = 0; i < comlist2.length; i++){
				if(comlist2[i][0] == b){
					g[a] = [comlist2[i][1], comlist2[i][3]];
					break;
				}
			}
		}
		command[a] = [b,c,d,e,f];
		newNs++;
		menuclose();
	}else if(x == 3){
		var num = (k) ? k-1 : a;
		for(i = Math.floor(num); i < ($HcommandMax - 1); i++) {
			command[i] = command[i + 1];
			g[i] = g[i+1];
		}
		command[$HcommandMax-1] = [41,0,0,0,0];
		g[$HcommandMax-1] = ['�ڱ�����', '1'];
	}else if(x == 4){
		i = Math.floor(a)
		if (i == 0){ return true; }
		i = Math.floor(a)
		tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
		command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i - 1];
		g[i] = k2[i];g[i-1] = k1[i];
		newNs = i-1;
	}else if(x == 5){
		i = Math.floor(a)
		if (i == $HcommandMax-1){ return true; }
		tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
		command[i] = tmpcom2[i];command[i+1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i + 1];
		g[i] = k2[i];g[i+1] = k1[i];
		newNs = i+1;
	}else if(x == 7){
		//  �̵�
		var ctmp = command[k];
		var gtmp = g[k];
		if(z > k) {
			// ������ ������
			for(i = k; i < z-1; i++) {
				command[i] = command[i+1];
				g[i] = g[i+1];
			}
		} else {
			// �Ʒ����� ����
			for(i = k; i > z; i--) {
				command[i] = command[i-1];
				g[i] = g[i-1];
			}
		}
		command[i] = ctmp;
		g[i] = gtmp;
	}else if(x == 9){
		command[a][3] = k;
	}

	str = plchg($HcommandMax);
	str = "<TABLE border=0><TR><TD class='commandjs2'><B>�����������̼۽�-----</B><br><br>"+str+"<br><B>�����������̼۽�-----</B></TD></TR></TABLE>";
	disp(str, 2);
	outp();
	theForm.CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}.disabled = false;
	ns(newNs);
	return true;
}

function plchg(cmdmax){
	strn1 = "";
	strturn = "";
	turn = $HislandTurn + 1;
	cflag = 1;
	trunCt = 0;
	ct    = 0;
	for(i = 0; i < document.myForm.CMDMAX.value; i++){
		commandturn = g[i][1];
		c = command[i];
		if(i+1 < document.myForm.CMDMAX.value) c2 = command[i+1];
		x = c[1];
		y = c[2];
		if((c[0] == $HcomSupply) && (mapdata[y][x] == $HlandSupply)) {
			commandturn = 0;
		}else if((c2[0] == $HcomPrepare2 || c2[0] == $HcomDraft) && (c2[3] == 22)) {
			commandturn = 1;
		}
		if(c[0] == $HcomPrepare2 && c[3] == 22) {
			g[i][0] = 'Ȳ���� ��� �� ������';
		}else if(c[0] == $HcomDraft && c[3] == 22) {
			g[i][0] = '7õ �̻� ��� ¡��';
		}
		if(commandturn == 0) {
			kind = '$HtagComName2_' + g[i][0] + '$H_tagComName';
		} else {
			kind = '$HtagComName1_' + g[i][0] + '$H_tagComName';
		}
		carg = c[3];
		tgt = c[4];
		tgt = '$HtagName_' + islname[tgt] + '${H_tagName}';
		if(carg == 0) { carg = 1; }
		if( (c[0] == $HcomFarm) ||
			(c[0] == $HcomFactory) ||
			(c[0] == $HcomFarm2) ||
			(c[0] == $HcomFactory2) ||
			(c[0] == $HcomMountain) ||
			(c[0] == $HcomPropaganda)
			) {
			trunCt += commandturn * carg;
		} else {
			trunCt += commandturn;
		}
		if(cflag <= trunCt) {
			point = '${HtagName_}(' + x + ',' + y + ')${H_tagName}';
			strturn = '$HtagComName1_' + turn + '$H_tagComName';
			turn += Math.floor(trunCt/cflag);
			trunCt %= cflag;
		} else {
			point = '${HtagComName2_}(' + x + ',' + y + ')${H_tagComName}';
			strturn = '$HtagComName2_' + turn + '$H_tagComName';
		}

		if(c[0] == $HcomDoNothing || c[0] == $HcomGiveup){ // �ڱ�����, ������ ����
			strn2 = kind;
		}else if(c[0] == $HcomInfantry){//  �δ� ��ġ
			if(0 < c[3] && c[3] < 10){ c[3] = 10; }
			if(DivPw[y][x] > 0 && DivPwC[y][x] != 'enemy' && (250 - DivPw[y][x] < c[3])) c[3] = 250 - DivPw[y][x];
			ct += parseInt(c[3]);
			if(ct > soldier){
				strn2 = point + '��' + kind + '(' + c[3] + ' ${HtagDisaster_}��' + ct + '${H_tagDisaster})';
			}else{
				strn2 = point + "" + kind + "(" + c[3] + " ��" + ct + ")";
			}
		}else if(c[0] == $HcomDeWar || c[0] == $HcomCeasefire) { // ��������
			strn2 = tgt + '��' + kind;
		}else if(c[0] == $HcomAmity) { // ��ȣ��
			if(c[3] == 1003){
				strn2 = tgt + '��' + kind + '(${HtagName_}��ȣ ����${H_tagName})';
			}else if(c[3] == 1002){
				strn2 = tgt + '��' + kind + '(${HtagName_}��ȣ �ź�${H_tagName})';
			}else{
				if(c[3] < 10){ c[3] = 10;}
				if(c[3] > 50){ c[3] = 50;}
				strn2 = tgt + '��' + kind + '($HtagName_' + c[3] + '��${H_tagName})';
			}
		}else if(c[0] == $HcomMissileNM || // �̻��� ���â
			c[0] == $HcomMissilePP || 
			c[0] == $HcomMissileDM || 
			c[0] == $HcomMissileLD || 
			c[0] == $HcomMissileHM || 
			c[0] == $HcomMissileBM){
			if(c[0] == $HcomMissileHM) {c[3] = 1;}
			if(c[3] == 0){
				arg = '($HtagName_������${H_tagName})';
			} else {
				arg = '($HtagName_' + c[3] + '��${H_tagName})';
			}
			strn2 = tgt + point + "" + kind + arg;
		}else if(c[0] == $HcomSendMonster){
			strn2 = tgt + point + "" + kind;
		}else if(c[0] == $HcomArea){
			if(c[3] == 1){
				strn2 = tgt + "" + kind + point + "(�δ뵵 �絵)";
			}else{
				strn2 = tgt + "" + kind + point;
			}
		}else if(c[0] == $HcomSell){ // �ķ� ����
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3];
			strn2 = kind + '$HtagName_' + arg + '$HunitFood2${H_tagName}(' + arg + '0${HunitMoney}���)';
		}else if(c[0] == $HcomPropaganda){ // ��ġ Ȱ��
			if(c[3] == 0){
				strn2 = kind;
			} else {
				strn2 = kind + '($HtagName_' + c[3] + 'ȸ${H_tagName})';
			}
		}else if(c[0] == $HcomMoney){ // �ڱݿ���
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * $HcomCost[$HcomMoney];
			arg = '($HtagName_' + arg + '$HunitMoney${H_tagName})';
			strn2 = tgt + "" + kind + arg;
		}else if(c[0] == $HcomFood){ // �ķ� ����
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3];
			arg = '($HtagName_' + arg + '$HunitFood2${H_tagName})';
			strn2 = tgt + "" + kind + arg;
		}else if(c[0] == $HcomSoldier){ // ���� ����
			if(c[3] == 0){ c[3] = 1; }
			arg = '($HtagName_' + c[3] + '$HunitPop${H_tagName})';
			strn2 = tgt + "" + kind + arg;
		}else if(c[0] == $HcomSoldier2){ //  �뺴 ����
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3];
			arg2 = arg * $HcomCost[$HcomSoldier2];
			strn2 = kind + '$HtagName_' + arg + '$HunitPop2${H_tagName}(' + arg2 + '${HunitMoney}���)';
		}else if(c[0] == $HcomMonument){ // ����
			if(c[3] == 0) {
				strn2 = point + "" + kind + '($HtagName_�溮${H_tagName})';
			} else if(c[3] == 1) {
				strn2 = point + "" + kind + '($HtagName_��븮��${H_tagName})';
			} else if(c[3] == 2) {
				strn2 = point + "" + kind + '($HtagName_��ȭ ����${H_tagName})';
			} else if(c[3] == 3) {
				strn2 = point + "" + kind + '($HtagName_�ο��� ��${H_tagName})';
			} else {
				strn2 = point + "" + kind;
			}
		}else if(c[0] == $HcomFarm || // ����, ����, ä���� ����
			c[0] == $HcomFactory ||
			c[0] == $HcomFarm2 ||
			c[0] == $HcomFactory2 ||
			c[0] == $HcomMountain) {
			if(c[3] != 0){
				arg = '($HtagName_' + c[3] + 'ȸ${H_tagName})';
				strn2 = point + "" + kind + arg;
			}else{
				strn2 = point + "" + kind;
			}
		}else if(c[0] == $HcomSupply){
			strn2 = point + "" + kind + "(" + c[3] + ")";
		}else if(c[0] == $HcomUnitOrder){
			strn2 = kind + "(" + c[3] + "����" + c[1] + ")";
		}else if(c[0] == $HcomItem){
			if(c[3] == 0){ c[3] = 1; }
			if(c[3] > $#FItemName){ c[3] = $#FItemName; }
			tmp = '';
			if(c[3] == 1) {
				tmp = '$FItemName[1]';
END
		for($i = 2; $i <= $#FItemName; $i++) {
	out(<<END);
			} else if(c[3] == $i) {
				tmp = '$FItemName[$i]';
END
		}
	out(<<END);
			}
			strn2 = point + "" + kind + '($HtagName_' + tmp + '${H_tagName})';
		}else if(c[0] == $HcomWithdraw && c[3] == 1){
			strn2 = point + "" + kind + "(����)";
		}else if((c[0] == $HcomPrepare2 || c[0] == $HcomDraft) && (c[3] == 22)) {
			strn2 = kind;
		}else{
			strn2 = point + "" + kind;
		}
		tmpnum = '';
		if(i < 9){ tmpnum = '0'; }
		strn1 += 
			'<div id="com_'+i+'"'+
			'onmouseover="mc_over('+i+');return false;" '+
			'><A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns(' + i + ')" '+
			'onmousedown="return comListMove('+i+');" '+
			'ondblclick="chNum('+c[3]+');return false;" '+
			'><NOBR>' + tmpnum + (i + 1) + '<FONT SIZE=-1>$HnormalColor_(' + strturn + ')��'
			 + strn2 + '$H_normalColor</FONT></NOBR></A></div>\\n';
	}
	return strn1;
}
function disp(str,bg){
	if(str==null)  str = "";
	bgclr = bg;
	if(document.getElementById || document.all){
		LayWrite('LINKMSG1', str);
	} else if(document.layers) {
		lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
		lay.document.open();
		lay.document.write("<font style='font-size:11pt'>"+str+"</font>");
		lay.document.close(); 
	}
}

function outp(){
	comary = "";
	for(k = 0; k < command.length; k++){
	comary = comary + command[k][0]
	+" "+command[k][1]
	+" "+command[k][2]
	+" "+command[k][3]
	+" "+command[k][4]
	+" ";
	}
	document.myForm.COMARY.value = comary;
}

function ps(x, y, id) {
	document.myForm.POINTX.options[x].selected = true;
	document.myForm.POINTY.options[y].selected = true;
	document.allForm.POINTX.value = x;
	document.allForm.POINTY.value = y;
	if(document.mark_form.mark.checked) {
		set_mark(x, y);
	}else if(!(document.myForm.MENUOPEN.checked)) {
		NaviClose();
		if(document.myForm.MENUOPEN2.checked) {
			moveLAYER("menu2",mx+10,my-50);
		} else {
END
	out("			menuinit(x,y,-2);\n") if($HjavaMode ne 'java');
	out(<<END);
			moveLAYER("menu",mx+10,my-50);
		}
	}
	return true;
}

function SelectPOINT(){
	document.allForm.POINTX.value = document.myForm.POINTX.options[document.myForm.POINTX.selectedIndex].value;
	document.allForm.POINTY.value = document.myForm.POINTY.options[document.myForm.POINTY.selectedIndex].value;
	document.allForm.submit();
}

function ns(x) {
	if (x == $HcommandMax){ return true; }
	document.myForm.NUMBER.options[x].selected = true;
	document.allForm.NUMBER.value = x;
	selCommand(x);
	return true;
}

function set_com(x, y, land, img, name, title, text, exp) {
	com_str = land + "\\n";
	for(i = 0; i < $HcommandMax; i++){
		c = command[i];
		x2 = c[1];
		y2 = c[2];
		if(x == x2 && y == y2 && c[0] < 30){
			com_str += "[" + (i + 1) +"]" ;
			kind = g[i][0];
			if(c[0] == $HcomFarm || c[0] == $HcomFactory || c[0] == $HcomFarm2 || c[0] == $HcomFactory2 || c[0] == $HcomMountain) {
				if(c[3] != 0){
					arg = "��" + c[3] + "ȸ��";
					com_str += kind + arg;
				}else{
					com_str += kind;
				}
			}else{
				com_str += kind;
			}
			com_str += " ";
		}
	}
	window.status = com_str;
	document.mapForm.COMSTATUS1.value= com_str;
	document.mapForm.COMSTATUS2.value= com_str;
	Navi(x, y, img, name, title, text, exp);
	document.mapForm.COMSTATUS1.scrollTop = 1;
	if(document.mapForm.COMSTATUS1.scrollTop > 0){
		document.mapForm.COMSTATUS1.setAttribute('rows','3');
		document.mapForm.COMSTATUS2.setAttribute('rows','3');
	}
}

function SelectList(theForm){
	var u, selected_ok;
	if(!theForm){s = ''}
	else { s = theForm.menuchoice.options[theForm.menuchoice.selectedIndex].value; }
	if(s == ''){
		u = 0; selected_ok = 0;
		document.myForm.COMMAND.options.length = $All_listCom;
		for (i=0; i<comlist.length; i++) {
			var command = comlist[i];
			for (a=0; a<command.length; a++) {
				comName = command[a][1] + "(" + command[a][2] + ")";
				document.myForm.COMMAND.options[u].value = command[a][0];
				document.myForm.COMMAND.options[u].text = comName;
				if(command[a][0] == $default_Kind){
					document.myForm.COMMAND.options[u].selected = true;
					selected_ok = 1;
				}
				u++;
			}
		}
		if(selected_ok == 0)
		document.myForm.COMMAND.selectedIndex = 0;
	} else {
		var command = comlist[s];
		document.myForm.COMMAND.options.length = command.length;
		for (i=0; i<command.length; i++) {
			comName = command[i][1] + "(" + command[i][2] + ")";
			document.myForm.COMMAND.options[i].value = command[i][0];
			document.myForm.COMMAND.options[i].text = comName;
			if(command[i][0] == $default_Kind){
				document.myForm.COMMAND.options[i].selected = true;
				selected_ok = 1;
			}
		}
		if(selected_ok == 0)
		document.myForm.COMMAND.selectedIndex = 0;
	}
}
function StatusMsg(x) {
msg = new Array(64);
END
	my($i ,$k);
	for($i = 0; $i < $HcommandTotal; $i++) {
		$k = $HcomList[$i];
		my($Msg) = $HcomMsg[$k];
		out("msg[$k] = \"$Msg\";\n");
	}
	out(<<END);
	window.status = msg[x];
	document.mapForm.COMSTATUS1.value= msg[x];
	document.mapForm.COMSTATUS2.value= msg[x];
}

function moveLAYER(layName,x,y){
	if(document.getElementById){		//NN6,IE5
		el = document.getElementById(layName);
		el.style.left = x;
		el.style.top  = y;
	} else if(document.layers){				//NN4
		msgLay.moveTo(x,y);
	} else if(document.all){				//IE4
		msgLay = document.all(layName).style;
		msgLay.pixelLeft = x;
		msgLay.pixelTop = y;
	}
}

var mapx = 0;
var mapy = 0;
function menuinit(x,y,z){
	var ItemList = "$ItemList";
	if(z < -1){
		mapx = x;mapy = y;
		land = mapdata[y][x];
		ow = owner[y][x];
		for(i = 0; i < document.myForm.NUMBER.selectedIndex;i++) {
			if((x == command[i][1] && y == command[i][2]) && (command[i][0] == $HcomSupply)){
				land = $HlandSupply;
			}else if(land == -1 && (x == command[i][1] && y == command[i][2]) && command[i][0] == $HcomReclaim){
				land = $HlandWaste;ow = $id
			}else if(land >= $HlandWaste || land == $HlandMonument){
				if((x == command[i][1] && y == command[i][2]) && (command[i][0] == $HcomPrepare || command[i][0] == $HcomPrepare2)){
					land = $HlandPlains;
				}
			}
		}
		if(land < 0) land = 0;
	}
	
	var ct = 0;
	var menulist = "";
	if(z < 0){
		if($id == ow) {
			com_array = mapcommand[land].split(",");
		}else{
			com_array = mapcommand2[land].split(",");
		}
		for(i = 0; i < com_array.length ; i++) {
			for(s = 0; s < 4 ;s++) {
			var comlist2 = comlist[s];
			for(j = 0; j < comlist2.length ; j++) {
				if(com_array[i] == comlist2[j][0]){
					if(comlist2[j][0] == $HcomWithdraw && (DivPw[mapy][mapx] == 0 || DivPwC[mapy][mapx] == 'enemy')){
						continue;
					}else if(comlist2[j][0] == $HcomItem){
						menulist += ItemList;
					}else{
						menulist += "<OPTION VALUE='" + comlist2[j][0] + "'>" + comlist2[j][1] + "(" + comlist2[j][2] + ")";
					}
					ct++;
				}
			}
			}
		}
	}else{
		var comlist2 = comlist[z];
		for(j = 0; j < comlist2.length ; j++) {
			if(comlist2[j][0] == $HcomItem){
				menulist += ItemList;
			}else{
				menulist += "<OPTION VALUE='" + comlist2[j][0] + "'>" + comlist2[j][1] + "(" + comlist2[j][2] + ")";
			}
			ct++;
		}
	}
	menulist = '<SELECT size="' + ct + '"NAME="command_list" onChange="select_command(com_list, myForm)">' + menulist + "</SELECT>";
	LayWrite('popupmenu', menulist);
	z++;if(z < 0) z = 0;
	for(i = 0; i < 5 ; i++) {
		if(i == z){
			document.getElementById('PMENU'+i).style.backgroundColor = '#FFAAAA';
		}else{
			document.getElementById('PMENU'+i).style.backgroundColor = '';
		}
	}
}

function menuclose(){
	moveLAYER("menu",-500,-500);
	moveLAYER("menu2",-500,-500);
	moveLAYER("TakokuYU",-500,-500);
	moveLAYER("TakokuSE",-500,-500);
}

function Mmove(e){
	if(document.all){
		mx = event.x + document.body.scrollLeft;
		my = event.y + document.body.scrollTop;
	}else if(document.layers){
		mx = e.pageX;
		my = e.pageY;
	}else if(document.getElementById){
		mx = e.pageX;
		my = e.pageY;
	}
	return moveLay.move();
}
function Kdown(e){
	var c, el;
	if(document.all){
		if (event.altKey || event.ctrlKey || event.shiftKey) return;
		c = event.keyCode;
		el = new String(event.srcElement.tagName);
		el = el.toUpperCase();
		if (el == "INPUT") return;
	}else if(document.getElementById){
		if (e.altKey || e.ctrlKey || e.shiftKey) return;
		c = e.which;
		el = new String(e.target.tagName);
		el = el.toUpperCase();
		if (el == "INPUT") return;
	}
	c = String.fromCharCode(c);
	window.status = c; //Ȯ�ο�

	// �и� Ű�� ���� ��ȹ ��ȣ�� �����Ѵ�
	switch (c) {
	case 'Z': c = $HcomPrepare2; break; // �� ������ ��
	case 'S': c = $HcomPlant; break; // �ĸ�
	case 'U': c = $HcomReclaim; break; // �Ÿ�
	case 'K': c = $HcomDestroy; break; // ����
	case 'N': c = $HcomFarm; break; // ���� ����
	case 'F': c = $HcomFactory; break; // ���� �Ǽ�
	case 'B': c = $HcomBase; break; // �̻��� ���� �Ǽ�
	case 'D': c = $HcomDbase; break; // ���� �ü� �Ǽ�
	case 'R': c = $HcomArea; break; // ���� �Ҿ�
	case 'C': c = $HcomDraft; break; // ¡��
	case 'G': c = $HcomInfantry; break; // �δ� ��ġ
	case 'T': c = $HcomWithdraw; break; //  �δ� ����
	case 'H': c = $HcomSupply; break; //  ���� ����
	case 'M': c = $HcomMissilePP; break; // PP�̻��� �߻�
	case 'A': c = $HcomPropaganda; break; // ��ġ Ȱ��
	case '-': c = $HcomDoNothing; break; //INS �ڱ�����
	case '.': cominput(myForm,3); return; //DEL ����
	case'\b': //BS 1��(��) ������
		var no = document.myForm.NUMBER.selectedIndex;
		if(no > 0) document.myForm.NUMBER.selectedIndex = no - 1;
		cominput(myForm,3);
		return;
	case '0':case'`': document.myForm.AMOUNT.selectedIndex = 0; return;
	case '1':case'a': document.myForm.AMOUNT.selectedIndex = 1; return;
	case '2':case'b': document.myForm.AMOUNT.selectedIndex = 2; return;
	case '3':case'c': document.myForm.AMOUNT.selectedIndex = 3; return;
	case '4':case'd': document.myForm.AMOUNT.selectedIndex = 4; return;
	case '5':case'e': document.myForm.AMOUNT.selectedIndex = 5; return;
	case '6':case'f': document.myForm.AMOUNT.selectedIndex = 6; return;
	case '7':case'g': document.myForm.AMOUNT.selectedIndex = 7; return;
	case '8':case'h': document.myForm.AMOUNT.selectedIndex = 8; return;
	case '9':case'i': document.myForm.AMOUNT.selectedIndex = 70; return;
	default:
	// IE ������ ���ε带 ���� F5 ���� �ֿ�Ƿ�, ���⿡ ó���� �־ �� �ȴ�
	return;
	}
	cominput(document.myForm, 6, c, 0);
}

function openCAMP(){
	document.campform.submit();
}
function openBBS(){
	document.bbsform.submit();
}
function openCHAT(){
	document.chatform.submit();
}
function openMEditor(){
	document.MapEditor.submit();
}

function LayWrite(layName, str) {
	if(document.getElementById){
		document.getElementById(layName).innerHTML = str;
	} else if(document.all){
		document.all(layName).innerHTML = str;
	} else if(document.layers){
		lay = document.layers[layName];
		lay.document.open();
		lay.document.write(str);
		lay.document.close(); 
	}
}

var oldNum=0;
function selCommand(num) {
	document.getElementById('com_'+oldNum).style.backgroundColor = '';
	document.getElementById('com_'+num).style.backgroundColor = '#FFFFAA';
	oldNum = num;
}

//  Ŀ��� �巯�ף���ӿ� �߰� ��ũ��Ʈ��
var moveLay = new MoveFalse();

var newLnum = -2;
var Mcommand = false;

function Mup() {
	moveLay.up();
	moveLay = new MoveFalse();
}

function setBorder(num, color) {
	if(document.getElementById) {
		if(color.length == 4) document.getElementById('com_'+num).style.borderTop = ' 1px solid '+color;
		else document.getElementById('com_'+num).style.border = '0px';
	}
}

function mc_out() {
	if(Mcommand && newLnum >= 0) {
		setBorder(newLnum, '');
		newLnum = -1;
	}
}

function mc_over(num) {
	if(Mcommand) {
		if(newLnum >= 0) setBorder(newLnum, '');
		newLnum = num;
		setBorder(newLnum, '#116');    // blue
	}
}

function comListMove(num) { moveLay = new MoveComList(num); return (document.layers) ? true : false; }

function MoveFalse() {
	this.move = function() { }
	this.up   = function() { }
}

function MoveComList(num) {
	var setLnum  = num;
	Mcommand = true;

	LayWrite('mc_div', '<NOBR><strong>'+(num+1)+': '+g[num][0]+'</strong></NOBR>');

	this.move = function() {
		moveLAYER('mc_div',mx+10,my-30);
		return false;
	}

	this.up   = function() {
		if(newLnum >= 0) {
			var com = command[setLnum];
			cominput(document.myForm,7,setLnum,0,newLnum);
		}
		else if(newLnum == -1) cominput(document.myForm,3,setLnum+1);

		mc_out();
		newLnum = -2;
		Mcommand = false;
		moveLAYER("mc_div",-50,-50);
	}
}

// ȭ�� õ�� ���������� Ŀ��� �۽ſ� �߰� ��ũ��Ʈ
function new_http() {
	if(document.getElementById) {
		try{
		   return new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e){
			try {
				return new ActiveXObject("Microsoft.XMLHTTP");
			} catch (E){
				if(typeof XMLHttpRequest != 'undefined') return new XMLHttpRequest;
			}
		}
	}
}

function send_command(form) {
	if (!xmlhttp) return true;

	form.CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}.disabled = true;

	var progress  = document.getElementById('progress');
	progress.innerHTML = '<blink>Sending...</blink>';

	if (xmlhttp.readyState == 1 || xmlhttp.readyState == 2 || xmlhttp.readyState == 3) return; 

	xmlhttp.open("POST", "$HthisFile", true);
	if(!window.opera) xmlhttp.setRequestHeader("referer", "$HthisFile");

	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			var result = xmlhttp.responseText;
			if(result.indexOf('AjaxOK') >= 0) {
				str = plchg($HcommandMax);
				str = "<TABLE border=0><TR><TD class='commandjs1'><B>�������� �۽��� ���� ���� ��������</B><br><br>"+str+"<br><B>�������� �۽��� ���� ���� ��������</B></TD></TR></TABLE>";
				disp(str, 1);
				selCommand(document.myForm.NUMBER.selectedIndex);
			} else {
				alert("�۽ſ� �����߽��ϴ�. ");
				form.CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}.disabled = false;
			}
			progress.innerHTML = '';
		}
	}

	var post;
	post += 'async=true&';
	post += 'CommandJavaButton$island->{'id'}=true&';
	post += 'COMARY='+form.COMARY.value+'&';
	post += 'PASSWORD='+form.PASSWORD.value+'&';

	xmlhttp.send(post);
	return false;
}

function showElement(layName) {
	var element = document.getElementById(layName).style;
	element.display = "block";
	element.visibility ='visible';
}

function hideElement(layName) {
	var element = document.getElementById(layName).style;
	element.display = "none";
}

function chNum(num) {
	for(i=0;i<document.ch_numForm.AMOUNT.options.length;i++){
		if(document.ch_numForm.AMOUNT.options[i].value == num){
			document.ch_numForm.AMOUNT.selectedIndex = i;
			document.ch_numForm.AMOUNT.options[i].selected = true;
			break;
		}
	}
	moveLAYER('ch_num', mx-10, my-60);
	showElement('ch_num');
}

function chNumDo(num) {
	if(num == 0) num = document.ch_numForm.AMOUNT.options[document.ch_numForm.AMOUNT.selectedIndex].value;
	cominput(document.myForm,9,num);
	hideElement('ch_num');
}

function chForceMenu() {
	document.getElementById("CHFORCE1").innerHTML = "���� ����̼۽š������";
	document.getElementById("CHFORCE2").innerHTML = "��硡���� ����̼۽�";
}

var mArray = new Array();

var lastX = 0;
var lastY = 0;
var lastN = 19;
var lastF = 0;

function set_mark(x, y) {
	if(!document.mark_form.mark.checked) return false;
	if(!document.getElementById) {
		alert("Warning: Your Browser could not support marking system.");
		return false;
	}

	var num  = document.mark_form.number_mark.value;
	var kind = document.mark_form.kind_mark.value;

	if(kind == '') {
		do_mark(lastX, lastY, lastN, '-');

		if(lastF == 1 && lastX == x && lastY == y) {
			lastX = 0;
			lastY = 0;
			lastN = 19;
			lastF = 0;
			return;
		}
		lastX = x;
		lastY = y;
		lastN = num;
		lastF = 1;
		kind = 'yellow';
	}
	do_mark(x, y, num, kind);
}

function do_mark(x, y, num, kind) {
	var xArray = new Array(0,1,1,1,0,-1,0,1,2,2,2,1,0,-1,-1,-2,-1,-1,0,2,2,3,3,3,2,2,1,0,-1,-2,-2,-3,-2,-2,-1,0,1,2,3,3,4,4,4,3,3,2,1,0,-1,-2,-2,-3,-3,-4,-3,-3,-2,-2,-1,0,1);
	var yArray = new Array(0,-1,0,1,1,0,-1,-2,-1,0,1,2,2,2,1,0,-1,-2,-2,-3,-2,-1,0,1,2,3,3,3,3,2,1,0,-1,-2,-3,-3,-3,-4,-3,-2,-1,0,1,2,3,4,4,4,4,4,3,2,1,0,-1,-2,-3,-4,-4,-4,-4);
	var cArray = new Array(8,9,10,11,12,13,14,15,16,17,18,19,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,0,1,2,3,4,5,6,7,8,9,10,11);

	for (i = 0; i < num; i++) {
		var targetX = x + xArray[i];
		var targetY = y + yArray[i];

		if(((targetY % 2) == 0) && ((y % 2) == 1)) {
			targetX = targetX - 1;
		}
		if($Hroundmode){
			targetX = cArray[targetX + 12];
			targetY = cArray[targetY + 12];
		}
		if(!(targetX < 0 || targetX >= $HislandSize || targetY < 0 || targetY >= $HislandSize)) {
			if(kind == '-') {
				unset_highlight(targetX, targetY);
			} else {
				set_highlight(targetX, targetY, kind);
			}
		}
	}
}

function do_mark_id(id, color) {
	for (x=0;x<$HislandSize;x++) {
		for (y=0;y<$HislandSize;y++) {
			if(id == owner[y][x]) {
				set_highlight(x, y, color);
			}else{
				unset_highlight(x, y);
			}
		}
	}
}
//  ȭ���� ��ŷȭ
function set_highlight(x, y, color) {
	if(document.getElementById) {
		document.getElementById(x+"a"+y+"i").width  = "30";
		document.getElementById(x+"a"+y+"i").height = "30";
		document.getElementById(x+"a"+y+"i").border = "1";
		document.getElementById(x+"a"+y+"i").style.borderColor = color;
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) || (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"b"+y+"i").width  = "30";
			document.getElementById(x+"b"+y+"i").height = "30";
			document.getElementById(x+"b"+y+"i").border = "1";
			document.getElementById(x+"b"+y+"i").style.borderColor = color;
		}
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) && (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"c"+y+"i").width  = "30";
			document.getElementById(x+"c"+y+"i").height = "30";
			document.getElementById(x+"c"+y+"i").border = "1";
			document.getElementById(x+"c"+y+"i").style.borderColor = color;
			document.getElementById(x+"d"+y+"i").width  = "30";
			document.getElementById(x+"d"+y+"i").height = "30";
			document.getElementById(x+"d"+y+"i").border = "1";
			document.getElementById(x+"d"+y+"i").style.borderColor = color;
		}
		mArray[x+"x"+y] = 1;
	}
}
// ��ŷ ����
function unset_highlight(x, y) {
	if(document.getElementById) {
		document.getElementById(x+"a"+y+"i").width  = "32";
		document.getElementById(x+"a"+y+"i").height = "32";
		document.getElementById(x+"a"+y+"i").border = "0";
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) || (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"b"+y+"i").width  = "32";
			document.getElementById(x+"b"+y+"i").height = "32";
			document.getElementById(x+"b"+y+"i").border = "0";
		}
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) && (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"c"+y+"i").width  = "32";
			document.getElementById(x+"c"+y+"i").height = "32";
			document.getElementById(x+"c"+y+"i").border = "0";
			document.getElementById(x+"d"+y+"i").width  = "32";
			document.getElementById(x+"d"+y+"i").height = "32";
			document.getElementById(x+"d"+y+"i").border = "0";
		}
		mArray[x+"x"+y] = 0;
	}
}
function set_mark_ms() {
	if(!document.getElementById) {
		alert("Warning: Your Browser could not support marking system.");
		return false;
	}
	if(document.mapForm.MSMARK[0].checked){
		do_mark_ms(1);// �δ�
	}else if(document.mapForm.MSMARK[1].checked){
		do_mark_ms(2);// �̻���
	}else if(document.mapForm.MSMARK[2].checked){
		do_mark_ms(3);// ���� ���׷�
	}
}
function do_mark_ms(m) {
	for (x=0;x<$HislandSize;x++) {
		for (y=0;y<$HislandSize;y++) {
			if(m == 1) {
				if(DivPw[y][x] > 0){
					sc = DivPwC[y][x];
					if(sc == 'enemy') sc = 'red';
					set_highlight2(x, y, DivPw[y][x], sc);
				}else{
					unset_highlight2(x, y);
				}
			}else if(missile[y][x] > 0 && m == 2) {
				set_highlight2(x, y, missile[y][x], 'aqua');
			}else if(resist[y][x] < 10 && m == 3) {
				set_highlight2(x, y, resist[y][x], 'aqua');
			}else if(m == 4) {
				if(document.mapForm.IDMARK.checked && owner[y][x] > 0 && owner[y][x] != ownerID){
					ctbl = ['white','lime','red','aqua','yellow','fuchsia','white','maroon','gray','blue','green','purple','olive','navy','black','teal','silver','white','white'];
					set_highlight(x, y, ctbl[owner[y][x]]);
				}else{
					unset_highlight(x, y);
				}
			}else{
				unset_highlight2(x, y);
			}
		}
	}
}
function set_highlight2(x, y, z, c) {
	if(document.getElementById) {
		document.getElementById(x+"a"+y).style.color = c;
		document.getElementById(x+"a"+y).innerHTML = z;
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) || (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"b"+y).style.color = c;
			document.getElementById(x+"b"+y).innerHTML = z;
		}
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) && (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"c"+y).style.color = c;
			document.getElementById(x+"d"+y).style.color = c;
			document.getElementById(x+"c"+y).innerHTML = z;
			document.getElementById(x+"d"+y).innerHTML = z;
		}
	}
}
function unset_highlight2(x, y) {
	if(document.getElementById) {
		document.getElementById(x+"a"+y).innerHTML = "";
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) || (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"b"+y).style.color = c;
			document.getElementById(x+"b"+y).innerHTML = "";
		}
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) && (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"c"+y).innerHTML = "";
			document.getElementById(x+"d"+y).innerHTML = "";
		}
	}
}
function mark_menu(){
	if(!document.mark_form.mark.checked){
		unset_all_highlight();
	}else{
		menuclose();
	}
}
// ��� ��ŷ�� ����
function unset_all_highlight() {
	for (f=0;f<$HislandSize;f++) {
		for (i=0;i<$HislandSize;i++) {
			if(mArray[i+"x"+f] == 1) {
				unset_highlight(i, f);
			}
		}
	}
}
// Ÿ���� ����
function swTakoku(){
	var id = document.myForm.TARGETID.options[document.myForm.TARGETID.selectedIndex].value;
	if(id > 0){
		document.getElementById("TakokuText").innerHTML = document.getElementById("Takoku"+id).innerHTML;
	}else{
		document.getElementById("TakokuText").innerHTML = "";
	}
}
function TakokuYuSe(ID){
	moveLAYER(ID,mx+10,my-150);
}
function handicap(){
	document.mapForm.COMSTATUS1.value= "2���� �̻����κ��� ���ݹް� �־�, ����� ������ ��ȭ�� �ڱ��� ������ �Ѵ� ��쿡 �ڵ�ĸ�� ��ũ�� ���� ���� �� �ֽ��ϴ�.";
}
function select_command(set_form, form_name) {
	var Sel = set_form.command_list.options[set_form.command_list.selectedIndex].value;
	if(Sel == ""){
		return;
	}else if(Sel > 100){
		Sel = Sel - 100;
		cominput(form_name, 6, $HcomItem, Sel);
	}else{
		cominput(form_name, 6, Sel, 0);
	}
	document.com_list.command_list.selectedIndex = -1;
}

//-->
</SCRIPT>
END
	islandInfo();
	out(<<END);
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell width=30% onmouseout="mc_out();return false;">
<br>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST onsubmit="return send_command(this);">
<B>��ȹ ��ȣ</B><SELECT NAME=NUMBER onchange="selCommand(this.selectedIndex)">
END
	# ��ȹ ��ȣ
	my($j, $i, $itemMenu);
	for($i = 0; $i < $HcommandMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}
	if ($HmenuOpen eq 'on') {
		$open = "CHECKED";
	}else{
		$open = "";
	}
	if($HjavaMode eq 'java'){
		$itemMenu = "<INPUT TYPE=\"checkbox\" NAME=\"MENUOPEN2\" $open onClick=\"menuclose()\">������<br>";
	}else{
		$itemMenu = "<INPUT TYPE=\"hidden\" NAME=\"MENUOPEN2\"><br>";
	}
	out(<<END);
</SELECT><BR>
<HR>
<B>���� ��ȹ</B>
<INPUT TYPE="checkbox" NAME="MENUOPEN" $open onClick="menuclose()">��ǥ��
$itemMenu
<SELECT NAME=menuchoice onchange="SelectList(myForm)">
<OPTION VALUE=>������
END
	for($i = 0; $i < $com_count; $i++) {
		($aa) = split(/,/,$HcommandDivido[$i]);
		out("<OPTION VALUE=$i>$aa\n");
	}
	out(<<END);
</SELECT>
<SELECT NAME=COMMAND onChange="StatusMsg(this.options[this.selectedIndex].value)" onClick="StatusMsg(this.options[this.selectedIndex].value)">
<option>��������������������</option>
<option>��������������������</option>
<option>��������������������</option>
<option>��������������������</option>
<option>��������������������</option>
<option>��������������������</option>
<option>��������������������</option>
<option>��������������������</option>
<option>��������������������</option>
<option>��������������������</option>
</SELECT>
<HR>
Ŀ��� �Է�<B>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,1)">����</A>
��<A HREF=JavaScript:void(0); onClick="cominput(myForm,2)">������</A>
��<A HREF=JavaScript:void(0); onClick="cominput(myForm,3)">����</A>
</B>
<HR>
<B>��ǥ(</B>
<SELECT NAME=POINTX>
END
	for($i = 0; $i < $HislandSize; $i++) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END
	for($i = 0; $i < $HislandSize; $i++) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<END);
</SELECT><B>)</B>
<B>����</B><SELECT NAME=AMOUNT>
END
	# ����
	for($i = 0; $i < 50; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}
	for($i = 50; $i < 251; $i+=10) {
		out("<OPTION VALUE=$i>$i\n");
	}
	out(<<END);
</SELECT>
<HR>
<B>��ǥ�� ����</B>��
<SELECT NAME=TARGETID onchange="swTakoku()">
$HtargetList<BR>
</SELECT>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="comary">
<INPUT TYPE=submit VALUE="��ȹ �۽�" NAME=CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}>
<INPUT TYPE=password NAME=PASSWORD VALUE="${\htmlEscape($HdefaultPassword)}" SIZE=8>
<INPUT TYPE="hidden" NAME="DUMMY" VALUE="DUMMY">
<span id="progress"></span>
</CENTER>
<HR>
<SPAN $HbgCommandCell>
<CENTER>
<B>Ŀ��� �̵�</B>��
<BIG>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,4)" STYlE="text-decoration:none"> �� </A> ����
<A HREF=JavaScript:void(0); onClick="cominput(myForm,5)" STYlE="text-decoration:none"> �� </A>
</BIG>
</CENTER>
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
   <layer name="LINKMSG1" width="200"></layer>
   <span id="LINKMSG1"></span>
</ilayer>
<BR>
Ŀ��� ǥ�ü���
<SELECT NAME=CMDMAX onClick="init2()" onChange="init2()">
END
	if($HcommandMax < 22){
		out("<OPTION VALUE=$HcommandMax>MAX\n");
	}else{
		out("<OPTION VALUE=20>20<OPTION VALUE=$HcommandMax>MAX\n");
	}
	out(<<END);
</SELECT>

</SPAN>
</FORM>
</TD>
<TD $HbgMapCell>
<FORM name="mapForm">
<INPUT TYPE="radio" NAME="MSMARK" onClick="set_mark_ms()" checked>�δ� ǥ��
<INPUT TYPE="radio" NAME="MSMARK" onClick="set_mark_ms()">�̻��� ��ź ���� ǥ��
<INPUT TYPE="radio" NAME="MSMARK" onClick="set_mark_ms()">���� ���׷� ǥ��
<INPUT TYPE="checkbox" NAME="IDMARK" onClick="do_mark_ms(4)">���� �з�
<center><TEXTAREA NAME='COMSTATUS1' cols='90' rows='2'>$advice</TEXTAREA></center>
END
	islandMap(2,1); # ���� ����, ������ ���
	my $comment = $Hislands[$HcurrentNumber]->{'comment'};
	out(<<END);
<center><TEXTAREA NAME='COMSTATUS2' cols='90' rows='2'></TEXTAREA></center>
</FORM>

<TABLE BORDER=0>
<TR><TD>
<FORM name="allForm" action="$HthisFile" method=POST>
<INPUT TYPE="hidden" NAME=PASSWORD VALUE="${\htmlEscape($HdefaultPassword)}">
<INPUT TYPE="hidden" NAME=NUMBER VALUE="allno">
<INPUT TYPE="hidden" NAME=POINTY VALUE="0">
<INPUT TYPE="hidden" NAME=POINTX VALUE="0">
<DIV ID='AutoCommand'><B>�ڵ���</B>
<SELECT NAME=COMMAND>
END
	#���ޥ��
	my($kind, $cost, $s);
	my($m) = @HcommandDivido;
	my($aa,$dd,$ff) = split(/,/,$HcommandDivido[$m-1]);
	for($i = 0; $i < $HcommandTotal; $i++) {
	$kind = $HcomList[$i];
	$cost = $HcomCost[$kind];
	if($kind > $ff){
		if($cost == 0) {
			$cost = '����'
		}
		if($kind == $HdefaultKind) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
		}
	}
	out(<<END);
</SELECT>
<INPUT TYPE="hidden" NAME="CommandButton$Hislands[$HcurrentNumber]->{'id'}">
<INPUT TYPE="button" onClick="SelectPOINT()" VALUE="�ڵ��� �۽�">
</DIV>
</FORM>
</TD><TD>
END
	my($ostr) = "�ֺ� ǥ�� OFF��";
	if($island->{'custom'} & 1){
		$ostr = "�ֺ� ǥ�� ON��";
	}
	out(<<END);
<FORM name="FormCustom" action="$HthisFile" method=POST>
<INPUT TYPE=hidden NAME=PASSWORD VALUE="${\htmlEscape($HdefaultPassword)}">
<INPUT TYPE=submit VALUE="$ostr" NAME=customMButton$Hislands[$HcurrentNumber]->{'id'}">
<INPUT TYPE=hidden NAME=custom0">
</FORM>
</TD>
END
	my($ostr) = "�� ��ź ���� ǥ�ÿ�";
	if($island->{'custom'} & 2){
		$ostr = "�δ� ǥ�ÿ�";
	}
	out(<<END);
<TD>
<FORM name="FormCustom" action="$HthisFile" method=POST>
<INPUT TYPE=hidden NAME=PASSWORD VALUE="${\htmlEscape($HdefaultPassword)}">
<INPUT TYPE=submit VALUE="$ostr" NAME=customMButton$Hislands[$HcurrentNumber]->{'id'}">
<INPUT TYPE=hidden NAME=custom1">
</FORM>
</TD>
</TR></TABLE>

</TD></TR></TABLE>
<!-- ���� ���� �� -->
<div id="ch_num" style="position:absolute;visibility:hidden;display:none">
<form name="ch_numForm">
<TABLE BORDER=1 BGCOLOR="#e0ffff" CELLSPACING=1>
<TR><TD VALIGN=TOP NOWRAP>
<A HREF="JavaScript:void(0)" onClick="hideElement('ch_num');" STYlE="text-decoration:none"><B>��</B></A>
<A HREF="JavaScript:void(0)" onClick="chNumDo(250);" STYlE="text-decoration:none"><B>Max</B></A>
<BR>
<select name="AMOUNT" size=13 onchange="chNumDo(0)">
</select>
</TD></TR>
</TABLE></form></div>
END
	if($HjavaMode eq 'java'){
		out(<<END);
<!--  Ŀ��� �� -->
<DIV ID="mc_div" style="background-color:white;position:absolute;top:-50;left:-50;height:22px;">&nbsp;</DIV>
<DIV ID="menu" style="position:absolute; top:-500;left:-500;">
<table border=0 class="PopupCell">
<tr><td NOWRAP COLSPAN=2><a href="Javascript:void(0);" onClick="menuclose()" class='M'>�޴��� �ݴ´�</A></td></tr>
<tr><td nowrap>$click_com<hr>$click_com3</td><td NOWRAP>$click_com2</td></tr>
</table></DIV>
END
	}else{
		out(<<END);
<!-- ���� ���� �� -->
<DIV ID="mc_div" style="background-color:white;position:absolute;top:-50;left:-50;height:22px;">&nbsp;</DIV>
<DIV ID="menu" style="position:absolute; top:-500;left:-500;">
<FORM NAME="com_list">
<TABLE BORDER=1 class="PopupCell">
<TR><TD VALIGN=TOP NOWRAP>
[<A HREF="JavaScript:void(0)" onClick="menuclose()" STYlE="text-decoration:none"><B>��</B></A>]
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,-1)' ID=PMENU0 STYlE='text-decoration:none'>�켱</A> 
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,0)' ID=PMENU1 STYlE='text-decoration:none'>��</A> 
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,1)' ID=PMENU2 STYlE='text-decoration:none'>��</A> 
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,2)' ID=PMENU3 STYlE='text-decoration:none'>��</A> 
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,3)' ID=PMENU4 STYlE='text-decoration:none'>Ÿ</A>
<BR>
<span id="popupmenu">
<SELECT size="18" NAME="command_list" onChange="select_command(com_list, myForm)">
</SELECT>
</span>
</TD></TR>
<TR><TD ALIGN=CENTER>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">�޴��� �ݴ´�</A>
</TD></TR></TABLE></FORM></DIV>
END
	}
	out(<<END);

<DIV ID="menu2" style="position:absolute; top:-500;left:-500;">
<table border=0 class="PopupCell">
<tr><td NOWRAP><a href="Javascript:void(0);" onClick="menuclose()" class='M'>�޴��� �ݴ´�</A></td></tr>
<tr><td NOWRAP>$click_com4</td></tr>
</table></DIV>

<FORM NAME="mark_form">
[��ŷ<INPUT TYPE=CHECKBOX NAME="mark" onClick="mark_menu()">
����
<SELECT NAME="kind_mark">
<OPTION VALUE="">ǥ��
<OPTION VALUE="yellow">Yellow
<OPTION VALUE="red">Red
<OPTION VALUE="blue">Blue
<OPTION VALUE="purple">Purple
<OPTION VALUE="gray">Gray
<OPTION VALUE="-">None
</SELECT>
����
<SELECT NAME="number_mark">
<OPTION VALUE="1">0HEX
<OPTION VALUE="7">1HEX
<OPTION VALUE="19" SELECTED>2HEX
<OPTION VALUE="37">3HEX
<OPTION VALUE="61">4HEX
</SELECT>]
��[<INPUT TYPE="BUTTON" VALUE="��ŷ ����" onClick="unset_all_highlight();">]
</FORM>
END
	my($ostr) = '<FONT COLOR="#0000FF">�ϴ�</FONT>(ǥ��)';
	$ostr = '<FONT COLOR="#FF0000">���� �ʴ�</FONT>' if($island->{'custom'} & 4);
	out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE=hidden NAME=PASSWORD VALUE="${\htmlEscape($HdefaultPassword)}">
[<b>Ŀ��� ���� ����</b>���� �Һ��ϴ� Ŀ��带 ������ �� ���, ���� ���� �մ�� ����<B>$ostr</B>
<INPUT TYPE=submit VALUE="����" NAME=customMButton$Hislands[$HcurrentNumber]->{'id'}">]
<INPUT TYPE=hidden NAME=custom2">
</FORM>
</CENTER>
END
}

#----------------------------------------------------------------------
#  Ŀ��� ���
#----------------------------------------------------------------------
sub commandJavaMain {
	# id�κ��� ���� ���
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# �н�����
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# password �Ǽ�
		unlock();
		tempWrongPassword();
		return;
	}

	# ���� �б�
	my($command) = $island->{'command'};
	for($i = 0; $i < $HcommandMax; $i++) {
		# Ŀ��� ���
		$HcommandComary =~ s/([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) //;
		$command->[$i] = {
			'kind' => $1==0 ? $HcomDoNothing : $1,
			'x' => $2,
			'y' => $3,
			'arg' => $4,
			'target' => $5
		};
	}

	#  �������� ����
	writeIslandsFile($HcurrentID);
	if($Hasync) {
		unlock();
		out("AjaxOK");
	} else {
		tempCommandAdd();
		# owner mode��
		ownerMain();
	}
}

1;


