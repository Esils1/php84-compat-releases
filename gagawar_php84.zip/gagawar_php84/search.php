<?php
include("header.php");
if ($do_search)
{
	$query = "";
	if (!$searchlimit)
	{
		$searchlimit = 25;
	}
	if (!$order_by)
	{
		$order_by = "rank";
	}

	if ($search_type == "string")
	{
		SQLquotes($search_string);
	        $query .= " empire LIKE '%$search_string%'";
	}
	elseif ($search_type == "num")
	{
		if ($search_num)
		        $query .= " num=$search_num";
		else	TheEnd("제국 번호를 입력하질 않았습니다!");
	}
	elseif ($search_type == "clan")
	        $query .= " clan=$search_clan";
	elseif ($search_type == "online")
		$query .= " online=1";
	else	TheEnd("검색 방법을 선택하지 않았습니다!");
	if (($search_era) && ($search_era != -1))
		$query .= " and era=$search_era";
	if (($search_max_nw) && ($search_nw_max))
	{
		fixInputNum($search_max_nw);
		$query .= " and networth<=$search_max_nw";
	}
	if (($search_min_nw) && ($search_nw_min))
	{
		fixInputNum($search_min_nw);
		$query .= " and networth>=$search_min_nw";
	}
	if (($search_race) && ($search_race != -1))
	{
		fixInputNum($search_min_nw);
		$query .= " and race=$search_race";
	}
	if ($search_dead)
	{
		$query .= " and ip!='0.0.0.0'";
	}
	$dbstr = db_query("SELECT rank,empire,num,land,networth,clan,race,era,online,disabled,turnsused,vacation,offsucc,offtotal,defsucc,deftotal,kills FROM $playerdb WHERE $query ORDER BY $order_by LIMIT $searchlimit;");
	if ($numrows = db_num_rows($dbstr))
	{
?>
색 정보: <span class="mprotected">보호/여행 모드</span>, <span class="mdead">사망</span>, <span class="mally">동맹</span>, <span class="mdisabled">정지</span>, <span class="madmin">관리자</span>, <span class="mself">당신</span><br>
상태 정보: O = 공격 성공률 (%), D = 방어 성공률 (%), K = 킬(KILL)<br>
<table class="scorestable">
<?php
		printSearchHeader($users['era']);
		while ($enemy = db_fetch_array($dbstr))
			printSearchLine();
		printSearchHeader($users['era']);
?>
</table>
<?php
		if ($numrows > $searchlimit)
			print "검색 한도 초과.<br>\n";
		else	print "$numrows 제국을 찾았습니다.<br>\n";
	}
	else	print "그런 제국을 찾지 못했습니다.<br>\n";
}
?>
<form method="post" action="<?php echo $config['main']?>?action=search">
<table class="inputtable">
<tr><td>
    <table class="inputtable">
    <tr><th class="aleft"><label>시기:</label></th>
        <td><select name="search_era" size="1">
        <option value="-1">아무거나</option>
<?php
$eralist = db_query("SELECT id,name FROM $eradb;");
while ($era = db_fetch_array($eralist))
{
?>
        <option value="<?php echo $era['id']?>"><?php echo $era['name']?></option>
<?php
}
?>
        </select></td></tr>
    <tr><th class="aleft"><label>종족:</label></th>
        <td><select name="search_race" size="1">
            <option value="-1" selected>아무거나</option>
<?php
$races = db_query("select id,name from $racedb;");
while ($race = db_fetch_array($races))
{
?>
            <option value="<?php echo $race['id']?>"><?php echo $race['name']?></option>
<?php
}
?>
            </select></td></tr>
    <tr><th class="aleft"><label>최대 총 재산:</label><input type="checkbox" name="search_nw_max" <?php if($search_nw_max) print" checked";?>)></th>
        <td>$<input type="text" name="search_max_nw" size="9" value="<?php if ($search_max_nw) echo $search_max_nw; else echo commas(10*$users['networth']);?>"></td></tr>
    <tr><th class="aleft"><label>최소 총 재산:</label><input type="checkbox" name="search_nw_min" <?php if($search_nw_min) print" checked";?>></th>
        <td>$<input type="text" name="search_min_nw" size="9" value="<?php if ($search_min_nw) echo $search_min_nw; else echo commas($users['networth']/10);?>"></td></tr>
    <tr><th class="aleft">정렬:</th>
        <td><input type="radio" name="order_by" value="rank" checked>총 재산</td></tr>
    <tr><th></th>
        <td><input type="radio" name="order_by" value="num">제국 번호</td></tr>
    <tr><th></th>
        <td><input type="radio" name="order_by" value="empire">제국 이름</td></tr>
    <tr><th></th>
        <td><input type="radio" name="order_by" value="clan">동맹</td></tr>
    <tr><th>멸망한 제국 제외:</th>
        <td><input type="checkbox" name="search_dead"></td></tr>
    <tr><th class="aleft"><label>최대 결과:</label></th>
        <td><input type="text" name="searchlimit" size="4" value="<?php if ($searchlimit) echo $searchlimit; else echo 25;?>"></td></tr>
    </table></td>
    <td><table class="inputtable">
        <tr><th class="aleft"><label><input type="radio" name="search_type" value="num"> 제국 번호:</label></th>
            <td><input type="text" name="search_num" size="4"></td></tr>
        <tr><th class="aleft"><label><input type="radio" name="search_type" value="string" checked> 검색 문자열:</label></th>
            <td><input type="text" name="search_string" size="15"></td></tr>
        <tr><th class="aleft"><label><input type="radio" name="search_type" value="clan"> 동맹 Tag 검색:</label></th>
            <td><select name="search_clan" size="1">
                <option value="0">없음 - 비동맹 제국</option>
<?php
$clanlist = db_query("SELECT num,name,tag FROM $clandb WHERE members>0 ORDER BY num;");
while ($clan = db_fetch_array($clanlist))
{
?>
                <option value="<?php echo $clan['num']?>"><?php echo $clan['tag']?> - <?php echo $clan['name']?></option>
<?php
}
?>
            </select></td></tr>
        <tr><th class="aleft"><label><input type="radio" name="search_type" value="online"> 온라인 검색</label></th>
            <td></td></tr>
        </table>
    </td></tr>
<tr><td colspan="2"><input type="submit" name="do_search" value="Search"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
