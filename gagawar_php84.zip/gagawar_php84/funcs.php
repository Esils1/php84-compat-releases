<?php
include("html.php");

// checkturns security fix
// - zEro
// Under ALPHA checking...

function CheckTurns ($numturns) {
	global $users, $config;
	$turns2 = $config['maxturns'] + 1;
	if ($numturns > $turns2) 
		TheEnd('<span class="cbad">치명적인 오류 발생</span>: 사용 가능한 턴 보다 더 많이 사용하려 했습니다!.');
	else if ($numturns > $users['turns'])
		TheEnd('<span class="cbad">치명적인 오류 발생</span>: 사용 가능한 턴 보다 더 많이 사용하려 했습니다!');		
}

// adds commas to a number
function commas ($str)
{
	return number_format($str,0,".",",");
}

// replace ' with '' to avoid malformed SQL queries
function sqlQuotes (&$str)
{
	$str = str_replace("'","''",stripslashes($str));
}

// Con...
function updateinfo($file) 
{ 
	global $prom_version; 
	if (is_file($file)) 
	{ 
		$cup_hd = fopen ($file, "r"); 
		$a=0; 
		while (!feof ($cup_hd)) 
		{ 
    		$cup_buff[$a] = fgets($cup_hd, 4096); 
			$a++; 
		} 
		fclose ($cup_hd); 
	} 
	else 
	{ 
		echo "Error: Please enter a valid file<br>"; 
	} 
	for ($a=0;$a<sizeof($cup_buff);$a++) 
	{ 
		if ($cup_buff[$a] <= $prom_version) 
		{  
			mail($config['adminemail'],"New Version of Promisance!","Informing that the new version of Promisance Enhanced is now avaliable for download.");
		} 
	} 
} 

// remove commas, make integer
function fixInputNum (&$num)
{
	$num = round(str_replace(",","",$num));
}

// randomize the mt_rand() function
function randomize ()
{
	mt_srand((double)microtime()*1000000);
}

// pluralize a string
function plural ($num, $plur, $sing)
{
	if ($num != 1)
		return $plur;
	else	return $sing;
}

// evaluate an SQL query, return first cell of first row
// useful for "SELECT count(*) ..." queries
function sqleval ($query)
{
	$data = db_fetch_row(db_query($query));
	return $data[0];
}

// prints a number, colored according to its positivity/negativity.
// Set nosign=1 to omit the +/-
function printCNum ($amt, $prefix, $nosign)
{
	$pos = "+";
	$neg = "-";
	if ($nosign)
		$neg = $pos = "";
?>
<span class=<?php
//!!!????
       	if ($amt < 0)
		print '"cbad">'.$neg.$prefix;
	elseif ($amt > 0)
		print '"cgood">'.$pos.$prefix;
	else	print '"cneutral">';
	print	commas(abs($amt));?></span><?php
}

// returns the requested networth
function getNetworth (&$user)
{
	global $config;
// New Net...
// (Troops * 1.5) + (Ballistas * 2) + (Dragons * 4) + (Galleons * 6) + (Land * 95) + (Peasants * 2) + (Cash / 10000) + (Towers * 10) + (Wizards * 2)
	return floor(($user['armtrp'] * 1.5) + ($user['lndtrp'] * 2) + ($user['flytrp'] * 4) + ($user['seatrp'] * 6) + ($user['land'] * 95) + ($user['peasants'] * 2) + ($user['cash'] / 10000) + ($user['towers'] * 10) + ($user['wizards'] * 2));

// Old Networth
//	return floor(($user[armtrp] * 1) + ($user[lndtrp] * $config[lndtrp] / $config[armtrp]) + ($user[flytrp] * $config[flytrp] / $config[armtrp]) + ($user[seatrp] * $config[seatrp] / $config[armtrp]) + ($user[wizards] * 2) + ($user[peasants] * 3) + (($user[cash] + $user[savings]/2 - $user[loan]*2) / (5 * $config[armtrp])) + ($user[land] * 500) + ($user[freeland] * 100) + ($user[food] * $config[food] / $config[armtrp]));
}


function pci ($user, $race)
{

// New PCI
	return round(100 * (1 + $user['shops'] / $user['land']) * ($user['tax'] / 100) * $race['pci']);
// Old PCI
//	return round(25 * (1 + $user[shops] / $user[land]) * $race[pci]);
}

// loads the information for the specified user number
function loadUser ($num)
{
	global $playerdb;
	return db_fetch_array(db_query("SELECT * FROM $playerdb WHERE num='$num';"));
}

// loads the information for the specified race number
function loadRace ($race)
{
	global $racedb;
	return db_fetch_array(db_query("SELECT * FROM $racedb WHERE id='$race';"));
}

// loads the information for the specified era number
function loadEra ($era)  {   
	global $eradb;   
	return db_fetch_array(db_query("SELECT * FROM $eradb WHERE id='$era'"));  
}

function loadClan ($num)
{
	global $clandb;
	return db_fetch_array(db_query("SELECT * FROM $clandb WHERE num='$num';"));
}

function loadClanTags ()
{
	global $clandb;
	$clans = db_query("SELECT num,tag FROM $clandb;");
	while ($clan = db_fetch_array($clans))
		$ctags["$clan[num]"] = $clan['tag'];
	$ctags["0"] = "None";
	return $ctags;
}

// Loads all race names into an associative array, intended for the scorelists
function loadRaceTags ()
{
	global $racedb;
	$races = db_query("SELECT id,name FROM $racedb;");
	while ($race = db_fetch_array($races))
		$rtags["$race[id]"] = $race['name'];
	return $rtags;
}

// Loads all era names, intended for the scorelists
function loadEraTags ()
{
	global $eradb;
	$eras = db_query("SELECT id,name FROM $eradb;");
	while ($era = db_fetch_array($eras))
		$etags["$era[id]"] = $era['name'];
	return $etags;
}

// Example: saveClanData($uclan,"name motd ally1 war3");
function saveClanData (&$clan, $data)
{
	global $clandb, $lockdb;
	if ($lockdb)
		return;
	$items = explode(" ",$data);
	$update = "";
	$i = 0;
	while ($tmp = $items[$i++])
	{
		$data = $clan[$tmp];
		if (is_numeric($data))
			$update .= "$tmp=$data";
		else
		{
			sqlQuotes($clan[$tmp]);
			$update .= "$tmp='$data'";
		}
		if ($items[$i]) $update .= ",";
	}
	if (!db_query("update $clandb set $update where num=$clan[num];"))
		print "FATAL ERROR: Failed to update clan data $update for clan #$clan[num]!<BR>\n";
}



// Example: saveUserData($users,"cash networth armtrp lndtrp flytrp seatrp etc");
function saveUserData (&$user, $data)
{
	global $playerdb, $lockdb;
	if ($lockdb)
		return;
	$items = explode(" ",$data);
	$update = "";
	$i = 0;
	while ($tmp = $items[$i++])
	{
		$data = $user[$tmp];
		if (is_numeric($data))
			$update .= "$tmp=$data";
		else
		{
			sqlQuotes($data);
			$update .= "$tmp='$data'";
		}
		if ($items[$i]) $update .= ",";
	}
	if (!db_query("UPDATE $playerdb SET $update WHERE num=$user[num];"))
		print "FATAL ERROR: Failed to update player data $update for user #$user[num]!<BR>\n";
}

// Saves data for a particular user, updating their networth in the process
// MUST specify "networth" among the fields to save!
// Example: saveUserDataNet($users,"networth cash armtrp lndtrp flytrp seatrp etc");
function saveUserDataNet (&$user, $data)
{
	$user['networth'] = getNetworth($user);
	return saveUserData($user, $data);
}

// function to return amount of land
function gimmeLand($currland, $bonus, $era)
{
	if ($era == 1)
		$multip = 1;
	elseif ($era == 2)
		$multip = 1.4;
	elseif ($era == 3)
		$multip = 1.8;
	
	return ceil((1 / ($currland * .00022 + .25)) * 20 * $bonus * $multip);
}

function calcSizeBonus ($networth)
{
	if ($networth <= 100000)
		$size = 0.524;
	elseif ($networth <= 500000)
		$size = 0.887;
	elseif ($networth <= 1000000)
		$size = 1.145;
	elseif ($networth <= 10000000)
		$size = 1.294;
	elseif ($networth <= 100000000)
		$size = 1.454;
	else	$size = 1.674;
	return $size;
}

function printStatsBar ()
{
	global $users, $uera, $config;
?>
<table style="width:100%">
<tr class="era<?php echo $users['era']?>" style="font-size:medium">
    <td class="acenter"><a href="<?php echo $config['main']?>?action=messages"><?php if (numNewMessages() > 0) print "<b><font color=red>New Mail!</font></b>"; else print "메세지함";?></a></td>
    <td class="acenter">턴: <?php echo $users['turns']?></td>
    <td class="acenter">돈: $<?php echo commas($users['cash'])?></td>
    <td class="acenter">땅: <?php echo commas($users['land'])?></td>
    <td class="acenter"><?php echo $uera['food']?>: <?php echo commas($users['food'])?></td>
    <td class="acenter">건강: <?php echo commas($users['health'])?>%</td>
    <td class="acenter">총 재산: $<?php echo commas($users['networth'])?></td></tr>
</table>
<table style="width:100%">
<tr class="era<?php echo $users['era']?>" style="font-size:medium">
	 <td class="acenter">추가 정보</td>
	 <td class="acenter">철: <?php echo commas($users['iron'])?></td>
    <td class="acenter"><?php echo $uera['runes']?>: <?php echo commas($users['runes'])?></td>
</tr>
</table>
<?php
}

// Take a specified number of turns performing the given action
// Valid actions (so far): cash, land, war; others will be added as necessary
function takeTurns ($numturns, $action)
{
	global $config;
	global $users, $urace, $uera, $landgained, $cashgained, $foodgained, $time;
	if ($users['era'] == 1)
	{
		$urace['ind'] *= .95;
		$urace['runes'] *= 1.4;
	}
	if ($users['era'] == 2)

	if ($users['era'] == 3)
	{
		$urace['ind'] *= 1.15;
		$urace['runes'] *= .80;
	}

	// Check turns function
	// - zEro
	// ALPHA Testing...

	CheckTurns($numturns);

	
		if (($action == 'cash') || ($action == 'land') || ($action == 'farm') || ($action == 'mine'))	// Actions which can be aborted
		$nonstop = 0;
	else	$nonstop = 1;

	$taken = 0;
	while ($taken < $numturns)					// use up specified number of turns
	{
		$taken++;
		$users['networth'] = getNetworth($users);
		if ($action == 'land')					// exploring?
		{
			$tmp = gimmeLand($users['land'],$urace['expl'],$users['era']);
			$users['land'] += $tmp;
			$users['freeland'] += $tmp;
			$landgained += $tmp;
		}
		$size = calcSizeBonus($users['networth']);		// size bonus/penalty
		$loanrate = $config['loanbase'] + $size;			// update savings and loan
		$saverate = $config['savebase'] - $size;
		$users['loan'] *= 1 + ($loanrate / 52 / 100);
		if ($users['turnsused'] > $config['protection'])		// no savings interest while under protection
			$users['savings'] *= 1 + ($saverate / 52 / 100);
		$users['loan'] = round($users['loan']);
		$users['savings'] = round($users['savings']);
		if ($users['savings'] > ($users['networth'] * 10))
			$users['savings'] = $users['networth'] * 10;
// income
// Old Income :P
//		$income = round(((pci($users,$urace) * ($users[tax] / 100) * ($users[health] / 100) * $users[peasants]) + ($users[shops] * 500)) / $size);

// New Income suggested by thadius aka gzip
		$income = round(((pci($users,$urace) * ($users['tax'] / 100) * ($users['health'] / 90) * $users['peasants']) + ($users['shops'] * 650)) / $size);

		if ($action == 'cash')					// cashing?
			// Era Hack 
			if ($users['era'] == 2) {
				$income = round($income * 1.53);
			}
			elseif ($users['era'] == 3) {
				$income = round($income * 1.15);
			}
			else
				$income = round($income * 1.25);
		$wartax = 0;
		if ($warflag)						// war tax?
			$wartax = $networth / 1000;

// expenses
		$loanpayed = round($users['loan'] / 200);
		$expenses = round(($users['armtrp'] * .8) + ($users['lndtrp'] * 1.2) + ($users['flytrp'] * 1.7) + ($users['seatrp'] * 2.4) + ($users['land'] * 4) + ($users['wizards'] * .5));
		$expbonus = round($expenses * ($urace['costs'] - ($users['barracks'] / $users['land'])));
		if ($expbonus > $expenses / 2)				// expenses bonus limit
			$expbonus = round($expenses / 2);
		$expenses -= $expbonus;
		$money = $income - ($expenses + $loanpayed + $wartax);
		$cashgained += $money;
		$users['loan'] -= $loanpayed;
		$users['cash'] += $money;
// build extra units
		$armtrp = ceil(($users['industry'] * ($users['ind_armtrp'] / 100)) * 8 * $urace['ind']);
		$users['armtrp'] += $armtrp;
		$lndtrp = ceil(($users['industry'] * ($users['ind_lndtrp'] / 100)) * 4 * $urace['ind']);
		$users['lndtrp'] += $lndtrp;
		$flytrp = ceil(($users['industry'] * ($users['ind_flytrp'] / 100)) * 2 * $urace['ind']);
		$users['flytrp'] += $flytrp;
		$seatrp = ceil(($users['industry'] * ($users['ind_seatrp'] / 100)) * 1 * $urace['ind']);
		$users['seatrp'] += $seatrp;
// update food
// Formulas:
// Foodproduction = (freeland * 5) + (farms * 150) * farms_bonus 
// Food consumption = [(footmen * .03) + (ballistas * .03) + (dragons * .02) + (galleons * .01) + (pop * .01) + (wizards * .20)] * food_bonus
		$foodpro = round(($users['freeland'] * 5) + ($users['farms'] * 150) * $urace['farms']);
		$foodcon = round((($users['armtrp'] * .03) + ($users['lndtrp'] * .03) + ($users['flytrp'] * .02) + ($users['seatrp'] * .01) + ($users['peasants'] * .01) + ($users['wizards'] * .20)) * $urace['food']);
		if ($action == 'farm')					// farming?
			// Era Hack 2 
			if ($users['era'] == 2) {
				$foodpro = round($foodpro * 1.15);
			}
			elseif ($users['era'] == 3) {
				$foodpro = round($foodpro * 1.25);
			}
			else
				$foodpro = round($foodpro * 1.53);

		$food = $foodpro - $foodcon;
		$users['food'] += $food;
		$foodgained += $food;


// Using Race Now
// Formulas:
// Iron Production = [(freeland * 5) + (mines * 75)] * race_iron_bonus
// Iron Consumption = [(footmen * .03) + (galleons * .01) + (population * .01) + (dragons * .02)] * race_ironlack 


		$ironpro = round((($users['freeland'] * 5) + ($users['mines'] * 75)) * $urace['ironbonus']);
		$ironcon = round((($users['armtrp'] * .03) + ($users['seatrp'] * .01) + ($users['peasants'] * .01) + ($users['flytrp'] * .02)) * $urace['ironlack']);

		if ($action == 'mine')					// Mining?
			// Era Hack 2 
			if ($users['era'] == 2) {
				$ironpro = round($ironpro * 1.15);
			}
			elseif ($users['era'] == 3) {
				$ironpro = round($ironpro * 1.53);
			}
			else {
				$ironpro = round($ironpro * 1.25);
			}

		$iron = $ironpro - $ironcon;
		$users['iron'] += $iron;
		$irongained += $iron;


// health
		if ($users['health'] < 101)
			$users['health']++;
		if ($users['health'] >= 100) 
			$users['health'] = 100;
// taxes
		$taxrate = $users['tax'] / 100;
		if ($users['tax'] > 40)
			$taxpenalty = ($taxrate - 0.40) / 2;
		if ($users['tax'] < 20)
			$taxpenalty = ($taxrate - 0.20) / 2;
// update population
		$popbase = round((($users['land'] * 2) + ($users['freeland'] * 5) + ($users['homes'] * 60)) / (0.95 + $taxrate + $taxpenalty));

		if ($users['peasants'] != $popbase)
			$peasants = ($popbase - $users['peasants']) / 20;
		if ($peasants > 0)	$peasmult = (4 / (($users['tax'] + 15) / 20)) - (7 / 9);
		if ($peasants < 0)	$peasmult = 1 / ((4 / (($users['tax'] + 15) / 20)) - (7 / 9));
		$peasants = round($peasants * $peasmult * $peasmult);
		$users['peasants'] += $peasants;
// gain magic energy
		$runes = 0;
		if (($users['labs'] / $users['land']) > .15)
			$runes = mt_rand(round($users['labs'] * 5.1),round($users['labs'] * 5.5));
		else	$runes = round($users['labs'] * 5.1);
		$runes = round($runes * $urace['runes']);
		$users['runes'] += $runes;
		$wizards = 0;
// These values in the midst of adjustment
		if ($users['wizards'] < ($users['labs'] * 25))
			$wizards = round($users['labs'] * 1.45);
		elseif ($users['wizards'] < ($users['labs'] * 50))
			$wizards = round($users['labs'] * 1.30);
		elseif ($users['wizards'] < ($users['labs'] * 90))
			$wizards = round($users['labs'] * 1.15);
		elseif ($users['wizards'] < ($users['labs'] * 100))
			$wizards = round($users['labs'] * 1.10);
		elseif ($users['wizards'] > ($users['labs'] * 175))
			$wizards = round($users['wizards'] * -.05);
		$users['wizards'] += $wizards;

// print status report
?>

<table class="empstatus">
<tr><td style="vertical-align:top"><table>
    <tr class="inputtable"><th colspan="2">경제 상태</th></tr>
    <tr><th>수입:</th>
        <td>$<?php echo commas($income)?></td></tr>
    <tr><th>지출:</th>
        <td>$<?php echo commas($expenses)?></td></tr>
    <tr><th>전쟁 세금:</th>
        <td>$<?php echo commas($wartax)?></td></tr>
    <tr><th>대출 상환금:</th>
        <td>$<?php echo commas($loanpayed)?></td></tr>
    <tr><th>총:</th>
        <td><?php printCNum($money,"$",0);?></td></tr>
    </table></td>

    <td style="vertical-align:top"> <table>   
    <tr class="inputtable"><th colspan="2">농업</th></tr>
    <tr><th>생성:</th>
        <td><?php echo commas($foodpro)?></td></tr>
    <tr><th>소비:</th>
        <td><?php echo commas($foodcon)?></td></tr>
    <tr><th>총:</th>
        <td><?php printCNum($food,"",0);?></th></tr>
    <tr class="inputtable"><th colspan="2">금속 산업</th></tr>
    <tr><th>생성:</th>
        <td><?php echo commas($ironpro)?></td></tr>
    <tr><th>소비:</th>
        <td><?php echo commas($ironcon)?></td></tr>
    <tr><th>총:</th>
        <td><?php printCNum($iron,"",0);?></th></tr>
    </table></td>

    <td style="vertical-align:top"><table>
    <tr class="inputtable"><th colspan="2">인구 & 군사 상태</th></tr>
    <tr><th><?php echo $uera['peasants']?>:</th>
        <td><?php printCNum($peasants,"",0);?></td></tr>
    <tr><th><?php echo $uera['wizards']?>:</th>
        <td><?php printCNum($wizards,"",0);?></td></tr>
    <tr><th><?php echo $uera['runes']?>:</th>
        <td><?php printCNum($runes,"",0);?></td></tr>
    <tr><th><?php echo $uera['armtrp']?>:</th>
        <td><?php printCNum($armtrp,"",0);?></td></tr>
    <tr><th><?php echo $uera['lndtrp']?>:</th>
        <td><?php printCNum($lndtrp,"",0);?></td></tr>
    <tr><th><?php echo $uera['flytrp']?>:</th>
        <td><?php printCNum($flytrp,"",0);?></td></tr>
    <tr><th><?php echo $uera['seatrp']?>:</th>
        <td><?php printCNum($seatrp,"",0);?></td></tr>
    </table></td></tr>
</table>
<?php
/*	// Here begins the non-tables version of the turns display
?>
우리의 <?php echo $uera[peasants]?> 는 $<?php echo commas($income)?> 을 벌었다. 지불비: $<?php echo commas($expenses)?><?php if ($loanpayed) print ", 대출 상환비:  $".commas($loanpayed)."";?>. 총: <?php printCNum($money,"$",0);?><br>
우리의 <?php echo $uera[farms]?> 는 <?php echo commas($foodpro)?> <?php echo $uera[food]?> 을 생성했고 우리의 국민은 <?php echo commas($foodcon)?> <?php echo $uera[food]?> 를 소비했다.  총: <?php printCNum($food,"",0);?> <?php echo $uera[food]?><br>
우리의 <?php echo $uera[labs]?> <?php if ($wizards >= 0) print "는 다음을 훈련했다:"; else print "는 다음을 잃었다:";?> <?php printCNum($wizards,"",1);?> <?php echo $uera[wizards]?> 그리고 다음을 생산했다: <?php printCNum($runes,"",1);?> <?php echo $uera[runes]?>.<br>
<?php
		if ($armtrp || $lndtrp || $flytrp || $seatrp)
		{
?>
우리의 <?php echo $uera[industry]?> 는 다음을 생산했다: <?php echo commas($armtrp)?> <?php echo $uera[armtrp]?>, <?php echo commas($lndtrp)?> <?php echo $uera[lndtrp]?>, <?php echo commas($flytrp)?> <?php echo $uera[flytrp]?>, <?php echo commas($seatrp)?> <?php echo $uera[seatrp]?>.<br>
<?php
		}

		if ($peasants)
		{
			printCNum($peasants,"",1);
			print " 국민이 ";
			if ($peasants > 0)
				print "새롭게 들어왔다.<br>\n";
			else	print "다른 곳으로 이동해 나갔다.<br>\n";
		}
*/	// Here ends the non-tables version of the turns display

		if (($users['tax'] > 40) && ($peasants < 0))
		{
?>
<span class="cbad">당신의 높은 세율은 국민을 분노하게 하고 있습니다.</span><br>
<?php
		}
		elseif (($users['tax'] < 20) && ($peasants > 0))
		{
?>
<span class="cgood">당신의 낮은 세율은 이민자들을 가져오고 있습니다.</span><br>
<?php
		}
?>
<hr style="width:50%">
<?php
		$users['turnsused']++;
		$users['turns']--;
// ran out of money/food? lose 3% of all units
		if (($users['food'] < 0) || ($users['cash'] < 0) || ($users['iron'] < 0))
		{
			$users['peasants'] = round($users['peasants'] * .97);
			for ($i = 0; $i < 4; $i++)
				$users[$trplst[$i]] = round($users[$trplst[$i]] * .97);
			$users['wizards'] = round($users['wizards'] * .97);
			if ($users['food'] < 0)	$users['food'] = 0;
			if ($users['cash'] < 0)	$users['cash'] = 0;
			if ($users['iron'] < 0)	$users['iron'] = 0;
?>
<span class="cbad">음식, 철, 또는 돈 이 부족하여 당신의 군대 및 인구의 3% 이 떠납니다!<?php
			if ($nonstop)
			{
?></span><br>
<?php
			}
			else
			{
?> Turns were stopped!</span><br>
<?php
				break;
			}
		}
	}
	$users['idle'] = time();
	saveUserDataNet($users,"networth land freeland savings loan cash armtrp lndtrp flytrp seatrp food health peasants runes wizards turnsused turns idle iron");
	return $taken;
}

function TheEnd ($reason)	// End current action
{
	global $users, $config, $version;
?>
<?php echo $reason?><br>
<?php
?>
<font size="2"><a href="http://digirave.net" target="_top">한글판 가가전쟁 by: Digirave</a>, 원작: 
<a href="http://www.madeinphp.com" target="_blank">Promisance</a>&trade; v<?php echo $version?> - Copyright &copy; 2001 by <a href="mailto:zero_skape@yahoo.com">zEro</a><br>
<a href="<?php echo $config['main']?>?action=credits">-- Full Credits --</a><br></a>
<?php
	HTMLendfull();
	exit;
}

function printScoreHeader ($color)
{
?>
<tr class="era<?php echo $color?>">
    <th style="width:5%" class="aright">순위</th>
    <th style="width:25%">제국</th>
    <th style="width:10%" class="aright">땅</th>
    <th style="width:15%" class="aright">총 재산</th>
    <th style="width:10%">동맹</th>
    <th style="width:10%">종족</th>
    <th style="width:5%">시대</th>
    <th style="width:5%">킬(KILL)</a></th></tr>
<?php
}

function printScoreLine ()
{
	global $users, $enemy, $rtags, $ctags, $etags, $racedb, $eradb, $config;
	$color = "normal";
	if ($enemy['num'] == $users['num'])
		$color = "self";
	elseif (($enemy['land'] == 0) || ($enemy['land'] < 0))
		$color = "dead";
	elseif ($enemy['disabled'] >= 2)
		$color = "disabled";
	elseif (($enemy['turnsused'] <= $config['protection']) || ($enemy['vacation'] > $config['vacationdelay']))
		$color = "protected";
?>
<tr class="m<?php echo $color?>">
    <td class="aright"><?php if ($enemy['online']) echo "*";?><?php echo $enemy['rank']?></td>
    <td class="acenter"><?php echo $enemy['empire']?> (#<?php echo $enemy['num']?>)</td>
    <td class="aright"><?php echo commas($enemy['land'])?></td>
    <td class="aright">$<?php echo commas($enemy['networth'])?></td>
    <td class="acenter"><?php echo $ctags["$enemy[clan]"]?></td>
    <td class="acenter"><?php echo $rtags["$enemy[race]"]?></td>
    <td class="acenter"><?php echo $etags["$enemy[era]"]?></td>
    <td class="acenter"><?php echo $enemy['kills']?></td></tr>
<?php
}

function printSearchHeader ($color)
{
?>
<tr class="era<?php echo $color?>">
    <th style="width:5%" class="aright">순위</th>
    <th style="width:35%">제국</th>
    <th style="width:10%" class="aright">땅</th>
    <th style="width:15%" class="aright">총 재산</th>
    <th style="width:10%">동맹</th>
    <th style="width:10%">종족</th>
    <th style="width:5%">시기</th>
    <th style="width:8%">O</th>
    <th style="width:8%">D</th>
    <th style="width:4%">K</th></tr>
<?php
}

function printSearchLine ()
{
	global $users, $enemy, $rtags, $ctags, $etags, $racedb, $eradb, $config;
	$color = "normal";
	if ($enemy['num'] == $users['num'])
		$color = "self";
	elseif (($enemy['land'] == 0) || ($enemy['land'] < 0))
		$color = "dead";
	elseif ($enemy['disabled'] >= 2)
		$color = "disabled";
	elseif (($enemy['turnsused'] <= $config['protection']) || ($enemy['vacation'] > $config['vacationdelay']))
		$color = "protected";
?>
<tr class="era<?php echo $color?>">
    <td class="aright"><?php if ($enemy['online']) echo "*";?><?php echo $enemy['rank']?></td>
    <td class="acenter"><?php echo $enemy['empire']?> (#<?php echo $enemy['num']?>)</td>
    <td class="aright"><?php echo commas($enemy['land'])?></td>
    <td class="aright">$<?php echo commas($enemy['networth'])?></td>
    <td class="acenter"><?php echo $ctags["$enemy[clan]"]?></td>	
    <td class="acenter"><?php echo $rtags["$enemy[race]"]?></td>
    <td class="acenter"><?php echo $etags["$enemy[era]"]?></td>
    <td class="acenter"><?php echo $enemy['offtotal']?> (<?php if ($enemy['offtotal']) echo round($enemy['offsucc']/$enemy['offtotal']*100); else echo 0;?>%)</td>
    <td class="acenter"><?php echo $enemy['deftotal']?> (<?php if ($enemy['deftotal']) echo round($enemy['defsucc']/$enemy['deftotal']*100); else echo 0;?>%)</td>
    <td class="acenter"><?php echo $enemy['kills']?></td></tr>
<?php
}

function printMainStats ($user, $race, $era)
{
	global $config;
?>
<table style="width:75%">
<tr class="e<?php echo $era['name']?>"><th colspan="3"><?php echo $user['empire']?> (#<?php echo $user['num']?>)</th></tr>
    <tr><td style="width:40%">
    <table class="empstatus" style="width:100%">
        <tr><th>턴</th><?php              ?><td><?php echo $user['turns']?> (최대 <?php echo $config['maxturns']?>)</td></tr>
        <tr><th>저축된 턴</th><?php       ?><td><?php echo $user['turnsstored']?> (최대 <?php echo $config['maxstoredturns']?>)</td></tr>
        <tr><th>순위</th><?php               ?><td>#<?php echo $user['rank']?></td></tr>
        <tr><th><?php echo $era['peasants']?></th><?php ?><td><?php echo commas($user['peasants'])?></td></tr>
        <tr><th>땅</th><?php         ?><td><?php echo commas($user['land'])?></td></tr>
        <tr><th>돈</th><?php              ?><td>$<?php echo commas($user['cash'])?></td></tr>
        <tr><th><?php echo $era['food']?></th><?php    ?><td><?php echo commas($user['food'])?></td></tr>
        <tr><th><?php echo $era['runes']?></th><?php   ?><td><?php echo commas($user['runes'])?></td></tr>
        <tr><th><?php echo $era['iron']?></th><?php   ?><td><?php echo commas($user['iron'])?></td></tr>
        <tr><th>총 재산</th><?php           ?><td>$<?php echo commas($user['networth'])?></td></tr>
    </table></td>
    <td style="width:20%"></td>
    <td style="width:40%">
    <table class="empstatus" style="width:100%">
        <tr><th>시기</th><?php               ?><td><?php echo $era['name']?></td></tr>
        <tr><th>종족</th><?php              ?><td><?php echo $race['name']?></td></tr>
        <tr><th>건강</th><?php            ?><td><?php echo $user['health']?>%</td></tr>
        <tr><th>세율</th><?php          ?><td><?php echo $user['tax']?>%</td></tr>
        <tr><th><?php echo $era['armtrp']?></th><?php ?><td><?php echo commas($user['armtrp'])?></td></tr>
        <tr><th><?php echo $era['lndtrp']?></th><?php ?><td><?php echo commas($user['lndtrp'])?></td></tr>
        <tr><th><?php echo $era['flytrp']?></th><?php ?><td><?php echo commas($user['flytrp'])?></td></tr>
        <tr><th><?php echo $era['seatrp']?></th><?php ?><td><?php echo commas($user['seatrp'])?></td></tr>
        <tr><th><?php echo $era['wizards']?></th><?php ?><td><?php echo commas($user['wizards'])?></td></tr>
    </table></td></tr>
</table>
<?php
}

function numNewMessages ()
{
	global $messagedb, $users;
	return sqleval("SELECT COUNT(*) FROM $messagedb WHERE dest=$users[num] AND time>$users[msgtime] AND deleted=0;");
}
function numTotalMessages ()
{
	global $messagedb, $users;
	return sqleval("SELECT COUNT(*) FROM $messagedb WHERE dest=$users[num] AND deleted=0;");
}

// The final 8 arguments are optional
function addNews ($event, $src, $dest, $data0 /*, $data1, $data2, $data3, $data4, $data5, $data6, $data7, $data8*/)
{
	global $newsdb, $time, $lockdb;
	if ($lockdb)
		return;
	$data_l = "data0";
	$data_n = "$data0";

	$numargs = func_num_args();
     
	for ($i = 4; $i < $numargs; $i++)
	{
		$n = func_get_arg($i);
		$data_l .= ",data".($i-3);
		$data_n .= ",".$n;
	}
	db_query("INSERT INTO $newsdb (time,num_s,num_d,event,$data_l) VALUES ($time,$src[num],$dest[num],$event,$data_n);");
}

function printNews (&$user)
{
	global $newsdb, $playerdb, $clandb, $uera, $time;

	$news = db_query("SELECT time,num_s,p1.empire AS name_s,c1.name AS clan_s,p1.era AS era_s,num_d,p2.empire AS name_d,c2.name AS clan_d,p2.era AS era_d,event,data0,data1,data2,data3,data4,data5,data6,data7,data8 FROM $newsdb LEFT JOIN $playerdb AS p1 ON (num_s=p1.num) LEFT JOIN $playerdb AS p2 ON (num_d=p2.num) LEFT JOIN $clandb AS c1 ON (clan_s=c1.num) LEFT JOIN $clandb AS c2 ON (clan_d=c2.num) WHERE num_d=$user[num] AND time>$user[newstime] ORDER BY time ASC;");
	if (!db_num_rows($news))
		return 0;
?>
<table class="inputtable" border>
<tr><th>시간</th>
    <th colspan="2">이벤트</th></tr>
<?php
	while ($new = db_fetch_array($news))
	{
?>
<tr style="vertical-align:top"><th><?php
		$hours = ($time-$new['time'])/3600;
		if ($hours > 24)
		{
			$days = floor($hours/24);
			print $days." days, ";
			$hours -= $days*24;
		}
		print round($hours,1)." 시간 전에 ";
?></th>
<?php
	
		$eera = loadEra($new['era_s']);
		switch ($new['event'])
		{
		case 100:
			switch ($new['data0'])
			{
			case 1:	$type = 'food';		break;
			case 2:	$type = 'armtrp';	break;
			case 3:	$type = 'lndtrp';	break;
			case 4:	$type = 'flytrp';	break;
			case 5:	$type = 'seatrp';	break;
			}
?>    <td colspan="2"><span class="cgood">당신은 <?php echo commas($new['data1'])?> <?php echo $uera[$type]?> 을 돈 $<?php echo commas($new['data3'])?> 에 시장에 팔았습니다.</span></td></tr>
<?php 			break;
		case 101:
?>    <td colspan="2"><span class="cgood">복권 숫자를 봅니다. 어라~ 당신것과 일치합니다!! 당신의 복권이 당첨되었습니다!! 돈 $<?php echo commas($new['data0'])?> 를 얻습니다!</span></td></tr>
<?php 			break;
		case 102:
?>    <td><span class="cgood"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?>) 이 당신에게 <?php echo commas($new['data0'])?> <?php echo $uera['seatrp']?> 를 보냈습니다. 다음의 물건이 있습니다: </span></td>
    <td><?php
			if ($new['data1'])	print commas($new['data1'])." $uera[armtrp]<br>\n";
			if ($new['data2'])	print commas($new['data2'])." $uera[lndtrp]<br>\n";
			if ($new['data3'])	print commas($new['data3'])." $uera[flytrp]<br>\n";
			if ($new['data4'])	print "$".commas($new['data4'])."<br>\n";
			if ($new['data5'])	print commas($new['data5'])." $uera[runes]<br>\n";
			if ($new['data6'])	print commas($new['data6'])." $uera[food]<br>\n";
?>    </td></tr>
<?php 			break;
		case 110:
?>    <td colspan="2"><span class="cgood">당신은 <?php echo $new['clan_d']?> 를 세웁니다.</span></td></tr>
<?php 			break;
		case 111:
?>    <td colspan="2"><span class="cwarn">당신은 <?php echo $new['clan_d']?> 를 해체합니다.</span></td></tr>
<?php 			break;
		case 112:
?>    <td colspan="2"><span class="cgood"><?php
			if ($new['num_s'] == $new['num_d'])
				print "당신";
			else	print "$new[name_s] (#$new[num_s])";
?> 이 동맹 <?php echo $new['clan_d']?> 에 합류합니다.</span></td></tr>
<?php 			break;
		case 113:
?>    <td colspan="2"><span class="cwarn"><?php
			if ($new['num_s'] == $new['num_d'])
				print "당신";
			else	print "$new[name_s] (#$new[num_s])";
?> 이 동맹 <?php echo $new['clan_d']?> 을 떠납니다.</span></td></tr>
<?php 			break;
		case 114:
?>    <td colspan="2"><span class="cwarn"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?> 이 당신을 <?php echo $new['clan_d']?> 에서 쫓아냈습니다.</span></td></tr>
<?php 			break;
		case 115:
?>    <td colspan="2"><span class="cgood"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?> 이 당신을 <?php echo $new['clan_d']?> 의 지도자로 선정했습니다.</span></td></tr>
<?php 			break;
		case 116:
?>    <td colspan="2"><span class="cgood">당신은 <?php echo $new['clan_d']?> 의 지도자가 되었습니다.</span></td></tr>
<?php 			break;
		case 117:
?>    <td colspan="2"><span class="cwarn"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?> 은 해체된 <?php echo $new['clan_d']?> 으로 부터 당신을 쫓아냈습니다.</span></td></tr>
<?php 			break;
		case 118:
?>    <td colspan="2"><span class="cgood"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?> 는 <?php echo $new['clan_d']?> 의 외교관으로 임명했습니다.</span></td></tr>
<?php 			break;
		case 119:
?>    <td colspan="2"><span class="cwarn"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?> 는 <?php echo $new['clan_d']?> 의 외교관으로 당신의 자격을 박탈시켰습니다.</span></td></tr>
<?php 			break;
		case 201:
?>    <td colspan="2"><span class=<?php
			if ($new['data0'] < 0)
				print '"cwarn">'."$new[name_s] (#$new[num_s]) 이 당신의 제국 정보를 보려고하는 것을 감지합니다!";
			else	print '"cbad">'."다른 제국이 당신의 제국 정보를 봤습니다!";
?></span></td></tr>
<?php 			break;
		case 202:
?>    <td colspan="2"><span class=<?php
			if ($new['data0'] < 0)
				print '"cwarn">'."$new[name_s] (#$new[num_s]) 이 당신의 군사를 제거하려고 했습니다!";
			else
			{
				print '"cbad">';
				if ($new['data0'] == 0)
					print "1";
				else	print "3";
				print "% 의 군사가 $new[name_s] (#$new[num_s]) 에 의해 제거되었습니다!";
			}
?></span></td></tr>
<?php 			break;
		case 204:
?>    <td colspan="2"><span class=<?php
			if ($new['data0'] < 0)
				print '"cwarn">'."$new[name_s] (#$new[num_s]) 이 당신의 제국에 폭풍을 읽으키려는 것은 감지합니다!";
			else
			{
				print '"cbad">'."폭풍에 의해 ".commas($new['data1'])." $uera[food] 이 소모되었으며 $".commas($new['data2']) . " 의 손상을 받습니다";
				if ($new['data0'] == 0)
					print ", 그러나 폭풍의 피해는 방어막에 의해 대부분 막아졌습니다.";
				else	print "!";
			}
?></span></td></tr>
<?php 			break;
		case 205:
?>    <td colspan="2"><span class=<?php
			if ($new['data0'] < 0)
				print '"cwarn">'."$new[name_s] (#$new[num_s]) 이 당신의 $uera[runes] 를 파괴하려는 것을 감지합니다!";
			else
			{
				print '"cbad">'."번개에 의해 ".commas($new['data1'])." 개의 $uera[runes] 이 손상됩니다.";
				if ($new['data0'] == 0)
					print ", 그러나 방어억에 의해 피해가 최소화됩니다.";
				else	print "!";
			}
?></span></td></tr>
<?php 			break;
		case 206:
?>    <td colspan="2"><span class=<?php
			if ($new['data0'] < 0)
				print '"cwarn">'."$new[name_s] (#$new[num_s]) 이 당신의 제국에 괴물을 보내려는 것을 감지합니다!";
			else
			{
				print '"cbad">'."괴물들이 당신의 제국의 일부를 파괴합니다";
				if ($new['data0'] == 0)
					print ", 그러나 방어막에 의해 대부분의 괴물들이 들어오지 못했습니다.";
				else	print "!";
			}
?></span></td></tr>
<?php 			break;
		case 211:
			if ($new['data0'] < 0)
			{
?>    <td colspan="2"><span class="cwarn">당신의 <?php echo $uera['wizards']?> 와 <?php echo $new['name_s']?> (#<?php echo $new['num_s']?>) 이 싸우려는 것을 감지합니다!</span></td></tr>
<?php 			}
			elseif ($new['data0'] == 0)
			{
?>    <td><span class="cwarn">당신은 <?php echo $new['name_s']?> (#<?php echo $new['num_s']?>) 이 당신의 마법사와 싸우면서 지는 것을 발견합니다!</span></td>
    <td>당신은 <?php echo $new['data2']?> <?php echo $eera['wizards']?> 을 죽였으며, <?php echo $new['data1']?> <?php echo $uera['wizards']?> 를 잃습니다.</td></tr>
<?php 			}
			else
			{
?>    <td><span class="cbad">당신의 <?php echo $uera['wizards']?> 는 <?php echo $new['name_s']?> (#<?php echo $new['num_s']?>) 에 의해 패배당하고 <?php echo $new['data0']?> 땅을 잃습니다!</span></td>
    <td>당신은 <?php echo $new['data1']?> <?php echo $uera['wizards']?> 을 잃지만, 공격자의 <?php echo $eera['wizards']?> 를 <?php echo $new['data2']?> 만큼 죽입니다.</td></tr>
<?php 			}
			break;
		case 212:
?>    <td colspan="2"><span class=<?php
			if ($new['data0'] < 0)
				print '"cwarn">'."$new[name_s] (#$new[num_s]) 이 당신의 돈을 훔치려는 것을 발견합니다!";
			else
			{
				print '"cbad">'."누군가 당신으로 부터 $".commas($new['data1'])." 를 훔칩니다";
				if ($new['data0'] == 0)
					print ", 그러나 방어막에 의해 더 훔치는 것을 방지합니다.";
				else	print "!";
			}
?></span></td></tr>
<?php 			break;
		case 300:
?>    <td colspan="2"><span class="cwarn">당신의 군사는 <?php echo sqleval("SELECT empire FROM $playerdb WHERE num=$new[data0];")?> (#<?php echo $new['data0']?>) 를  <?php echo $new['name_s']?> (#<?php echo $new['num_s']?>) 의 공격으로 부터 도우러 갑니다!</span></td></tr>
<?php 			break;
		case 301:
?>    <td colspan="2"><span class="cbad"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?>) 이 최후의 공격을 가하면서 당신의 제국은 멸망합니다...</span></td></tr>
<?php 			break;
		case 302:
		case 303:
?>    <td><span class="cbad"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?>) 이 당신을 공격합니다!</span></td>
    <td><?php
			if ($new['data0'])
				print "당신은 적에게 $new[data0] 땅을 뺏기며 다음의 손상을 받습니다:<br>";
			else	print "방어선을 유지하며 적을 물리쳤지만, 다음의 손상이 있었습니다:<br>";

			if ($new['data1']) print commas($new['data1'])." $uera[armtrp]<br>";
			if ($new['data2']) print commas($new['data2'])." $uera[lndtrp]<br>";
			if ($new['data3']) print commas($new['data3'])." $uera[flytrp]<br>";
			if ($new['data4']) print commas($new['data4'])." $uera[seatrp]<br>";
			print "당신은 다음을 파괴했습니다:<br>";
			if ($new['data5']) print commas($new['data5'])." $eera[armtrp]<br>";
			if ($new['data6']) print commas($new['data6'])." $eera[lndtrp]<br>";
			if ($new['data7']) print commas($new['data7'])." $eera[flytrp]<br>";
			if ($new['data8']) print commas($new['data8'])." $eera[seatrp]<br>";
?></td></tr>
<?php 			break;
		case 304:
		case 305:
		case 306:
		case 307:
			switch ($new['event'])
			{
			case 304:	$unit = 'armtrp';	break;
			case 305:	$unit = 'lndtrp';	break;
			case 306:	$unit = 'flytrp';	break;
			case 307:	$unit = 'seatrp';	break;
			}

?>    <td><span class="cbad"><?php echo $new['name_s']?> (#<?php echo $new['num_s']?>) 이 당신을 공격했습니다!</span></td>
    <td><?php
			if ($new['data0'])
				print "당신의 적은 $new[data0] 땅을 뺏고 다음을 파괴합니다:<br>";
			else	print "방어선을 유지하며 적을 물리쳤지만, 다음의 손상을 입습니다:<br>";

			if ($new['data1']) print commas($new['data1'])." $uera[$unit]<br>";
			print "당신은 다음을 파괴합니다:<br>";
			if ($new['data2']) print commas($new['data2'])." $eera[$unit]<br>";
?></td></tr>
<?php 			break;
		}
	}
?>
</table>
<?php
	return 1;
}
?>
