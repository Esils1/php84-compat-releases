<?php
include("header.php");

if ($lockdb)
	TheEnd("복권은 현재 사용 불가!");

$tickcost = round($users['networth'] * 10);

$jackpot = sqleval("SELECT cash FROM $lotterydb WHERE num=0 AND ticket=$tick_curjp;");
$lastjackpot = sqleval("SELECT cash FROM $lotterydb WHERE num=0 AND ticket=$tick_lastjp;");
$lastnum = sqleval("SELECT cash FROM $lotterydb WHERE num=0 AND ticket=$tick_lastnum;");
$lastwin = sqleval("SELECT cash FROM $lotterydb WHERE num=0 AND ticket=$tick_lastwin;");
$jackpotgrow = sqleval("SELECT cash FROM $lotterydb WHERE num=0 AND ticket=$tick_jpgrow;");

$tickets = db_query("SELECT * FROM $lotterydb WHERE num=$users[num];");
if ($do_ticket)
{
	if (db_num_rows($tickets) >= $maxtickets)
		TheEnd("더 많은 복권을 살 수 없습니다!");
        if ($users['cash'] < $tickcost)
		TheEnd("복권을 살 충분한 돈이 없습니다!");
	else
	{
		$tmp = sqleval("SELECT num FROM $playerdb ORDER BY num DESC LIMIT 1;");
                $ticknum = mt_rand(1,3 * $tmp);
                $jackpot += $tickcost;
		db_query("INSERT INTO $lotterydb (num,ticket,cash) VALUES ($users[num],$ticknum,$tickcost);");
		db_query("UPDATE $lotterydb SET cash=$jackpot WHERE num=0 AND ticket=$tick_curjp;");
		$users['cash'] -= $tickcost;
		saveUserDataNet($users,"networth cash");
	}
	$tickets = db_query("SELECT * FROM $lotterydb WHERE num=$users[num];");
}
?>
복권을 사시면 그 돈이 누가 복권 당첨 번호를 맞추어 당첨되어 이길 때 까지 모아집니다. 복권 가격은 $<?php echo commas($tickcost)?> 입니다.<br>
복권 번호 당첨은 하루에 한번씩 일어날 수 있습니다.<br><br>
현재 당첨액수: $<?php echo commas($jackpot)?><br><br>
<?php echo sqleval("SELECT COUNT(*) FROM $lotterydb WHERE num!=0;")?> 복권이 다음 번호 당첨까지 구입되었습니다.<br>
마지막 복권 당첨 번호는 #<?php echo $lastnum?> 이였습니다,<br>
<?php
if ($lastwin)
{
	$enemy = loadUser($lastwin);
	print "$enemy[empire] (#$enemy[num]) 이 당첨되어 총 $".commas($lastjackpot)."을 얻었습니다!<br>\n";
}
else	print "아무도 당첨되지 않아 당첨액이 $".commas($jackpotgrow)." 만큼 증가되었습니다!<br>\n";
if (db_num_rows($tickets))
{
	print "당신은 다음의 복권 번호를 가지고 있습니다:";
	while ($ticket = db_fetch_array($tickets))
		print " #$ticket[ticket]";
}
else	print "당신은 현재 복권을 가지고 있지 않습니다";
print ".<br>\n";

if ($users['cash'] < $tickcost)
	print "복권 살 돈이 부족합니다.<br>\n";
elseif (db_num_rows($tickets) < $maxtickets)
{
?>
<form method="post" action="<?php echo $config['main']?>?action=lottery">
<div>
<input type="submit" name="do_ticket" value="복권 구매하기!">
</div>
</form>
<?php
}
TheEnd("");
?>
