<?php
if($digibbs == 1)  {
global $db, $data_id;

//*********************************************
//LOGIN CHECK ROUTINE: 1 - mysql secure check *
//                                            *
include("../member/lib/loginlib.php");
include("../member/lib/loginsetup" . $form_idnum . ".php");

include("../member/lib/FastTemplate.php");

//!!!T START
if(!preg_match('/korean/', $GLOBALS['lang'])) {
  $GLOBALS['t_loginfirst'] = "Please login first!";
  $GLOBALS['t_loggedout'] = "You are logged out.";
  }
else  {
  $GLOBALS['t_loginfirst'] = "먼저 로그인하시기 바랍니다!";
  $GLOBALS['t_loggedout'] = "로그 아웃되었습니다.";
  }
//!!!T END
  
  
//COOKIES ARE ID, TEMPPASS, TEMPPASS2
$dbclass = new dbclass($db_host, $db_user, $db_pass, $db_name);
$db = new loginclass($dbclass);

$data_id = $db->dataid($ID);

if(!$TEMPPASS)  {
  $tpl_error = $GLOBALS['t_loginfirst'];
  $tpl = new FastTemplate("../member/$GLOBALS[lang2]_templates");
  $tpl->define(array('loginerr' => "bnlogincheckfail.html"));
  $tpl->assign(array('TITLE' => $tpl_title,
                     'TPL_ERROR' => $tpl_error,
                     'FORM_IDNUM' => $form_idnum));
  $tpl->parse('MAIN', 'loginerr');
  $tpl->FastPrint();
  exit;
}
elseif($TEMPPASS != $data_id['temppass'])  {
  $tpl_error = $GLOBALS['t_loggedout'];
  $tpl = new FastTemplate("../member/$GLOBALS[lang2]_templates");
  $tpl->define(array('loginerr' => "bnlogincheckfail.html"));
  $tpl->assign(array('TITLE' => $tpl_title,
                     'TPL_ERROR' => $tpl_error,
                     'FORM_IDNUM' => $form_idnum));
  $tpl->parse('MAIN', 'loginerr');
  $tpl->FastPrint();
  exit;
  }
}
//                                                 *
//LOGIN CHECK ROUTINE END                          *
//**************************************************
?>