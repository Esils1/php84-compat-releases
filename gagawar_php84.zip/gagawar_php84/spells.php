<?php
function SpellSpy ()
{
	global $users, $uratio, $enemy, $erace, $eera, $eratio, $wizloss;
	if ($uratio > $eratio)
	{
		SpellSucceed("당신은 다음의 정보를 알아냈습니다:");
		printMainStats($enemy,$erace,$eera);
		addNews(201,$users,$enemy,1);
	}
	else
	{
		SpellFail();
		addNews(201,$users,$enemy,-$wizloss);
	}
}

function SpellBlast ()
{
	global $users, $uratio, $enemy, $eratio, $shmod, $time, $wizloss;
	if ($uratio > ($eratio * 1.15))
	{
		SpellSucceed("당신은 상대편의 군사의 일부분을 제거했습니다!");
		$dam = 1 - ($shmod * .03);
		$enemy['armtrp'] = round($enemy['armtrp'] * $dam);
		$enemy['lndtrp'] = round($enemy['lndtrp'] * $dam);
		$enemy['flytrp'] = round($enemy['flytrp'] * $dam);
		$enemy['seatrp'] = round($enemy['seatrp'] * $dam);
		$enemy['wizards'] = round($enemy['wizards'] * $dam);
		if ($enemy['shield'] > $time)
		{
			SpellShielded();
			addNews(202,$users,$enemy,0);
		}
		else	addNews(202,$users,$enemy,1);
		$users['offsucc']++;
	}
	else
	{
		SpellFail();
		addNews(202,$users,$enemy,-$wizloss);
		$enemy['defsucc']++;
	}
    saveUserDataNet($enemy,"networth armtrp lndtrp flytrp seatrp wizards");
}

function SpellShield ()
{
	global $users, $lratio, $time;
	if ($lratio >= 15)
	{
		if ($users['shield'] > $time)
		{
			if ($users['shield'] < $time + 3600*3)
			{
				SpellSucceed("당신의 방어막은 12 시간으로 연장되었습니다!");
				$users['shield'] = $time + 3600*12;
			}
			else
			{
				SpellSucceed("당신은 방어막을 3 시간 더 연장했습니다!");
				$users['shield'] += 3600*3;
			}
		}
		else
		{
			SpellSucceed("당신의 제국에 앞으로 12시간 동안 방어막이 형성됩니다!");
			$users['shield'] = $time + 3600*12;
		}
		saveUserData($users,"shield");
	}
	else	SpellFail();
}

function SpellStorm ()
{
	global $users, $uratio, $enemy, $eera, $eratio, $shmod, $time, $wizloss;
	if ($uratio > ($eratio * 1.21))
	{
		$foodloss = round($enemy['food'] * .0912 * $shmod);
		$cashloss = round($enemy['cash'] * .1265 * $shmod);
		$enemy['food'] -= $foodloss;
		$enemy['cash'] -= $cashloss;
		SpellSucceed("당신의 마법은 ".commas($foodloss)." $eera[food] 을 파괴했으며 돈 $".commas($cashloss)."을 파괴했습니다!");
		if ($enemy['shield'] > $time)
		{
			SpellShielded();
			addNews(204,$users,$enemy,0,$cashloss,$foodloss);
		}
		else	addNews(204,$users,$enemy,1,$cashloss,$foodloss);
		$users['offsucc']++;
	}
	else
	{
		SpellFail();
		addNews(204,$users,$enemy,-$wizloss);
		$enemy['defsucc']++;
	}
    saveUserDataNet($enemy,"networth food cash");
}

function SpellRunes ()
{
	global $users, $uratio, $enemy, $eera, $eratio, $shmod, $time, $wizloss;
	if ($uratio > ($eratio * 1.3))
	{
		$runeloss = round($enemy['runes'] * .03 * $shmod);
		$enemy['runes'] -= $runeloss;
		SpellSucceed("당신은 적의 $eera[runes] 을 ".commas($runeloss)." 만큼 파괴했습니다!");
		if ($enemy['shield'] > $time)
		{
			SpellShielded();
			addNews(205,$users,$enemy,0,$runeloss);
		}
		else	addNews(205,$users,$enemy,1,$runeloss);
		$users['offsucc']++;
	}
	else
	{
		SpellFail();
		addNews(205,$users,$enemy,-$wizloss);
		$enemy['defsucc']++;
	}
	saveUserData($enemy,"runes");
}

function SpellStruct ()
{
	global $users, $uratio, $enemy, $eratio, $shmod, $time, $wizloss;
	if ($uratio > ($eratio * 1.7))
	{
		SpellSucceed("당신의 마법은 적의 제국의 일부를 파괴했습니다!");
		if ($enemy['shops'] >= 15 * $shmod) {	$destroyed += ceil($enemy['shops'] * $shmod);	$enemy['shops'] -= ceil($enemy['shops'] * $shmod); }
		if ($enemy['homes'] >= 15 * $shmod) {	$destroyed += ceil($enemy['homes'] * $shmod);	$enemy['homes'] -= ceil($enemy['homes'] * $shmod); }
		if ($enemy['industry'] >= 15 * $shmod) {	$destroyed += ceil($enemy['industry'] * $shmod);	$enemy['industry'] -= ceil($enemy['industry']* $shmod); }
		if ($enemy['barracks'] >= 15 * $shmod) {	$destroyed += ceil($enemy['barracks'] * $shmod);	$enemy['barracks'] -= ceil($enemy['barracks'] * $shmod); }
		if ($enemy['farms'] >= 15 * $shmod) {	$destroyed += ceil($enemy['farms'] * $shmod);	$enemy['farms'] -= ceil($enemy['farms'] * $shmod); }
		if ($enemy['labs'] >= 15 * $shmod) {	$destroyed += ceil($enemy['labs'] * $shmod);	$enemy['labs'] -= ceil($enemy['labs'] * $shmod); }
		if ($enemy['towers'] >= 10 * $shmod) {	$destroyed += ceil($enemy['towers'] * $shmod);	$enemy['towers'] -= ceil($enemy['towers'] * $shmod); }
		if ($enemy['banks'] >= 15 * $shmod) {	$destroyed += ceil($enemy['banks'] * $shmod);	$enemy['banks'] -= ceil($enemy['mines'] * $shmod); }
		if ($enemy['mines'] >= 15 * $shmod) {	$destroyed += ceil($enemy['mines'] * $shmod);	$enemy['mines'] -= ceil($enemy['banks'] * $shmod); }
		$enemy['freeland'] += $destroyed;
		if ($enemy['shield'] > $time)
		{
			SpellShielded();
			addNews(206,$users,$enemy,0);
		}
		else	addNews(206,$users,$enemy,1);
		$users['offsucc']++;
	}
	else
	{
		SpellFail();
		addNews(206,$users,$enemy,-$wizloss);
		$enemy['defsucc']++;
	}
    saveUserDataNet($enemy,"networth shops homes industry barracks farms labs towers freeland mines banks");
}

function cashandfood()
 {
	global $users, $urace, $lratio;
	return $users['wizards'] * $users['health']/100 * 65 * (1 + $users['labs'] / $users['land']) * $urace['magic'] / (calcSizeBonus($users['networth']) * calcSizeBonus($users['networth']));
}

function SpellFood ()
{
	global $users, $urace, $lratio, $config, $uera;
	if ($lratio >= 30)
 	{
		$food = cashandfood()/$config['food'];
		SpellSucceed(commas($food)." $uera[food] 이 생성되었습니다!");
		$users['food'] += $food;
	}
	else	SpellFail();
}

function SpellGold ()
{
	global $users, $urace, $lratio;
	if ($lratio >= 30)
	{
		$money = cashandfood();
		SpellSucceed("$".commas($money)." 돈이 생겼습니다!");
		$users['cash'] += $money;
	}
	else	SpellFail();
}

function SpellGate ()
{
	global $users, $lratio, $time;
	if ($lratio >= 75)
	{
		if ($users['gate'] > $time)
			if ($users['gate'] < $time + 3600*3)
			{
				SpellSucceed("당신의 시간의 문은 12 시간으로 연장되었습니다!");
				$users['gate'] = $time + 3600*12;
			}
			else
			{
				SpellSucceed("당신은 시간의 문을 3 시간 더 연장했습니다!");
				$users['gate'] += 3600*3;
			}
		else
		{
			SpellSucceed("당신은 시간의 문을 열었었습니다. 앞으로 12시간 동안 아무나 공격할 수 있습니다!");
			$users['gate'] = $time + 3600*12;
		}
		saveUserData($users,"gate");
	}
	else	SpellFail();
}

function SpellUngate ()
{
	global $users, $lratio, $time;
	if ($lratio >= 80)
 	{
		SpellSucceed("당신은 열려있는 시간의 문을 닫습니다!");
		$users['gate'] = $time;
        saveUserData($users,"gate");
 	}
	else	SpellFail();
}

function wizDestroyBuildings ($type, $pcloss)
{
	global $buildloss, $enemy, $users;
	$pcloss /= 100;
	$loss = 0;
	if ($enemy[$type] > 0)
		$loss = mt_rand(1,ceil($enemy[$type] * $pcloss + 2));
	if ($loss > $enemy[$type])
		$loss = $enemy[$type];

	$enemy[$type] -= $loss;
	$buildloss += $loss;
}

function SpellSteal ()
{
	global $users, $uratio, $enemy, $eratio, $shmod, $time, $wizloss;
	if ($uratio > ($eratio * 1.75))
	{
		$money = round($enemy['cash']/100000 * mt_rand(ceil(10000 * $shmod), ceil(15000 * $shmod)));
		$users['cash'] += $money;
		$enemy['cash'] -= $money;
		SpellSucceed("당신은 상대편으로 부터 $".commas($money)." 돈을 훔칩니다!");
		if ($enemy['shield'] > $time)
		{
			SpellShielded();
			addNews(212,$users,$enemy,0,$money);
		}
		else	addNews(212,$users,$enemy,1,$money);
		$users['offsucc']++;
	}
	else
	{
		SpellFail();
		addNews(212,$users,$enemy,-$wizloss);
		$enemy['defsucc']++;
	}
    saveUserDataNet($enemy,"networth cash");
}

function SpellAdvance ()
{
	global $users, $uera, $lratio, $spname;
	if (!$spname[12])
		TheEnd("당신 더 이상 발전할 수 없습니다!");
	if ($lratio >= 90)
	{
		SpellSucceed("당신은 다음 시기로 발전했습니다!");
		$users['era']++;
		saveUserData($users,"era");
		$uera = loadEra($users['era']);	// update era-specific stuff immediately
		setspnames();
	}
	else	SpellFail();
}

function SpellFight ()
{
	global $users, $uera, $uratio, $enemy, $eera, $eratio, $lratio, $buildloss, $wizloss;
	if ($lratio >= 50)
	{
		SpellSucceed("당신의 $uera[wizards] 는 적 $enemy[empire]'s 과 싸웁니다...");
		if ($uratio > $eratio * 2.2)
		{
			print "...그리고 당신은 성공적으로 적의 $eera[wizards] 를 물리칩니다!<br>\n";
			$uloss = mt_rand(0,round($users['wizards'] * 0.09 + 1));
			$eloss = mt_rand(0,round($enemy['wizards'] * 0.06 + 1));
			if ($uloss > $users['wizards'])	$uloss = $users['wizards'];
			if ($eloss > $enemy['wizards'])	$eloss = $enemy['wizards'];
			$buildloss = 0;
			wizDestroyBuildings('homes',7);
			wizDestroyBuildings('shops',7);
			wizDestroyBuildings('industry',7);
			wizDestroyBuildings('barracks',7);
			wizDestroyBuildings('labs',7);
			wizDestroyBuildings('farms',7);
			wizDestroyBuildings('towers',7);
			wizDestroyBuildings('banks',7);
			wizDestroyBuildings('mines',7);
			wizDestroyBuildings('freeland',10);
			$users['land'] += $buildloss;
			$users['freeland'] += $buildloss;
			$enemy['land'] -= $buildloss;
			print "당신의 $uera[wizards] 은 적 $enemy[empire] 의 방어를 뚫고 땅 $buildloss 를 이겨냅니다!.<br>\n";
			print "당신은 또한 적의 $eera[wizards] $eloss 개를 죽이고, 당신은 $uera[wizards] 를 $uloss 개 잃습니다!<br>\n";
			if (($enemy['land'] == 0) || ($enemy['land'] < 0))
			{
				print '<span class="cgood">'."<b>$enemy[empire] (#$enemy[num])</b> 의 제국은 파괴되었습니다!</span><br>\n";
				$users['kills']++;
				addNews(301,$users,$enemy,0);
			}
			addNews(211,$users,$enemy,$buildloss,$eloss,$uloss);
			$users['offsucc']++;
		}
		else
		{
			print "...그리고 당신은 적의 $eera[wizards] 에 대한 공격을 실패합니다!<br>\n";
			$uloss = mt_rand(0,round($users['wizards'] * 0.10 + 1));
			$eloss = mt_rand(0,round($enemy['wizards'] * 0.05 + 1));
			if ($uloss > $users['wizards'])	$uloss = $users['wizards'];
			if ($eloss > $enemy['wizards'])	$eloss = $enemy['wizards'];
			print "당신은 $uloss 개의 $uera[wizards] 를 잃었지만, 적의 $eera[wizards] 를 $eloss 개 죽입니다!<br>\n";
			addNews(211,$users,$enemy,0,$eloss,$uloss);
			$enemy['defsucc']++;
		}
		$users['wizards'] -= $uloss;
		$enemy['wizards'] -= $eloss;
	}
	else
	{
		SpellFail();
		addNews(211,$users,$enemy,-$wizloss);
	}
	saveUserDataNet($enemy,"networth homes shops industry barracks labs farms towers freeland land wizards mines banks");
// Temp fix...
	saveUserDataNet($users,"networth wizards freeland land");	// wizards get saved in takeTurns()
}


function SpellED ()
{
	global $users, $urace, $lratio, $config;
	if ($lratio >= 70)
	{
		$randland = mt_rand(5,40) / 1000;
		$land = $users['land'] * $randland * $urace['magic'];
		if ($land > $config['edcap']) { $land = $config['edcap']; }
		$health = $users['health'] - mt_rand(5,12);
		$health3 = $users['health'] - $health;
		$uloss = mt_rand(0,round($users['wizards'] * 0.10 + 1));
		$users['land'] += $land;
		$users['freeland'] += $land;
		$users['health'] = $health;
		$users['wizards'] += $uloss;
		$land = commas($land);
		SpellSucceed("$land 땅이 당신의 마법사에 의해 만들어집니다, 하지만 마법의 부작용에 당신 군인은 다음의 손상을 받습니다: $health3 건강 그리고 $uloss 개의 마법사를 잃습니다!");
		saveUserData($users,"health land freeland");
	}
	else	SpellFail();
}

function SpellHeal ()
{
	global $users, $urace, $lratio;
	if ($lratio >= 15)
	{
		if ($users['health'] > 100) { 
			TheEnd("건강이 완전히 회복됩니다."); 
		}
		$rand_health = mt_rand(7,15);
		$users['health'] = $users['health'] + $rand_health; 
		if ($users['health'] > 100)
			$users['health'] = 100;
		SpellSucceed("당신의 마법사들은 마법을 이용해 제국에 $rand_health 건강을 회복시켜줍니다!");
		saveUserData($users,"health");
	}
	else	SpellFail();
}

function CastSpell ($num)
{
	switch ($num)
	{
	case 1:	SpellSpy();		break;
	case 2:	SpellBlast();	break;
	case 3:	SpellShield();	break;
	case 4:	SpellStorm();	break;
	case 5:	SpellRunes();	break;
	case 6:	SpellGold();	break;
	case 7:	SpellStruct();	break;
	case 8:	SpellSteal();	break;
	case 9:	SpellFight();	break;
	case 10:	SpellGate();	break;
	case 11:	SpellUngate();	break;
	case 12:	SpellAdvance();break;
	case 13:	SpellED();		break;
	case 14:	SpellHeal();	break;
	case 15:	SpellFood();	break;
	}
}
?>
