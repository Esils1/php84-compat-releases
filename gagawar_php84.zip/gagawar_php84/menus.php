<?php
include("const.php");
?>
<h2 class="acenter">가가전쟁</h2>
<table class="menus">
<tr><th><hr><a href="<?php echo $config['main']?>?action=main">메뉴</a><hr></th></tr>
<tr><th>정보</th></tr>
<tr><td><b><a href="<?php echo $config['main']?>?action=guide">게임 설명서</a></b></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=status">제국 정보</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=scores">점수</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=search">제국 검색</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=news">뉴스 검색</a></td></tr>
<tr><td><a href="<?php echo $config['forums']?>" target="_blank">게시판</a></td></tr>
<tr><th>턴 사용하기</th></tr>
<tr><td><a href="<?php echo $config['main']?>?action=mine">광물 캐기</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=farm">농사</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=cash">돈 모으기</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=land">탐사</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=build">건설하기</a></td></tr>
<tr><th>재무</th></tr>
<tr><td><a href="<?php echo $config['main']?>?action=pvtmarketbuy">암거래 시장</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=pubmarketbuy">열린 시장</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=bank">세계 은행</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=lottery">복권</a></td></tr>
<tr><th>외교</th></tr>
<tr><td><a href="<?php echo $config['main']?>?action=aid">지원</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=military">전쟁</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=magic">마법</a></td></tr>
<?php
	if ($config['clans'] == 1)
	print "<tr><td><a href=$config[main]?action=clan>동맹</a></td></tr>";
?>
<tr><th>관리</th></tr>
<tr><td><a href="<?php echo $config['main']?>?action=messages">메세지</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=manage">제국 관리하기</a></td></tr>
<tr><td><a href="<?php echo $config['main']?>?action=delete">계정 삭제하기</a></td></tr>
</table>
