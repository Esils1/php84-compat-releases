<?php
//!!!S
if($digibbs != 0)  {
	$login_username = $data_id['id'];
	$login_password = substr(md5($data_id['id'] . $digibbskey), 0, 8);
}
//!!!E

include("funcs.php");

function EndNow ($reason)
{
	HTMLbegincompact("Login");
	print "$reason<br>\n";
	HTMLendcompact();
	exit;
}

if ($do_login)
{
	if ($login_username == "")
		EndNow("아이디를 입력하시길 바랍니다!");
	$users = db_fetch_array(db_query("SELECT * FROM $playerdb WHERE username='$login_username';"));
	if (!$users['num'])
		EndNow("먼저 제국을 새롭게 생성하시길 바랍니다!");
	if ($users['vacation'] > 0)
	{
		if ($users['vacation'] < $config['minvacation']+$config['vacationdelay'])
			EndNow("이 계정은 여행 모드로 되어 있습니다. ".($config['minvacation']+$config['vacationdelay'] - $users['vacation'])." 시간 동안 놀 수 없습니다.");
		else
		{
			$users['vacation'] = 0;
			$users['idle'] = $time;			// so they don't get deleted from being idle
			saveUserData($users,"vacation idle");
		}
	}
	$password = md5($login_password);
	$users['ip'] = $REMOTE_ADDR;
	saveUserData($users,"ip");
	if ($users['password'] == $password)
	{
		setcookie("usernamecookie","$users[username]",time()+200000);
		setcookie("passwordcookie","$users[password]",time()+200000);
		if ($musicbg == "ON")
			header("Location: ".$config['sitedir'].$config['main']."?action=game2");
		else
			header("Location: ".$config['sitedir'].$config['main']."?action=main");
	}
	else	EndNow("암호가 틀렸습니다!");
}
else
{
	setcookie("usernamecookie","");
	setcookie("passwordcookie","");
	HTMLbegincompact("Login");
?>
<h2><?php echo $config['servname']?></h2>
가가 전쟁<br>원작: Promisance Enhanced v<?php echo $version?><br>
<?php
$num = sqleval("SELECT COUNT(*) FROM $playerdb;");
echo " $num ";
?>
제국이 존재합니다<br>
<?php
if($digibbs != 0)  {?>
<form method="post" action="<?php echo $config['main']?>?action=login">
<div>
아이디: <?php echo $login_username?><br>
<input type="hidden" name="musicbg" value="OFF">
  <input type="submit" name="do_login" value="로그인"
  style="font-size : xx-small;
	color : #FFFFFF;
	font-family : Verdana;
	border-width : 1;
	border-style : solid;
	border-color : #858CA5;
	background-color : #677085;">
</div>
</form><?php }
else{
?>
<form method="post" action="<?php echo $config['main']?>?action=login">
<div>
아이디: <input type="text" name="login_username" size="8"><br>
암호: <input type="password" name="login_password" size="8"><br>
<input type="hidden" name="musicbg" value="OFF">
  <input type="submit" name="do_login" value="로그인"
  style="font-size : xx-small;
	color : #FFFFFF;
	font-family : Verdana;
	border-width : 1;
	border-style : solid;
	border-color : #858CA5;
	background-color : #677085;">
</div>
</form>
<?php
}
?>
<a href="<?php echo $config['main']?>?action=signup"><b>- 제국 생성하기 -</b></a><br>
<a href="<?php echo $config['main']?>?action=top10"><b>- 탑 10 제국들 -</b></a><br>
<?php
	HTMLendcompact();
}
?>
