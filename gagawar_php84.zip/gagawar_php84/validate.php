<?php
include("header.php");
if ($do_validate)
{
	if ($num = sqleval("SELECT num FROM $playerdb WHERE valcode='$valcode' AND num=$users[num];"))
	{
		db_query("UPDATE $playerdb SET validated=1 WHERE num=$num;");
		db_query("UPDATE $playerdb SET disabled=0 WHERE num=$num AND disabled=1;");
	        TheEnd("사용자 인증되었습니다!");
	}
	else	TheEnd("인증 코드가 틀립니다!");
}
else	TheEnd("");
?>
