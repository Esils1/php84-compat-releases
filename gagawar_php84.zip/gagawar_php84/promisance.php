<?php
@ignore_user_abort(true);
@set_time_limit(30);
if (!headers_sent()) {
    header('Content-Type: text/html; charset=utf-8');
}

/* PHP 5.5 legacy compatibility: restore variables expected by old source when register_globals is Off. */
if (!isset($_GET)) $_GET = $_GET;
if (!isset($_POST)) $_POST = $_POST;
if (!isset($_COOKIE)) $_COOKIE = $_COOKIE;
if (!isset($_SERVER)) $_SERVER = $_SERVER;
if (!isset($REMOTE_ADDR)) $REMOTE_ADDR = isset($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "";
if (!isset($HTTP_REFERER)) $HTTP_REFERER = isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : "";
if (!isset($SERVER_NAME)) $SERVER_NAME = isset($_SERVER["SERVER_NAME"]) ? $_SERVER["SERVER_NAME"] : "";
foreach (array($_COOKIE, $_GET, $_POST) as $__src) {
    foreach ($__src as $__k => $__v) {
        if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $__k)) {
            $$__k = $__v;
        }
    }
}
unset($__src, $__k, $__v);

if (!isset($action) || $action == "") {
    $action = "login";
}

include("const.php");

//!!!S
if($action != "top10")  {
	if($digibbs != 0)  {
		include("digi_checklogin.php");
	}
}
//!!!E

if (true)
{
	if (!$link = @db_connect($dbhost,$dbuser,$dbpass))
	{
		include("html.php");
		HTMLbegincompact("Database Error!");
		print "The game database is currently unavailable. Please try again later.\n";
		HTMLendcompact();
		exit;
	}
	db_select_db($dbname);
	if ($action == "game")
		$action = "main";

	/*
	 * Safe automatic turn execution.
	 * Do not run turns during login/signup/top10/count/admin/chat or any POST action.
	 * This prevents intermittent 500 errors when the first request after idle time
	 * coincides with form handling such as build/attack/market/aid.
	 */
	$__auto_turn_safe_actions = array("main", "status");
	$__auto_turn_is_post = (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) == 'POST');
	if (!$__auto_turn_is_post && in_array($action, $__auto_turn_safe_actions)) {
		@include_once("auto_turn.php");
	}
	unset($__auto_turn_safe_actions, $__auto_turn_is_post);

	include("$action.php");
}
