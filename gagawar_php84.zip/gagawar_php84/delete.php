<?php
include("header.php");

if ($do_delete)
{
	if ($delete_name == $users['name'])
	{
		db_query("UPDATE $playerdb SET land=0,disabled=4 WHERE num=$users[num];");
?>
당신의 계정은 삭제 처리될것으로 표기되었습니다. 그 동안 게임을 놀아주셔서 감사합니다!<br>
<a href="<?php echo $config['home']?>">홈</a>
<?php
		TheEnd("");
	}
	else	// name incorrect
		TheEnd("이름이 틀렸습니다. 계정이 삭제되지 않았습니다, 가입 당시 이름 $users[name]");
}
?>
<form method="post" action="<?php echo $config['main']?>?action=delete">
<div>
계정을 삭제하기 위해선 가입 당시에 사용한 이름을 입력하셔야 합니다.<br>
이름: <input type="text" name="delete_name" size="20"><br>
<input type="submit" name="do_delete" value="계정 삭제하기">
</div>
</form>
<?php
TheEnd("");
?>
