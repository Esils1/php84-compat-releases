<?php
include("header.php");

// this function generates the drop down box for ally and war lists
function listopt ($item)
{
	global $clandb, $uclan;
?>
<select name="<?php echo $item?>" size="1">
<option value="0"<?php if ($uclan[$item] == 0) print " selected";?>>None</option>
<?php
	$list = db_query("SELECT num,name,tag FROM $clandb WHERE members>0 ORDER BY num DESC;");
	while ($clan = db_fetch_array($list))
	{
?>
<option value="<?php echo $clan['num']?>"<?php if ($clan['num'] == $uclan[$item]) print " selected";?>><?php echo $clan['tag']?>: <?php echo $clan['name']?></option>
<?php
	}
?>
</select>
<?php
}

if ($users['clan'] == 0)
	TheEnd("당신은 그 동맹에 속해있지 않습니다!");

$uclan = loadClan($users['clan']);
if ($uclan['founder'] != $users['num'])
	TheEnd("당신은 그 동맹의 지도자가 아닙니다!");

if ($do_removeempire)
{
	$enemy = loadUser($modify_empire);
	if ($enemy['clan'] != $uclan['num'])
		TheEnd("그 제국은 당신의 동맹에 속해 있지 않습니다!");
	if ($enemy['num'] == $users['num'])
		TheEnd("자기 자신을 동맹에서 탈퇴시길 수 없습니다. 공식적으로 동맹을 해체하시길 바랍니다.");
	$enemy['clan'] = 0;
	saveUserData($enemy,"clan");
	addNews(114,$users,$enemy,0);
	$uclan['members']--;
	saveClanData($uclan,"members");
	TheEnd("당신은 <b>$enemy[empire] (#$enemy[num])</b> 을 당신의 동맹에서 쫓아냈습니다.");
}
if ($do_changepass)
{
	if ($new_password == $new_password_verify)
	{
		$uclan['password'] = md5($new_password);
		saveClanData($uclan,"password");
		TheEnd("동맹 암호가 변경되었습니다.");
	}
	else	TheEnd("암호들이 일치하지 않습니다!");
}
if ($do_changeflag)
{
	$uclan['pic'] = $new_flag;
	saveClanData($uclan,"pic");
	TheEnd("동맹 깃발이 변경되었습니다.");
}
if ($do_changename)
{
	if (!$new_name)
		TheEnd("새 이름을 입력하지 않았습니다!");
	$uclan['name'] = trim(HTMLSpecialChars($new_name));
	saveClanData($uclan,"name");
	TheEnd("동맹 이름이 변경되었습니다.");
}
if ($do_changeurl)
{
	$uclan['url'] = $new_url;
	saveClanData($uclan,"url");
	TheEnd("동맹 홈페이지 URL 주소가 변경되었습니다.");
}
if ($do_changemotd)
{
	$uclan['motd'] = HTMLSpecialChars($new_motd);	// don't allow HTML tags
	saveClanData($uclan,"motd");
	TheEnd("동맹 MOTD 가 변경되었습니다.");
}
if ($do_makefounder)
{
	$newfounder = loadUser($modify_empire);
	if ($newfounder['clan'] == $users['clan'])
	{
		$uclan['founder'] = $newfounder['num'];
		saveClanData($uclan,"founder");
		addNews(115,$users,$enemy,0);
		TheEnd("<b>$newfounder[empire] (#$newfounder[num])</b> 이 이제 <b>$uclan[name] 의 지도자입니다</b>.");
	}
	else	TheEnd("그 제국은 당신의 동맹에 속해있지 않습니다!");
}
if ($do_changerelations)
{
	$uclan['ally1'] = $ally1;
	$uclan['ally2'] = $ally2;
	$uclan['ally3'] = $ally3;
	$uclan['war1'] = $war1;
	$uclan['war2'] = $war2;
	$uclan['war3'] = $war3;
	saveClanData($uclan,"ally1 ally2 ally3 war1 war2 war3");
	TheEnd("당신의 동맹의 관계를 변경했습니다.");
}

if ($uclan['url'])
{
?><a href="<?php echo $uclan['url']?>" target="_blank"><?php
}
if ($uclan['pic'])
{
?><img src="<?php echo $uclan['pic']?>" style="border:0" alt="<?php echo $uclan['name']?> 의 홈페이지"><?php
}
elseif ($uclan['url'])
{
?><?php echo $uclan['name']?>'s Home Page<?php
}
if ($uclan['url'])
{
?></a><?php
}
?>
<br>
<table style="background-color:#1F1F1F">
<tr><th class="<?php echo $uera['name']?>"> 동맹 관리: <i><?php echo $uclan['tag']?></i></th></tr>
<tr><td class="acenter"><a href="<?php echo $config['main']?>?action=clanstats&amp;sort_type=avgnet">평균 총 재산에 의한 최고 동맹</a></td></tr>
<tr><td class="acenter"><a href="<?php echo $config['main']?>?action=clanstats&amp;sort_type=members">구성원 수에 의한 최고 동맹</a></td></tr>
<tr><td class="acenter"><a href="<?php echo $config['main']?>?action=clanstats&amp;sort_type=totalnet">총 재산에 의한 최고 동맹</a></td></tr>
</table>
<form method="post" action="<?php echo $config['main']?>?action=clanmanage">
<div>
<h3><?php echo $uclan['name']?> 관계</h3>
<table class="inputtable">
<tr><th><span class="cgood">동맹</span><br>공격 불가</th>
    <th><span class="cbad">전쟁</span><br>무한 공격/마법</th></tr>
<tr><td><?php listopt('ally1');?></td>
    <td><?php listopt('war1');?></td></tr>
<tr><td><?php listopt('ally2');?></td>
    <td><?php listopt('war2');?></td></tr>
<tr><td><?php listopt('ally3');?></td>
    <td><?php listopt('war3');?></td></tr>
<tr><td colspan="2" class="acenter"><input type="submit" name="do_changerelations" value="관계 변경하기"></td></tr>
</table><br>
<?php echo $uclan['name']?> 이 현재 <?php echo $uclan['members']?> 구성원을 가지고 있습니다.<br><br>
<table class="inputtable">
<caption><b>제국 목록</b></caption>
<tr><th>변경?</th>
    <th>제국</th>
    <th>총 재산</th>
    <th>순위</th>
<?php //!!!???>
    <th>Sharing</th></tr>
<?php
$dblist = db_query("SELECT empire,num,forces,rank,networth FROM $playerdb WHERE clan=$uclan[num];");
while ($listclan = db_fetch_array($dblist))
{
?>
<tr><td class="acenter"><input type="radio" name="modify_empire" value="<?php echo $listclan['num']?>"<?php if ($listclan['num'] == $uclan['founder']) print " CHECKED";?>></td>
    <td class="acenter"><?php echo $listclan['empire']?> (#<?php echo $listclan['num']?>)</td>
    <td class="aright">$<?php echo commas($listclan['networth'])?></td>
    <td class="aright">#<?php echo $listclan['rank']?></td>
    <td class="acenter"><span class=<?php if ($listclan['forces']) print '"cgood">예'; else print '"cbad">아니오';?></span></td></tr>
<?php
}
?>
<tr><td class="acenter"><input type="submit" name="do_makefounder" value="지도자"><br>
                        <input type="submit" name="do_removeempire" value="제거"></td></tr>
</table><br>
<table class="inputtable">
<tr><th>암호 변경하기:</th>
    <td class="acenter">새 암호: <input type="password" name="new_password" size="8"><br>
                     암호 확인: <input type="password" name="new_password_verify" size="8"></td>
    <td class="acenter"><input type="submit" name="do_changepass" value="암호 변경하기"></td></tr>
<tr><th>동맹 이름:</th>
    <td class="acenter"><input type="text" name="new_name" value="<?php echo $uclan['name']?>" size="32"></td>
    <td class="acenter"><input type="submit" name="do_changename" value="이름 변경하기"></td></tr>
<tr><th>깃발 주소(URL):</th>
    <td class="acenter"><input type="text" name="new_flag" value="<?php echo $uclan['pic']?>" size="32"></td>
    <td class="acenter"><input type="submit" name="do_changeflag" value="깃발 변경하기"></td></tr>
<tr><th>홈페이지 주소(URL):</th>
    <td class="acenter"><input type="text" name="new_url" value="<?php echo $uclan['url']?>" size="32"></td>
    <td class="acenter"><input type="submit" name="do_changeurl" value="주소 변경하기"></td></tr>
</table><br>
동맹 MOTD (Message of the Day, 모든 동맹 구성원의 메인 메뉴 밑에 보입니다, HTML 비허용):<br>
<textarea rows="10" cols="60" name="new_motd"><?php echo $uclan['motd']?></textarea><br>
<input type=submit name="do_changemotd" value="MOTD 변경하기">
</div>
</form>
<?php
TheEnd("");
?>
