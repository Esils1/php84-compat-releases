<?php
include("header.php");

if ($users['era'] == 1) { $rev = "25%"; }
if ($users['era'] == 2)
	$rev = "15%";
if ($users['era'] == 3)
	$rev = "53%";


if ($do_mine)
{
	fixInputNum($mine_turns);
	if ($mine_turns < 0)
		TheEnd("0 이하의 턴으로 채광을 할 수 없습니다!");
	if ($mine_turns > $users['turns'])
		TheEnd("턴이 부족합니다!");
	$turns = takeTurns($mine_turns,'mine');
?>
당신은 총 <?php echo commas($irongained)?> 의 철을 턴 <?php echo $turns?> 개 동안 얻었습니다.<hr>
<?php
}
?>
<form method="post" action="<?php echo $config['main']?>?action=mine">
<center>광산 개발하는 동안 당신은 턴당 <?php echo $rev?> 철을 얻습니다.</center>
<table class="inputtable">
<tr><td>철 광산 개발하는데 몇 턴을 사용하겠습니까?</td>
    <td><input type="text" name="mine_turns" size="5" value="0"></td></tr>
<tr><td colspan="2" class="acenter"><input type="submit" name="do_mine" value="광산 개발"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
