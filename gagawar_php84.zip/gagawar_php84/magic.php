<?php
include("header.php");
include("magicfun.php");

?>
<a href="<?php echo $config['main']?>?action=guide&amp;section=magic&amp;era=<?php echo $users['era']?>">가가전쟁 설명서: 마법</a><br>
<form method="post" action="<?php echo $config['main']?>?action=magic">
마법 주문은 충분한 마법을 모아야만 나타납니다.
<table class="inputtable">
<tr><td><select name="spell_num" size="1">
        <option value="0">마법을 선택하십시오</option>
<?php

// New code hack to only show the spell if you have those runes.
// - zEro

setspcost();
	printMRow(3);
	printMRow(15);
	printMRow(6);
	printMRow(10);
	printMRow(11);
if (($users['runes'] >= $spcost[12]) && ($spname[12])) {
	printMRow(12);
}
	printMRow(14);
if (($users['runes'] >= $spcost[13]) && ($users['land'] >= $config['edneed'])) {
	printMRow(13);
}

// End of new spell hack.

?>
        </select></td></tr>
<tr><td class="acenter"><input type="submit" name="do_spell" value="마법 걸기"></td></tr>
</table>
</form>
<?php
if ($users['shield'] > $time)
	print "<i>우리는 마법에 대한 방어막을 현재 가지고 있습니다. 앞으로 ".round(($users['shield']-$time)/3600,1)." 시간 동안 유지될 것입니다..</i><br>\n";
if ($users['gate'] > $time)
	print "<i>우리는 현재 시간의 문이 열려있습니다. 앞으로 ".round(($users['gate']-$time)/3600,1)." 시간 동안 열여 있을 것입니다.</i><br>\n";
TheEnd("");
?>
