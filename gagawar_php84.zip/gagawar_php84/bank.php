<?php
include("header.php");
$size = calcSizeBonus($users['networth']);
$loanrate = $config['loanbase'] + $size ;
$loanrate = round($loanrate);
$savrate = $config['savebase'] + $size;
$savrate = round($savrate);
$banks2 = round($users['banks'] / 100);
if ($users['banks'] <= 1000) {
	$maxloan = $users['networth'] * 5;
	$maxsave = $users['networth'] * 10;
}
else {
	$maxloan = $users['networth'] * $banks2;
	$maxsave = $users['networth'] * $banks2;
}
$maxsave = round($maxsave);
$maxloan = round($maxloan);

if ($do_borrow)
{
	if ($lastweek)
		TheEnd("게임의 마지막 주에 대출을 받을 수 없습니다!");
	fixInputNum($borrow);
	if ($borrow < 0)
		TheEnd("0 보다 작은 액수를 대출 받을 수 없습니다.");
 	if ($borrow + $users['loan'] > $maxloan)
		TheEnd("그렇게 많이 대출을 받을 수 없습니다.");
	$users['cash'] += $borrow;
	$users['loan'] += $borrow;
	saveUserDataNet($users,"networth cash loan");
?>
당신은 $<?php echo commas($borrow)?> 만ŭ 대출을 받았습니다. 턴당 0.5% 의 대출이 상ȯ될 것입니다.<hr>
<?php
}
if ($do_repay)
{
	fixInputNum($repay);
	if ($repay > $users['cash'])
		TheEnd("당신은 그렇게 많은 돈을 가지고 있지 않습니다!");
	if ($repay > $users['loan'])
		TheEnd("당신은 그렇게 많이 갚을 필요가 없습니다!");
	$users['cash'] -= $repay;
	$users['loan'] -= $repay;
	saveUserDataNet($users,"networth cash loan");
?>
$<?php echo commas($repay)?> 를 지불해주셔서 감사합니다. 당장 반영시Ű도록 하겠습니다.<hr>
<?php
}
if ($do_deposit)
{
	fixInputNum($deposit);
	if ($deposit > $users['cash'])
		TheEnd("당신은 그렇게 많은 돈을 가지고 있지 않습니다!");
	if ($deposit < 0)
		TheEnd("당신은 0 이하의 돈을 입금할 수 없습니다!");
	if ($deposit + $users['savings'] > $maxsave)
		TheEnd("그렇게 많은 돈을 저출할 수 없습니다!");
	$users['cash'] -= $deposit;
	$users['savings'] += $deposit;
	saveUserDataNet($users,"networth cash savings");
?>
당신은 $<?php echo commas($deposit)?> 의 돈을 저축했습니다.<hr>
<?php
}
if ($do_withdraw)
{
	fixInputNum($withdraw);
	if ($withdraw > $users['savings'])
		TheEnd("당신은 저금에 그렇게 많은 돈을 가지고 있지 않습니다!");
	$users['cash'] += $withdraw;
	$users['savings'] -= $withdraw;
	saveUserDataNet($users,"networth cash savings");
?>
당신은 저금에서 $<?php echo commas($withdraw)?> 를 인출합니다.<hr>
<?php
}
?>
<h2>가가전쟁 은행에 오신것을 ȯ영합니다</h2>
<table>
    <tr><td>
    <table class="empstatus" style="width:100%">
        <tr class="inputtable"><th colspan="2" style="text-align:center">저금</th></tr>
        <tr><th>이자 연이율:</th>   <td><?php echo $savrate?>%</td></tr>
        <tr><th>최대 저금가능액:</th><td>$<?php echo commas($maxsave)?></td></tr>
        <tr><th>현재 저금액:</th><td>$<?php echo commas($users['savings'])?></td></tr>
    </table></td>
    <td style="width:10%"></td>
    <td>
    <table class="empstatus" style="width:100%">
        <tr class="inputtable"><th colspan="2" style="text-align:center">대출</th></tr>
        <tr><th>이자 연이율:</th>   <td><?php echo $loanrate?>%</td></tr>
        <tr><th>최대 대출가능액:</th><td>$<?php echo commas($maxloan)?></td></tr>
        <tr><th>현재 대출액:</th><td>$<?php echo commas($users['loan'])?></td></tr>
    </table></td></tr>
</table><br>
이자는 턴당 계산됩니다 (52 턴 = 1 연이율 년)<br>
<?php
if ($users['turnsused'] < $config['protection'])
{
?>
<b>(보ȣ 받고 있는 동안 이자가 계산되지 않습니다)</b><br>
<?php
}
?>
<br>
<form method="post" action="<?php echo $config['main']?>?action=bank">
<table class="inputtable">
<?php
if ($lastweek)
{
?>
<tr><td colspan="3">마지막 주에 대출을 받을 수 없습니다.</td></tr>
<?php
}
else
{
?>
<tr><th>대출 받기</th>
    <td>$<input type="text" name="borrow" size="9" value="0"></td>
    <td><input type="submit" name="do_borrow" value="대출하기"></td></tr>
<?php
}
?>
<tr><th>대출 상ȯ하기</th>
    <td>$<input type="text" name="repay" size="9" value="0"></td>
    <td><input type="submit" name="do_repay" value="상ȯ"></td></tr>
<tr><th>은행에 입금하기</th>
    <td>$<input type="text" name="deposit" size="9" value="0"></td>
    <td><input type="submit" name="do_deposit" value="입금하기"></td></tr>
<tr><th>은행에 인출하기</th>
    <td>$<input type="text" name="withdraw" size="9" value="0"></td>
    <td><input type="submit" name="do_withdraw" value="인출하기"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
