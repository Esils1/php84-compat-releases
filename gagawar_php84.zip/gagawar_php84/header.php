<?php
include("funcs.php");
randomize();
// load user data
$num = sqleval("SELECT num FROM $playerdb WHERE username='$cookie[usernamecookie]' AND password='$cookie[passwordcookie]';");
if (!$num)
{
	HTMLbegincompact("Error");
?>
당신은 현재 로그인되어 있지 않습니다.<br><br>
<a href="<?php echo $config['main']?>?action=login">여기를 눌러</a> 로그인하시길 바랍니다.<br>
<?php
	HTMLendcompact();
	exit;
}
$users = loadUser($num);
$admin = 0;
$suid = 0;
if ($users['disabled'] == 2)
{
	if ($do_updatenet)
	{
		$userlist = db_query("SELECT * FROM $playerdb;");
		while ($user = db_fetch_array($userlist))
			db_query("UPDATE $playerdb SET networth=".getNetworth($user)." WHERE num=$user[num];");
	}
	if ($do_updateranks)
	{
		$i = 1;
		$userlist = db_query("SELECT num FROM $playerdb ORDER BY networth DESC;");
		while ($user = db_fetch_array($userlist))
			db_query("UPDATE $playerdb SET rank=".$i++." WHERE num=$user[num];");
	}
	if ($do_setuser)
	{
		if ($whichuser == 1)
		{
			setcookie("admincookie","");
			$cookie['admincookie'] = "";
		}
		else
		{
			setcookie("admincookie","$whichuser",time()+200000);
			$cookie['admincookie'] = $whichuser;
		}
	}
	$admin = 1;
	HTMLbeginfull($action);		// gotta start the page early for the admin
?>
<form method="post" action="<?php echo $config['main']?>">
<div>
<input type="hidden" name="action" value="<?php echo $action?>">
#<input type="text" name="whichuser" size="4"<?php if ($cookie['admincookie']) print " value=\"$cookie[admincookie]\"";?>>
<input type="submit" name="do_setuser" value="Set User"><br>
<input type="submit" name="do_updatenet" value="Update Networths"> <input type="submit" name="do_updateranks" value="Update Rankings">
</div>
</form>
<?php
	if ($cookie['admincookie'])
	{
		$suid = 1;
		$users = loadUser($cookie['admincookie']);
	}
	else
	{
?>
<a href="<?php echo $config['main']?>?action=clanadmin">둥맹 관리</a><br>
<a href="<?php echo $config['main']?>?action=useradmin">사용자 관리</a><br>
<?php
	}
	if (!$users['num'])
		TheEnd("그런 사용자가 없습니다!");
}
$urace = loadRace($users['race']);
$uera = loadEra($users['era']);
$rtags = loadRaceTags();
$ctags = loadClanTags();
$etags = loadEraTags();

if (!$admin)

// Testing

	HTMLbeginfull($action);		// start the page here for non-admins

if (($users['vacation'] > 0) && ($users['vacation'] < $config['minvacation']+$config['vacationdelay']))
	TheEnd("이 계정은 현재 여행 모드로 ".($config['minvacation']+$config['vacationdelay'] - $users['vacation'])." 시간 동안 놀 수 없습니다.");
?>
<span style="font-size:x-large"><?php echo $config['servname']?></span> - 사용자: <span style="font-size:large"><?php echo $users['empire']?></span> (#<?php echo $users['num']?>)<br>
<b>게임 뉴스:</b> <?php echo $config['news']?><br>
<a href="<?php echo $config['main']?>?action=guide&amp;section=<?php echo $action?>">[게임 설명서]</a> - <a href="<?php echo $config['main']?>?action=<?php echo $action?>" target=_self>[화면 갱신]</a><br>
<?php
printStatsBar();
if (($action != "delete") && ($action != "validate") && ($action != "revalidate"))
{
	switch ($users['disabled'])
	{
	case 0:	if ($users['land'] == 0)
		{
			$users['idle'] = $time;
			$users['disabled'] = 1;
			if (!$suid)
				saveUserData($users,"idle disabled");
?>
당신의 제국은 완전히 잿더미가 되었습니다.<br>
이런 일들이 있었습니다...<br><br>
<?php
			printNews($users);
?>
<a href="<?php echo $config['main']?>?action=delete">계정 삭제하기</a>
<?php
			TheEnd("");
		}
		elseif (($users['turnsused'] > $config['valturns']) && ($users['validated'] == 0))
		{
			$users['idle'] = $time;
			$users['disabled'] = 1;
			if (!$suid)
				saveUserData($users,"idle disabled");
?>
이제 당신은 인증을 받아야합니다. 인증 메일을 받지 못했다면 다시 발송 받을 수 있습니다<br>
<form method="post" action="<?php echo $config['main']?>?action=validate">
<table class="inputtable">
<tr><td>인증 코드 입력하기:</td>
    <td class="aright"><input type="text" size="32" name="valcode"<?php if ($suid) print " value=\"$users[valcode]\"";?>></td></tr>
<tr><th colspan="2" class="acenter"><input type="submit" name="do_validate" value="인증하기"></th></tr>
</table>
</form>
<a href="<?php echo $config['main']?>?action=revalidate">인증 코드 재발급하기</a><br>
<a href="<?php echo $config['main']?>?action=delete">계정 삭제하기</a>
<?php
			TheEnd("");
		}
		break;
	case 1:	if ($users['validated'] == 0)
		{
?>
당신은 인증을 받지 않았습니다. 계속 놀려면 인증을 받아야합니다. 인증 메일을 받지 못했다면 다시 발송 받을 수 있습니다.<br>
<form method="post" action="<?php echo $config['main']?>?action=validate">
<table class="inputtable">
<tr><td>인증 코드 입력하기:</td>
    <td class="aright"><input type="text" size="32" name="valcode"<?php if ($suid) print " value=\"$users[valcode]\"";?>></td></tr>
<tr><th colspan="2" class="acenter"><input type="submit" name="do_validate" value="인증하기"></th></tr>
</table>
</form>
<a href="<?php echo $config['main']?>?action=revalidate">재발급 받기</a><br>
<a href="<?php echo $config['main']?>?action=delete">계정 삭제</a>
<?php
			TheEnd("");
		}
		elseif ($users['land'] == 0)
		{
			if ($action == "messages")
				break;
?>
당신의 제국은 멸망했습니다.<br>
당신은 할 일이 없습니다...<br><br>
<?php
			printNews($users);
?>
<a href="<?php echo $config['main']?>?action=delete">계정 삭제하기</a>
<?php
			TheEnd("");
		}
		break;
	case 2:	break;
	case 3:	if ($users['ismulti'])
			print "멀티 사용에 의해 이 계정은 정지당했습니다.<br>\n";
		else	print "부정행위에 의해 이 계정은 정지당했습니다.<br>\n";
		TheEnd("관리자 $config[adminemail] 로 연락하시길 바랍니다.");
		break;
	case 4:	TheEnd("당신의 계정은 삭제 처리 예정입니다. 감사합니다!");
		break;
	}
	$users['ip'] = $REMOTE_ADDR;
	saveUserData($users,"ip");
	if (!$suid)
	{
		$users['online'] = 1;
		$users['ip'] = $REMOTE_ADDR;
		saveUserData($users,"online ip");
	}
}
?>
