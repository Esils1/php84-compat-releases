<?php
include("header.php");
if ($do_explore)
{
	fixInputNum($explore_turns);
	if ($explore_turns < 0)
		TheEnd("0 이하의 턴 동안 탐사하실 수 없습니다!");
	if ($explore_turns > $users['turns'])
		TheEnd("당신은 그렇게 많은 턴을 가지고 있지 않습니다!");
	$turns = takeTurns($explore_turns,'land');
	print "당신은 ".commas($landgained)." 땅을 $turns 턴 동안 얻습니다.<HR>\n";
}
?>
탐사하는 턴당 당신은 <b><?php echo gimmeLand($users['land'],$urace['expl'],$users['era'])?></b> 땅을 얻습니다.<br>
<form method="post" action="<?php echo $config['main']?>?action=land">
<table class="inputtable">
<tr><td>몇 턴 동안 탐사하겠습니까?</td>
    <td><input type="text" name="explore_turns" size="5" value="0"></td></tr>
<tr><td colspan="2" class="acenter"><input type="submit" name="do_explore" value="탐사하기"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
