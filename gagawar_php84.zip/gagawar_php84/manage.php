<?php
include("header.php");
// killUnits(unit,0.10,0.30,3) will destroy 30%-90% of unit
// use multiple rolls to get numbers closer to the middle
function killUnits ($type, $minpc, $maxpc, $rolls)
{
	global $users;
	$losspct = 0;
	$min = round(1000000 * $minpc);
	$max = round(1000000 * $maxpc);
	for ($i = 0; $i < $rolls; $i++)
		$losspct += mt_rand($min,$max);
	$losspct /= 1000000;
	$loss = round($users[$type] * $losspct);
	$users[$type] -= $loss;
	return $loss;
}

if (($do_polymorph) && ($yes_polymorph))
{
	if ($users['turns'] < $config['initturns'])
		TheEnd("당신은 턴이 부족합니다!");
	if ($users['health'] < 75)
		TheEnd("당신은 건강이 부족합니다!");
	if ($users['wizards'] < $users['land']*3)
		TheEnd("당신은 $uera[wizards] 이 부족합니다!");
	if ($new_race != $users['race'])
	{
		$users['health'] -= 50;
		$users['turns'] -= $config['initturns'];
		print "당신의 $uera[wizards] 이 집중합니다. 당신의 국민들이 모습이 바뀝니다...<br>";
		print commas(killUnits('armtrp',0.10,0.15,1))." $uera[armtrp], ".
			commas(killUnits('lndtrp',0.10,0.15,1))." $uera[lndtrp], ".
			commas(killUnits('flytrp',0.10,0.15,1))." $uera[flytrp], ".
			commas(killUnits('seatrp',0.10,0.15,1))." $uera[seatrp], ".
			commas(killUnits('peasants',0.15,0.20,1))." $uera[peasants], 와 ".
			commas(killUnits('wizards',0.10,0.15,1))." $uera[wizards] 이 쇼크로 인해 죽습니다.<br>\n";
		$buildloss = 0;
		$buildloss += killUnits('homes',0.08,0.27,2);
		$buildloss += killUnits('shops',0.08,0.27,2);
		$buildloss += killUnits('industry',0.08,0.27,2);
		$buildloss += killUnits('barracks',0.08,0.27,2);
		$buildloss += killUnits('labs',0.08,0.27,2);
		$buildloss += killUnits('farms',0.08,0.27,2);
		$buildloss += killUnits('towers',0.08,0.27,2);
		$users['freeland'] += $buildloss;
		$size = calcSizeBonus($users['networth']);
		print commas($buildloss)." 구조물, ".
			commas(killUnits('food',0.05*$size,0.15*$size,3))." $uera[food], ".
			commas(killUnits('runes',0.05*$size,0.15*$size,3))." $uera[runes], 와 $".
			commas(killUnits('cash',0.05*$size,0.15*$size,3))." 이 혼란에 소모되었습니다.<br>\n";
		$users['race'] = $new_race;
		$urace = loadRace($users['race']);
		$users['networth'] = getNetworth($users);
		saveUserDataNet($users,"networth armtrp lndtrp flytrp seatrp wizards homes shops industry barracks labs farms towers freeland food runes cash turns health race");
	}
}
if ($do_changetax)
{
	fixInputNum($new_tax);
	if ($new_tax < 5)
		TheEnd("그렇게 낮게 세금을 책정할 수 없습니다!");
	if ($new_tax > 70)
		TheEnd("그렇게 높게 세금을 책정할 수 없습니다!");
	$users['tax'] = $new_tax;
	saveUserData($users,"tax");
	print "세금 비율이 업데이트되었습니다!<br>\n";
}

// New code
// CSS Changer
// Idea from QM 3.1
// - zEro

if ($do_changestyle)
{
	fixInputNum($style);
	$users['style'] = $style;
	saveUserData($users,"style");
}

// End of code

if ($do_changeindustry)
{
	fixInputNum($ind_armtrp);
	fixInputNum($ind_lndtrp);
	fixInputNum($ind_flytrp);
	fixInputNum($ind_seatrp);

	$total = $ind_armtrp + $ind_lndtrp + $ind_flytrp + $ind_seatrp;
	if (($ind_armtrp > 100) || ($ind_armtrp < 0))		// infantry
		TheEnd("생산 비율을 그렇게 설정하실 수 없습니다!");
	elseif (($ind_lndtrp > 100) || ($ind_lndtrp < 0))	// tanks
		TheEnd("생산 비율을 그렇게 설정하실 수 없습니다!");
	elseif (($ind_flytrp > 100) || ($ind_flytrp < 0))	// helis
		TheEnd("생산 비율을 그렇게 설정하실 수 없습니다!");
	elseif (($ind_seatrp > 100) || ($ind_seatrp < 0))	// ships
		TheEnd("생산 비율을 그렇게 설정하실 수 없습니다!");
	elseif ($total > 100)					// total
		TheEnd("생산 비율을 그렇게 설정하실 수 없습니다!");
	$users['ind_armtrp'] = $ind_armtrp;
	$users['ind_lndtrp'] = $ind_lndtrp;
	$users['ind_flytrp'] = $ind_flytrp;
	$users['ind_seatrp'] = $ind_seatrp;
	saveUserData($users,"ind_armtrp ind_lndtrp ind_flytrp ind_seatrp");
	print "생산 비율이 업데이트 되었습니다!<br>\n";
}
if ($do_changepass)
{
	if (($new_password) && ($new_password == $new_password_verify))
	{
		db_query("update $playerdb set password=MD5('$new_password') where num=$users[num];");
		TheEnd("암호가 변경되었습니다. 다시 로그아웃하셔서 로그인하시길 바랍니다.");
	}
	else	print "오류! 암호들이 일치하지 않습니다!<br>\n";
}
if (($do_setvacation) && ($yes_vacation))
{
	if ($lastweek)
		TheEnd("마지막 주 동안은 여행 모드가 금지되어 있습니다!");
	$users['vacation'] = 1;
	SaveUserData($users,"vacation");
	TheEnd("여행 모드가 설정되 었습니다. $config[vacationdelay] 동안 당신의 제국은 정지 당합니다.");
}
?>
<a href="<?php echo $config['main']?>?action=guide&amp;section=manage&amp;era=<?php echo $users['era']?>">가가전쟁 설명서: 제국 관리</a><br>
<table style="width:100%">
<tr><td class="acenter" style="width:30%">
        <form method="post" action="<?php echo $config['main']?>?action=manage">
        <table class="inputtable">
        <tr><th>다형변화</th></tr>
        <tr><td class="acenter"><?php echo $config['initturns']?> 턴 필요,<br><?php echo $users['land']*3?> <?php echo $uera['wizards']?> 필요, 그리고 <br>최소 75% 건강 필요</td></tr>
<?php
	$races = db_query("select id,name from $racedb;");
	while ($race = db_fetch_array($races))
	{
?>
        <tr><td><label><input type="radio" name="new_race" value="<?php echo $race['id']?>"<?php if ($race['id'] == $users['race']) print " checked";?>> <?php echo $race['name']?></label></td></tr>
<?php
	}
?>
        <tr><td class="acenter"><label><input type="checkbox" name="yes_polymorph" value="1">예,<br> 정말 다형변화를 하고 싶습니다!</td></tr>
        <tr><th><input type="submit" name="do_polymorph" value="다형변화 시작"></th></tr>
        </table>
        </form>
    </td>
    <td class="acenter" style="width:30%">
        <form method="post" action="<?php echo $config['main']?>?action=manage">
        <table class="inputtable">
        <tr><td>세금 비율:</td>
            <td class="aright"><input type="text" name="new_tax" size="3" value="<?php echo $users['tax']?>">%</td></tr>
        <tr><th colspan="2"><input type="submit" name="do_changetax" value="세금 비율 변동하기"></th></tr>
        </table>
        </form>
        <form method="post" action="<?php echo $config['main']?>?action=manage">
        <table class="inputtable">
        <tr><th colspan="2">생산 비율 설정</th></tr>
        <tr><td><?php echo $uera['armtrp']?></td>
            <td class="aright"><input type="text" name="ind_armtrp" size="3" value="<?php echo $users['ind_armtrp']?>">%</td></tr>
        <tr><td><?php echo $uera['lndtrp']?></td>
            <td class="aright"><input type="text" name="ind_lndtrp" size="3" value="<?php echo $users['ind_lndtrp']?>">%</td></tr>
        <tr><td><?php echo $uera['flytrp']?></td>
            <td class="aright"><input type="text" name="ind_flytrp" size="3" value="<?php echo $users['ind_flytrp']?>">%</td></tr>
        <tr><td><?php echo $uera['seatrp']?></td>
            <td class="aright"><input type="text" name="ind_seatrp" size="3" value="<?php echo $users['ind_seatrp']?>">%</td></tr>
        <tr><th colspan="2"><input type ="submit" name="do_changeindustry" value="생산 비율 설정하기"></th></tr>
        </table>
<br>
        <table class="inputtable">
        <tr><th>HTML 스타일 선택하기</th></tr>
        <tr><td class="acenter">
                당신은 <?php echo $config['maxstyles']?> HTML 스타일 중에 선택하실 수 있습니다.</td></tr>
        <tr><td class="acenter"><label><select name="style">
<?php 
for ($i=0; $i < $config['maxstyles']; $i++) {
	print "<option value=$i>$styles[$i]</option>";
}
?>
</select>

</label></td></tr>
        <tr><th><input type="submit" name="do_changestyle" value="스타일 변경하기"></th></tr>
        </table>
<!-- End of new code -->

        </form>
    </td>
    <td class="acenter" style="width:40%">
        <form method="post" action="<?php echo $config['main']?>?action=manage">
        <table class="inputtable">
<?php /*        <tr><th colspan="2">Change Password</th></tr>
        <tr><td>New:</td>
            <td><input type="password" name="new_password" size="8"></td></tr>
        <tr><td>Verify:</td>
            <td><input type="password" name="new_password_verify" size="8"></td></tr>
        <tr><th colspan="2"><input type="submit" name="do_changepass" value="암호 변경하기"></th></tr>
*/?>
        </table>
        </form>
<?php
if (!$lastweek)
{
?>
<?php
//!!!
//여행모드 삭제
//!!!
?>	
<?php
}
else	print "마지막 주 동안은 여행 모드를 사용하실 수 없습니다.<br>\n";
?>
    </td></tr>
</table>
        </form>
<?php
TheEnd("");
?>
