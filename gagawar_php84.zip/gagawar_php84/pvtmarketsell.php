<?php
include("header.php");

// preset prices; getCosts adjusts them according to your barracks/land ratio and race bonus
$costs['armtrp'] = $config['armtrp'] * .32;
$costs['lndtrp'] = $config['lndtrp'] * .34;
$costs['flytrp'] = $config['flytrp'] * .36;
$costs['seatrp'] = $config['seatrp'] * .38;
$costs['food'] = $config['food'] * .20;
$costs['runes'] = $config['runes'] * .20;
$costs['iron'] = $config['iron'] * .26;

function getCosts ($type)
{
	global $users, $urace, $costs, $canbuy, $config;
// when selling units, the bonus INCREASES the price, so you can get more for them
	$costbonus = 1 + (1-$config['mktshop']) * ($users['barracks'] / $users['land']) + $config['mktshop'] * ($users['shops'] / $users['land']);
	if ($type == 'food')				// food unaffected by cost bonuses
		$costs[$type] = round($costs[$type]);
	elseif ($type == 'runes')
		$costs[$type] = round($costs[$type]);
	elseif ($type == 'iron')
		$costs[$type] = round($costs[$type]);
	else
	{
		$costs[$type] = $costs[$type] * $costbonus;
		if ($costs[$type] > $config[$type] * .5)
			$costs[$type] = $config[$type] * .5;
		$costs[$type] = round($costs[$type] * $urace['mkt']);
	}
}

function sellUnits ($type)
{
	global $users, $uera, $sell, $costs, $config;
	$amount = $sell[$type];
	fixInputNum($amount);
	$cost = $amount * $costs[$type];
	if ($amount == 0)
		return;
	elseif ($amount < 0)
		print "$uera[$type]를 0 보다 작은 숫자를 팔 수 없습니다!<br>\n";
	elseif ($type != 'food' && $amount > ($config['bmperc'] - $users["bmper"."$type"])/10000 * $users[$type])
		print "$uera[$type]를 그렇게 많이 팔 수 없습니다!<br>\n";
	elseif ($type == 'food' && $amount > $users[$type])
		print "$uera[$type]를 그렇게 많이 가지고 있지 않습니다!<br>\n";
	elseif ($type == 'runes' && $amount > $users[$type])
		print "$uera[$type]를 그렇게 많이 가지고 있지 않습니다!<br>\n";
	elseif ($type != 'runes' && $amount > ($config['bmperc'] - $users["bmper"."$type"])/10000 * $users[$type])
		print "$uera[$type]를 그렇게 많이 팔 수 없습니다!<br>\n";
	elseif ($type == 'iron' && $amount > $users[$type])
		print "$uera[$type]를 그렇게 많이 가지고 있지 않습니다!<br>\n";
	elseif ($type != 'iron' && $amount > ($config['bmperc'] - $users["bmper"."$type"])/10000 * $users[$type])
		print "$uera[$type]를 그렇게 많이 팔 수 없습니다!<br>\n";

	else
	{
		$users['cash'] += $cost;
		$users["bmper"."$type"] = $users["bmper"."$type"] + ($amount/$users[$type])*10000;
		$users[$type] -= $amount;
		print commas($amount)." $uera[$type] sold for $".commas($cost)."<br>\n";
	}
}

function printRow ($type)
{
	global $users, $uera, $costs, $config;
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($users[$type])?></td>
    <td class="aright"><?php if($type!='food') print commas(floor(($config['bmperc'] - $users["bmper"."$type"])/10000 * $users[$type])); else print commas($users[$type]);?></td>
    <td class="aright">$<?php echo $costs[$type]?></td>
    <td class="aright"><input type="text" name="sell[<?php echo $type?>]" size="8" value="0"></td></tr>
<?php
}

// for ($i = 0; $i < 5; $i++)
for ($i = 0; $i < 7; $i++)
	getCosts($trplst[$i]);
if ($do_sell)
{
//	for ($i = 0; $i < 5; $i++)
	for ($i = 0; $i < 7; $i++)
		sellUnits($trplst[$i]);
	saveUserDataNet($users,"networth cash armtrp lndtrp flytrp seatrp food bmperseatrp bmperflytrp bmperlndtrp bmperarmtrp runes iron");
}
?>
참고: <a href="<?php echo $config['main']?>?action=guide&amp;section=military&amp;era=<?php echo $users['era']?>">가가전쟁 설명서: 군대</a><br>
<form method="post" action="<?php echo $config['main']?>?action=pvtmarketsell">
<table class="inputtable">
<tr><td colspan="3"><a href="<?php echo $config['main']?>?action=pvtmarketbuy">물건 구입하기</a></td>
    <td colspan="2" class="aright"><a href="<?php echo $config['main']?>?action=pvtmarketsell">물건 판매하기</a></td></tr>
<tr><th class="aleft">대상</th>
    <th class="aright">소유</th>
    <th class="aright">판매 가능</th>
    <th class="aright">가격</th>
    <th class="aright">판매</th></tr>
<?php
// for ($i = 0; $i < 5; $i++)
for ($i = 0; $i < 7; $i++)
	printRow($trplst[$i]);
?>
<tr><td colspan="6" class="acenter"><input type="submit" name="do_sell" value="물건 팔기"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
