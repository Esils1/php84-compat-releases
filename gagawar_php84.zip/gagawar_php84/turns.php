<?php
include_once("const.php");
include_once("funcs.php");
if ($REQUEST_URI)
{
	HTMLbegin("Error");
	print "Access forbidden!<br>\n";
	HTMLend();
	exit;
}
if (!$link = @db_connect($dbhost,$dbuser,$dbpass))
{
	print "Error! Database unavailable!\n";
	exit;
}
db_select_db($dbname);
$hour = date("H");
$min = date("i");
if ($lockdb)
{
	print "데이터베이스는 현재 잠겨있습니다. 턴 생성이되지 않았습니다...\n";
		// so everyone doesn't get deleted when turns start running
	db_query("UPDATE $playerdb SET idle=$time;");
}
else
{
	print "$datetime: Processing turns...";
//S!!!
db_query("UPDATE $playerdb SET attacks=(attacks-1) WHERE attacks>0;");
//E!!!
	if ($min == $turnoffset)
	{
		if ($hour == 24)
		{
			randomize();
			// DO NOT CHANGE THIS LINE
			if ($config['updater'] == 1) 
			//	updateinfo("http://www.madeinphp.com/update.info");
			// ...
			$lotterynum = mt_rand(1,3 * sqleval("SELECT num FROM $playerdb ORDER BY num DESC LIMIT 1;"));

			$jackpot = sqleval("SELECT cash FROM $lotterydb WHERE num=0 AND ticket=$tick_curjp;");
			$lastjackpot = sqleval("SELECT cash FROM $lotterydb WHERE num=0 AND ticket=$tick_lastjp;");

			db_query("UPDATE $lotterydb SET cash=$lotterynum WHERE num=0 AND ticket=$tick_lastnum;");

			if ($lastjackpot > $jackpot)
				$lastjackpot = $config['jackpot'];
			db_query("UPDATE $lotterydb SET cash=$jackpot WHERE num=0 AND ticket=$tick_lastjp;");
			db_query("UPDATE $lotterydb SET cash=($jackpot-$lastjackpot) WHERE num=0 AND ticket=$tick_jpgrow;");

			$win = sqleval("SELECT num FROM $lotterydb WHERE num>0 AND ticket=$lotterynum;");
			if ($win)
			{
				$winner = loadUser($win);
				addNews(101,$winner,$winner,$jackpot);
		               	$winner['cash'] += $jackpot;
				saveUserDataNet($winner,"networth cash");
				db_query("UPDATE $lotterydb SET cash=$config[jackpot] WHERE num=0 AND ticket=$tick_curjp;");
			}
			else	$win = 0;
			db_query("UPDATE $lotterydb SET cash=$win WHERE num=0 AND ticket=$tick_lastwin;");
			db_query("DELETE FROM $lotterydb WHERE num>0;");
		}
		if ($hour == $config['aidhours']) {
			db_query("UPDATE $playerdb SET aidcred=(aidcred+1) WHERE aidcred < $config[maxaid];");
			db_query("UPDATE $playerdb SET aidget=(aidget-1) WHERE aidget >= 0;");
		}
		db_query("OPTIMIZE TABLE lottery, market;");	// the only tables that get deleted from

		// db_query("UPDATE $playerdb SET aidcred=(aidcred+1) WHERE aidcred<5;");
		//!!!db_query("UPDATE $playerdb SET attacks=(attacks-1) WHERE attacks>0;");
		db_query("UPDATE $playerdb SET vacation=(vacation+1) WHERE vacation>0;");
	}
	db_query("UPDATE $playerdb SET turns=(turns+$turnsper) WHERE vacation=0 AND disabled<=2;");
	
	// Health recovers...	
	db_query("UPDATE $playerdb SET health=(health+1) WHERE health<100;");
	db_query("UPDATE $playerdb SET health=100 WHERE health>100;");

	db_query("UPDATE $playerdb SET turns=(turns+1),turnsstored=(turnsstored-1) WHERE vacation=0 AND disabled<=2 AND turnsstored>0;");
	db_query("UPDATE $playerdb SET turnsstored=(turnsstored+(turns-$config[maxturns])),turns=$config[maxturns] WHERE turns>$config[maxturns];");
	db_query("UPDATE $playerdb SET turnsstored=$config[maxstoredturns] WHERE turnsstored>$config[maxstoredturns];");
// another fix..
// - zero
	db_query("UPDATE $playerdb SET msgcred=(msgcred+1) WHERE msgcred < $config[maxmsg];");

	db_query("UPDATE $playerdb SET bmperarmtrp=(bmperarmtrp-(100*(1+shops/land))) WHERE bmperarmtrp > (100*(1+shops/land));");
	db_query("UPDATE $playerdb SET bmperlndtrp=(bmperlndtrp-(100*(1+shops/land))) WHERE bmperlndtrp > (100*(1+shops/land));");
	db_query("UPDATE $playerdb SET bmperflytrp=(bmperflytrp-(100*(1+shops/land))) WHERE bmperflytrp > (100*(1+shops/land));");
	db_query("UPDATE $playerdb SET bmperseatrp=(bmperseatrp-(100*(1+shops/land))) WHERE bmperseatrp > (100*(1+shops/land));");
	db_query("UPDATE $playerdb SET bmperarmtrp=0 WHERE bmperarmtrp < (100*(1+shops/land));");
	db_query("UPDATE $playerdb SET bmperlndtrp=0 WHERE bmperlndtrp < (100*(1+shops/land));");
	db_query("UPDATE $playerdb SET bmperflytrp=0 WHERE bmperflytrp < (100*(1+shops/land));");
	db_query("UPDATE $playerdb SET bmperseatrp=0 WHERE bmperseatrp < (100*(1+shops/land));");

	db_query("UPDATE $playerdb SET pmkt_armtrp=(pmkt_armtrp+(8*(land + barracks))) WHERE pmkt_armtrp < (250 * (land+(2 * barracks)));");
	db_query("UPDATE $playerdb SET pmkt_lndtrp=(pmkt_lndtrp+(5*(land + barracks))) WHERE pmkt_lndtrp < (200 * (land+(2 * barracks)));");
	db_query("UPDATE $playerdb SET pmkt_flytrp=(pmkt_flytrp+(3*(land + barracks))) WHERE pmkt_flytrp < (180 * (land+(2 * barracks)));");
	db_query("UPDATE $playerdb SET pmkt_seatrp=(pmkt_seatrp+(2*(land + barracks))) WHERE pmkt_seatrp < (150 * (land+(2 * barracks)));");
	db_query("UPDATE $playerdb SET pmkt_food=(pmkt_food+(50*(land + farms))) WHERE pmkt_food < (2000 * (land + farms));");
	db_query("UPDATE $playerdb SET online=0 WHERE idle<($time-(3600 / $perminutes));");	// set 'em offline after they're idle for 2 turns updates

	db_query("UPDATE $playerdb SET idle=$time WHERE password='farm';");	// so the land farms won't idle to death

	/* new players must validate their accounts within 48 hours */
	/* you can not idle for more than 7 days unless you are on vacation or disabled */
	/* dead empires get deleted after 3 days */
	/* empires marked for deletion are deleted immediately */
	$delusers = db_query("SELECT * FROM $playerdb WHERE
		(validated=0 AND disabled=1 AND idle<($time-86400*2)) OR
		(disabled<=1 AND vacation=0 AND land>0 AND idle<($time-86400*7)) OR
		(land=0 AND disabled=1 AND ip!='0.0.0.0' AND idle<($time-86400*3)) OR
		(disabled=4)
			;");
	while ($users = db_fetch_array($delusers))
	{
		print "Deleting user $users[empire] (#$users[num])...\n";
		db_query("UPDATE $messagedb SET deleted=1 WHERE src=$users[num] OR dest=$users[num];");
										// delete any messages to/from that user
		db_query("DELETE FROM $marketdb WHERE seller=$users[num];");	// any of the user's items on the market
		db_query("DELETE FROM $lotterydb WHERE num=$users[num];");	// any lottery tickets
		$users['name'].= ".DEAD.".$time;
		$users['username'] .= ".DEAD.".$time;
		$users['password'] = md5($users['password']);
		$users['email'] .= ".DEAD.".$time;
		$users['disabled'] = $users['validated'] = 1;
		$users['land'] = $users['shops'] = $users['homes'] = $users['industry'] = $users['barracks'] = $users['labs'] = $users['farms'] = $users['towers'] = $users['freeland'] = 0;
		$users['ip'] = "0.0.0.0";
		$users['idle'] = $time;
										// and kill the user
		saveUserDataNet($users,"networth name username password email disabled validated land shops homes industry barracks labs farms towers freeland ip idle");
	}

	print "...done!  ";
}
print "Updating ranks...";
$users = db_query("SELECT num FROM $playerdb ORDER BY networth DESC;");
$urank = 0;
while ($user = db_fetch_array($users))
{
	$urank++;
	db_query("UPDATE $playerdb SET rank=$urank WHERE num=$user[num];");
}
print "done!\n\n";
?>
