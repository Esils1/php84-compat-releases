<?php
include("header.php");

function printRow ($type)
{
	global $users, $uera, $canbuild;
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($users[$type])?></td>
    <td class="aright"><?php echo commas($canbuild)?></td>
    <td class="aright"><input type="text" name="build[<?php echo $type?>]" size="5" value="0"></td></tr>
<?php
}

function getBuildAmounts ()
{
	global $users, $config, $urace, $buildcost, $buildrate, $canbuild;
	$buildcost = round($config['buildings'] + ($users['land'] * 0.1));
	$buildrate = $users['land'] * 0.015 + 4;
//	if ($buildrate > 400)	$buildrate = 400;
	$buildrate = round($urace['bpt'] * $buildrate);
	$canbuild = floor($users['cash'] / $buildcost);		// limit by money
	if ($canbuild > $buildrate * $users['turns'])		// by turns
		$canbuild = $buildrate * $users['turns'];
	if ($canbuild > $users['freeland'])			// and by land
		$canbuild = $users['freeland'];
}

function buildStructures ($type, $cost)
{
	global $users, $build, $totalbuild, $totalspent;
	$amount = $build[$type];
	fixInputNum($amount);
	if ($amount < 0)
		TheEnd("0 이하의 구조물을 만들 수 없습니다!");
	$users[$type] += $amount;
	$totalbuild += $amount;
	$users['freeland'] -= $amount;
	$users['cash'] -= $amount * $cost;
	$totalspent += $amount * $cost;
}

getBuildAmounts();
if ($do_build)
{	// nothing gets saved until later; if one has invalid input, it'll get caught and will prevent the build
	$totalbuild = $totalspent = 0;
	buildStructures('homes',$buildcost);
	buildStructures('shops',$buildcost);
	buildStructures('industry',$buildcost);
	buildStructures('barracks',$buildcost);
	buildStructures('labs',$buildcost);
	buildStructures('farms',$buildcost);
	buildStructures('towers',$buildcost);
// Alpha Code
	buildStructures('banks',$buildcost);
	buildStructures('mines',$buildcost);
	if ($totalbuild > $canbuild)	// this takes into account turns, money, AND free land all at once
		TheEnd("그렇게 많이 만들 수 없습니다!");
	if ($users['cash'] < 0)		// in case we decide to add variable building costs
		TheEnd("그렇게 많은 돈을 가지고 있지 않습니다!");
	$turns = ceil($totalbuild / $buildrate);
//	saveUserData($users,"homes shops industry barracks labs farms towers freeland cash");
// Alpha Code...
	saveUserData($users,"homes shops industry barracks labs farms towers freeland cash banks mines");
	takeTurns($turns,'build');
?>
당신은 <?php echo commas($totalbuild)?> 구조물을 <?php echo commas($turns)?> 턴 동안 만들며 돈 $<?php echo commas($totalspent)?> 을 사용합니다.<hr>
<?php
	getBuildAmounts();
} 
?>
각 구조물 사용 가능한 땅 1 을 필요하며 돈 $<?php echo commas($buildcost)?> 을 이용합니다.<br>
당신은 턴당 구조물 <?php echo commas($buildrate)?> 을 지을 수 있습니다.<br>
우리의 자원으로는 <span class="cgood"><?php echo commas($canbuild)?></span> 구조물을 만들 수 있습니다.<br><br>
<form method="post" action="<?php echo $config['main']?>?action=build">
<table class="inputtable">
<tr><th class="aleft">구조물</th>
    <th class="aright">보유</th>
    <th class="aright">건설 가능</th>
    <th class="aright">건설</th></tr>
<?php
printRow('shops');
printRow('homes');
printRow('barracks');
printRow('industry');
printRow('labs');
printRow('farms');
printRow('towers');
printRow('banks');
printRow('mines');
?>
<tr><td>사용가능한 땅</td>
    <td class="aright"><?php echo commas($users['freeland'])?></td>
    <td colspan="2"></td></tr>
<tr><td colspan="4" class="acenter"><input type="submit" name="do_build" value="건설하기"></td></tr>
</table>
</form>
<a href="<?php echo $config['main']?>?action=demolish">구조물 파괴하기</a>
<?php
TheEnd("");
?>
