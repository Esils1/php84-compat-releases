<?php
include("funcs.php");

function printTop10Header ()
{
	global $config;
?>
<tr class="era0">
    <th style="width:5%" class="aright"><a href="<?php echo $config['main']?>?action=top10&amp;sort=rank+ASC">랭킹</a></th>
    <th style="width:25%">국가</th>
    <th style="width:10%" class="aright">토지</th>
    <th style="width:15%" class="aright">총 재산</th>
    <th style="width:10%">동맹</th>
    <th style="width:10%">종족</th>
    <th style="width:5%">시대</th>
    <th style="width:8%"><a href="<?php echo $config['main']?>?action=top10&amp;sort=offtotal+DESC">O</a></th>
    <th style="width:8%"><a href="<?php echo $config['main']?>?action=top10&amp;sort=deftotal+DESC">D</a></th>
    <th style="width:4%"><a href="<?php echo $config['main']?>?action=top10&amp;sort=kills+DESC">K</a></th></tr>
<?php
}

$ctags = loadClanTags();
HTMLbegincompact("Top 10");
if (!$sort)
	$sort = "rank ASC";
if (($sort != "rank ASC") && ($sort != "offtotal DESC") && ($sort != "deftotal DESC") && ($sort != "kills DESC"))
{
	print "Invalid sort method!\n";
	HTMLendcompact();
}
?>
<b>가가 전쟁 탑 10</b><br>
현재 게임 시각: <?php echo $datetime?><br><br>
<b><?php echo sqleval("SELECT COUNT(*) FROM $playerdb WHERE online=1;")?></b> 명의 사용자가 현재 접속중입니다. 총 <b><?php echo sqleval("SELECT COUNT(*) FROM $playerdb;")?></b> 명의 사용자가 있습니다.<br>
<b><?php echo $killed=sqleval("SELECT SUM(kills) FROM $playerdb;")?></b> 제국이 멸망했고, <b><?php echo sqleval("SELECT COUNT(*) FROM $playerdb WHERE land=0;")-$killed?></b> 제국이 버림받았습니다.<br>
<b><?php echo sqleval("SELECT COUNT(*) FROM $playerdb WHERE disabled=3;")?></b> 계정이 관리자에 의해 정지당했습니다.<br><br>
<b>랭킹은 <?php echo $perminutes?> 분 마다 업데이트됩니다.</b><br><br>
색깔: <span class="mprotected">보호/여행</span>, <span class="mdead">사망</span>, <span class="mdisabled">정지</span><br>
통계: O = 공격 성공률 (%), D = 방어 성공률 (%), K = 명망시킨 제국 수<br>
* 로 표시된 제국은 현재 온라인입니다.<br>
<table class="scorestable">
<?php
printTop10Header();
$rtags = loadRaceTags();
$etags = loadEraTags();
$users['num'] = 0;	// so we can use printScoreLine() and not worry
$users['clan'] = 0;	// about it using the ingame-specific colors
$top10 = db_query("SELECT rank,empire,num,land,networth,clan,online,disabled,turnsused,vacation,race,era,offsucc,offtotal,defsucc,deftotal,kills FROM $playerdb ORDER BY $sort LIMIT 10;");
while ($enemy = db_fetch_array($top10))
	printSearchLine();
printTop10Header();
?>
</table>
<?php
HTMLendcompact();
?>
