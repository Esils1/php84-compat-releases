<?php
include("header.php");

if ($lockdb)
	TheEnd("메세지 보내는 것은 현재 가능하지 않습니다!");

if ($users['msgcred'] == 0)
	TheEnd("당신은 돈이 떨어졌습니다. 몇 분 더 기다리시길 바랍니다.");

if ($do_message)
{
	$msg_body = HTMLSpecialChars($msg_body);	// don't allow HTML tags
	SQLquotes($msg_body);
	db_query("INSERT INTO $messagedb (time,src,dest,msg) VALUES ($time,$users[num],$msg_dest,'$msg_body');");
	if ($msg_replyto)
	{
		db_query("UPDATE $messagedb SET replied=1 WHERE id=$msg_replyto;");
		TheEnd("제국 #$msg_dest 에 대해 답변하기.");
	}
	else
	{
		$users['msgcred']--;
		saveUserData($users,"msgcred");
		TheEnd("제국 #$msg_dest 에 메세지가 보내졌습니다.");
	}
}
$replyid = 0;
if ($do_reply)
{
	$replyid = $msg_id;
?>
<form method="post" action="<?php echo $config['main']?>?action=messages">
<div>
<input type="hidden" name="msg_replyto" value="<?php echo $msg_id?>">
<input type="hidden" name="msg_dest" value="<?php echo $msg_src?>">
<textarea rows="10" cols="60" name="msg_body"></textarea><br>
<input type="submit" name="do_message" value="제국 #<?php echo $msg_src?> 으로 메세지보내기">
</div>
</form>
<?php
}
if ($do_delete)
{
	db_query("UPDATE $messagedb SET deleted=1 WHERE id=$msg_id AND dest=$users[num];");
	TheEnd("메세지 삭제되었습니다!");
}
if ($do_deleteall)
{
	db_query("UPDATE $messagedb SET deleted=1 WHERE dest=$users[num];");
	TheEnd("모든 메세지가 삭제되었습니다!");
}

$msgs = db_query("SELECT * FROM $messagedb WHERE dest=$users[num] AND deleted=0 ORDER BY time ASC;");
if (db_num_rows($msgs))
{
	while ($message = db_fetch_array($msgs))
	{
		if (($replyid == 0) || ($replyid == $message['id']))
		{
			$enemy = loadUser($message['src']);
?>
<form method="post" action="<?php echo $config['main']?>?action=messages">
<div>
<input type="hidden" name="msg_id" value="<?php echo $message['id']?>">
<input type="hidden" name="msg_src" value="<?php echo $message['src']?>">
<table style="width:100%">
<tr><td>시간: <b><?php echo gaga_korean_datetime($message['time'])?></b>, <b><?php echo $enemy['empire']?> (#<?php echo $enemy['num']?>) 제국으로 부터 메세지가 왔습니다</b></td></tr>
<tr><td><tt><?php echo str_replace("\n","<br>",$message['msg'])?></tt></td></tr>
<?php
			if ($replynum == 0)
			{
?><tr><td><?php
				if ($message['replied'] == 0)
				{
?><input type="submit" name="do_reply" value="답변하기"><?php
				}
?><input type="submit" name="do_delete" value="삭제하기"></td></tr>
<?php 			}
?>
</table>
</div>
</form>
<?php
		}
	}
?>
<form method="post" action="<?php echo $config['main']?>?action=messages">
<div>
<input type="submit" name="do_deleteall" value="모든 메세지 삭제하기">
</div>
</form>
<?php
}
else	print "새로운 메세지가 없습니다...<hr>\n";
$users['msgtime'] = $time;
saveUserData($users,"msgtime");
?>
우리는 현재 <?php echo $users['msgcred']?> 메세지를 보낼 수 있습니다.<br><br>
<form method="post" action="<?php echo $config['main']?>?action=messages">
<div>
다음의 제국에게 메세지 보내기: <input type="text" name="msg_dest" size="4"> (제국 번호, # 표시된 부분)<br>
<textarea rows="15" cols="60" name="msg_body"></textarea><br>
<input type="submit" name="do_message" value="메세지 보내기">
</div>
</form>
<?php
TheEnd("");
?>
