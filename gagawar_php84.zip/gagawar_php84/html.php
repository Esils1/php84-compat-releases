<?php
function getmicrotime ()
{
	list($usec, $sec) = explode(" ",microtime());
	return ((double)$usec + (double)$sec);
}

// Begins a full HTML page
function HTMLbeginfull ($title)
{
	global $starttime, $users;
	$starttime = getmicrotime();
	Header("Pragma: no-cache");
	Header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");
	Header("Content-Type: text/html; charset=utf-8");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<html>
<head>
<title>Promisance - <?php echo $title?></title>
<link rel="stylesheet" type="text/css" href="styles/<?php if ($users['style']) { print "$users[style]"; } else { print "default"; }?>.css">
</head>
<body>
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td width="41%"><a href=".">로그인 화면</a></td>
    <td width="59%">
      <div align="right">

			<script language="JavaScript" type="text/JavaScript">function MM_openBrWindowz(theURL,winName,features) {window.open(theURL,winName,features);}</script>

<script language="JavaScript" type="text/JavaScript">function MM_openBrWindowz(theURL,winName,features) {window.open(theURL,winName,features);}</script>
<div align="right"><a href="#" onClick="MM_openBrWindowz('chat.php','gagachatscreen','width=760,height=360')">채팅 방</a></div>

	  </div>
    </td>
  </tr>
</table>

<table style="width:100%">
<tr><td style="width:144px;vertical-align:top"><?php include("menus.php");?></td><td class="acenter" style="vertical-align:top"><?php include("ad.php");?>
<?php
}

// Ends a full HTML page
function HTMLendfull ()
{
	global $starttime;
	$endtime = getmicrotime() - $starttime;
	echo "<!--$endtime-->\n";
?>
</td></tr>
</table>
</body>
</html>
<?php
}

// Begins a compact HTML page
function HTMLbegincompact ($title)
{
	global $starttime;
	$starttime = getmicrotime();
	Header("Pragma: no-cache");
	Header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");
	Header("Content-Type: text/html; charset=utf-8");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Promisance - <?php echo $title?></title>
<link rel="stylesheet" type="text/css" href="styles/<?php if ($users['style']) { print "$users[style]"; } else { print "default"; }?>.css">
</head>
<body>
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td width="41%"><a href=".">로그인 화면</a></td>
    <td width="59%">
      <div align="right">

			<script language="JavaScript" type="text/JavaScript">function MM_openBrWindowz(theURL,winName,features) {window.open(theURL,winName,features);}</script>

<script language="JavaScript" type="text/JavaScript">function MM_openBrWindowz(theURL,winName,features) {window.open(theURL,winName,features);}</script>
<div align="right"><a href="#" onClick="MM_openBrWindowz('chat.php','gagachatscreen','width=760,height=360')">채팅 방</a></div>

	  </div>
    </td>
  </tr>
</table>

<div class="acenter">
<?php
}

// Ends a compact HTML page
function HTMLendcompact ()
{
	global $starttime;
	$endtime = getmicrotime() - $starttime;
	echo "<!--$endtime-->\n";
?>
</div>
</body>
</html>
<?php
}
?>
