<?php
include("header.php");
if ($mark_news)
{
	$users['newstime'] = $time;
	saveUserData($users,"newstime");
}

printMainStats($users,$urace,$uera);
if ($users['turnsused'] <= $config['protection'])
{
?>
<span class="mprotected">신제국 보호 (<?php echo $config['protection']?> 턴)</span><br>
<?php
}
$nextturn = $perminutes - ((date("i") + $turnoffset) % $perminutes);
?>
<b><?php echo $datetime?></b><br>
<?php echo $perminutes?> 분당 <?php echo $turnsper?> 턴이 생성됩니다<br>
<?php
if ($lockdb)
	print "턴 생성은 현재 정지되어 있습니다.<br><br>\n";
else	print "다음 턴은 $nextturn 분 후에 받습니다<br><br>\n";
$newmsgs = numNewMessages();
$oldmsgs = numTotalMessages() - $newmsgs;
print "<a href=\"$config[main]?action=messages\"><b>";
if ($newmsgs + $oldmsgs)
	print "당신은 $newmsgs 새 메세지가 있으며 $oldmsgs 읽은 메세지가 있습니다.";
else	print "메세지 보내기";
print "</b></a><br>\n";

if ($all_news)
	$users['newstime'] = $time - 86400*7;			// show all news under 1wk old
$hasnews = printNews($users);
if ($all_news)
{
	if (!$hasnews)
		print "<b>뉴스가 없습니다</b><br>\n";
}
else
{
	if ($hasnews)
		print "<a href=\"$config[main]?action=main&amp;mark_news=yes\">읽음으로 뉴스 표시</a><br>\n";
	else	print "<b>새 뉴스가 없습니다</b><br>\n";
	print "<a href=\"$config[main]?action=main&amp;all_news=yes\">뉴스 보기 (7 일 동안)</a><br>\n";
}
TheEnd("");
?>
