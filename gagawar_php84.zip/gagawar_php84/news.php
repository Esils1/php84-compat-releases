<?php
include("header.php");
$newslimit = 100;

if ($do_search)
{
	switch ($search_type)
	{
	case 'num':
		if (!$search_num)
			$dbh = "1";
		elseif ($search_by == 'Attacker')
			$dbh = "num_s=$search_num";
		elseif ($search_by == 'Defender')
			$dbh = "num_d=$search_num";
		else	$dbh = "num_s=$search_num OR num_d=$search_num";
		break;
	case 'clan':
		if ($search_by == 'Attacker')
			$dbh = "clan_s=$search_clan";
		elseif ($search_by == 'Defender')
			$dbh = "clan_d=$search_clan";
		else	$dbh = "clan_s=$search_clan OR clan_d=$search_clan";
		break;
	}
	$news = db_query("SELECT time,num_s,p1.empire AS name_s,c1.tag AS clan_s,num_d,p2.empire AS name_d,c2.tag AS clan_d,event,data0 FROM $newsdb LEFT JOIN $playerdb AS p1 ON (num_s=p1.num) LEFT JOIN $playerdb AS p2 ON (num_d=p2.num) LEFT JOIN $clandb AS c1 ON (num_s=p1.num and p1.clan=c1.num) LEFT JOIN $clandb AS c2 ON (num_d=p2.num and p2.clan=c2.num) WHERE ($dbh) AND ((event>=202 AND event<=209) OR (event>=302 AND event<=307)) ORDER BY time DESC LIMIT $newslimit;");
?>
<h2><?php echo db_num_rows($news)?> 이벤트 일치:</h2>
<table class="inputtable" style="width:90%">
<tr><th>날짜/시간</th>
    <th>공격자</th>
    <th>방어자</th>
    <th>결과</th></tr>
<?php
	while ($results = db_fetch_array($news))
	{
?>
<tr><td><?php echo gaga_korean_datetime($results['time'])?></td>
    <td><?php echo $results['name_s']?> (#<?php echo $results['num_s']?>)<br>동맹: <?php echo $results['clan_s']?></td>
    <td><?php echo $results['name_d']?> (#<?php echo $results['num_d']?>)<br>동맹: <?php echo $results['clan_d']?></td>
    <td><?php
		$rlevel = floor($results['event'] / 100);
		$rcode = floor($results['event'] % 100);
		$rdata = $results['data0'];

		if ($rlevel == 2)
		{
			print "레벨 $rcode 마법<br>";
			if ($rcode == 9)
				if ($rdata < 0)
					print "실패";
				elseif ($rdata == 0)
					print "방어 견딤";
				else	print "$rdata Acres";
			elseif ($rdata < 0)
				print "실패";
			elseif ($rdata == 0)
				print "보호막";
			else	print "Successful";
		}
		else
		{
			switch($rcode)
			{
			case 2:	print "일반 공격";	break;
			case 3:	print "습격";	break;
			case 4:	print "게릴자전";	break;
			case 5:	print "땅 공격";	break;
			case 6:	print "공중 공격";		break;
			case 7:	print "수중 공격";		break;
			}
			if ($results['data0'] > 0)
				print "<br>$results[data0] 땅";
			else	print "<br>방어 견딤";
		}
?></td></tr>
<tr><td colspan="4"><hr></td></tr>
<?php
	}
?>
</table>
<?php
}
?>
<form method="post" action="<?php echo $config['main']?>?action=news">
<table class="inputtable">
<tr><th class="aleft">검색:</th>
    <td><label><input type="radio" name="search_by" value="Attacker"> 공격자</label> <label><input type="radio" name="search_by" value="Defender"> 방어자</label> <label><input type="radio" name="search_by" value="Either" checked> 상관 없음</label></td></tr>
<tr><th class="aleft"><label><input type="radio" name="search_type" value="num" checked> 번호</label></th>
    <td><input type="text" name="search_num" size="5"></td></tr>
<tr><th class="aleft"><label><input type="radio" name="search_type" value="clan"> 동맹</label></th>
    <td><select name="search_clan" size="1">
        <option value="0">없음 - 비동맹 제국</option>
<?php
$clanlist = db_query("SELECT num,name,tag FROM $clandb ORDER BY num;");
while ($clan = db_fetch_array($clanlist))
{
?>
        <option value="<?php echo $clan['num']?>"><?php echo $clan['tag']?> - <?php echo $clan['name']?></option>
<?php
}
?>
    </select></td></tr>
<tr><td colspan="2" class="acenter"><input type="submit" name="do_search" value="뉴스 검사"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
