<?php
include("header.php");

if ($users['disabled'] != 2)
	TheEnd("You are not an administrator!");

if ($do_modify == 1)
{
	foreach ($modify as $modify_num)
	{
		if ($modify_setmulti)
		{
			print "$modify_num marked as multi!<BR>\n";
			db_query("UPDATE $playerdb SET ismulti=1 WHERE num=$modify_num;");
		}
		if ($modify_clrmulti)
		{
			print "$modify_num no longer marked as multi!<BR>\n";
			db_query("UPDATE $playerdb SET ismulti=0 WHERE num=$modify_num;");
		}
		if ($modify_setdisabled)
		{
			print "$modify_num disabled!<BR>\n";
			db_query("UPDATE $playerdb SET disabled=3 WHERE num=$modify_num;");
		}
		if ($modify_clrdisabled)
		{
			print "$modify_num no longer disabled!<BR>\n";
			db_query("UPDATE $playerdb SET disabled=0,idle=$time WHERE num=$modify_num;");
		}
		if ($modify_admin)
		{
			print "Granting $modify_num administrative privileges!<BR>\n";
			db_query("UPDATE $playerdb SET disabled=2 WHERE num=$modify_num;");
		}
		if ($modify_delete)
		{
			print "Deleting $modify_num!<BR>\n";
			db_query("UPDATE $playerdb SET land=0,disabled=4 WHERE num=$modify_num;");
			$users['kills']++;
		}
	}
	saveUserData($users,"kills");
}

if (!$sortby)
	$sortby = "ip";
$multis = db_query("SELECT num,empire,ip,name,username,email,idle,disabled,turnsused,validated,land,ismulti FROM $playerdb WHERE ip!='0.0.0.0' ORDER BY $sortby, num ASC;");
?>
<form method="post" action="<?php echo $config['main']?>?action=useradmin">
<table>
<tr><th class="aright"><a href="<?php echo $config['main']?>?action=useradmin&amp;sortby=num">Num</a></th>
    <th class="aleft"><a href="<?php echo $config['main']?>?action=useradmin&amp;sortby=empire">Empire</a></th>
    <th class="aright"><a href="<?php echo $config['main']?>?action=useradmin&amp;sortby=ip">IP</a></th>
    <th class="acenter"><a href="<?php echo $config['main']?>?action=useradmin&amp;sortby=name">Name</a></th>
    <th class="acenter"><a href="<?php echo $config['main']?>?action=useradmin&amp;sortby=username">Username</a></th>
    <th class="acenter"><a href="<?php echo $config['main']?>?action=useradmin&amp;sortby=email">E-mail</a></th>
    <th class="aright"><a href="<?php echo $config['main']?>?action=useradmin&amp;sortby=idle">Idle</a></th>
    <th class="aright">Status</th>
    <th class="aright">Modify</th></tr>
<?php
while ($multi = db_fetch_array($multis))
{
	$idle = $time - $multi['idle'];
	if ($multi[$sortby] == $lastsort)
		if ($multi['ismulti'])
			if ($multi['disabled'] == 3)
				print '<tr class="cbad">'."\n";
			else	print '<tr class="cgood">'."\n";
		else	print '<tr class="cwarn">'."\n";
	else	print "<tr>\n";
?>
    <th class="aright"><?php echo $multi['num']?></th>
    <td class="aleft"><?php echo $multi['empire']?></td>
    <td class="aright"><?php echo $multi['ip']?></td>
    <td class="acenter"><?php echo $multi['name']?></td>
    <td class="acenter"><?php echo $multi['username']?></td>
    <td class="acenter"><?php echo $multi['email']?></td>
    <td class="aright"><?php echo gmdate("d",$idle)-1?>:<?php echo gmdate("H:i:s",$idle)?></td>
    <td class="aright"><?php
	switch ($multi['disabled'])
	{
	case 0:	if ($multi['land'] == 0)
			print "Dead (uninformed)";
		elseif ($multi['ismulti'])
			print "Multi (legal)";
		elseif ($multi['validated'])
			print "Normal";
		elseif ($multi['turnsused'] > $config['valturns'])
			print "Unvalidated (uninformed)";
		else	print "New account";
		break;
	case 1:	if ($multi['validated'] == 0)
			print "Unvalidated (informed)";
		elseif ($multi['land'] == 0)
			print "Dead (informed)";
		break;
	case 2:	print "Admin";
		break;
	case 3:	if ($multi['ismulti'])
			print "Multi (disabled)";
		else	print "Cheater";
		break;
	case 4:	print "Deleted";
		break;
	}
?></td>
    <td class="aright"><input type="checkbox" name="modify[]" value="<?php echo $multi['num']?>"<?php if ($multi['num'] == $users['num']) print " disabled";?>></td></tr>
<?php
	
	$lastsort = $multi[$sortby];
}
?>
<tr><th colspan="9" class="aright">
        <input type="hidden" name="do_modify" value="1">
        <input type="hidden" name="sortby" value="<?php echo $sortby?>">
        Multi: <input type="submit" name="modify_setmulti" value="Set">/<input type="submit" name="modify_clrmulti" value="Clr"><br>
        Disabled: <input type="submit" name="modify_setdisabled" value="Set">/<input type="submit" name="modify_clrdisabled" value="Clr"><br>
        Delete Account: <input type="submit" name="modify_delete" value="NUKE"><br>
        Make Admin (Clr Disabled to undo): <input type="submit" name="modify_admin" value="ADMIN"></th></tr>
</table>
</form>
<?php
HTMLendfull();
?>
