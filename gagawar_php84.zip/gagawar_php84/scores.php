<?php
include("header.php");
?>
<b>가가전쟁 점수 순위</b><br>
현재 게임 시각: <?php echo $datetime?><br><br>
<b><?php echo sqleval("SELECT COUNT(*) FROM $playerdb WHERE online=1;")?></b> 의 사용자가 현재 접속중입니다. 총 <b><?php echo sqleval("SELECT COUNT(*) FROM $playerdb;")?></b> 의 사용자가 존재합니다.<br>
<b><?php echo $killed=sqleval("SELECT SUM(kills) FROM $playerdb;")?></b> 제국이 멸망했습니다, <b><?php echo sqleval("SELECT COUNT(*) FROM $playerdb WHERE land=0;")-$killed?></b> 개의 제국이 버림받았습니다.<br>
<b><?php echo sqleval("SELECT COUNT(*) FROM $playerdb WHERE disabled=3;")?></b> 계정이 관리자에 의해 정지당했습니다.<br>
<table class="scorestable">
<?php
$start = $users['rank'] - 15;
if ($start < 10)
	$start = 10;

for ($topten = 0; $topten < 2; $topten++)	// why duplicate the code when we can use it twice?
{
	if ($topten == 0)
		$limit = "10";
	else	$limit = "$start,30";
	$scores = db_query("SELECT rank,empire,num,land,networth,clan,race,era,online,disabled,turnsused,vacation,kills FROM $playerdb ORDER BY rank ASC LIMIT $limit;");
	if (db_num_rows($scores) == 0) break;
	printScoreHeader($users['era']);
	while ($enemy = db_fetch_array($scores))
		printScoreLine();
}
printScoreHeader($users['era']);
?>
</table>
<?php
TheEnd("");
?>
