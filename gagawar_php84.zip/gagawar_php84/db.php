<?php
// PHP 8.4 mysqli database helpers converted from legacy mysql_* usage.
if (!isset($GLOBALS['db_link'])) { $GLOBALS['db_link'] = null; }
function db_connect($host, $user, $pass) { $GLOBALS['db_link'] = @mysqli_connect($host, $user, $pass); if ($GLOBALS['db_link']) { @mysqli_set_charset($GLOBALS['db_link'], 'utf8'); } return $GLOBALS['db_link']; }
function db_select_db($dbname, $link = null) { if (!$link) $link = $GLOBALS['db_link']; return @mysqli_select_db($link, $dbname); }
function db_query($query, $link = null) { if (!$link) $link = $GLOBALS['db_link']; return @mysqli_query($link, $query); }
function db_fetch_array($result) { if (!$result) return false; return @mysqli_fetch_array($result); }
function db_fetch_assoc($result) { if (!$result) return false; return @mysqli_fetch_assoc($result); }
function db_fetch_row($result) { if (!$result) return false; return @mysqli_fetch_row($result); }
function db_num_rows($result) { if (!$result) return 0; return @mysqli_num_rows($result); }
function db_insert_id($link = null) { if (!$link) $link = $GLOBALS['db_link']; return @mysqli_insert_id($link); }
function db_escape($string, $link = null) { if (!$link) $link = $GLOBALS['db_link']; return @mysqli_real_escape_string($link, $string); }
function db_error($link = null) { if (!$link) $link = $GLOBALS['db_link']; return @mysqli_error($link); }
function db_close($link = null) { if (!$link) $link = $GLOBALS['db_link']; return @mysqli_close($link); }
function db_result($result, $row = 0, $field = 0) { if (!$result) return false; @mysqli_data_seek($result, $row); $data = @mysqli_fetch_array($result); if ($data === null || $data === false) return false; return isset($data[$field]) ? $data[$field] : false; }
?>
