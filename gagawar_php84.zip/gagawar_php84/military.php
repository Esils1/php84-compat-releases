<?php

/* Military.php
 * (c) Morvandium and Quietust
 * Last Revision: January 23 by zEro
 * Major Changes: Added compatibility code for Clans
 */

include("header.php");
include("magicfun.php");
$atknames['Standard'] = "일반 공격";
$atknames['Surprise'] = "습격";
$atknames['armtrp'] = "게릴라전";
$atknames['lndtrp'] = "땅 공격";
$atknames['flytrp'] = "공중 공격";
$atknames['seatrp'] = "수중 공격";

// era of troops, quantity of troops, type of troops, offense or defense
function CalcPoints($era, $quantity, $ttype, $atype)
{
	$type = $atype."_".$ttype;
	return $quantity * $era[$type];
}

function ClanCheck()  //  Need to set warflag and netmult
{
	global $warflag, $netmult, $users, $uclan, $enemy;
	if ($users['clan'] == $enemy['clan'])
		TheEnd("당신은 같은 동맹에 있는 제국을 공격할 수 없습니다!");
	if (($uclan['ally1'] == $enemy['clan']) || ($uclan['ally2'] == $enemy['clan']) || ($uclan['ally3'] == $enemy['clan']))
		TheEnd("동맹을 공격하고자하는 당신의 의도를 제국의 장군들이 그냥 무시합니다.");
	if (($uclan['war1'] == $enemy['clan']) || ($uclan['war2'] == $enemy['clan']) || ($uclan['war3'] == $enemy['clan']))
	{
		$warflag = 1.2;
		$netmult = 50;
	}
}



function ReadInput ($type)
{
	global $users, $usent, $enemy, $esent, $sendall, $trplst;
	
	for ($i = 0; $i < 4; $i++)
	{
		$trp = $trplst[$i];
		$esent[$trp] = $enemy[$trp];
		if ($enemy['forces'] > 0)			// if enemy shares forces, he can't use them for defense
			$esent[$trp] *= 0.9;
		if ($sendall)				// send everything?
			$usent[$trp] = $users[$trp];
	}

	if (($type != 'Standard') && ($type != 'Surprise'))
	{
		for ($i = 0; $i < 4; $i++)
		{
			$trp = $trplst[$i];
			if ($type != $trp)
			{
				$usent[$trp] = 0;
				$esent[$trp] = 0;
			}
		}
	}
	for ($i = 0; $i < 4; $i++)
		CheckQuantity($trplst[$i]);
}

function CheckQuantity($type)
{
	global $users, $uera, $usent;
	fixInputNum($usent[$type]);
	$esent[$type] = round($esent[$type]);
	if ($usent[$type] < 0)
		TheEnd("0 이하의 군사로 공격할 수 없습니다!");
	if ($usent[$type] > $users[$type])
		TheEnd("$uera[$type]를 그렇게 많이 가지고 있지 않습니다!");
}

function Attack($type)
{
	global $users, $uera, $usent, $enemy, $eera, $esent, $playerdb, $datetime, $time, $trplst, $warflag;
	$uoffense = 0;
	$edefense = 0;
	for ($i = 0; $i < 4; $i++)
	{
		$uoffense += CalcPoints($uera,$usent[$trplst[$i]],$trplst[$i],'o');
		$edefense += CalcPoints($eera,$esent[$trplst[$i]],$trplst[$i],'d');
	}
	if ($uoffense == 0)
		TheEnd("공격할 군대가 있어야합니다!");

	$uoffense *= $users['health'] / 100;
	$edefense *= $enemy['health'] / 100;
	if ($warflag)
		$uoffense *= 1.2;

	if ($users['era'] != $enemy['era'])			// only step through time gate if necessary
	{
		if ($users['gate'] > $time)		// your time gate?
			print "당신의 시간의 문을 통과합니다..<br>\n";
		elseif ($enemy['gate'] > $time)		// or enemy's time gate?
			print "적의 시간의 문을 통과합니다..<br>\n";
	}

	if ($type == "Surprise")			// surprise attack?
	{
		$offpts *= 1.25;
		$helping = 0;
		$users['health'] -= 5;
	}
	elseif (($enemy['clan']) && ($enemy['forces'] == 1))	// enemy has allies and sharing forces?
	{
		$dbally = db_query("SELECT armtrp,lndtrp,flytrp,seatrp,num,era,race,clan,gate FROM $playerdb WHERE clan=$enemy[clan] AND forces>0 AND num!=$enemy[num] AND land>0;");
		$helping = db_num_rows($dbally);
	}
	if ($helping)					// add up allies
	{
		print "$helping 이 당신의 적을 도우러 갑니다..<br>\n";
		$emaxdefense = $edefense * 2;
		while ($ally = db_fetch_array($dbally))
		{
			$ad = 0;
			if (($enemy['gate'] > $time) || ($ally['gate'] > $time) || ($enemy['era'] == $ally['era']))
			{						// defense is limited to eras as well
				addNews(300,$users,$ally,$enemy['num']);
				$arace = loadRace($ally['race']);		// adjust according to ally race
				$aera = loadEra($ally['era']);		// and era

				for($i = 0; $i < 4; $i++)
					$ad += allyHelp($trplst[$i],$helping) * ($ally['health'] / 100);

				$ad = round($ad * $arace['defense']);
				$edefense += $ad;
			}
		}
		if ($edefense > $emaxdefense)				// limit ally defense
			$edefense = $emaxdefense;
	}
	$tdefense = $enemy['towers'] * 500 * min(1,$enemy['armtrp'] / (100*$users['towers']+1));   // and add in towers
	$edefense += $tdefense;
//!!!	if ($warflag == 0)						// war == infinite attacks
//!!!		$enemy[attacks]++;
	dobattle($uoffense,$edefense,$type,$tdefense);
}

function AllyHelp ($type, $numallies)
{
	global $enemy, $esent, $ally, $aera;
	$amt = round($ally[$type] * .1);
	if ($amt > $esent[$type] / $numallies)
		$amt = $esent[$type] / $numallies;
	return CalcPoints($aera,$amt,$type,'d');
}



/*
dobattle(Offense_Points, Defense_Points, Attack_Type)
This function:
determines who won
calls detloss() to determine troop losses
calls dealland() if attack was successful
*/
function dobattle ($op, $dp, $type, $towp)
{
	$emod = sqrt($op/($dp+1));		// modification to enemy losses
	$umod = sqrt(($dp-$towp)/($op+1));		// modification to attacker losses (towers not include)
	switch ($type)
	{
	case 'armtrp':
		detloss(.1155, .0705, $umod, $emod, 'armtrp');
		break;

	case 'lndtrp':
		detloss(.0985, .0530, $umod, $emod, 'lndtrp');
		break;

	case 'flytrp':
		detloss(.0688, .0445, $umod, $emod, 'flytrp');
		break;

	case 'seatrp':
		detloss(.0450, .0355, $umod, $emod, 'seatrp');
		break;
   
	case 'Surprise':
		$umod *= 1.2;			// fall through

	case 'Standard':
		detloss(.1455, .0805, $umod, $emod, 'armtrp');
		detloss(.1285, .0730, $umod, $emod, 'lndtrp');
		detloss(.0788, .0675, $umod, $emod, 'flytrp');
		detloss(.0650, .0555, $umod, $emod, 'seatrp');
		break;
	}
	if($op > $dp * 1.05)
	{
		dealland($type);
	}
	printedreport();
}

// New code by Morvandium

/*
This function determines the loss of specific types of troops
It handles the attacker and defender in one run through
*/
function detloss($uper, $eper, $umod, $emod, $type)
{
	global $uloss, $eloss, $usent, $esent;
	if ($usent[$type] > 0)		// can't lose more than you send... send none, lose none
		$uloss[$type] = min(mt_rand(0,(ceil($usent[$type] * $uper * $umod)+1)), $usent[$type]);
	else	$uloss[$type] = 0;
	if ($uloss[$type] > $usent[$type])
		$uloss[$type] = $usent[$type];	// you can't lose more than you sent

	$maxkill = round(.9*$usent[$type]) + mt_rand(0, round(.2*$usent[$type] + 1)); // max kills determination (90% - 110%)

	if ($esent[$type] > 0)		// he can't lose more than he defended with, or attacker can kill
		$eloss[$type] = min(mt_rand(0,ceil($esent[$type] * $eper * $emod)), $esent[$type], $maxkill);
	else	$eloss[$type] = 0;	// no troops, no losses
}

// End of new code

function LossCalc(&$player, &$ploss)
{
	global $trplst;
	for ($i = 0; $i < 4; $i++)
		$player[$trplst[$i]] -= $ploss[$trplst[$i]];
}

function DealLand($type)
{
	global $landloss, $buildgain, $enemy, $users;

	// destroy structures
	destroyBuildings('homes',7,70,$type);
	destroyBuildings('shops',7,70,$type);
	destroyBuildings('industry',7,50,$type);
	destroyBuildings('barracks',7,70,$type);
	destroyBuildings('labs',7,60,$type);
	destroyBuildings('farms',7,30,$type);
	destroyBuildings('towers',7,60,$type);
	destroyBuildings('mines',7,50,$type);
	destroyBuildings('banks',7,50,$type);
	destroyBuildings('freeland',10,0,$type);	// 3rd argument MUST be 0 - calculate gained freeland below
	$users['freeland'] += $landloss + $buildgain;

	// update total land counts
	$users['land'] += $landloss;
	$enemy['land'] -= $landloss;
}

// To handle destroying buildings during successful attacks
function destroyBuildings ($type, $pcloss, $pcgain, $atktype)
{
	global $landloss, $buildgain, $enemy, $users;
	$pcloss /= 100;
	$pcgain /= 100;

	if (($atktype == 'lndtrp') || ($atktype == 'flytrp') || ($atktype == 'seatrp'))
	{				// these attacks destroy extra buildings, but fewer are gained
		if ($atktype == 'flytrp')
		{
			$pcloss *= 1.25;
			$pcgain *= 0.72;
		}
		elseif (($type == 'towers') || ($type == 'labs'))
		{
			$pcloss *= 1.3;
			$pcgain *= 9/13;
		}
		else	$pcgain *= 0.9;
	}

	if ($enemy[$type] > 0)
		$loss = mt_rand(1,ceil($enemy[$type] * $pcloss + 2));
	if ($loss > $enemy[$type])
		$loss = $enemy[$type];
	$gain = ceil($loss * $pcgain);

	$enemy[$type] -= $loss;
	$landloss += $loss;
	if ($atktype == 'Standard')	// only gain buildings with standard attack
	{
		$users[$type] += $gain;
		$buildgain += $gain;
	}
}

function printedreport()
{
	global $users, $uloss, $uera, $enemy, $eloss, $eera, $landloss, $buildgain, $trplst;
	if ($landloss)
		print "당신의 군대는 $enemy[empire] 의 방어를 뚫고 땅 $landloss 을 뺏습니다!  전쟁에서 당신은 다음의 손상을 받습니다:<br>\n";
	else	print "힘든 전투 끝에, 당신의 군대는 $enemy[empire] 의 방어선을 뚫지 못했습니다.  이 시도 당신은 다음의 손상을 받습니다:<br>\n";
	for ($i = 0; $i < 4; $i++)
	{
		$trp = $trplst[$i];
		if ($uloss[$trp]) print commas($uloss[$trp])." $uera[$trp]<br>\n";
	}
	print "방어에서 $enemy[empire] 제국은 다음의 손상을 받았습니다:<br>\n";
	for ($i = 0; $i < 4; $i++)
	{
		$trp = $trplst[$i];
		if ($eloss[$trp]) print commas($eloss[$trp])." $eera[$trp]<br>\n";
	}
	if ($buildgain)
		print "당신은 또한 $buildgain 건물을 뺏었습니다!<br>\n";
	if (($enemy['land'] == 0) || ($enemy['land'] < 0))
	{
?><span class="cgood"><b><?php echo $enemy['empire']?> (#<?php echo $enemy['num']?>)</b> 제국을 명망 시켰습니다!</span><br>
<?php 		$users['kills']++;
	}
}

// To print the attack table
function printRow ($type)
{
	global $users, $uera;
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($users[$type])?></td>
    <td class="aright"><input type="text" name="usent[<?php echo $type?>]" size="8" value="0"></td></tr>
<?php
}

// *************
// End Functions
// *************

if ($users['turnsused'] <= $config['protection'])	// are they under protection?
	TheEnd("보호 받고 있는 동안 공격을 할 수 없습니다!");
if ($users['disabled'] == 2)			// are they admin?
	TheEnd("Administrative accounts cannot use offensive actions!");

if ($do_attack)
{

// Turns Hack - According to Race!
// Changed to be used on the db

	if ($users['turns'] < $urace['turns'])
		TheEnd("턴이 부족합니다!");

	if (!$target)							// specified target?
		TheEnd("목표물을 지정해야합니다!");
	if ($target == $users['num'])					// attacking self?
		TheEnd("자기 자신을 공격할 수 없습니다!");
	if ($users['health'] <= 20)
		TheEnd("당신은 공격할 충분한 건강이 없습니다.");
	$enemy = loadUser($target);
	$erace = loadRace($enemy['race']);
	$eera = loadEra($enemy['era']);					// load enemy info

	if (($enemy['land'] == 0) || ($enemy['land'] < 0))
		TheEnd("그 제국은 이미 멸망했씁니다!");
	if (($enemy['era'] != $users['era']) && ($users['gate'] <= $time) && ($enemy['gate'] <= $time))
		TheEnd("시간의 문을 먼저 열어야합니다!");
	if ($enemy['disabled'] >= 2)
		TheEnd("정지당한 제국을 공격할 수 없습니다!");
	if ($enemy['turnsused'] <= $config['protection'])
		TheEnd("신규 제국 보호를 받고 있는 제국을 공격할 수 없습니다!");
	if ($enemy['vacation'] > $config['vacationdelay'])
		TheEnd("여행 모드로 설정된 제국을 공격할 수 없습니다!");
	$warflag = 0;
	$netmult = 20;

	$uclan = loadClan($users['clan']);

//	if ($enemy[networth] > $users[networth] * 50)
	if ($enemy['networth'] > $users['networth'] * $config['nonattack'])
		TheEnd("당신의 장군들은 그렇게 강한 상대를 공격할 것을 거부합니다!");
//	if ($users[networth] > $enemy[networth] * 50)
	if ($users['networth'] > $enemy['networth'] * $config['nonattack'])
		TheEnd("당신의 장군들은 그렇게 약한 상대를 공격할 것을 거부합니다!");

	if ($enemy['clan'])
		ClanCheck();
 
	if ($warflag == 0)
	{
//!!!S
		if ($enemy['attacks'] > 2)
//!!!E
			TheEnd("그 제국은 너무 많은 공격을 받았습니다. 6 분 이후에 다시 시도하시길 바랍니다.");
		$revolt = 1;
//!!!S
		$enemy['attacks']++;
//!!!E
		if ($users['networth'] > $enemy['networth'] * $config['shamemult'])
		{						// Shame is less powerful than fear

?><span class="cwarn">당신의 군대는 너무 약한 상대를 공격한 것에 대해 경악합니다. 많은 자들이 떠나갑니다!</span><br>
<?php 			$revolt = 1 - $users['networth'] / $enemy['networth'] / 125;
		}
		elseif ($enemy['networth'] > $users['networth'] * $config['shamemult'])
		{
?><span class="cwarn">당신의 군대는 너무 강한 상대를 공격한 것에 대해 겁에 질립니다. 많은 자들이 떠나갑니다!</span><br>
<?php 			$revolt = 1 - $enemy['networth'] / $users['networth'] / 100;
		}
		if ($revolt < .9)
			$revolt = .9;
		for ($i = 0; $i < 4; $i++)
			$users[$trplst[$i]] = round($users[$trplst[$i]] * $revolt);
	}
	readInput($attacktype);

	Attack($attacktype);

	// record losses

	losscalc($users, $uloss);
	losscalc($enemy, $eloss);

	if (!$landloss)
		$landloss = 0;
	switch ($attacktype)
	{
	case 'Standard':addNews(302,$users,$enemy,$landloss,$eloss['armtrp'],$eloss['lndtrp'],$eloss['flytrp'],$eloss['seatrp'],$uloss['armtrp'],$uloss['lndtrp'],$uloss['flytrp'],$uloss['seatrp']);	break;
	case 'Surprise':addNews(303,$users,$enemy,$landloss,$eloss['armtrp'],$eloss['lndtrp'],$eloss['flytrp'],$eloss['seatrp'],$uloss['armtrp'],$uloss['lndtrp'],$uloss['flytrp'],$uloss['seatrp']);	break;
	case 'armtrp':	addNews(304,$users,$enemy,$landloss,$eloss['armtrp'],$uloss['armtrp']);	break;
	case 'lndtrp':	addNews(305,$users,$enemy,$landloss,$eloss['lndtrp'],$uloss['lndtrp']);	break;
	case 'flytrp':	addNews(306,$users,$enemy,$landloss,$eloss['flytrp'],$uloss['flytrp']);	break;
	case 'seatrp':	addNews(307,$users,$enemy,$landloss,$eloss['seatrp'],$uloss['seatrp']);	break;
	}
	if (($enemy['land'] == 0) || ($enemy['land'] < 0))
		addNews(301,$users,$enemy,0);

	$users['attacks'] -= 1;
	if ($users['attacks'] < 0)
		$users['attacks'] = 0;
	$users['offtotal']++;
	if ($landloss)
		$users['offsucc']++;
	else	$enemy['defsucc']++;
	$enemy['deftotal']++;
	$users['health'] -= mt_rand(3,8);
	//!!!S
	saveUserDataNet($users,"networth armtrp lndtrp flytrp seatrp land homes shops industry barracks labs farms towers freeland offsucc offtotal kills health mines banks attacks");
	saveUserDataNet($enemy,"networth armtrp lndtrp flytrp seatrp land homes shops industry barracks labs farms towers freeland defsucc deftotal mines banks attacks");
	//!!!E
	// 4th turn hack
	takeTurns($urace['turns'],'attack');

}
?>
<form method="post" action="<?php echo $config['main']?>?action=military">
<table class="inputtable">
<tr><td colspan="3" class="acenter">공격할 제국 번호는? <input type="text" name="target" size="5"></td></tr>
<tr><td colspan="3" class="acenter">공격 방식: <select name="attacktype" size="1">
        <option value="Standard"><?php echo $atknames['Standard']?></option>
        <option value="Surprise"><?php echo $atknames['Surprise']?> (동맹 지원 없음)</option>
        <option value="armtrp"><?php echo $atknames['armtrp']?></option>
        <option value="lndtrp"><?php echo $atknames['lndtrp']?></option>
        <option value="flytrp"><?php echo $atknames['flytrp']?></option>
        <option value="seatrp"><?php echo $atknames['seatrp']?></option>
        </select></td></tr>
<tr><th class="aleft">유닛</th>
    <th class="aright">소유</th>
    <th class="aright">보내기</th></tr>
<?php
for($i = 0; $i < 4; $i++)
	printRow($trplst[$i]);
?>
<tr><td colspan="3" class="acenter"><input type="checkbox" name="sendall" value="1">모두 보내기</td></tr>
<tr><td colspan="3" class="acenter"><input type="submit" name="do_attack" value="공격하기"></td></tr>
</table>
</form>
<hr>
<form method="post" action="<?php echo $config['main']?>?action=military">
<table class="inputtable">
<tr><td class="acenter">마법을 걸 제국? <input type="text" name="target" size="5"></td></tr>
<tr><td><select name="spell_num" size="1">
        <option value="0">마법 선택하기</option>
<?php
for ($i = 1; $i <= 12; $i++)
	if ($sptype[$i] == 'o')

		printMRow($i);
	


?>
        </select></td></tr>
<tr><td class="acenter"><input type="submit" name="do_spell" value="마법 걸기"></td></tr>
</table>
</form>
<?php
if ($users['shield'] > $time)
	print "<i>우리는 현재 마법에 대한 방어막을 가지고 있습니다. 앞으로 ".round(($users['shield']-$time)/3600,1)." 시간 동안 더 유지될 것입니다.</i><br>\n";
print "<i>우리 군사와 민간인의 건강은 현재 $users[health]% 입니다!</i><br>\n";
if ($users['gate'] > $time)
	print "<i>우리는 현재 시간의 문을 열어놨습니다. 앞으로 ".round(($users['gate']-$time)/3600,1)." 시간 동안 더 열려 있을 것입니다.</i><br>\n";
TheEnd("");
?>
