<?php
include("header.php");

$offpts = ($users['armtrp'] * $uera['o_armtrp']) + ($users['lndtrp'] * $uera['o_lndtrp']) + ($users['flytrp'] * $uera['o_flytrp']) + ($users['seatrp'] * $uera['o_seatrp']);
$defpts = ($users['armtrp'] * $uera['d_armtrp']) + ($users['lndtrp'] * $uera['d_lndtrp']) + ($users['flytrp'] * $uera['d_flytrp']) + ($users['seatrp'] * $uera['d_seatrp']);

$offpts = round($offpts * $urace['offense']);
$defpts = round(($defpts + ($users['towers'] * 500)) * $urace['defense']);
$size = calcSizeBonus($users['networth']);

$foodpro = round((5 * $users['freeland']) + ($users['farms'] * 75) * $urace['farms']);
$foodcon = round((($users['armtrp'] * .05) + ($users['lndtrp'] * .03) + ($users['flytrp'] * .02) + ($users['seatrp'] * .01) + ($users['peasants'] * .01) + ($users['wizards'] * .25)) * $urace['food']);
$foodnet = $foodpro - $foodcon;

$income = round(((pci($users,$urace) * ($users['tax'] / 100) * ($users['health'] / 100) * $users['peasants']) + ($users['shops'] * 500)) / $size);
$loanpayment = round($users['loan'] / 200);
$expenses = round(($users['armtrp'] * 1) + ($users['lndtrp'] * 2.5) + ($users['flytrp'] * 4) + ($users['seatrp'] * 7) + ($users['land'] * 8));
$expbonus = round($expenses * ($urace['costs'] - ($users['barracks'] / $users['land'])));
if ($expbonus > $expenses / 2)				// expenses bonus limit
	$expbonus = round($expenses / 2);
$expenses -= $expbonus;
$netincome = $income - $expenses;

$ironpro = round(($users['freeland'] * 5) + ($users['mines'] * 35));
$ironcon = round(($users['armtrp'] * .03) + ($users['seatrp'] * .01) + ($users['peasants'] * .01) + ($users['flytrp'] * .02));
$netiron = $ironpro - $ironcon;

$savrate = $config['savebase'] - $size;
$loanrate = $config['loanbase'] + $size;
?>
<table style="width:100%">
<tr><th colspan="3" class="e<?php echo $users['era']?>"><?php echo $users['empire']?> (#<?php echo $users['num']?>)</th></tr>
<tr><td style="vertical-align:top;width:33%">
        <table class="empstatus" style="width:100%">
        <tr><th colspan="2" class="era<?php echo $users['era']?>" style="text-align:center">제국</th></tr>
        <tr><th>돈:</th>
            <td>$<?php echo commas($users['cash'])?></td></tr>
        <tr><th>총 재산:</th>
            <td>$<?php echo commas($users['networth'])?></td></tr>
        <tr><th>인구:</th>
            <td><?php echo commas($users['peasants'])?></td></tr>
        <tr><th>종족:</th>
            <td><?php echo $urace['name']?></td></tr>
        <tr><th>시대:</th>
            <td><?php echo $uera['name']?></td></tr>
        </table>
    </td>
    <td style="vertical-align:top;width:33%">
        <table class="empstatus" style="width:100%">
        <tr><th colspan="2" class="era<?php echo $users['era']?>" style="text-align:center">농업</th></tr>
        <tr><th>예상 생산량:</th>
            <td><?php echo commas($foodpro)?></td></tr>
        <tr><th>예상 소비량:</th>
            <td><?php echo commas($foodcon)?></td></tr>
        <tr><th>총:</th>
            <td><?php printCNum($foodnet,"",0);?></td></tr>
        </table>
        <table class="empstatus" style="width:100%">
        <tr><th colspan="2" class="era<?php echo $users['era']?>" style="text-align:center">철 산업</th></tr>
        <tr><th>예상 생산량:</th>
            <td><?php echo commas($ironpro)?></td></tr>
        <tr><th>예상 소비량:</th>
            <td><?php echo commas($ironcon)?></td></tr>
        <tr><th>총:</th>
            <td><?php printCNum($netiron,"",0);?></td></tr>
        </table>
    </td>
    <td style="vertical-align:top;width:33%">
        <table class="empstatus" style="width:100%">
        <tr><th colspan="2" class="era<?php echo $users['era']?>" style="text-align:center">상태</th></tr>
        <tr><th>사용된 턴:</th>
            <td><?php echo commas($users['turnsused'])?></td></tr>
        <tr><th>순위:</th>
            <td>#<?php echo $users['rank']?></td></tr>
        <tr><th>공격행위:</th>
            <td><?php echo $users['offtotal']?> (<?php if ($users['offtotal']) echo round($users['offsucc']/$users['offtotal']*100); else echo 0;?>%)</td></tr>
        <tr><th>방어행위:</th>
            <td><?php echo $users['deftotal']?> (<?php if ($users['deftotal']) echo round($users['defsucc']/$users['deftotal']*100); else echo 0;?>%)</td></tr>
        <tr><th>킬(KILL):</th>
            <td><?php echo $users['kills']?></td></tr>
        </table>
    </td>
</tr>
<tr><td style="vertical-align:top;width:33%">
        <table class="empstatus" style="width:100%">
        <tr><th colspan="2" class="era<?php echo $users['era']?>" style="text-align:center">땅</th></tr>
        <tr><th><?php echo $uera['shops']?>:</th>
            <td><?php echo commas($users['shops'])?></td></tr>
        <tr><th><?php echo $uera['homes']?>:</th>
            <td><?php echo commas($users['homes'])?></td></tr>
        <tr><th><?php echo $uera['industry']?>:</th>
            <td><?php echo commas($users['industry'])?></td></tr>
        <tr><th><?php echo $uera['barracks']?>:</th>
            <td><?php echo commas($users['barracks'])?></td></tr>
        <tr><th><?php echo $uera['labs']?>:</th>
            <td><?php echo commas($users['labs'])?></td></tr>
        <tr><th><?php echo $uera['farms']?>:</th>
            <td><?php echo commas($users['farms'])?></td></tr>
        <tr><th><?php echo $uera['towers']?>:</th>
            <td><?php echo commas($users['towers'])?></td></tr>
        <tr><th><?php echo $uera['banks']?>:</th>
            <td><?php echo commas($users['banks'])?></td></tr>
        <tr><th><?php echo $uera['mines']?>:</th>
            <td><?php echo commas($users['mines'])?></td></tr>
        <tr><th>미사용 땅:</th>
            <td><?php echo commas($users['freeland'])?></td></tr>
        </table>
    </td>
    <td style="vertical-align:top;width:33%">
        <table class="empstatus" style="width:100%">
        <tr><th colspan="2" class="era<?php echo $users['era']?>" style="text-align:center">재정</th></tr>
        <tr><th>예상 수입:</th>
            <td>$<?php echo commas($income)?></td></tr>
        <tr><th>예상 소비:</th>
            <td>$<?php echo commas($expenses)?></td></tr>
        <tr><th>총:</th>
            <td><?php printCNum($netincome,"$",0);?></td></tr>
        <tr><th>대출 상환:</th>
            <td>$<?php echo commas($loanpayment)?></td></tr>
        <tr><th>인구당 수입:</th>
            <td>$<?php echo pci($users,$urace)?></td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><th>저금:</th>
            <td>$<?php echo commas($users['savings'])?> (<?php echo $savrate?>%)</td></tr>
        <tr><th>대출:</th>
            <td>$<?php echo commas($users['loan'])?> (<?php echo $loanrate?>%)</td></tr>
        </table>
    </td>
    <td style="vertical-align:top;width:33%">
        <table class="empstatus" style="width:100%">
        <tr><th colspan="2" class="era<?php echo $users['era']?>" style="text-align:center">군사</th></tr>
        <tr><th><?php echo $uera['armtrp']?>:</th>
            <td><?php echo commas($users['armtrp'])?></td></tr>
        <tr><th><?php echo $uera['lndtrp']?>:</th>
            <td><?php echo commas($users['lndtrp'])?></td></tr>
        <tr><th><?php echo $uera['flytrp']?>:</th>
            <td><?php echo commas($users['flytrp'])?></td></tr>
        <tr><th><?php echo $uera['seatrp']?>:</th>
            <td><?php echo commas($users['seatrp'])?></td></tr>
        <tr><th><?php echo $uera['wizards']?>:</th>
            <td><?php echo commas($users['wizards'])?></td>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><th>공격 점수:</th>
            <td><?php echo commas($offpts)?></td></tr>
        <tr><th>방어 점수:</th>
            <td><?php echo commas($defpts)?></td></tr>
        </table>
    </td>
</tr>
</table>
<?php
TheEnd("");
?>
