<?php
// 쳉耿껐
class Item {
	var $item;

	var $base,$refine;
	var $option0,$option1,$option2;

	var $type;

	function __construct($no) {
		$this->Item($no);
	}

	function Item($no) {
		mt_srand();
		$this->SetItem($no);
	}
//////////////////////////////////////////////////
//	ⅱⅳΖ?ㄼ턴ㅅㅼㅏ얠밭Η【?ㆂ뀝일ㅉㅻ?
	function SetItem($no) {
		if(!$no) return false;
		$this->item	= $no;

		$this->base	= substr($no,0,4);//ⅱⅳΖ?ㅞ댑居휘방
		// 은句촐
		$this->refine	= (int)substr($no,4,2);
		if(!$this->refine)
			$this->refine	= 0;
		// 꼴퓰卦
		$this->option0	= substr($no,6,3);
		$this->option1	= substr($no,9,3);
		$this->option2	= substr($no,12,3);

		if($item = LoadItemData($this->base)) {
			$this->type	= $item["type"];
		}
	}
//////////////////////////////////////////////////
//	ⅱⅳΖ?ㆂ음븜ㅉㅻ。
	function CreateItem() {
		$this->refine	= false;
		$this->option0	= false;
		$this->option1	= false;
		$this->option2	= false;
		list($low,$high)	= ItemAbilityPossibility($this->type);

		// 2:3:4
		// 꼴퓰卦ㄼㅔㄿ널顆。
		$prob	= mt_rand(1,9);
		switch($prob) {
			case 1:
			case 2:
			case 3:
				$AddLow	= true;
				break;
			case 4:
			case 5:
			case 6:
				$AddHigh	= true;
				break;
			case 7:
			case 8:
			case 9:
				$AddLow	= true;
				$AddHigh	= true;
				break;
		}

		// array_rand() ㅟ힌覡ㅚㅞㅗ령깖ㅉㅻ。

		if($AddHigh) {
			$prob	= mt_rand(0,count($high)-1);
			$this->option1	= $high["$prob"];
		}
		if($AddLow) {
			$prob	= mt_rand(0,count($low)-1);
			$this->option2	= $low["$prob"];
		}
	}
//////////////////////////////////////////////////
//	팅쇱ㅚㄲㅼ­3휘涇ㅞ꼴­
	function AddSpecial($opt) {
		$this->option0	= $opt;
	}
//////////////////////////////////////////////////
//	은句꼼퓰ㅚ嫁ㄻㅙㄶㄻ。
	function CanRefine() {
		$possible	= CanRefineType();
		if (REFINE_LIMIT <= $this->refine)
			return false;
		else if(in_array($this->type,$possible))
			return true;
		else
			return false;
	}
//////////////////////////////////////////////////
//	은句ㆂㅉㅻ
	function ItemRefine() {
		if($this->RefineProb($this->refine)) {
			print("+".$this->refine." -> ");
			$this->refine++;
			print("+".$this->refine." <span class=\"recover\">성공</span>&nbsp;!<br />\n");
			return true;
		} else {
			print("+".$this->refine." -> ");
			print("+".($this->refine + 1)." <span class=\"dmg\">실패</span>.<br />\n");
			return false;
		}
	}
//////////////////////////////////////////////////
//	은句텐奸ㅛ은句윙몽ㄻ휭ㄻㅘㅍㅞ널顆
	function RefineProb($now) {
		$prob	= mt_rand(0,99);
		//return true;// ⅣατΘ쇠ㅻㅘ윙몽顆100%
		switch($now) {
			case 0:
			case 1:
			case 2:
			case 3:
				return true;
			case 4:
				if($prob < 75)
				return true;
			case 5:
				if($prob < 75)
				return true;
			case 6:
				if($prob < 70)
				return true;
			case 7:
				if($prob < 60)
				return true;
			case 8:
				if($prob < 50)
				return true;
			case 9:
				if($prob < 50)
				return true;
		}
		return false;
	}
//////////////////////////////////////////////////
//	ⅱⅳΖ?ㆂ癎ㅉ。
	function ReturnItem() {
		// 은句ㅲⅹΨⅧητㅲ絹ㄴ얠밭ㅟ잭튬4訶샙ㅐㅁ癎ㅉ。
		if(!$this->refine && !$this->option0 && !$this->option1 && !$this->option2 )
			return $this->base;
		
		// 쒸ㅚㄿㅘㅲ은句ㅅㅼㅖㄴㅻㄻ、ⅹΨⅧητㄼ階ㅻ얠밭
		$item	= $this->base.
				sprintf("%02d",$this->refine).
				$this->option0.
				$this->option1.
				$this->option2;
		return $item;
	}
}
?>
