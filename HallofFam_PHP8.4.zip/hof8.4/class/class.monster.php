<?php 
include_once("class.char.php");
class monster extends char{

	// βτⅩ?【잽錮ㅞ揀웃
	var $monster = true;
	var $exphold;//론립촐
	var $moneyhold;//ㄺ뜯
	var $itemdrop;//孔ㅘㅉⅱⅳΖ?
	var $summon;
//////////////////////////////////////////////////
//	
	function __construct($data) {
		$this->monster($data);
	}

//////////////////////////////////////////////////
//	
	function monster($data) {
		$this->SetCharData($data);

	}
//////////////////////////////////////////////////
//	?γιΗ【?ㅞ艮쨍
	function SaveCharData($id=false) {
		// βτⅩ?【ㅟ艮쨍ㅇㅚㄴ。
		return false;
	}

//////////////////////////////////////////////////
//	으쨍얾쫴ㅛㅉㅻ。
	function GetNormal($mes=false) {
		if($this->STATE === ALIVE)
			return true;
		if($this->STATE === DEAD) {//삑絳얾쫴
			if($this->summon) return true;
			if($mes)
				print($this->Name("bold").' <span class="recover">부활</span>!<br />'."\n");
			$this->STATE = 0;
			return true;
		}
		if($this->STATE === POISON) {//판얾쫴
			if($mes)
				print($this->Name("bold")."의 <span class=\"spdmg\">독</span>이 치료되었습니다.<br />\n");
			$this->STATE = 0;
			return true;
		}
	}
//////////////////////////////////////////////////
//	ㅇㅬ【ㅇㅖㅻㄻㅙㄶㄻ널푤ㅉㅻ。
	function CharJudgeDead() {
		if($this->HP < 1 && $this->STATE !== DEAD) {//ㅇㅬ【
			$this->STATE	= DEAD;
			$this->HP	= 0;
			$this->ResetExpect();
			//$this->delay	= 0;

			return true;
		}
	}
//////////////////////////////////////////////////
//	?γιㅞ揀웃ㆂ?ΓΘㅉㅻ。
	function SetCharData($monster) {

		$this->name		= $monster["name"];
		$this->level	= $monster["level"];

		if ($monster["img"])
			$this->img		= $monster["img"];

		$this->str		= $monster["str"];
		$this->int		= $monster["int"];
		$this->dex		= $monster["dex"];
		$this->spd		= $monster["spd"];
		$this->luk		= $monster["luk"];

		$this->maxhp	= $monster["maxhp"];
		$this->hp		= $monster["hp"];
		$this->maxsp	= $monster["maxsp"];
		$this->sp		= $monster["sp"];

		$this->position	= $monster["position"];
		$this->guard	= $monster["guard"];

		if(is_array($monster["judge"]))
			$this->judge	= $monster["judge"];
		if(is_array($monster["quantity"]))
			$this->quantity	= $monster["quantity"];
		if(is_array($monster["action"]))
			$this->action	= $monster["action"];

		//βτⅩ?【잽錮
		//$this->monster		= $monster["monster"];
		$this->monster		= true;
		$this->summon		= $monster["summon"];
		$this->exphold		= $monster["exphold"];
		$this->moneyhold	= $monster["moneyhold"];
		$this->itemdrop		= $monster["itemdrop"];
		$this->atk	= $monster["atk"];
		$this->def	= $monster["def"];
		$this->SPECIAL	= $monster["SPECIAL"];
	}
//////////////////////////////////////////////////
//	쟁트錮ㅞ揀웃
	function SetBattleVariable($team=false) {
		// 뵈팖ㅯ벗ㅯㆂ漑삐ㅗㄽㅻ ㄻ?
		if(isset($this->IMG))
			return false;

		$this->team		= $team;//ㅃㅼ斛ㄻ?
		$this->IMG		= $this->img;
		$this->MAXHP	= $this->maxhp;
		$this->HP		= $this->hp;
		$this->MAXSP	= $this->maxsp;
		$this->SP		= $this->sp;
		$this->STR		= $this->str + $this->P_STR;
		$this->INT		= $this->int + $this->P_INT;
		$this->DEX		= $this->dex + $this->P_DEX;
		$this->SPD		= $this->spd + $this->P_SPD;
		$this->LUK		= $this->luk + $this->P_LUK;
		$this->POSITION	= $this->position;
		$this->STATE	= ALIVE;//으쨍얾쫴ㅛㅉㅻ

		$this->expect	= false;//(웃촐=귓쑨충 false=쫠덧충)
		$this->ActCount	= 0;//밋튼뀨웃
		$this->JdgCount	= array();//룩쾨ㅇㅏ횟쳬ㅞ뀨웃
	}
}
?>
