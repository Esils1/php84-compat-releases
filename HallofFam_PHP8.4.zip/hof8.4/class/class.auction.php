<?php
/*
■옥션 메모
□아이템
	데이터의 보존 방법
	define("AUCTION_ITEM","./*****");//코코

	.dat 의 내용에 대해
	번호(1행째만)
	번호<>경매 종료시각<>지금의 입찰 가격<>출품자 id<>아이템<>개수<>합계 입찰수<>최종 입찰자 id<>최종 입찰 시간<>코멘트<>IP
	번호-1<>경매 종료시각<>지금의 입찰 가격<>출품자 id<>아이템<>개수<>합계 입찰수<>최종 입찰자 id<>최종 입찰 시간<>코멘트<>IP
	번호-2<>경매 종료시각<>지금의 입찰 가격<>출품자 id<>아이템<>개수<>합계 입찰수<>최종 입찰자 id<>최종 입찰 시간<>코멘트<>IP
	...........
□캐릭터
*/
class Auction {

	// ファイルポインタ
	var $fp;

	// 옥션의 종류
	// 아이템 or캐릭터
	var $AuctionType;

	// 경매품 번호
	var $ArticleNo;

	// 출품물(캐릭터) 리스트
	var $Article = array();

	var $UserName;

	// 낙찰물이나 낙찰금의 처리용
	var $TempUser	= array();

	// 경과 로그
	var $AuctionLog;

	// 데이터가 변경되었어?
	var $DataChange	= false;

	var $QUERY;
	var $sort;

////////////////////////////////
// constructor　 　
	function Auction($type) {
		// 아이템옥션
		if($type == "item") {
			$this->AuctionType = "item";
			$this->ItemArticleRead();
		// 캐릭터옥션
		} else if($type == "char") {
			$this->AuctionType = "char";
		}
	}
//////////////////////////////////////////////
//	GET의 쿼리명
	function AuctionHttpQuery($name) {
		$this->QUERY	= $name;
	}
//////////////////////////////////////////////
//	시간이 경과해 종료한 경매품의 처리
	function ItemCheckSuccess() {
		$Now	= time();
		foreach($this->Article as $no => $Article) {
			// 경매 시간이 남아 있다면 다음
			if(AuctionLeftTime($Now,$Article["end"]))
				break;
			if(!function_exists("LoadItemData"))
				include(DATA_ITEM);
			$item	= LoadItemData($Article["item"]);
			if($Article["bidder"]) {
				// 낙찰자가 있다면 아이템을 건네준다.
				// 낙찰자가 있다면 출품자에게 돈을 건네준다.
				$this->UserGetItem($Article["bidder"],$Article["item"],$Article["amount"]);
				$this->UserGetMoney($Article["exhibitor"],$Article["price"]);
				// 결과를 로그에 남겨라
				$this->AddLog("No.{$Article['No']} <img src=\"".IMG_ICON.$item["img"]."\"><span class=\"bold\">{$item['name']} x{$Article['amount']}</span>개를 ".$this->UserGetNameFromTemp($Article["bidder"])." 이(가) ".MoneyFormat($Article["price"])." 로<span class=\"recover\"> 낙찰하였습니다.</span>");
			} else {
				// 입찰이 없었던 경우, 출품자에게 반환.
				$this->UserGetItem($Article["exhibitor"],$Article["item"],$Article["amount"]);
				// 결과를 로그에 남겨라
				$this->AddLog("No.{$Article['No']} <img src=\"".IMG_ICON.$item["img"]."\"><span class=\"bold\">{$item['name']} x{$Article['amount']}</span>개는 <span class=\"dmg\">입찰자가 없어 취소되었습니다.</span>");
			}
			// 마지막에 지운다
			unset($this->Article["$no"]);
			$this->DataChange	= true;
		}
	}
//////////////////////////////////////////////
//	
	function UserGetNameFromTemp($UserID) {
		if($this->TempUser["$UserID"]["Name"])
			return $this->TempUser["$UserID"]["Name"];
		else
			return "-";
	}
//////////////////////////////////////////////
//	옥션으로 돈을 획득
	function UserGetMoney($UserID,$Money) {
		if(!$this->TempUser["$UserID"]["user"])
		{
			$this->TempUser["$UserID"]["user"]	= new user($UserID);
			$this->TempUser["$UserID"]["Name"]	= $this->TempUser["$UserID"]["user"]->Name();
		}

		$this->TempUser["$UserID"]["UserGetTotalMoney"]	+= $Money;
		$this->TempUser["$UserID"]["Money"]	= true;//돈이 추가된 것을 기록
	}
//////////////////////////////////////////////
//	옥션으로 아이템 획득
	function UserGetItem($UserID,$item,$amount) {
		if(!$this->TempUser["$UserID"]["user"])
		{
			$this->TempUser["$UserID"]["user"]	= new user($UserID);
			$this->TempUser["$UserID"]["Name"]	= $this->TempUser["$UserID"]["user"]->Name();
		}

		$this->TempUser["$UserID"]["UserGetItem"]["$item"]	+= $amount;
		$this->TempUser["$UserID"]["item"]	= true;//아이템이 추가된 것을 기록
	}
//////////////////////////////////////////////
//	옥션으로 캐릭터 획득
//	(동작 확인 없음)
	function UserGetChar($UserID,$char) {
		$this->TempUser["$UserID"]["char"][]	= $char;//
		$this->TempUser["$UserID"]["CharAdd"]	= true;//캐릭터가 추가된 것을 기록
	}
//////////////////////////////////////////////
//	옥션 처리 결과를 청산한다?
	function UserSaveData() {
		foreach($this->TempUser as $user => $Result) {
			// 돈을 얻었다
			if($this->TempUser["$user"]["Money"]) {
				$this->TempUser["$user"]["user"]->GetMoney($this->TempUser["$user"]["UserGetTotalMoney"]);
				$this->TempUser["$user"]["user"]->SaveData();
			}
			// 아이템을 얻었다
			if($this->TempUser["$user"]["item"]) {
				foreach($this->TempUser["$user"]["UserGetItem"] as $itemNo => $amount) {
					$this->TempUser["$user"]["user"]->AddItem($itemNo,$amount);
				}
				$this->TempUser["$user"]["user"]->SaveUserItem();
			}
			// 캐릭터를 얻었다
			// (동작 확인 없음)
			if($this->TempUser["$user"]["CharAdd"]) {
				if($this->TempUser["$user"]["char"]) {
					foreach($this->TempUser["$user"]["char"] as $char) {
						$char->SaveCharData($user);
					}
				}
			}
			// 유저가 열린 모든 파일의 파일 포인터를 닫는다
			$this->TempUser["$user"]["user"]->fpCloseAll();
		}
		unset($this->TempUser);
	}
//////////////////////////////////////////////
//	입찰할 권리가 있을지 없을지 돌려준다
	function ItemBidRight($ArticleNo,$UserID) {
		if($this->Article["$ArticleNo"]["bidder"] == $UserID)
			return false;
		if($this->Article["$ArticleNo"]["exhibitor"] == $UserID)
			return false;
		return true;
	}
//////////////////////////////////////////////
//	유저의 이름을 호출한다
	function LoadUserName($id) {
		if($this->UserName["$id"]) {
			return $this->UserName["$id"];
		} else {
			$User	= new user($id);
			$Name	= $User->Name();
			if($Name) {
				$this->UserName["$id"]	= $Name;
			} else {
				$this->UserName["$id"]	= "-";
			}
			return $this->UserName["$id"];
		}
	}
//////////////////////////////////////////////
//	최저 입찰 가격을 돌려준다
	function ItemBottomPrice($ArticleNo) {
		if($this->Article["$ArticleNo"]) {
			return BottomPrice($this->Article["$ArticleNo"]["price"]);
		}
	}
//////////////////////////////////////////////
//	입찰한다
	function ItemBid($ArticleNo,$BidPrice,$Bidder,$BidderName) {
		if(!$Article	= $this->Article["$ArticleNo"])
			return false;
		$BottomPrice	= BottomPrice($this->Article["$ArticleNo"]["price"]);
		// IP가 같을 경우
		if($Article["IP"] == $_SERVER['REMOTE_ADDR']) {
			ShowError("IP제한.");
			return false;
		}
		// 휴대 단말을 금지한다.
		if(isMobile == "i") {
			ShowError("mobile forbid.");
			return false;
		}
		// 최저 입찰 가격을 나누고 있는 경우
		if($BidPrice < $BottomPrice)
			return false;

		// 누군가가 입찰하고 있었을 경우 돈을 환불한다.
		if($Article["bidder"]) {
			$this->UserGetMoney($Article["bidder"],$Article["price"]);
			$this->UserSaveData();
		}

		// 입찰 시간이 얼마 남지 않으면 연장한다.
		$Now	= time();
		$left	= AuctionLeftTime($Now,$Article["end"],true);
		/* // 남은 시간 1시간 이하라면 15분 연장한다
		if(1 < $left && $left < 3601) {
			$this->Article["$ArticleNo"]["end"]	+= 900;
		}
		*/
		// 남은 시간 15분 이하라면 15분으로 한다.
		if(0 < $left && $left < 901) {
			$dif	= 900 - $left;
			$this->Article["$ArticleNo"]["end"]	+= $dif;
		}
		

		$this->Article["$ArticleNo"]["price"]	= $BidPrice;
		$this->Article["$ArticleNo"]["TotalBid"]++;
		$this->Article["$ArticleNo"]["bidder"]	= $Bidder;
		$this->DataChange	= true;
		$item	= LoadItemData($Article["item"]);
		//$this->AddLog("No.".$Article["No"]." <span class=\"bold\">{$item['name']} x{$Article['amount']}</span>개를 ".MoneyFormat($BidPrice)." 에 ".$this->LoadUserName($Bidder)." 가<span class=\"support\"> 입찰하였습니다.</span>");
		$this->AddLog("No.".$Article["No"]." <span class=\"bold\">{$item['name']} x{$Article['amount']}</span>개를 ".MoneyFormat($BidPrice)." 에 ".$BidderName." 이(가)<span class=\"support\"> 입찰하였습니다.</span>");
		return true;
	}
//////////////////////////////////////////////
//	출품물 일람을 표시하는(그 1) 표시의 줄이 다를 뿐
	function ItemShowArticle($bidding=false) {
		if(count($this->Article) == 0) {
			print("경매물 없음(No auction)<br />\n");
			return false;
		} else {
			$Now	= time();
			$exp	= '<tr><td class="td9">번호</td><td class="td9">가격</td><td class="td9">입찰자</td><td class="td9">입찰수</td><td class="td9">나머지</td>'.
					'<td class="td9">출품자</td><td class="td9">코멘트</td></tr>'."\n";
			print('<table style="width:725px;text-align:center" cellpadding="0" cellspacing="0" border="0">'."{$exp}\n");
			foreach($this->Article as $Article) {

				print("<tr><td class=\"td7\">");
				// 경매 번호
				print($Article["No"]);
				print("</td><td class=\"td7\">");
				// 현재 입찰 가격
				print(MoneyFormat($Article["price"]));
				print("</td><td class=\"td7\">");
				// 입찰자
				if(!$Article["bidder"])
					$bidder	= "-";
				else
					$bidder	= $this->LoadUserName($Article["bidder"]);
				print($bidder);
				print("</td><td class=\"td7\">");
				// 합계 입찰수
				print($Article["TotalBid"]);
				print("</td><td class=\"td7\">");
				// 종료시각
				print(AuctionLeftTime($Now,$Article["end"]));
				print("</td><td class=\"td7\">");
				// 출품자
				$exhibitor	= $this->LoadUserName($Article["exhibitor"]);
				print($exhibitor);
				print("</td><td class=\"td8\">");
				// 코멘트
				print($Article["comment"]?$Article["comment"]:"&nbsp;");
				print("</td></tr>\n");
				// 아이템
				print('<tr><td colspan="7" style="text-align:left;padding-left:15px" class="td6">');
				$item	= LoadItemData($Article["item"]);
				print('<form action="?menu=auction" method="post">');
				// 입찰 폼
				if($bidding) {
					print('<a href="#" onClick="Element.toggle(\'Bid'.$Article["No"].'\';return false;)">입찰</a>');
					print('<span style="display:none" id="Bid'.$Article["No"].'">');
					print('&nbsp;<input type="text" name="BidPrice" style="width:80px" class="text" value="'.BottomPrice($Article["price"]).'">');
					print('<input type="submit" value="Bid" class="btn">');
					print('<input type="hidden" name="ArticleNo" value="'.$Article["No"].'">');
					print('</span>');
				}
				print(ShowItemDetail($item,$Article["amount"],1));
				print("</form>");
				print("</td></tr>\n");
			}
			print("{$exp}</table>\n");
			return true;
		}
	}
//////////////////////////////////////////////
//	출품물 일람을 표시하는(그 2) 표시의 줄이 다를 뿐
	function ItemShowArticle2($bidding=false) {
		if(count($this->Article) == 0) {
			print("경매물 없음(No auction)<br />\n");
			return false;
		} else {
			$Now	= time();
			// 소트 되고 있는 색을 바꾼다(가변 변수)
			if($this->sort)
				${"Style_".$this->sort}	= ' class="a0"';
			$exp	= '<tr><td class="td9"><a href="?menu='.$this->QUERY.'&sort=no"'.$Style_no.'>No</a></td>'.
					'<td class="td9"><a href="?menu='.$this->QUERY.'&sort=time"'.$Style_time.'>나머지</td>'.
					'<td class="td9"><a href="?menu='.$this->QUERY.'&sort=price"'.$Style_price.'>가격</a>'.
					'<br /><a href="?menu='.$this->QUERY.'&sort=rprice"'.$Style_rprice.'>(입찰가)</a></td>'.
					'<td class="td9">Item</td>'.
					'<td class="td9"><a href="?menu='.$this->QUERY.'&sort=bid"'.$Style_bid.'>Bids</a></td>'.
					'<td class="td9">입찰자</td><td class="td9">출품자</td></tr>'."\n";

			print("총출품수:".$this->ItemAmount()."\n");
			print('<table style="width:725px;text-align:center" cellpadding="0" cellspacing="0" border="0">'."\n");
			print($exp);
			foreach($this->Article as $Article) {

				// 경매 번호
				print("<tr><td rowspan=\"2\" class=\"td7\">");
				print($Article["No"]);
				// 종료시각
				print("</td><td class=\"td7\">");
				print(AuctionLeftTime($Now,$Article["end"]));
				// 현재 입찰 가격
				print("</td><td class=\"td7\">");
				print(MoneyFormat($Article["price"]));
				// 아이템
				print('</td><td class="td7" style="text-align:left">');
				$item	= LoadItemData($Article["item"]);
				print(ShowItemDetail($item,$Article["amount"],1));
				// 합계 입찰수
				print("</td><td class=\"td7\">");
				print($Article["TotalBid"]);
				// 입찰자
				print("</td><td class=\"td7\">");
				if(!$Article["bidder"])
					$bidder	= "-";
				else
					$bidder	= $this->LoadUserName($Article["bidder"]);
				print($bidder);
				// 출품자
				print("</td><td class=\"td8\">");
				$exhibitor	= $this->LoadUserName($Article["exhibitor"]);
				print($exhibitor);
				// 코멘트
				print("</td></tr><tr>");
				print("<td colspan=\"6\" class=\"td8\" style=\"text-align:left\">");
				print('<form action="?menu=auction" method="post">');
				// 입찰폼
				if($bidding) {
					print('<a style="margin:0 10px" href="#" onClick="Element.toggle(\'Bid'.$Article["No"].'\');return false;">입찰</a>');
					print('<span style="display:none" id="Bid'.$Article["No"].'">');
					print('&nbsp;<input type="text" name="BidPrice" style="width:80px" class="text" value="'.BottomPrice($Article["price"]).'">');
					print('<input type="submit" value="Bid" class="btn">');
					print('<input type="hidden" name="ArticleNo" value="'.$Article["No"].'">');
					print('</span>');
				}
				print($Article["comment"]?$Article["comment"]:"&nbsp;");
				print("</form>");
				print("</td></tr>\n");
				
				print("</td></tr>\n");
			}
			print($exp);
			print("</table>\n");
			return true;
		}
	}
//////////////////////////////////////////////////
//	그 번호의 경매품이 출품되고 있는지를 확인한다.
	function ItemArticleExists($no) {
		if($this->Article["$no"]) {
			return true;
		} else {
			return false;
		}
	}
//////////////////////////////////////////////
//	아이템을 출품한다
	function ItemAddArticle($item,$amount,$id,$time,$StartPrice,$comment) {
		// 종료시각의 계산
		$Now	= time();
		$end	= $Now + round($now + (60 * 60 * $time));
		// 개시가격의 그것
		if(preg_match("/^[0-9]/",$StartPrice)) {
			$price	= (int)$StartPrice;
		} else {
			$price	= 0;
		}
		// コメント?理
		$comment	= str_replace("\t","",$comment);
		$comment	= htmlspecialchars(trim($comment),ENT_QUOTES);
		$comment	= stripslashes($comment);
		// 경매품 번호
		$this->ArticleNo++;
		if(9999 < $this->ArticleNo)
			$this->ArticleNo	= 0;
		$New	= array(
			// 경매품 번호
			"No"		=> $this->ArticleNo,
			// 종료시각
			"end"		=> $end,
			// 지금의 입찰 가격
			"price"		=> (int)$price,
			// 출품자 id
			"exhibitor"	=> $id,
			// 아이템
			"item"		=> $item,
			// 개수
			"amount"	=> (int)$amount,
			// 합계 입찰수
			"TotalBid"	=> 0,
			// 최종 입찰자 id
			"bidder"	=> NULL,
			// 최종 입찰 시간(사용하지 않습니다!사용하고 싶다면 사용해 주세요)
			"latest"	=> NULL,
			// 코멘트
			"comment"	=> $comment,
			// IP
			"IP"	=> $_SERVER['REMOTE_ADDR'],
			);
		array_unshift($this->Article,$New);
		$itemData	= LoadItemData($item);
		$this->AddLog("No.".$this->ArticleNo." 에 <img src=\"".IMG_ICON.$itemData["img"]."\"><span class=\"bold\">{$itemData['name']} x{$amount}</span>개가 <span class=\"charge\">출품되었습니다. </span>");
		$this->DataChange	= true;
	}
//////////////////////////////////////////////
//	옥션의 데이터를 보존한다
	function ItemSaveData() {
		if(!$this->DataChange)
		{
			fclose($this->fp);
			unset($this->fp);
			return false;
		}
		// 아이템 옥션을 보존한다.
		$string	= $this->ArticleNo."\n";
		foreach($this->Article as $val) {
			//if(strlen($val["end"]) != 10) break;
			$string	.=	$val["No"].
				"<>".$val["end"].
				"<>".$val["price"].
				"<>".$val["exhibitor"].
				"<>".$val["item"].
				"<>".$val["amount"].
				"<>".$val["TotalBid"].
				"<>".$val["bidder"].
				"<>".$val["latest"].
				"<>".$val["comment"].
				"<>".$val["IP"]."\n";
		}
		//print($string);
		if(file_exists(AUCTION_ITEM) && $this->fp) {
			WriteFileFP($this->fp,$string,true);
			fclose($this->fp);
			unset($this->fp);
		} else {
			WriteFile(AUCTION_ITEM,$string,true);
		}
		$this->SaveLog();
	}
//////////////////////////////////////////////
//	
	function ItemSortBy($type) {
		switch($type) {
			case "no":
				usort($this->Article,"ItemArticleSortByNo");
				$this->sort	= "no";
				break;
			case "time":
				usort($this->Article,"ItemArticleSortByTime");
				$this->sort	= "time";
				break;
			case "price":
				usort($this->Article,"ItemArticleSortByPrice");
				$this->sort	= "price";
				break;
			case "rprice":
				usort($this->Article,"ItemArticleSortByRPrice");
				$this->sort	= "rprice";
				break;
			case "bid":
				usort($this->Article,"ItemArticleSortByTotalBid");
				$this->sort	= "bid";
				break;
			default:
				usort($this->Article,"ItemArticleSortByTime");
				$this->sort	= "time";
				break;
		}
	}
//////////////////////////////////////////////
// 아이템 옥션용의 파일을 열어
// 데이타를 뽑아서, 격납
	function ItemArticleRead() {
		// 파일이 있는 경우
		if(file_exists(AUCTION_ITEM)) {
			//$fp	= fopen(AUCTION_ITEM,"r+");
			$this->fp	= FileLock(AUCTION_ITEM);
			//if(!$fp) return false;
			//flock($fp,LOCK_EX);
			// 경매 번호를 예측한다
			$this->ArticleNo	= trim(fgets($this->fp));
			while( !feof($this->fp) ) {
				$str	= fgets($this->fp);
				if(!$str) break;
				$article = explode("<>",$str);
				if(strlen($article["1"]) != 10) break;
				$this->Article[$article["0"]]	= array(
				"No"		=> $article["0"],// 경매 번호
				"end"		=> $article["1"],// 종료시각
				"price"		=> $article["2"],// 지금의 입찰 가격
				"exhibitor"	=> $article["3"],// 출품자 id
				"item"		=> $article["4"],// 아이템
				"amount"	=> $article["5"],// 개수
				"TotalBid"	=> $article["6"],// 합계 입찰수
				"bidder"	=> $article["7"],// 최종 입찰자 id
				"latest"	=> $article["8"],// 최종 입찰 시간
				"comment"	=> trim($article["9"]),// 코멘트
				"IP"	=> trim($article["10"]),// IP
				);
			}
		// 파일이 없는 경우
		} else {
			// 아무것도 하지 않는다.
		}
	}
//////////////////////////////////////////////////
//	출품물의 수
	function ItemAmount() {
		return count($this->Article);
	}
//////////////////////////////////////////////////
//	옥션 경과 로그를 읽는다
	function LoadLog() {
		if($this->AuctionType == "item") {
			if(!file_exists(AUCTION_ITEM_LOG)) {
				$this->AuctionLog	= array();
				return false;
			}
			$fp	= fopen(AUCTION_ITEM_LOG,"r+");
			if(!$fp) return false;
			flock($fp,LOCK_EX);
			while( !feof($fp) ) {
				$str	= trim(fgets($fp));
				if(!$str) break;
				$this->AuctionLog[]	= $str;
			}
		}
	}
//////////////////////////////////////////////////
//	옥션 경과 로그의 보존
	function SaveLog() {
		if($this->AuctionType == "item") {
			if(!$this->AuctionLog)
				return false;
			// 30행 이하에 거둔다
			while(100 < count($this->AuctionLog)) {
				array_pop($this->AuctionLog);
			}
			foreach($this->AuctionLog as $log) {
				$string	.= $log."\n";
			}
			WriteFile(AUCTION_ITEM_LOG,$string);
		}
	}
//////////////////////////////////////////////////
//	로그의 표시
	function ShowLog() {
		if(!$this->AuctionLog)
			$this->LoadLog();
		if(!$this->AuctionLog)
			return false;
		foreach($this->AuctionLog as $log) {
			print("{$log}<br />\n");
		}
	}
//////////////////////////////////////////////////
//	로그의 추가
	function AddLog($string) {
		if(!$this->AuctionLog)
			$this->LoadLog();
		if(!$this->AuctionLog)
			$this->AuctionLog	= array();
		array_unshift($this->AuctionLog,$string);
	}


}
//////////////////////////////////////////////////
//	아이템을 번호순서에 줄서 바꾼다
	function ItemArticleSortByNo($a,$b) {
		if($a["No"] == $b["No"])
			return 0;
		return ($a["No"] > $b["No"]) ? 1:-1;
	}
//////////////////////////////////////////////////
//	아이템을 남은 시간순서에 줄서 바꾼다
	function ItemArticleSortByTime($a,$b) {
		if($a["end"] == $b["end"])
			return 0;
		return ($a["end"] > $b["end"]) ? 1:-1;
	}
//////////////////////////////////////////////////
//	아이템을 가격순서에 줄서 바꾼다
	function ItemArticleSortByPrice($a,$b) {
		if($a["price"] == $b["price"])
			return 0;
		return ($a["price"] > $b["price"]) ? -1:1;
	}
//////////////////////////////////////////////////
//	아이템을 가격순서에 줄서 바꾼다(반대)
	function ItemArticleSortByRPrice($a,$b) {
		if($a["price"] == $b["price"])
			return 0;
		return ($a["price"] > $b["price"]) ? 1:-1;
	}
//////////////////////////////////////////////////
//	아이템을 입찰수순에 줄서 바꾼다
	function ItemArticleSortByTotalBid($a,$b) {
		if($a["TotalBid"] == $b["TotalBid"])
			return 0;
		return ($a["TotalBid"] > $b["TotalBid"]) ? -1:1;
	}
//////////////////////////////////////////////////
//	남은 시간을 돌려준다
	function AuctionLeftTime($now,$end,$int=false) {
		$left	= $end - $now;
		// $int=true 라면 남은만큼 돌려준다
		if($int)
			return $left;
		if($left < 1) {// 종료하고 있는 경우는 false
			return false;
		}
		if($left < 601) {
			return "{$left}초";
		} else if($left < 3601) {
			$minutes	= floor($left/60);
			return "{$minutes}분";
		} else {
			$hour	= floor($left/3600);
			$minutes	= floor(($left%3600)/60);
			return "{$hour}시간{$minutes}분";
		}
	}
//////////////////////////////////////////////////
//	최저가격을 돌려준다
//	가격의5%가 최저치.
//	100 이하라면 100이 거기에 된다.
	function BottomPrice($price) {
		$bottom	= floor($price * 0.10);
		if($bottom < 101)
			return sprintf("%0.0f",$price + 100);
		else
			return sprintf("%0.0f",$price + $bottom);
	}
?>