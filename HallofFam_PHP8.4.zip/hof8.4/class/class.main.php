<?php
include(CLASS_USER);
include(GLOBAL_PHP);
class main extends user {

	var $islogin	= false;

//////////////////////////////////////////////////
//	
function __construct() {
    $this->main();
}
	function main() {
		$this->SessionSwitch();
		$this->Set_ID_PASS();
		if(isset($_POST["monster_battle"]) || isset($_POST["simu_battle"]) || isset($_POST["union_battle"]) || isset($_POST["ChallengeRank"])) {
			if($this->id && $this->pass) {
				$header_data = $this->LoadData(true);
				if(is_array($header_data) && $header_data["pass"] === $this->pass) {
					$this->SetData($header_data);
					$this->islogin = true;
				}
				$this->fpCloseAll();
			}
			$this->Head();
			ob_start();
			$this->Order();
			$content	= ob_get_contents();
			ob_end_clean();
			print($content);
			$this->Debug();
			$this->Foot();
			return true;
		}
		ob_start();
		$this->Order();
		$content	= ob_get_contents();
		ob_end_clean();
		$this->Head();
		print($content);
		$this->Debug();
		//$this->ShowSession();
		$this->Foot();
	}

//////////////////////////////////////////////////
//	
	function Order() {
		// 로그인 처리하기 전에 처리하는 것
		// 아직 유저 데이터 읽지 않았습니다
		switch(true) {
			case($_GET["menu"] === "auction"):
				include(CLASS_AUCTION);
				$ItemAuction	= new Auction(item);
				$ItemAuction->AuctionHttpQuery("auction");
				$ItemAuction->ItemCheckSuccess();// 경매가 종료한 물건을 조사한다
				$ItemAuction->UserSaveData();// 경매품과 금액을 각 ID에 나눠주어 보존한다
				break;

			case($_GET["menu"] === "rank"):
				include(CLASS_RANKING);
				$Ranking	= new Ranking();
				break;
		}
		if( true === $message = $this->CheckLogin() ):
		//if( false ):
		// 로그인
			include_once(DATA_ITEM);
			include(CLASS_CHAR);
			if($this->FirstLogin())
				return 0;

			switch(true) {

				case($this->OptionOrder()):	return false;

				case($_POST["delete"]):
					if($this->DeleteMyData())
						return 0;

				// 설정
				case($_SERVER["QUERY_STRING"] === "setting"):
					if($this->SettingProcess())
						$this->SaveData();

					$this->fpCloseAll();
					$this->SettingShow();
					return 0;

				// 옥션
				case($_GET["menu"] === "auction"):
					$this->LoadUserItem();//아이템 데이터를 읽는다
					$this->AuctionHeader();

					/*
					* 출품용의 물폼
					* 표시를 요구했을 경우인가,
					* 출품에 실패했을 경우 표시한다.
					*/
					$ResultExhibit	= $this->AuctionItemExhibitProcess($ItemAuction);
					$ResultBidding	= $this->AuctionItemBiddingProcess($ItemAuction);
					$ItemAuction->ItemSaveData();// 변경이 있었을 경우만 보존한다.

					// 출품 리스트를 표시한다
					if($_POST["ExhibitItemForm"]) {
						$this->fpCloseAll();
						$this->AuctionItemExhibitForm($ItemAuction);

					// 출품이나 입찰에 성공했을 경우는 데이터를 보존한다
					} else if($ResultExhibit !== false) {

						if($ResultExhibit === true || $ResultBidding === true)
							$this->SaveData();

						$this->fpCloseAll();
						$this->AuctionItemBiddingForm($ItemAuction);

					//  
					} else {
						$this->fpCloseAll();
						$this->AuctionItemExhibitForm($ItemAuction);
					}

					$this->AuctionFoot($ItemAuction);
					return 0;

				// 카리바
				case($_SERVER["QUERY_STRING"] === "hunt"):
					$this->LoadUserItem();//아이템 데이터 읽는다
					$this->fpCloseAll();
					$this->HuntShow();
					return 0;

				// 가
				case($_SERVER["QUERY_STRING"] === "town"):
					$this->LoadUserItem();//아이템 데이터 읽는다
					$this->fpCloseAll();
					$this->TownShow();
					return 0;

				// 시뮤
				case($_SERVER["QUERY_STRING"] === "simulate"):
					$this->CharDataLoadAll();//캐릭터 데이터 읽는다
					if($this->SimuBattleProcess())
						$this->SaveData();

					$this->fpCloseAll();
					$this->SimuBattleShow($result);
					return 0;

				// 유니온
				case($_GET["union"]):
					$this->CharDataLoadAll();//캐릭터 데이터 읽는다
					include(CLASS_UNION);
					include(DATA_MONSTER);
					if($this->UnionProcess()) {
						// 전투한다
						$this->SaveData();
						$this->fpCloseAll();
					} else {
						// 표시
						$this->fpCloseAll();
						$this->UnionShow();
					}
					return 0;

				// 일반 몬스터
				case($_GET["common"]):
					$this->CharDataLoadAll();//캐릭터 데이터 읽는다
					$this->LoadUserItem();//아이템 데이터 읽는다
					if($this->MonsterBattle()) {
						$this->SaveData();
						$this->fpCloseAll();
					} else {
						$this->fpCloseAll();
						$this->MonsterShow();
					}
					return 0;

				// 캐라스테
				case($_GET["char"]):
					$this->CharDataLoadAll();//캐릭터 데이터 읽는다
					include(DATA_SKILL);
					include(DATA_JUDGE_SETUP);
					$this->LoadUserItem();//아이템 데이터 읽는다
					$this->CharStatProcess();
					$this->fpCloseAll();
					$this->CharStatShow();
					return 0;

				// 아이템 일람
				case($_SERVER["QUERY_STRING"] === "item"):
					$this->LoadUserItem();//아이템 데이터 읽는다
					//$this->ItemProcess();
					$this->fpCloseAll();
					$this->ItemShow();
					return 0;

				// 제련
				case($_GET["menu"] === "refine"):
					$this->LoadUserItem();
					$this->SmithyRefineHeader();
					if($this->SmithyRefineProcess())
						$this->SaveData();

					$this->fpCloseAll();
					$result	= $this->SmithyRefineShow();
					return 0;

				// 제작
				case($_GET["menu"] === "create"):
					$this->LoadUserItem();
					$this->SmithyCreateHeader();
					include(DATA_CREATE);//제작할 수 있는 것 데이터등
					if($this->SmithyCreateProcess())
						$this->SaveData();

					$this->fpCloseAll();
					$this->SmithyCreateShow();
					return 0;
/*
				// 숍(구식:사는, 파는, 아르바이트)
				case($_SERVER["QUERY_STRING"] === "shop"):
					$this->LoadUserItem();//아이템 데이터 읽는다
					if($this->ShopProcess())
						$this->SaveData();
					$this->fpCloseAll();
					$this->ShopShow();
					return 0;
*/
				// 숍(산다)
				case($_GET["menu"] === "buy"):
					$this->LoadUserItem();//아이템 데이터 읽는다
					$this->ShopHeader();
					if($this->ShopBuyProcess())
						$this->SaveData();
					$this->fpCloseAll();
					$this->ShopBuyShow();
					return 0;

				// 숍(판다)
				case($_GET["menu"] === "sell"):
					$this->LoadUserItem();//아이템 데이터 읽는다
					$this->ShopHeader();
					if($this->ShopSellProcess())
						$this->SaveData();
					$this->fpCloseAll();
					$this->ShopSellShow();
					return 0;

				// 숍(일한다)
				case($_GET["menu"] === "work"):
					$this->ShopHeader();
					if($this->WorkProcess())
						$this->SaveData();
					$this->fpCloseAll();
					$this->WorkShow();
					return 0;

				// 랭킹
				case($_GET["menu"] === "rank"):
					$this->CharDataLoadAll();//캐릭터 데이터 읽는다
					$RankProcess	= $this->RankProcess($Ranking);

					if ($RankProcess === "BATTLE") {
						$this->SaveData();
						$this->fpCloseAll();
					} else if ($RankProcess === true) {
						$this->SaveData();
						$this->fpCloseAll();
						$this->RankShow($Ranking);
					} else {
						$this->fpCloseAll();
						$this->RankShow($Ranking);
					}
					return 0;

				// 고용
				case($_SERVER["QUERY_STRING"] === "recruit"):
					if($this->RecruitProcess())
						$this->SaveData();

					$this->fpCloseAll();
					$this->RecruitShow($result);
					return 0;

				// 그 이외(톱)
				default:
					$this->CharDataLoadAll();//캐릭터 데이터 읽는다
					$this->fpCloseAll();
					$this->LoginMain();
					return 0;
			}
		else:
		// 로그아웃
			$this->fpCloseAll();
			switch(true) {
				case($this->OptionOrder()):	return false;
				case($_POST["Make"]):
					list($bool,$message) = $this->MakeNewData();
					if( true === $bool ) {
						$this->LoginForm($message);
						return false;
					}
				case($_SERVER["QUERY_STRING"] === "newgame"):
					$this->NewForm($message);	return false;
				default:	$this->LoginForm($message);
			}
		endif;
	}

//////////////////////////////////////////////////
//	UpDate,BBS,Manual등
	function OptionOrder() {
		$this->fpCloseAll();
		switch(true) {
			case($_SERVER["QUERY_STRING"] === "rank"):	RankAllShow();	return true;
			case($_SERVER["QUERY_STRING"] === "update"):	ShowUpDate();	return true;
			case($_SERVER["QUERY_STRING"] === "bbs"):	$this->bbs01();	return true;
			case($_SERVER["QUERY_STRING"] === "manual"):	ShowManual();	return true;
			case($_SERVER["QUERY_STRING"] === "manual2"):	ShowManual2();	return true;
			case($_SERVER["QUERY_STRING"] === "tutorial"):	ShowTutorial();	return true;
			case($_SERVER["QUERY_STRING"] === "log"):
				ShowLogList();
				return true;
			case($_SERVER["QUERY_STRING"] === "clog"): LogShowCommon(); return true;
			case($_SERVER["QUERY_STRING"] === "ulog"): LogShowUnion(); return true;
			case($_SERVER["QUERY_STRING"] === "rlog"): LogShowRanking(); return true;
			case($_GET["gamedata"]):
				ShowGameData();
				return true;
			case($_GET["log"]):
				ShowBattleLog($_GET["log"]);
				return true;
			case($_GET["ulog"]):
				ShowBattleLog($_GET["ulog"],"UNION");
				return true;
			case($_GET["rlog"]):
				ShowBattleLog($_GET["rlog"],"RANK");
				return true;
		}
	}

//////////////////////////////////////////////////
//	적의 수를 돌려주는 수~수+2(max:5)
	function EnemyNumber($party) {
		$min	= count($party);//플레이어의 PT수
		if($min == 5)//5인이라면 5마리
			return 5;
		$max	= $min + ENEMY_INCREASE;// 즉,+2이라면[1명:1~3마리] [2명:2~4마리] [3:3-5] [4:4-5] [5:5]
		if($max>5)
			$max	= 5;
		mt_srand();
		return mt_rand($min,$max);
	}
//////////////////////////////////////////////////
//	출현하는 확률로부터 적을 선택해 돌려준다
	function SelectMonster($monster) {
		foreach($monster as $val)
			$max	+= $val[0];//확률의 합계
		$pos	= mt_rand(0,$max);//0~합계 중(안)에서 난수를 취한다
		foreach($monster as $monster_no => $val) {
			$upp	+= $val[0];//그 시점에서의 확률의 합계
			if($pos <= $upp)//합계보다 낮으면 적이 결정된다
				return $monster_no;
		}
	}
//////////////////////////////////////////////////
//	적의 PT를 작성, 돌려준다
//	Specify=적지정(배열)
	function EnemyParty($Amount,$MonsterList,$Specify=false) {

		// 지정 몬스터
		if($Specify) {
			$MonsterNumbers	= $Specify;
		}

		// 몬스터를 우선 배열에 전부 넣는다
		$enemy	= array();
		if(!$Amount)
			return $enemy;
		mt_srand();
		for($i=0; $i<$Amount; $i++)
			$MonsterNumbers[]	= $this->SelectMonster($MonsterList);

		// 중복 하고 있는 몬스터를 조사한다
		$overlap	= array_count_values($MonsterNumbers);

		// 적정보를 읽고 배열에 넣는다.
		include(CLASS_MONSTER);
		foreach($MonsterNumbers as $Number) {
			if(1 < $overlap[$Number])//1마리 이상 출현한다면 이름에 기호를 붙인다.
				$enemy[]	= new monster(CreateMonster($Number,true));
			else
				$enemy[]	= new monster(CreateMonster($Number));
		}
		return $enemy;
	}
	//////////////////////////////////////////////////
//	자동 장착용 장비 위치 판정
		function EquipBestSlot($item) {
			if(!$item || !isset($item["type"]))
				return false;
			switch($item["type"]) {
				case "Sword":
				case "Dagger":
				case "Pike":
				case "Hatchet":
				case "Wand":
				case "Mace":
				case "TwoHandSword":
				case "Spear":
				case "Axe":
				case "Staff":
				case "Bow":
				case "CrossBow":
				case "Whip":
					return "weapon";
				case "Shield":
				case "MainGauche":
				case "Book":
					return "shield";
				case "Armor":
				case "Cloth":
				case "Robe":
					return "armor";
				case "Item":
					return "item";
			}
			return false;
		}

	//////////////////////////////////////////////////
//	자동 장착용 장비 점수
		function EquipBestScore($item,$slot) {
			$atk0	= isset($item["atk"][0]) ? (int)$item["atk"][0] : 0;
			$atk1	= isset($item["atk"][1]) ? (int)$item["atk"][1] : 0;
			$def0	= isset($item["def"][0]) ? (int)$item["def"][0] : 0;
			$def1	= isset($item["def"][1]) ? (int)$item["def"][1] : 0;
			$def2	= isset($item["def"][2]) ? (int)$item["def"][2] : 0;
			$def3	= isset($item["def"][3]) ? (int)$item["def"][3] : 0;
			$def	= $def0 + $def1 + $def2 + $def3;
			$bonus	= 0;
			$bonus	+= (isset($item["P_MAXHP"]) ? (int)$item["P_MAXHP"] : 0) * 2;
			$bonus	+= (isset($item["M_MAXHP"]) ? (int)$item["M_MAXHP"] : 0) * 50;
			$bonus	+= (isset($item["P_MAXSP"]) ? (int)$item["P_MAXSP"] : 0) * 3;
			$bonus	+= (isset($item["M_MAXSP"]) ? (int)$item["M_MAXSP"] : 0) * 50;
			$bonus	+= (isset($item["P_STR"]) ? (int)$item["P_STR"] : 0) * 80;
			$bonus	+= (isset($item["P_INT"]) ? (int)$item["P_INT"] : 0) * 80;
			$bonus	+= (isset($item["P_DEX"]) ? (int)$item["P_DEX"] : 0) * 80;
			$bonus	+= (isset($item["P_SPD"]) ? (int)$item["P_SPD"] : 0) * 80;
			$bonus	+= (isset($item["P_LUK"]) ? (int)$item["P_LUK"] : 0) * 80;
			$bonus	+= (isset($item["P_SUMMON"]) ? (int)$item["P_SUMMON"] : 0) * 80;
			if(isset($item["P_PIERCE"]) && is_array($item["P_PIERCE"]))
				$bonus	+= ((int)$item["P_PIERCE"][0] + (int)$item["P_PIERCE"][1]) * 80;

			switch($slot) {
				case "weapon":
					$score	= ($atk0 + $atk1) * 100 + $def * 20 + $bonus;
					break;
				case "shield":
				case "armor":
					$score	= $def * 100 + ($atk0 + $atk1) * 25 + $bonus;
					break;
				default:
					$score	= $bonus + ($atk0 + $atk1) * 50 + $def * 50;
					break;
			}
			$score	+= isset($item["buy"]) ? ((int)$item["buy"] / 1000) : 0;
			return $score;
		}

	//////////////////////////////////////////////////
//	장비를 자동으로 최적 장착
		function EquipBest($char) {
			$JobData	= LoadJobData($char->job);
			if(!isset($JobData["equip"]) || !$JobData["equip"]) {
				ShowError("장비 가능한 종류가 없습니다.","margin15");
				return false;
			}
			$EquipAllow	= array_flip($JobData["equip"]);
			$places		= array("weapon","shield","armor","item");
			if(!isset($this->item))
				$this->LoadUserItem();
			if(!is_array($this->item))
				$this->item	= array();
			$stock		= array();
			foreach($this->item as $no => $amount) {
				if(0 < (int)$amount)
					$stock[$no]	= (int)$amount;
			}
			foreach($places as $place) {
				if($char->{$place}) {
					if(!isset($stock[$char->{$place}]))
						$stock[$char->{$place}]	= 0;
					$stock[$char->{$place}]++;
				}
			}

			$candidates	= array(
				"weapon"	=> array(false),
				"shield"	=> array(false),
				"armor"		=> array(false),
				"item"		=> array(false)
			);
			foreach($stock as $no => $amount) {
				if($amount < 1)
					continue;
				$item	= LoadItemData($no);
				if(!$item || !isset($item["type"]) || !isset($EquipAllow[$item["type"]]))
					continue;
				$slot	= $this->EquipBestSlot($item);
				if(!$slot)
					continue;
				$candidates[$slot][]	= array(
					"no"		=> $no,
					"item"		=> $item,
					"handle"	=> isset($item["handle"]) ? (int)$item["handle"] : 0,
					"score"		=> $this->EquipBestScore($item,$slot)
				);
			}

			$best		= false;
			$bestScore	= -1;
			foreach($candidates["weapon"] as $weapon) {
				foreach($candidates["shield"] as $shield) {
					if($weapon && $shield && isset($weapon["item"]["dh"]) && $weapon["item"]["dh"])
						continue;
					foreach($candidates["armor"] as $armor) {
						foreach($candidates["item"] as $item) {
							$selected	= array("weapon"=>$weapon,"shield"=>$shield,"armor"=>$armor,"item"=>$item);
							$used		= array();
							$handle		= 0;
							$score		= 0;
							$valid		= true;
							foreach($selected as $pick) {
								if(!$pick)
									continue;
								if(!isset($used[$pick["no"]]))
									$used[$pick["no"]]	= 0;
								$used[$pick["no"]]++;
								if($stock[$pick["no"]] < $used[$pick["no"]]) {
									$valid	= false;
									break;
								}
								$handle	+= $pick["handle"];
								$score	+= $pick["score"];
							}
							if(!$valid || $char->GetHandle() < $handle)
								continue;
							if($bestScore < $score) {
								$bestScore	= $score;
								$best		= $selected;
							}
						}
					}
				}
			}
			if(!$best || (!$best["weapon"] && !$best["shield"] && !$best["armor"] && !$best["item"])) {
				ShowError("자동 장착할 수 있는 장비가 없습니다.","margin15");
				return false;
			}

			foreach($places as $place) {
				if($char->{$place}) {
					$this->AddItem($char->{$place});
					$char->{$place}	= NULL;
				}
			}
			$message	= array();
			$placeName	= array("weapon"=>"무기","shield"=>"방패","armor"=>"방어구","item"=>"아이템");
			foreach($places as $place) {
				if(!$best[$place])
					continue;
				$this->DeleteItem($best[$place]["no"]);
				$char->{$place}	= $best[$place]["no"];
				$message[]	= $placeName[$place]." : ".$best[$place]["item"]["name"];
			}

			$this->SaveUserItem();
			$char->SaveCharData($this->id);
			ShowResult($char->Name()." 의 최적 장비를 자동으로 장착했다.<br />".implode("<br />",$message),"margin15");
			return true;
		}

	//////////////////////////////////////////////////
//	캐릭터 추천 행동 패턴용 스킬 점수
		function RecommendSkillScore($skill) {
			$pow	= isset($skill["pow"]) ? (int)$skill["pow"] : 0;
			$sp		= isset($skill["sp"]) ? (int)$skill["sp"] : 0;
			$hits	= (isset($skill["target"][2]) && 0 < (int)$skill["target"][2]) ? (int)$skill["target"][2] : 1;
			$score	= $pow * $hits;
			$score	+= isset($skill["HpRecoveryRate"]) ? (int)$skill["HpRecoveryRate"] * 120 : 0;
			$score	+= isset($skill["SpRecoveryRate"]) ? (int)$skill["SpRecoveryRate"] * 80 : 0;
			$score	+= isset($skill["HpRegen"]) ? (int)$skill["HpRegen"] * 80 : 0;
			$score	+= isset($skill["SpRegen"]) ? (int)$skill["SpRegen"] * 60 : 0;
			$score	-= $sp;
			return $score;
		}

	//////////////////////////////////////////////////
//	현재 습득 스킬로 추천 행동 패턴을 만든다
		function RecommendPattern($char) {
			$max	= $char->MaxPatterns();
			$judge	= array();
			$quantity	= array();
			$action	= array();
			$skillList	= is_array($char->skill) ? $char->skill : array();
			if(!count($skillList))
				$skillList	= array(1000);
			$skillAllow	= array_flip($skillList);

			$bestAttack	= false;
			$bestAttackScore	= -999999;
			$bestHeal	= false;
			$bestHealScore	= -999999;
			$bestSupport	= false;
			$bestSupportScore	= -999999;

			foreach($skillList as $skillNo) {
				$skill	= LoadSkillData($skillNo);
				if(!$skill || !isset($skill["target"]))
					continue;
				$sp	= isset($skill["sp"]) ? (int)$skill["sp"] : 0;
				if($char->maxsp < $sp)
					continue;
				$target	= $skill["target"][0];
				$score	= $this->RecommendSkillScore($skill);
				if($target === "enemy" || $target === "all") {
					if($bestAttackScore < $score) {
						$bestAttackScore	= $score;
						$bestAttack	= array("no"=>$skillNo,"data"=>$skill);
					}
				} else if($target === "friend" || $target === "self") {
					$skillName	= isset($skill["name"]) ? $skill["name"] : "";
					$skillExp	= isset($skill["exp"]) ? $skill["exp"] : "";
					$isHeal	= isset($skill["HpRecoveryRate"]) || isset($skill["SpRecoveryRate"]) || strpos($skillName,"회복") !== false || strpos($skillExp,"회복") !== false;
					if($isHeal) {
						if($bestHealScore < $score) {
							$bestHealScore	= $score;
							$bestHeal	= array("no"=>$skillNo,"data"=>$skill);
						}
					} else if($bestSupportScore < $score) {
						$bestSupportScore	= $score;
						$bestSupport	= array("no"=>$skillNo,"data"=>$skill);
					}
				}
			}

			if($bestHeal) {
				$judge[]	= ($bestHeal["data"]["target"][0] === "self") ? 1101 : 1121;
				$quantity[]	= 70;
				$action[]	= $bestHeal["no"];
			}
			if($bestSupport && count($action) < $max) {
				$judge[]	= 1000;
				$quantity[]	= 0;
				$action[]	= $bestSupport["no"];
			}
			if($bestAttack && count($action) < $max) {
				$judge[]	= 1000;
				$quantity[]	= 0;
				$action[]	= $bestAttack["no"];
			}

			if(defined("DATA_BASE_CHAR")) {
				include_once(DATA_BASE_CHAR);
				if(function_exists("BaseCharStatus")) {
					$baseNo	= (int)floor(((int)$char->job) / 100);
					$base	= BaseCharStatus($baseNo);
					if(isset($base["Pattern"])) {
						$Pattern	= explode("|",$base["Pattern"]);
						if(count($Pattern) === 3) {
							$baseJudge	= explode("<>",$Pattern[0]);
							$baseQuantity	= explode("<>",$Pattern[1]);
							$baseAction	= explode("<>",$Pattern[2]);
							for($i=0; $i<count($baseAction) && count($action) < $max; $i++) {
								if(!isset($skillAllow[$baseAction[$i]]))
									continue;
								if(in_array($baseAction[$i],$action))
									continue;
								$judge[]	= isset($baseJudge[$i]) ? $baseJudge[$i] : 1000;
								$quantity[]	= isset($baseQuantity[$i]) ? $baseQuantity[$i] : 0;
								$action[]	= $baseAction[$i];
							}
						}
					}
				}
			}

			while(count($action) < $max) {
				$judge[]	= 1000;
				$quantity[]	= 0;
				$action[]	= isset($skillAllow[1000]) ? 1000 : (isset($skillList[0]) ? $skillList[0] : 1000);
			}

			$jobBase	= (int)floor(((int)$char->job) / 100);
			if($bestHeal || $jobBase === 2 || $jobBase === 3 || $jobBase === 4) {
				$position	= BACK;
				$guard	= "never";
			} else {
				$position	= FRONT;
				$guard	= "always";
			}

			return array(
				"judge"	=> array_slice($judge,0,$max),
				"quantity"	=> array_slice($quantity,0,$max),
				"action"	=> array_slice($action,0,$max),
				"position"	=> $position,
				"guard"	=> $guard
			);
		}

	//////////////////////////////////////////////////
//	캐릭터 상세 표시로부터 보내진 리퀘스트를 처리한다
//	길다...(100행 오버)
		function CharStatProcess() {
		$char	= $this->char[$_GET["char"]];
		if(!$char) return false;
		switch(true):
			// 스테이터스 상승
			case($_POST["stup"]):
				//스테이터스 포인트 초과(자지 않아를 위한 절대치)
				$Sum	= abs($_POST["upStr"]) + abs($_POST["upInt"]) + abs($_POST["upDex"]) + abs($_POST["upSpd"]) + abs($_POST["upLuk"]);
				if($char->statuspoint < $Sum) {
					ShowError("스테이터스 포인트 초과","margin15");
					return false;
				}

				if($Sum == 0)
					return false;

				$Stat	= array("Str","Int","Dex","Spd","Luk");
				foreach($Stat as $val) {//최대치를 넘지 않는가 체크
					if(MAX_STATUS < ($char->{strtolower($val)} + $_POST["up".$val])) {
						ShowError("최대 스테이터스 초과(".MAX_STATUS.")","margin15");
						return false;
					}
				}
				$char->str	+= $_POST["upStr"];//스테이터스를 늘린다
				$char->int	+= $_POST["upInt"];
				$char->dex	+= $_POST["upDex"];
				$char->spd	+= $_POST["upSpd"];
				$char->luk	+= $_POST["upLuk"];
				$char->SetHpSp();

				$char->statuspoint	-= $Sum;//포인트를 줄인다.
				print("<div class=\"margin15\">\n");
				if($_POST["upStr"])
					ShowResult("STR 이(가) <span class=\"bold\">".$_POST['upStr']."</span> 올라갔다.".($char->str - $_POST["upStr"])." -> ".$char->str."<br />\n");
				if($_POST["upInt"])
					ShowResult("INT 이(가) <span class=\"bold\">".$_POST['upInt']."</span> 올라갔다.".($char->int - $_POST["upInt"])." -> ".$char->int."<br />\n");
				if($_POST["upDex"])
					ShowResult("DEX 이(가) <span class=\"bold\">".$_POST['upDex']."</span> 올라갔다.".($char->dex - $_POST["upDex"])." -> ".$char->dex."<br />\n");
				if($_POST["upSpd"])
					ShowResult("SPD 이(가) <span class=\"bold\">".$_POST['upSpd']."</span> 올라갔다.".($char->spd - $_POST["upSpd"])." -> ".$char->spd."<br />\n");
				if($_POST["upLuk"])
					ShowResult("LUK 이(가) <span class=\"bold\">".$_POST['upLuk']."</span> 올라갔다.".($char->luk - $_POST["upLuk"])." -> ".$char->luk."<br />\n");
				print("</div>\n");
				$char->SaveCharData($this->id);
				return true;
			// 추천 행동 패턴·위치·호위 설정
			case($_POST["RecommendPattern"]):
				$recommend	= $this->RecommendPattern($char);
				if($char->PatternSave($recommend["judge"],$recommend["quantity"],$recommend["action"])) {
					$char->position	= $recommend["position"];
					$char->guard	= $recommend["guard"];
					$char->SaveCharData($this->id);
					ShowResult($char->Name()." 의 추천 패턴, 위치, 호위를 설정했습니다.","margin15");
					return true;
				}
				ShowError("추천 패턴 설정에 실패했습니다.","margin15");
				return false;
			// 배치·타설정(방어)
			case($_POST["position"]):
				if($_POST["position"] == "front") {
					$char->position	= FRONT;
					$pos	= "전방(Front)";
				} else {
					$char->position	= BACK;
					$pos	= "후방(Back)";
				}

				$char->guard	= $_POST["guard"];
				switch($_POST["guard"]) {
					case "never":	$guard	= "후방를 지키지 않는다"; break;
					case "life25":	$guard	= "체력이 25%이상이라면 후방를 지킨다"; break;
					case "life50":	$guard	= "체력이 50%이상이라면 후방를 지킨다"; break;
					case "life75":	$guard	= "체력이 75%이상이라면 후방를 지킨다"; break;
					case "prob25":	$guard	= "25%의 확률로 후방를 지킨다"; break;
					case "prob50":	$guard	= "50%의 확률로 후방를 지킨다"; break;
					case "prob75":	$guard	= "75%의 확률로 후방를 지킨다"; break;
					default:	$guard	= "반드시 후방를 지킨다"; break;
				}
				$char->SaveCharData($this->id);
				ShowResult($char->Name()." 의 배치를 {$pos} 에.<br />전방때 {$guard} 같게 설정.n","margin15");
				return true;
			//행동 설정
			case($_POST["ChangePattern"]):
				$max	= $char->MaxPatterns();
				//기억하는 패턴과 기술의 배열.
				for($i=0; $i<$max; $i++) {
					$judge[]	= $_POST["judge".$i];
					$quantity_post	= (int) $_POST["quantity".$i];
					if(4 < strlen($quantity_post)) {
						$quantity_post	= substr($quantity_post,0,4);
					}
					$quantity[]	= $quantity_post;
					$action[]	= $_POST["skill".$i];
				}
				//if($char->ChangePattern($judge,$action)) {
				if($char->PatternSave($judge,$quantity,$action)) {
					$char->SaveCharData($this->id);
					ShowResult("패턴 설정 보존 완료","margin15");
					return true;
				}
				ShowError("실패했습니다. 관리자에게 보고해 보세요 03050242","margin15");
				return false;
				break;
			//	행동 설정겸모의전
			case($_POST["TestBattle"]):
					$max	= $char->MaxPatterns();
					//기억하는 패턴과 기술의 배열.
					for($i=0; $i<$max; $i++) {
						$judge[]	= $_POST["judge".$i];
						$quantity_post	= (int) $_POST["quantity".$i];
						if(4 < strlen($quantity_post)) {
							$quantity_post	= substr($quantity_post,0,4);
						}
						$quantity[]	= $quantity_post;
						$action[]	= $_POST["skill".$i];
					}
					//if($char->ChangePattern($judge,$action)) {
					if($char->PatternSave($judge,$quantity,$action)) {
						$char->SaveCharData($this->id);
						$this->CharTestDoppel();
					}
				break;
			//	행동 패턴 메모(교환)
			case($_POST["PatternMemo"]):
				if($char->ChangePatternMemo()) {
					$char->SaveCharData($this->id);
					ShowResult("패턴 교환 완료","margin15");
					return true;
				}
				break;
			//	지정행에 추가
			case($_POST["AddNewPattern"]):
				if(!isset($_POST["PatternNumber"]))
					return false;
				if($char->AddPattern($_POST["PatternNumber"])) {
					$char->SaveCharData($this->id);
					ShowResult("패턴 추가 완료","margin15");
					return true;
				}
				break;
			//	지정행을 삭제
			case($_POST["DeletePattern"]):
				if(!isset($_POST["PatternNumber"]))
					return false;
				if($char->DeletePattern($_POST["PatternNumber"])) {
					$char->SaveCharData($this->id);
					ShowResult("패턴 삭제 완료","margin15");
					return true;
				}
				break;
			//	지정 개소만 장비를 뗀다
			case($_POST["remove"]):
				if(!$_POST["spot"]) {
					ShowError("장비를 떼는 개소가 선택되어 있지 않다","margin15");
					return false;
				}
				if(!$char->{$_POST["spot"]}) {// $this 와 $char 의 구별 주의!
					ShowError("지정된 개소에는 장비 없음","margin15");
					return false;
				}
				$item	= LoadItemData($char->{$_POST["spot"]});
				if(!$item) return false;
				$this->AddItem($char->{$_POST["spot"]});
				$this->SaveUserItem();
				$char->{$_POST["spot"]}	= NULL;
				$char->SaveCharData($this->id);
				SHowResult($char->Name()." 의 {$item['name']} 를 떼었다.","margin15");
				return true;
				break;
			//	장비 전부 뗀다
				case($_POST["remove_all"]):
					if($char->weapon || $char->shield || $char->armor || $char->item ) {
						if($char->weapon)	{ $this->AddItem($char->weapon);	$char->weapon	=NULL; }
					if($char->shield)	{ $this->AddItem($char->shield);	$char->shield	=NULL; }
					if($char->armor)	{ $this->AddItem($char->armor);		$char->armor	=NULL; }
					if($char->item)		{ $this->AddItem($char->item);		$char->item		=NULL; }
					$this->SaveUserItem();
					$char->SaveCharData($this->id);
					ShowResult($char->Name()." 의 장비를 전부 해제했다","margin15");
						return true;
					}	break;
				//	가장 좋은 장비를 자동 장착
				case($_POST["equip_best"]):
					return $this->EquipBest($char);
					break;
				//	지정물을 장비한다
				case($_POST["equip_item"]):
					$item_no	= $_POST["item_no"];
				if(!$this->item["$item_no"]) {//그 아이템을 소지하고 있을까
					ShowError("Item not exists.","margin15");
					return false;
				}

				$JobData	= LoadJobData($char->job);
				$item	= LoadItemData($item_no);//장비하려고 하고 있는 것
				if( !in_array( $item["type"], $JobData["equip"]) ) {//그것이 장비 불가능하면?
					ShowError("{$char->job_name} can't equip {$item['name']}.","margin15");
					return false;
				}

				if(false === $return = $char->Equip($item)) {
					ShowError("Handle Over.","margin15");
					return false;
				} else {
					$this->DeleteItem($item_no);
					foreach($return as $no) {
						$this->AddItem($no);
					}
				}

				$this->SaveUserItem();
				$char->SaveCharData($this->id);
				ShowResult("{$char->name} 는 {$item['name']} 를 장비했다.","margin15");
				return true;
				break;
			// 스킬 습득
			case($_POST["learnskill"]):
				if(!$_POST["newskill"]) {
					ShowError("스킬미선택","margin15");
					return false;
				}

				$char->SetUser($this->id);
				list($result,$message)	= $char->LearnNewSkill($_POST["newskill"]);
				if($result) {
					$char->SaveCharData();
					ShowResult($message,"margin15");
				} else {
					ShowError($message,"margin15");
				}
				return true;
			// 클래스 체인지(전직)
			case($_POST["classchange"]):
				if(!$_POST["job"]) {
					ShowError("직미선택","margin15");
					return false;
				}
				if($char->ClassChange($_POST["job"])) {
					// 장비를 전부 해제
					if($char->weapon || $char->shield || $char->armor || $char->item ) {
						if($char->weapon)	{ $this->AddItem($char->weapon);	$char->weapon	=NULL; }
						if($char->shield)	{ $this->AddItem($char->shield);	$char->shield	=NULL; }
						if($char->armor)	{ $this->AddItem($char->armor);		$char->armor	=NULL; }
						if($char->item)		{ $this->AddItem($char->item);		$char->item		=NULL; }
						$this->SaveUserItem();
					}
					// 보존
					$char->SaveCharData($this->id);
					ShowResult("전직 완료","margin15");
					return true;
				}
				ShowError("failed.","margin15");
				return false;
			//	개명(표시)
			case($_POST["rename"]):
				$Name	= $char->Name();
				$message = <<< EOD
<form action="?char={$_GET['char']}" method="post" class="margin15">
반각문자 16문자 (반각 1문자=전각 2문자)<br />
<input type="text" name="NewName" style="width:160px" class="text" />
<input type="submit" class="btn" name="NameChange" value="Change" />
<input type="submit" class="btn" value="Cancel" />
</form>
EOD;
				print($message);
				return false;
			// 개명(처리)
			case($_POST["NewName"]):
				list($result,$return)	= CheckString($_POST["NewName"],16);
				if($result === false) {
					ShowError($return,"margin15");
					return false;
				} else if($result === true) {
					if($this->DeleteItem("7500",1) == 1) {
						ShowResult($char->Name()."에서 ".$return."(으)로 이름을 변경했습니다.","margin15");
						$char->ChangeName($return);
						$char->SaveCharData($this->id);
						$this->SaveUserItem();
						return true;
					} else {
						ShowError("아이템이 없습니다.","margin15");
						return false;
					}
					return true;
				}
			// 각종 리셋 표시
			case($_POST["showreset"]):
				$Name	= $char->Name();
				print('<div class="margin15">'."\n");
				print("사용할 아이템<br />\n");
				print('<form action="?char='.$_GET['char'].'" method="post">'."\n");
				print('<select name="itemUse">'."\n");
				$resetItem	= array(7510,7511,7512,7513,7520);
				foreach($resetItem as $itemNo) {
					if($this->item[$itemNo]) {
						$item	= LoadItemData($itemNo);
						print('<option value="'.$itemNo.'">'.$item['name']." x".$this->item[$itemNo].'</option>'."\n");
					}
				}
				print("</select>\n");
				print('<input type="submit" class="btn" name="resetVarious" value="초기화">'."\n");
				print('<input type="submit" class="btn" value="취소">'."\n");
				print('</form>'."\n");
				print('</div>'."\n");
				break;

			// 각종 리셋의 처리
			case($_POST["resetVarious"]):
				switch($_POST["itemUse"]) {
					case 7510:
						$lowLimit	= 1;
						break;
					case 7511:
						$lowLimit	= 30;
						break;
					case 7512:
						$lowLimit	= 50;
						break;
					case 7513:
						$lowLimit	= 100;
						break;
					// skill
					case 7520:
						$skillReset	= true;
						break;
				}
				// 자갈을 SPD1으로 되돌리는 아이템으로 한다
				if($_POST["itemUse"] == 6000) {
					if($this->DeleteItem(6000) == 0) {
						ShowError("아이템이 없습니다.","margin15");
						return false;
					}
					if(1 < $char->spd) {
						$dif	= $char->spd - 1;
						$char->spd	-= $dif;
						$char->statuspoint	+= $dif;
						$char->SaveCharData($this->id);
						$this->SaveUserItem();
						ShowResult("포인트 환원 성공","margin15");
						return true;
					}
				}
				if($lowLimit) {
					if(!$this->item[$_POST["itemUse"]]) {
						ShowError("아이템이 없습니다.","margin15");
						return false;
					}
					if($lowLimit < $char->str) {$dif = $char->str - $lowLimit; $char->str -= $dif; $pointBack += $dif;}
					if($lowLimit < $char->int) {$dif = $char->int - $lowLimit; $char->int -= $dif; $pointBack += $dif;}
					if($lowLimit < $char->dex) {$dif = $char->dex - $lowLimit; $char->dex -= $dif; $pointBack += $dif;}
					if($lowLimit < $char->spd) {$dif = $char->spd - $lowLimit; $char->spd -= $dif; $pointBack += $dif;}
					if($lowLimit < $char->luk) {$dif = $char->luk - $lowLimit; $char->luk -= $dif; $pointBack += $dif;}
					if($pointBack) {
						if($this->DeleteItem($_POST["itemUse"]) == 0) {
							ShowError("아이템이 없습니다.","margin15");
							return false;
						}
						$char->statuspoint	+= $pointBack;
						// 장비도 전부 해제
						if($char->weapon || $char->shield || $char->armor || $char->item ) {
							if($char->weapon)	{ $this->AddItem($char->weapon);	$char->weapon	=NULL; }
							if($char->shield)	{ $this->AddItem($char->shield);	$char->shield	=NULL; }
							if($char->armor)	{ $this->AddItem($char->armor);		$char->armor	=NULL; }
							if($char->item)		{ $this->AddItem($char->item);		$char->item		=NULL; }
							ShowResult($char->Name()." 의 장비를 전부 해제했다","margin15");
						}
						$char->SaveCharData($this->id);
						$this->SaveUserItem();
						ShowResult("포인트 환원 성공","margin15");
						return true;
					} else {
						ShowError("포인트 환원 성공","margin15");
						return false;
					}
				}
				break;

			// 사요나라(표시)
			case($_POST["byebye"]):
				$Name	= $char->Name();
				$message = <<< HTML_BYEBYE
<div class="margin15">
{$Name} 을(를) 해고합니까?<br>
<form action="?char={$_GET['char']}" method="post">
<input type="submit" class="btn" name="kick" value="Yes">
<input type="submit" class="btn" value="No">
</form>
</div>
HTML_BYEBYE;
				print($message);
				return false;
			// 사요나라(처리)
			case($_POST["kick"]):
				//$this->DeleteChar($char->birth);
				$char->DeleteChar();
				$host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']));
				//$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				$extra = INDEX;
				header("Location: http://$host$uri/$extra");
				exit;
				break;
		endswitch;
	}
//////////////////////////////////////////////////////////////////////////////////////
//	캐릭터 상세 표시·장비 변경 등 등
//	너무 길다...(200행 이상)
	function CharStatShow() {
		$char	= &$this->char[$_GET["char"]];
		if(!$char) {
			print("Not exists");
			return false;
		}
		// 전투용 변수의 설정.
		$char->SetBattleVariable();

		// 직업 데이터
		$JobData	= LoadJobData($char->job);

		//전직 가능한 직업
		if($JobData["change"]) {
			include_once(DATA_CLASSCHANGE);
			foreach($JobData["change"] as $job) {
				if(CanClassChange($char,$job))
					$CanChange[]	= $job;//전직할 수 있는 캐릭터.
			}
		}

		////// 스테이터스 표시 //////////////////////////////
			?>
<form action="?char=<?=$_GET["char"]?>" method="post" style="padding:5px 0 0 15px"><?php 
		// 그 외 캐릭터
		print('<div style="padding-top:5px">');
		foreach($this->char as $key => $val) {
			//if($key == $_GET["char"]) break;//표시중 캐릭터 스킵
			echo "<a href=\"?char={$key}\">{$val->name}</a>&nbsp;&nbsp;";
		}
		print("</div>");
	?>
<h4>캐릭터 상태 <a href="?manual#charstat" target="_blank" class="a0">?</a></h4><?php 
		$char->ShowCharDetail();
		// 개명
		if($this->item["7500"])
			print('<input type="submit" class="btn" name="rename" value="이름 변경">'."\n");
		// 스테이터스 리셋 계
		if($this->item["7510"] ||
			$this->item["7511"] ||
			$this->item["7512"] ||
			$this->item["7513"] ||
			$this->item["7520"]) {
			print('<input type="submit" class="btn" name="showreset" value="초기화">'."\n");
		}
?>
<input type="submit" class="btn" name="byebye" value="해고">
</form><?php 
	// 스테이터스 상승 ////////////////////////////
	if(0 < $char->statuspoint) {
print <<< HTML
	<form action="?char={$_GET['char']}" method="post" style="padding:0 15px">
	<h4>상태 상승 <a href="?manual#statup" target="_blank" class="a0">?</a></h4>
HTML;

		$Stat	= array(
			"Str"=>"힘",
			"Int"=>"지능",
			"Dex"=>"민첩",
			"Spd"=>"스피드",
			"Luk"=>"운"
		);
		print("포인트 : {$char->statuspoint}<br />\n");
		foreach($Stat as $val => $label) {
			print("{$label}:\n");
			print("<select name=\"up{$val}\" class=\"vcent\">\n");
			for($i=0; $i < $char->statuspoint + 1; $i++)
				print("<option value=\"{$i}\">+{$i}</option>\n");
			print("</select>");
		}
		print("<br />");
		print('<input type="submit" class="btn" name="stup" value="상태 상승">');
		print("\n");

	print("</form>\n");
	}
	?>
	<form action="?char=<?=$_GET["char"]?>" method="post" style="padding:0 15px">
	<h4>행동 패턴 <a href="?manual#jdg" target="_blank" class="a0">?</a></h4><?php 

		// Action Pattern 행동 판정 /////////////////////////
		$list	= JudgeList();// 행동 판정 조건 일람
		print("<table cellspacing=\"5\"><tbody>\n");
		for($i=0; $i<$char->MaxPatterns(); $i++) {
			print("<tr><td>");
			//----- No
			print( ($i+1)."</td><td>");
			//----- JudgeSelect(판정의 종류)
			print("<select name=\"judge".$i."\">\n");
			foreach($list as $val) {//판단의 option
				$exp	= LoadJudgeData($val);
				print("<option value=\"{$val}\"".($char->judge[$i] == $val ? " selected" : NULL).($exp["css"]?' class="select0"':NULL).">".($exp["css"]?'&nbsp;':'&nbsp;&nbsp;&nbsp;')."{$exp['exp']}</option>\n");
			}
			print("</select>\n");
			print("</td><td>\n");
			//----- 수치(양)
			print("<input type=\"text\" name=\"quantity".$i."\" maxlength=\"4\" value=\"".$char->quantity[$i]."\" style=\"width:56px\" class=\"text\">");
			print("</td><td>\n");
			//----- //SkillSelect(기술의 종류)
			print("<select name=\"skill".$i."\">\n");
			foreach($char->skill as $val) {//기술의 option
				$skill	= LoadSkillData($val);
				print("<option value=\"{$val}\"".($char->action[$i] == $val ? " selected" : NULL).">");
				print($skill["name"].(isset($skill["sp"])?" - (SP:{$skill['sp']})":NULL));
				print("</option>\n");
			}
			print("</select>\n");
			print("</td><td>\n");
			print('<input type="radio" name="PatternNumber" value="'.$i.'">');
			print("</td></tr>\n");
		}
		print("</tbody></table>\n");
	?>
<input type="submit" class="btn" value="패턴 설정" name="ChangePattern">
<input type="submit" class="btn" value="추천 패턴 설정" name="RecommendPattern">
<input type="submit" class="btn" value="설정 및 시험" name="TestBattle">
&nbsp;<a href="?simulate">모의 전투</a><br />
<input type="submit" class="btn" value="패턴 전환" name="PatternMemo">
<input type="submit" class="btn" value="추가" name="AddNewPattern">
<input type="submit" class="btn" value="삭제" name="DeletePattern">
</form>
<form action="?char=<?=$_GET["char"]?>" method="post" style="padding:0 15px">
<h4>위치와 호위 <a href="?manual#posi" target="_blank" class="a0">?</a></h4>
<table><tbody>
<tr><td>위치 :</td><td><input type="radio" class="vcent" name="position" value="front"<?php  ($char->position=="front"?print(" checked") :NULL) ?>>전방</td></tr>
<tr><td></td><td><input type="radio" class="vcent" name="position" value="back"<?php  ($char->position=="back"?print(" checked") :NULL) ?>>후방</td></tr>
<tr><td>호위 :</td><td>
<select name="guard"><?php 

		// 전방때의 후방 방비 //////////////////////////////
		$option	= array(/*
		"always"=> "Always",
		"never"	=> "Never",
		"life25"	=> "If life more than 25%",
		"life50"	=> "If life more than 50%",
		"life75"	=> "If life more than 75%",
		"prob25"	=> "Probability of 25%",
		"prpb50"	=> "Probability of 50%",
		"prob75"	=> "Probability of 75%",
		*/
		"always"=> "반드시 지킨다",
		"never"	=> "지키지 않는다",
		"life25"	=> "체력이 25%이상이라면 지킨다",
		"life50"	=> "체력이 50%이상이라면 지킨다",
		"life75"	=> "체력이 75%이상이라면 지킨다",
		"prob25"	=> "25%의 확률로 지킨다",
		"prpb50"	=> "50%의 확률로 지킨다",
		"prob75"	=> "75%의 확률로 지킨다",
		);
		foreach($option as $key => $val)
			print("<option value=\"{$key}\"".($char->guard==$key ? " selected" : NULL ).">{$val}</option>");
	?>
	</select>
	</td></tr>
	</tbody></table>
	<input type="submit" class="btn" value="설정">
	</form>
<?php 
		// 장비중의 물건 표시 ////////////////////////////////
		$weapon	= LoadItemData($char->weapon);
		$shield	= LoadItemData($char->shield);
		$armor	= LoadItemData($char->armor);
		$item	= LoadItemData($char->item);

		$handle	= 0;
		$handle	= $weapon["handle"] + $shield["handle"] + $armor["handle"] + $item["handle"];
	?>
	<div style="margin:0 15px">
	<h4>장비 <a href="?manual#equip" target="_blank" class="a0">?</a></h4>
	<div class="bold u">현재 장비</div>
	<table>
	<tr><td class="dmg" style="text-align:right">공격력 :</td><td class="dmg"><?=$char->atk[0]?></td></tr>
	<tr><td class="spdmg" style="text-align:right">마법공격력 :</td><td class="spdmg"><?=$char->atk[1]?></td></tr>
	<tr><td class="recover" style="text-align:right">방어력 :</td><td class="recover"><?=$char->def[0]." + ".$char->def[1]?></td></tr>
	<tr><td class="support" style="text-align:right">마법방어력 :</td><td class="support"><?=$char->def[2]." + ".$char->def[3]?></td></tr>
	<tr><td class="charge" style="text-align:right">필요손 :</td><td class="charge"><?=$handle?> / <?=$char->GetHandle()?></td></tr>
	</table>
	<form action="?char=<?=$_GET["char"]?>" method="post">
	<table>
	<tr><td class="align-right">
	무기 :</td><td><input type="radio" class="vcent" name="spot" value="weapon"><?php ShowItemDetail(LoadItemData($char->weapon));?>
	</td></tr><tr><td class="align-right">
	방패 :</td><td><input type="radio" class="vcent" name="spot" value="shield"><?php ShowItemDetail(LoadItemData($char->shield));?>
	</td></tr><tr><td class="align-right">
	방어구 :</td><td><input type="radio" class="vcent" name="spot" value="armor"><?php ShowItemDetail(LoadItemData($char->armor));?>
	</td></tr><tr><td class="align-right">
	아이템 :</td><td><input type="radio" class="vcent" name="spot" value="item"><?php ShowItemDetail(LoadItemData($char->item));?>
	</td></tr></tbody>
		</table>
	<input type="submit" class="btn" name="remove" value="해제">
	<input type="submit" class="btn" name="remove_all" value="전부 해제">
	<input type="submit" class="btn" name="equip_best" value="전부 장착">
	</form>
	</div>
<?php 

		// 장비 가능한 것표시 ////////////////////////////////
		if($JobData["equip"])
			$EquipAllow	= array_flip($JobData["equip"]);//장비 가능한 것리스트(반전)
		else
			$EquipAllow	= array();//장비 가능한 것리스트(반전)
		$Equips		= array("Weapon"=>"2999","Shield"=>"4999","Armor"=>"5999","Item"=>"9999");

		print("<div style=\"padding:15px 15px 0 15px\">\n");
		print("\t<div class=\"bold u\">소지품 및 장비 가능 아이템</div>\n");
		if($this->item) {
			include(CLASS_JS_ITEMLIST);
			$EquipList	= new JS_ItemList();
			$EquipList->SetID("equip");
			$EquipList->SetName("type_equip");
			// JS를 사용하지 않는다.
			if($this->no_JS_itemlist)
				$EquipList->NoJS();
			reset($this->item);//이것이 없으면 장비 변경시에 표시되지 않는다
			foreach($this->item as $key => $val) {
				$item	= LoadItemData($key);
				if(!$item || !isset($item["type"]))
					continue;
				// 장비할 수 없기 때문에 다음
				if(!isset( $EquipAllow[ $item["type"] ] ))
					continue;
				$head	= '<input type="radio" name="item_no" value="'.$key.'" class="vcent">';
				$head	.= ShowItemDetail($item,$val,true)."<br />";
				$EquipList->AddItem($item,$head);
			}
			print($EquipList->GetJavaScript("list0"));
			print($EquipList->ShowSelect());
			print('<form action="?char='.$_GET["char"].'" method="post">'."\n");
			print('<div id="list0">'.$EquipList->ShowDefault().'</div>'."\n");
			print('<input type="submit" class="btn" name="equip_item" value="장비">'."\n");
			print("</form>\n");
		} else {
			print("아이템 없음<br />\n");
		}
		print("</div>\n");

		
		/*
		print("\t<table><tbody><tr><td colspan=\"2\">\n");
		print("\t<span class=\"bold u\">Stock & Allowed to Equip</span></td></tr>\n");
		if($this->item):
			reset($this->item);//이것이 없으면 장비 변경시에 표시되지 않는다
			foreach($Equips as $key => $val) {
				print("\t<tr><td class=\"align-right\" valign=\"top\">\n");
				print("\t{$key} :</td><td>\n");
				while( substr(key($this->item),0,4) <= $val && substr(current($this->item),0,4) !== false ) {
					$item	= LoadItemData(key($this->item));
					if(!isset( $EquipAllow[ $item["type"] ] )) {
						next($this->item);
						break;
					}
					print("\t");
					print('<input type="radio" class="vcent" name="item_no" value="'.key($this->item).'">');
					print("\n\t");
					print(current($this->item)."x");
					ShowItemDetail($item);
					print("<br>\n");
					next($this->item);
				}
				print("\t</td></tr>\n");
			}
		else:
			print("<tr><td>No items.</td></tr>");
		endif;
		print("\t</tbody></table>\n");
		*/
	?>
	<form action="?char=<?=$_GET["char"]?>" method="post" style="padding:0 15px">
	<h4>스킬 <a href="?manual#skill" target="_blank" class="a0">?</a></h4><?php 

		// 스킬 표시 //////////////////////////////////////
		//include(DATA_SKILL);//ActionPattern에 이동
		include_once(DATA_SKILL_TREE);
		if($char->skill) {
			print('<div class="u bold">습득 완료</div>');
			print("<table><tbody>");
			foreach($char->skill as $val) {
				print("<tr><td>");
				$skill	= LoadSkillData($val);
				ShowSkillDetail($skill);
				print("</td></tr>");
			}
			print("</tbody></table>");
			print('<div class="u bold">새 스킬 배우기</div>');
			print("스킬 포인트 : {$char->skillpoint}");
			print("<table><tbody>");
			$tree	= LoadSkillTree($char);
			foreach(array_diff($tree,$char->skill) as $val) {
				print("<tr><td>");
				$skill	= LoadSkillData($val);
				ShowSkillDetail($skill,1);
				print("</td></tr>");
			}
			print("</tbody></table>");
			//dump($char->skill);
			//dump($tree);
			print('<input type="submit" class="btn" name="learnskill" value="배우기">'."\n");
			print('<input type="hidden" name="learnskill" value="1">'."\n");
		}
		// 전직 ////////////////////////////////////////////
		if($CanChange) {
			?>

	</form>
	<form action="?char=<?=$_GET["char"]?>" method="post" style="padding:0 15px">
	<h4>ClassChange</h4>
	<table><tbody><tr><?php 
			foreach($CanChange as $job) {
				print("<td valign=\"bottom\" style=\"padding:5px 30px;text-align:center\">");
				$JOB	= LoadJobData($job);
				print('<img src="'.IMG_CHAR.$JOB["img_".($char->gender?"female":"male")].'">'."<br />\n");//화상
				print('<input type="radio" value="'.$job.'" name="job">'."<br />\n");
				print($JOB["name_".($char->gender?"female":"male")]);
				print("</td>");
			}
			?>

	</tr></tbody></table>
	<input type="submit" class="btn" name="classchange" value="ClassChange">
	<input type="hidden" name="classchange" value="1"><?php 
		}
	?>

	</form>
	<?php //그 외 캐릭터
		print('<div  style="padding:15px">');
		foreach($this->char as $key => $val) {
			//if($key == $_GET["char"]) break;//표시중 캐릭터 스킵
			echo "<a href=\"?char={$key}\">{$val->name}</a>&nbsp;&nbsp;";
		}
		print('</div>');
	}
//////////////////////////////////////////////////
//	('A`)...
	function CharTestDoppel() {
		if(!$_POST["TestBattle"]) return 0;

		$char	= $this->char[$_GET["char"]];
		$this->DoppelBattle(array($char));
	}
//////////////////////////////////////////////////
//	돕페르겐가와 싸운다.
	function DoppelBattle($party,$turns=10) {
		//$enemy	= $party;
		//이것이 없으면 PHP4or5 로 다른 결과가 됩니다
		//$enemy	= unserialize(serialize($enemy));
		// ↓
		foreach($party as $key => $char) {
			$enemy[$key]	= new char();
			$enemy[$key]->SetCharData(get_object_vars($char));
			
		}
		foreach($enemy as $key => $doppel) {
			//$doppel->judge	= array();//코멘트를 취하면 돕펠이 행동하지 않는다.
			$enemy[$key]->ChangeName("ニセ".$doppel->name);
		}
		//dump($enemy[0]->judge);
		//dump($party[0]->judge);

		include(CLASS_BATTLE);
		$battle	= new battle($party,$enemy);
		$battle->SetTeamName($this->name,"분신");
		$battle->LimitTurns($turns);//최대 턴수는 10
		$battle->NoResult();
		$battle->Process();//전투 개시
		return true;
	}
//////////////////////////////////////////////////
//
	function SimuBattleProcess() {
		if($_POST["simu_battle"]) {
			$this->MemorizeParty();//파티 기억
			// 자신 파티
			foreach($this->char as $key => $val) {//체크된 녀석 리스트
				if($_POST["char_".$key])
					$MyParty[]	= $this->char[$key];
			}
			if( count($MyParty) === 0) {
				ShowError('전투하려면  최저 1명 필요',"margin15");
				return false;
			} else if(5 < count($MyParty)) {
				ShowError('전투에 낼 수 있는 캐릭터는 5명까지',"margin15");
				return false;
			}
			$this->DoppelBattle($MyParty,50);
			return true;
		}
	}
//////////////////////////////////////////////////
//	
	function SimuBattleShow($message=false) {
		print('<div style="margin:15px">');
		ShowError($message);
		print('<span class="bold">모의 전투</span>');
		print('<h4>팀</h4></div>');
		print('<form action="'.INDEX.'?simulate" method="post">');
		$this->ShowCharacters($this->char,"CHECKBOX",explode("<>",(string)$this->party_memo));
			?>
	<div style="margin:15px;text-align:center">
	<input type="submit" class="btn" name="simu_battle" value="전투!">
	<input type="reset" class="btn" value="초기화"><br>
	이 파티 저장:<input type="checkbox" name="memory_party" value="1">
	</div></form>
		<?php 
	}
//////////////////////////////////////////////////
//	
	function HuntShow() {
		include(DATA_LAND);
		include(DATA_LAND_APPEAR);
		print('<div style="margin:15px">');
		print('<h4>일반 몬스터</h4>');
		print('<div style="margin:0 20px">');

		$mapList	= LoadMapAppear($this);
		foreach($mapList as $map) {
			list($land)	= LandInformation($map);
			print("<p><a href=\"?common={$map}\">{$land['name']}</a>");
			//print(" ({$land['proper']})");
			print("</p>");
		}

		// Union
		print("</div>\n");
		$files	= glob(UNION."*");
		if($files) {
			include(CLASS_UNION);
			include(DATA_MONSTER);
			foreach($files as $file) {
				$UnionMons	= new union($file);
				if($UnionMons->is_Alive())
					$Union[]	= $UnionMons;
			}
		}
		if($Union) {
			print('<h4>유니온 몬스터</h4>');
			$result = $this->CanUnionBattle();
			if($result !== true) {
				$left_minute	= floor($result/60);
				$left_second	= $result%60;
				print('<div style="margin:0 20px">');
				print('다음 전투까지 남은 시간 : <span class="bold">'.$left_minute. ":".sprintf("%02d",$left_second)."</span>");
				print("</div>");
			}
			print("</div>");
			$this->ShowCharacters($Union);
		} else {
			print("</div>");
		}

		// union
		print("<div style=\"margin:0 15px\">\n");
		print("<h4>유니온 전투 로그 <a href=\"?ulog\">전부표시</a></h4>\n");
		print("<div style=\"margin:0 20px\">\n");
		$log	= @glob(LOG_BATTLE_UNION."*");
		foreach(array_reverse($log) as $file) {
			$limit++;
			BattleLogDetail($file,"UNION");
			if(15 <= $limit)
				break;
		}
		print("</div></div>\n");
	}
//////////////////////////////////////////////////
//	몬스터의 표시
	function MonsterShow() {
		$land_id	= $_GET["common"];
		include(DATA_LAND);
		include_once(DATA_LAND_APPEAR);
		// 아직 갈 수 없는 맵인데 가려고 했다.
		if(!in_array($_GET["common"],LoadMapAppear($this))) {
			print('<div style="margin:15px">not appeared or not exist</div>');
			return false;
		}
		list($land,$monster_list)	= LandInformation($land_id);
		if(!$land || !$monster_list) {
			print('<div style="margin:15px">fail to load</div>');
			return false;
		}

		print('<div style="margin:15px">');
		ShowError($message);
		print('<span class="bold">'.$land["name"].'</span>');
		print('<h4>팀</h4></div>');
		print('<form action="'.INDEX.'?common='.$_GET["common"].'" method="post">');
		$this->ShowCharacters($this->char,"CHECKBOX",explode("<>",(string)$this->party_memo));
			?>
	<div style="margin:15px;text-align:center">
	<input type="submit" class="btn" name="monster_battle" value="전투!">
	<input type="reset" class="btn" value="초기화"><br>
	이 파티 저장:<input type="checkbox" name="memory_party" value="1">
	</div></form>
<?php 
		include(DATA_MONSTER);
		include(CLASS_MONSTER);
		foreach($monster_list as $id =>$val) {
			if($val[1])
				$monster[]	= new monster(CreateMonster($id));
		}
		print('<div style="margin:15px"><h4>출현 몬스터</h4></div>');
		$this->ShowCharacters($monster,"MONSTER",$land["land"]);
	}

//////////////////////////////////////////////////
//	몬스터와의 전투
	function MonsterBattle() {
		if($_POST["monster_battle"]) {
			if($this->MemorizeParty())
				$this->SaveData();//파티 기억
			// 그 맵으로 싸울 수 있을지 확인한다.
			include_once(DATA_LAND_APPEAR);
			$land	= LoadMapAppear($this);
			if(!in_array($_GET["common"],$land)) {
				ShowError("맵이 나와 있지 않다.","margin15");
				return false;
			}

			// Time가 충분하고 있는지 어떤지 확인한다
			if($this->time < NORMAL_BATTLE_TIME) {
				ShowError("시간 부족 (필요 시간:".NORMAL_BATTLE_TIME.")","margin15");
				return false;
			}
			// 자기 파티
			foreach($this->char as $key => $val) {//체크한 녀석 리스트
				if($_POST["char_".$key])
					$MyParty[]	= $this->char[$key];
			}
			if( count($MyParty) === 0) {
				ShowError('전투하려면  최저 1명 필요합니다',"margin15");
				return false;
			} else if(5 < count($MyParty)) {
				ShowError('전투에 나올 수 있는 캐릭터는 최대 5명까지',"margin15");
				return false;
			}
			// 적파티(또는 한마리)
			include(DATA_LAND);
			include(DATA_MONSTER);
			list($Land,$MonsterList)	= LandInformation($_GET["common"]);
			$EneNum	= $this->EnemyNumber($MyParty);
			$EnemyParty	= $this->EnemyParty($EneNum,$MonsterList);

			$this->WasteTime(NORMAL_BATTLE_TIME);//시간의 소비
			include(CLASS_BATTLE);
			$battle	= new battle($MyParty,$EnemyParty);
			$battle->SetBackGround($Land["land"]);//배경
			$battle->SetTeamName($this->name,$Land["name"]);
			$battle->Process();//전투개시
			$battle->SaveCharacters();//캐릭터 데이터 보존
			list($UserMoney)	= $battle->ReturnMoney();//전투로 얻은 합계 금액
			//돈을 늘린다
			$this->GetMoney($UserMoney);
			//전투 로그의 보존
			if($this->record_btl_log)
				$battle->RecordLog();

			// 아이템을 받는다
			if($itemdrop	= $battle->ReturnItemGet(0)) {
				$this->LoadUserItem();
				foreach($itemdrop as $itemno => $amount)
					$this->AddItem($itemno,$amount);
				$this->SaveUserItem();
			}

			//dump($itemdrop);
			//dump($this->item);
			return true;
		}
	}

//////////////////////////////////////////////////
	function ItemProcess() {
	}

//////////////////////////////////////////////////
//	
	function ItemShow() {
		?>
		<div style="margin:15px">
		<h4>아이템</h4>
		<div style="margin:0 20px">
<?php 
		if($this->item) {
			include(CLASS_JS_ITEMLIST);
			$goods	= new JS_ItemList();
			$goods->SetID("my");
			$goods->SetName("type");
			// JS를 사용하지 않는다
			if($this->no_JS_itemlist)
				$goods->NoJS();
			//$goods->ListTable("<table>");
			//$goods->ListTableInsert("<tr><td>No</td><td>Item</td></tr>");
			foreach($this->item as $no => $val) {
				$item	= LoadItemData($no);
				$string	= ShowItemDetail($item,$val,1)."<br />";
				//$string	= "<tr><td>".$no."</td><td>".ShowItemDetail($item,$val,1)."</td></tr>";
				$goods->AddItem($item,$string);
			}
			print($goods->GetJavaScript("list"));
			print($goods->ShowSelect());
			print('<div id="list">'.$goods->ShowDefault().'</div>');
		} else {
			print("아이템 없음.");
		}
		print("</div></div>");
	}
//////////////////////////////////////////////////
//	가게 헤더
	function ShopHeader() {
		?>
<div style="margin:15px">
<h4>가게</h4>

<div style="width:600px">
<div style="float:left;width:50px;">
<img src="<?=IMG_CHAR?>ori_002.gif" />
</div>
<div style="float:right;width:550px;">
어서오세요.<br />
무기부터 방어구까지 없는게 없는 가게입니다.<br />
필요하신 물건이 있다면 언제든지 구입해주세요.<br />
<a href="?menu=buy">산다</a> / <a href="?menu=sell">판다</a><br />
<a href="?menu=work">아르바이트</a>
</div>
<div style="clear:both"></div>
</div>

</div><?php 
	}
//////////////////////////////////////////////////
//
	function ShopProcess() {
		switch(true) {
			case($_POST["partjob"]):
				if($this->WasteTime(100)) {
					$this->GetMoney(500);
					ShowResult("열심히 일해서 ".MoneyFormat(500)." 을 받았다!!","margin15");
					return true;
				} else {
					ShowError("시간이 없다. 일을 하다니 시간이 아깝다..","margin15");
					return false;
				}
			case($_POST["shop_buy"]):
				$ShopList	= ShopList();//팔고 있는 것 데이터
				if($_POST["item_no"] && in_array($_POST["item_no"],$ShopList)) {
					if(preg_match("/^[0-9]/",$_POST["amount"])) {
						$amount	= (int)$_POST["amount"];
						if($amount == 0)
							$amount	= 1;
					} else {
						$amount	= 1;
					}
					$item	= LoadItemData($_POST["item_no"]);
					$need	= $amount * $item["buy"];//구입에 필요한 돈
					if($this->TakeMoney($need)) {// 돈을 위축될까로 판정.
						$this->AddItem($_POST["item_no"],$amount);
						$this->SaveUserItem();
						if(1 < $amount) {
							$img	= "<img src=\"".IMG_ICON.$item['img']."\" class=\"vcent\" />";
							ShowResult("{$img}{$item['name']} を{$amount}개 구입했다 (".MoneyFormat($item["buy"])." x{$amount} = ".MoneyFormat($need).")","margin15");
							return true;
						} else {
							$img	= "<img src=\"".IMG_ICON.$item['img']."\" class=\"vcent\" />";
							ShowResult("{$img}{$item['name']} 을(를) 구입했다 (".MoneyFormat($need).")","margin15");
							return true;
						}
					} else {//자금부족
						ShowError("자금부족(Need ".MoneyFormat($need).")","margin15");
						return false;
					}
				}
				break;
			case($_POST["shop_sell"]):
				if($_POST["item_no"] && $this->item[$_POST["item_no"]]) {
					if(preg_match("/^[0-9]/",$_POST["amount"])) {
						$amount	= (int)$_POST["amount"];
						if($amount == 0)
							$amount	= 1;
					} else {
						$amount	= 1;
					}
					// 지운 개수(초과해 팔리는 것도 막는다)
					$DeletedAmount	= $this->DeleteItem($_POST["item_no"],$amount);
					$item	= LoadItemData($_POST["item_no"]);
					$price	= (isset($item["sell"]) ? $item["sell"] : round($item["buy"]*SELLING_PRICE));
					$this->GetMoney($price*$DeletedAmount);
					$this->SaveUserItem();
					if($DeletedAmount != 1)
						$add	= " x{$DeletedAmount}";
					$img	= "<img src=\"".IMG_ICON.$item['img']."\" class=\"vcent\" />";
					ShowResult("{$img}{$item['name']}{$add} 을(를) ".MoneyFormat($price*$DeletedAmount)." 에 팔았다.","margin15");
					return true;
				}
				break;
		}
	}
//////////////////////////////////////////////////
//	
	function ShopShow($message=NULL) {
		?>
	<div style="margin:15px">
	<?=ShowError($message)?>
	<h4>Goods List</h4>
	<div style="margin:0 20px">
	<?php 
		include(CLASS_JS_ITEMLIST);
		$ShopList	= ShopList();//팔고 있는 것 데이터

		$goods	= new JS_ItemList();
		$goods->SetID("JS_buy");
		$goods->SetName("type_buy");
		// JS를 사용하지 않는다.
		if($this->no_JS_itemlist)
			$goods->NoJS();
		foreach($ShopList as $no) {
			$item	= LoadItemData($no);
			$string	= '<input type="radio" name="item_no" value="'.$no.'" class="vcent">';
			$string	.= "<span style=\"padding-right:10px;width:10ex\">".MoneyFormat($item["buy"])."</span>".ShowItemDetail($item,false,1)."<br />";
			$goods->AddItem($item,$string);
		}
		print($goods->GetJavaScript("list_buy"));
		print($goods->ShowSelect());

		print('<form action="?shop" method="post">'."\n");
		print('<div id="list_buy">'.$goods->ShowDefault().'</div>'."\n");
		print('<input type="submit" class="btn" name="shop_buy" value="산다">'."\n");
		print('수량 <input type="text" name="amount" style="width:60px" class="text vcent">(2개 이상이면 입력)<br />'."\n");
		print('<input type="hidden" name="shop_buy" value="1">');
		print('</form></div>'."\n");

		print("<h4>내 아이템<a name=\"sell\"></a></h4>\n");//소지물 판다
		print('<div style="margin:0 20px">'."\n");
		if($this->item) {
			$goods	= new JS_ItemList();
			$goods->SetID("JS_sell");
			$goods->SetName("type_sell");
			// JS를 사용하지 않는다.
			if($this->no_JS_itemlist)
				$goods->NoJS();
			foreach($this->item as $no => $val) {
				$item	= LoadItemData($no);
				$price	= (isset($item["sell"]) ? $item["sell"] : round($item["buy"]*SELLING_PRICE));
				$string	= '<input type="radio" class="vcent" name="item_no" value="'.$no.'">';
				$string	.= "<span style=\"padding-right:10px;width:10ex\">".MoneyFormat($price)."</span>".ShowItemDetail($item,$val,1)."<br />";
				$head	= '<input type="radio" name="item_no" value="'.$no.'" class="vcent">'.MoneyFormat($item["buy"]);
				$goods->AddItem($item,$string);
			}
			print($goods->GetJavaScript("list_sell"));
			print($goods->ShowSelect());
	
			print('<form action="?shop" method="post">'."\n");
			print('<div id="list_sell">'.$goods->ShowDefault().'</div>'."\n");
			print('<input type="submit" class="btn" name="shop_sell" value="판다">');
			print('수량 <input type="text" name="amount" style="width:60px" class="text vcent">(2개 이상이면 입력)'."\n");
			print('<input type="hidden" name="shop_sell" value="1">');
			print('</form>'."\n");
		} else {
			print("아이템 없음");
		}
		print("</div>\n");
/*
		if($this->item) {
			foreach($this->item as $no => $val) {
				$item	= LoadItemData($no);
				$price	= (isset($item["sell"]) ? $item["sell"] : round($item["buy"]*SELLING_PRICE));
				print('<input type="radio" class="vcent" name="item_no" value="'.$no.'">');
				print(MoneyFormat($price));
				print("&nbsp;&nbsp;&nbsp;{$val}x");
				ShowItemDetail($item);
				print("<br>");
			}
		} else
			print("아이템 없음<br>");
			print('수량 <input type="text" name="amount" style="width:50px" class="text vcent">(2개 이상이면 입력)<br />'."\n");
			print('<input type="submit" class="btn vcent" name="shop_sell" value="판다">');
		print('<input type="hidden" name="shop_sell" value="1">');
		print('</form>');*/
		?>
<form action="?shop" method="post">
<h4>아르바이트</h4>
<div style="margin:0 20px">
가게에서 아르바이트를 하고 돈을 법니다...<br />
<input type="submit" class="btn" name="partjob" value="상점에서 일하기">
100시간을 사용해 <?=MoneyFormat("500")?> 획득.
</form></div></div><?php 
	}

//////////////////////////////////////////////////
	function ShopBuyProcess() {
		//dump($_POST);
		if(!$_POST["ItemBuy"])
			return false;

		print("<div style=\"margin:15px\">");
		print("<table cellspacing=\"0\">\n");
		print('<tr><td class="td6" style="text-align:center">가격</td>'.
		'<td class="td6" style="text-align:center">수</td>'.
		'<td class="td6" style="text-align:center">계</td>'.
		'<td class="td6" style="text-align:center">아이템</td></tr>'."\n");
		$moneyNeed	= 0;
		$ShopList	= ShopList();
		foreach($ShopList as $itemNo) {
			if(!$_POST["check_".$itemNo])
continue;
			$item	= LoadItemData($itemNo);
if(!$item) continue;
			$amount	= (int)$_POST["amount_".$itemNo];
			if($amount < 0)
				$amount	= 0;
			
			//print("$itemNo x $Deleted<br>");
			$buyPrice	= $item["buy"];
			$Total	= $amount * $buyPrice;
			$moneyNeed	+= $Total;
			print("<tr><td class=\"td7\">");
			print(MoneyFormat($buyPrice)."\n");
			print("</td><td class=\"td7\">");
			print("x {$amount}\n");
			print("</td><td class=\"td7\">");
			print("= ".MoneyFormat($Total)."\n");
			print("</td><td class=\"td8\">");
			print(ShowItemDetail($item)."\n");
			print("</td></tr>\n");
			$this->AddItem($itemNo,$amount);
		}
		print("<tr><td colspan=\"4\" class=\"td8\">합계 : ".MoneyFormat($moneyNeed)."</td></tr>");
		print("</table>\n");
		print("</div>");
		if($this->TakeMoney($moneyNeed)) {
			$this->SaveUserItem();
			return true;
		} else {
			ShowError("돈이 부족합니다","margin15");
			return false;
		}
	}
//////////////////////////////////////////////////
	function ShopBuyShow() {
		print('<div style="margin:15px">'."\n");
		print("<h4>산다</h4>\n");

print <<< JS_HTML
<script type="text/javascript">
<!--
function toggleCSS(id) {
Element.toggleClassName('i'+id+'a', 'tdToggleBg');
Element.toggleClassName('i'+id+'b', 'tdToggleBg');
Element.toggleClassName('i'+id+'c', 'tdToggleBg');
Element.toggleClassName('i'+id+'d', 'tdToggleBg');
Field.focus('text_'+id);
}
function toggleCheckBox(id) {
if($('check_'+id).checked) {
  $('check_'+id).checked = false;
} else {
  $('check_'+id).checked = true;
  Field.focus('text_'+id);
}
toggleCSS(id);
}
// -->
</script>
JS_HTML;

		print('<form action="?menu=buy" method="post">'."\n");
		print("<table cellspacing=\"0\">\n");
		print('<tr><td class="td6"></td>'.
		'<td style="text-align:center" class="td6">가격</td>'.
		'<td style="text-align:center" class="td6">수</td>'.
		'<td style="text-align:center" class="td6">아이템</td></tr>'."\n");
		$ShopList	= ShopList();
		foreach($ShopList as $itemNo) {
			$item	= LoadItemData($itemNo);
if(!$item) continue;
			print("<tr><td class=\"td7\" id=\"i{$itemNo}a\">\n");
			print('<input type="checkbox" name="check_'.$itemNo.'" value="1" onclick="toggleCSS(\''.$itemNo.'\')">'."\n");
			print("</td><td class=\"td7\" id=\"i{$itemNo}b\" onclick=\"toggleCheckBox('{$itemNo}')\">\n");
			// 매입가
			$price	= $item["buy"];
			print(MoneyFormat($price));
			print("</td><td class=\"td7\" id=\"i{$itemNo}c\">\n");
			print('<input type="text" id="text_'.$itemNo.'" name="amount_'.$itemNo.'" value="1" style="width:60px" class="text">'."\n");
			print("</td><td class=\"td8\" id=\"i{$itemNo}d\" onclick=\"toggleCheckBox('{$itemNo}')\">\n");
			print(ShowItemDetail($item));
			print("</td></tr>\n");
		}
		print("</table>\n");
		print('<input type="submit" name="ItemBuy" value="산다" class="btn">'."\n");
		print("</form>\n");

		print("</div>\n");
	}
//////////////////////////////////////////////////
	function ShopSellProcess() {
		//dump($_POST);
		if(!$_POST["ItemSell"])
			return false;
		include_once(DATA_ITEM);

		$getMoney	= 0;
		$sold	= false;
		print("<div style=\"margin:15px\">");
		print("<table cellspacing=\"0\">\n");
		print('<tr><td class="td6" style="text-align:center">판매가</td>'.
		'<td class="td6" style="text-align:center">수</td>'.
		'<td class="td6" style="text-align:center">계</td>'.
		'<td class="td6" style="text-align:center">아이템</td></tr>'."\n");
		foreach($this->item as $itemNo => $amountHave) {
			if(!$_POST["check_".$itemNo])
				continue;
			$item	= LoadItemData($itemNo);
			if(!$item) continue;
			$amount	= (int)$_POST["amount_".$itemNo];
			if($amount < 1)
				continue;
			$Deleted	= $this->DeleteItem($itemNo,$amount);
			if($Deleted < 1)
				continue;
			$sold	= true;
			//print("$itemNo x $Deleted<br>");
			$sellPrice	= ItemSellPrice($item);
			$Total	= $Deleted * $sellPrice;
			$getMoney	+= $Total;
			print("<tr><td class=\"td7\">");
			print(MoneyFormat($sellPrice)."\n");
			print("</td><td class=\"td7\">");
			print("x {$Deleted}\n");
			print("</td><td class=\"td7\">");
			print("= ".MoneyFormat($Total)."\n");
			print("</td><td class=\"td8\">");
			print(ShowItemDetail($item)."\n");
			print("</td></tr>\n");
		}
		print("<tr><td colspan=\"4\" class=\"td8\">합계 : ".MoneyFormat($getMoney)."</td></tr>");
		print("</table>\n");
		print("</div>");
		if($sold) {
			$this->SaveUserItem();
			$this->GetMoney($getMoney);
		}
		return true;
	}
//////////////////////////////////////////////////
	function ShopSellShow() {
		print('<div style="margin:15px">'."\n");
		print("<h4>판다</h4>\n");

print <<< JS_HTML
<script type="text/javascript">
<!--
function toggleCSS(id) {
Element.toggleClassName('i'+id+'a', 'tdToggleBg');
Element.toggleClassName('i'+id+'b', 'tdToggleBg');
Element.toggleClassName('i'+id+'c', 'tdToggleBg');
Element.toggleClassName('i'+id+'d', 'tdToggleBg');
Field.focus('text_'+id);
}
function toggleCheckBox(id) {
if($('check_'+id).checked) {
  $('check_'+id).checked = false;
} else {
  $('check_'+id).checked = true;
  Field.focus('text_'+id);
}
toggleCSS(id);
}
// -->
</script>
JS_HTML;

		print('<form action="?menu=sell" method="post">'."\n");
		print("<table cellspacing=\"0\">\n");
		print('<tr><td class="td6"></td>'.
		'<td style="text-align:center" class="td6">가격</td>'.
		'<td style="text-align:center" class="td6">수</td>'.
		'<td style="text-align:center" class="td6">아이템</td></tr>'."\n");
		foreach($this->item as $itemNo => $amount) {
			$item	= LoadItemData($itemNo);
			if(!$item) continue;
			print("<tr><td class=\"td7\" id=\"i{$itemNo}a\">\n");
			print('<input type="checkbox" name="check_'.$itemNo.'" value="1" onclick="toggleCSS(\''.$itemNo.'\')">'."\n");
			print("</td><td class=\"td7\" id=\"i{$itemNo}b\" onclick=\"toggleCheckBox('{$itemNo}')\">\n");
			// 판매가
			$price	= ItemSellPrice($item);
			print(MoneyFormat($price));
			print("</td><td class=\"td7\" id=\"i{$itemNo}c\">\n");
			print('<input type="text" id="text_'.$itemNo.'" name="amount_'.$itemNo.'" value="'.$amount.'" style="width:60px" class="text">'."\n");
			print("</td><td class=\"td8\" id=\"i{$itemNo}d\" onclick=\"toggleCheckBox('{$itemNo}')\">\n");
			print(ShowItemDetail($item,$amount));
			print("</td></tr>\n");
		}
		print("</table>\n");
		print('<input type="submit" name="ItemSell" value="판다" class="btn" />'."\n");
		print('<input type="hidden" name="ItemSell" value="1" />'."\n");
		print("</form>\n");

		print("</div>\n");
	}
//////////////////////////////////////////////////
//	아르바이트 처리
	function WorkProcess() {
		if($_POST["amount"]) {
			$amount	= (int)$_POST["amount"];
			// 1이상 10 이하
			if(0 < $amount && $amount < 11) {
				$time	= $amount * 100;
				$money	= $amount * 500;
				if($this->WasteTime($time)) {
					ShowResult(MoneyFormat($money)." (을)를 얻었다!","margin15");
					$this->GetMoney($money);
					return true;
				} else {
					ShowError("시간이 부족합니다。","margin15");
					return false;
				}
			}
		}
	}
//////////////////////////////////////////////////
//	아르바이트 표시
	function WorkShow() {
		?>
<div style="margin:15px">
<h4>아르바이트를 한다!</h4>
<form method="post" action="?menu=work">
<p>1회 100시간<br />
급여 : <?=MoneyFormat(500)?>/회</p>
<select name="amount">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
</select><br />
<input type="submit" value="일하기" class="btn" />
</form>
</div>
<?php 
	}
//////////////////////////////////////////////////
	function RankProcess($Ranking) {

		// RankBattle
		if($_POST["ChallengeRank"]) {
			if(!$this->party_rank) {
				ShowError("팀이 결정되어 있지 않습니다.","margin15");
				return false;
			}
			$result	= $this->CanRankBattle();
			if(is_array($result)) {
				ShowError("대기시간이 아직 남아있습니다","margin15");
				return false;
			}

			/*
				$BattleResult = 0;//승리
				$BattleResult = 1;//패배
				$BattleResult = "d";//무승부
			*/
			//list($message,$BattleResult)	= $Rank->Challenge($this);
			$Result	= $Ranking->Challenge($this);

			//if($Result === "Battle")
			//	$this->RankRecord($BattleResult,"CHALLENGE",false);

			/*
			// 승패에 의해서 다음까지의 전투의 시간을 설정한다
			//승리
			if($BattleResult === 0) {
				$this->SetRankBattleTime(time() + RANK_BATTLE_NEXT_WIN);

			//패배
			} else if($BattleResult === 1) {
				$this->SetRankBattleTime(time() + RANK_BATTLE_NEXT_LOSE);

			//무승부
			} else if($BattleResult === "d") {
				$this->SetRankBattleTime(time() + RANK_BATTLE_NEXT_LOSE);

			}
			*/

			return $Result;// ??していれば $Result = "Battle";
		}

		// 랭킹용의 팀 등록
		if($_POST["SetRankTeam"]) {
			$now	= time();
			// 아직 설정 시간이 남아있다
			if(($now - $this->rank_set_time) < RANK_TEAM_SET_TIME) {
				$left	= RANK_TEAM_SET_TIME - ($now - $this->rank_set_time);
				$day	= floor($left / 3600 / 24);
				$hour	= floor($left / 3600)%24;
				$min	= floor(($left % 3600)/60);
				$sec	= floor(($left % 3600)%60);
				ShowError("팀 재설정 까지 앞으로 {$day}일과 {$hour}시간 {$min}분 {$sec}초","margin15");
				return false;
			}
			foreach($this->char as $key => $val) {//チェックされたやつリスト
				if($_POST["char_".$key])
					$checked[]	= $key;
			}
			// 設定キャラ?が多いか少なすぎる
			if(count($checked) == 0 || 5 < count($checked)) {
				ShowError("팀 인원수는 1명 이상 5명 이하가 아니면 안됩니다.","margin15");
				return false;
			}

			$this->party_rank	= implode("<>",$checked);
			$this->rank_set_time	= $now;
			ShowResult("팀 설정 완료","margin15");
			return true;
		}
	}
//////////////////////////////////////////////////
//	
	function RankShow($Ranking) {

		//$ProcessResult	= $this->RankProcess($Ranking);// array();

		//전투를 했으므로 표시하지 않는다.
		//if($ProcessResult === "BATTLE")
		//	return true;
		if($Ranking->EnsureUser($this->id))
			ShowResult("랭킹에 등록되었습니다.","margin15");

		// 팀재설정의 남은 시간 계산
		$now	= time();
		if( ($now - $this->rank_set_time) < RANK_TEAM_SET_TIME) {
			$left	= RANK_TEAM_SET_TIME - ($now - $this->rank_set_time);
			$hour	= floor($left / 3600);
			$min	= floor(($left % 3600)/60);
			$left_mes	= "<div class=\"bold\">다시 설정 가능까지 {$hour}시간 {$min}분 남음.</div>\n";
			$disable	= " disabled";
		}
			?>

	<div style="margin:15px">
	<?=ShowError($message)?>
	<form action="?menu=rank" method="post">
	<h4>랭킹 - <a href="?rank">전체 랭킹 보기</a>&nbsp;<a href="?manual#ranking" target="_blank" class="a0">?</a></h4>
	<?php
		// 도전할 수 있을지(시간의 경과로)
		$CanRankBattle	= $this->CanRankBattle();
		if($CanRankBattle !== true) {
			print('<p>다음 도전까지 남은 시간 : <span class="bold">');
			print($CanRankBattle[0].":".sprintf("%02d",$CanRankBattle[1]).":".sprintf("%02d",$CanRankBattle[2]));
			print("</span></p>\n");
			$disableRB	= " disabled";
		}

		print("<div style=\"width:100%;padding-left:30px\">\n");
		print("<div style=\"float:left;width:50%\">\n");
		print("<div class=\"u\">상위 5</div>\n");
		$Ranking->ShowRanking(0,4);
		print("</div>\n");
		print("<div style=\"float:right;width:50%\">\n");
		print("<div class=\"u\">근처 5</div>\n");
		$Ranking->ShowRankingRange($this->id,5);
		print("</div>\n");
		print("<div style=\"clear:both\"></div>\n");
		print("</div>\n");

		// 구랭크용
		//$Rank->dump();
		/*
		print("<table><tbody><tr><td style=\"padding:0 50px 0 0\">\n");
		print("<div class=\"bold u\">RANKING</div>");
		$Rank->ShowRanking(0,10);
		print("</td><td>");
		print("<div class=\"bold u\">Nearly</div>");
		$Rank->ShowNearlyRank($this->id);
		print("</td></tr></tbody></table>\n");
		*/
	?>
	<input type="submit" class="btn" value="도전!" name="ChallengeRank" style="width:160px"<?=$disableRB?> />
	</form>
	<form action="?menu=rank" method="post">
	<h4>팀 설정</h4>
	<p>랭킹 전용의 팀 설정.<br />
	여기서 설정한 팀에서 싸웁니다.</p>
	</div>
		<?php $this->ShowCharacters($this->char,"CHECKBOX",explode("<>",(string)$this->party_rank));?>

	<div style="margin:15px">
	<?=$left_mes?>
	<input type="submit" class="btn" style="width:160px" value="팀 설정"<?=$disable?> />
	<input type="hidden" name="SetRankTeam" value="1" />
	<p>설정 후,<?=$reset=floor(RANK_TEAM_SET_TIME/(60*60))?>시간은 변경할 수 없습니다.</p>
	</form>
	</div>
<?php 
	}
//////////////////////////////////////////////////
	function RecruitProcess() {

		// 고용수한계
		if( MAX_CHAR <= count(is_array($this->char) ? $this->char : array()) )
			return false;

		include(DATA_BASE_CHAR);
		if($_POST["recruit"]) {
			// 캐릭터의 타입
			switch($_POST["recruit_no"]) {
				case "1": $hire = 2000; $charNo	= 1; break;
				case "2": $hire = 2000; $charNo	= 2; break;
				case "3": $hire = 2500; $charNo	= 3; break;
				case "4": $hire = 4000; $charNo	= 4; break;
				default:
					ShowError("캐릭터를 선택해 주세요","margin15");
					return false;
			}
			// 이름 처리
			if($_POST["recruit_name"]) {
				if(is_numeric(strpos($_POST["recruit_name"],"\t")))
					return "error.";
				$name	= trim($_POST["recruit_name"]);
				$name	= stripslashes($name);
				$len	= strlen($name);
				if ( 0 == $len || 16 < $len ) {
					ShowError("이름이 너무 짧거나 깁니다","margin15");
					return false;
				}
				$name	= htmlspecialchars($name,ENT_QUOTES);
			} else {
				ShowError("이름을 입력해 주세요","margin15");
				return false;
			}
			//성별
			if( !isset($_POST["recruit_gend"]) ) {
				ShowError("성별을 선택해 주세요","margin15");
				return false;
			} else {
				$Gender	= $_POST["recruit_gend"]?"♀":"♂";
			}
			// 캐릭터 데이터를 클래스에 넣는다
			
			$plus	= array("name"=>"$name","gender"=>$_POST["recruit_gend"]);
			$char	= new char();
			$char->SetCharData(array_merge(BaseCharStatus($charNo),$plus));
			//고용금
			if($hire <= $this->money) {
				$this->TakeMoney($hire);
			} else {
				ShowError("お金が足りません","margin15");
				return false;
			}
			// 캐릭터를 보존한다
			$char->SaveCharData($this->id);
			ShowResult($char->Name()."($char->job_name:{$Gender}) 이(가) 동료가 되었습니다!","margin15");
			return true;
		}
	}

//////////////////////////////////////////////////
//	
	function RecruitShow() {
		if( MAX_CHAR <= $this->CharCount() ) {
			?>

	<div style="margin:15px">
	<p>캐릭터수가 한계에 이르고 있습니다.<br>
	새 캐릭터를 고용하려면 빈 자리가 필요합니다.</p>
	<p>캐릭터수가 한계에 이르고 있습니다.<br>
	새로운 캐릭터를 넣으려면  빈 곳이 필요합니다.</p>
	</div><?php 
			return false;
		}
		include_once(CLASS_MONSTER);
		$char[0]	= new char();
		$char[0]->SetCharData(array_merge(BaseCharStatus("1"),array("gender"=>"0")));
		$char[1]	= new char();
		$char[1]->SetCharData(array_merge(BaseCharStatus("1"),array("gender"=>"1")));
		$char[2]	= new char();
		$char[2]->SetCharData(array_merge(BaseCharStatus("2"),array("gender"=>"0")));
		$char[3]	= new char();
		$char[3]->SetCharData(array_merge(BaseCharStatus("2"),array("gender"=>"1")));
		$char[4]	= new char();
		$char[4]->SetCharData(array_merge(BaseCharStatus("3"),array("gender"=>"0")));
		$char[5]	= new char();
		$char[5]->SetCharData(array_merge(BaseCharStatus("3"),array("gender"=>"1")));
		$char[6]	= new char();
		$char[6]->SetCharData(array_merge(BaseCharStatus("4"),array("gender"=>"0")));
		$char[7]	= new char();
		$char[7]->SetCharData(array_merge(BaseCharStatus("4"),array("gender"=>"1")));
		?>

	<form action="?recruit" method="post" style="margin:15px">
	<h4>새 캐릭터 종류</h4>
	<table cellspacing="0"><tbody><tr>
	<td class="td1" style="text-align:center">
	<?php $char[0]->ShowImage()?><?php $char[1]->ShowImage()?><br>
	<input type="radio" name="recruit_no" value="1" style="margin:3px"><br>
	<?=MoneyFormat(2000)?></td>
	<td class="td1" style="text-align:center">
	<?php $char[2]->ShowImage()?><?php $char[3]->ShowImage()?><br>
	<input type="radio" name="recruit_no" value="2" style="margin:3px"><br>
	<?=MoneyFormat(2000)?></td>
	<td class="td1" style="text-align:center">
	<?php $char[4]->ShowImage()?><?php $char[5]->ShowImage()?><br>
	<input type="radio" name="recruit_no" value="3" style="margin:3px"><br>
	<?=MoneyFormat(2500)?></td>
	<td class="td1" style="text-align:center">
	<?php $char[6]->ShowImage()?><?php $char[7]->ShowImage()?><br>
	<input type="radio" name="recruit_no" value="4" style="margin:3px"><br>
	<?=MoneyFormat(4000)?></td>
	</tr><tr>
	<td class="td4" style="text-align:center">
	전사</td>
	<td class="td5" style="text-align:center">
	마법사</td>
	<td class="td4" style="text-align:center">
	사제</td>
	<td class="td5" style="text-align:center">
	사냥꾼</td>
	</tr>
	</tbody></table>

	<h4>새 캐릭터 이름과 성별</h4>
	<table><tbody><tr><td valign="top">
	<input type="text" class="text" name="recruit_name" style="width:160px" maxlength="16"><br>
	<div style="margin:5px 0px">
	<input type="radio" class="vcent" name="recruit_gend" value="0">남성
	<input type="radio" class="vcent" name="recruit_gend" value="1" style="margin-left:15px;">여성</div>
	<input type="submit" class="btn" name="recruit" value="고용">
	<input type="hidden" class="btn" name="recruit" value="고용">
	</td><td valign="top">
	<p>1~16글자까지 입력할 수 있습니다.<br>
	한글 1문자는 2글자로 계산됩니다.
	</p>
	</td></tr></tbody></table>
	</form><?php 
	}
//////////////////////////////////////////////////
//	대장간 제련 헤더
	function SmithyRefineHeader() {
	?>
<div style="margin:15px">
<h4>대장간</h4>

<div style="width:600px">
<div style="float:left;width:80px;">
<img src="<?=IMG_CHAR?>mon_053r.gif" />
</div>
<div style="float:right;width:520px;">
여기에서는 아이템의 제련을 할 수 있다네!<br />
제련하는 것과 제련 회수를 선택해 주게나.<br />
다만 망가져도 책임은 없다네. 허허허.<br />
내 아우가 하고 있는 <span class="bold">제작공방</span>은 <a href="?menu=create">저쪽</a> 이라네.
</div>
<div style="clear:both"></div>
</div>
<h4>아이템의 제련<a name="refine"></a></h4>
<div style="margin:0 20px"><?php 
	}
//////////////////////////////////////////////////
//	대장간 처리(제련)
	function SmithyRefineProcess() {
		if(!$_POST["refine"])
			return false;
		if(!$_POST["item_no"]) {
			ShowError("제련할 아이템을 선택해 주세요.");
			return false;
		}
		// 아이템을 읽어들일 수 없는 경우
		if(!$item	= LoadItemData($_POST["item_no"])) {
			ShowError("아이템 데이터를 읽을 수 없습니다.");
			return false;
		}
		// 아이템을 소지하고 있지 않는 경우
		if(!$this->item[$_POST["item_no"]]) {
			ShowError("\"{$item['name']}\" 아이템을 소지하고 있지 않습니다.");
			return false;
		}
		// 회수가 지정되어 있지 않은 경우
		if($_POST["timesA"] < $_POST["timesB"])
			$times	= $_POST["timesB"];
		else
			$times	= $_POST["timesA"];
		if(!$times || $times < 1 || (REFINE_LIMIT) < $times ) {
			ShowError("제련 횟수를 올바르게 선택해 주세요.");
			return false;
		}
		$bulkAmount	= max((int)$_POST["bulkAmountA"],(int)$_POST["bulkAmountB"]);
		if($bulkAmount < 1)
			$bulkAmount	= 1;
		if((int)$this->item[$_POST["item_no"]] < $bulkAmount) {
			ShowError("대량 제련 개수는 보유 수량 이하로 입력해 주세요.");
			return false;
		}
		include(CLASS_SMITHY);
		$obj_item	= new Item($_POST["item_no"]);
		// 그 아이템을 제련할 수 없는 경우
		if(!$obj_item->CanRefine()) {
			ShowError("\"{$item['name']}\" 아이템은 제련할 수 없습니다.");
			return false;
		}
		// 여기로부터 제련을 시작하는 처리
		$Price	= round($item["buy"]/2);
		$itemRefine	= isset($item["refine"]) ? (int)$item["refine"] : 0;
		// 최대 제련수의 조정.
		if( REFINE_LIMIT < ($itemRefine + $times) ) {
			$times	= REFINE_LIMIT - $itemRefine;
		}
		$MoneySum	= 0;
		$Trys	= 0;
		$Processed	= 0;
		$Success	= 0;
		$Failed	= 0;
		$MoneyShort	= false;
		for($bulk=0; $bulk<$bulkAmount; $bulk++) {
			$obj_item	= new Item($_POST["item_no"]);
			$this->DeleteItem($_POST["item_no"]);// 아이템은 사라지는지 변화하므로 지운다
			$Processed++;
			if(1 < $bulkAmount)
				print("<div class=\"margin15\">".($bulk+1)." / {$bulkAmount} 번째 제련</div>\n");
			for($i=0; $i<$times; $i++) {
				// 돈을 깎는다
				if($this->TakeMoney($Price)) {
					$MoneySum	+= $Price;
					$Trys++;
					if(!$obj_item->ItemRefine()) {//제련한다(false=실패이므로 종료한다)
						$Failed++;
						break;
					}
				// 돈이 도중에 없어졌을 경우.
				} else {
					ShowError("자금이 부족합니다.<br />\n");
					$this->AddItem($obj_item->ReturnItem());
					$MoneyShort	= true;
					break;
				}
				// 지정 회수 제련을 다 성공했을 경우.
				if($i == ($times - 1)) {
					$this->AddItem($obj_item->ReturnItem());
					$Success++;
				}
			}
			if($MoneyShort)
				break;
		}
		print("사용 자금 : ".MoneyFormat($Price)." x ".$Trys." = ".MoneyFormat($MoneySum)."<br />\n");
		if(1 < $bulkAmount)
			print("대량 제련 결과 : 처리 {$Processed}개 / 성공 {$Success}개 / 실패 {$Failed}개".($MoneyShort ? " / 자금 부족으로 중단" : "")."<br />\n");
		$this->SaveUserItem();
		return true;
		/*// 돈이 충분할때의 계산
		$Price	= round($item["buy"]/2);
		$MoneyNeed	= $times * $Price;
		if($this->money < $MoneyNeed) {
			ShowError("Your request needs ".MoneyFormat($MoneyNeed));
			return false;
		}*/
		
	}
//////////////////////////////////////////////////
//	대장간 표시
	function SmithyRefineShow() {
		// ■제련 처리
		//$Result	= $this->SmithyRefineProcess();

		// 제련 가능한 것의 표시
		if($this->item) {
			include(CLASS_JS_ITEMLIST);
			$possible	= CanRefineType();
			$possible	= array_flip($possible);
			//배열의 선두의 값이"0"이므로 1으로 한다(isset 사용하지 않고 true로 하기 위해)
			$possible[key($possible)]++;

			$goods	= new JS_ItemList();
			$goods->SetID("my");
			$goods->SetName("type");

			$goods->ListTable("<table cellspacing=\"0\">");// 테이블 태그의 시작
			$goods->ListTableInsert("<tr><td class=\"td9\"></td><td class=\"align-center td9\">제련 가능</td><td class=\"align-center td9\">아이템</td></tr>"); // 테이블의 최초와 마지막 행에 표시시키는 녀석.

			// JS를 사용하지 않는다.
			if($this->no_JS_itemlist)
				$goods->NoJS();
			foreach($this->item as $no => $val) {
				$item	= LoadItemData($no);
				// 제련 가능한 것만 표시시킨다.
				if(!$item || !isset($item["type"]) || !isset($possible[$item["type"]]))
					continue;
				$price	= $item["buy"]/2;
				// NoTable
	//			$string	= '<input type="radio" class="vcent" name="item_no" value="'.$no.'">';
	//			$string	.= "<span style=\"padding-right:10px;width:10ex\">".MoneyFormat($price)."</span>".ShowItemDetail($item,$val,1)."<br />";

				$string	= '<tr>';
				$string	.= '<td class="td7"><input type="radio" class="vcent" name="item_no" value="'.$no.'">';
				$string	.= '</td><td class="td7">'.MoneyFormat($price).'</td><td class="td8">'.ShowItemDetail($item,$val,1)."<td>";
				$string	.= "</tr>";

				$goods->AddItem($item,$string);
			}
			// JavaScript 부분의 서두
			print($goods->GetJavaScript("list"));
			print('제련 가능한 물건들의 목록');
			// 종류의 셀렉트 박스
			print($goods->ShowSelect());
			print('<form action="?menu=refine" method="post">'."\n");
			// 제련 버튼
			print('<input type="submit" value="제련" name="refine" class="btn">'."\n");
			// 제련 회수의 지정
			print('회수 : <select name="timesA">'."\n");
			for($i=1; $i<11; $i++) {
				print('<option value="'.$i.'">'.$i.'</option>');
			}
			print('</select>'."\n");
			print(' 대량 개수 : <input type="text" name="bulkAmountA" value="1" maxlength="4" style="width:48px" class="text">'."\n");
			// 리스트의 표시
			print('<div id="list">'.$goods->ShowDefault().'</div>'."\n");
			// 제련 버튼
			print('<input type="submit" value="제련" name="refine" class="btn">'."\n");
			print('<input type="hidden" value="1" name="refine">'."\n");
			// 제련 회수의 지정
			print('회수 : <select name="timesB">'."\n");
			for($i=1; $i<(REFINE_LIMIT+1); $i++) {
				print('<option value="'.$i.'">'.$i.'</option>');
			}
			print('</select>'."\n");
			print(' 대량 개수 : <input type="text" name="bulkAmountB" value="1" maxlength="4" style="width:48px" class="text">'."\n");
			print('</form>'."\n");
		} else {
			print("아이템 없음<br />\n");
		}
		print("</div>\n");
	?>
	</div>
<?php 
	}
//////////////////////////////////////////////////
//	대장간 제작 헤더
	function SmithyCreateHeader() {
		?>
<div style="margin:15px">
<h4>대장간<a name="sm"></a></h4>
<div style="width:600px">
<div style="float:left;width:80px;">
<img src="<?=IMG_CHAR?>mon_053rz.gif" />
</div>
<div style="float:right;width:520px;">
안녕하신가, 모험가 양반<br />
여기에서는 아이템의 제작을 할 수 있다네!<br />
당신이 가지고 있는 아이템으로 장비를 만들 수 있다네.<br />
특별한 소재를 갖고 있다면 특수한 무기도 만들 수 있지.<br />
형님이 하고 있는 <span class="bold">제련공방</span>은 <a href="?menu=refine">이쪽</a>이니 가끔 이용해주게.<br />
<a href="#mat">소지중인 소재 목록</a>
</div>
<div style="clear:both"></div>
</div>
<h4>아이템의 제작<a name="refine"></a></h4>
<div style="margin:0 15px"><?php 
	}
//////////////////////////////////////////////////
//	제작 처리
	function SmithyCreateProcess() {
		if(!$_POST["Create"]) return false;

		// 아이템이 선택되어 있지 않다
		if(!$_POST["ItemNo"]) {
			ShowError("제작하는 아이템을 선택해 주세요");
			return false;
		}

		// 아이템을 읽는다
		if(!$item	= LoadItemData($_POST["ItemNo"])) {
			ShowError("error12291703");
			return false;
		}

		// 만들 수 있는 아이템인지 어떤지 확인한다
		if(!HaveNeeds($item,$this->item)) {
			ShowError($item["name"]." 을(를) 제작하는 소재가 충분하지 않습니다.");
			return false;
		}

		// 추가 소재
		if($_POST["AddMaterial"]) {
			// 소지하고 있지 않는 경우
			if(!$this->item[$_POST["AddMaterial"]]) {
				ShowError("그 추가 소재는 없습니다.");
				return false;
			}
			// 추가 소재의 아이템 데이터
			$ADD	= LoadItemData($_POST["AddMaterial"]);
			$this->DeleteItem($_POST["AddMaterial"]);
		}

		// 아이템의 제작
		// 돈을 줄인다
		//$Price	= $item["buy"];
		$Price	= 0;
		if(!$this->TakeMoney($Price)) {
			ShowError("돈이 부족합니다.".MoneyFormat($Price)."이(가) 필요합니다.");
			return false;
		}
		// 소재를 줄인다
		foreach($item["need"] as $M_item => $M_amount) {
			$this->DeleteItem($M_item,$M_amount);
		}
		include(CLASS_SMITHY);
		$item	= new item($_POST["ItemNo"]);
		$item->CreateItem();
		// 부가 효과
		if($ADD["Add"])
			$item->AddSpecial($ADD["Add"]);
		// 할 수 있던 아이템을 보존한다
		$done	= $item->ReturnItem();
		$this->AddItem($done);
		$this->SaveUserItem();

		print("<p>");
		print(ShowItemDetail(LoadItemData($done)));
		
		print("\n<br />가 완성되었다!</p>\n");
		return true;
	}
//////////////////////////////////////////////////
//	제작 표시
	function SmithyCreateShow() {
		//$result	= $this->SmithyCreateProcess();

		$CanCreate	= CanCreate($this);
		include(CLASS_JS_ITEMLIST);
		$CreateList	= new JS_ItemList();
		$CreateList->SetID("create");
		$CreateList->SetName("type_create");

		$CreateList->ListTable("<table cellspacing=\"0\">");// 테이블 태그의 시작
		$CreateList->ListTableInsert("<tr><td class=\"td9\"></td><td class=\"align-center td9\">제작비</td><td class=\"align-center td9\">아이템</td></tr>"); // 테이블의 최초와 마지막 행에 표시시키는 녀석

		// JS를 사용하지 않는다.
		if($this->no_JS_itemlist)
			$CreateList->NoJS();
		foreach($CanCreate as $item_no) {
			$item	= LoadItemData($item_no);
			if(!HaveNeeds($item,$this->item))// 소재 부족하면 다음
				break;
			// NoTable
			//$head	= '<input type="radio" name="ItemNo" value="'.$item_no.'">'.ShowItemDetail($item,false,1,$this->item)."<br />";
			//$CreatePrice	= $item["buy"];
			$CreatePrice	= 0;//
			$head	= '<tr><td class="td7"><input type="radio" name="ItemNo" value="'.$item_no.'"></td>';
			$head	.= '<td class="td7">'.MoneyFormat($CreatePrice).'</td><td class="td8">'.ShowItemDetail($item,false,1,$this->item)."</td>";
			$CreateList->AddItem($item,$head);
		}
		if($head) {
			print($CreateList->GetJavaScript("list"));
			print($CreateList->ShowSelect());
		?>
<form action="?menu=create" method="post">
<div id="list"><?=$CreateList->ShowDefault()?></div>
<input type="submit" class="btn" name="Create" value="제작">
<input type="reset" class="btn" value="초기화">
<input type="hidden" name="Create" value="1"><br />
<?php 
		// 추가 소재의 표시
		print('<div class="bold u" style="margin-top:15px">추가 소재</div>'."\n");
		for($item_no=7000; $item_no<7200; $item_no++) {
			if(!$this->item["$item_no"])
				break;
			if($item	= LoadItemData($item_no)) {
				print('<input type="radio" name="AddMaterial" value="'.$item_no.'" class="vcent">');
				print(ShowItemDetail($item,$this->item["$item_no"],1)."<br />\n");
			}
		}
		?>
<input type="submit" class="btn" name="Create" value="제작">
<input type="reset" class="btn" value="초기화">
</form>
<?php 
		} else {
			print("네가 가지고 있는 소재는.. 뭐, 만들 수 있을게 없을 것 같은데..");
		}


		// 所持素材一?
		print("</div>\n");
		print("<h4>소지 소재 일람<a name=\"mat\"></a> <a href=\"#sm\">↑</a></h4>");
		print("<div style=\"margin:0 15px\">");
		for($i=6000; $i<7000; $i++) {
			if(!$this->item["$i"])
				break;
			$item	= LoadItemData($i);
			ShowItemDetail($item,$this->item["$i"]);
			print("<br />\n");
		}
		?>
</div>
</div>
<?php 
		return $result;
	}
//////////////////////////////////////////////////
//	멤버가 되는 처리
	function AuctionJoinMember() {
		if(!$_POST["JoinMember"])
			return false;
		if($this->item["9000"]) {//이미 회원
			//ShowError("You are already a member.\n");
			return false;
		}
		// 돈이 부족하다
		if(!$this->TakeMoney(round(START_MONEY * 1.10))) {
			ShowError("돈이 부족합니다<br />\n");
			return false;
		}
		// 아이템을 더한다
		$this->AddItem(9000);
		$this->SaveUserItem();
		$this->SaveData();
		ShowResult("옥션 회원이 되었습니다.<br />\n");
		return true;
	}
//////////////////////////////////////////////////
//	
	function AuctionEnter() {
		if($this->item["9000"])//옥션 멤버 카드
			return true;
		else
			return false;
	}
//////////////////////////////////////////////////
//	옥션의 표시(header)
	function AuctionHeader() {
		?>
<div style="margin:15px 0 0 15px">
<h3>옥션(Auction)</h4>
<div style="margin-left:20px">

<div style="width:500px">
<div style="float:left;width:50px;">
<img src="<?=IMG_CHAR?>ori_003.gif" />
</div>
<div style="float:right;width:450px;"><?php 

		$this->AuctionJoinMember();
		if($this->AuctionEnter()) {
			print("고객은 회원증을 가지고 있네요.<br />\n");
			print("옥션 회장에 어서 오세요.<br />\n");
			print("<a href=\"#log\">옥션 로그</a>\n");
		} else {
			print("옥션에의 출품·입찰에는 입회가 필요합니다.<br />n");
			print("입찰비는&nbsp;".MoneyFormat(round(START_MONEY * 1.10))."&nbsp;입니다.<br />\n");
			print("입회합니까?<br />n");
			print('<form action="" method="post">'."\n");
			print('<input type="submit" value="입회한다" name="JoinMember" class="btn"/>'."\n");
			print("</form>\n");
		}
		if(!AUCTION_TOGGLE)
			ShowError("기능 정지중");
		if(!AUCTION_EXHIBIT_TOGGLE)
			ShowError("출품 정지중");
		?>
</div>
<div style="clear:both"></div>
</div>
</div>
<h3>아이템 옥션(Item Auction)</h4>
<div style="margin-left:20px"><?php 
	}
//////////////////////////////////////////////////
//	옥션의 표시
	function AuctionFoot($ItemAuction) {
		?>
</div>
<a name="log"></a>
<h4>옥션 로그(AuctionLog)</h4>
<div style="margin-left:20px">
<?php $ItemAuction->ShowLog();?>
</div><?php 
	}
//////////////////////////////////////////////////
//	입찰 처리
	function AuctionItemBiddingProcess($ItemAuction) {
		if(!$this->AuctionEnter())
			return false;
		if(!isset($_POST["ArticleNo"]))
			return false;

		$ArticleNo	= $_POST["ArticleNo"];
		$BidPrice	= (int)$_POST["BidPrice"];
		if($BidPrice < 1) {
			ShowError("입찰 가격에 잘못이 있습니다.");
			return false;
		}
		// 아직 출품중인지 어떤지 확인한다.
		if(!$ItemAuction->ItemArticleExists($ArticleNo)) {
			ShowError("그 경매품의 출품을 확인할 수 없습니다.");
			return false;
		}
		// 자신이 입찰할 수 있는 사람인지 어떤지의 확인
		if(!$ItemAuction->ItemBidRight($ArticleNo,$this->id)) {
			ShowError("No.".$ArticleNo." 는 입찰이 끝난 상태나 출품자입니다.");
			return false;
		}
		// 최저 입찰 가격을 나누지 않은가 확인한다.
		$Bottom	= $ItemAuction->ItemBottomPrice($ArticleNo);
		if($BidPrice < $Bottom) {
			ShowError("최저 입찰 가격을 밑돌고 있습니다.");
			ShowError("제시 입찰 가격:".MoneyFormat($BidPrice)." 최저 입찰 가격:".MoneyFormat($Bottom));
			return false;
		}
		// 부자비치는지 확인한다
		if(!$this->TakeMoney($BidPrice)) {
			ShowError("소지금이 부족한 것 같습니다.");
			return false;
		}

		// 실제로 입찰한다.
		if($ItemAuction->ItemBid($ArticleNo,$BidPrice,$this->id,$this->name)) {
			ShowResult("No:{$ArticleNo}&nbsp;에&nbsp;".MoneyFormat($BidPrice)."&nbsp;로 입찰하였습니다.<br />\n");
			return true;
		}
	}
//////////////////////////////////////////////////
//	아이템 옥션용의 오브젝트를 읽어 돌려준다
/*
	function AuctionItemLoadData() {
		include(CLASS_AUCTION);
		$ItemAuction	= new Auction(item);
		$ItemAuction->ItemCheckSuccess();// 경매가 종료한 물건을 조사한다
		$ItemAuction->UserSaveData();// 경매품과 금액을 각 ID에 나눠주어 보존한다

		return $ItemAuction;
	}
*/
//////////////////////////////////////////////////
//	입찰용 폼(화면)
	function AuctionItemBiddingForm($ItemAuction) {

		if(!AUCTION_TOGGLE)
			return false;

		// 출품용 폼에 가는 버튼
		if($this->AuctionEnter()) {
			// 입회하고 있었던 경우 입찰할 수 있도록
			$ItemAuction->ItemSortBy($_GET["sort"]);
			$ItemAuction->ItemShowArticle2(true);

			if(AUCTION_EXHIBIT_TOGGLE) {
				print("<form action=\"?menu=auction\" method=\"post\">\n");
				print('<input type="submit" value="Put Auction" name="ExhibitItemForm" class="btn" style="width:160px">'."\n");
				print("</form>\n");
			}

		} else {
			// 입찰할 수 없다
			$ItemAuction->ItemShowArticle2(false);
		}
	}
//////////////////////////////////////////////////
//	아이템 출품 처리
	function AuctionItemExhibitProcess($ItemAuction) {

		if(!AUCTION_EXHIBIT_TOGGLE)
			return "BIDFORM";// 출품 동결

		// 보존하지 않고 출품 리스트를 표시한다
		if(!$this->AuctionEnter())
			return "BIDFORM";
		if(!$_POST["PutAuction"])
			return "BIDFORM";

		if(!$_POST["item_no"]) {
			ShowError("출품할 아이템을 선택해 주세요.");
			return false;
		}
		// 세션에 의한 30초간의 출품 거부
		$SessionLeft	= 30 - (time() - $_SESSION["AuctionExhibit"]);
		if($_SESSION["AuctionExhibit"] && 0 < $SessionLeft) {
			ShowError("다시 출품하려면 {$SessionLeft}초 기다려 주세요.");
			return false;
		}
		// 동시 출품수의 제한
		if(AUCTION_MAX <= $ItemAuction->ItemAmount()) {
			ShowError("출품 수가 한계에 도달했습니다.(".$ItemAuction->ItemAmount()."/".AUCTION_MAX.")");
			return false;
		}
		// 출품 비용
		if(!$this->TakeMoney(500)) {
			ShowError("경매에 출품하려면 ".MoneyFormat(500)." 이 필요합니다.");
			return false;
		}
		// 아이템을 읽어들일 수 없는 경우
		if(!$item	= LoadItemData($_POST["item_no"])) {
			ShowError("아이템 데이터를 읽을 수 없습니다.");
			return false;
		}
		// 아이템을 소지하고 있지 않는 경우
		if(!$this->item[$_POST["item_no"]]) {
			ShowError("\"{$item['name']}\" 아이템을 소지하고 있지 않습니다.");
			return false;
		}
		// 그 아이템을 출품할 수 없는 경우
		$possible	= CanExhibitType();
		if(!$possible[$item["type"]]) {
			ShowError("Cant put \"{$item['name']}\" to the Auction");
			return false;
		}
		// 출품 시간의 확인
		if(	!(	$_POST["ExhibitTime"] === '1' ||
				$_POST["ExhibitTime"] === '3' ||
				$_POST["ExhibitTime"] === '6' ||
				$_POST["ExhibitTime"] === '12' ||
				$_POST["ExhibitTime"] === '18' ||
				$_POST["ExhibitTime"] === '24') ) {
			var_dump($_POST);
			ShowError("time?");
			return false;
		}
		// 수량의 확인
		if(preg_match("/^[0-9]/",$_POST["Amount"])) {
			$amount	= (int)$_POST["Amount"];
			if($amount == 0)
				$amount	= 1;
		} else {
			$amount	= 1;
		}
		// 줄인다(소지수보다 많이 지정되었을 경우 그 수를 조절한다)
		$_SESSION["AuctionExhibit"]	= time();//세션으로 2 중출품을 막는다
		$amount	= $this->DeleteItem($_POST["item_no"],$amount);
		$this->SaveUserItem();

		// 출품한다
		// $ItemAuction	= new Auction(item);// (2008/2/28:コメント化)
		$ItemAuction->ItemAddArticle($_POST["item_no"],$amount,$this->id,$_POST["ExhibitTime"],$_POST["StartPrice"],$_POST["Comment"]);
		print($item["name"]."&nbsp;을(를)&nbsp;{$amount}개&nbsp;출품하였습니다");
		return true;
	}
//////////////////////////////////////////////////
//	出品用フォ?ム
	function AuctionItemExhibitForm() {

		if(!AUCTION_EXHIBIT_TOGGLE)
			return false;

		include(CLASS_JS_ITEMLIST);
		$possible	= CanExhibitType();
		?>
<div class="u bold">출품 방법</div>
<ol>
<li>출품하는 아이템을 선택합니다.</li>
<li>2개 이상 출품하는 경우, 수량을 입력합니다.</li>
<li>출품하고 있는 기간의 길이를 지정합니다.</li>
<li>개시 가격을 지정합니다(기입 없음 = 0)</li>
<li>코멘트가 있으면 입력합니다.</li>
<li>송신합니다.</li>
</ol>
<div class="u bold">주의 사항</div>
<ul>
<li>출품에는 수수료로 $500 가 필요합니다.</li>
<li>(개발자 코멘트)잘 작동하려나 이거..</li>
</ul>
<a href="?menu=auction">일람으로 돌아온다</a>
</div>
<h4>출품한다</h4>
<div style="margin-left:20px">
<div class="u bold">출품 가능한 물건의 일람</div>
<?php 
		if(!$this->item) {
			print("아이템 없음<br />\n");
			return false;
		}
		$ExhibitList	= new JS_ItemList();
		$ExhibitList->SetID("auc");
		$ExhibitList->SetName("type_auc");
		// JS를 사용하지 않는다.
		if($this->no_JS_itemlist)
			$ExhibitList->NoJS();
		foreach($this->item as $no => $amount) {
			$item	= LoadItemData($no);
			if(!$possible[$item["type"]])
				break;
			$head	= '<input type="radio" name="item_no" value="'.$no.'" class="vcent">';
			$head	.= ShowItemDetail($item,$amount,1)."<br />";
			$ExhibitList->AddItem($item,$head);
		}
		print($ExhibitList->GetJavaScript("list"));
		print($ExhibitList->ShowSelect());
		?>
<form action="?menu=auction" method="post">
<div id="list"><?=$ExhibitList->ShowDefault()?></div>
<table><tr><td style="text-align:right">
수량(Amount) :</td><td><input type="text" name="Amount" class="text" style="width:60px" value="1" /><br />
</td></tr><tr><td style="text-align:right">
기간(Time) :</td><td>
<select name="ExhibitTime">
<option value="24" selected>24 hour</option>
<option value="18">18 hour</option>
<option value="12">12 hour</option>
<option value="6">6 hour</option>
<option value="3">3 hour</option>
<option value="1">1 hour</option>
</select>
</td></tr><tr><td>
시작금액(Start Price) :</td><td><input type="text" name="StartPrice" class="text" style="width:240px" maxlength="10"><br />
</td></tr><tr><td style="text-align:right">
코멘트(Comment) :</td><td>
<input type="text" name="Comment" class="text" style="width:240px" maxlength="40">
</td></tr><tr><td></td><td>
<input type="submit" class="btn" value="Put Auction" name="PutAuction" style="width:240px"/>
<input type="hidden" name="PutAuction" value="1">
</td></tr></table>
</form>

<?php 
		
	}
//////////////////////////////////////////////////
//	Union 몬스터의 처리
	function UnionProcess() {

		if($this->CanUnionBattle() !== true) {
			$host  = $_SERVER['HTTP_HOST'];
			$uri   = rtrim(dirname($_SERVER['PHP_SELF']));
			$extra = INDEX;
			header("Location: http://$host$uri/$extra?hunt");
			exit;
		}

		if(!$_POST["union_battle"])
			return false;
		$Union	= new union();
		// 쓰러지고 있는지, 존재하지 않는 경우.
		if(!$Union->UnionNumber($_GET["union"]) || !$Union->is_Alive()) {
			return false;
		}
		// 유니온 몬스터의 데이터
		$UnionMob	= CreateMonster($Union->MonsterNumber);
		$this->MemorizeParty();//파티 기억
		// 자신 파티
		foreach($this->char as $key => $val) {//체크한 녀석 리스트
			if($_POST["char_".$key]) {
				$MyParty[]	= $this->char[$key];
				$TotalLevel	+= $this->char[$key]->level;//자신 PT의 합계 레벨
			}
		}
		// 합계 레벨 제한
		if($UnionMob["LevelLimit"] < $TotalLevel) {
			ShowError('합계 레벨 오버('.$TotalLevel.'/'.$UnionMob["LevelLimit"].')',"margin15");
			return false;
		}
		if( count($MyParty) === 0) {
			ShowError('전투하려면  최저 1명 필요',"margin15");
			return false;
		} else if(5 < count($MyParty)) {
			ShowError('전투에 낼 수 있는 캐릭터는 5명까지',"margin15");
			return false;
		}
		if(!$this->WasteTime(UNION_BATTLE_TIME)) {
			ShowError('시간이 부족합니다.',"margin15");
			return false;
		}

		// 적PT수

		// 랜덤적파티
		if($UnionMob["SlaveAmount"])
			$EneNum	= $UnionMob["SlaveAmount"] + 1;//PT멤버와 같은 수만큼.
		else
			$EneNum	= 5;// Union 포함해 5에 고정한다.

		if($UnionMob["SlaveSpecify"])
			$EnemyParty	= $this->EnemyParty($EneNum-1, $Union->Slave, $UnionMob["SlaveSpecify"]);
		else
			$EnemyParty	= $this->EnemyParty($EneNum-1, $Union->Slave, $UnionMob["SlaveSpecify"]);

		// unionMob를 배열의 대략 중앙에 들어갈 수 있다
		array_splice($EnemyParty,floor(count($EnemyParty)/2),0,array($Union));

		$this->UnionSetTime();

		include(CLASS_BATTLE);
		$battle	= new battle($MyParty,$EnemyParty);
		$battle->SetUnionBattle();
		$battle->SetBackGround($Union->UnionLand);//배경
		//$battle->SetTeamName($this->name,"Union:".$Union->Name());
		$battle->SetTeamName($this->name,$UnionMob["UnionName"]);
		$battle->Process();//전투 개시

		$battle->SaveCharacters();//캐릭터 데이터 보존
			list($UserMoney)	= $battle->ReturnMoney();//전투로 얻은 합계 금액
			$this->GetMoney($UserMoney);//돈을 늘린다
			$battle->RecordLog("UNION");
			// 아이템을 받는다
			if($itemdrop	= $battle->ReturnItemGet(0)) {
				$this->LoadUserItem();
				foreach($itemdrop as $itemno => $amount)
					$this->AddItem($itemno,$amount);
				$this->SaveUserItem();
			}

		return true;
	}
//////////////////////////////////////////////////
//	Union 몬스터의 표시
	function UnionShow() {
		if($this->CanUnionBattle() !== true) {
			$host  = $_SERVER['HTTP_HOST'];
			$uri   = rtrim(dirname($_SERVER['PHP_SELF']));
			$extra = INDEX;
			header("Location: http://$host$uri/$extra?hunt");
			exit;
		}
		//if($Result	= $this->UnionProcess())
		//	return true;
		print('<div style="margin:15px">'."\n");
		print("<h4>유니온 몬스터</h4>\n");
		$Union	= new union();
		// 쓰러지고 있는지, 존재하지 않는 경우.
		if(!$Union->UnionNumber($_GET["union"]) || !$Union->is_Alive()) {
			ShowError("이미 쓰러졌거나 존재하지 않습니다.");
			return false;
		}
		print('</div>');
		$this->ShowCharacters(array($Union),false,"sea");
		print('<div style="margin:15px">'."\n");
		print("<h4>팀</h4>\n");
		print("</div>");
		print('<form action="'.INDEX.'?union='.$_GET["union"].'" method="post">');
		$this->ShowCharacters($this->char,"CHECKBOX",explode("<>",(string)$this->party_memo));
			?>
	<div style="margin:15px;text-align:center">
	<input type="submit" class="btn" value="전투!">
	<input type="hidden" name="union_battle" value="1">
	<input type="reset" class="btn" value="초기화"><br>
	이 파티 저장:<input type="checkbox" name="memory_party" value="1">
	</div></form>
<?php 
	}
//////////////////////////////////////////////////
//	마을의 표시
	function TownShow() {
		include(DATA_TOWN);
		print('<div style="margin:15px">'."\n");
		print("<h4>마을</h4>");
		print('<div class="town">'."\n");
		print("<ul>\n");
		$PlaceList	= TownAppear($this);
		// 가게
		if($PlaceList["Shop"]) {
			?>
<li><h5>가게
<ul>
<li><a href="?menu=buy">산다</a></li>
<li><a href="?menu=sell">판다</a></li>
<li><a href="?menu=work">아르바이트</a></li>
</ul>
</li>
<?php 
		}
		// 알선소
		if($PlaceList["Recruit"])
			print("<li><h5><p><a href=\"?recruit\">인재 알선소</a></p></li>");
		// 대장간
		if($PlaceList["Smithy"]) {
			?>
<li><h5>대장간
<ul>
<li><a href="?menu=refine">제련공방</a></li>
<li><a href="?menu=create">제작공방</a></li>
</ul>
</li>
<?php 
		}
		// 옥션 회장
		if($PlaceList["Auction"] && AUCTION_TOGGLE)
			print("<li><h5><a href=\"?menu=auction\">옥션회장(Auction)</li>");
		// 콜로세움
		if($PlaceList["Colosseum"])
			print("<li><h5><a href=\"?menu=rank\">콜로세움</a></li>");
		print("</ul>\n");
		print("</div>\n");
		print("<h4>광장</h4>");
		$this->TownBBS();
		print("</div>\n");
	}

//////////////////////////////////////////////////
//	보통 1행 게시판
	function TownBBS() {
		$file	= BBS_TOWN;
	?>
<form action="?town" method="post">
<input type="text" maxlength="60" name="message" class="text" style="width:300px"/>
<input type="submit" value="post" class="btn" style="width:100px" />
</form>
<?php 
		if(!file_exists($file))
			return false;
		$log	= file($file);
		if($_POST["message"] && strlen($_POST["message"]) < 121) {
			$_POST["message"]	= htmlspecialchars($_POST["message"],ENT_QUOTES);
			$_POST["message"]	= stripslashes($_POST["message"]);

			$name	= "<span class=\"bold\">{$this->name}</span>";
			$message	= $name." > ".$_POST["message"];
			if($this->UserColor)
				$message	= "<span style=\"color:{$this->UserColor}\">".$message."</span>";
			$message	.= " <span class=\"light\">(".date("Mj G:i").")</span>\n";
			array_unshift($log,$message);
			while(50 < count($log))
				array_pop($log);
			WriteFile($file,implode(null,$log));
		}
		foreach($log as $mes)
			print(nl2br($mes));
	}
//////////////////////////////////////////////////
	function SettingProcess() {
		if($_POST["NewName"]) {
			$NewName	= $_POST["NewName"];
			if(is_numeric(strpos($NewName,"\t"))) {
				ShowError('error1');
				return false;
			}
			$NewName	= trim($NewName);
			$NewName	= stripslashes($NewName);
			if (!$NewName) {
				ShowError('Name is blank.');
				return false;
			}
			$length	= strlen($NewName);
			if ( 0 == $length || 16 < $length) {
				ShowError('1 to 16 letters?');
				return false;
			}
			$userName	= userNameLoad();
			if(in_array($NewName,$userName)) {
				ShowError("그 이름은 사용되고 있습니다","margin15");
				return false;
			}
			if(!$this->TakeMoney(NEW_NAME_COST)) {
				ShowError('money not enough');
				return false;
			}
			$OldName	= $this->name;
			$NewName	= htmlspecialchars($NewName,ENT_QUOTES);
			if($this->ChangeName($NewName)) {
				ShowResult("Name Changed ({$OldName} -> {$NewName})","margin15");
				//return false;
				userNameAdd($NewName);
				return true;
			} else {
				ShowError("?");//이름이 같다?
				return false;
			}
		}

		if($_POST["setting01"]) {
			if($_POST["record_battle_log"])
				$this->record_btl_log	= 1;
			else
				$this->record_btl_log	= false;

			if($_POST["no_JS_itemlist"])
				$this->no_JS_itemlist	= 1;
			else
				$this->no_JS_itemlist	= false;
		}
		if($_POST["color"]) {
			if(	strlen($_POST["color"]) != 6 &&
				!preg_match("/^[0369cf]{6}/",$_POST["color"]))
				return "error 12072349";
			$this->UserColor	= $_POST["color"];
			ShowResult("설정이 변경되었습니다.","margin15");
			return true;
		}
	}
//////////////////////////////////////////////////
//	설정 표시 화면
	function SettingShow() {
		print('<div style="margin:15px">'."\n");
		if($this->record_btl_log) $record_btl_log	= " checked";
		if($this->no_JS_itemlist) $no_JS_itemlist	= " checked";
		?>
<h4>설정</h4>
<form action="?setting" method="post">
<table><tbody>
<tr><td><input type="checkbox" name="record_battle_log" value="1" <?=$record_btl_log?>></td><td>전투 로그의 기록</td></tr>
<tr><td><input type="checkbox" name="no_JS_itemlist" value="1" <?=$no_JS_itemlist?>></td><td>아이템 리스트에 JavaScript를 사용하지 않는다</td></tr>
</tbody></table>
<!--<tr><td>None</td><td><input type="checkbox" name="none" value="1"></td></tr>-->
색상 : <?php 
		$color	= file(COLOR_FILE);
		print('<select name="color" class="bgcolor">'."\n");
		foreach($color as $value) {
			$value	= trim($value);
			print("<option value=\"{$value}\" style=\"color:{$value}\" ".($this->UserColor == $value?" selected":"").">");
			print("색상 미리보기</option>\n");
		}
		print('</select>');
	?><br />
<input type="submit" class="btn" name="setting01" value="수정" style="width:100px">
<input type="hidden" name="setting01" value="1">
</form>
<h4>로그아웃</h4>
<form action="<?=INDEX?>" method="post">
<input type="submit" class="btn" name="logout" value="로그아웃" style="width:100px">
</form>
<h4>팀명의 변경</h4>
<form action="?setting" method="post">
비용 : <?=MoneyFormat(NEW_NAME_COST)?><br />
16 문자까지(전각=2문자)<br />
새로운 이름 : <input type="text" class="text" name="NewName" size="20">
<input type="submit" class="btn" value="변경" style="width:100px">
</form>
<h4>탈출구</h4>
<div class="u">※데이터의 삭제</div>
<form action="?setting" method="post">
비밀번호 : <input type="text" class="text" name="deletepass" size="20">
<input type="submit" class="btn" name="delete" value="삭제" style="width:100px">
</form>
</div><?php 
		return $Result;
	}
////////// Show //////////////////////////////////////////////////////
/*
 * ShowCharStat
 * ShowHunt
 * ShowItem
 * ShowShop
 * ShowRank
 * ShowRecruit
 * ShowSetting
 */

//////////////////////////////////////////////////
//	전투시에 선택한 멤버를 기억한다
	function MemorizeParty() {
		if($_POST["memory_party"]) {
			//$temp	= $this->party_memo;//일시적으로 기억
			//$this->party_memo	= array();
			$PartyMemo	= array();
			foreach($this->char as $key => $val) {//체크된 녀석 리스트
				if($_POST["char_".$key])
					//$this->party_memo[]	 = $key;
					$PartyMemo[]	= $key;
			}
			//if(5 < count($this->party_memo) )//5인 이상은 타목
			//	$this->party_memo	= $temp;
			if(0 < count($PartyMemo) && count($PartyMemo) < 6) {
				$this->party_memo	= implode("<>",$PartyMemo);
				return true;
			}
		}
		return false;
	}

//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////
//	로그인한 화면
	function LoginMain() {
		$this->ShowTutorial();
		$this->ShowMyCharacters();
		RegularControl($this->id);
	}
//////////////////////////////////////////////////
//	튜토리얼
	function ShowTutorial() {
		$last	= $this->last;
		$start	= substr($this->start,0,10);
		$term	= 60*60*1;
		if( ($last - $start) < $term) {
			?>
	<div style="margin:5px 15px">
	<a href="?tutorial">튜토리얼</a>- 전투의 기본(등록 후, 1시간만 표시됩니다)
	</div>

<?php 
		}
	}

//////////////////////////////////////////////////
//	자신의 캐릭터를 표시한다
	function ShowMyCharacters($array=NULL) {// $array ← 여러가지 받는다
		if(!$this->char) return false;
		$divide	= (count($this->char)<CHAR_ROW ? count($this->char) : CHAR_ROW);
		$width	= floor(100/$divide);//각 셀 가로폭

		print('<table cellspacing="0" style="width:100%"><tbody><tr>');//가로폭100%
		foreach($this->char as $val) {
			if( $i%CHAR_ROW==0 && $i != 0 )
				print("\t</tr><tr>\n");
			print("\t<td valign=\"bottom\" style=\"width:{$width}%\">");//캐릭터수에 따라%로 각 셀 분할
			$val->ShowCharLink($array);
			print("</td>\n");
			$i++;
		}
		print("</tr></tbody></table>");
	}
//////////////////////////////////////////////////
//	캐릭터를 오모테구미 봐로 표시한다
	function ShowCharacters($characters,$type=null,$checked=null) {
		if(!$characters) return false;
		$divide	= (count($characters)<CHAR_ROW ? count($characters) : CHAR_ROW);
		$width	= floor(100/$divide);//각 셀 가로폭

		if($type == "CHECKBOX") {
print <<< HTML
<script type="text/javascript">
<!--
function toggleCheckBox(id) {
id0 = "box" + id;
\$("box" + id).checked = \$("box" + id).checked?false:true;
Element.toggleClassName("text"+id,'unselect');
}
// -->
</script>
HTML;
		}

		print('<table cellspacing="0" style="width:100%"><tbody><tr>');//가로폭100%
		foreach($characters as $char) {
			if( $i%CHAR_ROW==0 && $i != 0 )
				print("\t</tr><tr>\n");
			print("\t<td valign=\"bottom\" style=\"width:{$width}%\">");//캐릭터수에 따라%로 각 셀 분할

			/*-------------------*/
			switch(1) {
				case ($type === "MONSTER"):
					$char->ShowCharWithLand($checked); break;
				case ($type === "CHECKBOX"):
					if(!is_array($checked)) $checked = array();
					if(in_array($char->birth,$checked))
						$char->ShowCharRadio($char->birth," checked");
					else
						$char->ShowCharRadio($char->birth);
					break;
				default:
					$char->ShowCharLink();
			}

			print("</td>\n");
			$i++;
		}
		print("</tr></tbody></table>");
	}

//////////////////////////////////////////////////
//	자신의 데이터와 쿠키를 지운다
	function DeleteMyData() {
		if($this->pass == $this->CryptPassword($_POST["deletepass"]) ) {
			$this->DeleteUser();
			$this->name	= NULL;
			$this->pass	= NULL;
			$this->id	= NULL;
			$this->islogin= false;
			unset($_SESSION["id"]);
			unset($_SESSION["pass"]);
			setcookie("NO","");
			$this->LoginForm();
			return true;
		}
	}

//////////////////////////////////////////////////
//	변수의 표시
	function Debug() {
		if(DEBUG)
			print("<pre>".print_r(get_object_vars($this),1)."</pre>");
	}

//////////////////////////////////////////////////
//	세션 정보를 표시한다.
	function ShowSession() {
		echo "this->id:$this->id<br>";
		echo "this->pass:$this->pass<br>";
		echo "SES[id]:{$_SESSION['id']}<br>";
		echo "SES[pass]:{$_SESSION['pass']}<br>";
		echo "SES[pass]:".$this->CryptPassword($_SESSION['pass'])."(crypted)<br>";
		echo "CK[NO]:{$_COOKIE['NO']}<br>";
		echo "SES[NO]:".session_id();
		dump($_COOKIE);
		dump($_SESSION);
	}

//////////////////////////////////////////////////
//	로그인한 시간을 설정한다
	function RenewLoginTime() {
		$this->login	= time();
	}

//////////////////////////////////////////////////
//	로그인했는지, 하고 있는지, 로그아웃 했는가.
	function CheckLogin() {
		//logout
		if(isset($_POST["logout"])) {
		//	$_SESSION["pass"]	= NULL;
		//	echo $_SESSION["pass"];
			unset($_SESSION["pass"]);
		//	session_destroy();
			return false;
		}

		//session
		$file=USER.$this->id."/".DATA;//data.dat
		if ($data = $this->LoadData()) {
			//echo "<div>$data['pass'] == $this->pass</div>";
			if($this->pass == NULL)
				return false;
			if ($data["pass"] === $this->pass) {
				//로그인 상태
				$this->DataUpDate($data);
				$this->SetData($data);
				if(RECORD_IP)
					$this->SetIp($_SERVER['REMOTE_ADDR']);
				$this->RenewLoginTime();

				$pass	= ($_POST["pass"])?$_POST["pass"]:$_GET["pass"];
				if ($pass) {//정확히 지금 로그인한다면
					$_SESSION["id"]	= $this->id;
					$_SESSION["pass"]	= $pass;
					setcookie("NO",session_id(),time()+COOKIE_EXPIRE);
				}

				$this->islogin	= true;//로그인 상태
				return true;
			} else
				return "비밀번호가 틀렸습니다.";
		} else {
			if($_POST["id"])
				return "ID \"{$this->id}\"는 존재하지 않습니다.";
		}
	}

//////////////////////////////////////////////////
//	$id 를 등록이 끝난 id로서 기록한다
	function RecordRegister($id) {
		$fp=fopen(REGISTER,"a");
		flock($fp,2);
		fputs($fp,"$id\n");
		fclose($fp);
	}

//////////////////////////////////////////////////
//	pass 와 id 를 설정한다
	function Set_ID_PASS() {
    $id = '';

    if (isset($_POST["id"]) && $_POST["id"] !== '') {
        $id = $_POST["id"];
    } elseif (isset($_GET["id"]) && $_GET["id"] !== '') {
        $id = $_GET["id"];
    }

    if ($id) {
        $this->id = $id;

        if (isset($_POST["id"]) && is_registered($_POST["id"])) {
            $_SESSION["id"] = $this->id;
        }
    } elseif (isset($_SESSION["id"]) && $_SESSION["id"] !== '') {
        $this->id = $_SESSION["id"];
    }

    $pass = '';

    if (isset($_POST["pass"]) && $_POST["pass"] !== '') {
        $pass = $_POST["pass"];
    } elseif (isset($_GET["pass"]) && $_GET["pass"] !== '') {
        $pass = $_GET["pass"];
    }

    if ($pass) {
        $this->pass = $pass;
    } elseif (isset($_SESSION["pass"]) && $_SESSION["pass"] !== '') {
        $this->pass = $_SESSION["pass"];
    }

    if ($this->pass) {
        $this->pass = $this->CryptPassword($this->pass);
    }
}
//////////////////////////////////////////////////
//	보존되고 있는 세션 번호를 변경한다.
	function SessionSwitch() {
    session_cache_expire(COOKIE_EXPIRE/60);

    if (!empty($_COOKIE["NO"]) && session_status() === PHP_SESSION_NONE) {
        session_id($_COOKIE["NO"]);
    }

    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    return true;
}

//////////////////////////////////////////////////
//	입력된 정보가 형태에 빠질까 판정
//	→ 신규 데이터를 작성.

	function MakeNewData() {
		// 등록자수가 한계의 경우
		if(MAX_USERS <= count(glob(USER."*")))
			return array(false,"최대 등록 인원에 도달했습니다.<br />등록자 수가 한계에 다다른 것 같습니다");
		if(isset($_POST["Newid"]))
			trim($_POST["Newid"]);
		if(empty($_POST["Newid"]))
			return array(false,"아이디를 입력해 주세요.");

		if(!preg_match("/[0-9a-zA-Z]{4,16}/",$_POST["Newid"])||
			preg_match("/[^0-9a-zA-Z]+/",$_POST["Newid"]))//정규 표현
			return array(false,"아이디 형식이 올바르지 않습니다.");

		if(strlen($_POST["Newid"]) < 4 || 16 < strlen($_POST["Newid"]))//문자 제한
			return array(false,"아이디는 4-16자의 영문/숫자로 입력해 주세요.");

		if(is_registered($_POST["Newid"]))
			return array(false,"이미 사용 중인 아이디입니다.");

		$file = USER.$_POST["Newid"]."/".DATA;
		// PASS
		//if(isset($_POST["pass1"]))
		//	trim($_POST["pass1"]);
		if(empty($_POST["pass1"]) || empty($_POST["pass2"]))
			return array(false,"비밀번호를 두 번 입력해 주세요.");

		if(!preg_match("/[0-9a-zA-Z]{4,16}/",$_POST["pass1"]) || preg_match("/[^0-9a-zA-Z]+/",$_POST["pass1"]))
			return array(false,"첫 번째 비밀번호 형식이 올바르지 않습니다.");
		if(strlen($_POST["pass1"]) < 4 || 16 < strlen($_POST["pass1"]))//문자 제한
			return array(false,"첫 번째 비밀번호는 4-16자의 영문/숫자로 입력해 주세요.");
		if(!preg_match("/[0-9a-zA-Z]{4,16}/",$_POST["pass2"]) || preg_match("/[^0-9a-zA-Z]+/",$_POST["pass2"]))
			return array(false,"두 번째 비밀번호 형식이 올바르지 않습니다.");
		if(strlen($_POST["pass2"]) < 4 || 16 < strlen($_POST["pass2"]))//문자 제한
			return array(false,"두 번째 비밀번호는 4-16자의 영문/숫자로 입력해 주세요.");

		if($_POST["pass1"] !== $_POST["pass2"])
			return array(false,"비밀번호가 서로 일치하지 않습니다.");

		$pass = $this->CryptPassword($_POST["pass1"]);
		// MAKE
		if(!file_exists($file)){
		if (!is_dir(USER.$_POST["Newid"])) {
    if (!mkdir(USER.$_POST["Newid"], 0777, true)) {
        return array(false, "유저 폴더 생성 실패");
    }
}

$fp = fopen($file, "w");
if (!$fp) {
    return array(false, "데이터 파일 생성 실패: ".$file);
}

flock($fp, LOCK_EX);
$now = time();
fputs($fp,"id=".$_POST["Newid"]."\n");
fputs($fp,"pass=".$pass."\n");
fputs($fp,"last=".$now."\n");
fputs($fp,"login=".$now."\n");
fputs($fp,"start=".$now.substr(microtime(),2,6)."\n");
fputs($fp,"money=".START_MONEY."\n");
fputs($fp,"time=".START_TIME."\n");
fputs($fp,"record_btl_log=1\n");
fclose($fp);

/* ?? 여기로 이동 */
$this->RecordRegister($_POST["Newid"]);

			//print("ID:$_POST['Newid'] success.<BR>");
			$_SESSION["id"]=$_POST["Newid"];
			setcookie("NO",session_id(),time()+COOKIE_EXPIRE);
			$success	= "<div class=\"recover\">아이디 : {$_POST['Newid']} 등록 완료. 로그인해 주세요.</div>";
			return array(true,$success);//강행...
		}
	}

//////////////////////////////////////////////////
//	신규 ID작성용의 폼
	function NewForm($error=NULL) {
		if(MAX_USERS <= count(glob(USER."*"))) {
			?>

	<div style="margin:15px">
	최대 등록 인원에 도달했습니다.<br />
	등록자수가 한계에 다다른 것 같습니다
	</div><?php 
			return false;
		}
		$idset=($_POST["Newid"]?" value={$_POST['Newid']}":NULL);
		?>
	<div style="margin:15px">
	<?=ShowError($error);?>
	<h4>새 게임 시작</h4>
	<form action="<?=INDEX?>" method="post">

	<table><tbody>
	<tr><td colspan="2">아이디와 비밀번호는 4-16자의 영문/숫자로 입력해 주세요.</td></tr>
	<tr><td><div style="text-align:right">아이디:</div></td>
	<td><input type="text" maxlength="16" class="text" name="Newid" style="width:240px"<?=$idset?>></td></tr>
	<tr><td colspan="2"><br />비밀번호를 한 번 더 입력해 주세요.</td></tr>
	<tr><td><div style="text-align:right">비밀번호:</div></td>
	<td><input type="password" maxlength="16" class="text" name="pass1" style="width:240px"></td></tr>

	<tr><td></td>
	<td><input type="password" maxlength="16" class="text" name="pass2" style="width:240px">(확인)</td></tr>

	<tr><td></td><td><input type="submit" class="btn" name="Make" value="가입" style="width:160px"></td></tr>

	</tbody></table>
	</form>
	</div>
<?php 
	}

//////////////////////////////////////////////////
//	로그인용의 폼
	function LoginForm($message = NULL) {
		?>
<div style="width:730px;">
<!-- 로그인 -->
<div style="width:350px;float:right">
<h4 style="width:350px">로그인</h4>
<?=$message?>
<form action="<?=INDEX?>" method="post" style="padding-left:20px">
<table><tbody>
<tr>
<td><div style="text-align:right">아이디:</div></td>
<td><input type="text" maxlength="16" class="text" name="id" style="width:160px"<?=$_SESSION["id"]?" value=\"{$_SESSION['id']}\"":NULL?>></td>
</tr>
<tr>
<td><div style="text-align:right">비밀번호:</div></td>
<td><input type="password" maxlength="16" class="text" name="pass" style="width:160px"></td>
</tr>
<tr><td></td><td>
<input type="submit" class="btn" name="Login" value="로그인" style="width:80px">&nbsp;
<a href="?newgame">신규 가입</a>
</td></tr>
</tbody></table>
</form>

<h4 style="width:350px">랭킹</h4><?php 
	include_once(CLASS_RANKING);
	$Rank	= new Ranking();
	$Rank->ShowRanking(0,4);
	?>
</div>
<!-- 식 -->
<div style="width:350px;padding:15px;float:left;">
<div style="width:350px;text-align:center">
<img src="./image/top01.gif" style="margin-bottom:20px" />
</div>
<div style="margin-left:20px">
<div class="u">이건 무슨 게임?</div>
<ul>
<li>게임의 목적은 랭킹에서 1위가 되는 것이고, 1위를 지키는 것입니다.</li>
<li>모험요소는 없지만, 조금 깊은 전투시스템이 매력입니다.</li>
</ul>
<div class="u">전투는 어떤 느낌?</div>
<ul>
<li>5명의 캐릭터로 파티를 편성.</li>
<li>각 캐릭터가 행동 패턴을 갖고, 전투의 상황에 따라 기술을 구사합니다.</li>
<li><a href="?log" class="a0">이쪽</a>에서 전투 로그를 확인할 수 있습니다.</li>
</ul>
<div class="u">관련정보?</div>
<ul>
<li>개발자:<a href="http://tekito.kanichat.com/">Tekito</a></li>
<li>한글화 제작-</li>
<li>Meph(시스템),신승(메뉴얼)</li>
</ul>
</div>
</div>
<div class="c-both"></div>
</div>

<!-- -------------------------------------------------------- -->

<div style="margin:15px">
<h4>정보</h4>
등록자 : <?=UserAmount()?> / <?=MAX_USERS?><br />
<?php 
	$Abandon	= ABANDONED;
	print(floor($Abandon/(60*60*24))."일을 접속 하지 않으실 경우, 아이디는 삭제됩니다");
print("</div>\n");
	}

//////////////////////////////////////////////////
//	상부에 표시되는 메뉴.
//	로그인하고 있는 인용과 그렇지 않은 사람.
	function MyMenu() {
		if($this->name && $this->islogin) { // 로그인하고 있는 사람용
			print('<div id="menu">'."\n");
			//print('<span class="divide"></span>');//단락
			print('<a href="'.INDEX.'">처음</a><span class="divide"></span>');
			print('<a href="?hunt">전투</a><span class="divide"></span>');
			print('<a href="?item">아이템</a><span class="divide"></span>');
			print('<a href="?town">마을</a><span class="divide"></span>');
			print('<a href="?setting">설정</a><span class="divide"></span>');
			print('<a href="?log">로그</a><span class="divide"></span>');
			if(BBS_OUT)
				print('<a href="'.BBS_OUT.'">BBS</a><span class="divide"></span>'."\n");
			print('</div><div id="menu2">'."\n");
				?>
	<div style="width:100%">
	<div style="width:33%;float:left"><?=$this->name?></div>
	<div style="width:67%;float:right">
	<div style="width:50%;float:left"><span class="bold">자금</span> : <?=MoneyFormat($this->money)?></div>
	<div style="width:50%;float:right"><span class="bold">시간</span> : <?=floor($this->time)?>/<?=MAX_TIME?></div>
	</div>
	<div class="c-both"></div>
	</div><?php 
			print('</div>');
		} else if(!$this->name && $this->islogin) {// 初回ログインの人
			print('<div id="menu">');
			print("첫 로그인입니다. 등록해 주셔서 감사합니다.");
			print('</div><div id="menu2">');
			print("빈칸을 채워 주세요.");
			print('</div>');
		} else { //// ログアウト?態の人、?客用の表示
			print('<div id="menu">');
			print('<a href="'.INDEX.'">처음</a><span class="divide"></span>'."\n");
			print('<a href="?newgame">신규</a><span class="divide"></span>'."\n");
			print('<a href="?manual">규칙과 메뉴얼</a><span class="divide"></span>'."\n");
			print('<a href="?gamedata=job">게임의 데이터</a><span class="divide"></span>'."\n");
			print('<a href="?log">전투로그</a><span class="divide"></span>'."\n");
			if(BBS_OUT)
			print('<a href="'.BBS_OUT.'">게시판</a><span class="divide"></span>'."\n");
			
			print('</div><div id="menu2">');
			print("[ ".TITLE." ]에 오신 것을 환영합니다");
			print('</div>');
		}
	}

//////////////////////////////////////////////////
//	HTML개시부분
	function Head() {
		?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head><?php $this->HtmlScript();?>
<title><?=TITLE?></title>
</head>
<body><a name="top"></a>
<div id="main_frame">
<div id="title"><img src="./image/title03.gif"></div>
<?php $this->MyMenu();?><div id="contents">
<?php 
	}

//////////////////////////////////////////////////
//	스타일시트라던가
	function HtmlScript() {
		?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="./basis.css" type="text/css">
<link rel="stylesheet" href="./style.css" type="text/css">
<script type="text/javascript" src="prototype.js"></script>
<?php 
	}

//////////////////////////////////////////////////
//	HTML완료부분
	function Foot() {
		?>
</div>
<div id="foot">
<a href="?update">업데이트</a> - <?php 
	if(BBS_BOTTOM_TOGGLE)
		print('<a href="?bbs">BBS</a> - '."\n");
		?>
<a href="?manual">매뉴얼</a> - 
<a href="?tutorial">튜토리얼</a> - 
<a href="?gamedata=job">게임 데이터</a> - 
<a href="admin.php">관리자</a> - 
<a href="#top">맨 위</a><br>
<h5>Copy Right <a href="http://tekito.kanichat.com/">Tekito</a> 2007-2008.<br>
<h6>H.O.F Korean Ver - <a href="http://angelhalo.org/">엔젤하이로</a> <a href="http://meph.koreahosting.co.kr/">옥탑방 연구소</a> -<br>
</div>
</div>
</body>
</html><?php 
	}

//////////////////////////////////////////////////
//	최초로그인용 폼
	function FirstLogin() {
		// 반치:설정이 끝난 =false / 비설정 =true
		if ($this->name)
			return false;

		do {
			if (!$_POST["Done"])
				break;
			if(is_numeric(strpos($_POST["name"],"\t"))) {
				$error	= 'error1';
				break;
			}
			if(is_numeric(strpos($_POST["name"],"\n"))) {
				$error	= 'error';
				break;
			}
			$_POST["name"]	= trim($_POST["name"]);
			$_POST["name"]	= stripslashes($_POST["name"]);
			if (!$_POST["name"]) {
				$error	= '팀 이름을 입력해 주세요.';
				break;
			}
			$length	= strlen($_POST["name"]);
			if ( 0 == $length || 16 < $length) {
				$error	= '1-16자로 입력해 주세요.';
				break;
			}
			$userName	= userNameLoad();
			if(in_array($_POST["name"],$userName)) {
				$error	= '그 이름은 사용되고 있습니다.';
				break;
			}
			// 최초 캐릭터의 이름
			$_POST["first_name"]	= trim($_POST["first_name"]);
			$_POST["first_name"]	= stripslashes($_POST["first_name"]);
			if(is_numeric(strpos($_POST["first_name"],"\t"))) {
				$error	= 'error';
				break;
			}
			if(is_numeric(strpos($_POST["first_name"],"\n"))) {
				$error	= 'error';
				break;
			}
			if (!$_POST["first_name"]) {
				$error	= '캐릭터 이름을 입력해 주세요.';
				break;
			}
			$length	= strlen($_POST["first_name"]);
			if ( 0 == $length || 16 < $length) {
				$error	= '1-16자로 입력해 주세요.';
				break;
			}
			if(!$_POST["fjob"]) {
				$error	= '캐릭터 직업을 선택해 주세요.';
				break;
			}
			$_POST["name"]	= htmlspecialchars($_POST["name"],ENT_QUOTES);
			$_POST["first_name"]	= htmlspecialchars($_POST["first_name"],ENT_QUOTES);

			$this->name	= $_POST["name"];
			userNameAdd($this->name);
			$this->SaveData();
			switch($_POST["fjob"]){
				case "1":
					$job = 1; $gend = 0; break;
				case "2":
					$job = 1; $gend = 1; break;
				case "3":
					$job = 2; $gend = 0; break;
				default:
					$job = 2; $gend = 1;
			}
			include(DATA_BASE_CHAR);
			$char	= new char();
			$char->SetCharData(array_merge(BaseCharStatus($job),array("name"=>$_POST["first_name"],"gender"=>"$gend")));
			$char->SaveCharData($this->id);
			return false;
		}while(0);

		include(DATA_BASE_CHAR);
		$war_male	= new char();
		$war_male->SetCharData(array_merge(BaseCharStatus("1"),array("gender"=>"0")));
		$war_female	= new char();
		$war_female->SetCharData(array_merge(BaseCharStatus("1"),array("gender"=>"1")));
		$sor_male	= new char();
		$sor_male->SetCharData(array_merge(BaseCharStatus("2"),array("gender"=>"0")));
		$sor_female	= new char();
		$sor_female->SetCharData(array_merge(BaseCharStatus("2"),array("gender"=>"1")));

		?>
	<form action="<?=INDEX?>" method="post" style="margin:15px">
	<?php ShowError($error);?>
	<h4>팀 이름</h4>
	<p>1-16자로 팀 이름을 정해 주세요.<br />
	한국어도 사용할 수 있습니다.</p>
	<div class="bold u">팀 이름</div>
	<input class="text" style="width:160px" maxlength="16" name="name"<?php print($_POST["name"]?"value=\"{$_POST['name']}\"":"")?>>
	<h4>첫 캐릭터</h4>
	<p>첫 캐릭터 이름을 1-16자로 정해 주세요.</p>
	<div class="bold u">캐릭터 이름</div>
	<input class="text" type="text" name="first_name" maxlength="16" style="width:160px;margin-bottom:10px">
	<table cellspacing="0" style="width:400px"><tbody>
	<tr><td class="td1" valign="bottom"><div style="text-align:center"><?=$war_male->ShowImage()?><br><input type="radio" name="fjob" value="1" style="margin:3px"></div></td>
	<td class="td1" valign="bottom"><div style="text-align:center"><?=$war_female->ShowImage()?><br><input type="radio" name="fjob" value="2" style="margin:3px"></div></td>
	<td class="td1" valign="bottom"><div style="text-align:center"><?=$sor_male->ShowImage()?><br><input type="radio" name="fjob" value="3" style="margin:3px"></div></td>
	<td class="td1" valign="bottom"><div style="text-align:center"><?=$sor_female->ShowImage()?><br><input type="radio" name="fjob" value="4" style="margin:3px"></div></td></tr>
	<tr><td class="td2"><div style="text-align:center">남성</div></td><td class="td3"><div style="text-align:center">여성</div></td>
	<td class="td2"><div style="text-align:center">남성</div></td><td class="td3"><div style="text-align:center">여성</div></td></tr>
	<tr><td colspan="2" class="td4"><div style="text-align:center">전사</div></td><td colspan="2" class="td4"><div style="text-align:center">마법사</div></td></tr>
	</tbody></table>
	<p>첫 캐릭터의 직업과 성별을 선택해 주세요.</p>
	<input class="btn" style="width:160px" type="submit" value="완료" name="Done">
	<input type="hidden" value="1" name="Done">
	<input class="btn" style="width:160px" type="submit" value="로그아웃" name="logout"></form><?php 
			return true;
	}
//////////////////////////////////////////////////
//	보통 1행 게시판
	function bbs01() {
		if(!BBS_BOTTOM_TOGGLE)
			return false;
		$file	= BBS_BOTTOM;
	?>
<div style="margin:15px">
<h4>one line bbs</h4>
버그 보고, 밸런스에 대한 의견이라든지는 이쪽에서 부디.
<form action="?bbs" method="post">
<input type="text" maxlength="60" name="message" class="text" style="width:300px"/>
<input type="submit" value="post" class="btn" style="width:100px" />
</form>
<?php 
		if(!file_exists($file))
			return false;
		$log	= file($file);
		if($_POST["message"] && strlen($_POST["message"]) < 121) {
			$_POST["message"]	= htmlspecialchars($_POST["message"],ENT_QUOTES);
			$_POST["message"]	= stripslashes($_POST["message"]);

			$name	= ($this->name ? "<span class=\"bold\">{$this->name}</span>":"名無し");
			$message	= $name." > ".$_POST["message"];
			if($this->UserColor)
				$message	= "<span style=\"color:{$this->UserColor}\">".$message."</span>";
			$message	.= " <span class=\"light\">(".date("Mj G:i").")</span>\n";
			array_unshift($log,$message);
			while(150 < count($log))// 로그 보존행수아
				array_pop($log);
			WriteFile($file,implode(null,$log));
		}
		foreach($log as $mes)
			print(nl2br($mes));
		print('</div>');
	}
//end of class
//////////////////////////////////////////////////////////////////////
}
?>
