<?php 
class Ranking {
/*
썼果쇨썹(ιτ?τⅠ쟁)
1. 칫쟁솎ㅞIDㆂ턴ㅉ
2.
	1겁ㅞ와。
		쟁트ㅗㄽㅮㅋㆃⅷι【。
	2-뵉꼈겁ㅞ와。
		1맣얍ㅞ와ㆂ천ㅉ。
	ιτ?낡ㅞ와。
		뵉꼈겁ㅞ와ㆂ천ㅉ。
3. 섐暇ㅞ쥬쇨ㅘ쟁트
4. 쐴貢솎、함솎ㅞ썹겁揀튼
5. 艮쨍。
----------------------------
ⅷι【ㄴㅸ、ㄴㅸ【
뎐ㅃㅺㄶㅻ졍ㅖㅞ(?)색앴。
∨|1겁ㄼ듸ㅚㄴ샤(ιτ?섐쫍ㄼ絹ㄴㅘㄽ)칫쟁솎ㄼ1겁ㅛㅚㅻ。
∨|1겁ㅟ칫쟁ㅗㄽㅚㄴ。
∨|윳억ㅚ2겁-뵉꼈겁ㅞ솎ㄼ얍ㅛ칫쟁ㅇㅖ쐴ㅔ。
∨|윳억ㅚ2겁-뵉꼈겁ㅞ솎ㄼ얍ㅛ칫쟁ㅇㅖㅁㅻ。
∨|윳억ㅚ2겁-뵉꼈겁ㅞ솎ㄼ얍ㅛ칫쟁ㅇㅖ1겁ㅛㅚㅻ。
∃|Α【?털臼ㅅㅼㅖ絹ㄴ솎ㅟ칫쟁ㅗㄽㅚㄴ。
∩|Α【?털臼ㅟㅇㅏㅁㅙ、ιτ?τⅠㅛ뺘꼴ㅇㅖㅚㄴ솎ㄼ칫쟁ㅉㅻ。
∨|칫쟁ㅇㅏ쥬쇨ㅞΑ【?ㄼㄺㄻㅇㄴ(웃潔루ㅁㅖㄴㅻ)。
∨|칫쟁ㅇㅏ쥬쇨ㅞΑ【?ㄼㄺㄻㅇㄴ(졍곳루ㅁㅖㄴㅻ)。
∩|칫쟁ㅇㅏ쥬쇨ㅞID섐쫍ㄼ씹ㄸㅖㄴㅻ。
∩|IDㆂ씹ㅇㅏㅘㄽιτ?τⅠㄻㅹㅲ씹鎌ㅉㅻ。
∃|샤닛윈맞ㄼㄲㅻ얠밭ㅟ칫쟁ㅗㄽㅚㄴ。
∨|쥬쇨ㄼ샤닛윈맞충(˚ㅏㅦㆃ絹닢렇)
*/

	var $Ranking	= array();

//////////////////////////////////////////////
// Φⅰⅳλㄻㅹ팖ㅯ벗ㆃㅗιτ?τⅠㆂ핼轎ㅛㅉㅻ
	function Ranking() {
		$file	= RANKING;

		if(!file_exists($file)) return 0;

		// Φⅰⅳλㄻㅹ팖ㆃㅗ핼轎ㅛㄴㅼㅻ
		$fp	= fopen($file,"r");
		flock($fp,LOCK_EX);
		while($line = fgets($fp) ) {
			$line	= trim($line);
			if(trim($line) == "") break;
				$this->Ranking[]	= $line;
		}
		//$this->Ranking	= file($file);
		// 핼轎ㄼ0ㅚㅹ쉠貫
		if(!$this->Ranking) return 0;
		// 띈자ㅓㅖ訶샙轎ㆂ暇념
		foreach($this->Ranking as $rank => $val) {
			$list	= explode("<>", $val);
			$this->Ranking["$rank"]	= array();
			$this->Ranking["$rank"]["id"]	= $list["0"];
		}
		//$this->JoinRanking("yqyqqq","last");
		//dump($this->Ranking);
	}

//////////////////////////////////////////////
// ιτ?τⅠ쟁ㅉㅻ。쟁ㄶ。
	function Challenge($id) {
		// ιτ?τⅠㄼ絹ㄴㅘㄽ(1겁ㅛㅚㅻ)
		if(!$this->Ranking) {
			$this->JoinRanking($id);
			$this->SaveRanking();
			$message	= "랭킹이 시작되었습니다."; 
			return array($message,true);
		}

		$MyRank	= $this->SearchID($id);//섐暇ㅞ썹겁
		// 1겁ㅞ얠밭。
		if($MyRank === 0) {
			$message	= "1위는 도전할 수 없습니다.";
			return array($message,true);
		}

		// 섐暇ㄼιτ?낡ㅚㅹ
		if(!$MyRank) {
			$this->JoinRanking($id);//섐暇ㆂ뵉꼈겁ㅛㅉㅻ。
			$MyRank	= count($this->Ranking) - 1;//섐暇ㅞιτ?(뵉꼈겁)

			$MyID	= $this->Ranking["$MyRank"]["id"];
			$RivalID= $this->Ranking["$MyRank" - 1]["id"];//섐暇ㅸㅺ1맣얍ㅞ와ㄼ쥬쇨。
			/*
			dump($this->Ranking);
			dump($RivalID);
			dump($MyID);
			dump($MyRank);//ⅷι【ㅗㅏㅹ닺칠ㅼ
			return 0;*/
			list($message,$result)	= $this->RankBattle($MyID,$RivalID);
			if($message == "Battle" && $result === true)
				$this->RankUp($MyID);

			$this->SaveRanking();
			return array($message,$result);
		}

		// 2겁-뵉꼈겁ㅞ와ㅞ썼果。
		if($MyRank) {
			$rival	= $MyRank - 1;//섐暇ㅸㅺ썹겁ㄼ1맣얍ㅞ와。

			$MyID	= $this->Ranking["$MyRank"]["id"];
			$RivalID= $this->Ranking["$rival"]["id"];
			list($message,$result)	= $this->RankBattle($MyID,$RivalID);
			if($message != "Battle")
				return array($message,$result);

			// 쟁트ㆂ밋ㅓㅖtrueㅚㅹιτ?ㄶｐ
			if($message == "Battle" && $result === true) {
				$this->RankUp($MyID);
				$this->SaveRanking();
			}
			return array($message,$result);
		}
	}

//////////////////////////////////////////////
// 쟁ㅿㅋㅻ
	function RankBattle($ChallengerID,$DefendID) {
		$challenger	= new user($ChallengerID);
		$challenger->CharDataLoadAll();
		$defender	= new user($DefendID);
		$defender->CharDataLoadAll();
		//print($ChallengerID."<br>".$DefendID."<br>");

		$Party_Challenger	= $challenger->RankParty();
		$Party_Defender		= $defender->RankParty();
		if($Party_Defender == "NOID") {//ζ【Ⅶ섐쫍ㄼ덞ㅛ쨍뷔ㅇㅚㄴ얠밭
			$message	= "No USER...<br />(win a game by default)";
			$this->DeleteRank($DefendID);
			$this->SaveRanking();
			return array($message,true);
		}

		// 癎촐
		// array(αΓ?【Ⅸ,쟁트ㄼㄲㅓㅏㄻ,쐴함)

		// ιτ?錮Ρ【Ζⅲ【ㄼㄲㅺㅮㅋㆃ―――
		if($Party_Challenger === false) {
			$message	= "전투 팀을 설정해 주세요!<br />(다른 플레이어에게 도전받으면 랭킹에서 제외됩니다)";
			return array($message,true);
		}
		// ιτ?錮Ρ【Ζⅲ【ㄼㄲㅺㅮㅋㆃ―――
		if($Party_Defender === false) {
			$this->DeleteRank($DefendID);
			$this->SaveRanking();
			$message	= "{$defender->name} 은(는) 랭킹 전투 팀이 없습니다<br />(부전승)";
			return array($message,true);
		}

		//dump($Party_Challenger);
		//dump($Party_Defender);
		include(CLASS_BATTLE);
		$battle	= new battle($Party_Challenger,$Party_Defender);
		$battle->SetBackGround("colosseum");
		$battle->SetTeamName($challenger->name,$defender->name);
		$battle->Process();//쟁트낙뾰
		$battle->RecordLog("RANK");
		return array("Battle",$battle->isChallengerWin());
	}

//////////////////////////////////////////////
// ιτ?τⅠㅛ뺘꼴ㅅㅋㅻ。
	function JoinRanking($id,$place=false) {
		if(!$place)//뵉꼈겁ㅛ퐁ㅼㅻ
			$place	= count($this->Ranking);
		$data	= array(array("id"=>$id));
		array_splice($this->Ranking, $place, 0, $data);
	}

//////////////////////////////////////////////////
// 썹겁ㆂ퐁ㅼ쬐ㄸㅻ。
	function ChangeRank($id,$id0) {
	
	}

//////////////////////////////////////////////////
// 썹겁ㆂ얍ㅂㅻ。
	function RankUp($id) {
		$place	= $this->SearchID($id);
		//1겁ㅟ絹果 ㄲㅘ、ιτ?τⅠㄼ1ㅔㅞ얠밭(1겁ㅞㅯ)
		$number	= count($this->Ranking);
		if($place === 0 || $number < 2)
			return false;

		$temp	= $this->Ranking["$place"];
		$this->Ranking["$place"]	= $this->Ranking["$place"-1];
		$this->Ranking["$place"-1]	= $temp;
	}

//////////////////////////////////////////////////
// 썹겁ㆂ꼈ㅂㅻ。
	function RankDown($id) {
		$place	= $this->SearchID($id);
		// 뵉꼈겁ㅟ絹果 ㄲㅘ、ιτ?τⅠㄼ1ㅔㅞ얠밭(1겁ㅞㅯ)
		$number	= count($this->Ranking);
		if($place === ($number - 1) ||  $number < 2)
			return false;

		$temp	= $this->Ranking["$place"];
		$this->Ranking["$place"]	= $this->Ranking["$place"+1];
		$this->Ranking["$place"+1]	= $temp;
	}

//////////////////////////////////////////////////
// ιτ?τⅠㄻㅹ씹ㅉ
	function DeleteRank($id) {
		$place	= $this->SearchID($id);
		if($place === false) return false;//븝쐤성함
		unset($this->Ranking["$place"]);
		return true;//븝쐤윙몽
	}

//////////////////////////////////////////////////
// ιτ?τⅠㆂ艮쨍ㅉㅻ
	function SaveRanking() {
		foreach($this->Ranking as $rank => $val) {
			$ranking	.= $val["id"]."\n";
		}

		WriteFile(RANKING,$ranking);
	}

//////////////////////////////////////////////////
// $id ㆂ천ㅉ
	function SearchID($id) {
		foreach($this->Ranking as $rank => $val) {
			if($val["id"] == $id)
				return (int)$rank;
		}
		return false;
	}

//////////////////////////////////////////////////
// ιτ?τⅠㅞ섀
	function ShowRanking($from=false,$to=false,$bold=false) {
		$last	= count($this->Ranking) - 1;
		// ιτ?τⅠㄼ쨍뷔ㅇㅚㄴ샤
		if(count($this->Ranking) < 1) {
			print("<div class=\"bold\">랭킹이 없습니다.</div>\n");
		// 섀ㅉㅻ웃ㆂ쀼쾨ㅅㅼㅏ샤
		} else if(is_numeric($from) && is_numeric($to)) {
			for($from; $from<$to; $from++) {
				$user	= new user($this->Ranking["$from"]["id"]);
				$place	= ($from==$last?"위(최하위)":"위");
				if($bold === $from) {
					echo ($from+1)."{$place} : <span class=\"u\">".$user->name."</span><br />";
					break;
				}
				if($this->Ranking["$from"])
					echo ($from+1)."{$place} : ".$user->name."<br />";
				//else break;
			}
		// 섀ㅉㅻ웃ㆂ쀼쾨ㅅㅼㅚㄻㅓㅏ샤(졍섀)
		} else if(!$no) {
			foreach($this->Ranking as $key => $val) {
				$user	= new user($val["id"]);
				echo ($key+1)."위 : ".$user->name."<br />";
			}
		}
	}

//////////////////////////////////////////////////
// $id숭澗ㅞιτ?τⅠㆂ섀
	function ShowNearlyRank($id,$no=5) {
		//dump($this->Ranking);
		$MyRank	= $this->SearchID($id);
		//print("aaa".$MyRank.":".$id."<br>");
		$lowest	= count($this->Ranking);
		// 뵉꼈겁ㅛ뜬ㄴㅞㅗ략ㅺ얍ㅂㅖ섀
		if( $lowest < ($MyRank+$no) ) {
			$moveup	= $no - ($lowest - $MyRank);
			$this->ShowRanking($MyRank-$moveup-5,$lowest,$MyRank);
			return 0;
		}
		// 얍ㅛ뜬ㄴㅞㅗ략ㅺ꼈ㅂㅖ섀
		if( ($MyRank-$no) < 0 ) {
			$this->ShowRanking(0,$no+5,$MyRank);
			return 0;
		}
		// 충닛
		$this->ShowRanking($MyRank-$no,$MyRank+$no,$MyRank);
	}

// end of class
}
?>
