<?php
//////////////////////////////////////////////////
//	extended class.battle.php
class ClassSkillEffect{
//////////////////////////////////////////////////
//	스킬을 대상으로 사용한다
/*

스킬 사용 대상자(피측)는 기본적으로
■전원
■랜덤(에 여러 차례)
■(아군의) HP가 낮은 순서로부터 회수=인원수분
■사모-사람(로 랜덤)
의 4 종류?
※적의 HP가 낮은 순서로부터 노릴 수 있으면 재미없고.

우선, 먼저 타겟을 결정한다.
후보(아군, 적, 자신, 아군+적)
후보보다 단체, 복수, 전체를 우선 순위에 따라서(단체, 복수만) 결정한다

공격이라면, 가이드가 들어갈지 판정.
공격.

지원→그대로 지원

*/
//////////////////////////////////////////////////
//	사용자가 대상자에게 스킬을 사용한다
	function SkillEffect($skill,$skill_no,$user,$target) {
		if($target === false) {
			print("대상이 없습니다. 실패!<br />\n");
			return false;
		}

		//스킬을 실제로 사용한다
		switch($skill_no):

			case 1020:// ManaBreak
				$dmg	= CalcBasicDamage($skill,$user,$target);
				DamageSP($target,$dmg);
				break;

			case 1021:// SoulBreak
				$dmg	= CalcBasicDamage($skill,$user,$target);
				DamageHP($target,$dmg);
				DamageSP($target,$dmg);
				break;

			case 1022://ChargeAttack
				if($user->POSITION != "front")
					$option["multiply"]	= 4;
				$dmg	= CalcBasicDamage($skill,$user,$target,$option);
				DamageHP($target,$dmg);
				$user->Move("front");
				break;

			case 1023://Hit&Away
				if($user->POSITION == "front")
					$option["multiply"]	= 3;
				$dmg	= CalcBasicDamage($skill,$user,$target,$option);
				DamageHP($target,$dmg);
				$user->Move("back");
				break;

			case 1024://LifeDivision
				$value	= round(abs($target->HP - $user->HP)*0.5);// 差分
				if($user->HP <= $target->HP) {
					if(1000 <= $value) {
						print("※값이 너무 커서 보정되었습니다.<br />n");
						$value	= 500;
					}
					DamageHP($target,$value);
					RecoverHP($user,$value);
				} else {
					DamageHP($user,$value);
					RecoverHP($target,$value);
				}
				break;

			case 1025://ManaDivision
				$value	= round(abs($target->SP - $user->SP)*0.5);// 差分
				if($user->SP <= $target->SP) {
					if(1000 <= $value) {
						print("※값이 너무 커서 보정되었습니다.<br />n");
						$value	= 500;
					}
					DamageSP($target,$value);
					RecoverSP($user,$value);
				} else {
					DamageSP($user,$value);
					RecoverSP($target,$value);
				}
				break;

			case 1116://Punish
				$dmg	= $user->MAXHP - $user->HP;
				DamageHP($target,$dmg);
				break;

			case 1119://Possession
				if($user === $target) break;
				$this->StatusChanges($skill,$target);
				break;

			case 1200://PoisonBlow
				if($target->STATE === 2) {
					$option["multiply"]	= 6;
					print("피해 6배!<br />\n");
				}
				$dmg	= CalcBasicDamage($skill,$user,$target,$option);
				DamageHP($target,$dmg);
				break;

			case 1208://PoisonInvasion
				$Rate	= (log(($user->INT+22)/10) - 0.8)/0.85;
				//$Rate	= 0.81 + (pow(pow($user->INT*0.1,2.05),21/40))/10;
				$target->PoisonDamage($Rate);
				break;

			case 1209://TransPoison
				if($target->STATE !== POISON) return false;
				$this->StatusChanges($skill,$target);
				$target->GetNormal(true);
				break;

			case 1220://AntiPoisoning
				$target->GetPoisonResist(50);
				break;

			case 2030: // LifeDrain
			case 2031: // LifeSqueeze
				if($user == $target) return false;//自分から自分は吸?しない。
				$dmg	= CalcBasicDamage($skill,$user,$target);
				AbsorbHP($target,$dmg,$user,$dmg);
				break;

			case 2032: // DeathKnell
				$p	= mt_rand(1,100);
				if(50<$p) $target->HP	= 0;
				else print("실패!<br />");
				return true;

			case 2055:// SoulRevenge
				$option["multiply"]	= $this->CountDead($user) + 1;
				print("피해 ".$option["multiply"]."배!<br />\n");
				$dmg	= CalcBasicDamage($skill,$user,$target,$option);
				DamageHP($target,$dmg);
				break;

			case 2056:// ZombieRevival
				//print("who? : ".$target->Name().":".$target->STATE."<br />\n");
				if($target->STATE !== DEAD) break;
				$target->GetNormal(true);
				$this->StatusChanges($skill,$target);
				RecoverHP($target,$target->MAXHP);
				break;

			case 2057:// SelfMetamorphorse
				if(60 < $target->HpPercent() || $target->SPECIAL["Metamo"]) {
					print("실패!<br />\n");
					break;
				}
				print($target->GetSpecial("Metamo",true));
				if($target->gender == 0)
					$target->img	= "mon_110r.gif";//♂
				else
					$target->img	= "mon_149r.gif";//♀
				$this->StatusChanges($skill,$target);
				RecoverHP($target,round($target->MAXHP/2));
				break;

			// SP흡수계
			case 2090://EneryRob
			case 2091://EneryCollect
				if($user == $target) return false;//자신으로부터 자신은 흡수하지 않는다.
				$dmg	= CalcBasicDamage($skill,$user,$target,array("pierce"=>1));
				AbsorbSP($target,$dmg,$user,$dmg);
				break;

			// 영창중의 캐릭터만을 대상으로 한다
			case 2110:
			case 2111:
				if($target->expect === false) break;
				$this->DelayChar($target,$skill);
				break;

/*
			// HP회복계
			case 3000:// Healing
			case 3001:// PowerHeal
			case 3002:// PartyHeal
			case 3003:// QuickHeal
			case 3004:// SmartHeal
			case 3103://
			case 5007:// Heal(Mons)
			case 5055:// RadiateHeating
				$heal	= CalcRecoveryValue($skill,$user,$target);
				RecoverHP($target,$heal);
				$this->StatusChanges($skill,$target);
				break;
*/

			case 3005: // ProgressiveHeal
				$heal	= CalcRecoveryValue($skill,$user,$target);
				$Rate	= ($target->HP / $target->MAXHP) * 100;
				if($Rate <= 30) {
					$heal	*= 2;
					print("치유 효과 2배!<br />");
				}
				RecoverHP($target,$heal);
				break;

			case 3010: // ManaRecharge(자신의SP회복)
				$SpRec	= ceil($target->MAXSP * 3/10);
				RecoverSP($target,$SpRec);
				break;

			case 3011: // HiManaRecharge
				$SpRec	= ceil($target->MAXSP * 5/10);
				RecoverSP($target,$SpRec);
				break;

			case 3012: // LifeConvert
				$HpDmg	= ceil($target->MAXHP * 3/10);
				DamageHP2($target,$HpDmg);
				$SpRec	= ceil($target->MAXSP * 7/10);
				RecoverSP($target,$SpRec);
				break;

			case 3013: // EnergyExchange
				$HpRate	= floor($target->HP/$target->MAXHP*100);
				$SpRate	= floor($target->SP/$target->MAXSP*100);
				print("{$target->name}의 체력과 스테미나 비율을 교환했습니다.<br />");
				print("체력: {$target->HP}(".$HpRate."%) → ");
				$target->HP	= round($SpRate/100*$target->MAXHP);
				print("{$target->HP}(".$SpRate."%)<br />");
				print("스테미나: {$target->SP}(".$SpRate."%) → ");
				$target->SP	= round($HpRate/100*$target->MAXSP);
				print("{$target->SP}(".$HpRate."%)<br />");
				break;

			case 3020: // ManaExtend
				$target->MAXSP	= round($target->MAXSP * 1.2);
				print($target->Name("bold")."의 최대 스테미나가 {$target->MAXSP}(으)로 증가했습니다.<br />\n");
				break;
/*
			case 3030: // Reflesh
				if($target->STATE == DEAD) break;
				if($target->STATE == POISON)
					$target->GetNormal(true);
				$heal	= CalcRecoveryValue($skill,$user,$target);
				RecoverHP($target,$heal);
				break;
*/
			//	소생계의 기술.
			case 3040:// Resurrection
			case 5030:// SoulRestor
			case 5063:// WakeUp
				if($target->STATE !== 1) break;
				$heal	= CalcRecoveryValue($skill,$user,$target);
				$target->GetNormal(true);
				RecoverHP($target,$heal);
				break;

			case 3050://Quick
				if($target == $user) return false;
				if($target->expect) return false;
				//$target->Quick($this->delay + 1);
				print("<span class=\"support\">".$target->Name("bold")." 행동이 빨라졌습니다!</span>");
				$target->DelayCut(101,$this->delay,1);
				print("<br />\n");
				break;

			case 3055://CastAsist
				if($target->expect && $target->expect_type === 1) {
					print("<span class=\"support\">".$target->Name("bold")." 시전 시간이 단축되었습니다!</span>");
					$target->DelayCut(60,$this->delay,1);
					print("<br />\n");
				}
				break;

			case 3060://HolyShield
			case 5067://BananaProtection
				if(!$target->SPECIAL["Barrier"]) {
					$target->GetSpecial("Barrier",true);
					print("<span class=\"support\">".$target->Name("bold")." got barriered!</span><br />\n");
				}
				break;
/*
			case 3101: // Blessing(아군 SP회복)
				$RATE	= 3;
				$SpRec	= ceil(sqrt($target->MAXSP) * $RATE);
				RecoverSP($target,$SpRec);
				break;

			case 3102: // Benediction
				$RATE	= 5;
				$SpRec	= ceil(sqrt($target->MAXSP) * $RATE);
				RecoverSP($target,$SpRec);
				break;

			case 3103: // Sanctuary
				$RATE	= 7;
				$SpRec	= ceil(sqrt($target->MAXSP) * $RATE);
				RecoverSP($target,$SpRec);
				break;
*/
case 3113: // Berserk
break;

			case 3120: // FirstAid
				$heal	= 50 + $target->MAXHP * 1/10;
				$heal	= ceil($heal);
				RecoverHP($target,$heal);
				break;

			case 3121: // SelfRecovery
				$heal	= 50 + $target->MAXHP * 2/10;
				$heal	= ceil($heal);
				RecoverHP($target,$heal);
				break;

			case 3122:// HyperRecovery
				$dif	= $user->MAXHP - $user->HP;
				$heal	= ceil($dif*0.6);
				RecoverHP($target,$heal);
				break;

			// 소환 캐릭터에만 적응하는 기술
			case 3300:// PowerTrain
			case 3301:// MindTrain
			case 3302:// SpeedTrain
			case 3303:// DefenceTrain
			case 3304:
			case 3305:
			case 3306:
			case 3307:
			case 3308:
			case 3310://SuppressBeast
				if(!$target->summon) break;
				$this->StatusChanges($skill,$target);
				break;

			case 3900:// GetPoison
				print("중독되었습니다<br />\n");
				$user->GetPoison(100);
				break;
			case 3901:// GetDead
				DamageHP($user,9999);
				break;

			case 4000: // StanceRestore(임전 태세)
				if($target->position != $target->POSITION) {
					$target->Move($target->position);
				}
				break;

			// 적스킬
			case 5002: // BloodSuck
				$dmg	= CalcBasicDamage($skill,$user,$target,array("pierce"=>1));
				AbsorbHP($target,$dmg,$user,$dmg);
				return $dmg;

			case 5006: // Charge!!!
				if($user == $target) {
					$user->POSITION = "back";
					return false;//자신은 대상외
				}
				if($target->POSITION == "back") {
					$target->POSITION = "front";
					print($target->Name("bold")." goes forward.<br />");
				}
				$this->StatusChanges($skill,$target);
				break;

			case 5060://ArmorSnatch
				$target->DownDEF(30);
				$target->DownMDEF(30);
				$user->UpDEF(30);
				$user->UpMDEF(30);
				break;

			// 스테이터스 변화형의 기술
			case 5022://Fortune
				if($user == $target) break;//자신에게는 사용하지 않는다.
				$heal	= CalcRecoveryValue($skill,$user,$target);
				RecoverHP($target,$heal);
				$this->StatusChanges($skill,$target);
				break;

			case 5803: // Spawn
				$spawn	= array(1018,1019,1020,1021,5002);
					$mob	= $spawn[array_rand($spawn)];
					$add	= CreateSummon($mob);
					$this->JoinCharacter($user,$add);
					$add->ShowImage("vcent");
					print($add->Name("bold")." 이(가) 팀에 합류했습니다.<br />\n");
					break;

			//---------------------------------------------//
			// 그 이외의 기술(여기가 가장 많이 분류된다)
			// 귀찮기 때문에 처리가 증가했다
			//---------------------------------------------//
			default:
				// 매직 스퀘어 그린다
				if($skill["MagicCircleAdd"]) {
					$this->MagicCircleAdd($user->team,$skill["MagicCircleAdd"]);
					print($user->Name("bold").'<span class="support"> draw MagicCircle x'.$skill["MagicCircleAdd"].'</span><br />'."\n");
				}
				// 매직 스퀘어 지운다(적)
				if($skill["MagicCircleDeleteEnemy"]) {
					$EnemyTeam	= ($user->team == TEAM_0)?TEAM_1:TEAM_0;//相手チ?ムを指定
					$this->MagicCircleDelete($EnemyTeam,$skill["MagicCircleDeleteEnemy"]);
					print($user->Name("bold").'<span class="dmg"> erased enemy MagicCircle x'.$skill["MagicCircleDeleteEnemy"].'</span><br />'."\n");
				}
				// HP지속 회복
				if($skill["HpRegen"]) {
					$target->GetSpecial("HpRegen",$skill["HpRegen"]);
					print($target->Name("bold").'<span class="recover"> gained HP regeneration +'.$skill["HpRegen"]."%</span><br />\n");
				}
				// SP지속 회복
				if($skill["SpRegen"]) {
					$target->GetSpecial("SpRegen",$skill["SpRegen"]);
					print($target->Name("bold").'<span class="support"> gained SP regeneration +'.$skill["SpRegen"]."%</span><br />\n");
				}
				// 영창 중의 캐릭터에만 적응하는 기술.
				if($skill["priority"] == "Charge" && !$target->expect)
					break;
				// 소환계의 처리
				if($skill["summon"]) {
					// 배열이 아니었으면 요소 1개의 배열로 해버린다.
					if(!is_array($skill["summon"]))
						$skill["summon"]	= array($skill["summon"]);
					foreach($skill["summon"] as $SummonNo) {
						$Strength	= $user->SUmmonPower();//소환력?
						$add	= CreateSummon($SummonNo,$Strength);
						if($skill["quick"])// 속공
							$add->Quick($this->delay * 2);
						//break;//여기 잡으면 에러 않게 된다(?).
							$this->JoinCharacter($user,$add);
							$add->ShowImage("vcent");
							print($add->Name("bold")." 이(가) 팀에 합류했습니다.<br />\n");
						}
					return true;
				}

				// 독의 치료
				if($skill["CurePoison"]) {
					if($target->STATE == POISON)
						$target->GetNormal(true);
				}
				// 기본적인 데미지의 계산
				if($skill["pow"]) {
					if($skill["support"]) {
						$heal	= CalcRecoveryValue($skill,$user,$target);
						RecoverHP($target,$heal);
						$this->StatusChanges($skill,$target);
					} else {
						if($skill["pierce"])//?? 여기서 설정할 필요 있어?
							$option["pierce"] = true;
						$dmg	= CalcBasicDamage($skill,$user,$target,$option);
						DamageHP($target,$dmg);
					}
				}
				// SP회복(레이트)
				if($skill["SpRecoveryRate"]) {
					$SpRec	= ceil(sqrt($target->MAXSP) * $skill["SpRecoveryRate"]);
					RecoverSP($target,$SpRec);
				}
				// 독화
				if($skill["poison"]) {
					$result	= $target->GetPoison($skill["poison"]);
					if($result === true)
						print($target->Name("bold")." <span class=\"spdmg\">중독</span>되었습니다!<br />\n");
					else if($result === "BLOCK")
						print($target->Name("bold")." 중독을 막았습니다.<br />\n");
				}
				// 노크 백(후위화)
				if($skill["knockback"])
					$target->KnockBack($skill["knockback"]);
				// 스테이터스 변화
				$this->StatusChanges($skill,$target);
				// 대열의 이동
				if($skill["move"])
					$target->Move($skill["move"]);
				// 행동을 늦춘다(DELAY)
				$this->DelayChar($target,$skill);
				return $dmg;
		endswitch;
	}
//////////////////////////////////////////////////
//	행동을 늦춘다
	function DelayChar($target,$skill) {
		if(!$skill["delay"])
			return false;

		print($target->Name("bold")." delayed ");
		$target->DelayByRate($skill["delay"],$this->delay,1);
		print(".<br />\n");
	}
//////////////////////////////////////////////////
//	스테이터스를 변화시킨다
//	Class내에 없으면 타목.
	function StatusChanges($skill,$target) {
		if($skill["PlusSTR"])
			$target->PlusSTR($skill["PlusSTR"]);
		if($skill["PlusINT"])
			$target->PlusINT($skill["PlusINT"]);
		if($skill["PlusDEX"])
			$target->PlusDEX($skill["PlusDEX"]);
		if($skill["PlusSPD"]) {
			$target->PlusSPD($skill["PlusSPD"]);
			$this->ChangeDelay();
		}
		if($skill["PlusLUK"])
			$target->PlusLUK($skill["PlusLUK"]);

		if($skill["UpMAXHP"])
			$target->UpMAXHP($skill["UpMAXHP"]);
		if($skill["UpMAXSP"])
			$target->UpMAXSP($skill["UpMAXSP"]);
		if($skill["UpSTR"])
			$target->UpSTR($skill["UpSTR"]);
		if($skill["UpINT"])
			$target->UpINT($skill["UpINT"]);
		if($skill["UpDEX"])
			$target->UpDEX($skill["UpDEX"]);
		if($skill["UpSPD"]) {
			$target->UpSPD($skill["UpSPD"]);
			$this->ChangeDelay();
		}
		if($skill["UpATK"])
			$target->UpATK($skill["UpATK"]);
		if($skill["UpMATK"])
			$target->UpMATK($skill["UpMATK"]);
		if($skill["UpDEF"])
			$target->UpDEF($skill["UpDEF"]);
		if($skill["UpMDEF"])
			$target->UpMDEF($skill["UpMDEF"]);

		if($skill["DownMAXHP"])
			$target->DownMAXHP($skill["DownMAXHP"]);
		if($skill["DownMAXSP"])
			$target->DownMAXSP($skill["DownMAXSP"]);
		if($skill["DownSTR"])
			$target->DownSTR($skill["DownSTR"]);
		if($skill["DownINT"])
			$target->DownINT($skill["DownINT"]);
		if($skill["DownDEX"])
			$target->DownDEX($skill["DownDEX"]);
		if($skill["DownSPD"]) {
			$target->DownSPD($skill["DownSPD"]);
			$this->ChangeDelay();
		}
		if($skill["DownATK"])
			$target->DownATK($skill["DownATK"]);
		if($skill["DownMATK"])
			$target->DownMATK($skill["DownMATK"]);
		if($skill["DownDEF"])
			$target->DownDEF($skill["DownDEF"]);
		if($skill["DownMDEF"])
			$target->DownMDEF($skill["DownMDEF"]);
	}

}
//////////////////////////////////////////////////
//	HP에 데미지
function DamageHP($target,$value) {
	print($target->Name("bold").'에게 <span class="dmg"><span class="bold">'.$value.'</span> 피해</span>');
	$target->HpDamage($value);
	print("<br />\n");
}
//////////////////////////////////////////////////
//	HP에 데미지(1 이하가 되지 않는다)
function DamageHP2($target,$value) {
	print($target->Name("bold").'에게 <span class="dmg"><span class="bold">'.$value.'</span> 피해</span>');
	$target->HpDamage2($value);
	print("<br />\n");
}
//////////////////////////////////////////////////
//	SP에 데미지
function DamageSP($target,$value) {
	print($target->Name("bold").'에게 <span class="spdmg"><span class="bold">'.$value.'</span> 스테미나 피해</span>');
	$target->SpDamage($value);
	print("<br />\n");
}
//////////////////////////////////////////////////
//	HP의 회복
function RecoverHP($target,$value) {
	print($target->Name("bold").' <span class="recover">체력 <span class="bold">'.$value.'</span> 회복</span>');
	$target->HpRecover($value);
	print("<br />\n");
}
//////////////////////////////////////////////////
//	SP의 회복
function RecoverSP($target,$value) {
	print($target->Name("bold").' <span class="support">스테미나 <span class="bold">'.$value.'</span> 회복</span>');
	$target->SpRecover($value);
	print("<br />\n");
}
//////////////////////////////////////////////////
//	HP의 흡수
function AbsorbHP($target,$value,$user,$value2) {
	print('<span class="recover">체력 <span class="bold">'.$value.'</span> 흡수</span>');
	$user->HpRecover($value);
	print(' - 대상 '.$target->Name("bold"));
	$target->HpDamage($value);
	print("<br />\n");
}
//////////////////////////////////////////////////
//	SP의 회복
function AbsorbSP($target,$value,$user,$value2) {
	print('<span class="support">스테미나 <span class="bold">'.$value.'</span> 흡수</span>');
	$user->SpRecover($value);
	print(' - 대상 '.$target->Name("bold"));
	$target->SpDamage($value);
	print("<br />\n");
}
//////////////////////////////////////////////////
//	기본적인 데미지 계산식에서 데미지만 돌려준다.
function CalcBasicDamage($skill,$user,$target,$option=null) {
	//기본적인 데미지 계산(물리 or마법)
	if($skill["type"] == 0) {//물리
		if($skill["inf"] == "dex")//위력을 DEX 의존으로 한다
			$str	= $user->DEX;
		else
			$str	= $user->STR;
		$dmg	= sqrt($str)*10;
		$dmg	+= $user->atk[0];//장비의 물공
		$dmg	*= $skill["pow"]/100;
		// 추가 방어 무시 데미지
		if($user->SPECIAL["Pierce"]["0"]) {
			$Pierce	= $user->SPECIAL["Pierce"]["0"] * $skill["pow"]/100;
		}
	} else {//마법
		$int	= $user->INT;
		$dmg	= sqrt($int)*10;
		$dmg	+= $user->atk[1];//장비의 마공
		$dmg	*= $skill["pow"]/100;
		// 추가 방어 무시 데미지
		if($user->SPECIAL["Pierce"]["1"]) {
			$Pierce	= $user->SPECIAL["Pierce"]["1"] * $skill["pow"]/100;
		}
	}

	if($option["multiply"])
		$dmg	*= $option["multiply"];

	// 1회 공격을 막아 0으로 한다.
	if($target->SPECIAL["Barrier"]) {
		$target->GetSpecial("Barrier",false);
		print("Attack has disappeared.<br />\n");
		$dmg	= 0;
	}

	$min	= $dmg*(1/10);//최저 보증 다메지

	//상대의 방어력에 의한 경감
	if(!$option["pierce"]) {
		if($skill["type"] == 0) {//물리
			$dmg	*= 1 - $target->def["0"]/100;
			$dmg	-= $target->def["1"];
		} else {//마법
			$dmg	*= 1 - $target->def["2"]/100;
			$dmg	-= $target->def["3"];
		}
	}
	$dmg	+=	$Pierce;
	//데미지의 격차
	//$dmg	*= mt_rand(90,110)/100;
	//$dmg	*= mt_rand(90,110)/100;
	//최저 데미지인지 어떤지
	if($dmg < $min)
		$dmg	= $min;

	return ceil($dmg);//최종 데미지
}
//////////////////////////////////////////////////
//	회복량의 계산
	function CalcRecoveryValue($skill,$user,$target) {
		$int	= $user->INT;
		$heal	= sqrt($int)*10;
		$heal	+= $user->atk["1"];//장비의 마공
		$heal	*= $skill["pow"]/100;
		$heal	= ceil($heal);

		// 회복량 증가계 패시브

		// 받는 측이 회복량 증가계의 패시브 스킬을 가지고 있으면 늘어난다
		//if($user->special["?"])
		//	

		return $heal;
	}
?>
