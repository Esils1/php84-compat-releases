<?php 
include(CLASS_SKILL_EFFECT);
class battle extends ClassSkillEffect{
/*
 * $battle	= new battle($MyParty,$EnemyParty);
 * $battle->SetTeamName($this->name,$party["name"]);
 * $battle->Process();//쟁트낙뾰
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
	// teams
	var $team0, $team1;
	// team name
	var $team0_name, $team1_name;
	// team ave level
	var $team0_ave_lv, $team1_ave_lv;

	// 渠鑒왠
	var $team0_mc = 0;
	var $team1_mc = 0;

	// 쟁트ㅞ뵉쭹?【τ웃(긴캣ㅅㅼㅻ꼼퓰윗ㅞㄲㅻ)
	var $BattleMaxTurn	= BATTLE_MAX_TURNS;
	var $NoExtends	= false;

	//
	var $NoResult	= false;

	// 쟁트해례
	var $BackGround = "grass";

	// Ⅹ?ν【λ ( << >> ˙ ㅃㅼㅞ揀웃)
	var $Scroll = 0;

	// 쥼?α【Ⅸ
	var $team0_dmg = 0;
	var $team1_dmg = 0;
	// 쥼밋튼뀨웃
	var $actions = 0;
	// 쟁트ㅛㄺㅁㅻ댑썅Ηⅲμⅳ
	var $delay;
	// 쐴貢Α【?
	var $result;
	// ㅲㅹㄸㅻㄺ뜯
	var $team0_money, $team1_money;
	// ㅂㅓㅘㅇㅏⅱⅳΖ?
	var $team0_item=array(), $team1_item=array();
	var $team0_exp=0, $team1_exp=0;// 쥼론립촐。

	// 팅쇱ㅚ揀웃
	var $ChangeDelay	= false;//?γιㅞSPDㄼ揀꼍ㅇㅏ붰ㅛDELAYㆂ뵈롼뻣ㅉㅻ。

	var $BattleResultType	= 0;// 0=룩춧춧ㄻㅚㅁㅼㅠDraw 1=으쨍솎ㅞ웃ㅗ쐴함ㆂ룩ㅱㅻ
	var $UnionBattle;// 뼛ㅺHP쥼HPㆂ괏ㅉ(????/????)
//////////////////////////////////////////////////
//	ⅣτⅩΘι??。

	function __construct($team0,$team1) {
		$this->battle($team0,$team1);
	}

//////////////////////////////////////////////////
//	ⅣτⅩΘι??。

	//냔Α【?ㅞ핼轎ㆂ숑ㅁㅘㅻ。
	function battle($team0,$team1) {
		include_once(DATA_JUDGE);
		include_once(DATA_SKILL);
		include_once(DATA_ITEM);

		//βτⅩ?【ㄼ뺘쟁ㅇㅖㅚㄿㅖㅲ쑈눌ㅅㅼㅻ얠밭ㄼㄲㅻㅞㅗ
		include_once(CLASS_MONSTER);

		$this->team0	= $team0;
		$this->team1	= $team1;

		// 냔Α【?ㅛ쟁트잽錮ㅞ揀웃ㆂ잘쾨ㅉㅻ(class.char.php)
		// 증히ㅞ팅쇱덧퓰툼ㆂ롼뻣ㅇㅖ잘쾨ㅉㅻ。
		// 쟁트잽錮ㅞ揀웃ㅟ쭹訶샙귐몄ㅐㅓㅏㅺㅉㅻ。class.char.phpㆂ뺘안。
		//  $this->team["$key"] ㅗ턴ㅉㅃㅘ.(과웃ㅟΑ【?휘방)
		foreach($this->team0 as $key => $char)
			$this->team0["$key"]->SetBattleVariable(TEAM_0);
		foreach($this->team1 as $key => $char)
			$this->team1["$key"]->SetBattleVariable(TEAM_1);
		//dump($this->team0[0]);
		// delay닢口
		$this->SetDelay();//Ηⅲμⅳ롼뻣
		$this->DelayResetAll();//썽덟꼍
	}
//////////////////////////////////////////////////
//	
	function SetResultType($var) {
		$this->BattleResultType	= $var;
	}
//////////////////////////////////////////////////
//	UnionBattleㅗㄲㅻ색ㅛㅉㅻ。
	function SetUnionBattle() {
		$this->UnionBattle	= true;
	}
//////////////////////////////////////////////////
//	해례꿱짐ㆂ?ΓΘㅉㅻ。
	function SetBackGround($bg) {
		$this->BackGround	= $bg;
	}
//////////////////////////////////////////////////
//	쟁트ㅛ?γι??【ㆂ텁충뺘꼴ㅅㅋㅻ。
	function JoinCharacter($user,$add) {
		foreach($this->team0 as $char) {
			if($user === $char) {
				//array_unshift($this->team0,$add);
				$add->SetTeam(TEAM_0);
				array_push($this->team0,$add);
				//dump($this->team0);
				$this->ChangeDelay();
				return 0;
			}
		}
		foreach($this->team1 as $char) {
			if($user === $char) {
				//array_unshift($this->team1,$add);
				$add->SetTeam(TEAM_1);
				array_push($this->team1,$add);
				$this->ChangeDelay();
				return 0;
			}
		}
	}
//////////////////////////////////////////////////
//	맞낌?【τ웃ㆂ룩ㅱㅑㅳㄶ。
	function LimitTurns($no) {
		$this->BattleMaxTurn	= $no;
		$this->NoExtends		= true;//ㅃㅼ걺얍긴캣ㅟㅇㅚㄴ。
	}
//////////////////////////////////////////////////
//	
	function NoResult() {
		$this->NoResult	= true;
	}
//////////////////////////////////////////////////
//	쟁트ㅞ뵉쭹?【τ웃ㆂ집ㅴㅉ。
	function ExtendTurns($no,$notice=false) {
		// 긴캣ㅇㅚㄴ揀웃ㄼ잘쾨ㅅㅼㅖㄴㅼㅠ긴캣ㅇㅚㄴ。
		if($this->NoExtends === true) return false;

		$this->BattleMaxTurn	+= $no;
		if(BATTLE_MAX_EXTENDS < $this->BattleMaxTurn)
			$this->BattleMaxTurn	= BATTLE_MAX_EXTENDS;
		if($notice) {
print <<< HTML
	<tr><td colspan="2" class="break break-top bold" style="text-align:center;padding:20px 0;">
	전투 턴이 연장되었습니다.
	</td></tr>
HTML;
		}
		return true;
	}
//////////////////////////////////////////////////
//	쟁트충넌팀ㅇㅏⅱⅳΖ?ㆂ癎ㅉ。
	function ReturnItemGet($team) {
		if($team == TEAM_0) {
			if(count($this->team0_item) != 0)
				return $this->team0_item;
			else
				return false;
		} else if($team == TEAM_1) {
			if(count($this->team1_item) != 0)
				return $this->team1_item;
			else
				return false;
		}
	}
//////////////////////////////////////////////////
//	칫쟁솎짝ㄼ쐴貢ㅇㅏㄻ­
	function ReturnBattleResult() {
		return $this->result;
	}
//////////////////////////////////////////////////
//	쟁트뎅臼ㆂ艮쨍ㅉㅻ
	function RecordLog($type=false) {
		if($type == "RANK") {
			$file	= LOG_BATTLE_RANK;
			$log	= @glob(LOG_BATTLE_RANK."*");
			$logAmount = MAX_BATTLE_LOG_RANK;
		} else if($type == "UNION") {
			$file	= LOG_BATTLE_UNION;
			$log	= @glob(LOG_BATTLE_UNION."*");
			$logAmount = MAX_BATTLE_LOG_UNION;
		} else {
			$file	= LOG_BATTLE_NORMAL;
			$log	= @glob(LOG_BATTLE_NORMAL."*");
			$logAmount = MAX_BATTLE_LOG;
		}

		// 매ㄴνⅠㆂ씹ㅉ
		$i	= 0;
		while($logAmount <= count($log) ) {
			unlink($log["$i"]);
			unset($log["$i"]);
			$i++;
		}

		// 옆ㅇㄴνⅠㆂ븜ㅻ
		$time	= time().substr(microtime(),2,6);
		$file	.= $time.".dat";

		$head	= $time."\n";//낙뾰샤닛(1밋涇)
		$head	.= $this->team0_name."<>".$this->team1_name."\n";//뺘꼴Α【?(2밋涇)
		$head	.= count($this->team0)."<>".count($this->team1)."\n";//뺘꼴와웃(3밋涇)
		$head	.= $this->team0_ave_lv."<>".$this->team1_ave_lv."\n";//却뚜μ?λ(4밋涇)
		$head	.= $this->result."\n";//쐴貢Α【?(5밋涇)
		$head	.= $this->actions."\n";//쥼?【τ웃(6밋涇)
		$head	.= "\n";// 끙밋(7밋涇)

		WriteFile($file,$head.ob_get_contents());
	}
//////////////////////////////////////////////////
//	쟁트썼果(ㅃㅼㆂ셋밋ㅇㅖ쟁트ㄼ썼果ㅅㅼㅻ)
		function Process() {
			$this->BattleHeader();

			//쟁트ㄼ쉠ㅿㅻㅮㅗ략ㅺ癎ㅉ
			do {
			if($this->actions % BATTLE_STAT_TURNS == 0)//곗쾨닛넣ㅗ얾떱ㆂ섀
				$this->BattleState();//얾떱ㅞ섀

			// 밋튼?γι
			if(DELAY_TYPE === 0)
				$char	= &$this->NextActer();
			else if(DELAY_TYPE === 1)
				$char	= &$this->NextActerNew();

			$this->Action($char);//밋튼
			$result	= $this->BattleResult();//¸ㅞ밋튼ㅗ쟁트ㄼ쉠貫ㅇㅏㄻㅙㄶㄻㅞ횟쾨

			//돐ㅞ뽁錮툼ㅗSPDㄼ揀꼍ㅇㅏ얠밭DELAYㆂ뵈롼뻣ㅉㅻ。
			if($this->ChangeDelay)
				$this->SetDelay();

		} while(!$result);

		$this->ShowResult($result);//쟁트ㅞ룸꽐섀
		$this->BattleFoot();

		//$this->SaveCharacters();
	}
//////////////////////////////////////////////////
//	전투 중에도 보이는 돌아가기 버튼
	function BattleReturnButton() {
		$return_url = INDEX;
		$return_label = "처음으로";
		if(isset($_GET["common"])) {
			$return_url = INDEX."?hunt";
			$return_label = "전투 목록으로 돌아가기";
		} else if(isset($_GET["union"])) {
			$return_url = INDEX."?hunt";
			$return_label = "전투 목록으로 돌아가기";
		} else if(isset($_GET["menu"]) && $_GET["menu"] === "rank") {
			$return_url = INDEX."?menu=rank";
			$return_label = "콜로세움으로 돌아가기";
		} else if($_SERVER["QUERY_STRING"] === "simulate") {
			$return_url = INDEX."?simulate";
			$return_label = "모의 전투로 돌아가기";
		}
		print('<div class="battle-return-fixed" style="position:fixed;right:18px;bottom:18px;z-index:1000;background:#25384b;border:1px solid #8ea3b8;padding:7px 12px;"><a href="'.$return_url.'" style="color:#ffffff;text-decoration:none">'.$return_label.'</a></div>'."\n");
	}
//////////////////////////////////////////////////
//	쟁트멨ㅞ?γι??【얾떱ㆂ艮쨍ㅉㅻ。
	function SaveCharacters() {
		//Α【?0
		foreach($this->team0 as $char) {
			$char->SaveCharData();
		}
		//Α【?1
		foreach($this->team1 as $char) {
			$char->SaveCharData();
		}
	}

//////////////////////////////////////////////////
//	쟁트쉠貫ㅞ횟쾨
//	졍곳삑ㆃㅗㅻ=draw(?)
	function BattleResult() {
		$team0Lose	= false;
		$team1Lose	= false;
		if(CountAlive($this->team0) == 0)//졍곳ㅇㅬ【ㅚㅹㅁㅛㅉㅻ。
			$team0Lose	= true;
		if(CountAlive($this->team1) == 0)//졍곳ㅇㅬ【ㅚㅹㅁㅛㅉㅻ。
			$team1Lose	= true;
		//쐴솎ㅞΑ【?휘방ㄻ과ㄽ暇ㅁㆂ癎ㅉ
		if( $team0Lose && $team1Lose ) {
			$this->result	= DRAW;
			return "draw";
		} else if($team0Lose) {//team1 won
			$this->result	= TEAM_1;
			return "team1";
		} else if($team1Lose) {// team0 won
			$this->result	= TEAM_0;
			return "team0";

		// 刮Α【?으쨍ㅇㅖㄴㅖ뵉쭹밋튼웃ㅛ찾ㅇㅏ샤。
		} else if($this->BattleMaxTurn <= $this->actions) {
			// 으쨍솎웃ㅞ복。
			/*
				// 으쨍솎웃ㅞ복ㄼ1와걺얍ㅚㅹ긴캣
			$AliveNumDiff	= abs(CountAlive($this->team0) - CountAlive($this->team1));
			if(0 < $AliveNumDiff && $this->BattleMaxTurn < BATTLE_MAX_EXTENDS) {
			*/
			$AliveNumDiff	= abs(CountAlive($this->team0) - CountAlive($this->team1));
			$Not5	= (CountAlive($this->team0) != 5 && CountAlive($this->team1) != 5);
			//$lessThan4	= ( CountAlive($this->team0) < 5 || CountAlive($this->team1) < 5 );
			//if( ( $lessThan4 || 0 < $AliveNumDiff ) && $this->BattleMaxTurn < BATTLE_MAX_EXTENDS ) {
			if( ( $Not5 || 0 < $AliveNumDiff ) && $this->BattleMaxTurn < BATTLE_MAX_EXTENDS ) {
				if($this->ExtendTurns(TURN_EXTENDS,1))
					return false;
			}

			// 룩춧춧ㄻㅚㅁㅼㅠㅏㅐ과ㄽ暇ㅁㅛㅉㅻ。
			if($this->BattleResultType == 0) {
				$this->result	= DRAW;//과ㄽ暇ㅁ。
				return "draw";
			// 룩춧춧ㄻㅚㅁㅼㅠ으쨍솎ㅞ웃ㅗ쐴함ㆂㅔㅁㅻ。
			} else if($this->BattleResultType == 1) {
				// ㅘㅺㄲㄸㅊ과ㄽ暇ㅁㅛ잘쾨
				// (1) 으쨍솎웃ㄼ쩔ㄴㅫㄶㄼ쐴ㅑ
				// (2) (1) ㄼ튿ㅈㅚㅹ쥼?α【Ⅸㄼ쩔ㄴㅫㄶㄼ쐴ㅑ
				// (3) (2) ㅗㅲ튿ㅈㅚㅹ과ㄽ暇ㅁ∞???(or漑귑짝ㅞ쐴ㅑ)
	
				$team0Alive	= CountAliveChars($this->team0);
				$team1Alive	= CountAliveChars($this->team1);
				if($team1Alive < $team0Alive) {// team0 won
					$this->result	= TEAM_0;
					return "team0";
				} else if($team0Alive < $team1Alive) {// team1 won
					$this->result	= TEAM_1;
					return "team1";
				} else {
					$this->result	= DRAW;
					return "draw";
				}
			} else {
				$this->result	= DRAW;
				print("error321708.<br /> ????? ?? ?? ??? ????.");
				return "draw";// ⅷι【뀨흰。
			}

			$this->result	= DRAW;
			print("error321709.<br /> ????? ?? ?? ??? ????.");
			return "draw";// ⅷι【뀨흰。
		}
	}
//////////////////////////////////////////////////
//	쟁트ㅞ룸꽐섀
	function ShowResult($result) {

		// 보짝ㅞΑ【?(쟁트ㆂ숑ㅁㅏ짝)
		$TotalAlive2	= 0;
		$TotalHp2	= 0;
		$TotalMaxHp2	= 0;
		// 뼛ㅺHP / 밭롼HP ㅞ 섀
		foreach($this->team1 as $char) {//Α【?1
			if($char->STATE !== DEAD)
				$TotalAlive2++;
			$TotalHp2	+= $char->HP;//밭롼HP
			$TotalMaxHp2	+= $char->MAXHP;//밭롼뵉쭹HP
		}

		// 괜짝ㅞΑ【?(쟁트ㆂ뼜넷ㅁㅏ짝)
		$TotalAlive1	= 0;
		$TotalHp1	= 0;
		$TotalMaxHp1	= 0;
		foreach($this->team0 as $char) {//Α【?0
			if($char->STATE !== DEAD)
				$TotalAlive1++;
			$TotalHp1	+= $char->HP;//밭롼HP
			$TotalMaxHp1	+= $char->MAXHP;//밭롼뵉쭹HP
		}

		// 룸꽐ㆂ섀ㅇㅚㄴ。
		if($this->NoResult) {
			print('<tr><td colspan="2" style="text-align:center;padding:10px 0px" class="break break-top">');
			//print("<a name=\"s{$this->Scroll}\"></a>");// Ⅹ?ν【λㅞ뵉멨
			print("??? ??");
			print("</td></tr>\n");
			print('<tr><td class="teams break">'."\n");
			// 보짝Α【?
			print("남은 체력 : {$TotalHp2}/{$TotalMaxHp2}<br />\n");
			print("생존 : {$TotalAlive2}/".count($this->team1)."<br />\n");
			print("총 피해 : {$this->team1_dmg}<br />\n");
			// 괜짝Α【?
			print('</td><td class="teams break">'."\n");
			print("남은 체력 : {$TotalHp1}/{$TotalMaxHp1}<br />\n");
			print("생존 : {$TotalAlive1}/".count($this->team0)."<br />\n");
			print("총 피해 : {$this->team0_dmg}<br />\n");
			print("</td></tr>\n");
			return false;
		}

		//if($this->actions % BATTLE_STAT_TURNS != 0 || $result == "draw")
		//if(($this->actions + 1) % BATTLE_STAT_TURNS != 0)
		$BreakTop	= " break-top";
		print('<tr><td colspan="2" style="text-align:center;padding:10px 0px" class="break'.$BreakTop.'">'."\n");
		//print($this->actions."%".BATTLE_STAT_TURNS."<br>");
		print("<a name=\"s{$this->Scroll}\"></a>\n");// Ⅹ?ν【λㅞ뵉멨
			if($result == "draw") {
				print("<span class=\"bold\">전투 결과 : 무승부</span><br />\n");
				print("<span style=\"font-size:150%\">무승부</span><br />\n");
			} else if($result == "team0") {
				print("<span class=\"bold\">전투 결과 : 승리</span><br />\n");
				$Team	= &$this->{$result};
				$TeamName	= $this->{$result."_name"};
				print("<span style=\"font-size:200%\">{$TeamName} 승리!</span><br />\n");
			} else {
				print("<span class=\"bold dmg\">전투 결과 : 패배</span><br />\n");
				$Team	= &$this->{$result};
				$TeamName	= $this->{$result."_name"};
				print("<span style=\"font-size:200%\">{$TeamName} 승리!</span><br />\n");
		}

		print('<tr><td class="teams">'."\n");
		// Unionㅘㅍㄶㅗㅚㄴㅞㅗㅿㅁㅻ
		print("남은 체력 : ");
		print($this->UnionBattle?"????/????":"{$TotalHp2}/{$TotalMaxHp2}");
		print("<br />\n");
/*
		if($this->UnionBattle) {
			print("HP remain : ????/????<br />\n");
		} else {
			print("HP remain : {$TotalHp2}/{$TotalMaxHp2}<br />\n");
		}
*/
		// 보짝Α【?
		print("생존 : {$TotalAlive2}/".count($this->team1)."<br />\n");
		print("총 피해 : {$this->team1_dmg}<br />\n");
		if($this->team1_exp)//팀ㅏ론립촐
			print("총 경험치 : ".$this->team1_exp."<br />\n");
		if($this->team1_money)//팀ㅏㄺ뜯
			print("자금 : ".MoneyFormat($this->team1_money)."<br />\n");
		if($this->team1_item) {//팀ㅏⅱⅳΖ?
			print("<div class=\"bold\">아이템</div>\n");
			foreach($this->team0_item as $itemno => $amount) {
				$item	= LoadItemData($itemno);
				print("<img src=\"".IMG_ICON.$item["img"]."\" class=\"vcent\">");
				print("{$item['name']} x {$amount}<br />\n");
			}
		}

		// 괜짝Α【?
		print('</td><td class="teams">');
		print("남은 체력 : {$TotalHp1}/{$TotalMaxHp1}<br />\n");
		print("생존 : {$TotalAlive1}/".count($this->team0)."<br />\n");
		print("총 피해 : {$this->team0_dmg}<br />\n");
		if($this->team0_exp)//팀ㅏ론립촐
			print("총 경험치 : ".$this->team0_exp."<br />\n");
		if($this->team0_money)//팀ㅏㄺ뜯
			print("자금 : ".MoneyFormat($this->team0_money)."<br />\n");
		if($this->team0_item) {//팀ㅏⅱⅳΖ?
			print("<div class=\"bold\">아이템</div>\n");
			foreach($this->team0_item as $itemno => $amount) {
				$item	= LoadItemData($itemno);
				print("<img src=\"".IMG_ICON.$item["img"]."\" class=\"vcent\">");
				print("{$item['name']} x {$amount}<br />\n");
			}
		}
		print("</td></tr>\n");
		//print("</td></tr>\n");//?
	}

//////////////////////////////////////////////////
//	?γιㅞ밋튼
	function Action($char) {
		// $char->judge ㄼ잘쾨ㅅㅼㅖㅚㅁㅼㅠ흼ㅠㅉ
		if($char->judge === array()) {
			$char->delay	= $char->SPD;
			return false;
		}

		// Α【?0ㅞ와ㅟ?λㅞ괜짝ㅛ
		// Α【?1ㅞ와ㅟ보짝ㅛ 밋튼펐股ㅘ룸꽐 ㆂ섀ㅉㅻ
		print("<tr><td class=\"ttd2\">\n");
		if($char->team === TEAM_0)
			print("</td><td class=\"ttd1\">\n");
		// 섐暇ㅞΑ【?ㅟㅙㅑㅹㄻ?
		foreach($this->team0 as $val) {
			if($val === $char) {
				$MyTeam	= &$this->team0;
				$EnemyTeam	= &$this->team1;
				break;
			}
		}
		//Α【?0ㅗㅚㄴㅚㅹΑ【?1
		if(!$MyTeam) {
			$MyTeam	= &$this->team1;
			$EnemyTeam	= &$this->team0;
		}

		//밋튼ㅞ횟쾨(뽁錮ㅉㅻ돐ㅞ횟쾨)
		if($char->expect) {// 귓쑨,츤ㅱ 눗貫
			$skill	= $char->expect;
			$return	= &$char->target_expect;
		} else {//쫠덧˚횟쾨˚Ⅹ?λ
			$JudgeKey	= -1;

			// 생쨀뀨록
			$char->AutoRegeneration();
			// 판얾쫴ㅚㅹ?α【Ⅸㆂ숑ㅁㅻ。
			$char->PoisonDamage();

			//횟쾨
			do {
				$Keys	= array();//란핼轎(썽덟꼍)
				do {
					$JudgeKey++;
					$Keys[]	= $JudgeKey;
				// 신假횟쾨ㅚㅹ샥ㅲ꼴ㄸㅻ
				} while($char->action["$JudgeKey"] == 9000 && $char->judge["$JudgeKey"]);

				//$return	= MultiFactJudge($Keys,$char,$MyTeam,$EnemyTeam);
				$return	= MultiFactJudge($Keys,$char,$this);

				if($return) {
					$skill	= $char->action["$JudgeKey"];
					foreach($Keys as $no)
						$char->JdgCount[$no]++;//룩쾨ㅇㅏ횟쳬ㅞ?ⅵτΘㄶｐ
					break;
				}
			} while($char->judge["$JudgeKey"]);

			/* // (2007/10/15)
			foreach($char->judge as $key => $judge){
				// $return ㅟ true,false,핼轎ㅞㄴㅕㅼㄻ
				// 핼轎ㅞ얠밭ㅟ횟쾨ㅞ얻뤄ㅛ곗쵠ㅇㅏ?γιㄼ癎ㅻ(Ο?)。
				$return	=& DecideJudge($judge,$char,$MyTeam,$EnemyTeam,$key);
				if($return) {
					$skill	= $char->action["$key"];
					$char->JdgCount[$key]++;//룩쾨ㅇㅏ횟쳬ㅞ?ⅵτΘㄶｐ
					break;
				}
			}
			*/
		}

		// 쟁트ㅞ쥼밋튼뀨웃ㆂ집ㅴㅉ。
		$this->actions++;

		if($skill) {
			$this->UseSkill($skill,$return,$char,$MyTeam,$EnemyTeam);
		// 밋튼ㅗㄽㅚㄻㅓㅏ얠밭ㅞ썼果
		} else {
			print($char->Name("bold")." sunk in thought and couldn't act.<br />(No more patterns)<br />\n");
			$char->DelayReset();
		}

		//Ηⅲμⅳκ?ΓΘ
		//if($ret	!== "DontResetDelay")
		//	$char->DelayReset;

		//echo $char->name." ".$skill."<br>";//널푤錮
		//?λㅞ쉠ㅿㅺ
		if($char->team === TEAM_1)
			print("</td><td class=\"ttd1\">&nbsp;\n");
		print("</td></tr>\n");
	}
//////////////////////////////////////////////////
//	쥼?α【Ⅸㆂ꼴뻣ㅉㅻ
	function AddTotalDamage($team,$dmg) {
		if(!is_numeric($dmg)) return false;
		if($team == $this->team0)
			$this->team0_dmg	+= $dmg;
		else if($team == $this->team1)
			$this->team1_dmg	+= $dmg;
	}

//////////////////////////////////////////////////
//
	function UseSkill($skill_no,$JudgedTarget,$My,$MyTeam,$Enemy) {
		$skill	= LoadSkillData($skill_no);//돐Η【?팖ㅰ

		// 댐?ⅳΨ곗쵠
		if($skill["limit"] && !$My->monster) {
			if(!$skill["limit"][$My->WEAPON]) {
				print('<span class="u">'.$My->Name("bold"));
				print('<span class="dmg"> 사용 실패 </span>: ');
				print("<img src=\"".IMG_ICON.$skill["img"]."\" class=\"vcent\"/>");
				print($skill['name']."</span><br />\n");
				//print($My->Name("bold")." Failed to use ".$skill["name"]."<br />\n");
				print("(무기 종류가 맞지 않습니다)<br />\n");
				$My->DelayReset();// 밋튼썹ㆂκ?ΓΘ
				return true;
			}
		}

		// SP짯
		if($My->SP < $skill["sp"]) {
			print($My->Name("bold")." ".$skill["name"]." 사용 실패(스테미나 부족)");
			if($My->expect) {//ㅲㅇ귓쑨ㅴ츤ㅱ텁충ㅗSPㄼ짯ㅇㅏ얠밭
				$My->ResetExpect();
			}
			$My->DelayReset();// 밋튼썹ㆂκ?ΓΘ
			return true;
		}

		// ㅲㅇ "귓쑨" ㅴ "츤ㅱ" ㄼ斛ㅚ돐ㅚㅹ(+귓쑨낙뾰ㅇㅖㅚㄴ얠밭)˚귓쑨,츤ㅱ낙뾰
		if($skill["charge"]["0"] && $My->expect === false) {
			// ㅃㅑㅹㅟ츤ㅱㅘ귓쑨ㆂ낙뾰ㅉㅻ얠밭 /////////////////////
			// 嫁果ㄻ渠匣ㅛㅸㅓㅖ訶ㆂ揀ㄸㅻ
			if($skill["type"] == 0) {//嫁果
				print('<span class="charge">'.$My->Name("bold").' 힘을 모으기 시작했습니다.</span>');
				$My->expect_type	= CHARGE;
			} else {//渠匣
				print('<span class="charge">'.$My->Name("bold").' 시전을 시작했습니다.</span>');
				$My->expect_type	= CAST;
			}
			$My->expect	= $skill_no;//귓쑨…츤ㅱ눗貫ㅘ튿샤ㅛ뽁錮ㅉㅻ돐
			// ˛뽁ㅓㅖㅚㄴㅞㅗⅣατΘㅛㅇㅏ。
			//$My->target_expect	= $JudgedTarget;//곗깸?【ⅢΓΘㅲ艮쨍
			//귓쑨…츤ㅱ샤닛ㅞ잘쾨。
			$My->DelayByRate($skill["charge"]["0"],$this->delay,1);
			print("<br />\n");

			// 쟁트ㅞ쥼밋튼뀨웃ㆂ맏ㅹㅉ(츤ㅱor귓쑨 ㅟ밋튼ㅛ퐁ㅼㅚㄴ)
			$this->actions--;

			return true;//Ηⅲμⅳ揀뭐ㅇㅏㄻㅹκ?ΓΘㅇㅚㄴㅸㄶㅛ。
		} else {
			// 돐ㆂ셋붰ㅛ뽁錮ㅉㅻ ///////////////////////////////////

			// 밋튼뀨웃ㆂΨιⅩㅉㅻ
			$My->ActCount++;

			// 밋튼펐股ㅞ섀(밋튼ㅉㅻ)
			print('<div class="u">'.$My->Name("bold"));
			print("<img src=\"".IMG_ICON.$skill["img"]."\" class=\"vcent\"/>");
			print($skill['name']."</div>\n");

			// 渠匣왠ㆂ씹희(黔鑒)
			if($skill["MagicCircleDeleteTeam"])
			{
				if($this->MagicCircleDelete($My->team,$skill["MagicCircleDeleteTeam"])) {
					print($My->Name("bold").'<span class="charge"> 마법진 x'.$skill["MagicCircleDeleteTeam"].' 사용</span><br />'."\n");
				// 渠匣왠씹희성함
				} else {
					print('<span class="dmg">실패!(마법진이 부족합니다)</span><br />'."\n");
					$My->DelayReset();// 밋튼썹ㆂκ?ΓΘ
					return true;
				}
			}

			// SPㅞ씹희(ㅃㅞ겁최ㅐㅘ츤ㅱ…귓쑨눗貫ㅘ튿샤ㅛ씹희ㅉㅻ)
			$My->SpDamage($skill["sp"],false);

			// Αγ【Ⅸ(귓쑨)눗貫ㅘ튿샤ㅛ뽁錮ㅉㅻ돐ㅞ언柑ㆂ씹ㅉ。
			if($My->expect)
				$My->ResetExpect();

			// HP돗윷돐ㅞ얠밭(Sacrifice)
			if($skill["sacrifice"])
				$My->SacrificeHp($skill["sacrifice"]);

		}

		// ?【ⅢΓΘㆂ젬ㅦ(몲渴)
		if($skill["target"]["0"] == "friend"):
			$candidate	= &$MyTeam;
		elseif($skill["target"]["0"] == "enemy"):
			$candidate	= &$Enemy;
		elseif($skill["target"]["0"] == "self"):
			$candidate[]	= &$My;
		elseif($skill["target"]["0"] == "all"):
			//$candidate	= $MyTeam + $Enemy;//???
			$candidate	= array_merge_recursive($MyTeam,$Enemy);//룸밭ㅞ멨,慤ㅣㆂιτ??ㅛㅇㅏ鑒ㄼㄴㄴ??
		endif;

		// 몲渴ㄻㅹ뽁錮ㅉㅻ쫑앴ㆂ젬ㅦ ˚ (Ⅹ?λ뽁錮)

		// 챰쫍ㅛ뽁錮
		if($skill["target"]["1"] == "individual") {
			$target	=& $this->SelectTarget($candidate,$skill);//쫑앴ㆂ젬찜
			if($defender =& $this->Defending($target,$candidate,$skill) )//쇤ㅺㅛ퐁ㅻ?γι
				$target	= &$defender;
			for($i=0; $i<$skill["target"]["2"]; $i++) {//챰쫍ㅛ假웃뀨셋밋
				$dmg	= $this->SkillEffect($skill,$skill_no,$My,$target);
				$this->AddTotalDamage($MyTeam,$dmg);
			}

		// 假웃ㅛ뽁錮
		} else if($skill["target"]["1"] == "multi") {
			for($i=0; $i<$skill["target"]["2"]; $i++) {
				$target	=& $this->SelectTarget($candidate,$skill);//쫑앴ㆂ젬찜
				if($defender =& $this->Defending($target,$candidate,$skill) )//쇤ㅺㅛ퐁ㅻ?γι
					$target	= &$defender;
				$dmg	= $this->SkillEffect($skill,$skill_no,$My,$target);
				$this->AddTotalDamage($MyTeam,$dmg);
			}

		// 졍쫍ㅛ뽁錮
		} else if($skill["target"]["1"] == "all") {
			foreach($candidate as $key => $char) {
				$target	= &$candidate[$key];
				//if($char->STATE === DEAD) break;//삑絳솎ㅟΡⅩ。
				if($skill["priority"] != "Dead") {//곗샤큭ㅛ。
					if($char->STATE === DEAD) break;//삑絳솎ㅟΡⅩ。
				}
				// 졍쫍뭉룐ㅟ쇤ㅺㅛ퐁ㅼㅚㄴ(ㅘㅉㅻ)
				for($i=0; $i<$skill["target"]["2"]; $i++) {
					$dmg	= $this->SkillEffect($skill,$skill_no,$My,$target);
					$this->AddTotalDamage($MyTeam,$dmg);
				}
			}
		}

		// 뽁錮멨뽁錮솎ㅛ궉뗍ㅉㅻ뫄꽐툼
		if($skill["umove"])
			$My->Move($skill["umove"]);

		// 뭉룐쫑앴ㅛㅚㅓㅏ?γι찾ㄼㅙㄶㅚㅓㅏㄻ널ㄻㅱㅻ(ㅘㅺㄲㄸㅊHP=0ㅛㅚㅓㅏㄻㅙㄶㄻ)。
		if($skill["sacrifice"]) { // Sacri록ㅞ돐ㆂ뽁ㅓㅏ얠밭。
			$Sacrier[]	= &$My;
			$this->JudgeTargetsDead($Sacrier);
		}
		list($exp,$money,$itemdrop)	= $this->JudgeTargetsDead($candidate);//蹇、쇠팀ㅉㅻ론립촐ㆂ팀ㅻ

		$this->GetExp($exp,$MyTeam);
		$this->GetItem($itemdrop,$MyTeam);
		$this->GetMoney($money,$MyTeam);

		// 돐ㅞ뽁錮툼ㅗSPDㄼ揀꼍ㅇㅏ얠밭DELAYㆂ뵈롼뻣ㅉㅻ。
		if($this->ChangeDelay)
			$this->SetDelay();

		// 밋튼멨ㅞ뮴컁(ㄼㄲㅼㅠ잘쾨ㅉㅻ)
		if($skill["charge"]["1"]) {
			$My->DelayReset();
			print($My->Name("bold")." 지연");
			$My->DelayByRate($skill["charge"]["1"],$this->delay,1);
			print("<br />\n");
			return false;
		}

		// 뵉멨ㅛ밋튼썹ㆂκ?ΓΘㅉㅻ。
		$My->DelayReset();
	}
//////////////////////////////////////////////////
//	론립촐ㆂ팀ㅻ
function GetExp($exp,$team) {
	if(!$exp) return false;

	$exp	= round(EXP_RATE * $exp);

	if($team === $this->team0){
		$this->team0_exp	+= $exp;
	} else {
		$this->team1_exp	+= $exp;
	}

	$Alive	= CountAliveChars($team);
	if($Alive === 0) return false;
	$ExpGet	= ceil($exp/$Alive);//으쨍솎ㅛㅐㅁ론립촐ㆂ暇ㅁㅻ。
	print("생존자가 {$ExpGet} 경험치를 획득했습니다.<br />\n");
	foreach($team as $key => $char) {
		if($char->STATE === 1) break;//삑絳솎ㅛㅟEXPㄲㅂㅚㄴ
		if($team[$key]->GetExp($ExpGet))//LvUpㅇㅏㅚㅹtrueㄼ癎ㅻ
			print("<span class=\"levelup\">".$char->Name()." 레벨 상승!</span><br />\n");
	}
}
//////////////////////////////////////////////////
//	ⅱⅳΖ?ㆂ쇠팀ㅉㅻ(Α【?ㄼ)
	function GetItem($itemdrop,$MyTeam) {
		if(!$itemdrop) return false;
		if($MyTeam === $this->team0) {
			foreach($itemdrop as $itemno => $amount) {
				$this->team0_item["$itemno"]	+= $amount;
			}
		} else {
			foreach($itemdrop as $itemno => $amount) {
				$this->team1_item["$itemno"]	+= $amount;
			}
		}
	}

	//////////////////////////////////////////////////
//	멨귑ㆂ쇤ㅺㅛ퐁ㅻ?γιㆂ젬ㅦ。
		function &Defending($target,$candidate,$skill) {
			static $none = false;
			if($target === false) return $none;

			if($skill["invalid"])//漑멩絹삳ㅗㄽㅻ돐。
				return $none;
			if($skill["support"])//쁑긺ㅚㅞㅗ?【Ιㅇㅚㄴ。
				return $none;
			if($target->POSITION == "front")//졀귑ㅚㅹ쇤ㅻ斛絹ㅇ。쉠ㅿㅻ
				return $none;
			// "졀귑ㅗ쒼놀ㅔ으쨍솎"ㆂ핼轎ㅛ됴ㅱㅻ˛
			// 졀귑 + 으쨍솎 + HP1걺얍 ㅛ揀뭐 ( 쩔초록뭉룐ㅗ삑ㅛㅚㄼㅹ쇤ㅻㅞㅗ [2007/9/20] )
			if(!is_array($candidate))
				return $none;
			$fore	= array();
			foreach($candidate as $key => $char) {
				//print("{$char->POSTION}:{$char->STATE}<br>");
				if($char->POSITION == "front" && $char->STATE !== 1 && 1 < $char->HP )
					$fore[]	= &$candidate["$key"];
			}
			if(count($fore) == 0)//졀귑ㄼㄴㅚㅁㅺㅳ쇤ㅼㅚㄴ。쉠ㅿㅻ
				return $none;
			// 곗와ㅕㅔ쇤ㅺㅛ퐁ㅻㄻ퐁ㅹㅚㄴㄻㆂ횟쾨ㅉㅻ。
			shuffle($fore);//핼轎ㅞ慤ㅣㆂ벽ㅌㅻ
			$defender	= false;
			$HpRate	= 0;
			$prob	= 0;
			foreach($fore as $key => $char) {
			// 횟쾨ㅛ뽁ㄶ揀웃ㆂ롼뻣ㅇㅏㅺㅉㅻ。
			switch($char->guard) {
				case "life25":
				case "life50":
				case "life75":
					$HpRate	= ($char->HP / $char->MAXHP) * 100;
				case "prob25":
				case "prob50":
				case "prob75":
					mt_srand();
					$prob	= mt_rand(1,100);
			}
			// 셋붰ㅛ횟쾨ㅇㅖㅯㅻ。
			switch($char->guard) {
				case "never":
					break;
				case "life25":// HP(%)ㄼ25%걺얍ㅚㅹ
					if(25 < $HpRate) $defender	= &$fore["$key"]; break;
				case "life50":// 》50%》
					if(50 < $HpRate) $defender	= &$fore["$key"]; break;
				case "life75":// 》70%》
					if(75 < $HpRate) $defender	= &$fore["$key"]; break;
				case "prob25":// 25%ㅞ널顆ㅗ
					if($prob < 25) $defender	= &$fore["$key"]; break;
				case "prob50":// 50% 》
					if($prob < 50) $defender	= &$fore["$key"]; break;
				case "prob75":// 75% 》
					if($prob < 75) $defender	= &$fore["$key"]; break;
				default:
					$defender	= &$fore["$key"];
			}
			// 챦ㄻㄼ멨귑ㆂ쇤ㅺㅛ퐁ㅓㅏㅞㅗㅍㅼㆂ섀ㅉㅻ
			if($defender) {
				print('<span class="bold">'.$defender->name.'</span>이(가) <span class="bold">'.$target->name.'</span>을(를) 보호했습니다!<br />'."\n");
				return $defender;
			}
		}
	}
//////////////////////////////////////////////////
//	Ⅹ?λ뽁錮멨ㅛ쫑앴솎(몲渴)ㄼㅇㅬ【ㅇㅏㄻㅙㄶㄻㆂ널ㄻㅱㅻ
	function JudgeTargetsDead($target) {
		$exp	= 0;
		$money	= 0;
		$itemdrop	= array();
		foreach($target as $key => $char) {
			// 沽ㄸㅏ?α【Ⅸㅞ복暇ㅗ론립촐ㆂ쇠팀ㅉㅻβτⅩ?【ㅞ얠밭。
			if(method_exists($target[$key],'HpDifferenceEXP')) {
				$exp	+= $target[$key]->HpDifferenceEXP();
			}
			if($target[$key]->CharJudgeDead()) {//삑ㆃㅐㄻㅙㄶㄻ
				// 삑絳αΓ?【Ⅸ
				print("<span class=\"dmg\">".$target[$key]->Name("bold")." 쓰러졌습니다.</span><br />\n");

				//론립촐ㅞ쇠팀
				$exp	+= $target[$key]->DropExp();

				//ㄺ뜯ㅞ쇠팀
				$money	+= $target[$key]->DropMoney();

				// ⅱⅳΖ?ΙνΓΨ
				if($item = $target[$key]->DropItem()) {
					$itemdrop["$item"]++;
					$item	= LoadItemData($item);
					print($char->Name("bold")."이(가) ");
					print("<img src=\"".IMG_ICON.$item["img"]."\" class=\"vcent\"/>\n");
					print("<span class=\"bold u\">{$item['name']}</span>을(를) 떨어뜨렸습니다.<br />\n");
				}

				//쑈눌?γιㅚㅹ씹ㅉ。
				if($target[$key]->summon === true) {
					unset($target[$key]);
				}

				// 삑ㆃㅐㅞㅗΗⅲμⅳㆂ컁ㅉ。
				$this->ChangeDelay();
			}
		}
		return array($exp,$money,$itemdrop);//쇠팀ㅉㅻ론립촐ㆂ癎ㅉ
	}
//////////////////////////////////////////////////
//	磎잭썹겁ㅛ슭ㅓㅖ몲渴ㄻㅹ곗와癎ㅉ
	function &SelectTarget($target_list,$skill) {

		/*
		* 磎잭ㅟㅉㅻㄼ、툭ㅖㅟㅮㅹㅚㄿㅖㅲ뵉쉠큭ㅛ?【ⅢΓΘㅟ斛ㅻ。
		* 嬌 : 멨귑ㄼ듸ㅚㄴ˚졀귑ㆂ쫑앴ㅛㅉㅻ。
		*    : 졍곳ㄼHP100%˚챦ㄻ ㅖㄽㅘㄶ ㅛ쫑앴ㅛㅉㅻ。
		*/

		//뼛ㅺHP(%)ㄼ쒸ㅚㄴ와ㆂ?【ⅢΓΘㅛㅉㅻ
		if($skill["priority"] == "LowHpRate") {
			$hp = 2;//곗깸1ㅸㅺ쭹ㄽㄴ웃샙ㅛ………
			foreach($target_list as $key => $char) {
				if($char->STATE == DEAD) break;//ㅇㅬ【솎ㅟ쫑앴ㅛㅚㅹㅚㄴ。
				$HpRate	= $char->HP / $char->MAXHP;//HP(%)
				if($HpRate < $hp) {
					$hp	= $HpRate;//맒얾ㅞ뵉ㅲHP(%)ㄼ콱ㄴ와
					$target	= &$target_list[$key];
				}
			}
			return $target;//뵉ㅲHPㄼ콱ㄴ와

		//멨귑ㆂ磎잭ㅉㅻ
		} else if($skill["priority"] == "Back") {
			foreach($target_list as $key => $char) {
				if($char->STATE == DEAD) break;//ㅇㅬ【솎ㅟ쫑앴ㅛㅚㅹㅚㄴ。
				if($char->POSITION != FRONT)//멨귑ㅚㅹ
				$target[]	= &$target_list[$key];//몲渴ㅛㄴㅼㅻ
			}
			if($target)
				return $target[array_rand($target)];//κⅩΘㅞ충ㄻㅹιτ??ㅗ

		/*
		* 磎잭ㅟㅉㅻㄼ、
		* 磎잭ㅉㅻ쫑앴ㄼㄴㅚㅁㅼㅠ뽁錮ㅟ성함ㅉㅻ(믐벗ㅯ)
		*/

		//ㅇㅬ【솎ㅞ충ㄻㅹιτ??ㅗ癎ㅉ。
		} else if($skill["priority"] == "Dead") {
			foreach($target_list as $key => $char) {
				if($char->STATE == DEAD)//ㅇㅬ【ㅚㅹ
				$target[]	= &$target_list[$key];//ㅇㅬ【솎κⅩΘ
			}
			if($target)
				return $target[array_rand($target)];//ㅇㅬ【솎κⅩΘㅞ충ㄻㅹιτ??ㅗ
			else
				return false;//챦ㅲㄴㅚㅁㅺㅳfalse癎ㅉㅇㄻㅚㄴ...(˚Ⅹ?λ뽁錮성함)

		// 쑈눌?γιㆂ磎잭ㅉㅻ。
		} else if($skill["priority"] == "Summon") {
			foreach($target_list as $key => $char) {
				if($char->summon)//쑈눌?γιㅚㅹ
					$target[]	= &$target_list[$key];//쑈눌?γικⅩΘ
			}
			if($target)
				return $target[array_rand($target)];//쑈눌?γιㅞ충ㄻㅹιτ??ㅗ
			else
				return false;//챦ㅲㄴㅚㅁㅺㅳfalse癎ㅉㅇㄻㅚㄴ...(˚Ⅹ?λ뽁錮성함)

		// Αγ【Ⅸ충ㅞ?γι
		} else if($skill["priority"] == "Charge") {
			foreach($target_list as $key => $char) {
				if($char->expect)
					$target[]	= &$target_list[$key];
			}
			if($target)
				return $target[array_rand($target)];
			else
				return false;//챦ㅲㄴㅚㅁㅺㅳfalse癎ㅉㅇㄻㅚㄴ...(˚Ⅹ?λ뽁錮성함)
		//
		}

		//ㅍㅼ걺낡(ιτ??)
		foreach($target_list as $key => $char) {
			if($char->STATE != DEAD)//ㅇㅬ【걺낡ㅚㅹ
				$target[]	= &$target_list[$key];//ㅇㅬ【솎κⅩΘ
		}
		return $target[array_rand($target)];//ιτ??ㅛ챦ㄻ곗와
	}
//////////////////////////////////////////////////
//	샥ㅞ밋튼ㅟ챦ㄻ(蹇、귓쑨충ㅞ渠匣ㄼ환튼ㅉㅻㅞㅟ챦ㄻ)
//	κΦⅰμτⅩㆂ癎ㅉ
	function &NextActer() {
		// 뵉ㅲΗⅲμⅳㄼ쭹ㄽㄴ와ㆂ천ㅉ
		foreach($this->team0 as $key => $char) {
			if($char->STATE === 1) break;
			// 뵉썽ㅟ챦ㅗㅲㄴㄴㅞㅗㅘㅺㄲㄸㅊ뵉썽ㅞ와ㅘㅉㅻ。
			if(!isset($delay)) {
				$delay	= $char->delay;
				$NextChar	= &$this->team0["$key"];
				break;
			}
			// ?γιㄼ베ㅞΗⅲμⅳㅸㅺ쩔ㅁㅼㅠ몫쭤
			if($delay <= $char->delay) {//밋튼
				// ㅲㅇ?γιㅘΗⅲμⅳㄼ튿ㅈㅚㅹ50%ㅗ몫쭤
				if($delay == $char->delay) {
					if(mt_rand(0,1))
						break;
				}
				$delay	= $char->delay;
				$NextChar	= &$this->team0["$key"];
			}
		}
		// ¸ㅘ튿ㅈ。
		foreach($this->team1 as $key => $char) {
			if($char->STATE === 1) break;
			if($delay <= $char->delay) {//밋튼
				if($delay == $char->delay) {
					if(mt_rand(0,1))
						break;
				}
				$delay	= $char->delay;
				$NextChar	= &$this->team1["$key"];
			}
		}
		// 졍곳Ηⅲμⅳ맏쒸
		$dif	= $this->delay - $NextChar->delay;//쟁트댑居Ηⅲμⅳㅘ밋튼솎ㅞΗⅲμⅳㅞ복暇
		if($dif < 0)//ㅲㅇㅲ복暇ㄼ0걺꼈ㅛㅚㅓㅏㅹ∞
			return $NextChar;
		foreach($this->team0 as $key => $char) {
			$this->team0["$key"]->Delay($dif);
		}
		foreach($this->team1 as $key => $char) {
			$this->team1["$key"]->Delay($dif);
		}
		/*// ⅷι【ㄼ싻ㅏㅹㅃㅼㅗ。
		if(!is_object($NextChar)) {
			print("AAA");
			dump($NextChar);
			print("BBB");
		}
		*/

		return $NextChar;
	}
//////////////////////////////////////////////////
//	샥ㅞ밋튼ㅟ챦ㄻ(蹇、귓쑨충ㅞ渠匣ㄼ환튼ㅉㅻㅞㅟ챦ㄻ)
//	κΦⅰμτⅩㆂ癎ㅉ
	function &NextActerNew() {

		// 샥ㅞ밋튼ㅮㅗ뵉ㅲ딧跨ㄼ청ㄴ와ㆂ천ㅉ。
		$nextDis	= 1000;
		foreach($this->team0 as $key => $char) {
			if($char->STATE === DEAD) break;
			$charDis	= $this->team0[$key]->nextDis();
			if($charDis == $nextDis) {
				$NextChar[]	= &$this->team0["$key"];
			} else if($charDis <= $nextDis) {
				$nextDis	= $charDis;
				$NextChar	= array($this->team0["$key"]);
			}
		}

		// ¸ㅘ튿ㅈ。
		foreach($this->team1 as $key => $char) {
			if($char->STATE === DEAD) break;
			$charDis	= $this->team1[$key]->nextDis();
			if($charDis == $nextDis) {
				$NextChar[]	= &$this->team1["$key"];
			} else if($charDis <= $nextDis) {
				$nextDis	= $charDis;
				$NextChar	= array($this->team1["$key"]);
			}
		}

		// 졍곳Ηⅲμⅳ맏쒸 //////////////////////

		//ㅲㅇㅲ복暇ㄼ0걺꼈ㅛㅚㅓㅏㅹ
		if($nextDis < 0) {
			if(is_array($NextChar)) {
				return $NextChar[array_rand($NextChar)];
			} else
				return $NextChar;
		}

		foreach($this->team0 as $key => $char) {
			$this->team0["$key"]->Delay($nextDis);
		}
		foreach($this->team1 as $key => $char) {
			$this->team1["$key"]->Delay($nextDis);
		}
		// ⅷι【ㄼ싻ㅏㅹㅃㅼㅗㅏㅇㄻㅱㅽ。
		/*
		if(!is_object($NextChar)) {
			print("AAA");
			dump($NextChar);
			print("BBB");
		}
		*/

		if(is_array($NextChar))
			return $NextChar[array_rand($NextChar)];
		else
			return $NextChar;
	}
//////////////////////////////////////////////////
//	?γι졍곳ㅞ밋튼Ηⅲμⅳㆂ썽덟꼍(=SPD)
	function DelayResetAll() {
		if(DELAY_TYPE === 0 || DELAY_TYPE === 1)
		{
			foreach($this->team0 as $key => $char) {
				$this->team0["$key"]->DelayReset();
			}
			foreach($this->team1 as $key => $char) {
				$this->team1["$key"]->DelayReset();
			}
		}
	}
//////////////////////////////////////////////////
//	Ηⅲμⅳㆂ롼뻣ㅇㅖ잘쾨ㅉㅻ
//	챦ㄻㅞSPDㄼ揀꼍ㅇㅏ얠밭맥ㅣ컁ㅉ
//	*** 돐ㅞ뽁錮툼ㅗSPDㄼ揀꼍ㅇㅏ붰ㅛ맥ㅣ싻ㅉ ***
	function SetDelay() {
		if(DELAY_TYPE === 0)
		{
			//SPDㅞ뵉쭹촐ㅘ밭롼ㆂ듄ㅱㅻ
			foreach($this->team0 as $key => $char) {
				$TotalSPD	+= $char->SPD;
				if($MaxSPD < $char->SPD)
					$MaxSPD	= $char->SPD;
			}
			//dump($this->team0);
			foreach($this->team1 as $char) {
				$TotalSPD	+= $char->SPD;
				if($MaxSPD < $char->SPD)
					$MaxSPD	= $char->SPD;
			}
			//却뚜SPD
			$AverageSPD	= $TotalSPD/( count($this->team0) + count($this->team1) );
			//댑썅delayㅘㄻ
			$AveDELAY	= $AverageSPD * DELAY;
			$this->delay	= $MaxSPD + $AveDELAY;//ㅍㅞ쟁트ㅞ댑썅Ηⅲμⅳ
			$this->ChangeDelay	= false;//falseㅛㅇㅚㄴㅘ遽뀨DELAYㆂ롼뻣ㅇ컁ㅇㅖㅇㅮㄶ。
		}
			else if(DELAY_TYPE === 1)
		{
		}
	}
//////////////////////////////////////////////////
//	쟁트ㅞ댑썅Ηⅲμⅳㆂ뵈롼뻣ㅅㅋㅻㅸㄶㅛㅉㅻ。
//	뽁ㄶ얠쎄ㅟ、돐ㅞ뽁錮ㅗ?γιㅞSPDㄼ揀꼍ㅇㅏ붰ㅛ뽁ㄶ。
//	class.skill_effect.php ㅗ뽁錮。
	function ChangeDelay(){
		if(DELAY_TYPE === 0)
		{
			$this->ChangeDelay	= true;
		}
	}
//////////////////////////////////////////////////
//	Α【?ㅞ潔졀ㆂ잘쾨
	function SetTeamName($name1,$name2) {
		$this->team0_name	= $name1;
		$this->team1_name	= $name2;
	}
//////////////////////////////////////////////////
//	쟁트낙뾰ㅇㅏ샤ㅞ却뚜μ?λㅴ밭롼HP툼ㆂ롼뻣…섀
//	쟁트ㅞ론겪ㅟ곗ㅔㅞㅗ뭣윙ㅅㅼㅻㄶㅓㄶ
	function BattleHeader() {
		foreach($this->team0 as $char) {//Α【?0
			$team0_total_lv	+= $char->level;//밭롼LV
			$team0_total_hp	+= $char->HP;//밭롼HP
			$team0_total_maxhp	+= $char->MAXHP;//밭롼뵉쭹HP
		}
		$team0_avelv	= round($team0_total_lv/count($this->team0)*10)/10;//Α【?0却뚜LV
		$this->team0_ave_lv	= $team0_avelv;
		foreach($this->team1 as $char) {//Α【?1
			$team1_total_lv	+= $char->level;
			$team1_total_hp	+= $char->HP;
			$team1_total_maxhp	+= $char->MAXHP;
		}
		$team1_avelv	= round($team1_total_lv/count($this->team1)*10)/10;
		$this->team1_ave_lv	= $team1_avelv;
		if($this->UnionBattle) {
			$team1_total_hp		= '????';
			$team1_total_maxhp	= '????';
		}
		?>
<table style="width:100%;" cellspacing="0"><tbody>
<tr><td class="teams"><div class="bold"><?=$this->team1_name?></div>
총 레벨 : <?=$team1_total_lv?><br>
평균 레벨 : <?=$team1_avelv?><br>
총 체력 : <?=$team1_total_hp?>/<?=$team1_total_maxhp?>
</td><td class="teams ttd1"><div class="bold"><?=$this->team0_name?></div>
총 레벨 : <?=$team0_total_lv?><br>
평균 레벨 : <?=$team0_avelv?><br>
총 체력 : <?=$team0_total_hp?>/<?=$team0_total_maxhp?>
</td></tr><?php 
	}
//////////////////////////////////////////////////
//	쟁트쉠貫샤ㅛ섀
	function BattleFoot() {
	/*	print("<tr><td>");
		dump($this->team0);
		print("</td></tr>");*/
		?>
</tbody></table>
<?php 
		$return_url = INDEX;
		$return_label = "처음으로";
		$sub_links = array('<a href="'.INDEX.'">처음으로</a>');
		if(isset($_GET["common"])) {
			$return_url = INDEX."?hunt";
			$return_label = "전투 목록으로 돌아가기";
			$sub_links = array(
				'<a href="'.INDEX.'?common='.rawurlencode($_GET["common"]).'">같은 전투 다시 선택</a>',
				'<a href="'.INDEX.'">처음으로</a>'
			);
		} else if(isset($_GET["union"])) {
			$return_url = INDEX."?hunt";
			$return_label = "전투 목록으로 돌아가기";
			$sub_links = array('<a href="'.INDEX.'">처음으로</a>');
		} else if(isset($_GET["menu"]) && $_GET["menu"] === "rank") {
			$return_url = INDEX."?menu=rank";
			$return_label = "콜로세움으로 돌아가기";
			$sub_links = array('<a href="'.INDEX.'">처음으로</a>');
		} else if($_SERVER["QUERY_STRING"] === "simulate") {
			$return_url = INDEX."?simulate";
			$return_label = "모의 전투로 돌아가기";
			$sub_links = array('<a href="'.INDEX.'?hunt">전투 목록</a>', '<a href="'.INDEX.'">처음으로</a>');
		}
		print('<div class="margin15 align-center battle-return" style="padding:15px 0 25px 0">'."\n");
		print('<h4>전투 종료</h4>'."\n");
		print('<a href="'.$return_url.'" class="btn" style="display:inline-block;padding:4px 12px;margin:4px">'.$return_label.'</a><br />'."\n");
		print(implode(' - ', $sub_links)."\n");
		print('</div>'."\n");
	}
//////////////////////////////////////////////////
//	쟁트꿱짐…냔?γιㅞ뼛ㅺHP뼛ㅺSP툼ㆂ섀
	function BattleState() {
		static $last;
		if($last !== $this->actions)
			$last	= $this->actions;
		else
			return false;

		print("<tr><td colspan=\"2\" class=\"btl_img\">\n");
		// 쟁트ⅩΖΓΨ썹ㅛ섐튼Ⅹ?ν【λ
		print("<a name=\"s".$this->Scroll."\"></a>\n");
		print("<div style=\"width:100%;hight:100%;position:relative;\">\n");
		print('<div style="position:absolute;bottom:0px;right:0px;">'."\n");
		if($this->Scroll)
			print("<a href=\"#s".($this->Scroll - 1)."\">&lt;&lt;</a>\n");
		else
			print("&lt;&lt;" );
		print("<a href=\"#s".(++$this->Scroll)."\">&gt;&gt;</a>\n");
		print('</div>');

		switch(BTL_IMG_TYPE) {
			case 0:
				print('<div style="text-align:center">');
				$this->ShowGdImage();//꿱짐
				print('</div>');
				break;
			case 1:
			case 2:
				$this->ShowCssImage();//꿱짐
				break;
		}
		print("</div>");
		print("</td></tr><tr><td class=\"ttd2 break\">\n");

		print("<table style=\"width:100%\"><tbody><tr><td style=\"width:50%\">\n");// team1-backs

		// 	보짝Α【?멨귑
		foreach($this->team1 as $char) {
			// 쑈눌?γιㄼ삑絳ㅇㅖㄴㅻ얠밭ㅟ흼ㅠㅉ
			if($char->STATE === DEAD && $char->summon == true)
				break;

			if($char->POSITION != FRONT)
				$char->ShowHpSp();
		}

		// 	보짝Α【?졀귑
		print("</td><td style=\"width:50%\">\n");
		foreach($this->team1 as $char) {
			// 쑈눌?γιㄼ삑絳ㅇㅖㄴㅻ얠밭ㅟ흼ㅠㅉ
			if($char->STATE === DEAD && $char->summon == true)
				break;

			if($char->POSITION == FRONT)
				$char->ShowHpSp();
		}

		print("</td></tr></tbody></table>\n");

		print("</td><td class=\"ttd1 break\">\n");

		// 	괜짝Α【?졀귑
		print("<table style=\"width:100%\"><tbody><tr><td style=\"width:50%\">\n");
		foreach($this->team0 as $char) {
			// 쑈눌?γιㄼ삑絳ㅇㅖㄴㅻ얠밭ㅟ흼ㅠㅉ
			if($char->STATE === DEAD && $char->summon == true)
				break;
			if($char->POSITION == FRONT)
				$char->ShowHpSp();
		}

		// 	괜짝Α【?멨귑
		print("</td><td style=\"width:50%\">\n");
		foreach($this->team0 as $char) {
			// 쑈눌?γιㄼ삑絳ㅇㅖㄴㅻ얠밭ㅟ흼ㅠㅉ
			if($char->STATE === DEAD && $char->summon == true)
				break;
			if($char->POSITION != FRONT)
				$char->ShowHpSp();
		}
		print("</td></tr></tbody></table>\n");

		print("</td></tr>\n");
	}
//////////////////////////////////////////////////
//	쟁트꿱짐(꿱짐ㅞㅯ)
	function ShowGdImage() {
		$url	= BTL_IMG."?";

		// HP=0 ㅞ?γιㅞ꿱짐(냠칠뿍ㄼㄲㅼㅠㅍㅼㆂ쇠ㅻ)
		$DeadImg	= substr(DEAD_IMG,0,strpos(DEAD_IMG,"."));

		//Α【?1
		$f	= 1;
		$b	= 1;//졀귑ㅞ웃…멨귑ㅞ웃ㆂ썽덟꼍
		foreach($this->team0 as $char) {
			//꿱짐ㅟ?γιㅛ잘쾨ㅅㅼㅖㄴㅻ꿱짐ㅞ냠칠뿍ㅮㅗㅞ潔졀
			if($char->STATE === 1)
				$img	= $DeadImg;
			else
				$img	= substr($char->img,0,strpos($char->img,"."));
			if($char->POSITION == "front")://졀귑
				$url	.= "f2{$f}=$img&";
				$f++;
			else:
				$url	.= "b2{$b}=$img&";//멨귑
				$b++;
			endif;
		}
		//Α【?0
		$f	= 1;
		$b	= 1;
		foreach($this->team1 as $char) {
			if($char->STATE === 1)
				$img	= $DeadImg;
			else
				$img	= substr($char->img,0,strpos($char->img,"."));
			if($char->POSITION == "front"):
				$url	.= "f1{$f}=$img&";
				$f++;
			else:
				$url	.= "b1{$b}=$img&";
				$b++;
			endif;
		}
		print('<img src="'.$url.'">');// ˙ㅃㅼㄼ섀ㅅㅼㅻㅞㅯ
	}
//////////////////////////////////////////////////
//	CSS쟁트꿱儆
	function ShowCssImage() {
		include_once(BTL_IMG_CSS);
		$img	= new cssimage();
		$img->SetBackGround($this->BackGround);
		$img->SetTeams($this->team1,$this->team0);
		$img->SetMagicCircle($this->team1_mc, $this->team0_mc);
		if(BTL_IMG_TYPE == 2)
			$img->NoFlip();// CSS꿱짐효탑絹ㅇ
		$img->Show();
	}
//////////////////////////////////////////////////
//	ㄺ뜯ㆂ팀ㅻ、곗샤큭ㅛ揀웃ㅛ艮쨍ㅉㅻㅐㅁ。
//	class펐ㅛα?ΓΙ븜ㅼ【
	function GetMoney($money,$team) {
		if(!$money) return false;
		$money	= ceil($money * MONEY_RATE);
		if($team === $this->team0) {
			print("{$this->team0_name} Get ".MoneyFormat($money).".<br />\n");
			$this->team0_money	+= $money;
		} else if($team === $this->team1) {
			print("{$this->team1_name} Get ".MoneyFormat($money).".<br />\n");
			$this->team1_money	+= $money;
		}
	}
//////////////////////////////////////////////////
//	ζ【Ⅶ【Η【?ㅛ팀ㅻ밭롼뜯넴ㆂ턴ㅉ
	function ReturnMoney() {
		return array($this->team0_money,$this->team1_money);
	}

//////////////////////////////////////////////////
//	졍쫍ㅞ삑솎웃ㆂ웃ㄸㅻ...(Ν?ν?τⅥㅇㄻ뽁ㅓㅖㅚㄴ?)
	function CountDeadAll() {
		$dead	= 0;
		foreach($this->team0 as $char) {
			if($char->STATE === DEAD)
				$dead++;
		}
		foreach($this->team1 as $char) {
			if($char->STATE === DEAD)
				$dead++;
		}
		return $dead;
	}

//////////////////////////////////////////////////
//	쀼쾨?γιㅞΑ【?ㅞ삑솎웃ㆂ웃ㄸㅻ(쀼쾨ㅞΑ【?)Ν?ν?τⅥㅇㄻ뽁ㅓㅖㅚㄴ?
	function CountDead($VarChar) {
		$dead	= 0;

		if($VarChar->team == TEAM_0) {
		//	print("A".$VarChar->team."<br>");
			$Team	= $this->team0;
		} else {
			//print("B".$VarChar->team);
			$Team	= $this->team1;
		}

		foreach($Team as $char) {
			if($char->STATE === DEAD) {
				$dead++;
			} else if($char->SPECIAL["Undead"] == true) {
				//print("C".$VarChar->Name()."/".count($Team)."<br>");
				$dead++;
			}
		}
		return $dead;
	}
//////////////////////////////////////////////////
//	渠鑒왠ㆂ케꼴ㅉㅻ
	function MagicCircleAdd($team,$amount) {
		if($team == TEAM_0) {
			$this->team0_mc	+= $amount;
			if(5 < $this->team0_mc)
				$this->team0_mc	= 5;
			return true;
		} else {
			$this->team1_mc	+= $amount;
			if(5 < $this->team1_mc)
				$this->team1_mc	= 5;
			return true;
		}
	}
//////////////////////////////////////////////////
//	渠鑒왠ㆂ븝쐤ㅉㅻ
	function MagicCircleDelete($team,$amount) {
		if($team == TEAM_0) {
			if($this->team0_mc < $amount)
				return false;
			$this->team0_mc	-= $amount;
			return true;
		} else {
			if($this->team1_mc < $amount)
				return false;
			$this->team1_mc	-= $amount;
			return true;
		}
	}
// end of class. /////////////////////////////////////////////////////
}

//////////////////////////////////////////////////
//	으쨍솎웃ㆂ웃ㄸㅖ癎ㅉ
function CountAlive($team) {
	$no	= 0;//썽덟꼍
	foreach($team as $char) {
		if($char->STATE !== 1)
			$no++;
	}
	return $no;
}

//////////////////////////////////////////////////
//	썽덟?γι으쨍웃ㆂ웃ㄸㅖ癎ㅉ
function CountAliveChars($team) {
	$no	= 0;//썽덟꼍
	foreach($team as $char) {
		if($char->STATE === 1)
			break;
		if($char->monster)
			break;
		$no++;
	}
	return $no;
}
//////////////////////////////////////////////////
//	쑈님록Ⅹ?λㅗ맥ㅠㅼㅏβτⅩ?【。
	function CreateSummon($no,$strength=false) {
		include_once(DATA_MONSTER);
		$monster	= CreateMonster($no,1);

		$monster["summon"]	= true;
		// 쑈눌βτⅩ?【ㅞ땡꼍。
		if($strength) {
			$monster["maxhp"]	= round($monster["maxhp"]*$strength);
			$monster["hp"]	= round($monster["hp"]*$strength);
			$monster["maxsp"]	= round($monster["maxsp"]*$strength);
			$monster["sp"]	= round($monster["sp"]*$strength);
			$monster["str"]	= round($monster["str"]*$strength);
			$monster["int"]	= round($monster["int"]*$strength);
			$monster["dex"]	= round($monster["dex"]*$strength);
			$monster["spd"]	= round($monster["spd"]*$strength);
			$monster["luk"]	= round($monster["luk"]*$strength);

			$monster["atk"]["0"]	= round($monster["atk"]["0"]*$strength);
			$monster["atk"]["1"]	= round($monster["atk"]["1"]*$strength);
		}

		$monster	= new monster($monster);
		$monster->SetBattleVariable();
		return $monster;
	}
//////////////////////////////////////////////////
//	假웃ㅞ횟쳬斛좡ㅗㅞ횟쾨
//function MultiFactJudge($Keys,$char,$MyTeam,$EnemyTeam) {
function MultiFactJudge($Keys,$char,$classBattle) {
	foreach($Keys as $no) {

		//$return	= DecideJudge($no,$char,$MyTeam,$EnemyTeam);
		$return	= DecideJudge($no,$char,$classBattle);

		// 횟쾨ㄼ휭ㅗㄲㅓㅏ얠밭쉠貫。
		if(!$return)
			return false;

		// 핼轎ㆂ흑넛ㅇㅖ땋켈밝涇ㆂ뼛ㅉ(ㅫㅬ한삐ㅞ鑒뫼ㅨ)
		/*
		if(!$compare && is_array($return))
			$compare	= $return;
		else if(is_array($return))
			$compare	= array_intersect($intersect,$return);
		*/

	}

	/*
	if($compare == array())
		$compare	= true;
	return $compare;
	*/
	return true;
}
?>
