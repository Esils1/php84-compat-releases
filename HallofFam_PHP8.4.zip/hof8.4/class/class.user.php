<?php 
class user {

	// Φⅰⅳλ?ⅳτ?
	var $fp;
	var $file;

	var $id, $pass;
	var $name, $last, $login ,$start;
	var $money;
	var $char;
	var $time;
	var $wtime;//쥼씹희샤닛
	var $ip;//IPⅱΙμⅩ

	var $party_memo;
	var $party_rank;//ιτ?τⅠ錮ㅞΡ【Ζⅲ
	var $rank_set_time;//ιτ?τⅠPT잘쾨ㅇㅏ샤닛
	var $rank_btl_time;//샥ㅞιτ?쟁ㅛ칫쟁ㅗㄽㅻ샤닛
	// ιτ?τⅠㅞ윙임
	// = "쥼쟁트뀨웃<>쐴貢웃<>함盖웃<>과ㄽ暇ㅁ<>숍겁漑귑";
	var $rank_record;
	var $union_btl_time;//샥ㅞUnion쟁ㅛ칫쟁ㅗㄽㅻ샤닛

	// OPTION
	var $record_btl_log;
	var $no_JS_itemlist;
	var $UserColor;

	// ζ【Ⅶ【ⅱⅳΖ?錮ㅞ揀웃
	var $fp_item;
	var $item;

//////////////////////////////////////////////////
//	쫑앴ㅞIDㅞζ【Ⅶ【?ιⅩㆂ븜윙
	function __construct($id=false,$noExit=false) {
		$this->user($id,$noExit);
	}

	function user($id,$noExit=false) {
		if($id)
		{
			$this->id	= $id;
			if($data = $this->LoadData($noExit)) {
				$this->DataUpDate($data);//timeㅘㄻ집ㅴㅉ
				$this->SetData($data);
			}
		}
	}
//////////////////////////////////////////////////
//	IPㆂ揀뭐
	function SetIp($ip) {
		$this->ip = $ip;
	}
//////////////////////////////////////////////////
//	ζ【ⅦΗ【?ㆂ팖ㅰ
	function LoadData($noExit=false) {
		$file	= USER.$this->id."/".DATA;
		if(file_exists($file))
		{
			$this->file	= $file;
			$this->fp	= FileLock($file,$noExit);
			if(!$this->fp)
				return false;
			$data	= ParseFileFP($this->fp);
			//$data	= ParseFile($file);// (2007/7/30 케꼴)
			/*
			$Array	= array("party_memo","party_rank");
			foreach($Array as $val)
			{
				if(!$data["$val"]) break;
				$data["$val"]	= explode("<>",$data["$val"]);
			}
			*/
			return $data;
		}
			else
		{
			return false;
		}
	}

//////////////////////////////////////////////////
//	IDㄼ룸똔ㅞㅘㅃㅽ쨍뷔ㅇㅖㄴㅻㄻㅏㅇㄻㅱㅻ
	function is_exist() {
		if($this->name)
			return true;
		else
			return false;
	}
//////////////////////////////////////////////////
//	潔졀ㆂ癎ㅉ
	function Name($opt=false) {
		if($this->name) {
			if($opt)
				return '<span class="'.$opt.'">'.$this->name.'</span>';
			else
				return $this->name;
		} else {
			return false;
		}
	}
//////////////////////////////////////////////////
//	潔졀ㆂ揀ㄸㅻ
	function ChangeName($name) {

		if($this->name == $name)
			return false;

		$this->name	= $name;
		return true;
	}
//////////////////////////////////////////////////
//	Union쟁트ㅇㅏ샤닛ㆂ?ΓΘ
	function UnionSetTime() {
		$this->union_btl_time	= time();
	}
//////////////////////////////////////////////////
//	UnionBattleㄼㅗㄽㅻㄻㅙㄶㄻ널푤ㅉㅻ。
	function CanUnionBattle() {
		$Now	= time();
		$Past	= $this->union_btl_time	+ UNION_BATTLE_NEXT;
		if($Past <= $Now) {
			return true;
		} else {
			return abs($Now - $Past);
		}
	}
//////////////////////////////////////////////////
//	ιτ?τⅠ쟁錮ㅞΡ【Ζⅲ桿윙ㆂ癎ㅉ
	function RankParty() {
		if(!$this->name)
			return "NOID";//캘ⅷι【。ㅍㅲㅍㅲζ【Ⅶ【ㄼ쨍뷔ㅇㅚㄴ얠밭。
		if(!$this->party_rank)
			return false;

		$PartyRank	= explode("<>",$this->party_rank);
		foreach($PartyRank as $no) {
			$char	= $this->CharDataLoad($no);
			if($char)
				$party[]	= $char;
			//if($this->char[$no])
			//	$party[]	= $this->char[$no];
		}

		if($party)
			return $party;
		else
			return false;
	}
//////////////////////////////////////////////////
//	ιτ?τⅠㅞ윙임
// side = ("CHALLENGE","DEFEND")
	function RankRecord($result,$side,$DefendMatch) {
		$record	= $this->RankRecordLoad();

		$record["all"]++;
		switch(true) {
			// 과ㄽ暇ㅁ
			/*
			case ($result === "d"):
				if($side != "CHALLENGE" && $DefendMatch)
					$record["defend"]++;
				break;
			*/
			// 쟁트룸꽐ㄼ칫쟁솎ㅞ쐴ㅑ
			case ($result === 0):
				if($side == "CHALLENGER") {
					$record["win"]++;
				} else {
					$record["lose"]++;
				}
				break;
			// 쟁트룸꽐ㄼ칫쟁솎ㅞㅁ
			case ($result === 1):
				if($side == "CHALLENGER") {
					$record["lose"]++;
				} else {
					$record["win"]++;
					if($DefendMatch)
						$record["defend"]++;
				}
				break;
			default:// 과ㄽ暇ㅁ
				if($side != "CHALLENGER" && $DefendMatch)
					$record["defend"]++;
				break;
		}

		$this->rank_record	= $record["all"]."|".$record["win"]."|".$record["lose"]."|".$record["defend"];
	}
//////////////////////////////////////////////////
//	ιτ?τⅠ쟁ㅞ윙임ㆂ맥ㅣ싻ㅉ
	function RankRecordLoad() {

		if(!$this->rank_record) {
			$record	= array(
						"all" => 0,
						"win" => 0,
						"lose" => 0,
						"defend" => 0,
						);
			return $record;
		}

		list(
			$record["all"],
			$record["win"],
			$record["lose"],
			$record["defend"],
		)	= explode("|",$this->rank_record);
		return $record;
	}
//////////////////////////////////////////////////
//	샥ㅞιτ?쟁ㅛ칫쟁ㅗㄽㅻ샤닛ㆂ뎅臼ㅉㅻ。
	function SetRankBattleTime($time) {
		$this->rank_btl_time	= $time;
	}

//////////////////////////////////////////////////
//	ιτ?τⅠ칫쟁ㅗㄽㅻㄻ­(絹果ㅚㅹ뼛ㅺ샤닛ㆂ癎ㅉ)
	function CanRankBattle() {
		$now	= time();
		if($this->rank_btl_time <= $now) {
			return true;
		} else if(!$this->rank_btl_time) {
			return true;
		} else {
			$left	= $this->rank_btl_time - $now;
			$hour		= floor($left/3600);
			$minutes	= floor(($left%3600)/60);
			$seconds	= floor(($left%3600)%60);
			return array($hour,$minutes,$seconds);
		}
	}

//////////////////////////////////////////////////
//	ㄺ뜯ㆂ집ㅴㅉ
	function GetMoney($no) {
		$this->money	+= $no;
	}

//////////////////////////////////////////////////
//	ㄺ뜯ㆂ맏ㅹㅉ
	function TakeMoney($no) {
		if($this->money < $no) {
			return false;
		} else {
			$this->money	-= $no;
			return true;
		}
	}

//////////////////////////////////////////////////
//	샤닛ㆂ씹희ㅉㅻ(쥼씹희샤닛ㅞ꼴뻣)
	function WasteTime($time) {
		if($this->time < $time)
			return false;
		$this->time		-= $time;
		$this->wtime 	+= $time;
		return true;
	}
//////////////////////////////////////////////////
//	?γι??【ㆂ쎄생ㅇㅖㅻ웃ㆂㄻㅎㄸㅻ。
	function CharCount() {
		$dir	= USER.$this->id;
		$no		= 0;
		foreach(glob("$dir/*") as $adr) {
			$number	= basename($adr,".dat");
			if(is_numeric($number)) {//?γιΗ【?Φⅰⅳλ
				$no++;
			}
		}
		return $no;
	}
//////////////////////////////////////////////////
//	졍쎄생?γι??【ㆂΦⅰⅳλㄻㅹ팖ㆃㅗ $this->char ㅛ너퓬
	function CharDataLoadAll() {
		$dir	= USER.$this->id;
		$this->char	= array();//핼轎ㅞ썽덟꼍ㅐㅁㅇㅖㄺㄿ
		foreach(glob("$dir/*") as $adr) {
			//print("substr:".substr($adr,-20,16)."<br>");//널푤錮
			//$number	= substr($adr,-20,16);//˛1밋ㅘ튿ㅈ룸꽐
			$number	= basename($adr,".dat");
			if(is_numeric($number)) {//?γιΗ【?Φⅰⅳλ
				//$chardata	= ParseFile($adr);// (2007/7/30 $adr -> $fp)
				//$this->char[$number]	= new char($chardata);
				$this->char[$number]	= new char($adr);
				$this->char[$number]->SetUser($this->id);//?γιㄼ챦ㅞㄻ잘쾨ㅉㅻ
			}
		}
	}
//////////////////////////////////////////////////
//	쀼쾨ㅞ쎄생?γι??【ㆂΦⅰⅳλㄻㅹ팖ㆃㅗ $this->char ㅛ너퓬멨 "癎ㅉ"。
	function CharDataLoad($CharNo) {
		// 덞ㅛ팖ㆃㅗㅻ얠밭。
		if($this->char[$CharNo])
			return $this->char[$CharNo];
		// 팖ㆃㅗ絹ㄴ얠밭。
		$file	= USER.$this->id."/".$CharNo.".dat";
		// ㅍㆃㅚ?γιㄴㅚㄴ얠밭。
		if(!file_exists($file))
			return false;

		// 듸ㅻ얠밭。
		//$chardata	= ParseFile($file);
		//$this->char[$CharNo]	= new char($chardata);
		$this->char[$CharNo]	= new char($file);
		$this->char[$CharNo]->SetUser($this->id);//?γιㄼ챦ㅞㄻ잘쾨ㅉㅻ
		return $this->char[$CharNo];
	}
//////////////////////////////////////////////////
//	ⅱⅳΖ?ㆂ케꼴
	function AddItem($no,$amount=false) {
		if(!isset($this->item))//ㅙㄶㅇㅏㅲㆃㄻ∞
			$this->LoadUserItem();
		if(!isset($this->item[$no]))
			$this->item[$no]	= 0;
		if($amount)
			$this->item[$no]	+= $amount;
		else
			$this->item[$no]++;
	}

//////////////////////////////////////////////////
//	ⅱⅳΖ?ㆂ븝쐤
	function DeleteItem($no,$amount=false) {
		if(!isset($this->item))//ㅙㄶㅇㅏㅲㆃㄻ∞
			$this->LoadUserItem();

		// 맏ㅹㅉ웃。
		if($this->item[$no] < $amount) {
			$amount	= $this->item[$no];
			if(!$amount)
				$amount = 0;
		}
		if(!is_numeric($amount))
			$amount	= 1;

		// 맏ㅹㅉ。
		$this->item[$no]	-= $amount;
		if($this->item[$no] < 1)
			unset($this->item[$no]);

		return $amount;
	}

//////////////////////////////////////////////////
//	ⅱⅳΖ?Η【?ㆂ팖ㅰ
	function LoadUserItem() {

		// 2신ㅛ팖ㅰㅞㆂ漑삐。
		if(isset($this->item))
			return false;

		$file	= USER.$this->id."/".ITEM;

		if(file_exists($file)) {
			$this->fp_item	= FileLock($file);
			$this->item	= ParseFileFP($this->fp_item);
			if($this->item === false)
				$this->item	= array();
		} else {
			$this->item	= array();
		}
	}

//////////////////////////////////////////////////
//	ⅱⅳΖ?Η【?ㆂ艮쨍ㅉㅻ
	function SaveUserItem() {
		$dir	= USER.$this->id;
		if(!file_exists($dir))
			return false;

		$file	= USER.$this->id."/".ITEM;

		if(!is_array($this->item))
			return false;

		// ⅱⅳΖ?ㅞ?【Θ
		ksort($this->item,SORT_STRING);

		foreach($this->item as $key => $val) {
			$text	.= "$key=$val\n";
		}

		if(file_exists($file) && $this->fp_item) {
			WriteFileFP($this->fp_item,$text,1);//$textㄼ란ㅗㅲ艮쨍ㅉㅻ
			fclose($this->fp_item);
			unset($this->fp_item);
		} else {
			// $textㄼ란ㅗㅲ艮쨍ㅉㅻ
			WriteFile($file,$text,1);
		}
	}

//////////////////////////////////////////////////
//	샤닛ㆂ론꿍ㅅㅋㅻ。(Timeㅞ집꼴)
	function DataUpDate($data) {
		$now	= time();
		$diff	= $now - $data["last"];
		$data["last"]	= $now;
		$gain	= $diff / (24*60*60) * TIME_GAIN_DAY;
		$data["time"]	+= $gain;
		if(MAX_TIME < $data["time"])
			$data["time"]	= MAX_TIME;
	}

//////////////////////////////////////////////////
//	Η【?ㆂ?ΓΘㅉㅻ。
//	˘?
	function SetData($data) {

		foreach($data as $key => $val) {
			$this->{$key}	= $val;
		}
		/*
		$this->name	= $data["name"];
		$this->login	= $data["login"];
		$this->last	= $data["last"];
		$this->start	= $data["start"];
		*/
	}

//////////////////////////////////////////////////
//	ΡⅩο【Ιㆂ거방꼍ㅉㅻ
	function CryptPassword($pass) {
		return substr(crypt($pass,CRYPT_KEY),strlen(CRYPT_KEY));
	}

//////////////////////////////////////////////////
//	潔졀ㆂ씹ㅉ
	function DeleteName() {
		$this->name	= NULL;
	}

//////////////////////////////////////////////////
//	Η【?ㆂ艮쨍ㅉㅻ려섟ㅛ揀뉩ㅉㅻ。(Ζ?ⅩΘ)
	function DataSavingFormat() {

		$Save	= array(
			"id",
			"pass",
			"ip",
			"name",
			"last",
			"login",
			"start",
			"money",
			"time",
			"wtime",
			"party_memo",
			"party_rank",
			"rank_set_time",
			"rank_btl_time",
			"rank_record",
			"union_btl_time",
			// opt
			"record_btl_log",
			"no_JS_itemlist",
			"UserColor",
			);
		foreach($Save as $val) {
			if($this->{$val})
				$text	.= "$val=".(is_array($this->{$val}) ? implode("<>",$this->{$val}) : $this->{$val})."\n";
		}
		

		/*
		$Save	= get_object_vars($this);
		unset($Save["char"]);
		unset($Save["item"]);
		unset($Save["islogin"]);
		foreach($Save as $key => $val) {
			$text	.= "$key=".(is_array($val) ? implode("<>",$val) : $val)."\n";
		}
		*/

		//print("<pre>".print_r($AAA,1)."</pre>");

		return $text;
	}

//////////////////////////////////////////////////
//	Η【?ㆂ艮쨍ㅉㅻ
	function SaveData() {
		$dir	= USER.$this->id;
		$file	= USER.$this->id."/".DATA;

		if(file_exists($this->file) && $this->fp) {
			//print("BBB");
			//ftruncate($this->fp,0);
			//rewind($this->fp);
			//$fp	= fopen($file,"w+");
			//flock($fp,LOCK_EX);
			//fputs($this->fp,$this->DataSavingFormat());
			WriteFileFP($this->fp,$this->DataSavingFormat());
			fclose($this->fp);
			unset($this->fp);
			//WriteFile("./user/1234/data2.dat",$this->DataSavingFormat());
			//WriteFile($file,$this->DataSavingFormat());
			//WriteFileFP($this->fp,$this->DataSavingFormat());
			//fclose($this->fp);
		} else {
			if(file_exists($file))
				WriteFile($file,$this->DataSavingFormat());
		}
	}
/////////////////////////////////////////////////
//	Η【?Φⅰⅳλ뤽?γιΦⅰⅳλㅞΦⅰⅳλ?ⅳτ?ㅲ졍珏ㅈㅻ
	function fpCloseAll() {
		// 댑居Η【?
		if(is_resource($this->fp))
		{
			fclose($this->fp);
			unset($this->fp);
		}

		// ⅱⅳΖ?Η【?
		if(is_resource($this->fp_item))
		{
			fclose($this->fp_item);
			unset($this->fp_item);
		}

		// ?γιΗ【?
		if($this->char)
		{
			foreach($this->char as $key => $var)
			{
				if(method_exists($this->char[$key],"fpclose"))
					$this->char[$key]->fpclose();
			}
		}

	}
//////////////////////////////////////////////////
//	ζ【Ⅶ【ㅞ븝쐤(졍Φⅰⅳλ)
	function DeleteUser($DeleteFromRank=true) {
		//ιτ?τⅠㄻㅹㅮㅊ씹ㅉ。
		if($DeleteFromRank) {
			include_once(CLASS_RANKING);
			$Ranking	= new Ranking();
			if( $Ranking->DeleteRank($this->id) )
				$Ranking->SaveRanking();
		}

		$dir	= USER.$this->id;
		$files	= glob("$dir/*");
		$this->fpCloseAll();
		foreach($files as $val)
			unlink($val);
		rmdir($dir);
	}
//////////////////////////////////////////////////
//	鑑덥ㅅㅼㅖㄴㅻㄻㅙㄶㄻ널ㄻㅱㅻ
	function IsAbandoned() {
		$now	= time();
		// $this->login ㄼㄺㄻㅇㅁㅼㅠ쉠貫ㅉㅻ。
		if(strlen($this->login) !== 10) {
			return false;
		}
		if( ($this->login + ABANDONED) < $now) {
			return true;
		} else {
			return false;
		}
	}
//////////////////////////////////////////////////
//	?γιΗ【?ㆂ씹ㅉ
	function DeleteChar($no) {
		$file	= USER.$this->id."/".$no.".dat";
		if($this->char[$no]) {
			$this->char[$no]->fpclose();
		}
		if(file_exists($file))
			unlink($file);
	}

//////////////////////////////////////////////////
//	
	//function Load

}
?>
