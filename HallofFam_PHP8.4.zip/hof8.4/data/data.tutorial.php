<div style="margin:15px">
<h4>튜토리얼</h4>
<p>전투의 기본적인 전략</p>
<img src="./image/manual/t001.gif" alt="이미지" />
<p>기본은 <span class="bold">전사</span>와 같은 탱커 캐릭터를 <span class="bold">전방</span>에<br />
<span class="bold">마법사</span>와 같은 피가 적은 보조형 캐릭터를 <span class="bold">후방</span>에</p>
<p>전방을 후방을 지키고, 공격력이 높은 후방이 적을 공격한다.<br />
다친 전방 캐릭터를 후방이 치료해 준다. 그런식의 형태입니다.</p>
<h4>일단은 한번 해보자!</h4>
<p>전사, 마법사와 사제가 갖추어지도록 합니다<br />
메뉴의 <span class="bold">마을 → </span><a href="?recruit">인재알선소</a>에서 고용해봅시다
<span class="light">(링크는 로그인하셨을때만 유효합니다.)</span><br />
고용한 후, 그럭저럭 싸울 수 있도록 설정해 둡니다.</p>
<img src="<?=IMG_CHAR_REV?>mon_079.gif" alt="守る人" />
<img src="<?=IMG_CHAR_REV?>mon_018.gif" alt="痛い攻?する人" />
<img src="<?=IMG_CHAR_REV?>mon_214.gif" alt="治す人" />
<p>그럼、후딱 전투를 해봅시다.<br />
메뉴의 전투 → <a href="?common=gb0">고블린과 놀기</a><span class="light">(링크는 로그인하셨을때만 유효합니다.)</span><br />
고용한 캐릭터들의 체크박스에 체크를 하고,<br />
전투!</p>
<p>제대로 전투가 된다면<br />전투 결과가 표시될 것 이라고 생각합니다.</p>
<h4>메뉴의 구성</h4>
<img src="./image/manual/003.gif">
<h4>음..음...</h4>
<div class="bold u">고용할 수 있는 초기 캐릭터</div>
<p><ul>
<li>전사 - 체력과 방어력이 많은 탱커입니다.</li>
<li>마법사 - 공격력은 강하지만, 물리공격에 약합니다.</li>
<li>사제 - 회복계입니다.</li>
<li>사냥꾼 - 상대의 전방을 무시하고 후방을 직접 공격할 수 있습니다.</li>
</ul></p>
<h4>음..음...2</h4>
한글화(2008/07/23)
편집일(2008/01/28)
</div>
