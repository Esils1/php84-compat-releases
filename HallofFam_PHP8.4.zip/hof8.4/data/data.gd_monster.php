<?php
/*
	どっかおかしくて?像表示されてないので必要ならば直して
*/
include_once(DATA_MONSTER);
?>
<div style="margin:0 15px">
<h4>몬스터</h4>
<table class="align-center" style="width:740px" cellspacing="0">
<?php
$List	= array(
1000	=> array("grass","SP가 있을 때 가끔 강한 공격을 합니다."),
1001	=> array("grass","SP가 있을 때 가끔 강한 공격을 합니다."),
1002	=> array("grass","후열로 밀어내는 공격을 합니다."),
1003	=> array("grass","적당한 강함의 몬스터입니다."),
1005	=> array("grass","레벨이 낮으면 강하게 느껴집니다."),
1009	=> array("grass","HP가 높습니다."),
1012	=> array("cave","동료를 불러 흡혈 공격을 합니다."),
1014	=> array("cave","마법으로 공격하지 않으면 쓰러뜨리기 어렵습니다."),
1017	=> array("cave","동굴의 보스입니다. 쓰러뜨리면 다음 지역으로 갈 수 있습니다."),
);
$Detail	= "<tr>
<td class=\"td6\">이미지</td>
<td class=\"td6\">경험치</td>
<td class=\"td6\">자금</td>
<td class=\"td6\">HP</td>
<td class=\"td6\">SP</td>
<td class=\"td6\">STR</td>
<td class=\"td6\">INT</td>
<td class=\"td6\">DEX</td>
<td class=\"td6\">SPD</td>
<td class=\"td6\">LUK</td>
</tr>";
foreach($List as $No => $exp) {
	$monster	= CreateMonster($No);
	$char	= new char($monster);
	print($Detail);
	print("</td><td class=\"td7\">\n");
	//print('<img src="'.IMG_CHAR.$monster["img"].'" />'."\n");
	$char->ShowCharWithLand($exp[0]);
	print("</td><td class=\"td7\">\n");
	print("{$monster['exphold']}\n");
	print("</td><td class=\"td7\">\n");
	print("{$monster['moneyhold']}\n");
	print("</td><td class=\"td7\">\n");
	print("{$monster['maxhp']}\n");
	print("</td><td class=\"td7\">\n");
	print("{$monster['maxsp']}\n");
	print("</td><td class=\"td7\">\n");
	print("{$monster['str']}\n");
	print("</td><td class=\"td7\">\n");
	print("{$monster['int']}\n");
	print("</td><td class=\"td7\">\n");
	print("{$monster['dex']}\n");
	print("</td><td class=\"td7\">\n");
	print("{$monster['spd']}\n");
	print("</td><td class=\"td8\">\n");
	print("{$monster['luk']}\n");
	print("</td></tr>\n");
	print("<tr><td class=\"td7\" colspan=\"11\">\n");
	print("$exp[1]");
	print("</td></tr>\n");
}
?>
</table>
</div>
