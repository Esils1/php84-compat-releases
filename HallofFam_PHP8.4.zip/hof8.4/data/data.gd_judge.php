<?php
include_once(DATA_JUDGE_SETUP);
?>
<div style="margin:0 15px">
<h4>판정(judge)</h4>
<?php
// 일람을 표시한다.
/*
$List	= JudgeList();
foreach($List as $No) {
	$Judge	= LoadJudgeData($No);
	print($Judge["exp2"]."<br />\n");
}
*/
?>
<table border="0" cellspacing="0">
  <tbody>
    <tr>
      <td class="td6">반드시</td>
      <td class="td6">반드시 실행된다</td>
    </tr>
    <tr>
      <td class="td9">다음턴으로</td>
      <td class="td9">다음 패턴으로 넘어간다</td>
    </tr>
    <tr>
      <td class="td6">자신의 HP가 10% 이상일 경우<br>
      자신의 HP가 20% 이상일 경우<br>
      자신의 HP가 30% 이상일 경우<br>
      자신의 HP가 40% 이상일 경우<br>
      자신의 HP가 50% 이상일 경우<br>
      자신의 HP가 60% 이상일 경우<br>
      자신의 HP가 70% 이상일 경우<br>
      자신의 HP가 80% 이상일 경우<br>
      자신의 HP가 90% 이상일 경우<br>
      자신의 HP가 10% 이하일 경우<br>
      자신의 HP가 20% 이하일 경우<br>
      자신의 HP가 30% 이하일 경우<br>
      자신의 HP가 40% 이하일 경우<br>
      자신의 HP가 50% 이하일 경우<br>
      자신의 HP가 60% 이하일 경우<br>
      자신의 HP가 70% 이하일 경우<br>
      자신의 HP가 80% 이하일 경우<br>
      자신의 HP가 90% 이하일 경우</td>
      <td valign="top" class="td6">HP가**%이상/이하<br>
      일 경우 실행된다.</td>
    </tr>
    <tr>
      <td class="td9">아군의 HP가10%이하인 캐릭터가 있을 때<br>
      아군의 HP가30%이하인 캐릭터가 있을 때<br>
      아군의 HP가50%이하인 캐릭터가 있을 때<br>
      아군의 HP가70%이하인 캐릭터가 있을 때<br>
      아군의 HP가90%이하인 캐릭터가 있을 때</td>
      <td valign="top" class="td9">HP가 **%이하인 캐릭터가<br>
      1명 이상 있을 경우 실행된다.</td>
    </tr>
    <tr>
      <td class="td6">아군의 평균 HP가 10% 이상일 때<br>
      아군의 평균 HP가 30% 이상일 때<br>
      아군의 평균 HP가 50% 이상일 때<br>
      아군의 평균 HP가 70% 이상일 때<br>
      아군의 평균 HP가 90% 이상일 때<br>
      아군의 평균 HP가 10% 이하일 때<br>
      아군의 평균 HP가 30% 이하일 때<br>
      아군의 평균 HP가 50% 이하일 때<br>
      아군의 평균 HP가 70% 이하일 때<br>
      아군의 평균 HP가 90% 이하일 때</td>
      <td valign="top" class="td6">평균HP가 **%이상/이하<br>
      일 경우 실행된다</td>
    </tr>
    <tr>
      <td class="td9">자신의 SP가 10% 이상일 때<br>
      자신의 SP가 20% 이상일 때<br>
      자신의 SP가 30% 이상일 때<br>
      자신의 SP가 40% 이상일 때<br>
      자신의 SP가 50% 이상일 때<br>
      자신의 SP가 60% 이상일 때<br>
      자신의 SP가 70% 이상일 때<br>
      자신의 SP가 80% 이상일 때<br>
      자신의 SP가 90% 이상일 때<br>
      자신의 SP가 10% 이하일 때<br>
      자신의 SP가 20% 이하일 때<br>
      자신의 SP가 30% 이하일 때<br>
      자신의 SP가 40% 이하일 때<br>
      자신의 SP가 50% 이하일 때<br>
      자신의 SP가 60% 이하일 때<br>
      자신의 SP가 70% 이하일 때<br>
      자신의 SP가 80% 이하일 때<br>
      자신의 SP가 90% 이하일 때</td>
      <td valign="top" class="td9">SP가 **%이상/이하<br>
      일 경우에 따라 실행된다.</td>
    </tr>
    <tr>
      <td class="td6">아군에 SPが10%이하인 캐릭터가 있을 때<br>
      아군에 SPが30%이하인 캐릭터가 있을 때<br>
      아군에 SPが50%이하인 캐릭터가 있을 때<br>
      아군에 SPが70%이하인 캐릭터가 있을 때<br>
      아군에 SPが90%이하인 캐릭터가 있을 때</td>
      <td valign="top" class="td6">SP가 **%이하의 캐릭터가<br>
      1명 이상 있을 경우 실행된다</td>
    </tr>
    <tr>
      <td class="td9">아군의 평균 SP가 10% 이상일 때<br>
      아군의 평균 SP가 30% 이상일 때<br>
      아군의 평균 SP가 50% 이상일 때<br>
      아군의 평균 SP가 70% 이상일 때<br>
      아군의 평균 SP가 90% 이상일 때<br>
      아군의 평균 SP가 10% 이하일 때<br>
      아군의 평균 SP가 30% 이하일 때<br>
      아군의 평균 SP가 50% 이하일 때<br>
      아군의 평균 SP가 70% 이하일 때<br>
      아군의 평균 SP가 90% 이하일 때</td>
      <td valign="top" class="td9">평균 SP가 **%이상/이하<br>
      에 따라 실행된다.</td>
    </tr>
    <tr>
      <td class="td6">1명 이상의 아군이 쓰러져 있을 때<br>
      2명 이상의 아군이 쓰러져 있을 때<br>
      3명 이상의 아군이 쓰러져 있을 때<br>
      자기 혼자만이 살아 있을 때<br>
      2명 이상이 살아 있을 때<br>
      3명 이상이 살아 있을 때<br>
      4명 이상이 살아 있을 때</td>
      <td valign="top" class="td6">아군의<br>
      생존?<br>
      사망?<br>
      에 따라 실행된다.</td>
    </tr>
    <tr>
      <td class="td9">10%의 확률로<br>
      30%의 확률로<br>
      50%의 확률로<br>
      70%의 확률로<br>
      90%의 확률로</td>
      <td valign="top" class="td9">확률.</td>
    </tr>
    <tr>
      <td class="td6">첫턴행동시<br>
      2턴행동시<br>
      3턴행동시<br>
      4턴행동시<br>
      5턴행동시</td>
      <td valign="top" class="td6">결정한 선택 턴에 따라<br>
      실행된다</td>
    </tr>
    <tr>
      <td class="td9">1번은 반드시<br>
      2번은 반드시<br>
      3번은 반드시</td>
      <td valign="top" class="td9">턴의 수치에 따라<br>
      반드시 실행된다</td>
    </tr>
    <tr>
      <td class="td6">아군에 차지(영창)중인 캐릭터가 있을 때<br>
      아군에 차지(영창)중인 캐릭터가 없을 때<br>
      적에 차지(영창)중인 캐릭터가 있을 때<br>
      적에 차지(영창)중인 캐릭터가 없을 때</td>
      <td valign="top" class="td6">아군/적<br>
      의 영창 캐릭터 유무에 따라<br>
      실행된다</td>
    </tr>
    <tr>
      <td class="td9">독상태의 캐릭터가  있을 때<br>
      독상태의 캐릭터가 2명 이상 있을 때<br>
      독상태의 캐릭터가 3명 이상 있을 때<br>
      독상태의 캐릭터가 4명 이상 있을 때</td>
      <td valign="top" class="td9">독 상태 캐릭터의 상태에 따라<br>
      실행한다</td>
    </tr>
    <tr>
      <td class="td6">자신이 전방일 때<br>
      아군에 전방이  없을 때<br>
      아군의 전방이 1명 있을 때<br>
      아군의 전방이 2명 이하일 때<br>
      아군의 전방이 3명 이하일 때<br>
      아군의 전방이 4명 이하일 때<br>
      아군에 전방이 뒤로 빠질 때<br>
      아군의 전방이 2명 이상일 때<br>
      아군의 전방이 3명 이상일 때<br>
      아군의 전방이 4명 이상일 때<br>
      자신이 후방일 때<br>
      아군에 후방이  없을 때<br>
      아군의 후방이 1명 있을 때<br>
      아군의 후방이 2명 이하일 때<br>
      아군의 후방이 3명 이하일 때<br>
      아군의 후방이 4명 이하일 때<br>
      아군의 후방이 1명 이상일 때<br>
      아군의 후방이 2명 이상일 때<br>
      아군의 후방이 3명 이상일 때<br>
      아군의 후방이 4명 이상일 때</td>
      <td valign="top" class="td6">자신의 위치<br>
      <br>
      또는<br>
      <br>
      아군의 전후방에 따라 실행.<br>
      (사망자는 포함하지 않는다)</td>
    </tr>
    <tr>
      <td class="td9">적이 전방이 있을 때<br>
      적이 전방이 없을 때<br>
      적이 후방이 있을 때<br>
      적이 후방이 없을 때</td>
      <td valign="top" class="td9">적의 대열에 따라 실행<br>
      (사망자는 포함하지 않는다)</td>
    </tr>
    <tr>
      <td class="td6">소환 캐릭터가 없을 때<br>
      소환 캐릭터가 1마리만 있을 때<br>
      소환 캐릭터가 1마리 이상 있을 때</td>
      <td valign="top" class="td6">소환캐릭터의 유무에 따라서 실행</td>
    </tr>
  </tbody>
</table>

</div>