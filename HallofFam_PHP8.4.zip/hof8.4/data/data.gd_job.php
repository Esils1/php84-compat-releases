<?php
include_once(DATA_JOB);
?>
<div style="margin:15px">
<h4>직업</h4>
<ul>
<li><a href="#100">전사</a>
<ul>
<li><a href="#101">로열 가드</a></li>
<li><a href="#102">희생기사</a></li>
<li><a href="#103">마녀사냥꾼</a></li>
</ul>
</li>
<li><a href="#200">마법사</a>
<ul>
<li><a href="#201">흑마법사</a></li>
<li><a href="#202">소환사</a></li>
<li><a href="#203">강령술사</a></li>
</ul>
</li>
<li><a href="#300">사제</a>
<ul>
<li><a href="#301">주교</a></li>
<li><a href="#302">드루이드</a></li>
</ul>
</li>
<li><a href="#400">사냥꾼</a>
<ul>
<li><a href="#401">저격수</a></li>
<li><a href="#402">마수 조련사</a></li>
<li><a href="#403">살인자</a></li>
</ul>
</li>
<li><a href="#500">고블린</a>
<ul>
</li>
</ul>
<h4>종류</h4>
<table cellspacing="0" style="width:740px">
<?php
$job	= array(
// 여기서 밖에 필요 없기 때문에 직업 데이터에는 쓰지 않습니다.
100 => "전사계 기본직.<br />적당히 몸빵도 되고, 공격도 적당히 쓸만하다.",
101 => "전사계 상급직.<br />방어도 공격도 한층 강해진다.",
102 => "전사계 상급직.<br />공격에 특화한 전사.<br />자신의 체력을 희생해 강력한 기술을 사용할 수 있다.<br /><a href=\"?manual#sacrier\">희생기사의 공격에 대해</a>",
103 => "전사계 상급직.<br />상대의 마력을 빼앗거나 한다, 약간 변칙적인 전사.",
200 => "마법계 기본직.<br />물리적 공격에는 약하지만 강한 마법을 사용할 수 있다.",
201 => "마법계 상급직.<br />한층 더 강력한 마법을 사용할 수 있게 된다.",
202 => "마법계 상급직.<br />시간은 걸리지만 강력한 소환수를 부를 수 있다.",
203 => "마법계 상급직.<br />상대의 능력을 내리거나 좀비를 만들거나 할 수 있다.<br />독도 취급할 수 있다.",
300 => "성직 기본직.<br />아군의 HP,SP의 회복을 할 수 있다.",
301 => "성직 상급직.<br />아군의 능력치도 올라가게 된다.",
302 => "성직 상급직.<br />특수한 서포트 능력을 가지고 있다.",
400 => "활계 기본직.<br />상대의 전방 캐릭터의 영향을 받지 않고 공격할 수 있다.",
401 => "활계 상급직.<br />한층 더 강력한 공격이 가능.",
402 => "활계 상급직.<br />민첩한 소환과 소환수의 강화를 할 수 있다.",
403 => "활계 상급직.<br />독의 취급에 뛰어난 직업.",
500 => "몬스터.<br />미지의 힘을 감추고 있다..",
);
$JobSkill	= array(
// 여기서 밖에 필요 없기 때문에 직업 데이터에는 쓰지 않습니다.
100 => array(1001,3110,3120),
101 => array(1012,1023,1019),
102 => array(1100,1114,1118),
103 => array(1020,2090,3215),
200 => array(1002,2011,3011),
201 => array(2001,2024,2015),
202 => array(3020,2500,2501),
203 => array(2030,2050,2460),
300 => array(3000,3101,2100),
301 => array(2101,3220,2481),
302 => array(3050,3055,3060),
400 => array(2300,2301,2302),
401 => array(2305,2306,2307),
402 => array(2405,2406,3300),
403 => array(1200,1207,1204),
500 => array(1001,3110,3120,1002,2011,3011,3000,3101,2100),
);
include(DATA_SKILL);
$EquipText	= array(
	"Sword" => "검",
	"TwoHandSword" => "양손검",
	"Dagger" => "단검",
	"Wand" => "지팡이",
	"Staff" => "스태프",
	"Bow" => "활",
	"Whip" => "채찍",
	"Shield" => "방패",
	"Book" => "마도서",
	"Armor" => "갑옷",
	"Cloth" => "의복",
	"Robe" => "로브",
	"Item" => "장신구"
);
foreach($job as $No => $exp) {
	$flag	= $flag ^ 1;
	$css	= $flag?' class="td6"':' style="padding:3px;"';
	$JobData	= LoadJobData($No);
	print("<tr>\n");
	print('<td'.$css.' valign="top"><a name="#'.$No.'"></a><span class="bold">');
	print($JobData["name_male"]);
	if($JobData["name_male"] !== $JobData["name_female"])
		print("<br />(".$JobData["name_female"].")");
	print('</span></td>'."\n");
	print("<td$css>");
	print('<img src="'.IMG_CHAR.$JobData["img_male"].'" />');
	print('<img src="'.IMG_CHAR.$JobData["img_female"].'" />');
	print("</td>");
	print("<td$css>$exp");
	print("</td>");
	print("<tr><td$css colspan=\"3\"><div style=\"margin-left:30px\">");
	$equip	= "장비 : ";
	foreach($JobData["equip"] as $item){
		$equip	.= (isset($EquipText[$item])?$EquipText[$item]:$item).", "; 
	}
	print(substr($equip,0,-2));
	print("</div></td></tr>\n");
	print("<tr><td$css colspan=\"3\"><div style=\"padding-left:30px\">\n");
	foreach($JobSkill["$No"] as $SkillNo) {
		$skill	= LoadSkillData($SkillNo);
		ShowSkillDetail($skill);
		print("<br />\n");
	}
	print("</div></td></tr>");
	print("</tr>\n");
}/*
<tr>
<td><span class="bold">Warrior</span></td>
<td><img src="<?=IMG_CHAR?>mon_079.gif" /><img src="<?=IMG_CHAR?>mon_080r.gif" /></td>
</tr>
<tr><td colspan="2"></td></tr>*/
?>
</table>
</div>
