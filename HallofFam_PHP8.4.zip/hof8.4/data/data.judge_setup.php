<?php
function LoadJudgeData($no) {
/*
	判?材料
	HP
	SP
	人?(自分だけ生存等)
	?態(毒等)？？？
	自分の行動回?
	回?限定
	相手の?態
	?純な確率
*/

	$Quantity	= '○○';

	switch($no) {

		case 1000:// 必ず
			$judge["exp"]	= "반드시";
			break;
		case 1001:// パス
			$judge["exp"]	= "다음 턴으로 넘긴다";
			break;
//------------------------ HP
		case 1099:
			$judge["exp"]	= "HP";
			$judge["css"]	= true;
			break;
		case 1100:// 自分のHP が{$Quantity}(%)以上
			$judge["exp"]	= "자신의 HP가{$Quantity}(%)이상";
			break;
		case 1101:// 自分のHP が{$Quantity}(%)以下
			$judge["exp"]	= "자신의 HP가{$Quantity}(%)이하";
			break;

		case 1105:// 自分のHP が{$Quantity}以上
			$judge["exp"]	= "자신의 HP가{$Quantity}이상";
			break;
		case 1106:// 自分のHP が{$Quantity}以下
			$judge["exp"]	= "자신의 HP가{$Quantity}이하";
			break;

		case 1110:// 最大HP が{$Quantity}以上
			$judge["exp"]	= "최대 HP가{$Quantity}이상";
			break;
		case 1111:// 最大HP が{$Quantity}以下
			$judge["exp"]	= "최대 HP가{$Quantity}이하";
			break;

		case 1121:// 味方に HPが{$Quantity}(%)以下のキャラ がいる時
			$judge["exp"]	= "아군에 HP가{$Quantity}(%)이하인 캐릭터가 있을때";
			break;

		case 1125:// 味方の 平均HPが {$Quantity}(%)以上の時
			$judge["exp"]	= "아군의 평균 HP가{$Quantity}(%)이상";
			break;
		case 1126:// 味方の 平均HPが {$Quantity}(%)以下の時
			$judge["exp"]	= "아군의 평균 HP가{$Quantity}(%)이하";
			break;
//------------------------ SP
		case 1199:
			$judge["exp"]	= "SP";
			$judge["css"]	= true;
			break;
		case 1200:// 自分のSP が{$Quantity}(%)以上
			$judge["exp"]	= "자신의 SP가{$Quantity}(%)이상";
			break;
		case 1201:// 自分のSP が{$Quantity}(%)以下
			$judge["exp"]	= "자신의 SP가{$Quantity}(%)이하";
			break;

		case 1205:// 自分のSP が{$Quantity}以上
			$judge["exp"]	= "자신의 SP가{$Quantity}이상";
			break;
		case 1206:// 自分のSP が{$Quantity}以下
			$judge["exp"]	= "자신의 SP가{$Quantity}이하";
			break;

		case 1210:// 最大SP が{$Quantity}以上
			$judge["exp"]	= "최대 SP가{$Quantity}이상";
			break;
		case 1211:// 最大SP が{$Quantity}以下
			$judge["exp"]	= "최대 SP가{$Quantity}이하";
			break;

		case 1221:// 味方に SPが{$Quantity}(%)以下のキャラ がいる時
			$judge["exp"]	= "아군에 SP가{$Quantity}(%)이하인 캐릭터가 있을때";
			break;

		case 1225:// 味方の 平均SPが {$Quantity}(%)以上の時
			$judge["exp"]	= "아군의 평균 SP가{$Quantity}(%)이상";
			break;
		case 1226:// 味方の 平均SPが {$Quantity}(%)以下の時
			$judge["exp"]	= "아군의 평균 SP가{$Quantity}(%)이하";
			break;
/*
//------------------------ STR
		case 1299:
			$judge["exp"]	= "STR";
			break;
		case 1300:// 自分のSTRが{$Quantity} 以上
			$judge["exp"]	= "自分のSTRが{$Quantity} 以上";
			break;
		case 1301:// 自分のSTRが{$Quantity} 以下
			$judge["exp"]	= "自分のSTRが{$Quantity} 以下";
			break;
//------------------------ INT
		case 1309:
			$judge["exp"]	= "INT";
			break;
		case 1310:// 自分のINTが{$Quantity} 以上
			$judge["exp"]	= "自分のINTが{$Quantity} 以上";
			break;
		case 1311:// 自分のINTが{$Quantity} 以下
			$judge["exp"]	= "自分のINTが{$Quantity} 以下";
			break;
//------------------------ DEX
		case 1319:
			$judge["exp"]	= "DEX";
			break;
		case 1320:// 自分のDEXが{$Quantity} 以上
			$judge["exp"]	= "自分のDEXが{$Quantity} 以上";
			break;
		case 1321:// 自分のDEXが{$Quantity} 以下
			$judge["exp"]	= "自分のDEXが{$Quantity} 以下";
			break;
//------------------------ SPD
		case 1329:
			$judge["exp"]	= "SPD";
			break;
		case 1330:// 自分のSPDが{$Quantity} 以上
			$judge["exp"]	= "自分のSPDが{$Quantity} 以上";
			break;
		case 1331:// 自分のSPDが{$Quantity} 以下
			$judge["exp"]	= "自分のSPDが{$Quantity} 以下";
			break;
//------------------------ LUK
		case 1339:
			$judge["exp"]	= "LUK";
			break;
		case 1340:// 自分のLUKが{$Quantity} 以上
			$judge["exp"]	= "自分のLUKが{$Quantity} 以上";
			break;
		case 1341:// 自分のLUKが{$Quantity} 以下
			$judge["exp"]	= "自分のLUKが{$Quantity} 以下";
			break;
//------------------------ ATK
		case 1349:
			$judge["exp"]	= "ATK";
			break;
		case 1350:// 自分のATKが{$Quantity} 以上
			$judge["exp"]	= "自分のATKが{$Quantity} 以上";
			break;
		case 1351:// 自分のATKが{$Quantity} 以下
			$judge["exp"]	= "自分のATKが{$Quantity} 以下";
			break;
//------------------------ MATK
		case 1359:
			$judge["exp"]	= "MATK";
			break;
		case 1360:// 自分のMATKが{$Quantity} 以上
			$judge["exp"]	= "自分のMATKが{$Quantity} 以上";
			break;
		case 1361:// 自分のMATKが{$Quantity} 以下
			$judge["exp"]	= "自分のMATKが{$Quantity} 以下";
			break;
//------------------------ DEF
		case 1369:
			$judge["exp"]	= "DEF";
			break;
		case 1370:// 自分のDEFが{$Quantity} 以上
			$judge["exp"]	= "自分のDEFが{$Quantity} 以上";
			break;
		case 1371:// 自分のDEFが{$Quantity} 以下
			$judge["exp"]	= "自分のDEFが{$Quantity} 以下";
			break;
//------------------------ MDEF
		case 1379:
			$judge["exp"]	= "MDEF";
			break;
		case 1380:// 自分のMDEFが{$Quantity} 以上
			$judge["exp"]	= "自分のMDEFが{$Quantity} 以上";
			break;
		case 1381:// 自分のMDEFが{$Quantity} 以下
			$judge["exp"]	= "自分のMDEFが{$Quantity} 以下";
			break;
*/
//------------------------ 生死(味方)
		case 1399:
			$judge["exp"]	= "생사";
			$judge["css"]	= true;
			break;
		case 1400:// 味方の生存者が {$Quantity}人以上
			$judge["exp"]	= "아군의 생존자가 {$Quantity}명 이상";
			break;
		case 1401:// 味方の生存者が {$Quantity}人以下
			$judge["exp"]	= "아군의 생존자가 {$Quantity}명 이하";
			break;
		case 1405:// 味方の死者が {$Quantity}人以上
			$judge["exp"]	= "아군의 사망자가 {$Quantity}명 이상";
			break;
		case 1406:// 味方の死者が {$Quantity}人以下
			$judge["exp"]	= "아군의 사망자가 {$Quantity}명 이하";
			break;

		case 1410:// 味方で前衛の生存者が {$Quantity}人以上
			$judge["exp"]	= "(초기설정의)전방의 생존자 {$Quantity}명 이상";
			break;
//------------------------ 生死(敵)
		case 1449:
			$judge["exp"]	= "생사(적)";
			$judge["css"]	= true;
			break;
		case 1450:// 相手の生存者が {$Quantity}人以上
			$judge["exp"]	= "상대방의 생존자가 {$Quantity}명 이상";
			break;
		case 1451:// 相手の生存者が {$Quantity}人以下
			$judge["exp"]	= "상대방의 생존자가 {$Quantity}명 이하";
			break;
		case 1455:// 相手の死者が {$Quantity}人以上
			$judge["exp"]	= "상대방의 사망자가 {$Quantity}명 이상";
			break;
		case 1456:// 相手の死者が {$Quantity}人以下
			$judge["exp"]	= "상대방의 사망자가 {$Quantity}명 이하";
			break;
//------------------------ チャ?ジ+詠唱
		case 1499:
			$judge["exp"]	= "차지+영창";
			$judge["css"]	= true;
			break;
		case 1500:// チャ?ジ中のキャラが {$Quantity}人以上
			$judge["exp"]	= "차지중인 캐릭터가 {$Quantity}명 이상";
			break;
		case 1501:// チャ?ジ中のキャラが {$Quantity}人以下
			$judge["exp"]	= "차지중인 캐릭터가 {$Quantity}명 이하";
			break;
		case 1505:// 詠唱中のキャラが {$Quantity}人以上
			$judge["exp"]	= "영창중인 캐릭터가 {$Quantity}명 이상";
			break;
		case 1506:// 詠唱中のキャラが {$Quantity}人以下
			$judge["exp"]	= "영창중인 캐릭터가 {$Quantity}명 이하";
			break;
		case 1510:// チャ?ジか詠唱中のキャラが {$Quantity}人以上
			$judge["exp"]	= "차지나 영창중인 캐릭터가 {$Quantity}명 이상";
			break;
		case 1511:// チャ?ジか詠唱中のキャラが {$Quantity}人以下
			$judge["exp"]	= "챠지나 영창중인 캐릭터가 {$Quantity}명 이하";
			break;
//------------------------ チャ?ジ+詠唱(敵)
		case 1549:
			$judge["exp"]	= "차지+영창(적)";
			$judge["css"]	= true;
			break;
		case 1550:// チャ?ジ中の相手が {$Quantity}人以上
			$judge["exp"]	= "차지중인 상대방이 {$Quantity}명 이상";
			break;
		case 1551:// チャ?ジ中の相手が {$Quantity}人以下
			$judge["exp"]	= "차지중인 상대방이 {$Quantity}명 이하";
			break;
		case 1555:// 詠唱中の相手が {$Quantity}人以上
			$judge["exp"]	= "영창중인 상대방이 {$Quantity}명 이상";
			break;
		case 1556:// 詠唱中の相手が {$Quantity}人以下
			$judge["exp"]	= "영창중인 상대방이 {$Quantity}명 이하";
			break;
		case 1560:// チャ?ジか詠唱中の相手が {$Quantity}人以上
			$judge["exp"]	= "차지나 영창중인 상대방이 {$Quantity}명 이상";
			break;
		case 1561:// チャ?ジか詠唱中の相手が {$Quantity}人以下
			$judge["exp"]	= "차지나 영창중인 상대방이 {$Quantity}명 이하";
			break;
//------------------------ 毒
		case 1599:
			$judge["exp"]	= "독";
			$judge["css"]	= true;
			break;
		case 1600:// 自分が毒?態
			$judge["exp"]	= "자신이 독 상태일 경우";
			break;
		case 1610:// 毒?態の味方が {$Quantity}人以上
			$judge["exp"]	= "독 상태의 아군이 {$Quantity}명 이상";
			break;
		case 1611:// 毒?態の味方が {$Quantity}人以下
			$judge["exp"]	= "독 상태의 아군이 {$Quantity}명 이하";
			break;
		case 1612:// 毒?態の味方が {$Quantity}% 以下
			$judge["exp"]	= "독 상태의 아군이 {$Quantity}% 이상";
			break;
		case 1613:// 毒?態の味方が {$Quantity}% 以下
			$judge["exp"]	= "독 상태의 아군이 {$Quantity}% 이하";
			break;
//------------------------ 毒(敵)
		case 1614:
			$judge["exp"]	= "독(적)";
			$judge["css"]	= true;
			break;
		case 1615:// 毒?態の相手が {$Quantity}人以上
			$judge["exp"]	= "독 상태의 상대방이 {$Quantity}명 이상";
			break;
		case 1616:// 毒?態の相手が {$Quantity}人以下
			$judge["exp"]	= "독 상태의 상대방이 {$Quantity}명 이하";
			break;
		case 1617:// 毒?態の相手が {$Quantity}% 以下
			$judge["exp"]	= "독 상태의 상대방이 {$Quantity}% 이상";
			break;
		case 1618:// 毒?態の相手が {$Quantity}% 以下
			$judge["exp"]	= "독 상태의 상대방이 {$Quantity}% 이하";
			break;
//------------------------ 隊列
		case 1699:
			$judge["exp"]	= "대열";
			$judge["css"]	= true;
			break;
		case 1700:// 自分が前列
			$judge["exp"]	= "자신이 전방";
			break;
		case 1701:// 自分が後列
			$judge["exp"]	= "자신이 후방";
			break;

		case 1710:// 味方の 前列が{$Quantity}人以上
			$judge["exp"]	= "아군의 전방이 {$Quantity}명 이상";
			break;
		case 1711:// 味方の 前列が{$Quantity}人以下
			$judge["exp"]	= "아군의 전방이 {$Quantity}명 이하";
			break;
		case 1712:// 味方の 前列が{$Quantity}人以下
			$judge["exp"]	= "아군의 전방이 {$Quantity}명";
			break;

		case 1715:// 味方の 後列が{$Quantity}人以上
			$judge["exp"]	= "아군의 후방이 {$Quantity}명 이상";
			break;
		case 1716:// 味方の 後列が{$Quantity}人以下
			$judge["exp"]	= "아군의 후방이 {$Quantity}명 이하";
			break;
		case 1717:// 味方の 後列が{$Quantity}人以下
			$judge["exp"]	= "아군의 후방이 {$Quantity}명";
			break;
//------------------------ 隊列(敵)
		case 1749:
			$judge["exp"]	= "대열(적)";
			$judge["css"]	= true;
			break;
		case 1750:// 相手の 前列が{$Quantity}人以上
			$judge["exp"]	= "상대방의 전방이 {$Quantity}명 이상";
			break;
		case 1751:// 相手の 前列が{$Quantity}人以下
			$judge["exp"]	= "상대방의 전방이 {$Quantity}명 이하";
			break;
		case 1752:// 相手の 前列が{$Quantity}人
			$judge["exp"]	= "상대방의 전방이 {$Quantity}명";
			break;

		case 1755:// 相手の 後列が{$Quantity}人以上
			$judge["exp"]	= "상대방의 후방이 {$Quantity}명 이상";
			break;
		case 1756:// 相手の 後列が{$Quantity}人以下
			$judge["exp"]	= "상대방의 후방이 {$Quantity}명 이하";
			break;
		case 1757:// 相手の 後列が{$Quantity}人
			$judge["exp"]	= "상대방의 후방이 {$Quantity}명";
			break;
//------------------------ 召喚
		case 1799:
			$judge["exp"]	= "소환";
			$judge["css"]	= true;
			break;
		case 1800:// 味方の 召喚キャラが {$Quantity}匹以上
			$judge["exp"]	= "아군의 소환캐릭터가 {$Quantity}마리 이상";
			break;
		case 1801:// 味方の 召喚キャラが {$Quantity}匹以下
			$judge["exp"]	= "아군의 소환캐릭터가 {$Quantity}마리 이하";
			break;
		case 1805:// 味方の 召喚キャラが {$Quantity}匹
			$judge["exp"]	= "아군의 소환캐릭터가 {$Quantity}마리";
			break;
//------------------------ 召喚(敵)
		case 1819:
			$judge["exp"]	= "소환(적)";
			$judge["css"]	= true;
			break;
		case 1820:// 相手の 召喚キャラが {$Quantity}匹以上
			$judge["exp"]	= "상대방의 소환캐릭터가 {$Quantity}마리 이상";
			break;
		case 1821:// 相手の 召喚キャラが {$Quantity}匹以下
			$judge["exp"]	= "상대방의 소환캐릭터가 {$Quantity}마리 이하";
			break;
		case 1825:// 相手の 召喚キャラが {$Quantity}匹
			$judge["exp"]	= "상대방의 소환캐릭터가 {$Quantity}마리";
			break;

//------------------------ 魔法陣
		case 1839:
			$judge["exp"]	= "마법진";
			$judge["css"]	= true;
			break;
		case 1840:// 味方の魔法陣の?が {$Quantity}個以上
			$judge["exp"]	= "아군의 마법진의 수가 {$Quantity}개 이상";
			break;
		case 1841:// 味方の魔法陣の?が {$Quantity}個以下
			$judge["exp"]	= "아군의 마법진의 수가 {$Quantity}개 이하";
			break;
		case 1845:// 味方の魔法陣の?が {$Quantity}個
			$judge["exp"]	= "아군의 마법진의 수가 {$Quantity}개";
			break;
//------------------------ 魔法陣(敵)
		case 1849:
			$judge["exp"]	= "마법진(적)";
			$judge["css"]	= true;
			break;
		case 1850:// 相手の魔法陣の?が {$Quantity}個以上
			$judge["exp"]	= "상대방의 마법진의 수가 {$Quantity}개 이상";
			break;
		case 1851:// 相手の魔法陣の?が {$Quantity}個以下
			$judge["exp"]	= "상대방의 마법진의 수가 {$Quantity}개 이하";
			break;
		case 1855:// 相手の魔法陣の?が {$Quantity}個
			$judge["exp"]	= "상대방의 마법진의 수가 {$Quantity}개";
			break;

//------------------------ 指定行動回?
		case 1899:
			$judge["exp"]	= "지정행동횟수";
			$judge["css"]	= true;
			break;
		case 1900:// 自分の行動回?が {$Quantity}回以上
			$judge["exp"]	= "자신의 행동이 {$Quantity}회 이상";
			break;
		case 1901:// 自分の行動回?が {$Quantity}回以下
			$judge["exp"]	= "자신의 행동이 {$Quantity}외 이하";
			break;
		case 1902:// 自分の行動回?が {$Quantity}回目
			$judge["exp"]	= "자신의 {$Quantity}회째의 행동";
			break;
//------------------------ 回?制限
		case 1919:
			$judge["exp"]	= "횟수제한";
			$judge["css"]	= true;
			break;
		case 1920:// {$Quantity}回だけ必ず
			$judge["exp"]	= "{$Quantity}회까지 반드시";
			break;
//------------------------ 確率
		case 1939:
			$judge["exp"]	= "확률";
			$judge["css"]	= true;
			break;
		case 1940:// {$Quantity}%の確率で
			$judge["exp"]	= "{$Quantity}%의 확률로";
			break;


//----------------------- 特殊
		case 9000:// 相手チ?ムにLv**以上が居る。
			$judge["exp"]	= "상대팀의 Lv{$Quantity}이상이 있을 때";
			break;




		default:
$judge	= false;
	}

	return $judge;
}
?>