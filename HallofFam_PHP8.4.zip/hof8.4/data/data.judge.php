<?php 
//function DecideJudge($number,$My,$MyTeam,$EnemyTeam,$classBattle) {
function DecideJudge($number,$My,$classBattle) {

	//횟쾨ㅛ뽁錮ㅉㅻ　웃샙　揀웃　핼轎　ㅘㄻㆂ
	//롼뻣ㅇㅏㅺㅉㅻ。
	if($My->team == TEAM_0) {
		$MyTeam	= $classBattle->team0;
		$EnemyTeam	= $classBattle->team1;
		$MyTeamMC	= $classBattle->team0_mc;
		$EnemyTeamMC	= $classBattle->team1_mc;
	} else {
		$MyTeam	= $classBattle->team1;
		$EnemyTeam	= $classBattle->team0;
		$MyTeamMC	= $classBattle->team1_mc;
		$EnemyTeamMC	= $classBattle->team0_mc;
	}

	$Judge		= $My->judge["$number"];
	$Quantity	= $My->quantity["$number"];

	switch($Judge) {

		case 1000:// ㅊ
			return true;
		case 1001:// ΡⅩ
			return false;

//------------------------ HP
		case 1100:// 섐暇ㅞHP ㄼ**(%)걺얍
			$hpp	= $My->HpPercent();
			if($Quantity <= $hpp) return true;
			break;
		case 1101:// 섐暇ㅞHP ㄼ**(%)걺꼈
			$hpp	= $My->HpPercent();
			if($hpp <= $Quantity) return true;
			break;

		case 1105:// 섐暇ㅞHP ㄼ**걺얍
			$hp		= $My->HP;
			if($Quantity <= $hp) return true;
			break;
		case 1106:// 섐暇ㅞHP ㄼ**걺꼈
			$hp		= $My->HP;
			if($hp <= $Quantity) return true;
			break;

		case 1110:// 뵉쭹HP ㄼ**걺얍
			$mhp		= $My->MAXHP;
			if($Quantity <= $mhp) return true;
			break;
		case 1111:// 뵉쭹HP ㄼ**걺꼈
			$mhp		= $My->MAXHP;
			if($mhp <= $Quantity) return true;
			break;

		case 1121:// 黔鑒ㅛ HPㄼ**(%)걺꼈ㅞ?γι ㄼㄴㅻ샤
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->HpPercent() <= $Quantity)
					return true;
			}
			break;

		case 1125:// 黔鑒ㅞ 却뚜HPㄼ **(%)걺얍ㅞ샤
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
					$sum	+= $char->HpPercent();
					$cnt++;// 으쨍와웃
			}
			$ave	= $sum/$cnt;
			if($Quantity <= $ave) return true;
			break;
		case 1126:// 黔鑒ㅞ 却뚜HPㄼ **(%)걺꼈ㅞ샤
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
					$sum	+= $char->HpPercent();
					$cnt++;// 으쨍와웃
			}
			$ave	= $sum/$cnt;
			if($ave <= $Quantity) return true;
			break;
//------------------------ SP
		case 1200:// 섐暇ㅞSP ㄼ**(%)걺얍
			$spp	= $My->SpPercent();
			if($Quantity <= $spp) return true;
			break;

		case 1201:// 섐暇ㅞSP ㄼ**(%)걺꼈
			$spp	= $My->SpPercent();
			if($spp <= $Quantity) return true;
			break;

		case 1205:// 섐暇ㅞSP ㄼ**걺얍
			$sp		= $My->SP;
			if($Quantity <= $sp) return true;
			break;
		case 1206:// 섐暇ㅞSP ㄼ**걺꼈
			$sp		= $My->SP;
			if($sp <= $Quantity) return true;
			break;

		case 1210:// 뵉쭹SP ㄼ**걺얍
			$msp		= $My->MAXSP;
			if($Quantity <= $msp) return true;
			break;
		case 1211:// 뵉쭹SP ㄼ**걺꼈
			$msp		= $My->MAXSP;
			if($msp <= $Quantity) return true;
			break;

		case 1221:// 黔鑒ㅛ SPㄼ**(%)걺꼈ㅞ?γι ㄼㄴㅻ샤
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->MAXSP === 0) break;
				if($char->SpPercent() <= $Quantity)
					return true;
			}
			break;

		case 1225:// 黔鑒ㅞ 却뚜SPㄼ **(%)걺얍ㅞ샤
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->MAXSP === 0) break;
					
					$sum	+= $char->SpPercent();
					$cnt++;// 으쨍와웃
			}
			// Divide by Zero
			if(!$cnt)
				break;
			$ave	= $sum/$cnt;
			if($Quantity <= $ave) return true;
			break;

		case 1226:// 黔鑒ㅞ 却뚜SPㄼ **(%)걺꼈ㅞ샤
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->MAXSP === 0) break;
					$sum	+= $char->SpPercent();
					$cnt++;// 으쨍와웃
			}
			// Divide by Zero
			if(!$cnt)
				break;
			$ave	= $sum/$cnt;
			if($ave <= $Quantity) return true;
			break;
//------------------------ STR
		case 1300:// 섐暇ㅞSTRㄼ** 걺얍
			break;
		case 1301:// 섐暇ㅞSTRㄼ** 걺꼈
			break;
//------------------------ INT
		case 1310:// 섐暇ㅞINTㄼ** 걺얍
			break;
		case 1311:// 섐暇ㅞINTㄼ** 걺꼈
			break;
//------------------------ DEX
		case 1320:// 섐暇ㅞDEXㄼ** 걺얍
			break;
		case 1321:// 섐暇ㅞDEXㄼ** 걺꼈
			break;
//------------------------ SPD
		case 1330:// 섐暇ㅞSPDㄼ** 걺얍
			break;
		case 1331:// 섐暇ㅞSPDㄼ** 걺꼈
			break;
//------------------------ LUK
		case 1340:// 섐暇ㅞLUKㄼ** 걺얍
			break;
		case 1341:// 섐暇ㅞLUKㄼ** 걺꼈
			break;
//------------------------ ATK
		case 1350:// 섐暇ㅞATKㄼ** 걺얍
			break;
		case 1351:// 섐暇ㅞATKㄼ** 걺꼈
			break;
//------------------------ MATK
		case 1360:// 섐暇ㅞMATKㄼ** 걺얍
			break;
		case 1361:// 섐暇ㅞMATKㄼ** 걺꼈
			break;
//------------------------ DEF
		case 1370:// 섐暇ㅞDEFㄼ** 걺얍
			break;
		case 1371:// 섐暇ㅞDEFㄼ** 걺꼈
			break;
//------------------------ MDEF
		case 1380:// 섐暇ㅞMDEFㄼ** 걺얍
			break;
		case 1381:// 섐暇ㅞMDEFㄼ** 걺꼈
			break;
//------------------------ 와웃(黔鑒)
		case 1400:// 黔鑒ㅞ으쨍솎ㄼ *와걺얍
			foreach($MyTeam as $char) {
				if($char->STATE !== DEAD)
					$alive++;
			}
			if($Quantity <= $alive) return true;
			break;

		case 1401:// 黔鑒ㅞ으쨍솎ㄼ *와걺꼈
			foreach($MyTeam as $char) {
				if($char->STATE !== DEAD)
					$alive++;
			}
			if($alive <= $Quantity) return true;
			break;

		case 1405:// 黔鑒ㅞ삑솎ㄼ *와걺얍
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD)
					$dead++;
			}
			if($Quantity <= $dead) return true;
			break;

		case 1406:// 黔鑒ㅞ삑솎ㄼ *와걺꼈
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD)
					$dead++;
			}
			if($dead <= $Quantity) return true;
			break;

		case 1410:// 黔鑒ㅗ졀귑ㅞ으쨍솎ㄼ *와걺얍
			$front_alive	= 0;
			foreach($MyTeam as $char) {
				if($char->STATE !== DEAD && $char->position == FRONT)
					$front_alive++;
			}
			if($Quantity <= $front_alive) return true;
			break;

//------------------------ 와웃(큠)
		case 1450:// 쥬쇨ㅞ으쨍솎ㄼ *와걺얍
			foreach($EnemyTeam as $char) {
				if($char->STATE !== DEAD)
					$alive++;
			}
			if($Quantity <= $alive) return true;
			break;

		case 1451:// 쥬쇨ㅞ으쨍솎ㄼ *와걺꼈
			foreach($EnemyTeam as $char) {
				if($char->STATE !== DEAD)
					$alive++;
			}
			if($alive <= $Quantity) return true;
			break;

		case 1455:// 쥬쇨ㅞ삑솎ㄼ *와걺얍
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD)
					$dead++;
			}
			if($Quantity <= $dead) return true;
			break;

		case 1456:// 쥬쇨ㅞ삑솎ㄼ *와걺꼈
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD)
					$dead++;
			}
			if($dead <= $Quantity) return true;
			break;

//------------------------ Αγ【Ⅸ+귓쑨
		case 1500:// Αγ【Ⅸ충ㅞ?γιㄼ *와걺얍
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CHARGE)
					$charge++;
			}
			if($Quantity <= $charge) return true;
			break;

		case 1501:// Αγ【Ⅸ충ㅞ?γιㄼ *와걺꼈
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CHARGE)
					$charge++;
			}
			if($charge <= $Quantity) return true;
			break;

		case 1505:// 귓쑨충ㅞ?γιㄼ *와걺얍
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CAST)
					$cast++;
			}
			if($Quantity <= $cast) return true;
			break;

		case 1506:// 귓쑨충ㅞ?γιㄼ *와걺꼈
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CHARGE)
					$cast++;
			}
			if($cast <= $Quantity) return true;
			break;

		case 1510:// Αγ【Ⅸㄻ귓쑨충ㅞ?γιㄼ *와걺얍
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CAST || $char->expect_type === CHARGE)
					$expect++;
			}
			if($Quantity <= $expect) return true;
			break;

		case 1511:// Αγ【Ⅸㄻ귓쑨충ㅞ?γιㄼ *와걺꼈
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CAST || $char->expect_type === CHARGE)
					$expect++;
			}
			if($expect <= $Quantity) return true;
			break;

//------------------------ Αγ【Ⅸ+귓쑨(큠)
		case 1550:// Αγ【Ⅸ충ㅞ쥬쇨ㄼ *와걺얍
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CHARGE)
					$charge++;
			}
			if($Quantity <= $charge) return true;
			break;

		case 1551:// Αγ【Ⅸ충ㅞ쥬쇨ㄼ *와걺꼈
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CHARGE)
					$charge++;
			}
			if($charge <= $Quantity) return true;
			break;

		case 1555:// 귓쑨충ㅞ쥬쇨ㄼ *와걺얍
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CAST)
					$cast++;
			}
			if($Quantity <= $cast) return true;
			break;

		case 1556:// 귓쑨충ㅞ쥬쇨ㄼ *와걺꼈
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CAST)
					$cast++;
			}
			if($cast <= $Quantity) return true;
			break;

		case 1560:// Αγ【Ⅸㄻ귓쑨충ㅞ쥬쇨ㄼ *와걺얍
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CAST || $char->expect_type === CHARGE)
					$expect++;
			}
			if($Quantity <= $expect) return true;
			break;

		case 1561:// Αγ【Ⅸㄻ귓쑨충ㅞ쥬쇨ㄼ *와걺꼈
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->expect_type === CAST || $char->expect_type === CHARGE)
					$expect++;
			}
			if($expect <= $Quantity) return true;
			break;

//------------------------ 판
		case 1600:// 섐暇ㄼ판얾쫴
			if($My->STATE === POISON) return true;
			break;

		case 1610:// 판얾쫴ㅞ黔鑒ㄼ **와걺얍
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->STATE === POISON)
					$poison++;
			}
			if($Quantity <= $poison) return true;
			break;

		case 1611:// 판얾쫴ㅞ黔鑒ㄼ **와걺꼈
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->STATE === POISON)
					$poison++;
			}
			if($poison <= $Quantity) return true;
			break;

		case 1612:// 판얾쫴ㅞ黔鑒ㄼ **% 걺얍
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				$alive++;
				if($char->STATE === POISON)
					$poison++;
			}
			if(!$alive) return false;
			$Rate	= ($poison/$alive) * 100;
			if($Quantity <= $Rate) return true;
			break;

		case 1613:// 판얾쫴ㅞ黔鑒ㄼ **% 걺꼈
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				$alive++;
				if($char->STATE === POISON)
					$poison++;
			}
			if(!$alive) return false;
			$Rate	= ($poison/$alive) * 100;
			if($Rate <= $Quantity) return true;
			break;
//------------------------ 판(큠)
		case 1615:// 판얾쫴ㅞ쥬쇨ㄼ **와걺얍
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->STATE === POISON)
					$poison++;
			}
			if($Quantity <= $poison) return true;
			break;

		case 1616:// 판얾쫴ㅞ쥬쇨ㄼ **와걺꼈
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->STATE === POISON)
					$poison++;
			}
			if($poison <= $Quantity) return true;
			break;

		case 1612:// 판얾쫴ㅞ쥬쇨ㄼ **% 걺얍
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				$alive++;
				if($char->STATE === POISON)
					$poison++;
			}
			if(!$alive) return false;
			$Rate	= ($poison/$alive) * 100;
			if($Quantity <= $Rate) return true;
			break;

		case 1613:// 판얾쫴ㅞ쥬쇨ㄼ **% 걺꼈
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				$alive++;
				if($char->STATE === POISON)
					$poison++;
			}
			if(!$alive) return false;
			$Rate	= ($poison/$alive) * 100;
			if($Rate <= $Quantity) return true;
			break;
//------------------------ 쭘轎
		case 1700:// 섐暇ㄼ졀轎
			if($My->POSITION == FRONT) return true;
			break;

		case 1701:// 섐暇ㄼ멨轎
			if($My->POSITION == BACK) return true;
			break;

		case 1710:// 黔鑒ㅞ 졀轎ㄼ**와걺얍
			$front	= 0;
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == FRONT)
					$front++;
			}
			if($Quantity <= $front) return true;
			break;

		case 1711:// 黔鑒ㅞ 졀轎ㄼ**와걺꼈
			$front	= 0;
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == FRONT)
					$front++;
			}
			if($front <= $Quantity) return true;
			break;

		case 1712:// 黔鑒ㅞ 졀轎ㄼ**와
			$front	= 0;
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == FRONT)
					$front++;
			}
			if($front == $Quantity) return true;
			break;

		case 1715:// 黔鑒ㅞ 멨轎ㄼ**와걺얍
			$back	= 0;
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == BACK)
					$back++;
			}
			if($Quantity <= $back) return true;
			break;

		case 1716:// 黔鑒ㅞ 멨轎ㄼ**와걺꼈
			$back	= 0;
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == BACK)
					$back++;
			}
			if($back <= $Quantity) return true;
			break;

		case 1717:// 黔鑒ㅞ 멨轎ㄼ**와
			$back	= 0;
			foreach($MyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == BACK)
					$back++;
			}
			if($back == $Quantity) return true;
			break;

//------------------------ 쭘轎(큠)
		case 1750:// 쥬쇨ㅞ 졀轎ㄼ**와걺얍
			$front	= 0;
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == FRONT)
					$front++;
			}
			if($Quantity <= $front) return true;
			break;

		case 1751:// 쥬쇨ㅞ 졀轎ㄼ**와걺꼈
			$front	= 0;
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == FRONT)
					$front++;
			}
			if($front <= $Quantity) return true;
			break;

		case 1752:// 쥬쇨ㅞ 졀轎ㄼ**와
			$front	= 0;
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == FRONT)
					$front++;
			}
			if($Quantity == $front) return true;
			break;

		case 1755:// 쥬쇨ㅞ 멨轎ㄼ**와걺얍
			$back	= 0;
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == BACK)
					$back++;
			}
			if($Quantity <= $back) return true;
			break;

		case 1756:// 쥬쇨ㅞ 멨轎ㄼ**와걺꼈
			$back	= 0;
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == BACK)
					$back++;
			}
			if($back <= $Quantity) return true;
			break;

		case 1757:// 쥬쇨ㅞ 멨轎ㄼ**와
			$back	= 0;
			foreach($EnemyTeam as $char) {
				if($char->STATE === DEAD) break;
				if($char->POSITION == BACK)
					$back++;
			}
			if($Quantity == $back) return true;
			break;

//------------------------ 쑈눌
		case 1800:// 黔鑒ㅞ 쑈눌?γιㄼ **걺얍
			$summon	= 0;
			foreach($MyTeam as $char) {
				//if($char->STATE === DEAD) break;
				if($char->summon)
					$summon++;
			}
			if($Quantity <= $summon) return true;
			break;

		case 1801:// 黔鑒ㅞ 쑈눌?γιㄼ **걺꼈
			$summon	= 0;
			foreach($MyTeam as $char) {
				//if($char->STATE === DEAD) break;
				if($char->summon)
					$summon++;
			}
			if($summon <= $Quantity) return true;
			break;

		case 1805:// 黔鑒ㅞ 쑈눌?γιㄼ **
			$summon	= 0;
			foreach($MyTeam as $char) {
				//if($char->STATE === DEAD) break;
				if($char->summon)
					$summon++;
			}
			if($summon == $Quantity) return true;
			break;

//------------------------ 쑈눌(큠)
		case 1820:// 쥬쇨ㅞ 쑈눌?γιㄼ **걺얍
			$summon	= 0;
			foreach($EnemyTeam as $char) {
				//if($char->STATE === DEAD) break;
				if($char->summon)
					$summon++;
			}
			if($Quantity <= $summon) return true;
			break;

		case 1821:// 쥬쇨ㅞ 쑈눌?γιㄼ **걺꼈
			$summon	= 0;
			foreach($EnemyTeam as $char) {
				//if($char->STATE === DEAD) break;
				if($char->summon)
					$summon++;
			}
			if($summon <= $Quantity) return true;
			break;

		case 1825:// 쥬쇨ㅞ 쑈눌?γιㄼ **
			$summon	= 0;
			foreach($EnemyTeam as $char) {
				//if($char->STATE === DEAD) break;
				if($char->summon)
					$summon++;
			}
			if($summon == $Quantity) return true;
			break;

//------------------------ 渠匣왠
		case 1840:// 黔鑒ㅞ渠匣왠ㅞ웃ㄼ **맣걺얍
			if($Quantity <= $MyTeamMC)
				return true;
			break;
		case 1841:// 黔鑒ㅞ渠匣왠ㅞ웃ㄼ **맣걺꼈
			if($MyTeamMC <= $Quantity)
				return true;
			break;
		case 1845:// 黔鑒ㅞ渠匣왠ㅞ웃ㄼ **맣
			if($Quantity == $MyTeamMC)
				return true;
			break;
//------------------------ 渠匣왠(큠)
		case 1850:// 쥬쇨ㅞ渠匣왠ㅞ웃ㄼ **맣걺얍
			if($Quantity <= $EnemyTeamMC)
				return true;
			break;
		case 1851:// 쥬쇨ㅞ渠匣왠ㅞ웃ㄼ **맣걺꼈
			if($EnemyTeamMC <= $Quantity)
				return true;
			break;
		case 1855:// 쥬쇨ㅞ渠匣왠ㅞ웃ㄼ **맣
			if($Quantity == $EnemyTeamMC)
				return true;
			break;

//------------------------ 쀼쾨밋튼뀨웃
		case 1900:// 섐暇ㅞ밋튼뀨웃ㄼ **뀨걺얍
			if(($Quantity-1) <= $My->ActCount) return true;
			break;

		case 1901:// 섐暇ㅞ밋튼뀨웃ㄼ **뀨걺꼈
			if($My->ActCount <= ($Quantity-1)) return true;
			break;

		case 1902:// 섐暇ㅞ밋튼뀨웃ㄼ **뀨涇
			if($My->ActCount == ($Quantity-1)) return true;
			break;

//------------------------ 뀨웃윈맞
		case 1920:// **뀨ㅐㅁㅊ
			if($My->JdgCount[$number] < $Quantity) return true;
			break;

//------------------------ 널顆
		case 1940:// **%ㅞ널顆ㅗ
			$prob	= mt_rand(1,100);
			if($prob <= $Quantity) return true;
			break;


//------------------------ 팅쇱ㅚ횟쾨
		case 9000:// 쥬쇨Α【?ㅛLv**걺얍ㄼ듸ㅻ。
			foreach($EnemyTeam as $char) {
				if($Quantity <= $char->level)
					return true;
			}
			break;
	}
}
//////////////////////////////////////////////////
//	SPㅛㅲ쭤錮ㅗㄽㅏ。(?)
function &FuncTeamHpSpRate($TeamHpRate,$NO) {
	foreach($TeamHpRate as $key => $Rate) {
		if($Rate <= $NO)
			$target[]	= &$MyTeam[$key];
	}
	return $target ? $target : false;
}
?>