<?php 
if(defined("DATA_ENCHANT") && file_exists(DATA_ENCHANT))
	include_once(DATA_ENCHANT);
else if(file_exists(__DIR__."/data.enchant.php"))
	include_once(__DIR__."/data.enchant.php");

function LoadItemData($no) {
	if(!$no)
		return false;
	$base	= substr($no,0,4);//아이템의 종류
	$refine	= (int) substr($no,4,2);//정련치
	// 부가 능력
	$option0	= substr($no,6,3);
	$option1	= substr($no,9,3);
	$option2	= substr($no,12,3);

/*
 * 설정 항목
 * ---------------------------------------------
 * "name"	=> "명칭",
 * "type"=>"종류",
 * "buy"=>"매입가",
 * "img"=>"화상",
 * "atk"=>array(물리 공격, 마법 공격),
 * "def"=>array(물리비율?,물리감, 마법비율?,마법감),
 * "dh"=> true,//양손 무기인가 아닌가( "D"ouble"H"and )
 * "handle"=>"수치",
 * "need" => array("소재 번호"=>수, ...),// 제작에 필요한 아이템
 * ---------------------------------------------
 * type
 * "Sword"	한 손검
 * "TwoHandSword"	양손검
 * "Dagger"	단검
 * "Spear"	양손창
 * "Pike"	한 손창
 * "Axe"	양손도끼
 * "Hatchet"한 손도끼
 * "Wand"	한 손지팡이
 * "Staff"	양손지팡이
 * "Mace"	둔기(한 손)
 * "Bow"	활
 * "CrossBow"	석궁
 * 
 * "Shield"	방패
 * "MainGauche"	방어용 단검
 * "Book"	책
 * 
 * "Armor"	갑옷
 * "Cloth"	코트
 * "Robe"	로브
 * 
 * "?"
 *--------------------------------------------
	추가 옵션
	P_MAXHP
	M_MAXHP
	P_MAXSP
	M_MAXSP
	P_STR
	P_INT
	P_DEX
	P_SPD
	P_LUK
	P_SUMMON = 소환력 강화
	P_PIERCE = array(물리, 마법),
 *--------------------------------------------
 */
	switch($base) {
		case "1000":	//	1000-1100	한 손검
$item	= array(
"name"	=> "숏소드",
"type"	=> "Sword",
"buy"	=> "500",
"img"	=> "we_sword026.png",
"atk"	=> array(10,0),
"handle"=> "1",
"need"	=> array("6001"=>"4",),
); break;
		case "1001":
$item	= array(
"name"	=> "펄션",
"type"	=> "Sword",
"buy"	=> "1000",
"img"	=> "we_sword031.png",
"atk"	=> array(15,0),
"handle"=> "2",
"need"	=> array("6001"=>"6","6002"=>"2",),
); break;
		case "1002":
$item	= array(
"name"	=> "대검",
"type"	=> "Sword",
"buy"	=> "3000",
"img"	=> "we_sword026.png",
"atk"	=> array(20,0),
"handle"=> "2",
"need"	=> array("6001"=>"4","6002"=>"4",),
); break;
		case "1003":
$item	= array(
"name"	=> "레이피어",
"type"	=> "Sword",
"buy"	=> "5000",
"img"	=> "we_sword026c.png",
"atk"	=> array(25,0),
"handle"=> "3",
"need"	=> array("6001"=>"2","6002"=>"8",),
); break;
		case "1004":
$item	= array(
"name"	=> "커틀러스",
"type"	=> "Sword",
"buy"	=> "8000",
"img"	=> "we_sword026.png",
"atk"	=> array(30,0),
"handle"=> "4",
"need"	=> array("6002"=>"8","6003"=>"2",),
); break;
		case "1005":
$item	= array(
"name"	=> "롱소드",
"type"	=> "Sword",
"buy"	=> "14000",
"img"	=> "we_sword026.png",
"atk"	=> array(40,0),
"handle"=> "5",
"need"	=> array("6003"=>"12",),
); break;
		case "1006":
$item	= array(
"name"	=> "브로드소드",
"type"	=> "Sword",
"buy"	=> "20000",
"img"	=> "we_sword026.png",
"atk"	=> array(50,0),
"handle"=> "6",
"need"	=> array("6002"=>"4","6003"=>"16",),
); break;
		case "1007":
$item	= array(
"name"	=> "쇼텔",
"type"	=> "Sword",
"buy"	=> "35000",
"img"	=> "we_sword026.png",
"atk"	=> array(60,0),
"handle"=> "7",
"need"	=> array("6003"=>"24",),
); break;
		case "1008":
$item	= array(
"name"	=> "플랑베르주",
"type"	=> "Sword",
"buy"	=> "60000",
"img"	=> "we_sword026.png",
"atk"	=> array(80,0),
"handle"=> "10",
"need"	=> array("6003"=>"32",),
); break;
	case "1009":
$item	= array(
"name"	=> "룬 소드",
"type"	=> "Sword",
"dh"	=> true,
"buy"	=> "20000",
"img"	=> "we_sword008c.png",
"atk"	=> array(55,45),
"def"	=> array(0,0,15,0),
"handle"=> "7",
"option"	=> "INT+1 ,",
"need"	=> array(),
"P_INT"	=> "1",
"need"	=> array("6004"=>"3","7000"=>"5","7001"=>"5",),
); break;
	case "1010":
$item	= array(
"name"	=> "룬 블레이드",
"type"	=> "Sword",
"dh"	=> true,
"buy"	=> "35000",
"img"	=> "we_sword006c.png",
"atk"	=> array(65,75),
"def"	=> array(0,0,20,5),
"handle"=> "10",
"option"	=> "MAXHP+90, MAXSP+90, INT+3 ,",
"need"	=> array(),
"P_MAXHP"	=> "90",
"P_MAXSP"	=> "90",
"P_INT"	=> "3",
"need"	=> array("6004"=>"5","7000"=>"10","7001"=>"10","1009"=>"1","6803"=>"1",),
); break;
		case "1020":
$item	= array(
"name"	=> "드래곤 버스터",
"type"	=> "Sword",
"buy"	=> "70000",
"img"	=> "we_sword026.png",
"atk"	=> array(20,0),
"handle"=> "8",
"P_PIERCE"=> array(30,0),
"need"	=> array("6002"=>"15","6800"=>"1",),
"option"	=> "물리 방어 무시+30 ,",
); break;
		case "1021":
$item	= array(
"name"	=> "라이트 브링어",
"type"	=> "Sword",
"buy"	=> "100000",
"img"	=> "we_sword026.png",
"atk"	=> array(3,0),
"handle"=> "1",
); break;
		case "1022":
$item	= array(
"name"	=> "라이트 브링어",
"type"	=> "Sword",
"buy"	=> "160000",
"img"	=> "we_sword004.png",
"atk"	=> array(80,0),
"def"	=> array(5,0,5,0),
"P_SPD"	=> 5,
"handle"=> "9",
"option"	=> "Def/Mdef+5 ,SPD+5 ,",
"need"	=> array("6002"=>"30","6003"=>"10","6802"=>"1",),
); break;
		case "1023":
$item	= array(
"name"	=> "바나나 검",
"type"	=> "Sword",
"buy"	=> "1000",
"img"	=> "banana.png",
"atk"	=> array(3,0),
"P_SPD"	=> 1,
"handle"=> "0",
"option"	=> "SPD+1 ,",
"need"	=> array("6600"=>"3","6602"=>"1",),
); break;
		case "1100":	//	1100-1200	양손검
$item	= array(
"name"	=> "슬레이어",
"type"	=> "TwoHandSword",
"dh"	=> true,
"buy"	=> "1000",
"img"	=> "we_sword006.png",
"atk"	=> array(30,0),
"handle"=> "2",
"need"	=> array("6001"=>"8",),
); break;
		case "1101":
$item	= array(
"name"	=> "클레이모어",
"type"	=> "TwoHandSword",
"dh"	=> true,
"buy"	=> "5000",
"img"	=> "we_sword006.png",
"atk"	=> array(45,0),
"handle"=> "3",
"need"	=> array("6001"=>"6","6002"=>"4",),
); break;
		case "1102":
$item	= array(
"name"	=> "츠바이핸더",
"type"	=> "TwoHandSword",
"dh"	=> true,
"buy"	=> "16000",
"img"	=> "we_sword006.png",
"atk"	=> array(65,0),
"handle"=> "5",
"need"	=> array("6001"=>"6","6002"=>"8",),
); break;
		case "1103":
$item	= array(
"name"	=> "바스타드소드",
"type"	=> "TwoHandSword",
"dh"	=> true,
"buy"	=> "30000",
"img"	=> "we_sword006.png",
"atk"	=> array(80,0),
"handle"=> "6",
"need"	=> array("6001"=>"2","6002"=>"6","6003"=>"8",),
); break;
		case "1104":
$item	= array(
"name"	=> "참수검",
"type"	=> "TwoHandSword",
"dh"	=> true,
"buy"	=> "70000",
"img"	=> "we_sword006.png",
"atk"	=> array(100,0),
"handle"=> "8",
"need"	=> array("6002"=>"10","6003"=>"20",),
); break;
		case "1120":
$item	= array(
"name"	=> "드래곤 슬레이어",
"type"	=> "TwoHandSword",
"dh"	=> true,
"buy"	=> "80000",
"img"	=> "we_sword006.png",
"atk"	=> array(10,0),
"handle"=> "10",
"need"	=> array(),
"P_PIERCE"=> array(50,0),
"need"	=> array("6002"=>"5","6003"=>"10","6800"=>"1",),
"option"	=> "물리 방어 무시+50 ,",
); break;
		case "1200":	// 1200-1300	단검
$item	= array(
"name"	=> "스틸레토",
"type"	=> "Dagger",
"buy"	=> "1000",
"img"	=> "we_sword010.png",
"atk"	=> array(7,0),
"handle"=> "1",
); break;
		case "1201":
$item	= array(
"name"	=> "쿠크리",
"type"	=> "Dagger",
"buy"	=> "10000",
"img"	=> "we_sword010.png",
"atk"	=> array(21,0),
"handle"=> "3",
"need"	=> array("6001"=>12,"6020"=>4),
); break;
		case "1202":
$item	= array(
"name"	=> "스파타",
"type"	=> "Dagger",
"buy"	=> "20000",
"img"	=> "we_sword010.png",
"atk"	=> array(28,0),
"handle"=> "4",
"need"	=> array("6001"=>16,"6020"=>4),
); break;
		case "1203":
$item	= array(
"name"	=> "글라디우스",
"type"	=> "Dagger",
"buy"	=> "40000",
"img"	=> "we_sword010.png",
"atk"	=> array(34,0),
"handle"=> "5",
"need"	=> array("6002"=>12,"6020"=>4),
); break;
		case "1204":
$item	= array(
"name"	=> "암살자의 단검",
"type"	=> "Dagger",
"buy"	=> "50000",
"img"	=> "we_sword010.png",
"atk"	=> array(40,0),
"handle"=> "6",
"need"	=> array("6003"=>10,"6020"=>4),
); break;
		case "1205":
$item	= array(
"name"	=> "메일 브레이커",
"type"	=> "Dagger",
"buy"	=> "50000",
"img"	=> "we_sword010.png",
"atk"	=> array(20,0),
"handle"=> "6",
"P_PIERCE"	=>array(20,0),
"option"	=> "물리 방어 무시+20 ,",
"need"	=> array("6003"=>20,"6022"=>4),
); break;

		case "1220":
$item	= array(
"name"	=> "바나나 단검",
"type"	=> "Dagger",
"buy"	=> "1000",
"img"	=> "banana.png",
"atk"	=> array(1,0),
"P_SPD"	=> 1,
"handle"=> "0",
"option"	=> "SPD+1 ,",
"need"	=> array("6600"=>"3","6602"=>"1",),
); break;

		case "1300":	//	1300-1400	양손창
$item	= array(
"name"	=> "파르티잔",
"type"	=> "Spear",
"dh"	=> true,
"buy"	=> "1000",
"img"	=> "we_spear016.png",
"atk"	=> array(28,0),
"handle"=> "2",
); break;
		case "1400":	//	1400-1500	한 손창
$item	= array(
"name"	=> "재블린",
"type"	=> "Pike",
"buy"	=> "1000",
"img"	=> "we_spear012.png",
"atk"	=> array(14,0),
"handle"=> "2",
); break;
		case "1500":	//	1500-1600	양손도끼
$item	= array(
"name"	=> "대형 도끼",
"type"	=> "Axe",
"dh"	=> true,
"buy"	=> "1000",
"img"	=> "we_axe013b.png",
"atk"	=> array(35,0),
"handle"=> "2",
); break;
		case "1600":	//	1600-1700	한 손도끼
$item	= array(
"name"	=> "토마호크",
"type"	=> "Hatchet",
"buy"	=> "1000",
"img"	=> "we_axe003.png",
"atk"	=> array(17,0),
"handle"=> "2",
); break;
		case "1700":	//	1700-1800	한 손지팡이
$item	= array(
"name"	=> "로드",
"type"	=> "Wand",
"buy"	=> "1000",
"img"	=> "we_staff002.png",
"atk"	=> array(1,5),
"handle"=> "1",
"need"	=> array("6020"=>"2","6001"=>"1",),
); break;
		case "1701":
$item	= array(
"name"	=> "짧은 지팡이",
"type"	=> "Wand",
"buy"	=> "2000",
"img"	=> "we_staff002.png",
"atk"	=> array(5,10),
"handle"=> "2",
"need"	=> array("6020"=>"4","6001"=>"1",),
); break;
		case "1702":
$item	= array(
"name"	=> "나무 지팡이",
"type"	=> "Wand",
"buy"	=> "4000",
"img"	=> "we_staff002.png",
"atk"	=> array(8,15),
"handle"=> "3",
"need"	=> array("6020"=>"8","6002"=>"1",),
); break;
		case "1703":
$item	= array(
"name"	=> "은 지팡이",
"type"	=> "Wand",
"buy"	=> "6000",
"img"	=> "we_staff002.png",
"atk"	=> array(6,20),
"handle"=> "4",
"need"	=> array("6002"=>"8","6020"=>"2"),
); break;
		case "1704":
$item	= array(
"name"	=> "포스 지팡이",
"type"	=> "Wand",
"buy"	=> "10000",
"img"	=> "we_staff002.png",
"atk"	=> array(10,26),
"handle"=> "5",
"need"	=> array("6020"=>"10","6002"=>"4",),
); break;
		case "1705":
$item	= array(
"name"	=> "요정 지팡이",
"type"	=> "Wand",
"buy"	=> "18000",
"img"	=> "we_staff002.png",
"atk"	=> array(5,32),
"handle"=> "6",
"need"	=> array("6021"=>"6","6002"=>"4",),
); break;
		case "1706":
$item	= array(
"name"	=> "마법사 지팡이",
"type"	=> "Wand",
"buy"	=> "25000",
"img"	=> "we_staff002.png",
"atk"	=> array(2,40),
"handle"=> "7",
"need"	=> array("6021"=>"10","6002"=>"4",),
); break;
		case "1800":	//	1800-1900	양손지팡이
$item	= array(
"name"	=> "스태프",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "2000",
"img"	=> "we_staff008b.png",
"atk"	=> array(8,25),
"handle"=> "2",
"need"	=> array("6002"=>"2","6020"=>"4"),
); break;
		case "1801":
$item	= array(
"name"	=> "긴 스태프",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "5000",
"img"	=> "we_staff008b.png",
"atk"	=> array(4,37),
"handle"=> "3",
"need"	=> array("6021"=>"8"),
); break;
		case "1802":
$item	= array(
"name"	=> "마도사 스태프",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "14000",
"img"	=> "we_staff008b.png",
"atk"	=> array(15,49),
"handle"=> "5",
"need"	=> array("6002"=>"2","6021"=>"8",),
); break;
		case "1803":
$item	= array(
"name"	=> "은 스태프",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "20000",
"img"	=> "we_staff008b.png",
"atk"	=> array(10,60),
"handle"=> "6",
"need"	=> array("6002"=>"12","6022"=>"1",),
); break;
		case "1804":
$item	= array(
"name"	=> "금 스태프",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "30000",
"img"	=> "we_staff008b.png",
"atk"	=> array(10,72),
"handle"=> "7",
); break;
		case "1805":
$item	= array(
"name"	=> "수정 스태프",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "35000",
"img"	=> "we_staff008b.png",
"atk"	=> array(12,84),
"handle"=> "8",
); break;
//--------------
		case "1810":
$item	= array(
"name"	=> "마나 스태프",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "20000",
"img"	=> "we_staff008b.png",
"atk"	=> array(3,24),
"handle"=> "4",
"P_MAXSP"	=> "60",
"option"	=> "SP+60 ,",
"need"	=> array("6020"=> 8,"6021"=> 8,),
); break;
		case "1811":
$item	= array(
"name"	=> "천상의 스태프",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "35000",
"img"	=> "we_staff008b.png",
"atk"	=> array(12,32),
"handle"=> "6",
"P_MAXSP"	=> "90",
"option"	=> "SP+90 ,",
"need"	=> array("6020"=> 12,"6021"=> 12,),
); break;
		case "1812":
$item	= array(
"name"	=> "사계절",
"type"	=> "Staff",
"dh"	=> true,
"buy"	=> "60000",
"img"	=> "we_staff008b.png",
"atk"	=> array(12,40),
"handle"=> "8",
"P_MAXSP"	=> "130",
"option"	=> "SP+130 ,",
"need"	=> array("6020"=> 16,"6021"=> 16,),
); break;
		case "1900":	//	1900-2000	둔기(한 손)
$item	= array(
"name"	=> "청동 메이스",
"type"	=> "Mace",
"buy"	=> "1000",
"img"	=> "we_axe015b.png",
"atk"	=> array(5,5),
"handle"=> "2",
); break;
		case "2000":	//	2000-2100	활
$item	= array(
"name"	=> "짧은 활",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "1000",
"img"	=> "we_bow001.png",
"atk"	=> array(20,0),
"handle"=> "2",
"need"	=> array("6020"=>"6","6181"=>"1",),
); break;
		case "2001":
$item	= array(
"name"	=> "합성궁",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "4000",
"img"	=> "we_bow001.png",
"atk"	=> array(30,0),
"handle"=> "6",
"need"	=> array("6020"=>"9","6181"=>"2",),
); break;
		case "2002":
$item	= array(
"name"	=> "대궁",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "8000",
"img"	=> "we_bow001.png",
"atk"	=> array(40,0),
"handle"=> "12",
"need"	=> array("6021"=>"6","6181"=>"2",),
); break;
		case "2003":
$item	= array(
"name"	=> "사냥꾼 활",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "14000",
"img"	=> "we_bow001.png",
"atk"	=> array(50,0),
"handle"=> "16",
"need"	=> array("6020"=>"4","6021"=>"4","6181"=>"4",),
); break;
		case "2004":
$item	= array(
"name"	=> "은 활",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "20000",
"img"	=> "we_bow001.png",
"atk"	=> array(60,0),
"handle"=> "20",
"need"	=> array("6002"=>"4","6021"=>"6","6182"=>"2",),
); break;
		case "2005":
$item	= array(
"name"	=> "명사수",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "30000",
"img"	=> "we_bow001.png",
"atk"	=> array(70,0),
"handle"=> "24",
"need"	=> array("6021"=>"12","6182"=>"4",),
); break;
		case "2006":
$item	= array(
"name"	=> "로빈 후드",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "45000",
"img"	=> "we_bow001.png",
"atk"	=> array(80,0),
"handle"=> "28",
"need"	=> array("6021"=>"4","6022"=>"14","6182"=>"6",),
); break;
		case "2007":
$item	= array(
"name"	=> "배리스터",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "60000",
"img"	=> "we_bow001.png",
"atk"	=> array(90,0),
"handle"=> "30",
); break;
		case "2008":
$item	= array(
"name"	=> "아르테미스",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "100000",
"img"	=> "we_bow001.png",
"atk"	=> array(140,0),
"handle"=> "40",
); break;
		case "2020":
$item	= array(
"name"	=> "드래곤 윙",
"type"	=> "Bow",
"dh"	=> true,
"buy"	=> "120000",
"img"	=> "we_bow001.png",
"atk"	=> array(40,0),
"handle"=> "30",
"P_PIERCE"=> array(40,0),
"need"	=> array("6022"=>"10","6182"=>"5","6801"=>"1",),
"option"	=> "물리 방어 무시+40 ,",
); break;
						//	2100-2199	석궁
		case "2100":
$item	= array(
"name"	=> "가스트라페테스",
"type"	=> "CrossBow",
"dh"	=> true,
"buy"	=> "1000",
"img"	=> "we_bow013.png",
"atk"	=> array(25,0),
"handle"=> "2",
); break;
						//	2200-2299	편
		case "2200":
$item	= array(
"name"	=> "조련사의 채찍",
"type"	=> "Whip",
"buy"	=> "1000",
"img"	=> "we_other007.png",
"atk"	=> array(20,0),
"handle"=> "4",
"P_SUMMON"	=> "10",
"need"	=> array("6181"=>"8",),
); break;
		case "2201":
$item	= array(
"name"	=> "긴 채찍",
"type"	=> "Whip",
"buy"	=> "20000",
"img"	=> "we_other007.png",
"atk"	=> array(30,0),
"handle"=> "8",
"P_SUMMON"	=> "15",
"need"	=> array("6040"=>"4","6181"=>"12",),
); break;
		case "2202":
$item	= array(
"name"	=> "아나콘다",
"type"	=> "Whip",
"buy"	=> "30000",
"img"	=> "we_other007.png",
"atk"	=> array(40,0),
"handle"=> "12",
"P_SUMMON"	=> "20",
"need"	=> array("6040"=>"6","6181"=>"16",),
); break;
		case "2203":
$item	= array(
"name"	=> "전갈",
"type"	=> "Whip",
"buy"	=> "50000",
"img"	=> "we_other007.png",
"atk"	=> array(50,0),
"handle"=> "16",
"P_SUMMON"	=> "25",
"need"	=> array("6040"=>"12","6181"=>"24","6000"=>"24",),
); break;
// 2210 채찍
		case "2210":
$item	= array(
"name"	=> "와이어",
"type"	=> "Whip",
"buy"	=> "50000",
"img"	=> "we_other007.png",
"atk"	=> array(70,0),
"handle"=> "8",
"P_SUMMON"	=> "4",
"need"	=> array("6040"=>"4","6001"=>"24",),
); break;
		case "2211":
$item	= array(
"name"	=> "은빛 꼬리",
"type"	=> "Whip",
"buy"	=> "70000",
"img"	=> "we_other007.png",
"atk"	=> array(100,0),
"handle"=> "10",
"P_SUMMON"	=> "8",
"need"	=> array("6040"=>"12","6002"=>"32",),
); break;
//------------------------------------- 3000 방패
		case "3000":
$item	= array(
"name"	=> "나무 방패",
"type"	=> "Shield",
"buy"	=> "1000",
"img"	=> "shield_001m.png",
"def"	=> array(5,5,0,0),
"handle"=> "1",
"need"	=> array("6001"=>"1","6020"=>"4",),
); break;
		case "3001":
$item	= array(
"name"	=> "버클러",
"type"	=> "Shield",
"buy"	=> "2000",
"img"	=> "shield_001m.png",
"def"	=> array(8,8,3,3),
"handle"=> "2",
"need"	=> array("6001"=>"4","6020"=>"2",),
); break;
		case "3002":
$item	= array(
"name"	=> "철 방패",
"type"	=> "Shield",
"buy"	=> "4000",
"img"	=> "shield_001m.png",
"def"	=> array(12,5,5,5),
"handle"=> "3",
"need"	=> array("6003"=>"6",),
); break;
		case "3003":
$item	= array(
"name"	=> "카이트 실드",
"type"	=> "Shield",
"buy"	=> "5000",
"img"	=> "shield_001m.png",
"def"	=> array(5,20,10,5),
"handle"=> "3",
"need"	=> array("6001"=>"2","6002"=>"6",),
); break;
		case "3004":
$item	= array(
"name"	=> "역장 방패",
"type"	=> "Shield",
"buy"	=> "8000",
"img"	=> "shield_001m.png",
"def"	=> array(0,0,20,15),
"handle"=> "4",
"need"	=> array("6002"=>"8","6021"=>"4",),
); break;
		case "3005":
$item	= array(
"name"	=> "중형 방패",
"type"	=> "Shield",
"buy"	=> "8000",
"img"	=> "shield_001m.png",
"def"	=> array(15,10,8,8),
"handle"=> "4",
"need"	=> array("6002"=>"8","6003"=>"8"),
); break;
		case "3006":
$item	= array(
"name"	=> "원형 방패",
"type"	=> "Shield",
"buy"	=> "10000",
"img"	=> "shield_001m.png",
"def"	=> array(15,20,10,10),
"handle"=> "5",
"need"	=> array("6002"=>"4","6003"=>"16"),
); break;
		case "3007":
$item	= array(
"name"	=> "타워 실드",
"type"	=> "Shield",
"buy"	=> "15000",
"img"	=> "shield_001m.png",
"def"	=> array(18,15,15,10),
"handle"=> "6",
"need"	=> array("6002"=>"8","6003"=>"20"),
); break;
		case "3008":
$item	= array(
"name"	=> "요정 방패",
"type"	=> "Shield",
"buy"	=> "18000",
"img"	=> "shield_001m.png",
"def"	=> array(0,0,30,20),
"handle"=> "6",
"need"	=> array("6002"=>"32",),
); break;
		case "3100":	//	3100-		개
$item	= array(
"name"	=> "교본",
"type"	=> "Book",
"buy"	=> "200",
"img"	=> "book_002.png",
"atk"	=> array(0,2),
"def"	=> array(0,5,0,0),
"handle"=> "1",
); break;
		case "3101":
$item	= array(
"name"	=> "마법 사전",
"type"	=> "Book",
"buy"	=> "5000",
"img"	=> "book_002.png",
"atk"	=> array(0,5),
"def"	=> array(2,2,2,2),
"handle"=> "2",
"need"	=> array("6182"=>"28",),
); break;
		case "3102":
$item	= array(
"name"	=> "마법 노트",
"type"	=> "Book",
"buy"	=> "8000",
"img"	=> "book_002.png",
"atk"	=> array(0,7),
"def"	=> array(2,0,2,0),
"handle"=> "3",
"need"	=> array("6182"=>"28",),
); break;
		case "3103":
$item	= array(
"name"	=> "성경",
"type"	=> "Book",
"buy"	=> "10000",
"img"	=> "book_002.png",
"atk"	=> array(0,4),
"def"	=> array(0,0,8,3),
"handle"=> "3",
"need"	=> array("6182"=>"36",),
); break;
		case "3104":
$item	= array(
"name"	=> "소환사의 성서",
"type"	=> "Book",
"buy"	=> "12000",
"img"	=> "book_002.png",
"atk"	=> array(0,3),
"def"	=> array(0,0,4,5),
"handle"=> "3",
"P_SUMMON"	=> "10",
"need"	=> array("6182"=>"36",),
); break;
		case "3105":
$item	= array(
"name"	=> "세계 백과사전",
"type"	=> "Book",
"buy"	=> "20000",
"img"	=> "book_002.png",
"atk"	=> array(5,0),
"def"	=> array(10,5,7,0),
"handle"=> "5",
"need"	=> array("6182"=>"58",),
); break;
		case "5000":	//	5000-5100	 갑옷
$item	= array(
"name"	=> "가죽 갑옷",
"type"	=> "Armor",
"buy"	=> "1000",
"img"	=> "armor_016b.png",
"def"	=> array(18,15,7,0),
"handle"=> "1",
"need"	=> array("6040"=>"8"),
); break;
		case "5001":
$item	= array(
"name"	=> "비늘 갑옷",
"type"	=> "Armor",
"buy"	=> "2000",
"img"	=> "armor_016b.png",
"def"	=> array(20,15,10,5),
"handle"=> "2",
"need"	=> array("6040"=>"10","6001"=>"2",),
); break;
		case "5002":
$item	= array(
"name"	=> "링 메일",
"type"	=> "Armor",
"buy"	=> "5000",
"img"	=> "armor_016b.png",
"def"	=> array(25,15,13,10),
"handle"=> "3",
"need"	=> array("6001"=>"14",),
); break;
		case "5003":
$item	= array(
"name"	=> "체인 메일",
"type"	=> "Armor",
"buy"	=> "6000",
"img"	=> "armor_016b.png",
"def"	=> array(30,20,15,5),
"handle"=> "4",
"need"	=> array("6001"=>"16","6002"=>"2",),
); break;
		case "5004":
$item	= array(
"name"	=> "은 갑옷",
"type"	=> "Armor",
"buy"	=> "8000",
"img"	=> "armor_016b.png",
"def"	=> array(35,25,18,10),
"handle"=> "5",
"need"	=> array("6002"=>"18",),
); break;
		case "5005":
$item	= array(
"name"	=> "하프 플레이트",
"type"	=> "Armor",
"buy"	=> "10000",
"img"	=> "armor_016b.png",
"def"	=> array(15,70,24,15),
"handle"=> "5",
"need"	=> array("6002"=>"12","6003"=>"6",),
); break;
		case "5006":
$item	= array(
"name"	=> "드래곤 갑옷",
"type"	=> "Armor",
"buy"	=> "14000",
"img"	=> "armor_016b.png",
"def"	=> array(40,30,25,15),
"handle"=> "6",
); break;
		case "5007":
$item	= array(
"name"	=> "판금 갑옷",
"type"	=> "Armor",
"buy"	=> "10000",
"img"	=> "armor_016b.png",
"def"	=> array(20,100,25,20),
"handle"=> "6",
"need"	=> array("6002"=>"16","6003"=>"8",),
); break;
		case "5008":
$item	= array(
"name"	=> "스프린트 갑옷",
"type"	=> "Armor",
"buy"	=> "18000",
"img"	=> "armor_016b.png",
"def"	=> array(42,35,27,20),
"handle"=> "7",
"need"	=> array("6002"=>"24","6003"=>"10",),
); break;
		case "5009":
$item	= array(
"name"	=> "전투복",
"type"	=> "Armor",
"buy"	=> "18000",
"img"	=> "armor_016b.png",
"def"	=> array(60,40,0,0),
"handle"=> "7",
"need"	=> array("6001"=>"12","6002"=>"12","6003"=>"12",),
); break;
		case "5010":
$item	= array(
"name"	=> "플루터 갑옷",
"type"	=> "Armor",
"buy"	=> "25000",
"img"	=> "armor_016b.png",
"def"	=> array(45,35,28,20),
"handle"=> "8",
); break;
		case "5011":
$item	= array(
"name"	=> "악마 갑옷",
"type"	=> "Armor",
"buy"	=> "20000",
"img"	=> "armor_016b.png",
"def"	=> array(20,140,15,70),
"handle"=> "8",
); break;
		case "5012":
$item	= array(
"name"	=> "플레이트 코트",
"type"	=> "Armor",
"buy"	=> "25000",
"img"	=> "armor_016b.png",
"def"	=> array(47,35,28,30),
"handle"=> "9",
); break;
		case "5013":
$item	= array(
"name"	=> "금 갑옷",
"type"	=> "Armor",
"buy"	=> "40000",
"img"	=> "armor_016b.png",
"def"	=> array(50,35,30,35),
"handle"=> "10",
); break;
		case "5014":
$item	= array(
"name"	=> "백금 갑옷",
"type"	=> "Armor",
"buy"	=> "50000",
"img"	=> "armor_016b.png",
"def"	=> array(52,35,30,40),
"handle"=> "12",
); break;
		case "5015":
$item	= array(
"name"	=> "수정 갑옷",
"type"	=> "Armor",
"buy"	=> "80000",
"img"	=> "armor_016b.png",
"def"	=> array(55,35,32,45),
"handle"=> "13",
); break;
		case "5016":
$item	= array(
"name"	=> "풀 플레이트",
"type"	=> "Armor",
"buy"	=> "120000",
"img"	=> "armor_016b.png",
"def"	=> array(60,40,35,45),
"handle"=> "16",
); break;
		case "5017":
$item	= array(
"name"	=> "룬 갑옷",
"type"	=> "Armor",
"buy"	=> "20000",
"img"	=> "armor_009c.png",
"def"	=> array(15,90,35,45),
"handle"=> "5",
"need"	=> array("6005"=>"3","7000"=>"5","7001"=>"5",),
); break;
		case "5018":
$item	= array(
"name"	=> "룬 플레이트",
"type"	=> "Armor",
"buy"	=> "45000",
"img"	=> "armor_009e.png",
"def"	=> array(25,100,45,65),
"handle"=> "7",
"need"	=> array("6005"=>"5","7000"=>"10","7001"=>"10","5017"=>"1","6803"=>"1",),
); break;
		case "5100":	//	5100-5200	 코트
$item	= array(
"name"	=> "면 셔츠",
"type"	=> "Cloth",
"buy"	=> "500",
"img"	=> "armor_014e.png",
"def"	=> array(5,5,5,5),
"handle"=> "1",
"need"	=> array("6180"=>"4",),
); break;
		case "5101":
$item	= array(
"name"	=> "가죽 재킷",
"type"	=> "Cloth",
"buy"	=> "1000",
"img"	=> "armor_014e.png",
"def"	=> array(10,0,10,0),
"handle"=> "2",
"need"	=> array("6040"=>"4","6180"=>"4",),
); break;
		case "5102":
$item	= array(
"name"	=> "가벼운 재킷",
"type"	=> "Cloth",
"buy"	=> "2000",
"img"	=> "armor_014e.png",
"def"	=> array(15,5,15,5),
"handle"=> "3",
"need"	=> array("6040"=>"2","6180"=>"8",),
); break;
		case "5103":
$item	= array(
"name"	=> "긴 코트",
"type"	=> "Cloth",
"buy"	=> "5000",
"img"	=> "armor_014e.png",
"def"	=> array(18,5,18,5),
"handle"=> "4",
"need"	=> array("6040"=>"6","6180"=>"10",),
); break;
		case "5104":
$item	= array(
"name"	=> "단단한 재킷",
"type"	=> "Cloth",
"buy"	=> "9000",
"img"	=> "armor_014e.png",
"def"	=> array(23,7,23,7),
"handle"=> "5",
"need"	=> array("6040"=>"10","6180"=>"10",),
); break;
		case "5105":
$item	= array(
"name"	=> "킬트 코트",
"type"	=> "Cloth",
"buy"	=> "14000",
"img"	=> "armor_014e.png",
"def"	=> array(25,10,25,10),
"handle"=> "6",
"need"	=> array("6040"=>"4","6183"=>"12",),
); break;
		case "5106":
$item	= array(
"name"	=> "귀족 코트",
"type"	=> "Cloth",
"buy"	=> "18000",
"img"	=> "armor_014e.png",
"def"	=> array(28,12,28,12),
"handle"=> "7",
"need"	=> array("6040"=>"6","6183"=>"20",),
); break;
		case "5107":
$item	= array(
"name"	=> "군주의 코트",
"type"	=> "Cloth",
"buy"	=> "22000",
"img"	=> "armor_014e.png",
"def"	=> array(30,15,30,15),
"handle"=> "8",
"need"	=> array("6040"=>"4","6183"=>"15","6184"=>"15",),
); break;
		case "5200":	//	5200-5300 로브
$item	= array(
"name"	=> "면 로브",
"type"	=> "Robe",
"buy"	=> "1000",
"img"	=> "armor_012.png",
"def"	=> array(0,5,30,10),
"handle"=> "1",
"need"	=> array("6180"=>"4",),
); break;
		case "5201":
$item	= array(
"name"	=> "은빛 로브",
"type"	=> "Robe",
"buy"	=> "1500",
"img"	=> "armor_012.png",
"def"	=> array(2,5,35,15),
"handle"=> "2",
"need"	=> array("6002"=>"1","6180"=>"6",),
); break;
		case "5202":
$item	= array(
"name"	=> "엘프 로브",
"type"	=> "Robe",
"buy"	=> "3000",
"img"	=> "armor_012.png",
"def"	=> array(3,10,40,20),
"handle"=> "3",
"need"	=> array("6180"=>"8","6184"=>"2",),
); break;
		case "5203":
$item	= array(
"name"	=> "요정 로브",
"type"	=> "Robe",
"buy"	=> "5000",
"img"	=> "armor_012.png",
"def"	=> array(4,10,45,25),
"handle"=> "4",
"need"	=> array("6180"=>"12","6184"=>"4",),
); break;
		case "5204":
$item	= array(
"name"	=> "십자 로브",
"type"	=> "Robe",
"buy"	=> "8000",
"img"	=> "armor_012.png",
"def"	=> array(5,10,48,25),
"handle"=> "5",
"need"	=> array("6180"=>"14","6184"=>"4",),
); break;
		case "5205":
$item	= array(
"name"	=> "하얀 로브",
"type"	=> "Robe",
"buy"	=> "10000",
"img"	=> "armor_012.png",
"def"	=> array(6,10,50,25),
"handle"=> "6",
"need"	=> array("6183"=>"8","6184"=>"8",),
); break;
		case "5206":
$item	= array(
"name"	=> "성스러운 로브",
"type"	=> "Robe",
"buy"	=> "14000",
"img"	=> "armor_012.png",
"def"	=> array(7,10,52,30),
"handle"=> "7",
"need"	=> array("6183"=>"12","6184"=>"12",),
); break;
						// 5500 - 장식품
		case "5500":
$item	= array(
"name"	=> "생명의 반지",
"type"	=> "Item",
"buy"	=> "10000",
"img"	=> "acce_024.png",
"handle"=> "2",
"P_MAXHP"	=> "50",
"option"	=> "MAXHP+50, ",
); break;
		case "5501":
$item	= array(
"name"	=> "마나 반지",
"type"	=> "Item",
"buy"	=> "10000",
"img"	=> "acce_024.png",
"handle"=> "2",
"P_MAXSP"	=> "20",
"option"	=> "MAXSP+20, ",
); break;

		case "5502":
$item	= array(
"name"	=> "동전 목걸이",
"type"	=> "Item",
"buy"	=> "40000",
"img"	=> "acce_019.png",
"handle"=> "4",
"P_MAXHP"	=> "50",
"P_MAXSP"	=> "100",
"P_STR"	=> "5",
"P_INT"	=> "5",
"P_DEX"	=> "5",
"P_SPD"	=> "5",
"P_LUK"	=> "10",
"option"	=> "MAXHP+50, MAXSP+100, STR+5, INT+5, DEX+5, SPD+5, LUK+10 ,",
"need"	=> array("6160"=>"5","6161"=>"5","6162"=>"5"),
); break;

		case "5510":
$item	= array(
"name"	=> "힘의 반지",
"type"	=> "Item",
"buy"	=> "10000",
"img"	=> "acce_024.png",
"handle"=> "3",
"P_STR"	=> "30",
"option"	=> "STR+30, ",
); break;
		case "5515":
$item	= array(
"name"	=> "지능의 반지",
"type"	=> "Item",
"buy"	=> "10000",
"img"	=> "acce_024.png",
"handle"=> "3",
"P_INT"	=> "30",
"option"	=> "INT+30, ",
); break;
		case "5520":
$item	= array(
"name"	=> "재치의 반지",
"type"	=> "Item",
"buy"	=> "10000",
"img"	=> "acce_024.png",
"handle"=> "3",
"P_DEX"	=> "30",
"option"	=> "DEX+30, ",
); break;
		case "5525":
$item	= array(
"name"	=> "속도의 반지",
"type"	=> "Item",
"buy"	=> "10000",
"img"	=> "acce_024.png",
"handle"=> "2",
"P_SPD"	=> "10",
"option"	=> "SPD+10, ",
); break;
		case "5530":
$item	= array(
"name"	=> "행운의 반지",
"type"	=> "Item",
"buy"	=> "10000",
"img"	=> "acce_024.png",
"handle"=> "3",
"P_LUK"	=> "30",
"option"	=> "LUK+30, ",
); break;



		case "5600":
$item	= array(
"name"	=> "광전사의 반지",
"type"	=> "Item",
"buy"	=> "10000",
"img"	=> "acce_024.png",
"handle"=> "2",
"P_STR"	=> "100",
"M_MAXHP"	=> "-50",
"option"	=> "STR+100, HP-50% ,",
); break;
						// 6000	-	소재계
		case "6000"://석계
$item	= array(
"name"	=> "돌",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "5",
"img"	=> "item_009z.png",
); break;
		case "6001":
$item	= array(
"name"	=> "강철",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "mat_001.png",
); break;
		case "6002":
$item	= array(
"name"	=> "은",
"type"	=> "Material",
"buy"	=> "50000",
"sell"	=> "250",
"img"	=> "mat_002.png",
); break;
		case "6003":
$item	= array(
"name"	=> "철",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "30",
"img"	=> "mat_001.png",
); break;

						// 6020-목재
		case "6020":
$item	= array(
"name"	=> "목재",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "20",
"img"	=> "mat_025.png",
); break;
		case "6021":
$item	= array(
"name"	=> "참나무",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "30",
"img"	=> "mat_025.png",
); break;
		case "6022":
$item	= array(
"name"	=> "편백나무",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "40",
"img"	=> "mat_025.png",
); break;
		case "6040"://6040-가죽
$item	= array(
"name"	=> "가죽",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "mat_024.png",
); break;
		case "6041":
$item	= array(
"name"	=> "뱀 가죽",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "mat_024.png",
); break;
		case "6060"://6060-뼈
$item	= array(
"name"	=> "",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "mat_016.png",
); break;
		case "6080"://6080-송곳니
$item	= array(
"name"	=> "",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "mat_013.png",
); break;
		case "6100"://6100-마리
$item	= array(
"name"	=> "",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "20",
"img"	=> "mat_008.png",
); break;
		case "6120"://6120-보석
$item	= array(
"name"	=> "다이아몬드",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "100",
"img"	=> "gem_02.png",
); break;
		case "6140"://6140-음
$item	= array(
"name"	=> "소란스러운 소리",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "other_007.png",
); break;
		case "6160"://6160-코인
$item	= array(
"name"	=> "금화",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "500",
"img"	=> "acce_005.png",
); break;
		case "6161":
$item	= array(
"name"	=> "은화",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "250",
"img"	=> "acce_005b.png",
); break;
		case "6162":
$item	= array(
"name"	=> "동화",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "100",
"img"	=> "acce_005c.png",
); break;
						//6180 - 실, 섬유
		case "6180":
$item	= array(
"name"	=> "면",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "other_008.png",
); break;
		case "6181":
$item	= array(
"name"	=> "덩굴",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "other_008.png",
); break;
		case "6182":
$item	= array(
"name"	=> "삼베",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "other_008.png",
); break;
		case "6183":
$item	= array(
"name"	=> "양모",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "other_008.png",
); break;
		case "6184":
$item	= array(
"name"	=> "비단",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "other_008.png",
); break;
		case "6200"://6200 - 음
$item	= array(
"name"	=> "소란스러운 소리",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "other_007.png",
); break;
		case "6600"://6600 - 쓰레기
$item	= array(
"name"	=> "바나나",
"type"	=> "Material",
"buy"	=> "100",
"sell"	=> "50",
"img"	=> "banana.png",
); break;
		case "6601":
$item	= array(
"name"	=> "황금 바나나",
"type"	=> "Material",
"buy"	=> "100",
"sell"	=> "5000",
"img"	=> "banana.png",
); break;
		case "6602":
$item	= array(
"name"	=> "바나나 금속",
"type"	=> "Material",
"buy"	=> "100",
"sell"	=> "50",
"img"	=> "banana.png",
); break;
		case "6800"://6800 - 레어
$item	= array(
"name"	=> "드래곤 이빨",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "mat_013.png",
); break;
		case "6801":
$item	= array(
"name"	=> "드래곤 윙",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "mat_011.png",
); break;
		case "6802":
$item	= array(
"name"	=> "부러진 검",
"type"	=> "Material",
"buy"	=> "1000",
"sell"	=> "10",
"img"	=> "we_sword026.png",
); break;
						// 제작 강화계
		case "7000":
$item	= array(
"name"	=> "힘의 구슬",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_019.png",
"Add"	=> "X00",
); break;
		case "7001":
$item	= array(
"name"	=> "마법 구슬",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_019.png",
"Add"	=> "X01",
); break;

						//몬스터 드랍
		case "7100":
$item	= array(
"name"	=> "고블린의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "M01",
); break;
		case "7101":
$item	= array(
"name"	=> "박쥐의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7102":
$item	= array(
"name"	=> "스켈레톤 전사의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7103":
$item	= array(
"name"	=> "스켈레톤 병사의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7104":
$item	= array(
"name"	=> "스켈레톤 궁수의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7105":
$item	= array(
"name"	=> "해골 주술사의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7106":
$item	= array(
"name"	=> "사이클롭스의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7107":
$item	= array(
"name"	=> "고블린 대장장이의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7108":
$item	= array(
"name"	=> "미믹 몬스터의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7109":
$item	= array(
"name"	=> "스켈레톤 대장의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7110":
$item	= array(
"name"	=> "사악한 마법사의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7111":
$item	= array(
"name"	=> "게이즈의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7112":
$item	= array(
"name"	=> "사악한 하인의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7113":
$item	= array(
"name"	=> "켄타우로스 사냥꾼의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7114":
$item	= array(
"name"	=> "켄타우로스 기사의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7115":
$item	= array(
"name"	=> "바포메트의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
		case "7116":
$item	= array(
"name"	=> "군주 바포메트의 눈물",
"type"	=> "Material",
"buy"	=> "3000",
"sell"	=> "100",
"img"	=> "item_018.png",
"Add"	=> "",
); break;
//------------------------------ 7500 외 소모품
		case "7500":
$item	= array(
"name"	=> "이름 변경 카드",
"type"	=> "Other",
"buy"	=> "5000",
"sell"	=> "100",
"img"	=> "item_035z.png",
); break;
		case "7510":
$item	= array(
"name"	=> "초기화 수정(스탯1)",
"type"	=> "Other",
"buy"	=> "500000",
"sell"	=> "100",
"img"	=> "gem_03.png",
); break;
		case "7511":
$item	= array(
"name"	=> "초기화 수정(스탯30)",
"type"	=> "Other",
"buy"	=> "500000",
"sell"	=> "100",
"img"	=> "gem_03.png",
); break;
		case "7512":
$item	= array(
"name"	=> "초기화 수정(스탯50)",
"type"	=> "Other",
"buy"	=> "500000",
"sell"	=> "100",
"img"	=> "gem_03.png",
); break;
		case "7513":
$item	= array(
"name"	=> "초기화 수정(스탯100)",
"type"	=> "Other",
"buy"	=> "100000",
"sell"	=> "100",
"img"	=> "gem_03.png",
); break;
		case "7520":
$item	= array(
"name"	=> "초기화 수정(스킬)",
"type"	=> "Other",
"buy"	=> "500000",
"sell"	=> "100",
"img"	=> "gem_03.png",
); break;
//------------------------------ 8000 지도, 열쇠
		case "8000":
$item	= array(
"name"	=> "고대 동굴",
"type"	=> "Map",
"buy"	=> "5000",
"sell"	=> "100",
"img"	=> "book_003.png",
); break;
		case "8001":
$item	= array(
"name"	=> "고대 동굴 B2",
"type"	=> "Key",
"buy"	=> "5000",
"sell"	=> "100",
"img"	=> "item_032.png",
); break;
		case "8002":
$item	= array(
"name"	=> "고대 동굴 B3",
"type"	=> "Key",
"buy"	=> "5000",
"sell"	=> "100",
"img"	=> "item_032.png",
); break;
		case "8003":
$item	= array(
"name"	=> "고대 동굴 B4",
"type"	=> "Key",
"buy"	=> "5000",
"sell"	=> "100",
"img"	=> "item_032.png",
); break;
		case "8004":
$item	= array(
"name"	=> "고대 동굴 B5",
"type"	=> "Key",
"buy"	=> "5000",
"sell"	=> "100",
"img"	=> "item_032.png",
); break;
		case "8009":
$item	= array(
"name"	=> "테키토 산",
"type"	=> "Map",
"buy"	=> "500",
"sell"	=> "100",
"img"	=> "book_003.png",
); break;
		case "8010":
$item	= array(
"name"	=> "깊은 곳으로 가는 지도(대충산)",
"type"	=> "Map",
"buy"	=> "5000",
"sell"	=> "100",
"img"	=> "book_003.png",
); break;
		case "8011":
$item	= array(
"name"	=> "정상으로 가는 지도(대충산)",
"type"	=> "Map",
"buy"	=> "5000",
"sell"	=> "100",
"img"	=> "book_003.png",
); break;
						// 9000 - 그 외
		case "9000":
$item	= array(
"name"	=> "경매 회원 카드",
"type"	=> "Special",
"buy"	=> "9999",
"sell"	=> "100",
"img"	=> "item_035.png",
); break;


		default:
			return false;
	}

	// 추가 변수
	$item["no"]	= $no;
	$item["base_name"]	= $item["name"];
	switch($item["type"]) {
		case "Sword":
		case "TwoHandSword":
		case "Dagger":
		case "Wand":
		case "Staff":
		case "Bow":
		case "Whip":
			$item["type2"]	= "WEAPON";
			break;
		case "Shield":
		case "Book":
		case "Armor":
		case "Cloth":
		case "Robe":
			$item["type2"]	= "GUARD";
			break;
		default:
			$item["type2"]	= "OTHER";
			break;
	}

	// 정련치
	if($refine) {
		$item["refine"]	= $refine;
		$item["name"]	= "+".$refine." ".$item["name"];
		//$item["name"]	.= "+".$refine;
		//$RefineRate	= 1 + 0.5 * ($refine/10);
		if(isset($item["atk"]["0"])) {
			//$item["atk"]["0"]	= ceil($item["atk"]["0"] * $RefineRate);// 단순식
			// 1.05*1.05*1.05....
			/*
			for($i=0; $i<$refine; $i++) {
				$item["atk"]["0"]	*= 1.05;
			}
			*/
			$item["atk"]["0"]	*= ( 1 + ($refine*$refine)/100 );
			$item["atk"]["0"]	= ceil($item["atk"]["0"]);
		}
		if(isset($item["atk"]["1"])) {
			//$item["atk"]["1"]	= ceil($item["atk"]["1"] * $RefineRate);
			/*
			for($i=0; $i<$refine; $i++) {
				$item["atk"]["1"]	*= 1.05;
			}
			*/
			$item["atk"]["1"]	*= ( 1 + ($refine*$refine)/100 );
			$item["atk"]["1"]	= ceil($item["atk"]["1"]);
		}
		// 방어구의 값강화
		$RefineRate	= 1 + 0.3 * ($refine/10);
		if(isset($item["def"]["0"]))
			$item["def"]["0"]	= ceil($item["def"]["0"] * $RefineRate);
		if(isset($item["def"]["1"]))
			$item["def"]["1"]	= ceil($item["def"]["1"] * $RefineRate);
		if(isset($item["def"]["2"]))
			$item["def"]["2"]	= ceil($item["def"]["2"] * $RefineRate);
		if(isset($item["def"]["3"]))
			$item["def"]["3"]	= ceil($item["def"]["3"] * $RefineRate);
			
	}
	// 부가 능력
	if($option0)
		AddEnchantData($item,$option0);
	if($option1)
		AddEnchantData($item,$option1);
	if($option2)
		AddEnchantData($item,$option2);

	return $item;
}
?>
