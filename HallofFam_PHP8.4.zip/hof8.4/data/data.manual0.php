<div style="margin:15px">
<!-- ---------------------------------------------------------------- -->
<a name="content"></a>
<h4>목차</h4>
<ul>
<li><a href="#caution">주의!</a></li>
<li><a href="#rule">룰(무엇을 해야 하는가)</a></li>
<li><a href="#menu">메뉴</a></li>
<li><a href="#btl">전투의 흐름에 대해</a></li>
<li><a href="#char">캐릭터 설정에 대해</a></li>
<li><a href="#charstat">캐릭터의 기본적인 능력치에 대해</a></li>
<li><a href="#statup">능력치의 상승</a></li>
<li><a href="#jdg">캐릭터의 전투중 지시설정에 대해</a></li>
<li><a href="#posi">캐릭터의 위치관계와 후열을 지키기</a></li>
<li><a href="#equip">캐릭터의 장비</a></li>
<li><a href="#skill">캐릭터의 기술</a></li>
<li><a href="#elem">공격의 속성</a></li>
<li><a href="#state">캐릭터의 상태</a></li>
<li><a href="#jobchange">전직(직업체인지)</a></li>
<li><a href="#sacrier">Sacrier의 공격방법에 대해</a></li>
<li><a href="#ranking">랭킹</a></li>
<li><a href="?manual2">고수용 메뉴얼</a></li>
<li><a href="#cr">사용한 그림</a></li>
</ul>
<a name="caution"></a>
<h4 name="caution">caution! <a href="#content">↑</a></h4>
<p class="error" style="margin-left:50px;font-size:200%">
존나 귀찮다. 웬만하면 아이디 만들면 뜨는 <br /><a href="?tutorial" class="a0">튜토리얼</a>만 보고 해라.</p>
<p class="error" style="margin-left:50px">이 게임은 제작중이다.</p>
<p class="error" style="margin-left:50px">※이 게임은 썩었어.<br />
그냥 뭐라 할거 없이 끝장이다</p>
<p class="error" style="margin-left:50px">게임 밸런스는 기대하지 마라</p>
<p class="error" style="margin-left:50px">이 게임은,<br />
일본어 이외의 언어(한국어, 더러운 영어)가 침범하고 있다..</p>
<p class="error" style="margin-left:50px">어느 날 숲의 데이터가 날아가버릴지도 모른다.</p>
<p style="margin-left:50px">데이터는 보장되지 않아.<br />
갑자기, 변경이 되어버릴지도...<br />
제물.<br />
무료.</p>

<p>
■ 게임의 관리체계에 대해
</p><p>
기본적으로 관리는 하지 않는다.<br />
데이터가 날아가도 복구 안해준다.
</p><p>
뭔가의 버그로 오작동을 일으켜서<br />
데이터가 날아가도 복구같은건 안해준다.
</p><p>
■ 게임의 밸런스가 무너졌을 경우
</p><p>
무너진 원인을 고치려고는 하겠지만, 그것 뿐이다.<br />
밸런스가 무너진 데이터나 상황은 건드리지 않을꺼야.
</p><p>
■ 혼자서 복수의 계정을 사용하는 경우
</p><p>
네 꼴리는대로
</p><p>
■ 게임의 매너에 대해서<br />
소지한 복수의 계정에서 특정 계정으로 <br />
돈이나 아이템 몰아주기는 금지<br />
대처는 하겠지만 그만둬 주세요.
</p><p>
폭언, 비열한 말투에 대해선 딱히 건드리진 않는다.
마음대로 싸워라.
</p>

<!-- ---------------------------------------------------------------- -->
<a name="rule"></a>
<h4>룰(Rule) <a href="#content">↑</a></h4>
<p style="margin-left:50px">게임의 목적은,<br />
언젠가 이룰 날이 올 랭킹1위가 되는 것.<br />
또한, 1위를 지켜내는 것.<br />
모험적인 요소 따윈 없다.</p>
<p style="margin-left:50px">1-5명의 파티를 스스로 편성하여 싸우게하고,<br />
랭킹을 올린다.</p>
<p style="margin-left:50px">랭킹 1위가 되기 위해서<br />
적(몬스터)과 싸워서 캐릭터를 키운다.<br />
적(몬스터)과 싸워서 강한 아이템을 모은다.<br />
이러한 과정을 즐겨주면 충분하다.<br />
랭킹에서 싸울 상대는 다른 유저들.</p>
<p style="margin-left:50px">각 캐릭터는 기술의 사용조건을 상세하게 설정할 수 있도록 만들었다.<br />
하지만 그 결과, 미칠듯이 귀찮은 게임이 되어버렸다.</p>
<p class="bold u" style="margin-left:50px">※랭킹은 현재 확인이 가능하다.</p>
<!-- ---------------------------------------------------------------- -->
<a name="menu"></a>
<h4>메뉴(Menu) <a href="#content">↑</a></h4>
<img src="./image/manual/003.gif">
<p><span class="u bold">로그인 후에 이하와 같은 메뉴가 표시된다</span>
<ul>
<li><span class="bold">Top</span> - 소지 캐릭터 일람이 표시된다</li>
<li><span class="bold">전투(Hunt)</span> - 몬스터와의 전투</li>
<li><span class="bold">아이템(Item)</span> - 소지 아이템 목록을 본다</li>
<li><span class="bold">가게(Shop)</span> - 가게에서 물건을 구입할 수 있다. 아르바이트도 가능</li>
<li><span class="bold">랭크(Rank)</span> - 랭킹</li>
<li><span class="bold">고용(Recruit)</span> - 새로운 캐릭터 고용</li>
<li><span class="bold">설정(Setting)</span> - 각종설정, 로그아웃, 계정삭제.</li>
<li><span class="bold">로그(Log)</span> - 과거의 전투 로그를 본다.</li>
</ul></p>
<p>그리고,<span class="u bold">메뉴 하단에</span>
<ul>
<li /><span class="bold">팀명</span> - 이름이다
<li /><span class="bold">자금(Funds)</span> - 당연히 돈이다.
<li /><span class="bold">시간(Time)</span> - 시간이다. 전투나 알바를 하면 소모. 시간이 지나면 충전된다.
</ul></p>
<a name="btl"></a>
<!-- ---------------------------------------------------------------- -->
<h4>전투의 흐름에 대해 <a href="#content">↑</a></h4>
<div style="margin-left:50px">
<div class="error">※이 항목은 개발자의 입이 제대로 돌아가지 않아<br />
설명이 매우 어렵습니다.</div>
<p>전투는 한번 시작하면 싸움이 끝나는 부분까지 한번에 처리된다.<br />
전투 도중에 유저가 행동을 선택하는 일은 없다</p>
1. 캐릭터의 스테이터스에 따라서 각 캐릭터가 순서대로 행동한다.
<div class="bold" style="margin-left:30px">↓↓↓</div>
2. 캐릭터에게 미리 설정되어 있는 지시에 따라서 캐릭터가 행동한다.
<div class="bold" style="margin-left:30px">↓↓↓</div>
3. ( 1과 2의 반복 )
<div class="bold" style="margin-left:30px">↓↓↓</div>
4. 어느 정도 전투가 진행되고, 전투 종료조건을 만족할 경우 싸움이 끝난다.
<p><span class="bold u">종료조건</span><br />
1.어느 쪽의 캐릭터가 모두 전투불능이 된다.<br />
2.합계 <?=BATTLE_MAX_TURNS?>회의 턴이 지났지만 결판이 나지 않았을 때 무승부가 된다.</p>
<p>나중에 바뀔지도 모르겠다.</p>
</div>
<!-- ---------------------------------------------------------------- -->
<a name="char"></a>
<h4>캐릭터의 설정에 대해 <a href="#content">↑</a></h4>
<p style="margin-left:50px">로그인 후, TOP 화면의 그림을 클릭하면<br />
그 캐릭터의 스테이터스 화면이 표시된다.<br />
<img src="./image/manual/001.gif"><br />
이하의 항목에서 자세한 설정내용을 설명</p>
<!-- ---------------------------------------------------------------- -->
<a name="charstat"></a>
<h4>캐릭터의 기본적인 능력치에 대해서 <a href="#content">↑</a></h4>
<p style="margin-left:50px">
<img src="./image/manual/002.gif">
<ul>
<li /><span class="bold">Exp</span> : 다음 레벨업 까지의 경험치
<li /><span class="bold">MaxHP</span> : 최대 체력, 0이 되면 전투중에 쓰러진다.
<li /><span class="bold">MaxSP</span> : 기술을 썼을때 소모되는 그거
<li /><span class="bold">Str</span> : 힘, 최대 HP와 물리 공격력에 영향을 준다.
<li /><span class="bold">Int</span> : 지력, 최대 SP와 마법의 위력 등에 영향.
<li /><span class="bold">Dex</span> : 손재주, 장비의 선택 폭이 넓어진다. 궁수 계열 공격의 위력이 올라간다.
<li /><span class="bold">Spd</span> : 민첩함, 이게 높으면 전투중에 많이 행동한다. 순서가 돌아오는 간격이 짧아진다.
<li /><span class="bold">Luk</span> : 운, 소환수가 강화된다.
</ul>
</p>
<!-- ---------------------------------------------------------------- -->
<a name="statup"></a>
<h4>능력치 상승 <a href="#content">↑</a></h4>
<p style="margin-left:50px">캐릭터가 전투에서 경험을 축적하여 <span class="u">레벨업</span> 했을 때<br />
어느정도의 포인트를 받아, 그것을 소비하여 각 스테이터스를 자유롭게 올린다.</p>
<!-- ---------------------------------------------------------------- -->
<a name="jdg"></a>
<h4>캐릭터의 전투중 지시설정에 대해서 <a href="#content">↑</a></h4>
<div class="error" style="margin-left:50px">※이 항목도 개발자의 입이 제대로 돌아가지 않아<br />
설명이 매우 어렵습니다.</div>
<p style="margin-left:50px">기본적으로 캐릭터는 전투중에<br />
유저가 설정한 지시에 따라서 행동할 것이다.(아마도)</p>
<div style="margin-left:50px">
<table cellspacing="5"><tbody>
<tr><td class="bold">No</td><td style="text-align:center" class="bold">判定</td>
<td style="text-align:center" class="bold">使う技</td></tr>
<tr><td>1</td><td>
<select>
<option>반드시</option>
<option>자신의 HP가 50%이상 있을 때</option>
<option>자신의 HP가 50%이하 있을 때</option>
<option>아군의 HP가 50%이하 있는 캐릭터가 있을 때</option>
<option>아군의 평균 HP가 50% 이상일 때</option>
<option>아군의 평균 HP가 50% 이하일 때</option>
<option>자신의 SP가 50% 이상 있을 때</option>
<option>자신의 SP가 50% 이하 있을 때</option>
<option>50%의 확률로</option>
<option selected>첫턴행동시</option>
<option>2턴 행동시</option>
<option>3턴 행동시</option>
<option>1번은 반드시</option>
<option>2번은 반드시</option>
<option>3번은 반드시</option>
</select>
</td><td>
<select>
<option>기술1</option>
<option>기술2</option>
<option selected>기술3</option>
<option>회복마법</option>
<option>아이템을 사용한다</option>
</select>
</td></tr><tr><td>2</td><td>
<select>
<option>반드시</option>
<option>자신의 HP가 50%이상 있을 때</option>
<option>자신의 HP가 50%이하 있을 때</option>
<option>아군의 HP가 50%이하 있는 캐릭터가 있을 때</option>
<option>아군의 평균 HP가 50% 이상일 때</option>
<option>아군의 평균 HP가 50% 이하일 때</option>
<option selected>자신의 SP가 50% 이상 있을 때</option>
<option>자신의 SP가 50% 이하 있을 때</option>
<option>50%의 확률로</option>
<option>첫턴행동시</option>
<option>2턴 행동시</option>
<option>3턴 행동시</option>
<option>1번은 반드시</option>
<option>2번은 반드시</option>
<option>3번은 반드시</option>
</select>
</td><td>
<select>
<option>기술1</option>
<option selected>기술2</option>
<option>기술3</option>
<option>회복마법</option>
<option>아이템을 사용한다</option>
</select>
</td></tr><tr><td>3</td><td>
<select>
<option selected>반드시</option>
<option>자신의 HP가 50%이상 있을 때</option>
<option>자신의 HP가 50%이하 있을 때</option>
<option>아군의 HP가 50%이하 있는 캐릭터가 있을 때</option>
<option>아군의 평균 HP가 50% 이상일 때</option>
<option>아군의 평균 HP가 50% 이하일 때</option>
<option>자신의 SP가 50% 이상 있을 때</option>
<option>자신의 SP가 50% 이하 있을 때</option>
<option>50%의 확률로</option>
<option>첫턴행동시</option>
<option>2턴 행동시</option>
<option>3턴 행동시</option>
<option>1번은 반드시</option>
<option>2번은 반드시</option>
<option>3번은 반드시</option>
</select>
</td><td>
<select>
<option selected>기술1</option>
<option>기술2</option>
<option>기술3</option>
<option>회복마법</option>
<option>아이템을 사용한다</option>
</select>
</td></tr></tbody></table>
</div>
<p style="margin-left:50px">전투중의 지시 설정 예.<br />
캐릭터의 행동순서가 돌아 올 때마다, <br />
<span class="bold">No</span> 의 낮은 숫자로부터 순서대로  <span class="bold">판정</span> 되어,<br />
그 판정에 부합되는 경우 <span class="bold">기술</span> 이 사용된다.<br />
순번이 돌아올 때마다 전투의 상황이 변화하니, 그 상황에 맞추어 행동할 거다(아마도)</p>
<div style="margin-left:50px">
<table><tbody>
<tr><td>"첫턴행동시"</td><td>"기술3"</td></tr>
<tr><td>"자신의 SP가 50%이상 있을 때"</td><td>"기술2"</td></tr>
<tr><td>"반드시"</td><td>"기술1"</td></tr>
</tbody></table>
</div>
<p style="margin-left:50px">이런 설정이라면,<br />
그 캐릭터가 처음에 행동을 할 때에는 기술 3을 사용하겠지?<br />
2턴째 이후의 행동에서 SP가 50% 이상일 때에는 기술 2를,<br />
SP가 49% 이하라면 기술1을 쓸꺼라고 생각해.</p>
<p style="margin-left:50px">또, 조건을 설정하는 숫자는 캐릭터의 <span class="bold">Int</span> 에 따라서 늘어난다 (No가 증가한다)<br />
조건의 종류는 그냥 뜨는 그게 전부다.(메뉴얼에서는 몇개인가 생략했다)</p>
<!-- ---------------------------------------------------------------- -->
<a name="posi"></a>
<h4>캐릭터의 위치관계와 후방을 지키기 <a href="#content">↑</a></h4>
<table><tbody>
<tr><td style="text-align:right">배치:</td>
<td><input class="vcent" type="radio" checked name="position">전방(Front)</td>
</tr><tr><td></td>
<td><input class="vcent" type="radio" name="position">후방(Backs)</td>
</tr><tr><td>후위의 지키는 방법 :</td><td>
<select>
<option>반드시</option>
<option>지키지 않는다</option>
<option>자신의 체력이 25% 이상이라면</option>
<option>자신의 체력이 50% 이상이라면</option>
<option>자신의 체력이 75% 이상이라면</option>
<option>25%의 확률로</option>
<option>50%의 확률로</option>
<option>75%의 확률로</option>
</select>
</td></tr></tbody></table>
<p>캐릭터가 전투시, 전방이란 후방인가를 정한다.<br />
전방의 캐릭터일 경우,<br />
전투시에 적이 아군의 후방을 공격했을 때<br />
수비하는 조건이 맞아들어갔다면,<br />
캐릭터가 대신 공격을 맞는다.</p>
<!-- ---------------------------------------------------------------- -->
<a name="equip"></a>
<h4>캐릭터의 장비 <a href="#content">↑</a></h4>
<p>스테이터스 화면에서는 현재의 장비와, 장비가능한 종류의 아이템을 표시한다.</p>
<p>각 장비와 캐릭터에는 <span class="charge">handle</span> 이라는 수치가 설정되어 있고, <br />
캐릭터가 지닌 <span class="charge">handle</span>상한치를, 장비의 합계 <span class="charge">handle</span>이 넘어설 수가 없다.
<br />
장비를 제한하기 위한 수치니까. dex와 레벨이 오르면 <span class="charge">handle</span>의 상한치가 올라간다.</p>
<?php
	$sample	= array(1000,1700,5000);
	foreach($sample as $val) {
		include_once(DATA_ITEM);
		ShowItemDetail(LoadItemData($val));
		print("<br />\n");
	}
?>
<p><ul>
<li><span class="dmg">Atk</span> - 물리공격력</li>
<li><span class="spdmg">Matk</span> - 마법공격력</li>
<li><span class="recover">Def</span> - 물리방어</li>
<li><span class="support">Mdef</span> - 마법방어</li>
<li><span class="charge">h:</span> - 이게 handle</li>
</ul></p>
<!-- ---------------------------------------------------------------- -->
<a name="skill"></a>
<h4>캐릭터의 기술 <a href="#content">↑</a></h4>
<?php
	$sample	= array(1000,1001,1002,2300,3000,3110);
	foreach($sample as $val) {
		include_once(DATA_SKILL);
		ShowSkillDetail(LoadSkillData($val));
		print("<br />\n");
	}
?>
<p>(이미지) 기술의 이름 / 대상 - 선택 / 소비 SP / 위력%x회수 / (준비:대기 시간) ... ... ...</p>
<ul>
<p><li><span class="bold">대상</span> - 기술이 영향을 끼치는 대상<br />
<span class="dmg">enemy</span> - 적<br />
<span class="recover">friend</span> - 아군<br />
<span class="support">self</span> - 사용자<br />
<span class="charge">all</span> - 적과 아군(전체)</li>
<li><span class="bold">선택</span> - <span class="u">대상</span> 중에서 누구에게 기술을 사용하는가<br />
<span class="recover">individual</span> - 개인에게<br />
<span class="spdmg">multi</span> - (랜덤하게)여러명<br />
<span class="charge">all</span> - 대상 전원</li>
<li><span class="bold">소비SP</span> - 기술 사용시에 소비되는 SP. 부족하면 실패한다</li>
<li><span class="bold">위력</span> - 기술의 강력함</li>
<li><span class="bold">횟수</span> - 기술의 실행횟수。<br />
100%x2 라면, 합계로 200% 의 위력。</li>
<li>(<span class="bold">준비</span>:<span class="bold">대기시간</span>)<br />
기술을 발동시키기 까지늬 시간. (사용예:<span class="charge">○○○ start charging.</span>)<br />
그리고, 발동 후에 경직되는 시간.<br />
숫자가 클 수록 시간이 길어진다.<br /></li>
<li><span class="bold">그밖에</span><br />
<span class="spdmg">Magic</span> - 마법을 사용하는 기술, 위력이나 효과에 int가 영향을 받는다<br />
<span class="charge">invalid</span> - 상대의 전방의 적에게 막히지 않는다<br />
<span class="support">BackAttack</span> - 후방(Back)의 캐릭터를 우선적 공격대상으로 한다.</li>
</ul></p>
<p>그리고, 레벨이 오를 때에 기술을 습득하기 위한<br />
포인트를 받을 수 있으니<br />
그것을 소비해서 새로운 기술을 익힐 수 있다.</p>
<!-- ---------------------------------------------------------------- -->
<a name="elem"></a>
<h4>공격의 속성에 대해서<a href="#content">↑</a></h4>
<p>화염 같은 적은 물에 약하다던가<br />
그런 설정따윈 없다.</p>
<p>물리니, 마법이니, 요 두가지가 전부.</p>
<!-- ---------------------------------------------------------------- -->
<a name="state"></a>
<h4>캐릭터의 상태에 대해서 <a href="#content">↑</a></h4>
<ul>
<li><span class="recover">생존</span> - HP가 1 이상인 상태.</li>
<li><span class="dmg">사망</span> - HP가 0이 된 상태.</li>
<li><span class="spdmg">맹독</span> - 행동할 때 마다 <span class="u">최대 HP와 레벨에 비례한 데미지</span>를 받는다. 독 데미지로는 죽진 않아</li>
</ul>
<!-- ---------------------------------------------------------------- -->
<a name="jobchange"></a>
<h4>전직(직업체인지) <a href="#content">↑</a></h4>
<p>전직조건을 채우면 캐릭터 스테이터스 화면 가장 아래에 표시될지도?</p>
<!-- ---------------------------------------------------------------- -->
<a name="sacrier"></a>
<h4>Sacrier의 공격방법에 대해서 <a href="#content">↑</a></h4>
<p style="margin:15px">
<img src="<?=IMG_CHAR?>mon_100r.gif">
<img src="<?=IMG_CHAR?>mon_012.gif"><br />
Sacrier의 기술 대부분은 HP를 소모한다.<br />
캐릭터가<span class="bold u">후방</span>에 있을 경우에는 HP 소비가 <span class="bold u">2배</span>가 된다.</p>
<!-- ---------------------------------------------------------------- -->
<a name="ranking"></a>
<h4>랭킹 <a href="#content">↑</a></h4>
<p>
랭킹은<br />
<img src="<?=IMG_ICON?>crown01.png" class="vcent">1위 1명<br />
<img src="<?=IMG_ICON?>crown02.png" class="vcent">2위 2명<br />
<img src="<?=IMG_ICON?>crown03.png" class="vcent">3위 3명<br />
4위 이하 3명<br />
...<br />
이렇게 동일 순위에 여러명 존재하도록 최종적으로 바꾸었다.(2008/01/27)<br />
도전하면 랭크 1위부터 랜덤하게 선택된 사람과 대전하고,<br />
승리하면 상대와 순위가 바뀐다.<br />
편집(2008/01/27)</p>
<!-- ---------------------------------------------------------------- -->
<a name="cr"></a>
<h4>사용하기를 허락해준 그림.. <a href="#content">↑</a></h4>
<p><a href="http://whitecafe.sakura.ne.jp/">Whitecat님</a> - 무기와 기술의 그림 등<br />
<a href="http://www.geocities.co.jp/Milano-Cat/3319/">Rド님</a> - 캐릭터 그림 등</p>
</div>