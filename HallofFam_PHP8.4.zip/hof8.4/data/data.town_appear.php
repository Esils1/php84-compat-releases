<?php
// 뮠궳궋궚귡밲궴궔궻뢯뙸륆뙊궴궔...
// 볷븊빶궳궋궚귡뤾룋귩빾궑귢귡궴궔갂
// 궇귡귺귽긡?궕궶궋궴뛱궚궶궋궴궔궳궖귡
// 빶긲?귽깑궸궥귡뷠뾴궕궇궯궫궻궔궵궎궔뷊뼪
function TownAppear($user) {
	$place	= array();

	// 뼰륆뙊궳뛱궚귡
	$place["Shop"]	= true;
	$place["Recruit"]	= true;
	$place["Smithy"]	= true;
	$place["Auction"]	= true;
	$place["Colosseum"]	= true;

	// 벫믦궻귺귽긡?궕궶궋궴뛱궚궶궋?먠
	//if($user->item[****])
	//	$place["****"]	= true;

	return $place;
}
?>