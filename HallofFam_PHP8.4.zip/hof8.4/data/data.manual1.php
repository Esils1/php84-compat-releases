<?php 
	if(!function_exists("LoadSkillData"))
		include(DATA_SKILL);
?>
<div style="margin:15px">
<!-- ---------------------------------------------------------------- -->
<a name="content"></a>
<h4>목차</h4>
<ul>
<li><a href="#mj">행동의 다중설정에 대해</a></li>
<li><a href="#twenty">약 20%의 확율을 만들자</a></li>
<li><a href="#def">방어력의 수치에 대해</a></li>
<li><a href="#res">약점속성과 상태이상이 적은 이유</a></li>
</ul>
<!-- ---------------------------------------------------------------- -->
<a name="mj"></a>
<h4>행동의 다중설정에 대해<a href="#content">↑</a></h4>
<div style="margin:0 20px">
<p>"think over" 라는 스킬을 습득하면 <br />
조건에 따른 다중설정이 가능해진다.</p>
<p><img src="./image/char/mon_079.gif" class="vcent">전사 계열의 경우라면...<img src="./image/char/mon_080r.gif" class="vcent"></p>
<table cellspacing="5">
<tbody>
<tr>
<td>1</td>
<td>
<select>
<option>반드시</option>
<option selected>자신의 HP가 50%이상일 때</option>
<option>자신의 SP가 20% 이상일 때</option>
<option>자신의 SP가 30% 이상일 때</option>
<option>첫턴행동시</option>
</select>
</td>
<td>
<select>
<option>Attack</option>
<option>Bash</option>
<option>RagingBlow</option>
<option>Reinforce</option>
<option>SelfRecovery</option>
<option selected>* think over</option>
</select>
</td>
<td><?php ShowSkillDetail(LoadSkillData(9000))?></td>
</tr>
<tr>
<td>2</td>
<td><select>
<option>반드시</option>
<option>자신의 HP가 50%이상일 때</option>
<option selected>자신의 SP가 20% 이상일 때</option>
<option>자신의 SP가 30% 이상일 때</option>
<option>첫턴행동시</option>
</select></td>
<td><select>
<option>Attack</option>
<option>Bash</option>
<option>RagingBlow</option>
<option>Reinforce</option>
<option selected>SelfRecovery</option>
<option>* think over</option>
</select></td>
<td><?php ShowSkillDetail(LoadSkillData(3121))?></td>
</tr>
<tr>
<td>3</td>
<td><select>
<option>반드시</option>
<option>자신의 HP가 50%이상일 때</option>
<option>자신의 SP가 20% 이상일 때</option>
<option>자신의 SP가 30% 이상일 때</option>
<option selected>첫턴행동시</option>
</select></td>
<td><select>
<option>Attack</option>
<option>Bash</option>
<option>RagingBlow</option>
<option selected>Reinforce</option>
<option>SelfRecovery</option>
<option>* think over</option>
</select></td>
<td><?php ShowSkillDetail(LoadSkillData(3110))?></td>
</tr>
<tr>
<td>4</td>
<td><select>
<option>반드시</option>
<option>자신의 HP가 50%이상일 때</option>
<option>자신의 SP가 20% 이상일 때</option>
<option selected>자신의 SP가 30% 이상일 때</option>
<option>첫턴행동시</option>
</select></td>
<td><select>
<option>Attack</option>
<option>Bash</option>
<option selected>RagingBlow</option>
<option>Reinforce</option>
<option>SelfRecovery</option>
<option>* think over</option>
</select></td>
<td><?php ShowSkillDetail(LoadSkillData(1017))?></td>
</tr>
<tr>
<td>5</td>
<td><select>
<option selected>반드시</option>
<option>자신의 HP가 50%이상일 때</option>
<option>자신의 SP가 20% 이상일 때</option>
<option>자신의 SP가 30% 이상일 때</option>
<option>첫턴행동시</option>
</select></td>
<td><select>
<option selected>Attack</option>
<option>Bash</option>
<option>RagingBlow</option>
<option>Reinforce</option>
<option>SelfRecovery</option>
<option>* think over</option>
</select></td>
<td><?php ShowSkillDetail(LoadSkillData(1000))?></td>
</tr>
</tbody>
</table>
이 경우, 1과 2의
<ul>
<li>자신의 HP가 50% 이하일 때</li>
<li>자신의 SP가 20% 이상일 때</li>
</ul>
<p>라는 설정이 양쪽 다 맞는 경우에만 기술을 사용한다.</p>
<!-- ----------------------------------- -->
<p>대략 설명하자면...</p>
<table cellspacing="5">
<tbody>
<tr>
<td>1</td>
<td>
<select>
<option selected>~의 때</option>
</select>
</td>
<td>
<select>
<option>Skill 1</option>
<option>Skill 2</option>
<option>Skill 3</option>
<option selected>* think over</option>
</select>
</td>
<td>조건에 맞지 않으면 3으로</td>
</tr>
<tr>
<td>2</td>
<td><select>
<option selected>~의 때</option>
</select></td>
<td><select>
<option selected>Skill 1</option>
<option>Skill 2</option>
<option>Skill 3</option>
<option>* think over</option>
</select></td>
<td>1+2의 조건에 맞으면 스킬1 사용</td>
</tr>
<tr>
<td>3</td>
<td><select>
<option selected>~의 때</option>
</select></td>
<td><select>
<option>Skill 1</option>
<option>Skill 2</option>
<option>Skill 3</option>
<option selected>* think over</option>
</select></td>
<td>조건에 맞지 않으면 6으로</td>
</tr>
<tr>
<td>4</td>
<td><select>
<option selected>~의 때</option>
</select></td>
<td><select>
<option>Skill 1</option>
<option>Skill 2</option>
<option>Skill 3</option>
<option selected>* think over</option>
</select></td>
<td>조건에 맞지 않으면 6으로</td>
</tr>
<tr>
<td>5</td>
<td><select>
<option selected>~의 때</option>
</select></td>
<td><select>
<option>Skill 1</option>
<option selected>Skill 2</option>
<option>Skill 3</option>
<option>* think over</option>
</select></td>
<td>3+4+5의 조건에 맞으면 스킬2 사용</td>
</tr>
<tr>
<td>6</td>
<td><select>
<option selected>~의 때</option>
</select></td>
<td><select>
<option>Skill 1</option>
<option>Skill 2</option>
<option selected>Skill 3</option>
<option>* think over</option>
</select></td>
<td>6의 조건에 맞으면 스킬3 사용</td>
</tr>
</tbody>
</table>
<p>...일걸?</p>
</div>
<!-- ---------------------------------------------------------------- -->
<a name="twenty"></a>
<h4>약 20%의 확율을 만들자<a href="#content">↑</a></h4>
<p>행동의 다중설정의 70%의 확율, 30%의 확율을 동시에 조합해라<br />
0.7 * 0.3 = 0.21 = 21%</p>
<!-- ---------------------------------------------------------------- -->
<a name="def"></a>
<h4>*방어력의 수치에 대해<a href="#content">↑</a></h4>
<p>앞은 나누고 뒤는 뺀다</p>
<!-- ---------------------------------------------------------------- -->
<a name="res"></a>
<h4>*약점속성과 상태이상이 적은 이유<a href="#content">↑</a></h4>
<p>만들면 네들 머리가 따라가리?</p>
</div>