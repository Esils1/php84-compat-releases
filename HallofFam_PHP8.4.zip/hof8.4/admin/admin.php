<?php
	//include("./setting.php");
	if(!defined("ADMIN_PASSWORD"))
		exit(1);
	error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
	ini_set('display_errors', 0);
	/*
	* 로그인
	*/
	if($_POST["pass"] == ADMIN_PASSWORD || $_COOKIE["adminPass"] == ADMIN_PASSWORD) {
		setcookie ("adminPass", $_POST["pass"]?$_POST["pass"]:$_COOKIE["adminPass"],time()+60*30);
		$login = true;
	}

	/*
	* 로그아웃
	*/
	if($_POST["logout"]) {
		setcookie ("adminPass");
		$login = false;
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script type="text/javascript" src="prototype.js"></script>
<title>HoF - admin</title>
<style TYPE="text/css">
<!--
body{
	background:#10151b;
	color:#d8e0eb;
	font-family:Arial, sans-serif;
	font-size:14px;
	margin:0;
	padding:18px;
}
a{color:#9fb6d8;text-decoration:none;font-weight:bold}
a:hover{color:#fff;text-decoration:underline}
form{
	margin: 0;
	padding: 0;
}
textarea{
	width: min(100%, 980px);
	height: 360px;
	background:#18212b;
	color:#e5edf7;
	border:1px solid #40526a;
	padding:10px;
	box-sizing:border-box;
}
input, select{
	background:#202935;
	color:#e5edf7;
	border:1px solid #506685;
	padding:4px 8px;
	margin:2px;
}
input[type=submit]{
	background:#304052;
	font-weight:bold;
	cursor:pointer;
}
input[type=submit]:hover{background:#40526a}
.admin-wrap{max-width:1120px;margin:0 auto}
.admin-head{
	border-bottom:1px solid #304052;
	margin-bottom:14px;
	padding-bottom:10px;
}
.admin-title{font-size:22px;font-weight:bold;margin-bottom:8px}
.admin-menu a,.admin-menu input{
	display:inline-block;
	margin-right:8px;
	margin-bottom:6px;
}
.admin-panel{
	background:#18212b;
	border:1px solid #304052;
	padding:14px;
	margin:12px 0;
}
.admin-list{list-style:none;padding-left:0}
.admin-list li{
	border-bottom:1px solid #263546;
	padding:8px 0;
}
.hint{color:#91a2bb;font-size:12px}
table{border-collapse:collapse;background:#18212b}
td,th{border:1px solid #40526a;padding:5px 8px}
.setting-table input{width:220px}
.code{font-family:Consolas, monospace;color:#b7d2ff}
.danger{color:#ff8a8a;font-weight:bold}
.ok{color:#66cc66;font-weight:bold}
-->
</style>
</head>
<body>
<div class="admin-wrap">
<?php
if($login) {

	/*
	* function dump
	*/
	if(!function_exists("dump")) {
		function dump($var) {
			print("<pre>".print_r($var,1)."</pre>\n");
		}
	}

	function adminH($text) {
		return htmlspecialchars((string)$text, ENT_QUOTES, "UTF-8");
	}

	function adminWriteFile($file,$text) {
		$fp = @fopen($file,"c+");
		if(!$fp) {
			print('<p class="danger">파일을 열 수 없습니다: '.adminH($file)."</p>\n");
			return false;
		}
		flock($fp,LOCK_EX);
		ftruncate($fp,0);
		rewind($fp);
		fwrite($fp,$text);
		flock($fp,LOCK_UN);
		fclose($fp);
		return true;
	}

	function adminShowFileEditor($file,$title,$postKey,$hint="") {
		if($_POST["changeData"]) {
			if(adminWriteFile($file,$_POST["fileData"]))
				print('<p class="ok">저장했습니다.</p>'."\n");
		}
		print('<div class="admin-panel">'."\n");
		print('<h3>'.adminH($title)."</h3>\n");
		print('<p class="hint">'.adminH($file).($hint ? ' - '.adminH($hint) : '')."</p>\n");
		print('<form action="?" method="post">'."\n");
		print('<textarea name="fileData">');
		print(adminH(file_exists($file) ? file_get_contents($file) : ""));
		print("</textarea><br>\n");
		print('<input type="submit" name="changeData" value="저장">');
		print('<input type="submit" value="새로고침">');
		print('<input type="hidden" name="'.$postKey.'" value="1">');
		print("</form>\n");
		print("</div>\n");
	}

	function adminSettingRows() {
		return array(
			array("TITLE","타이틀","string"),
			array("DEBUG","디버그 사용","expr"),
			array("MAX_TIME","최대 활동 시간","expr"),
			array("TIME_GAIN_DAY","하루 회복 시간","expr"),
			array("START_TIME","시작 시간","expr"),
			array("START_MONEY","시작 자금","expr"),
			array("MAX_CHAR","최대 캐릭터 수","expr"),
			array("MAX_USERS","최대 유저 수","expr"),
			array("ABANDONED","휴면 처리 기간","expr"),
			array("CHAR_NO_IMAGE","캐릭터 기본 이미지","string"),
			array("SESSION_SWITCH","세션 사용","expr"),
			array("CHAR_ROW","캐릭터 한 줄 표시 수","expr"),
			array("CRYPT_KEY","암호화 키(설치 후 변경 주의)","string"),
			array("COOKIE_EXPIRE","쿠키 유지 시간","expr"),
			array("UP_PASS","업데이트 비밀번호","string"),
			array("MAX_LEVEL","최대 레벨","expr"),
			array("MAX_STATUS","스테이터스 최대치","expr"),
			array("GET_STATUS_POINT","레벨업 스테이터스 포인트","expr"),
			array("GET_SKILL_POINT","레벨업 스킬 포인트","expr"),
			array("REFINE_LIMIT","제련 한계","expr"),
			array("SELLING_PRICE","기본 판매가 비율","expr"),
			array("NEW_NAME_COST","이름 변경 비용","expr"),
			array("EXP_RATE","경험치 배율","expr"),
			array("MONEY_RATE","자금 배율","expr"),
			array("CONTROL_PERIOD","자동 관리 주기","expr"),
			array("RECORD_IP","IP 기록 여부","expr"),
			array("BBS_OUT","외부 게시판 주소","string"),
			array("AUCTION_MAX","최대 출품 수","expr"),
			array("AUCTION_TOGGLE","옥션 사용","expr"),
			array("AUCTION_EXHIBIT_TOGGLE","옥션 출품 허용","expr"),
			array("JUDGE_LIST_AUTO_LOAD","판정 목록 자동 취득","expr"),
			array("RANK_TEAM_SET_TIME","랭킹 팀 설정 주기","expr"),
			array("RANK_BATTLE_NEXT_LOSE","랭킹 패배 후 대기","expr"),
			array("RANK_BATTLE_NEXT_WIN","랭킹 승리 후 대기","expr"),
			array("NORMAL_BATTLE_TIME","일반 전투 소모 시간","expr"),
			array("ENEMY_INCREASE","적 증원 확률","expr"),
			array("BATTLE_MAX_TURNS","전투 최대 행동 수","expr"),
			array("TURN_EXTENDS","전투 연장 행동 수","expr"),
			array("BATTLE_MAX_EXTENDS","전투 연장 한계","expr"),
			array("BTL_IMG_TYPE","전투 이미지 출력 방식","expr"),
			array("BTL_IMG","전투 이미지 파일","string"),
			array("BATTLE_STAT_TURNS","전투 상태 표시 간격","expr"),
			array("DEAD_IMG","전투 사망 이미지","string"),
			array("MAX_BATTLE_LOG","일반 전투 로그 보존 수","expr"),
			array("MAX_BATTLE_LOG_UNION","유니온 전투 로그 보존 수","expr"),
			array("MAX_BATTLE_LOG_RANK","랭킹 전투 로그 보존 수","expr"),
			array("MAX_STATUS_MAXIMUM","전투 중 능력 상승 한계","expr"),
			array("DELAY_TYPE","딜레이 방식","expr"),
			array("DELAY","구 딜레이 값","expr"),
			array("DELAY_BASE","신 딜레이 기준값","expr"),
			array("UNION_BATTLE_TIME","유니온 전투 소모 시간","expr"),
			array("UNION_BATTLE_NEXT","유니온 전투 대기 시간","expr"),
			array("BBS_BOTTOM_TOGGLE","하단 게시판 사용","expr")
		);
	}

	function adminReadDefineRaw($text,$name) {
		if(preg_match('/^define\("'.preg_quote($name,'/').'"\s*,\s*(.*?)\);/m',$text,$m))
			return trim($m[1]);
		return "";
	}

	function adminDefineValueForInput($raw,$type) {
		if($type === "string" && strlen($raw) >= 2) {
			$quote = $raw[0];
			if(($quote === '"' || $quote === "'") && substr($raw,-1) === $quote)
				return stripcslashes(substr($raw,1,-1));
		}
		return $raw;
	}

	function adminNormalizeDefineValue($value,$type) {
		$value = trim($value);
		if($type === "string")
			return '"'.addcslashes($value,"\\\"").'"';
		if(!preg_match('/^[0-9\s\+\-\*\/\.\(\)]+$/',$value))
			return false;
		return $value;
	}

	function adminSaveSettings($file) {
		$text = file_get_contents($file);
		$rows = adminSettingRows();
		foreach($rows as $row) {
			list($name,$label,$type) = $row;
			if(!isset($_POST["setting"][$name]))
				continue;
			$value = adminNormalizeDefineValue($_POST["setting"][$name],$type);
			if($value === false) {
				print('<p class="danger">'.adminH($label).' 값 형식이 올바르지 않습니다.</p>'."\n");
				return false;
			}
			$pattern = '/^define\("'.preg_quote($name,'/').'"\s*,\s*.*?\);([^\r\n]*)$/m';
			$replace = 'define("'.$name.'",'.$value.');$1';
			$text = preg_replace($pattern,$replace,$text,1);
		}
		if(adminWriteFile($file,$text)) {
			print('<p class="ok">설정을 저장했습니다. 변경 값은 다음 요청부터 적용됩니다.</p>'."\n");
			return true;
		}
		return false;
	}

	function adminShowSettingsEditor() {
		$file = "./setting.php";
		if($_POST["saveSettings"])
			adminSaveSettings($file);
		$text = file_get_contents($file);
		$rows = adminSettingRows();
		print('<div class="admin-panel">'."\n");
		print("<h3>기본 설정</h3>\n");
		print('<p class="hint">수식 입력 가능: 예) 60*60*12, 1/4. 문자열은 따옴표 없이 입력합니다.</p>'."\n");
		print('<form action="?" method="post">'."\n");
		print('<table class="setting-table"><tbody>'."\n");
		print('<tr><th>설정</th><th>설명</th><th>현재 적용값</th><th>저장값</th></tr>'."\n");
		foreach($rows as $row) {
			list($name,$label,$type) = $row;
			$raw = adminReadDefineRaw($text,$name);
			$value = adminDefineValueForInput($raw,$type);
			$current = defined($name) ? constant($name) : "";
			print("<tr>");
			print('<td><span class="code">'.adminH($name)."</span></td>");
			print('<td>'.adminH($label)."</td>");
			print('<td>'.adminH($current)."</td>");
			print('<td><input type="text" name="setting['.adminH($name).']" value="'.adminH($value).'" style="width:220px"></td>');
			print("</tr>\n");
		}
		print("</tbody></table>\n");
		print('<input type="submit" name="saveSettings" value="설정 저장"> ');
		print('<a href="?">새로고침</a>');
		print("</form>\n");
		print("</div>\n");
	}

	/*
	* changeData(데이터로 변경을 합니다.)
	*/
	function changeData($file,$text) {
		if(adminWriteFile($file,$text))
			print('<p class="ok">데이터를 저장했습니다.</p>'."\n");
	}

	/*
	* 메뉴
	*/
print <<< MENU
<div class="admin-head">
<div class="admin-title">H.O.F 관리자 모드</div>
<form action="?" method="post" class="admin-menu">
<a href="?">설정 관리</a>
<a href="?menu=user">유저 관리</a>
<a href="?menu=data">데이터/로그 관리</a>
<a href="?menu=other">도구 목록</a>
<a href="./index.php">게임으로 돌아가기</a>
<input type="submit" value="로그아웃" name="logout" />
</form>
</div>
MENU;

	/*
	* 유저
	*/
	if($_GET["menu"] === "user") {
		$userList = glob(USER."*");
		print("<div class=\"admin-panel\"><h3>유저 목록</h3>\n");
		print("<p class=\"hint\">유저 ID를 선택하면 저장 파일을 직접 확인하거나 수정할 수 있습니다.</p>\n");
		foreach($userList as $user) {
			print('<form action="?" method="post">');
			print('<input type="submit" name="UserData" value="열기">');
			print('<input type="hidden" name="userID" value="'.basename($user).'">');
			print(basename($user)."\n");
			print("</form>\n");
		}
		print("</div>\n");
	}

	/*
	* 유저데이터
	*/
	else if($_POST["UserData"]) {
		$userID = basename($_POST["userID"]);
		$userFileList = glob(USER.$userID."/*");
		print("<div class=\"admin-panel\"><h3>유저 파일 : ".adminH($userID)."</h3>\n");
		foreach($userFileList as $file) {
			print('<form action="?" method="post">');
			print('<input type="submit" name="UserFileDet" value="편집">');
			print('<input type="hidden" name="userFile" value="'.adminH(basename($file)).'">');
			print('<input type="hidden" name="userID" value="'.adminH($userID).'">');
			print(adminH(basename($file))."\n");
			print("</form>\n");
		}
		print('<br><form action="?" method="post">');
		print('<span class="danger">유저 삭제</span> 관리자 비밀번호 확인 :<input type="text" name="deletePass" size="">');
		print('<input type="submit" name="deleteUser" value="삭제">');
		print('<input type="hidden" name="userID" value="'.adminH($userID).'">');
		print("</form>\n");
		print("</div>\n");
	}

	/*
	* 유저데이터의 삭제
	*/
	else if($_POST["deleteUser"]) {
		if($_POST["deletePass"] == ADMIN_PASSWORD) {
			$userID = basename($_POST["userID"]);
			include(GLOBAL_PHP);
			include(CLASS_USER);
			$userD = new user($userID);
			$userD->DeleteUser();
			print(adminH($userID)."를 삭제하였습니다.");
		} else {
			print("패스워드가 틀립니다.");
		}
	}

	/*
	* 유저데이터 (상세)
	*/
	else if($_POST["UserFileDet"]) {
		$userID = basename($_POST["userID"]);
		$userFile = basename($_POST["userFile"]);
		$file = USER.$userID."/".$userFile;
		// 데이터의 수정
		if(!is_file($file)) {
			print('<div class="admin-panel"><p class="danger">파일을 찾을 수 없습니다: '.adminH($file)."</p></div>\n");
		} else {
			if($_POST["changeData"]) {
				if(adminWriteFile($file,$_POST["fileData"]))
					print('<p class="ok">데이터를 저장했습니다.</p>'."\n");
			}

			print("<div class=\"admin-panel\"><h3>파일 편집</h3><p class=\"hint\">".adminH($file)."</p>\n");
			print('<form action="?" method="post">');
			print('<textarea name="fileData">');
			print(adminH(file_get_contents($file)));
			print("</textarea><br>\n");
			print('<input type="submit" name="changeData" value="수정">');
			print('<input type="submit" value="새로고침">');
			print('<input type="hidden" name="userFile" value="'.adminH($userFile).'">');
			print('<input type="hidden" name="userID" value="'.adminH($userID).'">');
			print('<input type="hidden" name="UserFileDet" value="1">');
			print("</form>\n");
			print('<form action="?" method="post">');
			print('<input type="submit" name="UserData" value="돌아가기">');
			print('<input type="hidden" name="userID" value="'.adminH($userID).'">');
			print("</form>\n");
			print("</div>\n");
		}
	}

	/*
	* 데이터 집계
	*/
	else if($_GET["menu"] === "data") {
print <<< DATA
<div class="admin-panel">
<h3>데이터/로그 관리</h3>
<p class="hint">통계 조회는 유저 수가 많으면 시간이 걸릴 수 있습니다. 삭제 기능은 즉시 반영됩니다.</p>
<form action="?" method="post">
<ul class="admin-list">
<li><input type="submit" name="UserDataDetail" value="보기"> 유저 자금 통계</li>
<li><input type="submit" name="UserCharDetail" value="보기"> 캐릭터 능력치 통계</li>
<li><input type="submit" name="ItemDataDetail" value="보기"> 아이템 보유량 통계</li>
<li><input type="submit" name="UserIpShow" value="보기"> 유저 IP 목록</li>
<li><input type="submit" name="searchBroken" value="검사"> 손상 의심 데이터 찾기 <input type="text" name="brokenSize" value="100" size=""> byte 이하</li>
<li><input type="submit" name="adminBattleLog" value="관리"> 전투 로그 삭제</li>
<li><input type="submit" name="adminAuction" value="편집"> 옥션 데이터</li>
<li><input type="submit" name="adminRanking" value="편집"> 랭킹 데이터</li>
<li><input type="submit" name="adminTown" value="편집"> 마을 광장 글</li>
<li><input type="submit" name="adminRegister" value="편집"> 유저 등록정보</li>
<li><input type="submit" name="adminUserName" value="편집"> 유저 이름 목록</li>
<li><input type="submit" name="adminUpDate" value="편집"> 업데이트 글</li>
<li><input type="submit" name="adminAutoControl" value="편집"> 자동관리 로그</li>
</ul>
</form>
</div>
DATA;
	}

	/*
	* 데이터 집계(유저 데이터)
	*/
	else if($_POST["UserDataDetail"]) {
		include(GLOBAL_PHP);
		include(CLASS_USER);
		$userFileList = glob(USER."*");
		foreach($userFileList as $user) {
			$user = new user(basename($user,".dat"));
			$totalMoney += $user->money;
		}
		print("유저 수 :".count($userFileList)."<br>\n");
		print("전체 자금 :".MoneyFormat($totalMoney)."<br>\n");
		print("평균 자금 :".MoneyFormat($totalMoney/count($userFileList))."<br>\n");
	}

	/*
	* 데이터 집계(캐릭터 데이터)
	*/
	else if($_POST["UserCharDetail"]) {
		include(GLOBAL_PHP);
		$userFileList = glob(USER."*");
		foreach($userFileList as $user) {
			$userDir = glob($user."/*");
			foreach($userDir as $fileName) {
				if(!is_numeric(basename($fileName,".dat"))) break;
				$charData = ParseFile($fileName);
				$charAmount++;
				$totalLevel += $charData["level"];
				$totalStr += $charData["str"];
				$totalInt += $charData["int"];
				$totalDex += $charData["dex"];
				$totalSpd += $charData["spd"];
				$totalLuk += $charData["luk"];
				if($charData["gender"] === "0")
					$totalMale++;
				else if($charData["gender"] === "1")
					$totalFemale++;
				$totalJob[$charData["job"]]++;

				//print($charData["name"]."<br>");
			}
		}
		print("캐릭터 수 :".$charAmount."<br>\n");
		print("평균 레벨 :".$totalLevel/$charAmount."<br>\n");
		print("평균 힘 :".$totalStr/$charAmount."<br>\n");
		print("평균 지능 :".$totalInt/$charAmount."<br>\n");
		print("평균 민첩 :".$totalDex/$charAmount."<br>\n");
		print("평균 스피드 :".$totalSpd/$charAmount."<br>\n");
		print("평균 운 :".$totalLuk/$charAmount."<br>\n");
		print("남성 :{$totalMale}(".($totalMale/$charAmount*100)."%)<br>\n");
		print("여성 :{$totalFemale}(".($totalFemale/$charAmount*100)."%)<br>\n");

		print("--- 직업<br>\n");
		arsort($totalJob);
		include(DATA_JOB);
		foreach($totalJob as $job => $amount) {
			$jobData = LoadJobData($job);
			print($job."({$jobData['name_male']},{$jobData['name_female']})"." : ".$amount."(".($amount/$charAmount*100)."%)<br>\n");
		}
	}

	/*
	* 데이터 집계(아이템 데이터)
	*/
	else if($_POST["ItemDataDetail"]) {
		include(GLOBAL_PHP);
		$userFileList = glob(USER."*");
		$userAmount = count($userFileList);
		$items = array();
		foreach($userFileList as $user) {
			if(!$data = ParseFile($user."/item.dat"));
			foreach($data as $itemno => $amount)
				$items[$itemno] += $amount;
		}
		foreach($items as $itemno => $amount) {
			if(strlen($itemno) != 4) break;
			print($itemno." : ".$amount."(평균:".$amount/$userAmount.")<br>");
		}
	}

	/*
	* 유저의 IP표시
	*/
	else if($_POST["UserIpShow"]) {
		include(GLOBAL_PHP);
		$userFileList = glob(USER."*");
		$ipList = array();
		foreach($userFileList as $user) {
			$file = $user."/data.dat";
			if(!$data = ParseFile($file)) break;
			$html .= "<tr><td>".$data["id"]."</td><td>".$data["name"]."</td><td>".$data["ip"]."</td></tr>\n";
			$ipList[$data["ip"]?$data["ip"]:"*UnKnown"]++;
		}
		// 중복 리스트
		print("<p>IP중복 리스트</p>\n");
		foreach($ipList as $ip => $amount) {
			if(1 < $amount)
				print("$ip : $amount<br>\n");
		}
		print("<table border=\"1\">\n");
		print($tags = "<tr><td>아이디</td><td>이름</td><td>IP</td></tr>\n");
		print($html);
		print("</table>\n");
	}

	/*
	* 망가져있는 가능성이 있는 데이터를 찾는다
	*/
	else if($_POST["searchBroken"]) {
		print("<p>망가져 있을 가능성이 있는 파일<br>\n");
		$baseSize = $_POST["brokenSize"]?(int)$_POST["brokenSize"]:100;
		print("※{$baseSize}byte 이하의 파일을 찾았습니다(아이템 데이터 제외).</p>");
		$userFileList = glob(USER."*");
		foreach($userFileList as $user) {
			$userDir = glob($user."/*");
			if(filesize($user."/data.dat") < $baseSize)
				print($user."/data.dat"."(".filesize($user."/data.dat").")"."<br>\n");
			foreach($userDir as $fileName) {
				if(!is_numeric(basename($fileName,".dat"))) break;
				if(filesize($fileName) < $baseSize)
					print($fileName."(".filesize($fileName).")<br>\n");
			}
		}
	}

	/*
	* 전투 로그의 관리
	*/
	else if($_POST["adminBattleLog"]) {
		if($_POST["deleteLogCommon"]) {
			$dir = LOG_BATTLE_NORMAL;
			$logFile = glob($dir."*");
			foreach($logFile as $file) {
				unlink($file);
			}
			print("<p>일반 전투 로그를 삭제했습니다.</p>\n");
		} else if($_POST["deleteLogUnion"]) {
			$dir = LOG_BATTLE_UNION;
			$logFile = glob($dir."*");
			foreach($logFile as $file) {
				unlink($file);
			}
			print("<p>유니온 전투 로그를 삭제했습니다.</p>\n");
		} else if($_POST["deleteLogRanking"]) {
			$dir = LOG_BATTLE_RANK;
			$logFile = glob($dir."*");
			foreach($logFile as $file) {
				unlink($file);
			}
			print("<p>랭킹 전투 로그를 삭제했습니다.</p>\n");
		}
print <<< DATA
<br>
<form action="?" method="post">
<input type="hidden" name="adminBattleLog" value="1">
<ul>
<li><input type="submit" name="deleteLogCommon" value="삭제"> 일반 전투 로그 전체 삭제</li>
<li><input type="submit" name="deleteLogUnion" value="삭제"> 유니온 전투 로그 전체 삭제</li>
<li><input type="submit" name="deleteLogRanking" value="삭제"> 랭킹 전투 로그 전체 삭제</li>
</ul>
</form>
DATA;
	}

	/*
	* 옥션의 관리
	*/
	else if($_POST["adminAuction"]) {
		adminShowFileEditor(AUCTION_ITEM,"옥션 데이터","adminAuction");
	}

	/*
	* 랭킹의 관리
	*/
	else if($_POST["adminRanking"]) {
		adminShowFileEditor(RANKING,"랭킹 데이터","adminRanking");
	}

	/*
	* 마을 광장의 관리
	*/
	else if($_POST["adminTown"]) {
		adminShowFileEditor(BBS_TOWN,"마을 광장 글","adminTown");
	}

	/*
	* 유저 등록정보의 관리
	*/
	else if($_POST["adminRegister"]) {
		adminShowFileEditor(REGISTER,"유저 등록정보","adminRegister");
	}

	/*
	* 유저 이름의 관리
	*/
	else if($_POST["adminUserName"]) {
		adminShowFileEditor(USER_NAME,"유저 이름 목록","adminUserName");
	}

	/*
	* 갱신정보의 관리
	*/
	else if($_POST["adminUpDate"]) {
		adminShowFileEditor(UPDATE,"업데이트 글","adminUpDate");
	}

	/*
	* 자동 관리의 로그
	*/
	else if($_POST["adminAutoControl"]) {
		adminShowFileEditor(MANAGE_LOG_FILE,"자동 관리 로그","adminAutoControl");
	}

	/*
	* OTHER
	*/
	else if($_GET["menu"] === "other") {
print("
<div class=\"admin-panel\">\n
<h3>도구 목록</h3>\n
<ul>\n
<li><a href=\"".ADMIN_DIR."list_item.php\">아이템 목록</a></li>\n
<li><a href=\"".ADMIN_DIR."list_enchant.php\">장비 효과 목록</a></li>\n
<li><a href=\"".ADMIN_DIR."list_job.php\">직업 목록</a></li>\n
<li><a href=\"".ADMIN_DIR."list_judge.php\">판정 목록</a></li>\n
<li><a href=\"".ADMIN_DIR."list_monster.php\">몬스터 목록</a></li>\n
<li><a href=\"".ADMIN_DIR."list_skill3.php\">스킬목록</a></li>\n
<li><a href=\"".ADMIN_DIR."set_action2.php\">패턴설정기</a></li>\n
</ul>\n
</div>\n
");
	}

	/*
	* 그 이외
	*/
	else {
		adminShowSettingsEditor();
	}

print <<< ADMIN
<div class="admin-panel hint">
관리 기능은 파일 데이터를 직접 편집하거나 삭제합니다. 변경 전 내용을 확인한 뒤 실행해 주세요.
</div>
ADMIN;


} else {
print <<< LOGIN
<div class="admin-head">
<div class="admin-title">H.O.F 관리자 로그인</div>
</div>
<div class="admin-panel">
<form action="?" method="post">
관리자 비밀번호 : <input type="password" name="pass" />
<input type="submit" value="로그인" />
</form>
</div>
LOGIN;
}

?>
</div>
</body>
</html>
