<?php
// game setting
define("TITLE","Hall of Fame Ver Korean");//타이틀
define("MAX_TIME",1000);//최대활동시간
define("TIME_GAIN_DAY",6000);//1일 동안 회복되는 Time 게이지
define("MAX_CHAR",15);//최대 신규 등록 캐릭터 수
define("MAX_USERS",500);//최대 등록 유저 수
define("ABANDONED",60*60*24*14);//게임이 버림-_-받았다고 간주하는 기간
define("CONTROL_PERIOD",60*60*12);//전기관리의 주기
define("RECORD_IP",1);//IP를 기록하겠습니까?(0=NO 1=YES)

// other
define("DEBUG",0);// 디버그 0=OFF
define("CHAR_NO_IMAGE","NoImage.gif");// 캐릭터 이미지가 없을 경우 표시되는 이미지
define("SESSION_SWITCH",1);// 0=OFF
define("CHAR_ROW",5);// 한 줄에 표시되는 캐릭터의 수
define("CRYPT_KEY",'1234');// 관리자패스워드 admin 변경할것
define("COOKIE_EXPIRE",60*60*24*3);//60*60*24*3
define("UP_PASS","password");// 갱신정보 만이 사용되지 않는다.

define("START_TIME",1000);//게임 시작시에 보유하는 Time
define("START_MONEY",50000);//초기소지금
define("MAX_STATUS",250);//스테이터스 최대치
define("GET_STATUS_POINT",5);//레벨업시 얻는 스테이터스 포인트의 수치
define("GET_SKILL_POINT",2);//레벨업시 얻는 스킬 포인트의 수치
define("MAX_LEVEL",50);//최대 레벨
define("SELLING_PRICE",1/4);//판매가가 설정되어 있지 않은 아이템의 판매가
define("REFINE_LIMIT",20);//제련 한계치

define("EXP_RATE",1);//경험치를 받을 수 있는 배율
define("MONEY_RATE",1);//돈을 받을 수 있는 배율

define("NEW_NAME_COST",30000);//이름을 변경하는데 필요한 돈
define("BBS_OUT","");//외부 BBS를 사용할 경우 주소를 입력, 없으면 쓰지 마세요 ->""
define("BBS_BOTTOM_TOGGLE",0);// 아래에 있던 일행게시판 (0=OFF)
define("AUCTION_TOGGLE",0);// 옥션을 이용하겠는가?(0=OFF 1=ON)
define("AUCTION_EXHIBIT_TOGGLE",0);// 옥션의 물건 등록을 가능하게 하겠습니까?(0=OFF 1=ON)
define("JUDGE_LIST_AUTO_LOAD",0);//패턴 판단의 리스트를 1=자동 0=수동 추가(약간 가볍다)
define("AUCTION_MAX",100);//옥션에 물건 등록을 할 수 있는 최대 수

// ranking
define("RANK_TEAM_SET_TIME",60*60*12);//랭킹 팀을 설정할 수 있는 주기
define("RANK_BATTLE_NEXT_LOSE",60*60*1);//랭킹전에서 졌을 때, 다음 싸움을 할 수 있을때까지(기본값 60*60*24)
define("RANK_BATTLE_NEXT_WIN",60*1);//랭킹전에서 이겼을때 다음 전투까지

// battle setting
define("NORMAL_BATTLE_TIME",100);//일반 몬스터와 전투시 소모되는 시간
define("ENEMY_INCREASE",0);//적의 증원(랜덤)
define("BATTLE_MAX_TURNS",100);//전투의 최대 행동 회수(전투가 수치 이상 길어질 경우 종료된다)
define("TURN_EXTENDS",20);// 결착이 날 것 같은 경우 연장되는 턴 수
define("BATTLE_MAX_EXTENDS",100);//연장했을 경우의 최대 행동 회수(연장 한계)
define("BTL_IMG_TYPE",2);// (0=GD 1=CSS 2=반전제 이미지 사용CSS)
define("BTL_IMG","./image.php");// GD표시
define("BATTLE_STAT_TURNS",10);// 전투의 상황을 표시하는 간격
define("DEAD_IMG","mon_145.gif");// HP=0 캐릭터의 이미지
define("MAX_BATTLE_LOG",1000);// 전투로그를 보존하는 수
define("MAX_BATTLE_LOG_UNION",100);// 전투로그를 보존하는 수
define("MAX_BATTLE_LOG_RANK",100);// 전투로그를 보존하는 수
define("MAX_STATUS_MAXIMUM",2000);// 초기치 x치(%) 전투 중의 능력 상승으로 오르는 수치의 한계치 (1000%=10배가 한계)

define("DELAY_TYPE",1);// 0=구 1=신
// DELAY_TYPE=0
define("DELAY",2.5);//딜레이(2 이상이 기준, SPD가 높은 사람이 유리)
// DELAY_TYPE=1
define("DELAY_BASE",5);// 수치가 높으면 차이가 나지 않는다.

// union
define("UNION_BATTLE_TIME",10);//유니온전에서 소비되는 시간
define("UNION_BATTLE_NEXT",60*10);//유니온 다음 전투까지의 간격


// files
define("INDEX","index.php");

// CLASS FILE
define("CLASS_DIR", "./class/");
define("BTL_IMG_CSS", CLASS_DIR."class.css_btl_image.php");// CSS표시
define("CLASS_MAIN", CLASS_DIR."class.main.php");
define("CLASS_USER", CLASS_DIR."class.user.php");
define("CLASS_CHAR", CLASS_DIR."class.char.php");
define("CLASS_MONSTER", CLASS_DIR."class.monster.php");
define("CLASS_UNION", CLASS_DIR."class.union.php");
define("CLASS_BATTLE", CLASS_DIR."class.battle.php");
define("CLASS_SKILL_EFFECT", CLASS_DIR."class.skill_effect.php");
define("CLASS_RANKING", CLASS_DIR."class.rank2.php");
define("CLASS_JS_ITEMLIST", CLASS_DIR."class.JS_itemlist.php");
define("CLASS_SMITHY", CLASS_DIR."class.smithy.php");
define("CLASS_AUCTION", CLASS_DIR."class.auction.php");
define("GLOBAL_PHP", CLASS_DIR."global.php");
define("COLOR_FILE", CLASS_DIR."Color.dat");

// DATA FILE
define("DATA_DIR", "./data/");
define("DATA_BASE_CHAR", DATA_DIR."data.base_char.php");
define("DATA_JOB", DATA_DIR."data.job.php");
define("DATA_ITEM", DATA_DIR."data.item.php");
define("DATA_ENCHANT", DATA_DIR."data.enchant.php");
define("DATA_SKILL", DATA_DIR."data.skill.php");
define("DATA_SKILL_TREE", DATA_DIR."data.skilltree.php");
define("DATA_JUDGE_SETUP", DATA_DIR."data.judge_setup.php");
define("DATA_JUDGE", DATA_DIR."data.judge.php");
define("DATA_MONSTER", DATA_DIR."data.monster.php");
define("DATA_LAND", DATA_DIR."data.land_info.php");
define("DATA_LAND_APPEAR", DATA_DIR."data.land_appear.php");
define("DATA_CLASSCHANGE", DATA_DIR."data.classchange.php");
define("DATA_CREATE", DATA_DIR."data.create.php");
define("DATA_TOWN", DATA_DIR."data.town_appear.php");

define("MANUAL", DATA_DIR."data.manual0.php");
define("MANUAL_HIGH", DATA_DIR."data.manual1.php");

define("GAME_DATA_JOB", DATA_DIR."data.gd_job.php");
define("GAME_DATA_ITEM", DATA_DIR."data.gd_item.php");
define("GAME_DATA_JUDGE", DATA_DIR."data.gd_judge.php");
define("GAME_DATA_MONSTER", DATA_DIR."data.gd_monster.php");

define("TUTORIAL", DATA_DIR."data.tutorial.php");
// DAT
define("AUCTION_ITEM","./auction.dat");//아이템 옥션용의 파일
define("AUCTION_ITEM_LOG","./auction_log.dat");//아이템 옥션용의 로그 파일

define("REGISTER","./register.dat");
define("UPDATE","./update.dat");
define("CTRL_TIME_FILE","./ctrltime.dat");//정기관리를 위한 시간 기억 파일
define("RANKING","./ranking.dat");
define("BBS_BOTTOM","./bbs.dat");
define("BBS_TOWN","./bbs_town.dat");
define("MANAGE_LOG_FILE","./managed.dat");//정기관리 기록 파일
define("USER_NAME","./username.dat");//이름 보존 파일

// dir
define("IMG_CHAR","./image/char/");
define("IMG_CHAR_REV","./image/char_rev/");
define("IMG_ICON","./image/icon/");
define("IMG_OTHER","./image/other/");
define("USER","./user/");
define("UNION","./union/");
define("DATA","data.dat");
define("ITEM","item.dat");

define("LOG_BATTLE_NORMAL","./log/normal/");
define("LOG_BATTLE_RANK","./log/rank/");
define("LOG_BATTLE_UNION","./log/union/");

//상태정의
define("FRONT","front");
define("BACK","back");

define("TEAM_0",0);
define("TEAM_1",1);
define("WIN",0);
define("LOSE",1);
define("DRAW","d");

define("ALIVE",0);
define("DEAD",1);
define("POISON",2);

define("CHARGE",0);
define("CAST",1);

?>