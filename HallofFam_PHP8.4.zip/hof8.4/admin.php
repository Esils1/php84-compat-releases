<?php
header("Content-Type: text/html; charset=UTF-8");
/*
* 이 파일명은 변경해도 OK
* 패스워드는 변경해 주세요.
*
* 관리하지 않으면
* admin.php 와 admin 폴더를
* 서버로부터 삭제해도 OK
*
*/
	include("setting.php");
	define("ADMIN_DIR","./admin/");//관리용 파일 저장 장소
	define("ADMIN_PASSWORD","1064");//패스워드
	include(ADMIN_DIR."admin.php");
?>