(function () {
  'use strict';

  function formatRegdate(regdate) {
    if (!/^\d{14}$/.test(regdate || '')) return '';
    return regdate.substr(8, 2) + ':' + regdate.substr(10, 2);
  }

  function createEl(tag, className, text) {
    var el = document.createElement(tag);
    if (className) el.className = className;
    if (typeof text === 'string') el.textContent = text;
    return el;
  }

  function parseJsonResponse(r) {
    return r.text().then(function (text) {
      var data = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch (e) {
        return { ok: false, error: 'API 응답 오류 HTTP ' + r.status + ' - JSON이 아닙니다.' };
      }
      if (!r.ok && data && !data.error) data.error = 'API 오류 HTTP ' + r.status;
      return data || { ok: false, error: '빈 API 응답입니다.' };
    });
  }

  function postForm(url, data, token) {
    var form = new FormData();
    Object.keys(data).forEach(function (k) { form.append(k, data[k]); });
    return fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: token ? { 'X-Esils-Chat-Token': token } : {},
      body: form
    }).then(parseJsonResponse);
  }

  function normalizeCssLength(value, fallback, minPx, maxPx) {
    value = String(value || '').replace(/\s+/g, '').toLowerCase();
    fallback = fallback || '';
    if (!value) value = String(fallback);
    if (/^\d+(?:\.\d+)?%$/.test(value)) {
      var pct = parseFloat(value);
      if (!isFinite(pct)) pct = 100;
      if (pct < 5) pct = 5;
      if (pct > 100) pct = 100;
      return pct + '%';
    }
    var m = value.match(/^(\d+)(?:px)?$/);
    if (m) {
      var px = parseInt(m[1], 10);
      if (!px || px < minPx) px = minPx;
      if (px > maxPx) px = maxPx;
      return px + 'px';
    }
    return normalizeCssLength(fallback, String(minPx), minPx, maxPx);
  }


  function parseSeconds(value, fallback, min, max) {
    var n = parseInt(value, 10);
    if (!isFinite(n) || n <= 0) n = fallback;
    if (n < min) n = min;
    if (n > max) n = max;
    return n;
  }

  function initChat(root) {
    if (!root || root.getAttribute('data-emc-ready') === '1') return;
    root.setAttribute('data-emc-ready', '1');

    var api = root.getAttribute('data-api') || './widgets/esils_chat/api.php';
    var room = root.getAttribute('data-room') || 'main';
    var titleText = root.getAttribute('data-title') || '회원 채팅';
    var adminUrl = root.getAttribute('data-admin-url') || '';
    var height = normalizeCssLength(root.getAttribute('data-height'), '190', 80, 1600);
    var maxWidth = normalizeCssLength(root.getAttribute('data-max-width'), '220', 120, 2000);
    var collapsed = root.getAttribute('data-collapsed') === 'Y';
    var pollNormalMs = parseSeconds(root.getAttribute('data-poll-normal'), 5, 1, 60) * 1000;
    var pollActiveMs = parseSeconds(root.getAttribute('data-poll-active'), 3, 1, 60) * 1000;
    if (pollActiveMs > pollNormalMs) pollActiveMs = pollNormalMs;
    var pollActiveDurationMs = parseSeconds(root.getAttribute('data-poll-active-duration'), 30, 1, 300) * 1000;
    var refreshAfterSend = root.getAttribute('data-refresh-after-send') !== 'N';
    var activeUntil = 0;
    var fetchTimer = null;
    var lastId = 0;
    var token = '';
    var logged = false;
    var canSend = false;
    var isAdmin = false;
    var isChatManager = false;
    var fetching = false;
    var adminLink = null;

    root.style.maxWidth = maxWidth;
    root.innerHTML = '';

    var box = createEl('div', 'emc-box' + (collapsed ? ' is-collapsed' : ''));
    var header = createEl('button', 'emc-header');
    header.type = 'button';

    var title = createEl('span', 'emc-title', titleText);
    var meta = createEl('span', 'emc-meta', '접속 확인 중');
    header.appendChild(title);
    header.appendChild(meta);

    var panel = createEl('div', 'emc-panel');
    var toolbar = createEl('div', 'emc-toolbar');
    adminLink = createEl('a', 'emc-admin-link', '관리');
    adminLink.href = adminUrl || '#';
    adminLink.target = '_blank';
    adminLink.style.display = 'none';
    toolbar.appendChild(adminLink);

    var messages = createEl('div', 'emc-messages');
    messages.style.height = height;
    var notice = createEl('div', 'emc-notice', '로그인 회원만 채팅할 수 있습니다.');
    var form = createEl('form', 'emc-form');
    var input = createEl('textarea', 'emc-input');
    input.placeholder = '메시지 입력';
    input.maxLength = 500;
    input.rows = 1;
    var send = createEl('button', 'emc-send', '전송');
    send.type = 'submit';
    form.appendChild(input);
    form.appendChild(send);

    panel.appendChild(toolbar);
    panel.appendChild(messages);
    panel.appendChild(notice);
    panel.appendChild(form);
    box.appendChild(header);
    box.appendChild(panel);
    root.appendChild(box);

    header.addEventListener('click', function () {
      box.classList.toggle('is-collapsed');
      if (!box.classList.contains('is-collapsed')) scrollBottom();
    });

    function setNotice(text, warn) {
      notice.textContent = text || '';
      notice.style.display = text ? 'block' : 'none';
      if (notice.classList) notice.classList.toggle('is-warn', !!warn);
      else notice.className = 'emc-notice' + (warn ? ' is-warn' : '');
    }

    function scrollBottom() {
      messages.scrollTop = messages.scrollHeight;
    }

    function markActivePolling() {
      activeUntil = new Date().getTime() + pollActiveDurationMs;
    }

    function nextPollDelay() {
      return (new Date().getTime() < activeUntil) ? pollActiveMs : pollNormalMs;
    }

    function scheduleFetch(delay) {
      if (fetchTimer) window.clearTimeout(fetchTimer);
      fetchTimer = window.setTimeout(function () { fetchMessages(true); }, Math.max(1000, delay || nextPollDelay()));
    }

    function renderMessage(msg) {
      if (!msg || !msg.id) return;
      var exists = messages.querySelector('[data-id="' + msg.id + '"]');
      if (exists) return;

      var item = createEl('div', 'emc-message' + (msg.is_deleted === 'Y' ? ' is-deleted' : ''));
      item.setAttribute('data-id', msg.id);

      var top = createEl('div', 'emc-message-top');
      var nick = createEl('strong', 'emc-nick', msg.nick_name || '회원');
      var time = createEl('span', 'emc-time', formatRegdate(msg.regdate));
      top.appendChild(nick);
      top.appendChild(time);

      var content = createEl('div', 'emc-content', msg.content || '');
      item.appendChild(top);
      item.appendChild(content);

      if (isAdmin && msg.is_deleted !== 'Y') {
        var del = createEl('button', 'emc-delete', '삭제');
        del.type = 'button';
        del.addEventListener('click', function (ev) {
          ev.stopPropagation();
          if (!confirm('이 채팅 메시지를 삭제할까요?')) return;
          postForm(api + '?action=delete&room=' + encodeURIComponent(room), { id: msg.id }, token)
            .then(function (res) {
              if (!res.ok) { setNotice(res.error || '삭제 실패', true); return; }
              item.className += ' is-deleted';
              content.textContent = '관리자에 의해 삭제된 메시지입니다.';
              if (del.parentNode) del.parentNode.removeChild(del);
            })
            .catch(function () { setNotice('삭제 요청 실패', true); });
        });
        item.appendChild(del);
      }

      messages.appendChild(item);
      lastId = Math.max(lastId, parseInt(msg.id, 10) || 0);
      if (messages.children.length > 120) messages.removeChild(messages.firstChild);
      scrollBottom();
    }

    function applyState(res) {
      if (!res || !res.ok) {
        setNotice(res && res.error ? res.error : '채팅 상태를 확인하지 못했습니다.', true);
        return;
      }
      logged = !!res.logged;
      canSend = !!res.can_send;
      token = res.token || token || '';
      isAdmin = !!(res.member && res.member.can_delete);
      isChatManager = !!(res.member && res.member.is_chat_manager);
      meta.textContent = '접속 ' + (res.online_count || 0);
      if (res.settings && res.settings.max_length) input.maxLength = parseInt(res.settings.max_length, 10) || 500;
      if (res.settings) {
        pollNormalMs = parseSeconds(res.settings.poll_normal_seconds, 5, 1, 60) * 1000;
        pollActiveMs = parseSeconds(res.settings.poll_active_seconds, 3, 1, 60) * 1000;
        if (pollActiveMs > pollNormalMs) pollActiveMs = pollNormalMs;
        pollActiveDurationMs = parseSeconds(res.settings.poll_active_duration_seconds, 30, 1, 300) * 1000;
        refreshAfterSend = res.settings.refresh_after_send !== 'N';
      }

      root.className = root.className.replace(/\bis-guest\b/g, '').replace(/\s+$/g, '');
      if (!logged) root.className += ' is-guest';
      form.style.display = canSend ? 'flex' : 'none';
      input.disabled = !canSend;
      send.disabled = !canSend;

      if (isChatManager && (res.admin_url || adminUrl)) {
        adminLink.href = res.admin_url || adminUrl;
        adminLink.style.display = 'inline-block';
      } else {
        adminLink.style.display = 'none';
      }

      if (res.blocked) setNotice(res.block_message || '채팅이 차단되었습니다.', true);
      else if (!logged && canSend) setNotice('비회원 채팅 허용 중입니다.', false);
      else if (!canSend) setNotice('로그인 회원만 채팅할 수 있습니다.', true);
      else setNotice('', false);
    }

    function fetchState() {
      return fetch(api + '?action=state&room=' + encodeURIComponent(room), { credentials: 'same-origin' })
        .then(parseJsonResponse)
        .then(applyState)
        .catch(function () { setNotice('채팅 API 연결 실패', true); });
    }

    function fetchMessages(autoSchedule) {
      if (fetching) {
        if (autoSchedule) scheduleFetch(1000);
        return;
      }
      fetching = true;
      fetch(api + '?action=fetch&room=' + encodeURIComponent(room) + '&after_id=' + encodeURIComponent(lastId), { credentials: 'same-origin' })
        .then(parseJsonResponse)
        .then(function (res) {
          fetching = false;
          if (!res || !res.ok) {
            setNotice(res && res.error ? res.error : '채팅 조회 실패', true);
            if (autoSchedule) scheduleFetch(pollNormalMs);
            return;
          }
          if (typeof res.online_count !== 'undefined') meta.textContent = '접속 ' + (res.online_count || 0);
          if (Array.isArray(res.messages)) {
            if (res.messages.length > 0) markActivePolling();
            res.messages.forEach(renderMessage);
          }
          if (autoSchedule) scheduleFetch(nextPollDelay());
        })
        .catch(function () {
          fetching = false;
          setNotice('채팅 조회 실패', true);
          if (autoSchedule) scheduleFetch(pollNormalMs);
        });
    }

    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (!canSend) { setNotice(logged ? '현재 채팅을 보낼 수 없습니다.' : '로그인 후 이용할 수 있습니다.', true); return; }
      var text = input.value.replace(/^\s+|\s+$/g, '');
      if (!text) return;
      send.disabled = true;
      postForm(api + '?action=send&room=' + encodeURIComponent(room), { content: text }, token)
        .then(function (res) {
          send.disabled = false;
          if (!res || !res.ok) { setNotice(res && res.error ? res.error : '전송 실패', true); return; }
          input.value = '';
          if (logged) setNotice('', false);
          markActivePolling();
          if (Array.isArray(res.messages)) res.messages.forEach(renderMessage);
          if (refreshAfterSend) {
            window.setTimeout(function () { fetchMessages(false); }, 100);
            scheduleFetch(pollActiveMs);
          }
        })
        .catch(function () {
          send.disabled = false;
          setNotice('전송 요청 실패', true);
        });
    });

    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' && !ev.shiftKey) {
        ev.preventDefault();
        if (typeof Event === 'function') form.dispatchEvent(new Event('submit', { cancelable: true }));
        else {
          var evt = document.createEvent('Event');
          evt.initEvent('submit', true, true);
          form.dispatchEvent(evt);
        }
      }
    });

    fetchState().then(function () {
      fetchMessages(false);
      scheduleFetch(pollNormalMs);
      window.setInterval(fetchState, 30000);
    });
  }

  function boot() {
    var roots = document.querySelectorAll('.emc-chat[data-api]');
    for (var i = 0; i < roots.length; i++) initChat(roots[i]);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
