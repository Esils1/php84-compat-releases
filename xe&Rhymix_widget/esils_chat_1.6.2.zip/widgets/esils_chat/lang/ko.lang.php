<?php
$lang->esils_chat = 'Esils 회원 채팅';
$lang->esils_chat_title = '회원 채팅';
$lang->esils_chat_description = 'Rhymix/XE 회원 채팅';
