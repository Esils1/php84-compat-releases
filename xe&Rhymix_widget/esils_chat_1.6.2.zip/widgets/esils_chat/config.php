<?php
// Optional manual override. Usually not needed when this folder is placed at XE_ROOT/widgets/esils_chat/.
// Example:
// define('EMC_XE_ROOT', '/home/account/public_html/xe');
// define('EMC_ROOM_DEFAULT', 'main');
