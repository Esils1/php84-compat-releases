<?php
/**
 * Esils Chat common library for Rhymix 2.x / XE Core 1.11.x
 * Path: RX/XE_ROOT/widgets/esils_chat/lib.php
 */
error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

if (is_file(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
}

if (!defined('EMC_ROOM_DEFAULT')) define('EMC_ROOM_DEFAULT', 'main');
if (!defined('EMC_PER_PAGE')) define('EMC_PER_PAGE', 50);

function emc_xe_root()
{
    if (defined('RX_BASEDIR') && RX_BASEDIR && is_file(rtrim(RX_BASEDIR, '/\\') . '/config/config.inc.php')) {
        return rtrim(RX_BASEDIR, '/\\');
    }

    if (defined('EMC_XE_ROOT') && EMC_XE_ROOT) {
        $root = rtrim(EMC_XE_ROOT, '/\\');
        if (is_file($root . '/config/config.inc.php')) return $root;
    }

    $widget_dir = __DIR__;
    $xe_root_from_widget = realpath($widget_dir . '/../..');
    $base = dirname(__DIR__);
    $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/\\') : '';
    $candidates = array(
        $xe_root_from_widget,
        $base,
        $base . '/xe',
        $docroot ? $docroot . '/xe' : null,
        $docroot ?: null,
        getcwd(),
        getcwd() . '/xe',
    );

    foreach ($candidates as $candidate) {
        if (!$candidate) continue;
        $candidate = rtrim($candidate, '/\\');
        if (is_file($candidate . '/config/config.inc.php')) return $candidate;
    }

    return $base;
}

function emc_context_init_safe()
{
    if (!class_exists('Context')) return;

    // Rhymix 2.x는 Context::init()가 static이고, XE Core 1.x는 인스턴스 방식인 경우가 있다.
    // PHP 8.x에서는 non-static 메서드를 static으로 호출하면 치명 오류가 되므로 Reflection으로 구분한다.
    if (method_exists('Context', 'init')) {
        try {
            $method = new ReflectionMethod('Context', 'init');
            if ($method->isStatic()) {
                Context::init();
                return;
            }
        } catch (Exception $e) {
            // 아래 인스턴스 방식으로 재시도한다.
        }
    }

    if (method_exists('Context', 'getInstance')) {
        try {
            $context = Context::getInstance();
            if (is_object($context) && method_exists($context, 'init')) {
                $context->init();
                return;
            }
        } catch (Exception $e) {
            // 이미 초기화되었거나 직접 실행 환경에서 일부 라우팅 정보가 부족할 수 있다.
        }
    }
}

function emc_bootstrap_xe($json_on_error)
{
    $root = emc_xe_root();
    $config = $root . '/config/config.inc.php';
    if (!is_file($config)) {
        $msg = 'Rhymix/XE config/config.inc.php 파일을 찾을 수 없습니다. esils_chat 폴더를 사이트 루트의 widgets 폴더 안에 올려주세요.';
        if ($json_on_error) emc_json(array('ok' => false, 'error' => $msg), 500);
        header('Content-Type: text/html; charset=UTF-8');
        die($msg);
    }
    if (!defined('__XE__')) define('__XE__', true);
    require_once $config;

    emc_context_init_safe();

    if (function_exists('session_status')) {
        if (session_status() === PHP_SESSION_NONE) @session_start();
    } else if (!session_id()) {
        @session_start();
    }
}

function emc_utf8_sanitize_value($value)
{
    if (is_array($value)) {
        $out = array();
        foreach ($value as $k => $v) $out[$k] = emc_utf8_sanitize_value($v);
        return $out;
    }
    if (is_object($value)) {
        $vars = get_object_vars($value);
        foreach ($vars as $k => $v) $value->{$k} = emc_utf8_sanitize_value($v);
        return $value;
    }
    if (is_string($value)) {
        if (function_exists('mb_check_encoding') && !@mb_check_encoding($value, 'UTF-8')) {
            if (function_exists('iconv')) {
                $fixed = @iconv('UTF-8', 'UTF-8//IGNORE', $value);
                if ($fixed !== false) return $fixed;
            }
            return preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $value);
        }
    }
    return $value;
}

function emc_json_encode($data)
{
    $flags = 0;
    if (defined('JSON_UNESCAPED_UNICODE')) $flags |= JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    $json = json_encode($data, $flags);
    if ($json !== false && $json !== null) return $json;

    // 과거 로그에 잘못된 UTF-8 바이트가 섞여 있으면 json_encode()가 false를 반환한다.
    // 백업/응답이 빈 내용으로 저장되지 않도록 문자열을 정리한 뒤 재시도한다.
    $data = emc_utf8_sanitize_value($data);
    $json = json_encode($data, $flags);
    if ($json !== false && $json !== null) return $json;
    return '{}';
}

function emc_send_security_headers($content_type)
{
    if (headers_sent()) return;
    if ($content_type) header($content_type);
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: same-origin');
    header('X-Robots-Tag: noindex, nofollow');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
}

function emc_json($data, $status)
{
    if (!headers_sent()) {
        if (function_exists('http_response_code')) http_response_code($status);
        emc_send_security_headers('Content-Type: application/json; charset=UTF-8');
    }
    echo emc_json_encode($data);
    exit;
}

function emc_log_dir()
{
    return __DIR__ . '/logs';
}

function emc_harden_private_dir($dir)
{
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_dir($dir)) return false;
    $ht = "# Esils Chat private directory\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n";
    @file_put_contents($dir . '/.htaccess', $ht);
    @file_put_contents($dir . '/index.html', '');
    @file_put_contents($dir . '/web.config', '<?xml version="1.0" encoding="UTF-8"?><configuration><system.webServer><security><requestFiltering><hiddenSegments><add segment="." /></hiddenSegments></requestFiltering></security></system.webServer></configuration>');
    return true;
}

function emc_log_error($context, $message)
{
    $dir = emc_log_dir();
    emc_harden_private_dir($dir);
    if (!is_dir($dir) || !is_writable($dir)) return;
    $file = $dir . '/error.log';
    if (is_file($file) && @filesize($file) > 1048576) {
        @rename($file, $dir . '/error-' . date('Ymd-His') . '.log');
    }
    $line = '[' . date('Y-m-d H:i:s') . '] ' . preg_replace('/[^a-zA-Z0-9_\-.]/', '_', (string)$context) . ' ' . str_replace(array("\r", "\n"), ' ', (string)$message) . "\n";
    @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}

function emc_api_fail($safe_message, $status, $context, $debug_message)
{
    if ($debug_message !== '') emc_log_error($context, $debug_message);
    $data = array('ok' => false, 'error' => $safe_message);
    // 운영 보안을 위해 상세 오류는 API 응답에 노출하지 않고 logs/error.log에만 기록한다.
    emc_json($data, $status);
}

function emc_h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function emc_get($source, $key, $default)
{
    if (is_array($source) && array_key_exists($key, $source)) return $source[$key];
    if (is_object($source) && isset($source->{$key})) return $source->{$key};
    return $default;
}

function emc_db_config()
{
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    // Rhymix 2.x 기본 설정 파일(files/config/config.php)을 우선 사용한다.
    if (class_exists('Rhymix\Framework\Config')) {
        $master = Rhymix\Framework\Config::get('db.master');
        if (is_array($master) && !empty($master['database'])) {
            $cfg = array(
                'host'    => isset($master['host']) ? (string)$master['host'] : 'localhost',
                'port'    => isset($master['port']) ? (int)$master['port'] : 3306,
                'user'    => isset($master['user']) ? (string)$master['user'] : '',
                'pass'    => isset($master['pass']) ? (string)$master['pass'] : '',
                'name'    => isset($master['database']) ? (string)$master['database'] : '',
                'prefix'  => isset($master['prefix']) ? (string)$master['prefix'] : 'rx_',
                'charset' => isset($master['charset']) ? (string)$master['charset'] : 'utf8mb4'
            );
            return $cfg;
        }
    }

    // Rhymix 설정 클래스를 사용할 수 없는 직접 실행 환경을 대비해 config.php를 직접 읽는다.
    $root = emc_xe_root();
    $rx_config_file = $root . '/files/config/config.php';
    if (is_file($rx_config_file)) {
        $rx_config = include $rx_config_file;
        if (is_array($rx_config) && isset($rx_config['db']['master']) && is_array($rx_config['db']['master'])) {
            $master = $rx_config['db']['master'];
            $cfg = array(
                'host'    => isset($master['host']) ? (string)$master['host'] : 'localhost',
                'port'    => isset($master['port']) ? (int)$master['port'] : 3306,
                'user'    => isset($master['user']) ? (string)$master['user'] : '',
                'pass'    => isset($master['pass']) ? (string)$master['pass'] : '',
                'name'    => isset($master['database']) ? (string)$master['database'] : '',
                'prefix'  => isset($master['prefix']) ? (string)$master['prefix'] : 'rx_',
                'charset' => isset($master['charset']) ? (string)$master['charset'] : 'utf8mb4'
            );
            return $cfg;
        }
    }

    // XE Core 1.11.x 및 이전 형식 호환.
    $file = $root . '/files/config/db.config.php';
    if (!is_file($file)) {
        emc_json(array('ok' => false, 'error' => 'Rhymix/XE DB 설정 파일 files/config/config.php 또는 files/config/db.config.php 를 찾을 수 없습니다.'), 500);
    }

    $db_info = null;
    require $file;
    if (!$db_info) {
        emc_json(array('ok' => false, 'error' => 'Rhymix/XE DB 설정을 읽을 수 없습니다.'), 500);
    }

    $master = emc_get($db_info, 'master_db', null);
    if (is_array($master) && isset($master[0])) $master = $master[0];

    $cfg = array(
        'host'    => emc_get($master, 'db_hostname', 'localhost'),
        'port'    => (int)emc_get($master, 'db_port', 3306),
        'user'    => emc_get($master, 'db_userid', ''),
        'pass'    => emc_get($master, 'db_password', ''),
        'name'    => emc_get($master, 'db_database', ''),
        'prefix'  => emc_get($master, 'db_table_prefix', emc_get($db_info, 'db_table_prefix', 'xe_')),
        'charset' => emc_get($master, 'db_charset', 'utf8mb4')
    );
    return $cfg;
}

function emc_db()
{
    static $mysqli = null;
    if ($mysqli instanceof mysqli) return $mysqli;

    if (function_exists('mysqli_report')) {
        mysqli_report(MYSQLI_REPORT_OFF);
    }
    $cfg = emc_db_config();
    if (!class_exists('mysqli')) {
        emc_json(array('ok' => false, 'error' => 'PHP mysqli 확장이 필요합니다.'), 500);
    }
    $port = !empty($cfg['port']) ? (int)$cfg['port'] : 3306;
    $mysqli = @new mysqli($cfg['host'], $cfg['user'], $cfg['pass'], $cfg['name'], $port);
    if ($mysqli->connect_errno) {
        emc_json(array('ok' => false, 'error' => 'DB 접속 실패: ' . $mysqli->connect_error), 500);
    }
    $charset = !empty($cfg['charset']) ? $cfg['charset'] : 'utf8mb4';
    if (!@$mysqli->set_charset($charset)) {
        if (!@$mysqli->set_charset('utf8mb4')) @$mysqli->set_charset('utf8');
    }
    return $mysqli;
}

function emc_table($name)
{
    $cfg = emc_db_config();
    $prefix = preg_replace('/[^a-zA-Z0-9_]/', '', $cfg['prefix']);
    return '`' . $prefix . $name . '`';
}

function emc_raw_table($name)
{
    $cfg = emc_db_config();
    $prefix = preg_replace('/[^a-zA-Z0-9_]/', '', $cfg['prefix']);
    return $prefix . $name;
}


function emc_table_exists($name)
{
    static $cache = array();
    $raw = emc_raw_table($name);
    if (array_key_exists($raw, $cache)) return $cache[$raw];
    $db = emc_db();
    $stmt = $db->prepare('SHOW TABLES LIKE ?');
    if (!$stmt) { $cache[$raw] = false; return false; }
    $stmt->bind_param('s', $raw);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();
    $cache[$raw] = $exists;
    return $exists;
}


function emc_sql_table_name($name)
{
    return '`' . str_replace('`', '``', emc_raw_table($name)) . '`';
}

function emc_column_exists($table_name, $column)
{
    $db = emc_db();
    $column = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$column);
    if ($column === '') return false;
    $sql = 'SHOW COLUMNS FROM ' . emc_sql_table_name($table_name) . ' LIKE ?';
    $stmt = $db->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('s', $column);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();
    return $exists;
}

function emc_add_column_if_missing($table_name, $column, $definition)
{
    if (emc_column_exists($table_name, $column)) return true;
    $db = emc_db();
    $column = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$column);
    if ($column === '') return false;
    return @$db->query('ALTER TABLE ' . emc_sql_table_name($table_name) . ' ADD `' . $column . '` ' . $definition) ? true : false;
}

function emc_add_index_silent($table_name, $index_sql)
{
    $db = emc_db();
    @ $db->query('ALTER TABLE ' . emc_sql_table_name($table_name) . ' ADD ' . $index_sql);
}

function emc_primary_columns($table_name)
{
    $db = emc_db();
    $cols = array();
    $res = @ $db->query('SHOW INDEX FROM ' . emc_sql_table_name($table_name) . " WHERE Key_name = 'PRIMARY'");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $seq = isset($row['Seq_in_index']) ? (int)$row['Seq_in_index'] : 0;
            $cols[$seq] = isset($row['Column_name']) ? $row['Column_name'] : '';
        }
        $res->free();
    }
    ksort($cols);
    return array_values($cols);
}

function emc_rebuild_presence_table()
{
    // presence는 현재 접속자 표시용 임시 테이블이므로 데이터 보존보다 스키마 안정성이 우선이다.
    $db = emc_db();
    $table = emc_table('esils_chat_presence');
    @ $db->query("DROP TABLE IF EXISTS {$table}");
    @ $db->query("CREATE TABLE IF NOT EXISTS {$table} (
        room_id VARCHAR(64) NOT NULL DEFAULT 'main',
        client_key VARCHAR(96) NOT NULL,
        member_srl BIGINT NOT NULL DEFAULT 0,
        nick_name VARCHAR(80) NOT NULL,
        last_seen CHAR(14) NOT NULL,
        ipaddress VARCHAR(45) DEFAULT NULL,
        PRIMARY KEY (room_id, client_key),
        KEY idx_room_last_seen (room_id, last_seen),
        KEY idx_last_seen (last_seen),
        KEY idx_member_srl (member_srl)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function emc_ensure_presence_table_ready()
{
    // 관리자 페이지나 채팅 API를 먼저 열어도 접속자 테이블이 없어서 로그가 반복 생성되지 않게 한다.
    // presence는 임시 상태 테이블이라 CREATE IF NOT EXISTS를 매 요청 1회 실행해도 데이터 정합성 문제가 없다.
    static $checked = false;
    if ($checked) return true;
    $checked = true;

    $db = emc_db();
    $table = emc_table('esils_chat_presence');
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        room_id VARCHAR(64) NOT NULL DEFAULT 'main',
        client_key VARCHAR(96) NOT NULL,
        member_srl BIGINT NOT NULL DEFAULT 0,
        nick_name VARCHAR(80) NOT NULL,
        last_seen CHAR(14) NOT NULL,
        ipaddress VARCHAR(45) DEFAULT NULL,
        PRIMARY KEY (room_id, client_key),
        KEY idx_room_last_seen (room_id, last_seen),
        KEY idx_last_seen (last_seen),
        KEY idx_member_srl (member_srl)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    if (!@ $db->query($sql)) {
        $sql2 = str_replace('DEFAULT CHARSET=utf8mb4', 'DEFAULT CHARSET=utf8', $sql);
        if (!@ $db->query($sql2)) {
            emc_log_error('presence_table_create', $db->error);
            return false;
        }
    }
    return true;
}

function emc_migrate_presence_schema()
{
    static $done = false;
    if ($done) return;
    $done = true;

    if (!emc_ensure_presence_table_ready()) return;
    if (!emc_table_exists('esils_chat_presence')) {
        emc_rebuild_presence_table();
        return;
    }

    $db = emc_db();
    $table = emc_sql_table_name('esils_chat_presence');

    emc_add_column_if_missing('esils_chat_presence', 'room_id', "VARCHAR(64) NOT NULL DEFAULT 'main'");
    emc_add_column_if_missing('esils_chat_presence', 'client_key', "VARCHAR(96) NOT NULL DEFAULT ''");
    emc_add_column_if_missing('esils_chat_presence', 'ipaddress', "VARCHAR(45) DEFAULT NULL");

    @ $db->query("UPDATE {$table} SET room_id = 'main' WHERE room_id = '' OR room_id IS NULL");
    @ $db->query("UPDATE {$table} SET client_key = CONCAT('m:', member_srl) WHERE (client_key = '' OR client_key IS NULL) AND member_srl > 0");
    @ $db->query("UPDATE {$table} SET client_key = CONCAT('g:', MD5(CONCAT(IFNULL(ipaddress,''), '|', IFNULL(nick_name,''), '|', last_seen))) WHERE client_key = '' OR client_key IS NULL");

    $primary = emc_primary_columns('esils_chat_presence');
    if ($primary !== array('room_id', 'client_key')) {
        @ $db->query("ALTER TABLE {$table} DROP PRIMARY KEY");
        @ $db->query("ALTER TABLE {$table} ADD PRIMARY KEY (room_id, client_key)");
        $primary = emc_primary_columns('esils_chat_presence');
    }

    // 과거 버전의 member_srl 단일 PRIMARY KEY 또는 깨진 인덱스가 남아 있으면 접속자 수가 0으로 고정될 수 있다.
    // 이 테이블은 임시 상태만 저장하므로, 스키마가 불안정하면 안전하게 재생성한다.
    if ($primary !== array('room_id', 'client_key')) {
        emc_log_error('presence_schema', 'presence table schema was incompatible; table rebuilt');
        emc_rebuild_presence_table();
        return;
    }

    emc_add_index_silent('esils_chat_presence', 'KEY idx_room_last_seen (room_id, last_seen)');
    emc_add_index_silent('esils_chat_presence', 'KEY idx_last_seen (last_seen)');
    emc_add_index_silent('esils_chat_presence', 'KEY idx_member_srl (member_srl)');
}

function emc_ensure_schema()
{
    static $done = false;
    if ($done) return;
    $done = true;
    if (!emc_table_exists('esils_chat_settings') || !emc_table_exists('esils_chat_messages')) {
        emc_install_schema();
    }
}

function emc_now()
{
    return date('YmdHis');
}

function emc_today()
{
    return date('Ymd');
}

function emc_client_ip()
{
    if (!empty($_SERVER['REMOTE_ADDR'])) return $_SERVER['REMOTE_ADDR'];
    return '';
}

function emc_clean_room($room)
{
    $room = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$room);
    return $room ? substr($room, 0, 64) : EMC_ROOM_DEFAULT;
}

function emc_sanitize_css_length($value, $default, $min_px, $max_px, $allow_percent)
{
    $value = trim(strtolower((string)$value));
    $default = trim((string)$default);
    if ($value === '') $value = $default;
    $value = preg_replace('/\s+/', '', $value);

    if ($allow_percent && preg_match('/^(\d{1,3})(?:\.(\d{1,2}))?%$/', $value, $m)) {
        $num = (float)($m[1] . (isset($m[2]) && $m[2] !== '' ? '.' . $m[2] : ''));
        if ($num < 5) $num = 5;
        if ($num > 100) $num = 100;
        $out = rtrim(rtrim(number_format($num, 2, '.', ''), '0'), '.');
        return $out . '%';
    }

    if (preg_match('/^(\d{1,5})(?:px)?$/', $value, $m)) {
        $num = (int)$m[1];
        if ($num < $min_px) $num = $min_px;
        if ($num > $max_px) $num = $max_px;
        return (string)$num;
    }

    if ($value !== $default) {
        return emc_sanitize_css_length($default, '', $min_px, $max_px, $allow_percent);
    }
    return (string)$min_px;
}

function emc_css_length_for_style($value, $default, $min_px, $max_px, $allow_percent)
{
    $v = emc_sanitize_css_length($value, $default, $min_px, $max_px, $allow_percent);
    return preg_match('/%$/', $v) ? $v : $v . 'px';
}

function emc_logged_info()
{
    $info = null;
    $is_logged = false;

    if (class_exists('Context')) {
        $is_logged = (bool)Context::get('is_logged');
        $info = Context::get('logged_info');
    }

    // XE 1.x 직접 실행 경로(admin.php/api.php)에서 Context 초기화가 충분하지 않은 경우 세션값을 보조로 사용한다.
    if ((!$info || empty($info->member_srl)) && !empty($_SESSION['logged_info']) && is_object($_SESSION['logged_info'])) {
        $info = $_SESSION['logged_info'];
        $is_logged = !empty($info->member_srl);
    }

    if (!$is_logged || !$info || empty($info->member_srl)) return null;
    return $info;
}

function emc_is_admin($info)
{
    return $info && isset($info->is_admin) && $info->is_admin === 'Y';
}

function emc_parse_member_srls($value)
{
    $items = preg_split('/[^0-9]+/', (string)$value, -1, PREG_SPLIT_NO_EMPTY);
    $out = array();
    foreach ($items as $item) {
        $srl = (int)$item;
        if ($srl > 0) $out[$srl] = $srl;
    }
    return array_values($out);
}

function emc_get_sub_admin_srls()
{
    return emc_parse_member_srls(emc_get_setting('sub_admin_members', ''));
}

function emc_set_sub_admin_srls($srls)
{
    $clean = array();
    foreach ((array)$srls as $srl) {
        $srl = (int)$srl;
        if ($srl > 0) $clean[$srl] = $srl;
    }
    ksort($clean);
    return emc_set_setting('sub_admin_members', implode(',', $clean));
}

function emc_is_chat_subadmin($info)
{
    if (!$info || empty($info->member_srl)) return false;
    if (emc_is_admin($info)) return false;
    return in_array((int)$info->member_srl, emc_get_sub_admin_srls(), true);
}

function emc_can_manage_chat($info)
{
    return emc_is_admin($info) || emc_is_chat_subadmin($info);
}

function emc_require_chat_manager()
{
    $info = emc_logged_info();
    if (!emc_can_manage_chat($info)) {
        header('Content-Type: text/html; charset=UTF-8');
        echo '<!doctype html><meta charset="UTF-8"><title>Esils Chat 관리자</title><div style="font-family:sans-serif;padding:30px">채팅 관리자 권한이 필요합니다.</div>';
        exit;
    }
    return $info;
}

function emc_get_members_by_srl($srls)
{
    $srls = emc_parse_member_srls(implode(',', (array)$srls));
    if (!$srls) return array();
    $db = emc_db();
    $table = emc_table('member');
    $ids = implode(',', array_map('intval', $srls));
    $sql = "SELECT member_srl, user_id, user_name, nick_name, email_address FROM {$table} WHERE member_srl IN ({$ids}) ORDER BY nick_name ASC, member_srl ASC";
    $res = @$db->query($sql);
    $rows = array();
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $rows[(int)$row['member_srl']] = $row;
        }
        $res->free();
    }
    return $rows;
}

function emc_search_members($query, $limit)
{
    $query = trim((string)$query);
    if ($query === '') return array();
    $limit = max(1, min(50, (int)$limit));
    $db = emc_db();
    $table = emc_table('member');
    $like = '%' . $query . '%';
    $srl = ctype_digit($query) ? (int)$query : 0;
    $sql = "SELECT member_srl, user_id, user_name, nick_name, email_address FROM {$table} WHERE member_srl = ? OR user_id LIKE ? OR user_name LIKE ? OR nick_name LIKE ? OR email_address LIKE ? ORDER BY member_srl DESC LIMIT ?";
    $stmt = $db->prepare($sql);
    if (!$stmt) return array();
    $stmt->bind_param('issssi', $srl, $like, $like, $like, $like, $limit);
    $stmt->execute();
    $stmt->bind_result($member_srl, $user_id, $user_name, $nick_name, $email_address);
    $rows = array();
    while ($stmt->fetch()) {
        $rows[] = array(
            'member_srl' => (int)$member_srl,
            'user_id' => $user_id,
            'user_name' => $user_name,
            'nick_name' => $nick_name,
            'email_address' => $email_address,
        );
    }
    $stmt->close();
    return $rows;
}

function emc_require_admin()
{
    $info = emc_logged_info();
    if (!emc_is_admin($info)) {
        header('Content-Type: text/html; charset=UTF-8');
        echo '<!doctype html><meta charset="UTF-8"><title>Esils Chat 관리자</title><div style="font-family:sans-serif;padding:30px">XE 관리자 로그인 후 이용할 수 있습니다.</div>';
        exit;
    }
    return $info;
}

function emc_member_name($info)
{
    if (!$info) return '';
    if (isset($info->nick_name) && $info->nick_name !== '') return $info->nick_name;
    if (isset($info->user_id) && $info->user_id !== '') return $info->user_id;
    return '회원';
}

function emc_strlen($text)
{
    return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
}

function emc_substr($text, $start, $length)
{
    return function_exists('mb_substr') ? mb_substr($text, $start, $length, 'UTF-8') : substr($text, $start, $length);
}

function emc_hash_equals($known, $user)
{
    if (function_exists('hash_equals')) return hash_equals($known, $user);
    if (!is_string($known) || !is_string($user) || strlen($known) !== strlen($user)) return false;
    $res = 0;
    for ($i = 0, $len = strlen($known); $i < $len; $i++) $res |= ord($known[$i]) ^ ord($user[$i]);
    return $res === 0;
}

function emc_create_token()
{
    if (empty($_SESSION['emc_chat_token'])) {
        if (function_exists('random_bytes')) {
            $_SESSION['emc_chat_token'] = bin2hex(random_bytes(16));
        } else {
            $_SESSION['emc_chat_token'] = sha1(uniqid('', true) . mt_rand());
        }
    }
    return $_SESSION['emc_chat_token'];
}

function emc_check_token_json()
{
    $token = isset($_SERVER['HTTP_X_ESILS_CHAT_TOKEN']) ? $_SERVER['HTTP_X_ESILS_CHAT_TOKEN'] : '';
    if (!$token && isset($_POST['token'])) $token = $_POST['token'];
    if (empty($_SESSION['emc_chat_token']) || !emc_hash_equals($_SESSION['emc_chat_token'], $token)) {
        emc_json(array('ok' => false, 'error' => '요청 토큰이 올바르지 않습니다. 페이지를 새로고침 해주세요.'), 403);
    }
}

function emc_check_token_admin()
{
    $token = isset($_POST['token']) ? $_POST['token'] : '';
    return !empty($_SESSION['emc_chat_token']) && emc_hash_equals($_SESSION['emc_chat_token'], $token);
}

function emc_default_settings()
{
    return array(
        'title' => '회원 채팅',
        'allow_guest_chat' => 'N',
        'default_collapsed' => 'N',
        'max_width' => '220',
        'height' => '190',
        'flood_seconds' => '2',
        'poll_normal_seconds' => '5',
        'poll_active_seconds' => '3',
        'poll_active_duration_seconds' => '30',
        'refresh_after_send' => 'Y',
        'max_length' => '500',
        'guest_label' => '비회원',
        'show_admin_link' => 'Y',
        'backup_enabled' => 'Y',
        'backup_file_enabled' => 'N',
        'backup_retention_days' => '30',
        'log_retention_days' => '365',
        'rate_limit_member_per_minute' => '15',
        'rate_limit_ip_per_minute' => '10',
        'same_text_seconds' => '20',
        'sub_admin_members' => '',
        'auto_backup_last_date' => ''
    );
}


function emc_clamp_seconds_value($value, $default, $min, $max)
{
    if ($value === '' || $value === null) $value = $default;
    $n = (int)$value;
    if ($n < $min) $n = $min;
    if ($n > $max) $n = $max;
    return (string)$n;
}

function emc_normalize_settings_array($settings)
{
    $defaults = emc_default_settings();
    if (!is_array($settings)) $settings = array();
    foreach ($defaults as $k => $v) {
        if (!array_key_exists($k, $settings)) $settings[$k] = $v;
    }
    $settings['flood_seconds'] = emc_clamp_seconds_value($settings['flood_seconds'], $defaults['flood_seconds'], 1, 60);
    $settings['poll_normal_seconds'] = emc_clamp_seconds_value($settings['poll_normal_seconds'], $defaults['poll_normal_seconds'], 1, 60);
    $settings['poll_active_seconds'] = emc_clamp_seconds_value($settings['poll_active_seconds'], $defaults['poll_active_seconds'], 1, 60);
    $settings['poll_active_duration_seconds'] = emc_clamp_seconds_value($settings['poll_active_duration_seconds'], $defaults['poll_active_duration_seconds'], 1, 300);
    if ((int)$settings['poll_active_seconds'] > (int)$settings['poll_normal_seconds']) {
        $settings['poll_active_seconds'] = $settings['poll_normal_seconds'];
    }
    $settings['refresh_after_send'] = (isset($settings['refresh_after_send']) && $settings['refresh_after_send'] === 'N') ? 'N' : 'Y';
    $settings['flood_seconds'] = (string)max(1, (int)$settings['flood_seconds']);
    return $settings;
}

function emc_install_schema()
{
    $db = emc_db();
    $msg_table = emc_table('esils_chat_messages');
    $presence_table = emc_table('esils_chat_presence');
    $settings_table = emc_table('esils_chat_settings');
    $blocks_table = emc_table('esils_chat_blocks');
    $backups_table = emc_table('esils_chat_backups');
    $rooms_table = emc_table('esils_chat_rooms');

    $sql = array();
    $sql[] = "CREATE TABLE IF NOT EXISTS {$msg_table} (
        message_srl BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        room_id VARCHAR(64) NOT NULL DEFAULT 'main',
        member_srl BIGINT NOT NULL DEFAULT 0,
        nick_name VARCHAR(80) NOT NULL,
        content TEXT NOT NULL,
        ipaddress VARCHAR(45) DEFAULT NULL,
        regdate CHAR(14) NOT NULL,
        is_deleted CHAR(1) NOT NULL DEFAULT 'N',
        PRIMARY KEY (message_srl),
        KEY idx_room_message (room_id, message_srl),
        KEY idx_member_srl (member_srl),
        KEY idx_ipaddress (ipaddress),
        KEY idx_regdate (regdate)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    $sql[] = "CREATE TABLE IF NOT EXISTS {$presence_table} (
        room_id VARCHAR(64) NOT NULL DEFAULT 'main',
        client_key VARCHAR(96) NOT NULL,
        member_srl BIGINT NOT NULL DEFAULT 0,
        nick_name VARCHAR(80) NOT NULL,
        last_seen CHAR(14) NOT NULL,
        ipaddress VARCHAR(45) DEFAULT NULL,
        PRIMARY KEY (room_id, client_key),
        KEY idx_room_last_seen (room_id, last_seen),
        KEY idx_last_seen (last_seen),
        KEY idx_member_srl (member_srl)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    $sql[] = "CREATE TABLE IF NOT EXISTS {$settings_table} (
        setting_key VARCHAR(64) NOT NULL,
        setting_value TEXT NOT NULL,
        updated_regdate CHAR(14) NOT NULL,
        PRIMARY KEY (setting_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    $sql[] = "CREATE TABLE IF NOT EXISTS {$blocks_table} (
        block_srl BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        room_id VARCHAR(64) NOT NULL DEFAULT '_all',
        target_type VARCHAR(16) NOT NULL,
        target_value VARCHAR(128) NOT NULL,
        nick_name VARCHAR(80) DEFAULT NULL,
        reason VARCHAR(255) DEFAULT NULL,
        start_regdate CHAR(14) NOT NULL,
        expire_regdate CHAR(14) NOT NULL DEFAULT '00000000000000',
        created_member_srl BIGINT NOT NULL DEFAULT 0,
        created_nick_name VARCHAR(80) DEFAULT NULL,
        is_active CHAR(1) NOT NULL DEFAULT 'Y',
        PRIMARY KEY (block_srl),
        KEY idx_target (target_type, target_value),
        KEY idx_room_target (room_id, target_type, target_value),
        KEY idx_active_expire (is_active, expire_regdate)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    $sql[] = "CREATE TABLE IF NOT EXISTS {$backups_table} (
        backup_srl BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        backup_date CHAR(8) NOT NULL,
        room_id VARCHAR(64) NOT NULL DEFAULT '_all',
        message_count INT UNSIGNED NOT NULL DEFAULT 0,
        backup_json LONGTEXT NOT NULL,
        file_path VARCHAR(255) DEFAULT NULL,
        file_ok CHAR(1) NOT NULL DEFAULT 'N',
        regdate CHAR(14) NOT NULL,
        PRIMARY KEY (backup_srl),
        UNIQUE KEY uniq_backup (backup_date, room_id),
        KEY idx_backup_date (backup_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    $sql[] = "CREATE TABLE IF NOT EXISTS {$rooms_table} (
        room_id VARCHAR(64) NOT NULL,
        room_title VARCHAR(120) NOT NULL DEFAULT '',
        is_enabled CHAR(1) NOT NULL DEFAULT 'Y',
        allow_guest_chat VARCHAR(1) NOT NULL DEFAULT '',
        default_collapsed VARCHAR(1) NOT NULL DEFAULT '',
        max_width VARCHAR(32) NOT NULL DEFAULT '',
        height VARCHAR(32) NOT NULL DEFAULT '',
        flood_seconds VARCHAR(8) NOT NULL DEFAULT '',
        max_length VARCHAR(8) NOT NULL DEFAULT '',
        show_admin_link VARCHAR(1) NOT NULL DEFAULT '',
        room_note VARCHAR(255) DEFAULT NULL,
        created_regdate CHAR(14) NOT NULL,
        updated_regdate CHAR(14) NOT NULL,
        PRIMARY KEY (room_id),
        KEY idx_enabled (is_enabled)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";



    $results = array();
    foreach ($sql as $s) {
        $ok = $db->query($s);
        if (!$ok) {
            $s2 = str_replace('DEFAULT CHARSET=utf8mb4', 'DEFAULT CHARSET=utf8', $s);
            $ok = $db->query($s2);
        }
        $results[] = array('ok' => $ok ? true : false, 'error' => $ok ? '' : $db->error);
    }

    // presence는 현재 접속 상태용 임시 테이블이지만, 일반 관리자/설치 페이지 접근 때 초기화하면 접속자 수가 1로 고정될 수 있다.
    // 스키마가 깨진 경우에만 emc_migrate_presence_schema() 내부에서 재생성한다.
    emc_migrate_presence_schema();
    emc_add_column_if_missing('esils_chat_blocks', 'room_id', "VARCHAR(64) NOT NULL DEFAULT '_all'");
    emc_add_index_silent('esils_chat_blocks', 'KEY idx_room_target (room_id, target_type, target_value)');
    emc_add_index_silent('esils_chat_messages', 'KEY idx_member_regdate (member_srl, regdate)');
    emc_add_index_silent('esils_chat_messages', 'KEY idx_ip_regdate (ipaddress, regdate)');
    emc_harden_backup_dir();
    emc_register_room(EMC_ROOM_DEFAULT, '회원 채팅');

    $defaults = emc_default_settings();
    foreach ($defaults as $k => $v) {
        emc_setting_init($k, $v);
    }
    return $results;
}

function emc_setting_init($key, $value)
{
    $db = emc_db();
    $table = emc_table('esils_chat_settings');
    $now = emc_now();
    $stmt = $db->prepare("INSERT IGNORE INTO {$table} (setting_key, setting_value, updated_regdate) VALUES (?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param('sss', $key, $value, $now);
        $stmt->execute();
        $stmt->close();
    }
}

function emc_get_setting($key, $default)
{
    static $cache = null;
    if ($cache === null) $cache = emc_get_settings();
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function emc_get_settings()
{
    emc_ensure_schema();
    emc_migrate_presence_schema();
    emc_add_column_if_missing('esils_chat_blocks', 'room_id', "VARCHAR(64) NOT NULL DEFAULT '_all'");
    emc_add_index_silent('esils_chat_blocks', 'KEY idx_room_target (room_id, target_type, target_value)');
    emc_add_index_silent('esils_chat_messages', 'KEY idx_member_regdate (member_srl, regdate)');
    emc_add_index_silent('esils_chat_messages', 'KEY idx_ip_regdate (ipaddress, regdate)');
    emc_harden_backup_dir();
    emc_register_room(EMC_ROOM_DEFAULT, '회원 채팅');

    $defaults = emc_default_settings();
    $values = $defaults;
    $db = emc_db();
    $table = emc_table('esils_chat_settings');
    $sql = "SELECT setting_key, setting_value FROM {$table}";
    $res = @$db->query($sql);
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $values[$row['setting_key']] = $row['setting_value'];
        }
        $res->free();
    }
    return emc_normalize_settings_array($values);
}

function emc_set_setting($key, $value)
{
    $db = emc_db();
    $table = emc_table('esils_chat_settings');
    $now = emc_now();
    $stmt = $db->prepare("REPLACE INTO {$table} (setting_key, setting_value, updated_regdate) VALUES (?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param('sss', $key, $value, $now);
        $stmt->execute();
        $stmt->close();
        return true;
    }
    return false;
}

function emc_bool_setting($key)
{
    return emc_get_setting($key, 'N') === 'Y';
}

function emc_regdate_to_time($regdate)
{
    if (!preg_match('/^\d{14}$/', $regdate)) return 0;
    return strtotime(substr($regdate,0,4) . '-' . substr($regdate,4,2) . '-' . substr($regdate,6,2) . ' ' . substr($regdate,8,2) . ':' . substr($regdate,10,2) . ':' . substr($regdate,12,2));
}

function emc_time_to_regdate($timestamp)
{
    if (!$timestamp || $timestamp <= 0) return '00000000000000';
    return date('YmdHis', $timestamp);
}


function emc_room_row_default($room_id)
{
    return array(
        'room_id' => emc_clean_room($room_id),
        'room_title' => '',
        'is_enabled' => 'Y',
        'allow_guest_chat' => '',
        'default_collapsed' => '',
        'max_width' => '',
        'height' => '',
        'flood_seconds' => '',
        'max_length' => '',
        'show_admin_link' => '',
        'room_note' => '',
        'created_regdate' => emc_now(),
        'updated_regdate' => emc_now()
    );
}

function emc_room_exists($room_id)
{
    $room_id = emc_clean_room($room_id);
    $db = emc_db();
    $table = emc_table('esils_chat_rooms');
    $cnt = 0;
    $stmt = $db->prepare("SELECT COUNT(*) FROM {$table} WHERE room_id = ?");
    if (!$stmt) return false;
    $stmt->bind_param('s', $room_id);
    $stmt->execute();
    $stmt->bind_result($cnt);
    $stmt->fetch();
    $stmt->close();
    return ((int)$cnt) > 0;
}

function emc_register_room($room_id, $title)
{
    $room_id = emc_clean_room($room_id);
    if ($room_id === '') $room_id = EMC_ROOM_DEFAULT;
    $title = trim((string)$title);
    $db = emc_db();
    $table = emc_table('esils_chat_rooms');
    $now = emc_now();
    $stmt = $db->prepare("INSERT IGNORE INTO {$table} (room_id, room_title, is_enabled, created_regdate, updated_regdate) VALUES (?, ?, 'Y', ?, ?)");
    if ($stmt) {
        $stmt->bind_param('ssss', $room_id, $title, $now, $now);
        $stmt->execute();
        $stmt->close();
    }
    if ($title !== '') {
        $stmt = $db->prepare("UPDATE {$table} SET room_title = IF(room_title = '', ?, room_title), updated_regdate = updated_regdate WHERE room_id = ?");
        if ($stmt) {
            $stmt->bind_param('ss', $title, $room_id);
            $stmt->execute();
            $stmt->close();
        }
    }
    return $room_id;
}

function emc_get_room($room_id)
{
    $room_id = emc_clean_room($room_id);
    $db = emc_db();
    $table = emc_table('esils_chat_rooms');
    $stmt = $db->prepare("SELECT room_id, room_title, is_enabled, allow_guest_chat, default_collapsed, max_width, height, flood_seconds, max_length, show_admin_link, room_note, created_regdate, updated_regdate FROM {$table} WHERE room_id = ?");
    if (!$stmt) return null;
    $stmt->bind_param('s', $room_id);
    $stmt->execute();
    $stmt->bind_result($r_room_id, $room_title, $is_enabled, $allow_guest_chat, $default_collapsed, $max_width, $height, $flood_seconds, $max_length, $show_admin_link, $room_note, $created_regdate, $updated_regdate);
    $row = null;
    if ($stmt->fetch()) {
        $row = array(
            'room_id' => $r_room_id,
            'room_title' => $room_title,
            'is_enabled' => $is_enabled,
            'allow_guest_chat' => $allow_guest_chat,
            'default_collapsed' => $default_collapsed,
            'max_width' => $max_width,
            'height' => $height,
            'flood_seconds' => $flood_seconds,
            'max_length' => $max_length,
            'show_admin_link' => $show_admin_link,
            'room_note' => $room_note,
            'created_regdate' => $created_regdate,
            'updated_regdate' => $updated_regdate
        );
    }
    $stmt->close();
    return $row;
}

function emc_save_room($data)
{
    $room_id = emc_clean_room(isset($data['room_id']) ? $data['room_id'] : '');
    if ($room_id === '') return false;
    $room_title = trim((string)(isset($data['room_title']) ? $data['room_title'] : ''));
    $is_enabled = (isset($data['is_enabled']) && $data['is_enabled'] === 'N') ? 'N' : 'Y';
    $allow_guest_chat = isset($data['allow_guest_chat']) && in_array($data['allow_guest_chat'], array('Y','N'), true) ? $data['allow_guest_chat'] : '';
    $default_collapsed = isset($data['default_collapsed']) && in_array($data['default_collapsed'], array('Y','N'), true) ? $data['default_collapsed'] : '';
    $max_width = trim((string)(isset($data['max_width']) ? $data['max_width'] : ''));
    if ($max_width !== '') $max_width = emc_sanitize_css_length($max_width, '220', 120, 2000, true);
    $height = trim((string)(isset($data['height']) ? $data['height'] : ''));
    if ($height !== '') $height = emc_sanitize_css_length($height, '190', 80, 1600, true);
    $flood_seconds = trim((string)(isset($data['flood_seconds']) ? $data['flood_seconds'] : ''));
    if ($flood_seconds !== '') $flood_seconds = (string)max(1, min(60, (int)$flood_seconds));
    $max_length = trim((string)(isset($data['max_length']) ? $data['max_length'] : ''));
    if ($max_length !== '') $max_length = (string)max(50, min(2000, (int)$max_length));
    $show_admin_link = isset($data['show_admin_link']) && in_array($data['show_admin_link'], array('Y','N'), true) ? $data['show_admin_link'] : '';
    $room_note = trim((string)(isset($data['room_note']) ? $data['room_note'] : ''));
    if (emc_strlen($room_note) > 255) $room_note = emc_substr($room_note, 0, 255);
    $now = emc_now();
    $created = $now;
    $db = emc_db();
    $table = emc_table('esils_chat_rooms');
    $stmt = $db->prepare("SELECT created_regdate FROM {$table} WHERE room_id = ?");
    if ($stmt) {
        $stmt->bind_param('s', $room_id);
        $stmt->execute();
        $stmt->bind_result($old_created);
        if ($stmt->fetch() && preg_match('/^\d{14}$/', $old_created)) $created = $old_created;
        $stmt->close();
    }
    $stmt = $db->prepare("REPLACE INTO {$table} (room_id, room_title, is_enabled, allow_guest_chat, default_collapsed, max_width, height, flood_seconds, max_length, show_admin_link, room_note, created_regdate, updated_regdate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) return false;
    $stmt->bind_param('sssssssssssss', $room_id, $room_title, $is_enabled, $allow_guest_chat, $default_collapsed, $max_width, $height, $flood_seconds, $max_length, $show_admin_link, $room_note, $created, $now);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok ? true : false;
}

function emc_get_effective_settings($room_id)
{
    $settings = emc_get_settings();
    $room = emc_get_room($room_id);
    if (!$room) return null;
    $effective = $settings;
    if (trim($room['room_title']) !== '') $effective['title'] = $room['room_title'];
    foreach (array('allow_guest_chat','default_collapsed','max_width','height','flood_seconds','max_length','show_admin_link') as $key) {
        if (isset($room[$key]) && trim((string)$room[$key]) !== '') $effective[$key] = $room[$key];
    }
    $effective = emc_normalize_settings_array($effective);
    $effective['_room'] = $room;
    $effective['room_id'] = $room['room_id'];
    $effective['room_enabled'] = $room['is_enabled'];
    return $effective;
}

function emc_require_room_json($room_id)
{
    $room_id = emc_clean_room($room_id);
    $settings = emc_get_effective_settings($room_id);
    if (!$settings) {
        emc_api_fail('등록되지 않은 채팅방입니다. 관리자에서 채팅방을 등록하거나 위젯 코드로 먼저 생성해야 합니다.', 403, 'room_not_registered', $room_id);
    }
    if ($settings['room_enabled'] !== 'Y') {
        emc_json(array('ok' => false, 'error' => '비활성화된 채팅방입니다.'), 403);
    }
    return $settings;
}

function emc_count_recent_messages($room, $field, $value, $seconds)
{
    $field = $field === 'member_srl' ? 'member_srl' : 'ipaddress';
    $db = emc_db();
    $table = emc_table('esils_chat_messages');
    $since = emc_time_to_regdate(time() - max(1, (int)$seconds));
    $cnt = 0;
    if ($field === 'member_srl') {
        $v = (int)$value;
        $stmt = $db->prepare("SELECT COUNT(*) FROM {$table} WHERE room_id = ? AND member_srl = ? AND regdate >= ? AND is_deleted = 'N'");
        if (!$stmt) return 0;
        $stmt->bind_param('sis', $room, $v, $since);
    } else {
        $v = (string)$value;
        $stmt = $db->prepare("SELECT COUNT(*) FROM {$table} WHERE room_id = ? AND ipaddress = ? AND regdate >= ? AND is_deleted = 'N'");
        if (!$stmt) return 0;
        $stmt->bind_param('sss', $room, $v, $since);
    }
    $stmt->execute();
    $stmt->bind_result($cnt);
    $stmt->fetch();
    $stmt->close();
    return (int)$cnt;
}

function emc_has_same_text_recent($room, $sender, $content, $seconds)
{
    $seconds = (int)$seconds;
    if ($seconds <= 0) return false;
    $db = emc_db();
    $table = emc_table('esils_chat_messages');
    $since = emc_time_to_regdate(time() - $seconds);
    $cnt = 0;
    if ((int)$sender['member_srl'] > 0) {
        $member_srl = (int)$sender['member_srl'];
        $stmt = $db->prepare("SELECT COUNT(*) FROM {$table} WHERE room_id = ? AND member_srl = ? AND content = ? AND regdate >= ? AND is_deleted = 'N'");
        if (!$stmt) return false;
        $stmt->bind_param('siss', $room, $member_srl, $content, $since);
    } else {
        $ip = $sender['ip'];
        $stmt = $db->prepare("SELECT COUNT(*) FROM {$table} WHERE room_id = ? AND ipaddress = ? AND content = ? AND regdate >= ? AND is_deleted = 'N'");
        if (!$stmt) return false;
        $stmt->bind_param('ssss', $room, $ip, $content, $since);
    }
    $stmt->execute();
    $stmt->bind_result($cnt);
    $stmt->fetch();
    $stmt->close();
    return ((int)$cnt) > 0;
}

function emc_cleanup_old_logs()
{
    $days = (int)emc_get_setting('log_retention_days', '365');
    if ($days <= 0) return;
    if ($days < 7) $days = 7;
    $cutoff = emc_time_to_regdate(time() - ($days * 86400));
    $db = emc_db();
    $table = emc_table('esils_chat_messages');
    @ $db->query("DELETE FROM {$table} WHERE regdate < '" . $db->real_escape_string($cutoff) . "'");
}

function emc_block_check($member_srl, $ip, $nick_name, $room)
{
    $db = emc_db();
    $table = emc_table('esils_chat_blocks');
    $now = emc_now();
    $m = (string)(int)$member_srl;
    $ip = (string)$ip;
    $nick_name = (string)$nick_name;
    $room = emc_clean_room($room);
    $all_room = '_all';

    $stmt = $db->prepare("SELECT block_srl, target_type, target_value, reason, expire_regdate FROM {$table}
        WHERE is_active = 'Y'
          AND (expire_regdate = '00000000000000' OR expire_regdate >= ?)
          AND (room_id = ? OR room_id = ?)
          AND ((target_type = 'member' AND target_value = ?) OR (target_type = 'ip' AND target_value = ?) OR (target_type = 'nick' AND target_value = ?))
        ORDER BY block_srl DESC LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param('ssssss', $now, $room, $all_room, $m, $ip, $nick_name);
    $stmt->execute();
    $stmt->bind_result($block_srl, $target_type, $target_value, $reason, $expire_regdate);
    $row = null;
    if ($stmt->fetch()) {
        $row = array(
            'block_srl' => (int)$block_srl,
            'target_type' => $target_type,
            'target_value' => $target_value,
            'reason' => $reason,
            'expire_regdate' => $expire_regdate
        );
    }
    $stmt->close();
    return $row;
}

function emc_block_message($block)
{
    if (!$block) return '';
    $reason = trim((string)$block['reason']);
    $expire = $block['expire_regdate'] === '00000000000000' ? '영구' : substr($block['expire_regdate'],0,4) . '-' . substr($block['expire_regdate'],4,2) . '-' . substr($block['expire_regdate'],6,2) . ' ' . substr($block['expire_regdate'],8,2) . ':' . substr($block['expire_regdate'],10,2);
    return '채팅이 차단되었습니다. 해제 시각: ' . $expire . ($reason ? ' / 사유: ' . $reason : '');
}

function emc_add_block($target_type, $target_value, $nick_name, $reason, $expire_regdate, $admin_info, $room_id)
{
    $target_type = preg_replace('/[^a-z]/', '', (string)$target_type);
    if (!in_array($target_type, array('member', 'ip', 'nick'))) return false;
    $target_value = trim((string)$target_value);
    if ($target_value === '') return false;
    $nick_name = trim((string)$nick_name);
    $reason = trim((string)$reason);
    if (!preg_match('/^\d{14}$/', $expire_regdate)) $expire_regdate = '00000000000000';
    $room_id = trim((string)$room_id) === '_all' ? '_all' : emc_clean_room($room_id);

    $db = emc_db();
    $table = emc_table('esils_chat_blocks');
    $start = emc_now();
    $created_member_srl = $admin_info ? (int)$admin_info->member_srl : 0;
    $created_nick = emc_member_name($admin_info);
    $stmt = $db->prepare("INSERT INTO {$table} (room_id, target_type, target_value, nick_name, reason, start_regdate, expire_regdate, created_member_srl, created_nick_name, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Y')");
    if (!$stmt) return false;
    $stmt->bind_param('sssssssis', $room_id, $target_type, $target_value, $nick_name, $reason, $start, $expire_regdate, $created_member_srl, $created_nick);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function emc_backup_dir()
{
    return __DIR__ . '/backups';
}

function emc_harden_backup_dir()
{
    $dir = emc_backup_dir();
    emc_harden_private_dir($dir);
    emc_harden_private_dir($dir . '/private');
    return is_dir($dir);
}

function emc_backup_public_path($date, $room)
{
    $safe_room = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $room);
    $suffix = substr(sha1($date . '|' . $safe_room . '|' . mt_rand() . '|' . microtime(true)), 0, 12);
    return 'backups/private/esils_chat_' . $date . '_' . $safe_room . '_' . $suffix . '.json';
}

function emc_backup_exists($date, $room)
{
    $db = emc_db();
    $table = emc_table('esils_chat_backups');
    $cnt = 0;
    $stmt = $db->prepare("SELECT COUNT(*) FROM {$table} WHERE backup_date = ? AND room_id = ?");
    if (!$stmt) return false;
    $stmt->bind_param('ss', $date, $room);
    $stmt->execute();
    $stmt->bind_result($cnt);
    $stmt->fetch();
    $stmt->close();
    return ((int)$cnt) > 0;
}

function emc_backup_date($date, $room, $force)
{
    if (!preg_match('/^\d{8}$/', $date)) return array('ok' => false, 'error' => '백업 날짜 형식이 올바르지 않습니다.');
    $room = $room === '_all' || $room === '' ? '_all' : emc_clean_room($room);
    if (!$force && emc_backup_exists($date, $room)) return array('ok' => true, 'skipped' => true, 'message_count' => 0);

    $db = emc_db();
    $msg_table = emc_table('esils_chat_messages');
    $like = $date . '%';
    $rows = array();

    if ($room === '_all') {
        $stmt = $db->prepare("SELECT message_srl, room_id, member_srl, nick_name, content, ipaddress, regdate, is_deleted FROM {$msg_table} WHERE regdate LIKE ? ORDER BY message_srl ASC");
        if (!$stmt) return array('ok' => false, 'error' => $db->error);
        $stmt->bind_param('s', $like);
    } else {
        $stmt = $db->prepare("SELECT message_srl, room_id, member_srl, nick_name, content, ipaddress, regdate, is_deleted FROM {$msg_table} WHERE regdate LIKE ? AND room_id = ? ORDER BY message_srl ASC");
        if (!$stmt) return array('ok' => false, 'error' => $db->error);
        $stmt->bind_param('ss', $like, $room);
    }
    $stmt->execute();
    $stmt->bind_result($message_srl, $room_id, $member_srl, $nick_name, $content, $ipaddress, $regdate, $is_deleted);
    while ($stmt->fetch()) {
        $rows[] = array(
            'message_srl' => (int)$message_srl,
            'room_id' => $room_id,
            'member_srl' => (int)$member_srl,
            'nick_name' => $nick_name,
            'content' => $content,
            'ipaddress' => $ipaddress,
            'regdate' => $regdate,
            'is_deleted' => $is_deleted
        );
    }
    $stmt->close();

    $payload = array(
        'type' => 'esils_chat_daily_backup',
        'version' => '1.6.4',
        'backup_date' => $date,
        'room_id' => $room,
        'generated_at' => emc_now(),
        'message_count' => count($rows),
        'messages' => $rows
    );
    $json = emc_json_encode($payload);
    $dir = emc_backup_dir();
    $file_rel = emc_backup_public_path($date, $room);
    $file_ok = 'N';
    emc_harden_backup_dir();
    if (emc_get_setting('backup_file_enabled', 'N') === 'Y' && is_dir($dir . '/private') && is_writable($dir . '/private')) {
        $written = @file_put_contents(__DIR__ . '/' . $file_rel, $json, LOCK_EX);
        if ($written !== false) $file_ok = 'Y';
    }

    $backup_table = emc_table('esils_chat_backups');
    $count = count($rows);
    $regdate = emc_now();
    $stmt = $db->prepare("REPLACE INTO {$backup_table} (backup_date, room_id, message_count, backup_json, file_path, file_ok, regdate) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) return array('ok' => false, 'error' => $db->error);
    $stmt->bind_param('ssissss', $date, $room, $count, $json, $file_rel, $file_ok, $regdate);
    $ok = $stmt->execute();
    $err = $stmt->error;
    $stmt->close();
    if (!$ok) return array('ok' => false, 'error' => $err);
    return array('ok' => true, 'skipped' => false, 'message_count' => $count, 'file_ok' => $file_ok, 'file_path' => $file_rel);
}

function emc_backup_messages_from_db($date, $room)
{
    $rows = array();
    if (!preg_match('/^\d{8}$/', (string)$date)) return $rows;
    $room = ($room === '_all' || $room === '') ? '_all' : emc_clean_room($room);
    $db = emc_db();
    $msg_table = emc_table('esils_chat_messages');
    $like = $date . '%';
    if ($room === '_all') {
        $stmt = $db->prepare("SELECT message_srl, room_id, member_srl, nick_name, content, ipaddress, regdate, is_deleted FROM {$msg_table} WHERE regdate LIKE ? ORDER BY message_srl ASC");
        if (!$stmt) return $rows;
        $stmt->bind_param('s', $like);
    } else {
        $stmt = $db->prepare("SELECT message_srl, room_id, member_srl, nick_name, content, ipaddress, regdate, is_deleted FROM {$msg_table} WHERE regdate LIKE ? AND room_id = ? ORDER BY message_srl ASC");
        if (!$stmt) return $rows;
        $stmt->bind_param('ss', $like, $room);
    }
    $stmt->execute();
    $stmt->bind_result($message_srl, $room_id, $member_srl, $nick_name, $content, $ipaddress, $regdate, $is_deleted);
    while ($stmt->fetch()) {
        $rows[] = array(
            'message_srl' => (int)$message_srl,
            'room_id' => $room_id,
            'member_srl' => (int)$member_srl,
            'nick_name' => $nick_name,
            'content' => $content,
            'ipaddress' => $ipaddress,
            'regdate' => $regdate,
            'is_deleted' => $is_deleted
        );
    }
    $stmt->close();
    return $rows;
}

function emc_auto_backup_daily()
{
    if (!emc_bool_setting('backup_enabled')) return;
    $yesterday = date('Ymd', time() - 86400);
    $last = emc_get_setting('auto_backup_last_date', '');
    if (preg_match('/^\d{8}$/', $last) && strcmp($last, $yesterday) >= 0) return;

    if (preg_match('/^\d{8}$/', $last)) {
        $start_ts = strtotime(substr($last,0,4) . '-' . substr($last,4,2) . '-' . substr($last,6,2) . ' +1 day');
    } else {
        $start_ts = strtotime($yesterday);
    }
    $end_ts = strtotime($yesterday);
    $limit = 0;
    for ($ts = $start_ts; $ts <= $end_ts && $limit < 7; $ts += 86400, $limit++) {
        $d = date('Ymd', $ts);
        emc_backup_date($d, '_all', false);
        emc_set_setting('auto_backup_last_date', $d);
    }
}

function emc_widget_base_url()
{
    if (defined('RX_BASEURL')) {
        $base = trim((string)RX_BASEURL);
        if ($base === '' || $base === '/') return '/widgets/esils_chat';
        return rtrim($base, '/') . '/widgets/esils_chat';
    }

    // XE 하위폴더 설치와 직접 실행(admin.php/api.php)을 모두 처리한다.
    $script = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', $_SERVER['SCRIPT_NAME']) : '/index.php';
    $base = dirname($script);
    if (preg_match('#/widgets/esils_chat$#', $base)) return $base;
    if (preg_match('#/widgets/esils_chat/#', $base)) return preg_replace('#/widgets/esils_chat/.*$#', '/widgets/esils_chat', $base);
    if ($base === '/' || $base === '.' || $base === '\\') $base = '';
    $base = rtrim($base, '/');
    return $base . '/widgets/esils_chat';
}
