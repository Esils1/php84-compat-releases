<?php
/**
 * Esils Chat Widget installer/upgrader for Rhymix 2.x / XE Core 1.11.x
 */
require_once __DIR__ . '/lib.php';
emc_bootstrap_xe(false);
$info = emc_require_admin();
$results = emc_install_schema();
emc_harden_backup_dir();
emc_auto_backup_daily();
emc_cleanup_old_logs();
header('Content-Type: text/html; charset=UTF-8');
$ok_all = true;
foreach ($results as $r) if (!$r['ok']) $ok_all = false;
$base_url = emc_widget_base_url();
?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>Esils Chat 설치/업그레이드</title>
<style>
body{font-family:Arial,"Malgun Gothic",sans-serif;background:#f3f4f6;color:#111827;padding:28px;line-height:1.65}.box{max-width:980px;background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:24px;box-shadow:0 10px 30px rgba(15,23,42,.08)}h1{margin-top:0;letter-spacing:-.03em}h2{margin-top:22px;font-size:18px}.ok{color:#059669;font-weight:700}.bad{color:#dc2626;font-weight:700}code{background:#f3f4f6;padding:2px 6px;border-radius:6px}.btn{display:inline-block;border-radius:9px;padding:9px 12px;background:#2563eb;color:#fff;text-decoration:none;margin-right:6px}.btn.gray{background:#4b5563}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.panel{border:1px solid #e5e7eb;border-radius:14px;padding:14px;background:#f9fafb}.panel h3{margin:0 0 8px;font-size:15px}pre{background:#111827;color:#f9fafb;padding:16px;border-radius:10px;overflow:auto}.note{background:#eff6ff;border-left:4px solid #bfdbfe;border-radius:10px;padding:10px 12px}.danger{background:#fef2f2;border-left:4px solid #fecaca;border-radius:10px;padding:10px 12px;color:#991b1b}ul,ol{padding-left:20px}@media(max-width:760px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="box">
<h1>Esils Chat 설치/업그레이드 결과</h1><p class="note">웹호스팅 AJAX 최적화판 1.6.4입니다. 설치 확인 후 관리자 화면에서 채팅방별 코드생성을 사용하십시오.</p>
<?php foreach ($results as $idx => $r): ?>
<p>테이블 <?php echo $idx + 1; ?>: <?php echo $r['ok'] ? '<span class="ok">생성/확인 완료</span>' : '<span class="bad">실패</span> ' . emc_h($r['error']); ?></p>
<?php endforeach; ?>
<?php if ($ok_all): ?>
<div class="grid">
<div class="panel"><h3>설치 위치</h3>
<p>Rhymix/XE 루트 기준: <code>./widgets/esils_chat/</code></p>
<p>감지된 루트: <code><?php echo emc_h(emc_xe_root()); ?></code></p>
</div>
<div class="panel"><h3>관리 화면</h3>
<p><a class="btn" href="admin.php">관리자 열기</a> <a class="btn gray" href="admin.php?view=rooms">채팅방 관리</a></p>
<p><code><?php echo emc_h($base_url); ?>/admin.php</code></p>
</div>
</div>
<h2>위젯 사용 순서</h2>
<ol>
<li>관리자 화면의 <b>채팅방 관리</b>에서 방을 추가합니다.</li>
<li>등록된 채팅방의 <b>코드생성</b> 버튼을 눌러 위젯 코드를 복사합니다.</li>
<li>게시글, 페이지, 레이아웃 HTML 영역에 붙여 넣습니다.</li>
<li>관리자 → 캐시파일 재생성을 실행합니다.</li>
</ol>
<p class="note">웹호스팅 기준입니다. 평상시 메시지는 5초마다 조회하고, 최근 메시지가 있으면 3초 주기로 빠르게 확인합니다. 내가 메시지를 보낸 직후에는 즉시 1회 갱신합니다. 접속자/권한 상태는 30초마다 확인합니다.</p>
<div class="grid"><div class="panel"><h3>우측 카운터 아래 권장값</h3><ul>
<li>가로 폭: <code>220</code></li>
<li>메시지 높이: <code>190</code></li>
<li>처음 상태: <code>펼친다</code></li>
</ul></div><div class="panel"><h3>설정 우선순위</h3><ol>
<li>위젯 코드에 직접 들어간 값</li>
<li>채팅방별 설정</li>
<li>전체 기본 설정</li>
</ol></div></div>
<h2>수동 삽입 예비 코드</h2>
<pre>&lt;!-- Esils Chat Widget --&gt;
&lt;link rel=&quot;stylesheet&quot; href=&quot;<?php echo emc_h($base_url); ?>/assets/chat.css&quot; /&gt;
&lt;div class=&quot;emc-chat&quot; data-api=&quot;<?php echo emc_h($base_url); ?>/api.php&quot; data-admin-url=&quot;<?php echo emc_h($base_url); ?>/admin.php&quot; data-room=&quot;main&quot; data-title=&quot;회원 채팅&quot; data-height=&quot;190&quot; data-max-width=&quot;220&quot; data-collapsed=&quot;N&quot; data-poll-normal=&quot;5&quot; data-poll-active=&quot;3&quot; data-poll-active-duration=&quot;30&quot; data-refresh-after-send=&quot;Y&quot;&gt;&lt;/div&gt;
&lt;script src=&quot;<?php echo emc_h($base_url); ?>/assets/chat.js&quot; defer&gt;&lt;/script&gt;</pre>
<h2>보안/운영 적용</h2>
<ul>
<li>등록된 채팅방만 API 접근을 허용합니다.</li>
<li>백업 디렉터리 <code>backups/</code>, <code>backups/private/</code>, 로그 디렉터리 <code>logs/</code>에 웹 접근 차단 파일을 생성합니다.</li>
<li>API 진단, 부하량 계측 DB 기록, API 자동 백업 실행은 제거했습니다.</li>
</ul>
<p class="danger">설치 확인 후 보안을 위해 <code>install.php</code>는 삭제하거나 <code>install.done.php</code>처럼 파일명을 바꾸십시오. 제거가 필요하면 README의 수동 제거 절차를 사용하십시오.</p>
<?php endif; ?>
</div>
</body>
</html>
