Esils Chat Widget 1.7.4

1. 개요
  Rhymix 2.x 및 XE Core 1.11.x에서 모두 동작하도록 보정한 PHP 8.4 대응 Ajax 채팅 위젯입니다.
  WebSocket은 사용하지 않고, 웹호스팅에서 운영 가능한 AJAX 폴링 방식으로 동작합니다.
  XE/Rhymix에서 채팅을 중앙 관리하고, 외부 PHP/CGI 게임에는 iframe 코드로 채팅창을 붙일 수 있습니다.

2. 지원 기준
  - XE Core 1.11.x + PHP 5.5~7.x 권장
  - Rhymix 2.x + PHP 7.x~8.4 권장
  - 위젯 코드는 PHP 5.5~8.4 문법 범위를 기준으로 작성했습니다.
  - XE 코어 자체의 PHP 8.x 호환성은 별도 문제입니다.

3. 설치 경로
  사이트 루트/widgets/esils_chat/

4. 설치/업그레이드 절차
  1) 압축을 사이트 루트에 그대로 덮어씁니다.
  2) XE/Rhymix 최고 관리자 로그인 상태에서 아래 주소를 1회 실행합니다.
       /widgets/esils_chat/install.php
     XE가 /xe/ 하위 폴더에 설치되어 있다면:
       /xe/widgets/esils_chat/install.php
  3) 관리자 → 캐시파일 재생성을 실행합니다.
  4) /widgets/esils_chat/admin.php 에 접속해 전체 설정과 채팅방 목록을 확인합니다.
  5) 내부 페이지는 채팅방 관리 → 코드생성 버튼의 위젯 코드를 사용합니다.
  6) 외부 게임 페이지는 외부 연동 메뉴에서 사이트를 등록한 뒤 코드생성 버튼의 iframe 코드를 사용합니다.

5. 설치 후 보안 조치
  - install.php는 설치 확인 후 삭제하거나 install.done.php처럼 파일명을 바꾸십시오.
  - uninstall.php는 배포본에서 제거했습니다. 제거가 필요하면 아래 수동 제거 절차를 사용하십시오.
  - backups/, backups/private/, logs/에는 웹 접근 차단 파일이 포함되어 있습니다.
  - 백업 JSON 파일 저장은 기본 비활성입니다. 필요한 경우에만 켜십시오.

6. 채팅방 구조
  - 채팅방 ID가 같으면 같은 대화방입니다.
  - 채팅방 ID가 다르면 메시지 로그가 분리됩니다.
  - 전체 기본 설정은 모든 채팅방의 기본값입니다.
  - 채팅방별 설정에서 값을 비워두면 전체 기본 설정을 상속합니다.
  - 채팅방별 설정값을 넣으면 해당 방에만 우선 적용됩니다.
  - API는 등록되지 않은 room_id 접근을 차단합니다.

7. 설정 우선순위
  1) 위젯 코드에 직접 넣은 값
  2) 채팅방별 설정값
  3) 전체 기본 설정값

8. 관리자 화면
  /widgets/esils_chat/admin.php

  메뉴 구성:
  - 요약: 전체 상태, 운영 안내, 설치 후 보안 점검
  - 전체 설정: 기본 출력값, 조회 주기, 보안/운영 안정화, 부관리자 지정
  - 채팅방 관리: 방 추가, 방별 설정, 방별 코드생성, 방별 로그 이동
  - 외부 연동: 외부 iframe 사용, 허용 도메인, 사이트별 Secret Key, iframe 코드 생성, PHP/CGI 예제 확인
  - 채팅 로그: 날짜/방/검색어 기준 로그 확인, 메시지 삭제 처리, 차단 처리
  - 차단 관리: 전체 또는 특정 방 기준 회원/IP/닉네임/외부 사용자 차단
  - 백업 확인: DB 백업 목록과 메시지 내용 확인
  - 에러 로그: 최고관리자 전용 내부 오류 로그 확인

9. 부관리자 권한
  가능:
    - 채팅 로그 확인
    - 채팅 메시지 삭제 처리
    - 회원/IP/닉네임/외부 사용자 차단
    - 차단 해제
    - 백업 확인

  불가:
    - 전체 설정 변경
    - 채팅방별 설정 변경
    - 외부 연동 설정 변경
    - 채팅방 로그 전체 삭제
    - 백업 생성/삭제
    - 부관리자 추가/해제

10. 웹호스팅 운영 기준
  - 평상시 메시지 조회 주기: 기본 5초
  - 최근 메시지 감지 후 빠른 조회 주기: 기본 3초
  - 빠른 조회 유지 시간: 기본 30초
  - 내가 메시지를 보낸 직후: 즉시 1회 갱신
  - 접속자 수/권한 상태 확인: 30초
  - 전송 간격 제한: 최소 1초 이상
  - API 진단 기능: 제거
  - 부하량 계측 DB 기록: 제거
  - api.php에서 자동 백업 실행: 제거
  - 접속자 presence 갱신: 30초 제한

11. 외부 게임 연동 방식
  목적:
    - 채팅 관리, 로그, 차단, 백업은 XE/Rhymix에서 중앙 관리합니다.
    - 게임 페이지에서는 iframe으로 채팅창만 붙입니다.
    - 게임에 로그인한 닉네임은 서명 토큰으로 채팅에 전달합니다.

  관리자 설정:
    1) /widgets/esils_chat/admin.php 접속
    2) 외부 연동 메뉴 이동
    3) 외부 iframe 연동을 사용으로 변경
    4) 사이트 ID 입력. 예: hako55, hakonew, garden
    5) 허용 도메인 입력. 예: https://esils.com, https://esil.shop
    6) 허용 채팅방 입력. 예: hakophp55, hakonew 또는 *
    7) Secret Key는 비워두면 자동 생성됩니다.
    8) 등록된 외부 사이트 목록의 코드생성 버튼을 눌러 iframe 코드를 생성합니다.
    9) PHP 게임은 PHP 전체 예제, CGI/Perl 게임은 CGI/Perl 전체 예제를 참고해 auth 토큰을 생성합니다.

  보안 기준:
    - 외부 토큰으로 관리자/부관리자 권한을 부여하지 않습니다.
    - 외부 사용자는 일반 채팅 사용자로만 처리합니다.
    - Secret Key는 브라우저에 직접 출력하지 말고 게임 서버 PHP/CGI 코드 안에서만 사용하십시오.
    - 토큰은 만료시간을 둡니다. 기본 권장값은 300초입니다.
    - 허용 도메인과 허용 채팅방을 반드시 제한하십시오.

  iframe 주소 형식:
    /widgets/esils_chat/embed.php?room=채팅방ID&auth=서명토큰

  iframe 코드 생성:
    - 외부 연동 → 등록된 외부 사이트 → 코드생성
    - 채팅방 ID, auth 토큰 표기, 가로/세로 크기를 입력한 뒤 생성 버튼을 누릅니다.
    - CHAT_TOKEN_HERE는 게임 서버에서 생성한 실제 토큰 변수/값으로 치환하십시오.

  PHP 게임:
    - 코드생성 창의 PHP 게임용 전체 예제를 사용합니다.
    - 게임 로그인 변수에서 user_id와 nickname을 가져와 토큰을 생성합니다.

  CGI/Perl 게임:
    - 코드생성 창의 CGI/Perl 게임용 전체 예제를 사용합니다.
    - 예제 파일: examples/external_game_token_perl_cgi_sample.cgi
    - Digest::SHA, MIME::Base64, Encode 모듈이 필요합니다.
    - 기존 CGI 화면 안에서 iframe HTML만 출력하거나, 템플릿 변수로 넣어 사용하면 됩니다.

  다른 도메인 게임 페이지에서는 브라우저의 타사 쿠키 제한이 있을 수 있으므로, 로그인 닉네임 연동은 반드시 auth 서명 토큰 방식을 사용하십시오.

12. 차단 기준
  - 회원번호 차단: XE/Rhymix 회원 member_srl 기준
  - IP 차단: 접속 IP 기준
  - 닉네임 차단: 표시 닉네임 기준
  - 외부 사용자 차단: external:사이트ID:게임유저ID 형식

13. 장애 확인 순서
  1) /widgets/esils_chat/install.php 실행 결과 확인
  2) 관리자 → 캐시파일 재생성
  3) /widgets/esils_chat/admin.php 접속 확인
  4) 채팅방 관리에서 room_id 등록 여부 확인
  5) 외부 연동 사용 시 허용 도메인, 허용 방, Secret Key 확인
  6) 브라우저 개발자도구 Network에서 embed.php / api.php 응답 확인
  7) 관리자 화면 → 에러 로그 또는 widgets/esils_chat/logs/error.log 확인

14. 수동 제거 절차
  파일 제거:
    /widgets/esils_chat/ 폴더 삭제

  DB 테이블 제거 예시:
    DROP TABLE xe_esils_chat_messages;
    DROP TABLE xe_esils_chat_presence;
    DROP TABLE xe_esils_chat_settings;
    DROP TABLE xe_esils_chat_blocks;
    DROP TABLE xe_esils_chat_backups;
    DROP TABLE xe_esils_chat_rooms;

  접두사가 rx_이면 rx_esils_chat_... 형태로 바꿔 실행하십시오.

15. 1.7.4 변경 사항
  - 1.6.4 접속자 보정 로직을 외부 연동 iframe 버전에 동일 반영했습니다.
  - 접속자 수 계산에 presence 테이블값과 최근 3분 이내 실제 채팅 발신자를 함께 반영합니다.
  - 외부 연동 사용자는 external_site_id + external_user_id 기준으로 최근 발신자 보정 계산에 포함합니다.
  - 메시지 전송 응답에도 접속자 수를 포함해 전송 직후 표시값이 바로 갱신됩니다.
  - 브라우저 포커스 복귀/탭 재표시 시 상태와 메시지를 즉시 다시 확인합니다.

16. 1.7.3 변경 사항
  - 접속자 수가 1명으로 고정되는 문제를 수정했습니다.
  - presence 저장을 INSERT/UPDATE 분리 방식에서 원자적 UPSERT 방식으로 변경해 중복키 발생 시 접속자 테이블이 재생성되는 문제를 제거했습니다.
  - 관리자/외부 iframe 접근 때마다 presence 테이블이 초기화되던 동작을 제거했습니다.
  - 브라우저별 client_id를 전송해 외부 iframe/쿠키 제한 환경에서도 접속자를 안정적으로 구분합니다.

17. 1.7.2 변경 사항
  - 외부 연동 메뉴에서 등록된 외부 사이트별 아이프레임 코드를 바로 생성/복사할 수 있습니다.
  - 채팅방 ID, auth 토큰 표기, 가로/세로 크기를 입력해 iframe 코드를 만들 수 있습니다.
  - PHP 게임용 전체 예제와 CGI/Perl 게임용 전체 예제를 함께 제공합니다.
