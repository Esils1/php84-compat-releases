#!/usr/bin/perl
# Esils Chat 외부 연동 Perl CGI 예제
#
# 목적:
# - XE/Rhymix의 Esils Chat 관리자가 채팅방/로그/차단/백업을 중앙 관리합니다.
# - CGI 게임은 로그인한 사용자 ID와 닉네임으로 서명 토큰을 만든 뒤 iframe을 출력합니다.
# - Secret Key는 브라우저에 직접 출력하지 말고 CGI 서버 코드 안에서만 사용하십시오.
#
# 필요 Perl 모듈:
# - Digest::SHA
# - MIME::Base64
# - Encode

use strict;
use warnings;
use utf8;
use Digest::SHA qw(hmac_sha256 sha1_hex);
use MIME::Base64 qw(encode_base64);
use Encode qw(encode);

binmode STDOUT, ':encoding(UTF-8)';

sub esils_chat_b64url {
    my ($data) = @_;
    my $b64 = encode_base64($data, '');
    $b64 =~ tr{+/}{-_};
    $b64 =~ s/=+\z//;
    return $b64;
}

sub esils_chat_json_escape {
    my ($s) = @_;
    $s = '' unless defined $s;
    $s =~ s/\\/\\\\/g;
    $s =~ s/"/\\"/g;
    $s =~ s/\r/\\r/g;
    $s =~ s/\n/\\n/g;
    $s =~ s/\t/\\t/g;
    return $s;
}

# 관리자 → 외부 연동에서 등록한 값으로 바꿉니다.
my $site_id = 'hako55';
my $room = 'hakophp55';
my $secret = 'CHANGE_ME_TO_SECRET_KEY';
my $embed_base = 'https://example.com/xe/widgets/esils_chat/embed.php';
my $ttl = 300;

# 실제 게임 로그인 세션/데이터에서 가져오십시오.
# 예: 회원ID, 캐릭터ID, 섬ID, 군주ID 등 변하지 않는 고유값.
my $login_user_id = 'game_user_001';   # TODO: 실제 게임 로그인 고유 ID로 교체
# 예: 게임 닉네임, 섬 이름, 캐릭터명.
my $login_nickname = '게임닉네임';     # TODO: 실제 게임 닉네임/캐릭터명으로 교체

my $iat = time();
my $exp = $iat + $ttl;
my $nonce = substr(sha1_hex($iat . rand() . $$), 0, 12);

my $json = '{'
    . '"site":"' . esils_chat_json_escape($site_id) . '",'
    . '"room":"' . esils_chat_json_escape($room) . '",'
    . '"user_id":"' . esils_chat_json_escape($login_user_id) . '",'
    . '"nickname":"' . esils_chat_json_escape($login_nickname) . '",'
    . '"iat":' . $iat . ','
    . '"exp":' . $exp . ','
    . '"nonce":"' . esils_chat_json_escape($nonce) . '"'
    . '}';

my $payload_b64 = esils_chat_b64url(encode('UTF-8', $json));
my $sig = esils_chat_b64url(hmac_sha256($payload_b64, $secret));
my $chat_token = $payload_b64 . '.' . $sig;

print "Content-Type: text/html; charset=UTF-8\r\n\r\n";
print qq{<iframe src="$embed_base?room=$room&auth=$chat_token" width="320" height="420" style="border:0;overflow:hidden" loading="lazy"></iframe>};
