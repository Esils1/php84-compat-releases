<?php
/**
 * Esils Chat Rhymix/XE Widget
 * Path: RX/XE_ROOT/widgets/esils_chat/
 */
if (!defined('__XE__')) exit();
require_once __DIR__ . '/lib.php';

class esils_chat extends WidgetHandler
{
    function proc($args)
    {
        $global_settings = emc_get_settings();
        $room = isset($args->room) ? $this->_cleanRoom($args->room) : 'main';
        $pre_title = isset($args->title) && trim($args->title) !== '' ? trim($args->title) : $global_settings['title'];

        // 위젯 코드로 실제 출력된 방만 API에서 허용되도록 방 목록에 자동 등록한다.
        emc_register_room($room, $pre_title);
        $settings = emc_get_effective_settings($room);
        if (!$settings) $settings = $global_settings;

        $title = isset($args->title) && trim($args->title) !== '' ? trim($args->title) : $settings['title'];
        $height = isset($args->height) ? emc_sanitize_css_length($args->height, $settings['height'], 80, 1600, true) : emc_sanitize_css_length($settings['height'], '190', 80, 1600, true);
        $max_width = isset($args->max_width) ? emc_sanitize_css_length($args->max_width, $settings['max_width'], 120, 2000, true) : emc_sanitize_css_length($settings['max_width'], '220', 120, 2000, true);
        $collapsed = isset($args->default_collapsed) && $args->default_collapsed !== '' ? ($args->default_collapsed === 'Y' ? 'Y' : 'N') : ($settings['default_collapsed'] === 'Y' ? 'Y' : 'N');
        $poll_normal = max(1, min(60, (int)$settings['poll_normal_seconds']));
        $poll_active = max(1, min(60, (int)$settings['poll_active_seconds']));
        if ($poll_active > $poll_normal) $poll_active = $poll_normal;
        $poll_active_duration = max(1, min(300, (int)$settings['poll_active_duration_seconds']));
        $refresh_after_send = isset($settings['refresh_after_send']) && $settings['refresh_after_send'] === 'N' ? 'N' : 'Y';

        $widget_url = $this->_widgetUrl();
        $id = 'esils-member-chat-' . substr(md5($room . microtime(true) . mt_rand()), 0, 10);
        $ver = '20260605_174';

        $html = array();
        $html[] = '<link rel="stylesheet" href="' . $this->_esc($widget_url . '/assets/chat.css?v=' . $ver) . '" />';
        $html[] = '<div id="' . $this->_esc($id) . '" class="emc-chat"';
        $html[] = ' data-api="' . $this->_esc($widget_url . '/api.php') . '"';
        $html[] = ' data-admin-url="' . $this->_esc($widget_url . '/admin.php') . '"';
        $html[] = ' data-room="' . $this->_esc($room) . '"';
        $html[] = ' data-title="' . $this->_esc($title) . '"';
        $html[] = ' data-height="' . $this->_esc($height) . '"';
        $html[] = ' data-max-width="' . $this->_esc($max_width) . '"';
        $html[] = ' data-collapsed="' . $collapsed . '"';
        $html[] = ' data-poll-normal="' . $poll_normal . '"';
        $html[] = ' data-poll-active="' . $poll_active . '"';
        $html[] = ' data-poll-active-duration="' . $poll_active_duration . '"';
        $html[] = ' data-refresh-after-send="' . $refresh_after_send . '"';
        $html[] = '></div>';
        $html[] = '<script src="' . $this->_esc($widget_url . '/assets/chat.js?v=' . $ver) . '" defer></script>';

        return implode('', $html);
    }

    function _widgetUrl()
    {
        return emc_widget_base_url();
    }

    function _cleanRoom($room)
    {
        $room = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$room);
        return $room ? substr($room, 0, 64) : 'main';
    }

    function _esc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}
