<?php
/**
 * Esils Chat Widget API for Rhymix 2.x / XE Core 1.11.x
 * Hardened: registered-room whitelist, room-specific settings, stronger flood protection.
 */
require_once __DIR__ . '/lib.php';

function emc_require_sender($room, $settings)
{
    $info = emc_logged_info();
    $external = emc_external_identity_from_request($room);
    $ip = emc_client_ip();

    if ($external) {
        $member_srl = 0;
        $nick_name = $external['nickname'];
    } else if ($info) {
        $member_srl = (int)$info->member_srl;
        $nick_name = emc_member_name($info);
    } else {
        if ($settings['allow_guest_chat'] !== 'Y') {
            emc_json(array('ok' => false, 'error' => '로그인 후 이용할 수 있습니다.', 'login_required' => true), 401);
        }
        $member_srl = 0;
        $nick_name = trim($settings['guest_label']) !== '' ? trim($settings['guest_label']) : '비회원';
    }

    $external_key = $external ? $external['external_key'] : '';
    $block = emc_block_check($member_srl, $ip, $nick_name, $room, $external_key);
    if ($block) {
        emc_json(array('ok' => false, 'error' => emc_block_message($block), 'blocked' => true), 403);
    }

    return array(
        'info' => $info,
        'external' => $external,
        'member_srl' => $member_srl,
        'nick_name' => $nick_name,
        'ip' => $ip,
        'settings' => $settings,
        'external_site_id' => $external ? $external['site_id'] : '',
        'external_user_id' => $external ? $external['external_user_id'] : '',
        'external_key' => $external_key
    );
}

function emc_presence_request_client_id()
{
    $client_id = '';
    if (!empty($_SERVER['HTTP_X_ESILS_CHAT_CLIENT_ID'])) {
        $client_id = (string)$_SERVER['HTTP_X_ESILS_CHAT_CLIENT_ID'];
    } else if (isset($_REQUEST['client_id'])) {
        $client_id = (string)$_REQUEST['client_id'];
    }
    $client_id = preg_replace('/[^a-zA-Z0-9_\-:.]/', '', $client_id);
    return substr($client_id, 0, 96);
}

function emc_presence_client_key($info, $external = null)
{
    if ($external && !empty($external['external_key'])) {
        $base = 'e:' . substr(sha1($external['external_key']), 0, 40);
    } else if ($info && isset($info->member_srl) && (int)$info->member_srl > 0) {
        $base = 'm:' . (int)$info->member_srl;
    } else {
        if (empty($_SESSION['emc_chat_guest_key'])) {
            $seed = session_id() . '|' . emc_client_ip() . '|' . (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '') . '|' . microtime(true) . '|' . mt_rand();
            $_SESSION['emc_chat_guest_key'] = 'g:' . substr(sha1($seed), 0, 40);
        }
        $base = $_SESSION['emc_chat_guest_key'];
    }

    // 같은 브라우저의 여러 탭은 1명으로, 다른 브라우저/기기는 별도 접속자로 계산한다.
    // 외부 iframe 환경에서는 세션 쿠키가 제한될 수 있으므로 JS client_id를 함께 사용한다.
    $client_id = emc_presence_request_client_id();
    if ($client_id !== '') {
        return $base . ':c:' . substr(sha1($client_id), 0, 40);
    }
    return $base;
}

function emc_update_presence($room, $info, $settings, $force)
{
    $room = emc_clean_room($room);
    emc_ensure_presence_table_ready();
    emc_migrate_presence_schema();
    $external = emc_external_identity_from_request($room);
    $client_key = emc_presence_client_key($info, $external);
    $now_ts = time();
    $session_key = 'emc_presence_update_' . md5($room . '|' . $client_key);

    // 메시지 조회는 자주 발생하므로 presence DB 쓰기는 30초에 1회로 제한한다.
    // 단, state 요청은 30초 주기이므로 강제로 갱신한다.
    if (!$force && isset($_SESSION[$session_key]) && ($now_ts - (int)$_SESSION[$session_key]) < 30) return true;

    $db = emc_db();
    $table = emc_table('esils_chat_presence');
    $member_srl = ($info && isset($info->member_srl) && !$external) ? (int)$info->member_srl : 0;
    $nick_name = $external ? $external['nickname'] : ($info ? emc_member_name($info) : (isset($settings['guest_label']) && trim($settings['guest_label']) !== '' ? trim($settings['guest_label']) : '비회원'));
    $now = emc_now();
    $ip = emc_client_ip();

    $ok = false;
    for ($try = 0; $try < 2; $try++) {
        $stmt = $db->prepare("INSERT INTO {$table} (room_id, client_key, member_srl, nick_name, last_seen, ipaddress) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE member_srl = VALUES(member_srl), nick_name = VALUES(nick_name), last_seen = VALUES(last_seen), ipaddress = VALUES(ipaddress)");
        if ($stmt) {
            $stmt->bind_param('ssisss', $room, $client_key, $member_srl, $nick_name, $now, $ip);
            $exec = $stmt->execute();
            $err = $stmt->error;
            $stmt->close();
            if ($exec) { $ok = true; break; }
            if ($try === 0 && stripos($err, "doesn't exist") !== false) { emc_rebuild_presence_table(); continue; }
            emc_log_error('presence_upsert', $err);
            break;
        }
        $err = $db->error;
        if ($try === 0 && stripos($err, "doesn't exist") !== false) { emc_rebuild_presence_table(); continue; }
        if (stripos($err, "doesn't exist") === false) emc_log_error('presence_upsert_prepare', $err);
        break;
    }

    if ($ok) {
        $_SESSION[$session_key] = $now_ts;
        if (mt_rand(1, 100) === 1) {
            $old = date('YmdHis', $now_ts - 86400);
            @ $db->query("DELETE FROM {$table} WHERE last_seen < '" . $db->real_escape_string($old) . "'");
        }
    }
    return $ok;
}

function emc_presence_count_from_table($room, $limit)
{
    emc_ensure_presence_table_ready();
    emc_migrate_presence_schema();
    $db = emc_db();
    $table = emc_table('esils_chat_presence');
    $cnt = 0;

    for ($try = 0; $try < 2; $try++) {
        $stmt = $db->prepare("SELECT COUNT(*) AS cnt FROM {$table} WHERE room_id = ? AND last_seen >= ?");
        if ($stmt) {
            $stmt->bind_param('ss', $room, $limit);
            $stmt->execute();
            $stmt->bind_result($cnt_result);
            if ($stmt->fetch()) $cnt = (int)$cnt_result;
            $stmt->close();
            return $cnt;
        }
        $err = $db->error;
        if ($try === 0 && stripos($err, "doesn't exist") !== false) { emc_rebuild_presence_table(); continue; }
        if (stripos($err, "doesn't exist") === false) emc_log_error('presence_count_prepare', $err);
        break;
    }

    // 일부 호스팅에서 prepared statement가 실패해도 단순 SELECT는 동작하는 경우가 있어 한 번 더 계산한다.
    $room_sql = $db->real_escape_string($room);
    $limit_sql = $db->real_escape_string($limit);
    $res = @ $db->query("SELECT COUNT(*) AS cnt FROM {$table} WHERE room_id = '{$room_sql}' AND last_seen >= '{$limit_sql}'");
    if ($res) {
        $row = $res->fetch_assoc();
        $cnt = isset($row['cnt']) ? (int)$row['cnt'] : 0;
        $res->free();
    }
    return $cnt;
}

function emc_recent_sender_count($room, $limit)
{
    // presence 갱신이 브라우저/세션/iframe/캐시 환경에서 누락되더라도
    // 최근 실제 채팅을 보낸 사용자는 접속자로 보정한다.
    $db = emc_db();
    $table = emc_table('esils_chat_messages');
    $cnt = 0;

    $sql = "SELECT COUNT(*) AS cnt FROM (
        SELECT CASE
            WHEN external_site_id <> '' AND external_user_id <> '' THEN CONCAT('e:', external_site_id, ':', external_user_id)
            WHEN member_srl > 0 THEN CONCAT('m:', member_srl)
            ELSE CONCAT('g:', IFNULL(ipaddress, ''), ':', IFNULL(nick_name, ''))
        END AS actor_key
        FROM {$table}
        WHERE room_id = ? AND regdate >= ? AND is_deleted <> 'Y'
        GROUP BY actor_key
    ) AS recent_actors";
    $stmt = $db->prepare($sql);
    if ($stmt) {
        $stmt->bind_param('ss', $room, $limit);
        $stmt->execute();
        $stmt->bind_result($cnt_result);
        if ($stmt->fetch()) $cnt = (int)$cnt_result;
        $stmt->close();
        return $cnt;
    }

    $err = $db->error;
    if ($err && stripos($err, "doesn't exist") === false) emc_log_error('recent_sender_count_prepare', $err);

    $room_sql = $db->real_escape_string($room);
    $limit_sql = $db->real_escape_string($limit);
    $res = @ $db->query("SELECT COUNT(*) AS cnt FROM (
        SELECT CASE
            WHEN external_site_id <> '' AND external_user_id <> '' THEN CONCAT('e:', external_site_id, ':', external_user_id)
            WHEN member_srl > 0 THEN CONCAT('m:', member_srl)
            ELSE CONCAT('g:', IFNULL(ipaddress, ''), ':', IFNULL(nick_name, ''))
        END AS actor_key
        FROM {$table}
        WHERE room_id = '{$room_sql}' AND regdate >= '{$limit_sql}' AND is_deleted <> 'Y'
        GROUP BY actor_key
    ) AS recent_actors");
    if ($res) {
        $row = $res->fetch_assoc();
        $cnt = isset($row['cnt']) ? (int)$row['cnt'] : 0;
        $res->free();
    }
    return $cnt;
}

function emc_online_count($room, $fallback_current)
{
    $room = emc_clean_room($room);
    $limit = date('YmdHis', time() - 180);

    $presence_count = emc_presence_count_from_table($room, $limit);
    $recent_sender_count = emc_recent_sender_count($room, $limit);
    $cnt = max($presence_count, $recent_sender_count);

    if ($fallback_current && $cnt < 1) $cnt = 1;
    return $cnt;
}

function emc_row_to_message($row, $admin)
{
    $content = $row['is_deleted'] === 'Y' ? '관리자에 의해 삭제된 메시지입니다.' : $row['content'];
    $message = array(
        'id' => (int)$row['message_srl'],
        'room_id' => $row['room_id'],
        'member_srl' => (int)$row['member_srl'],
        'nick_name' => $row['nick_name'],
        'content' => $content,
        'regdate' => $row['regdate'],
        'is_deleted' => $row['is_deleted']
    );
    if ($admin) {
        $message['ipaddress'] = $row['ipaddress'];
        $message['external_site_id'] = isset($row['external_site_id']) ? $row['external_site_id'] : '';
        $message['external_user_id'] = isset($row['external_user_id']) ? $row['external_user_id'] : '';
    }
    return $message;
}

function emc_fetch_messages($room, $after_id, $admin)
{
    $db = emc_db();
    $table = emc_table('esils_chat_messages');
    $messages = array();

    if ($after_id > 0) {
        $stmt = $db->prepare("SELECT message_srl, room_id, member_srl, nick_name, content, ipaddress, external_site_id, external_user_id, regdate, is_deleted FROM {$table} WHERE room_id = ? AND message_srl > ? ORDER BY message_srl ASC LIMIT 80");
        if (!$stmt) emc_api_fail('메시지를 조회하지 못했습니다.', 500, 'fetch_prepare', $db->error);
        $stmt->bind_param('si', $room, $after_id);
    } else {
        $stmt = $db->prepare("SELECT message_srl, room_id, member_srl, nick_name, content, ipaddress, external_site_id, external_user_id, regdate, is_deleted FROM (SELECT message_srl, room_id, member_srl, nick_name, content, ipaddress, external_site_id, external_user_id, regdate, is_deleted FROM {$table} WHERE room_id = ? ORDER BY message_srl DESC LIMIT 80) AS x ORDER BY message_srl ASC");
        if (!$stmt) emc_api_fail('메시지를 조회하지 못했습니다.', 500, 'fetch_prepare_initial', $db->error);
        $stmt->bind_param('s', $room);
    }

    $stmt->execute();
    $stmt->bind_result($message_srl, $room_id, $member_srl, $nick_name, $content, $ipaddress, $external_site_id, $external_user_id, $regdate, $is_deleted);
    while ($stmt->fetch()) {
        $messages[] = emc_row_to_message(array(
            'message_srl' => $message_srl,
            'room_id' => $room_id,
            'member_srl' => $member_srl,
            'nick_name' => $nick_name,
            'content' => $content,
            'ipaddress' => $ipaddress,
            'external_site_id' => $external_site_id,
            'external_user_id' => $external_user_id,
            'regdate' => $regdate,
            'is_deleted' => $is_deleted,
        ), $admin);
    }
    $stmt->close();
    return $messages;
}

function emc_last_sender_regdate($room, $member_srl, $ip)
{
    $db = emc_db();
    $table = emc_table('esils_chat_messages');
    if ($member_srl > 0) {
        $stmt = $db->prepare("SELECT regdate FROM {$table} WHERE room_id = ? AND member_srl = ? AND is_deleted = 'N' ORDER BY message_srl DESC LIMIT 1");
        if (!$stmt) return null;
        $stmt->bind_param('si', $room, $member_srl);
    } else {
        $stmt = $db->prepare("SELECT regdate FROM {$table} WHERE room_id = ? AND member_srl = 0 AND ipaddress = ? AND is_deleted = 'N' ORDER BY message_srl DESC LIMIT 1");
        if (!$stmt) return null;
        $stmt->bind_param('ss', $room, $ip);
    }
    $stmt->execute();
    $stmt->bind_result($regdate);
    $row = $stmt->fetch();
    $stmt->close();
    return $row ? $regdate : null;
}

function emc_check_send_rate_limits($room, $sender, $content)
{
    $settings = $sender['settings'];
    $member_limit = max(1, min(120, (int)$settings['rate_limit_member_per_minute']));
    $ip_limit = max(1, min(120, (int)$settings['rate_limit_ip_per_minute']));
    $same_text_seconds = max(0, min(300, (int)$settings['same_text_seconds']));

    if ((int)$sender['member_srl'] > 0) {
        $member_count = emc_count_recent_messages($room, 'member_srl', (int)$sender['member_srl'], 60);
        if ($member_count >= $member_limit) {
            emc_json(array('ok' => false, 'error' => '채팅 입력이 너무 많습니다. 잠시 후 다시 입력하세요.'), 429);
        }
    }

    $ip_count = emc_count_recent_messages($room, 'ipaddress', $sender['ip'], 60);
    if ($ip_count >= $ip_limit) {
        emc_json(array('ok' => false, 'error' => '현재 IP의 채팅 입력이 너무 많습니다. 잠시 후 다시 입력하세요.'), 429);
    }

    if ($same_text_seconds > 0 && emc_has_same_text_recent($room, $sender, $content, $same_text_seconds)) {
        emc_json(array('ok' => false, 'error' => '같은 내용을 반복해서 입력할 수 없습니다.'), 429);
    }
}

function emc_send_message($room, $sender, $content)
{
    $settings = $sender['settings'];
    $max_length = (int)$settings['max_length'];
    $flood_seconds = (int)$settings['flood_seconds'];
    if ($max_length < 50) $max_length = 50;
    if ($max_length > 2000) $max_length = 2000;
    if ($flood_seconds < 1) $flood_seconds = 1;
    if ($flood_seconds > 60) $flood_seconds = 60;

    $content = trim(str_replace(array("\r\n", "\r"), "\n", (string)$content));
    $content = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $content);
    $content = strip_tags($content);
    $content = preg_replace('/\n{3,}/', "\n\n", $content);

    if ($content === '') emc_json(array('ok' => false, 'error' => '내용을 입력하세요.'), 400);
    if (emc_strlen($content) > $max_length) $content = emc_substr($content, 0, $max_length);

    $last = emc_last_sender_regdate($room, (int)$sender['member_srl'], $sender['ip']);
    if ($flood_seconds > 0 && $last && time() - emc_regdate_to_time($last) < $flood_seconds) {
        emc_json(array('ok' => false, 'error' => $flood_seconds . '초 후 다시 입력하세요.'), 429);
    }
    emc_check_send_rate_limits($room, $sender, $content);

    $regdate = emc_now();
    $table = emc_table('esils_chat_messages');
    $db = emc_db();
    $stmt = $db->prepare("INSERT INTO {$table} (room_id, member_srl, nick_name, content, ipaddress, external_site_id, external_user_id, regdate, is_deleted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'N')");
    if (!$stmt) emc_api_fail('메시지를 저장하지 못했습니다.', 500, 'send_prepare', $db->error);
    $member_srl = (int)$sender['member_srl'];
    $nick_name = $sender['nick_name'];
    $ip = $sender['ip'];
    $external_site_id = isset($sender['external_site_id']) ? $sender['external_site_id'] : '';
    $external_user_id = isset($sender['external_user_id']) ? $sender['external_user_id'] : '';
    $stmt->bind_param('sissssss', $room, $member_srl, $nick_name, $content, $ip, $external_site_id, $external_user_id, $regdate);
    $ok = $stmt->execute();
    $id = $stmt->insert_id;
    $err = $stmt->error;
    $stmt->close();
    if (!$ok) emc_api_fail('메시지를 저장하지 못했습니다.', 500, 'send_execute', $err);
    return $id;
}

function emc_delete_message($info, $message_id)
{
    if (!emc_can_manage_chat($info)) emc_json(array('ok' => false, 'error' => '채팅 관리자만 삭제할 수 있습니다.'), 403);
    $db = emc_db();
    $table = emc_table('esils_chat_messages');
    $message_id = (int)$message_id;
    $stmt = $db->prepare("UPDATE {$table} SET is_deleted = 'Y' WHERE message_srl = ?");
    if (!$stmt) emc_api_fail('메시지를 삭제하지 못했습니다.', 500, 'delete_prepare', $db->error);
    $stmt->bind_param('i', $message_id);
    $stmt->execute();
    $stmt->close();
    return true;
}

emc_bootstrap_xe(true);
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'state';
$action = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$action);
if ($action === '') $action = 'state';
$room = emc_clean_room(isset($_REQUEST['room']) ? $_REQUEST['room'] : EMC_ROOM_DEFAULT);
$settings = emc_require_room_json($room);
$info = emc_logged_info();
$external = emc_external_identity_from_request($room);
$presence_ok = emc_update_presence($room, $info, $settings, $action === 'state');

switch ($action) {
    case 'state':
        $member_srl = ($info && !$external) ? (int)$info->member_srl : 0;
        $nick = $external ? $external['nickname'] : ($info ? emc_member_name($info) : (trim($settings['guest_label']) !== '' ? trim($settings['guest_label']) : '비회원'));
        $external_key = $external ? $external['external_key'] : '';
        $block = emc_block_check($member_srl, emc_client_ip(), $nick, $room, $external_key);
        $can_send = ($external || $info || $settings['allow_guest_chat'] === 'Y') && !$block;
        emc_json(array(
            'ok' => true,
            'logged' => (bool)($info || $external),
            'external_logged' => (bool)$external,
            'can_send' => (bool)$can_send,
            'login_required' => (!$info && !$external && $settings['allow_guest_chat'] !== 'Y'),
            'blocked' => $block ? true : false,
            'block_message' => $block ? emc_block_message($block) : '',
            'token' => emc_create_token(),
            'member' => $external ? array(
                'member_srl' => 0,
                'nick_name' => $external['nickname'],
                'is_external' => true,
                'external_site_id' => $external['site_id'],
                'external_user_id' => $external['external_user_id'],
                'is_admin' => false,
                'is_chat_manager' => false,
                'can_delete' => false
            ) : ($info ? array(
                'member_srl' => (int)$info->member_srl,
                'nick_name' => emc_member_name($info),
                'is_external' => false,
                'is_admin' => emc_is_admin($info),
                'is_chat_manager' => emc_can_manage_chat($info),
                'can_delete' => emc_can_manage_chat($info)
            ) : null),
            'settings' => array(
                'allow_guest_chat' => $settings['allow_guest_chat'],
                'guest_label' => $settings['guest_label'],
                'max_length' => (int)$settings['max_length'],
                'show_admin_link' => $settings['show_admin_link'],
                'poll_normal_seconds' => (int)$settings['poll_normal_seconds'],
                'poll_active_seconds' => (int)$settings['poll_active_seconds'],
                'poll_active_duration_seconds' => (int)$settings['poll_active_duration_seconds'],
                'refresh_after_send' => $settings['refresh_after_send'],
                'room_id' => $room,
                'room_title' => $settings['title']
            ),
            'admin_url' => ($info && emc_can_manage_chat($info) && $settings['show_admin_link'] === 'Y') ? emc_widget_base_url() . '/admin.php' : '',
            'online_count' => emc_online_count($room, true),
            'server_time' => emc_now()
        ), 200);
        break;

    case 'fetch':
        if (!$info && !$external && $settings['allow_guest_chat'] !== 'Y') {
            emc_json(array('ok' => true, 'logged' => false, 'login_required' => true, 'messages' => array()), 200);
        }
        $after_id = isset($_GET['after_id']) ? (int)$_GET['after_id'] : 0;
        emc_json(array(
            'ok' => true,
            'logged' => (bool)($info || $external),
            'messages' => emc_fetch_messages($room, $after_id, emc_is_admin($info)),
            'online_count' => emc_online_count($room, true)
        ), 200);
        break;

    case 'send':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') emc_json(array('ok' => false, 'error' => 'POST 요청만 허용됩니다.'), 405);
        if (!emc_external_identity_from_request($room)) emc_check_token_json();
        $sender = emc_require_sender($room, $settings);
        emc_update_presence($room, $sender['info'], $settings, true);
        $content = isset($_POST['content']) ? $_POST['content'] : '';
        $id = emc_send_message($room, $sender, $content);
        emc_json(array(
            'ok' => true,
            'id' => $id,
            'messages' => emc_fetch_messages($room, max(0, $id - 1), emc_is_admin($sender['info'])),
            'online_count' => emc_online_count($room, true)
        ), 200);
        break;

    case 'delete':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') emc_json(array('ok' => false, 'error' => 'POST 요청만 허용됩니다.'), 405);
        $info = emc_logged_info();
        if (!$info) emc_json(array('ok' => false, 'error' => '로그인 후 이용할 수 있습니다.'), 401);
        emc_check_token_json();
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($id <= 0) emc_json(array('ok' => false, 'error' => '삭제할 메시지 번호가 없습니다.'), 400);
        emc_delete_message($info, $id);
        emc_json(array('ok' => true), 200);
        break;

    default:
        emc_json(array('ok' => false, 'error' => '지원하지 않는 요청입니다.'), 400);
}
