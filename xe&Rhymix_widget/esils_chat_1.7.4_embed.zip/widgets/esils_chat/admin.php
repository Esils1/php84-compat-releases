<?php
/**
 * Esils Chat Management Console
 * Hardened room-aware management console.
 */
require_once __DIR__ . '/lib.php';
emc_bootstrap_xe(false);
$admin_info = emc_require_chat_manager();
$is_super_admin = emc_is_admin($admin_info);
emc_install_schema();
emc_ensure_presence_table_ready();
emc_auto_backup_daily();
emc_cleanup_old_logs();
$token = emc_create_token();
$db = emc_db();
$message = '';
$error = '';

function emc_admin_url($view, $extra = '')
{
    $url = 'admin.php?view=' . urlencode($view);
    if ($extra) $url .= '&' . $extra;
    return $url;
}

function emc_admin_room_options($include_all, $selected)
{
    $db = emc_db();
    $table = emc_table('esils_chat_rooms');
    $html = '';
    if ($include_all) $html .= '<option value="_all"' . ($selected === '_all' ? ' selected' : '') . '>전체(_all)</option>';
    $res = @$db->query("SELECT room_id, room_title, is_enabled FROM {$table} ORDER BY room_id ASC");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $label = $row['room_id'];
            if ($row['room_title'] !== '') $label .= ' - ' . $row['room_title'];
            if ($row['is_enabled'] !== 'Y') $label .= ' [비활성]';
            $html .= '<option value="' . emc_h($row['room_id']) . '"' . ($selected === $row['room_id'] ? ' selected' : '') . '>' . emc_h($label) . '</option>';
        }
        $res->free();
    }
    return $html;
}

function emc_room_inherit_label($room, $key, $global, $yesno)
{
    if (!isset($room[$key]) || trim((string)$room[$key]) === '') return '<span class="muted">전체 설정 상속(' . emc_h($global) . ')</span>';
    if ($yesno) return $room[$key] === 'Y' ? '예' : '아니오';
    return emc_h($room[$key]);
}

function emc_admin_post_action($admin_info, $is_super_admin)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return array('', '');
    if (!emc_check_token_admin()) return array('', '요청 토큰이 올바르지 않습니다. 새로고침 후 다시 실행하세요.');

    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $db = emc_db();

    if ($action === 'save_settings') {
        if (!$is_super_admin) return array('', '실제 설정 변경은 최고 관리자만 할 수 있습니다.');
        $keys = array('title','allow_guest_chat','default_collapsed','max_width','height','flood_seconds','poll_normal_seconds','poll_active_seconds','poll_active_duration_seconds','refresh_after_send','max_length','guest_label','show_admin_link','backup_enabled','backup_file_enabled','backup_retention_days','log_retention_days','rate_limit_member_per_minute','rate_limit_ip_per_minute','same_text_seconds');
        foreach ($keys as $k) {
            $v = isset($_POST[$k]) ? trim((string)$_POST[$k]) : '';
            if (in_array($k, array('allow_guest_chat','default_collapsed','show_admin_link','backup_enabled','backup_file_enabled','refresh_after_send'), true)) $v = $v === 'Y' ? 'Y' : 'N';
            if ($k === 'max_width') { $v = emc_sanitize_css_length($v, '220', 120, 2000, true); }
            if ($k === 'height') { $v = emc_sanitize_css_length($v, '190', 80, 1600, true); }
            if ($k === 'flood_seconds') { $v = (string)max(1, min(60, (int)$v)); }
            if ($k === 'poll_normal_seconds') { $v = (string)max(1, min(60, (int)$v)); }
            if ($k === 'poll_active_seconds') { $v = (string)max(1, min(60, (int)$v)); }
            if ($k === 'poll_active_duration_seconds') { $v = (string)max(1, min(300, (int)$v)); }
            if ($k === 'max_length') { $v = (string)max(50, min(2000, (int)$v)); }
            if ($k === 'backup_retention_days') { $v = (string)max(1, min(3650, (int)$v)); }
            if ($k === 'log_retention_days') { $v = (string)max(0, min(3650, (int)$v)); }
            if ($k === 'rate_limit_member_per_minute') { $v = (string)max(1, min(120, (int)$v)); }
            if ($k === 'rate_limit_ip_per_minute') { $v = (string)max(1, min(120, (int)$v)); }
            if ($k === 'same_text_seconds') { $v = (string)max(0, min(300, (int)$v)); }
            if ($k === 'title' && $v === '') $v = '회원 채팅';
            if ($k === 'guest_label' && $v === '') $v = '비회원';
            emc_set_setting($k, $v);
        }
        $normal_poll = max(1, min(60, (int)emc_get_setting('poll_normal_seconds', '5')));
        $active_poll = max(1, min(60, (int)emc_get_setting('poll_active_seconds', '3')));
        if ($active_poll > $normal_poll) emc_set_setting('poll_active_seconds', (string)$normal_poll);
        emc_harden_backup_dir();
        return array('전체 설정을 저장했습니다.', '');
    }


    if ($action === 'save_external_global') {
        if (!$is_super_admin) return array('', '외부 연동 설정은 최고 관리자만 변경할 수 있습니다.');
        $enabled = (isset($_POST['external_embed_enabled']) && $_POST['external_embed_enabled'] === 'Y') ? 'Y' : 'N';
        $ttl = isset($_POST['external_default_ttl']) ? (int)$_POST['external_default_ttl'] : 300;
        if ($ttl < 60) $ttl = 60;
        if ($ttl > 86400) $ttl = 86400;
        emc_set_setting('external_embed_enabled', $enabled);
        emc_set_setting('external_default_ttl', (string)$ttl);
        return array('외부 연동 기본 설정을 저장했습니다.', '');
    }

    if ($action === 'save_external_site') {
        if (!$is_super_admin) return array('', '외부 연동 사이트 설정은 최고 관리자만 변경할 수 있습니다.');
        $site_id = isset($_POST['site_id']) ? emc_clean_site_id($_POST['site_id']) : '';
        if ($site_id === '') return array('', '사이트 ID가 없습니다. 영문, 숫자, _, -만 사용할 수 있습니다.');
        $sites = emc_external_sites();
        $next = array();
        foreach ($sites as $s) {
            if ($s['site_id'] !== $site_id) $next[] = $s;
        }
        $secret = isset($_POST['secret_key']) ? trim((string)$_POST['secret_key']) : '';
        if ($secret === '') $secret = emc_random_secret(32);
        $next[] = array(
            'site_id' => $site_id,
            'site_name' => isset($_POST['site_name']) ? trim((string)$_POST['site_name']) : $site_id,
            'enabled' => (isset($_POST['enabled']) && $_POST['enabled'] === 'N') ? 'N' : 'Y',
            'allowed_origins' => isset($_POST['allowed_origins']) ? emc_external_split_lines($_POST['allowed_origins']) : array(),
            'allowed_rooms' => isset($_POST['allowed_rooms']) ? emc_external_split_lines($_POST['allowed_rooms']) : array('*'),
            'token_ttl' => isset($_POST['token_ttl']) ? (int)$_POST['token_ttl'] : (int)emc_get_setting('external_default_ttl', '300'),
            'secret_key' => $secret,
        );
        emc_external_save_sites($next);
        return array('외부 연동 사이트를 저장했습니다.', '');
    }

    if ($action === 'delete_external_site') {
        if (!$is_super_admin) return array('', '외부 연동 사이트 삭제는 최고 관리자만 할 수 있습니다.');
        $site_id = isset($_POST['site_id']) ? emc_clean_site_id($_POST['site_id']) : '';
        $next = array();
        foreach (emc_external_sites() as $s) {
            if ($s['site_id'] !== $site_id) $next[] = $s;
        }
        emc_external_save_sites($next);
        return array('외부 연동 사이트를 삭제했습니다.', '');
    }

    if ($action === 'save_room') {
        if (!$is_super_admin) return array('', '채팅방 설정 변경은 최고 관리자만 할 수 있습니다.');
        $room_id = isset($_POST['room_id']) ? emc_clean_room($_POST['room_id']) : '';
        if ($room_id === '') return array('', '채팅방 ID가 없습니다. 영문, 숫자, _, -만 사용할 수 있습니다.');
        $ok = emc_save_room($_POST);
        return $ok ? array('채팅방 설정을 저장했습니다.', '') : array('', '채팅방 설정 저장에 실패했습니다.');
    }

    if ($action === 'register_discovered_room') {
        if (!$is_super_admin) return array('', '채팅방 등록은 최고 관리자만 할 수 있습니다.');
        $room_id = isset($_POST['room_id']) ? emc_clean_room($_POST['room_id']) : '';
        if ($room_id === '') return array('', '등록할 채팅방 ID가 없습니다.');
        emc_register_room($room_id, $room_id);
        return array('기존 로그에서 발견된 채팅방을 등록했습니다.', '');
    }

    if ($action === 'clear_room_messages') {
        if (!$is_super_admin) return array('', '채팅방 로그 삭제는 최고 관리자만 할 수 있습니다.');
        $room_id = isset($_POST['room_id']) ? emc_clean_room($_POST['room_id']) : '';
        if ($room_id === '') return array('', '삭제할 채팅방 ID가 없습니다.');
        $table = emc_table('esils_chat_messages');
        $stmt = $db->prepare("DELETE FROM {$table} WHERE room_id = ?");
        if (!$stmt) return array('', '채팅방 로그 삭제 준비 실패: ' . $db->error);
        $stmt->bind_param('s', $room_id);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
        return array('채팅방 로그를 삭제했습니다. 삭제 건수: ' . (int)$affected, '');
    }

    if ($action === 'add_sub_admin') {
        if (!$is_super_admin) return array('', '부관리자 지정은 최고 관리자만 할 수 있습니다.');
        $member_srl = isset($_POST['member_srl']) ? (int)$_POST['member_srl'] : 0;
        if ($member_srl <= 0) return array('', '추가할 회원 번호가 없습니다.');
        $current = emc_get_sub_admin_srls();
        $current[] = $member_srl;
        emc_set_sub_admin_srls($current);
        return array('채팅 부관리자를 추가했습니다.', '');
    }

    if ($action === 'remove_sub_admin') {
        if (!$is_super_admin) return array('', '부관리자 해제는 최고 관리자만 할 수 있습니다.');
        $member_srl = isset($_POST['member_srl']) ? (int)$_POST['member_srl'] : 0;
        if ($member_srl <= 0) return array('', '해제할 회원 번호가 없습니다.');
        $next = array();
        foreach (emc_get_sub_admin_srls() as $srl) {
            if ((int)$srl !== $member_srl) $next[] = (int)$srl;
        }
        emc_set_sub_admin_srls($next);
        return array('채팅 부관리자 권한을 해제했습니다.', '');
    }

    if ($action === 'delete_message') {
        $id = isset($_POST['message_srl']) ? (int)$_POST['message_srl'] : 0;
        if ($id <= 0) return array('', '삭제할 메시지 번호가 없습니다.');
        $table = emc_table('esils_chat_messages');
        $stmt = $db->prepare("UPDATE {$table} SET is_deleted = 'Y' WHERE message_srl = ?");
        if (!$stmt) return array('', '삭제 준비 실패: ' . $db->error);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        return array('메시지를 삭제 처리했습니다.', '');
    }

    if ($action === 'add_block' || $action === 'quick_block') {
        $target_type = isset($_POST['target_type']) ? $_POST['target_type'] : '';
        $target_value = isset($_POST['target_value']) ? trim($_POST['target_value']) : '';
        $nick_name = isset($_POST['nick_name']) ? trim($_POST['nick_name']) : '';
        $reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';
        $room_id = isset($_POST['room_id']) ? trim($_POST['room_id']) : '_all';
        $days = isset($_POST['days']) ? (int)$_POST['days'] : 1;
        $hours = isset($_POST['hours']) ? (int)$_POST['hours'] : 0;
        $permanent = isset($_POST['permanent']) && $_POST['permanent'] === 'Y';
        if ($target_value === '') return array('', '차단 대상 값이 없습니다.');
        if ($permanent) {
            $expire = '00000000000000';
        } else {
            if ($days < 0) $days = 0;
            if ($hours < 0) $hours = 0;
            if ($days === 0 && $hours === 0) $days = 1;
            $expire = emc_time_to_regdate(time() + ($days * 86400) + ($hours * 3600));
        }
        $ok = emc_add_block($target_type, $target_value, $nick_name, $reason, $expire, $admin_info, $room_id);
        return $ok ? array('차단 목록에 추가했습니다.', '') : array('', '차단 추가에 실패했습니다.');
    }

    if ($action === 'deactivate_block') {
        $id = isset($_POST['block_srl']) ? (int)$_POST['block_srl'] : 0;
        if ($id <= 0) return array('', '해제할 차단 번호가 없습니다.');
        $table = emc_table('esils_chat_blocks');
        $stmt = $db->prepare("UPDATE {$table} SET is_active = 'N' WHERE block_srl = ?");
        if (!$stmt) return array('', '해제 준비 실패: ' . $db->error);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        return array('차단을 해제했습니다.', '');
    }

    if ($action === 'backup_date') {
        if (!$is_super_admin) return array('', '백업 생성/갱신은 최고 관리자만 할 수 있습니다. 부관리자는 백업 확인만 가능합니다.');
        $date = isset($_POST['backup_date']) ? preg_replace('/[^0-9]/', '', $_POST['backup_date']) : '';
        $room = isset($_POST['room_id']) ? trim($_POST['room_id']) : '_all';
        if (strlen($date) !== 8) return array('', '백업 날짜는 YYYYMMDD 형식이어야 합니다.');
        $res = emc_backup_date($date, $room, true);
        if (!$res['ok']) return array('', '백업 실패: ' . $res['error']);
        return array('백업 완료: ' . (int)$res['message_count'] . '건', '');
    }

    if ($action === 'clear_error_log') {
        if (!$is_super_admin) return array('', '에러 로그 삭제는 최고 관리자만 할 수 있습니다.');
        $file = isset($_POST['log_file']) ? basename((string)$_POST['log_file']) : 'error.log';
        if (!preg_match('/^error(?:-[0-9]{8}-[0-9]{6})?\.log$/', $file)) return array('', '허용되지 않은 로그 파일입니다.');
        $path = emc_log_dir() . '/' . $file;
        if (is_file($path)) @file_put_contents($path, '', LOCK_EX);
        return array('에러 로그를 비웠습니다.', '');
    }

    if ($action === 'delete_backup') {
        if (!$is_super_admin) return array('', '백업 삭제는 최고 관리자만 할 수 있습니다.');
        $id = isset($_POST['backup_srl']) ? (int)$_POST['backup_srl'] : 0;
        if ($id <= 0) return array('', '삭제할 백업 번호가 없습니다.');
        $table = emc_table('esils_chat_backups');
        $file_path = '';
        $stmt = $db->prepare("SELECT file_path FROM {$table} WHERE backup_srl = ?");
        if ($stmt) {
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->bind_result($file_path);
            $stmt->fetch();
            $stmt->close();
        }
        $stmt = $db->prepare("DELETE FROM {$table} WHERE backup_srl = ?");
        if (!$stmt) return array('', '백업 삭제 준비 실패: ' . $db->error);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        if ($file_path && strpos($file_path, '..') === false && is_file(__DIR__ . '/' . $file_path)) @unlink(__DIR__ . '/' . $file_path);
        return array('백업을 삭제했습니다.', '');
    }

    return array('', '지원하지 않는 관리 요청입니다.');
}

list($message, $error) = emc_admin_post_action($admin_info, $is_super_admin);
$view = isset($_GET['view']) ? $_GET['view'] : 'dashboard';
$valid_views = $is_super_admin ? array('dashboard','settings','rooms','room_edit','external','logs','blocks','backups','backup_detail','errors') : array('dashboard','logs','blocks','backups','backup_detail');
if (!in_array($view, $valid_views, true)) $view = $is_super_admin ? 'dashboard' : 'logs';
$settings = emc_get_settings();

function emc_admin_header($view, $message, $error, $is_super_admin, $admin_info)
{
    emc_send_security_headers('Content-Type: text/html; charset=UTF-8');
    $tabs = array('dashboard' => '요약');
    if ($is_super_admin) {
        $tabs['settings'] = '전체 설정';
        $tabs['rooms'] = '채팅방 관리';
        $tabs['external'] = '외부 연동';
    }
    $tabs['logs'] = '채팅 로그';
    $tabs['blocks'] = '차단 관리';
    $tabs['backups'] = '백업 확인';
    if ($is_super_admin) $tabs['errors'] = '에러 로그';
    echo '<!doctype html><html lang="ko"><head><meta charset="UTF-8"><title>Esils Chat 관리자</title>';
    echo '<style>
    :root{--bg:#f3f4f6;--card:#fff;--line:#e5e7eb;--text:#111827;--muted:#6b7280;--blue:#2563eb;--blue-dark:#1d4ed8;--green:#059669;--red:#dc2626;--gray:#4b5563;--soft:#f9fafb}
    body{margin:0;background:var(--bg);color:var(--text);font-family:Arial,"Malgun Gothic",sans-serif;font-size:13px;line-height:1.55}
    .wrap{max-width:1260px;margin:0 auto;padding:24px}.head{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:16px;gap:12px}.head h1{margin:0;font-size:24px;letter-spacing:-.03em}.head .sub{color:var(--muted);font-size:12px}.top-actions{display:flex;gap:8px;align-items:center;justify-content:flex-end;flex-wrap:wrap}
    .tabs{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0 18px}.tabs a{padding:9px 12px;border-radius:10px;background:#fff;border:1px solid var(--line);color:#374151;text-decoration:none}.tabs a:hover{border-color:#bfdbfe;background:#eff6ff}.tabs a.on{background:var(--blue-dark);color:#fff;border-color:var(--blue-dark);font-weight:700}
    .card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:16px;box-shadow:0 6px 18px rgba(15,23,42,.05)}.card h2{margin:0 0 10px;font-size:18px;letter-spacing:-.02em}.card h3{margin:16px 0 8px;font-size:15px}.card p{margin:6px 0}.card.compact{padding:14px}
    .msg{padding:10px 12px;border-radius:10px;margin-bottom:12px}.ok{background:#ecfdf5;color:#047857}.err{background:#fef2f2;color:#b91c1c}.warn{background:#fffbeb;color:#92400e}
    table{width:100%;border-collapse:collapse;background:#fff}th,td{border-bottom:1px solid var(--line);padding:8px;text-align:left;vertical-align:top}th{background:var(--soft);color:#374151;font-size:12px;white-space:nowrap}td small{color:var(--muted)}.content{white-space:pre-wrap;word-break:break-word;max-width:420px}.deleted{color:#6b7280;background:#fafafa}
    input[type=text],input[type=number],select,textarea{border:1px solid #d1d5db;border-radius:8px;padding:7px 8px;box-sizing:border-box;font:inherit;background:#fff}textarea{width:100%;min-height:70px}input:focus,select:focus,textarea:focus{outline:none;border-color:var(--blue);box-shadow:0 0 0 3px rgba(37,99,235,.13)}
    .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.kpi-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px}.kpi{background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px;box-shadow:0 4px 14px rgba(15,23,42,.04)}.kpi .label{color:var(--muted);font-size:12px}.kpi .value{font-size:24px;font-weight:800;letter-spacing:-.03em;margin-top:4px}.kpi .note{font-size:12px;color:var(--muted);margin-top:4px}
    .field label{display:block;font-weight:700;margin-bottom:5px}.field .desc{color:var(--muted);font-size:12px;margin-top:3px}.help-list{margin:8px 0 0;padding-left:18px;color:#374151}.help-list li{margin:3px 0}.section-note{border-left:4px solid #bfdbfe;background:#eff6ff;padding:10px 12px;border-radius:10px;color:#1e3a8a}.danger-note{border-left:4px solid #fecaca;background:#fef2f2;padding:10px 12px;border-radius:10px;color:#991b1b}
    .btn{display:inline-block;border:0;border-radius:8px;padding:7px 10px;background:var(--blue);color:#fff;text-decoration:none;cursor:pointer;font:inherit;line-height:1.25}.btn:hover{filter:brightness(.96)}.btn.red{background:var(--red)}.btn.gray{background:var(--gray)}.btn.green{background:var(--green)}.btn.slim{padding:4px 7px;font-size:12px}.actions{display:flex;gap:5px;flex-wrap:wrap}.filter{display:flex;gap:8px;flex-wrap:wrap;align-items:end}.filter .field{min-width:120px}.muted{color:var(--muted)}.code{font-family:Consolas,monospace;background:#f3f4f6;padding:2px 5px;border-radius:5px}.pager{display:flex;gap:8px;margin-top:12px}.badge{display:inline-block;padding:2px 7px;border-radius:999px;background:#eef2ff;color:#3730a3;font-size:12px}.badge.off{background:#fee2e2;color:#991b1b}.badge.okay{background:#dcfce7;color:#166534}
    .room-add-grid{display:grid;grid-template-columns:180px 180px 72px;gap:8px;align-items:start;max-width:460px}.room-add-grid input[type=text]{width:100%}.room-add-grid .btn{margin-top:25px;width:72px;text-align:center;padding-left:0;padding-right:0}.room-add-grid .field{min-width:0}.backup-create-grid{display:grid;grid-template-columns:150px 170px 104px;gap:8px;align-items:start;max-width:440px}.backup-create-grid input,.backup-create-grid select{width:100%}.backup-create-grid .btn{margin-top:25px;width:104px;text-align:center;padding-left:0;padding-right:0}.backup-create-grid .field{min-width:0}.block-form-grid{display:grid;grid-template-columns:145px 160px 250px 160px;gap:10px;align-items:start;max-width:760px}.block-form-grid .field{min-width:0}.block-form-grid input[type=text],.block-form-grid select{width:100%}.block-form-grid .block-reason{grid-column:1 / span 2}.block-form-grid .block-period{grid-column:3 / span 2}.period-line{display:flex;gap:6px;align-items:center;flex-wrap:nowrap;white-space:nowrap}.period-line .btn{width:70px;text-align:center;padding-left:0;padding-right:0;margin-left:8px}.block-form-grid .short-num{width:54px;text-align:center}.admin-filter{display:grid;grid-template-columns:160px 170px 180px 120px auto auto;gap:8px;align-items:start;max-width:940px}.admin-filter .field{min-width:0}.admin-filter input,.admin-filter select{width:100%}.admin-filter .btn{margin-top:25px}.admin-filter.errors{grid-template-columns:170px 115px 72px;max-width:380px}.admin-filter.errors .btn{width:72px;text-align:center;padding-left:0;padding-right:0}.room-code-text{width:100%;min-height:88px;font-family:Consolas,monospace;font-size:12px;line-height:1.45;background:#111827;color:#f9fafb;border-color:#111827}.fold-box{margin-top:12px;border:1px solid var(--line);border-radius:12px;background:#fff}.fold-box summary{cursor:pointer;padding:10px 12px;font-weight:700;color:#374151;background:#f9fafb;border-radius:12px}.fold-box table{border-top:1px solid var(--line)}.logbox{white-space:pre-wrap;word-break:break-word;background:#111827;color:#f9fafb;border-radius:12px;padding:12px;font-family:Consolas,monospace;font-size:12px;line-height:1.5;max-height:520px;overflow:auto}.modal{display:none;position:fixed;z-index:9999;left:0;top:0;right:0;bottom:0;align-items:center;justify-content:center;background:rgba(15,23,42,.55);padding:20px}.modal-box{width:min(760px,96vw);max-height:92vh;overflow:auto;background:#fff;border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.35);padding:18px}.modal-head{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px}.modal-head h3{margin:0;font-size:18px}.modal-section{margin-top:14px}.modal-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
    @media(max-width:1000px){.kpi-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.grid3{grid-template-columns:repeat(2,minmax(0,1fr))}}
    @media(max-width:800px){.grid,.grid3,.room-add-grid,.backup-create-grid,.block-form-grid,.admin-filter,.kpi-grid{grid-template-columns:1fr}.head{display:block}.top-actions{justify-content:flex-start;margin-top:10px}.room-add-grid .btn,.backup-create-grid .btn,.admin-filter .btn,.admin-filter.errors .btn{margin-top:0;width:auto;padding-left:10px;padding-right:10px}.block-form-grid .block-reason,.block-form-grid .block-period{grid-column:auto}.period-line{flex-wrap:wrap;white-space:normal}table{font-size:12px}}
    </style><script>
    function emcOpenCode(id){var el=document.getElementById(id); if(el){el.style.display="flex";}}
    function emcCloseCode(id){var el=document.getElementById(id); if(el){el.style.display="none";}}
    function emcCopyCode(id){var el=document.getElementById(id); if(!el){return;} el.focus(); el.select(); try{ if(navigator.clipboard && navigator.clipboard.writeText){navigator.clipboard.writeText(el.value);} else {document.execCommand("copy");} }catch(e){try{document.execCommand("copy");}catch(ignore){}}}
    function emcEscapeAttr(v){return String(v).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c];});}
    function emcBuildExternalIframe(key){
        var baseEl=document.getElementById("extBase_"+key), roomEl=document.getElementById("extRoom_"+key), tokenEl=document.getElementById("extAuth_"+key), wEl=document.getElementById("extWidth_"+key), hEl=document.getElementById("extHeight_"+key), out=document.getElementById("extCodeText_"+key+"_iframe");
        if(!baseEl||!roomEl||!tokenEl||!wEl||!hEl||!out){return;}
        var base=baseEl.value||"", room=roomEl.value||"main", token=tokenEl.value||"CHAT_TOKEN_HERE", width=wEl.value||"320", height=hEl.value||"420";
        width=String(width).replace(/[^0-9A-Za-z.%_-]/g,""); height=String(height).replace(/[^0-9A-Za-z.%_-]/g,"");
        if(width===""){width="320";} if(height===""){height="420";}
        var src=base+"?room="+encodeURIComponent(room)+"&auth="+encodeURIComponent(token);
        out.value="<iframe src=\""+emcEscapeAttr(src)+"\" width=\""+emcEscapeAttr(width)+"\" height=\""+emcEscapeAttr(height)+"\" style=\"border:0;overflow:hidden\" loading=\"lazy\"></iframe>";
        out.focus(); out.select();
    }
    </script></head><body><div class="wrap">';
    $role = $is_super_admin ? '최고 관리자' : '채팅 부관리자';
    $actions = '<div class="top-actions"></div>';
    echo '<div class="head"><div><h1>Esils Chat 관리자</h1><div class="sub">웹호스팅 AJAX 최적화판 / 권한: <b>' . emc_h($role) . '</b> / 로그인: ' . emc_h(emc_member_name($admin_info)) . ' / 설치 경로: <span class="code">./widgets/esils_chat</span></div></div>' . $actions . '</div>';
    echo '<div class="tabs">';
    foreach ($tabs as $k => $label) { $href = ($k === 'dashboard') ? 'admin.php' : ('admin.php?view=' . $k); echo '<a class="' . ($view === $k ? 'on' : '') . '" href="' . $href . '">' . emc_h($label) . '</a>'; }
    echo '</div>';
    if (!$is_super_admin) echo '<div class="msg warn">부관리자는 채팅 로그 확인, 채팅 메시지 삭제 처리, 사용자 차단/해제, 백업 확인만 가능합니다. 백업 삭제, 실제 설정 변경, 채팅방 설정 변경은 불가능합니다.</div>';
    if ($message) echo '<div class="msg ok">' . emc_h($message) . '</div>';
    if ($error) echo '<div class="msg err">' . emc_h($error) . '</div>';
}

function emc_admin_footer()
{
    echo '</div></body></html>';
}

function emc_fmt_regdate($regdate)
{
    if (!preg_match('/^\d{14}$/', $regdate)) return emc_h($regdate);
    return emc_h(substr($regdate,0,4) . '-' . substr($regdate,4,2) . '-' . substr($regdate,6,2) . ' ' . substr($regdate,8,2) . ':' . substr($regdate,10,2) . ':' . substr($regdate,12,2));
}

function emc_view_dashboard($settings, $is_super_admin)
{
    $db = emc_db();
    $msg_table = emc_table('esils_chat_messages');
    $blocks_table = emc_table('esils_chat_blocks');
    $backups_table = emc_table('esils_chat_backups');
    $rooms_table = emc_table('esils_chat_rooms');
    $today = emc_today();
    $total = 0; $today_count = 0; $active_blocks = 0; $backup_count = 0; $room_count = 0; $enabled_rooms = 0;
    $res = @$db->query("SELECT COUNT(*) AS c FROM {$msg_table}"); if ($res) { $r=$res->fetch_assoc(); $total=(int)$r['c']; $res->free(); }
    $res = @$db->query("SELECT COUNT(*) AS c FROM {$msg_table} WHERE regdate LIKE '" . $db->real_escape_string($today) . "%' "); if ($res) { $r=$res->fetch_assoc(); $today_count=(int)$r['c']; $res->free(); }
    $res = @$db->query("SELECT COUNT(*) AS c FROM {$blocks_table} WHERE is_active='Y' AND (expire_regdate='00000000000000' OR expire_regdate >= '" . emc_now() . "')"); if ($res) { $r=$res->fetch_assoc(); $active_blocks=(int)$r['c']; $res->free(); }
    $res = @$db->query("SELECT COUNT(*) AS c FROM {$backups_table}"); if ($res) { $r=$res->fetch_assoc(); $backup_count=(int)$r['c']; $res->free(); }
    $res = @$db->query("SELECT COUNT(*) AS c, SUM(CASE WHEN is_enabled='Y' THEN 1 ELSE 0 END) AS e FROM {$rooms_table}"); if ($res) { $r=$res->fetch_assoc(); $room_count=(int)$r['c']; $enabled_rooms=(int)$r['e']; $res->free(); }

    echo '<div class="kpi-grid">';
    echo '<div class="kpi"><div class="label">등록 채팅방</div><div class="value">' . $room_count . '</div><div class="note">활성 ' . $enabled_rooms . '개</div></div>';
    echo '<div class="kpi"><div class="label">전체 로그</div><div class="value">' . $total . '</div><div class="note">오늘 ' . $today_count . '건</div></div>';
    echo '<div class="kpi"><div class="label">활성 차단</div><div class="value">' . $active_blocks . '</div><div class="note">회원/IP/닉네임 차단</div></div>';
    echo '<div class="kpi"><div class="label">백업 기록</div><div class="value">' . $backup_count . '</div><div class="note">DB 백업 기준</div></div>';
    echo '</div>';
    echo '<div class="grid">';
    echo '<div class="card"><h2>전체 기본 설정</h2><p>비회원 채팅: <b>' . ($settings['allow_guest_chat']==='Y'?'허용':'비허용') . '</b></p><p>처음 상태: <b>' . ($settings['default_collapsed']==='Y'?'접힘':'펼침') . '</b></p><p>가로 폭: <b>' . emc_h($settings['max_width']) . '</b> / 높이: <b>' . emc_h($settings['height']) . '</b></p><p>백업 파일 저장: <b>' . ($settings['backup_file_enabled']==='Y'?'사용':'DB만 사용') . '</b></p>' . ($is_super_admin ? '<p><a class="btn" href="admin.php?view=settings">전체 설정</a> <a class="btn gray" href="admin.php?view=rooms">채팅방 관리</a></p>' : '') . '</div>';
    echo '<div class="card"><h2>웹호스팅 운영 기준</h2><ul class="help-list"><li>평상시 메시지 조회는 ' . emc_h($settings['poll_normal_seconds']) . '초마다 실행합니다.</li><li>최근 메시지 감지 후 ' . emc_h($settings['poll_active_duration_seconds']) . '초 동안 ' . emc_h($settings['poll_active_seconds']) . '초 주기로 빠르게 조회합니다.</li><li>내가 메시지를 보낸 직후 즉시 1회 갱신합니다.</li><li>접속자 수와 권한 상태 확인은 30초마다 실행합니다.</li><li>API 진단과 부하 계측 DB 기록은 제거되어 있습니다.</li><li>등록된 채팅방 ID만 API 접근을 허용합니다.</li></ul></div>';
    echo '</div>';
    echo '<div class="card"><h2>채팅방/설정 적용 방식</h2><p>채팅방 ID가 같으면 같은 대화방을 사용하고, ID가 다르면 메시지 로그가 분리됩니다.</p><p>설정은 <b>전체 기본 설정</b>을 먼저 적용한 뒤, 등록된 채팅방의 개별 설정값이 있으면 해당 방 설정이 우선합니다. 위젯 코드에 제목/크기/처음 상태를 직접 넣으면 그 코드값이 최우선입니다.</p><p>위젯이 페이지에 출력되면 해당 room_id는 자동 등록됩니다. 등록되지 않은 room_id의 API 접근은 차단됩니다.</p></div>';
    echo '<div class="card"><h2>설치/운영 도움말</h2><div class="grid"><div><h3>적용 순서</h3><ol class="help-list"><li><span class="code">widgets/esils_chat/</span>에 업로드</li><li><span class="code">install.php</span> 1회 실행</li><li>채팅방 관리에서 방 생성 후 코드생성</li><li>관리자 → 캐시파일 재생성</li></ol></div><div><h3>운영 보안</h3><ul class="help-list"><li>설치 확인 후 <b>install.php</b> 파일명 변경 또는 삭제</li><li>제거가 필요하면 README의 수동 제거 절차를 사용</li><li>백업/로그 폴더는 웹 접근 차단 파일 자동 생성</li></ul></div></div><p class="muted">관리 화면: <span class="code">' . emc_h(emc_widget_base_url() . '/admin.php') . '</span>' . ($is_super_admin ? ' / 설치 주소: <span class="code">' . emc_h(emc_widget_base_url() . '/install.php') . '</span>' : '') . '</p></div>';
}

function emc_view_settings($settings, $token)
{
    echo '<form method="post" class="card"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="save_settings">';
    echo '<h2>전체 기본 설정</h2><p class="section-note">이 값은 모든 채팅방의 기본값입니다. 채팅방별 설정에서 값을 비워두면 아래 값을 상속합니다.</p><div class="grid">';
    echo '<div class="field"><label>제목</label><input type="text" name="title" value="' . emc_h($settings['title']) . '" style="width:100%"></div>';
    echo '<div class="field"><label>비회원 채팅</label><select name="allow_guest_chat"><option value="N"' . ($settings['allow_guest_chat']==='N'?' selected':'') . '>비허용</option><option value="Y"' . ($settings['allow_guest_chat']==='Y'?' selected':'') . '>허용</option></select></div>';
    echo '<div class="field"><label>처음 상태</label><select name="default_collapsed"><option value="N"' . ($settings['default_collapsed']==='N'?' selected':'') . '>펼친다</option><option value="Y"' . ($settings['default_collapsed']==='Y'?' selected':'') . '>접는다</option></select></div>';
    echo '<div class="field"><label>관리 버튼 표시</label><select name="show_admin_link"><option value="Y"' . ($settings['show_admin_link']==='Y'?' selected':'') . '>표시</option><option value="N"' . ($settings['show_admin_link']==='N'?' selected':'') . '>숨김</option></select></div>';
    echo '<div class="field"><label>가로 폭(px 또는 %)</label><input type="text" name="max_width" value="' . emc_h($settings['max_width']) . '" placeholder="220 또는 100%"><div class="desc">숫자만 입력하면 px로 적용됩니다.</div></div>';
    echo '<div class="field"><label>메시지 영역 높이(px 또는 %)</label><input type="text" name="height" value="' . emc_h($settings['height']) . '" placeholder="190 또는 60%"></div>';
    echo '<div class="field"><label>전송 간격 제한(초)</label><input type="number" min="1" name="flood_seconds" value="' . emc_h($settings['flood_seconds']) . '"><div class="desc">최소 1초입니다. 0초 이하는 저장되지 않습니다.</div></div>';
    echo '<div class="field"><label>평상시 메시지 조회 주기(초)</label><input type="number" min="1" name="poll_normal_seconds" value="' . emc_h($settings['poll_normal_seconds']) . '"><div class="desc">기본 5초 권장. 웹호스팅에서는 3초 미만을 권장하지 않습니다.</div></div>';
    echo '<div class="field"><label>최근 메시지 후 빠른 조회 주기(초)</label><input type="number" min="1" name="poll_active_seconds" value="' . emc_h($settings['poll_active_seconds']) . '"><div class="desc">기본 3초 권장. 평상시 조회 주기보다 클 경우 자동 보정됩니다.</div></div>';
    echo '<div class="field"><label>빠른 조회 유지 시간(초)</label><input type="number" min="1" name="poll_active_duration_seconds" value="' . emc_h($settings['poll_active_duration_seconds']) . '"><div class="desc">최근 메시지 감지 후 빠른 조회를 유지할 시간입니다.</div></div>';
    echo '<div class="field"><label>전송 직후 즉시 갱신</label><select name="refresh_after_send"><option value="Y"' . ($settings['refresh_after_send'] === 'Y' ? ' selected' : '') . '>사용</option><option value="N"' . ($settings['refresh_after_send'] === 'N' ? ' selected' : '') . '>미사용</option></select><div class="desc">내가 메시지를 보낸 직후 채팅 내용을 즉시 1회 더 확인합니다.</div></div>';
    echo '<div class="field"><label>최대 글자 수</label><input type="number" name="max_length" value="' . emc_h($settings['max_length']) . '"></div>';
    echo '<div class="field"><label>비회원 표시 이름</label><input type="text" name="guest_label" value="' . emc_h($settings['guest_label']) . '"></div>';
    echo '</div><h2>보안/운영 안정화</h2><p class="section-note">웹호스팅 기준으로 DB 쓰기와 반복 요청을 줄이는 방향입니다. 비회원 채팅을 허용하는 방은 IP 제한을 낮게 잡는 것이 안전합니다.</p><div class="grid">';
    echo '<div class="field"><label>회원별 분당 전송 제한</label><input type="number" name="rate_limit_member_per_minute" value="' . emc_h($settings['rate_limit_member_per_minute']) . '"><div class="desc">방별 회원 기준 1분 전송 상한입니다.</div></div>';
    echo '<div class="field"><label>IP별 분당 전송 제한</label><input type="number" name="rate_limit_ip_per_minute" value="' . emc_h($settings['rate_limit_ip_per_minute']) . '"><div class="desc">방별 IP 기준 1분 전송 상한입니다.</div></div>';
    echo '<div class="field"><label>같은 문구 반복 차단 초</label><input type="number" name="same_text_seconds" value="' . emc_h($settings['same_text_seconds']) . '"></div>';
    echo '<div class="field"><label>로그 보관일</label><input type="number" name="log_retention_days" value="' . emc_h($settings['log_retention_days']) . '"><div class="desc">0이면 자동 삭제하지 않습니다. 7일 미만은 7일로 보정됩니다.</div></div>';
    echo '<div class="field"><label>일일 DB 백업</label><select name="backup_enabled"><option value="Y"' . ($settings['backup_enabled']==='Y'?' selected':'') . '>사용</option><option value="N"' . ($settings['backup_enabled']==='N'?' selected':'') . '>미사용</option></select><div class="desc">관리 페이지 접속 시 전날 로그를 DB에 백업합니다. API 요청에서는 실행하지 않습니다.</div></div>';
    echo '<div class="field"><label>백업 JSON 파일 저장</label><select name="backup_file_enabled"><option value="N"' . ($settings['backup_file_enabled']==='N'?' selected':'') . '>DB에만 보관</option><option value="Y"' . ($settings['backup_file_enabled']==='Y'?' selected':'') . '>파일도 저장</option></select><div class="desc">파일 저장 시 backups/private/에 저장하고 .htaccess로 접근 차단합니다.</div></div>';
    echo '<div class="field"><label>백업 보관일</label><input type="number" name="backup_retention_days" value="' . emc_h($settings['backup_retention_days']) . '"></div>';
    echo '</div><p><button class="btn green" type="submit">전체 설정 저장</button></p></form>';

    $q = isset($_GET['member_q']) ? trim($_GET['member_q']) : '';
    $current_srls = emc_get_sub_admin_srls();
    $current_members = emc_get_members_by_srl($current_srls);
    echo '<div class="card"><h2>채팅 부관리자</h2><p class="muted">부관리자는 운영 보조 권한입니다. 채팅 로그 확인, 채팅 메시지 삭제 처리, 사용자 차단/해제, 백업 확인이 가능하며 백업 삭제, 실제 설정 변경, 채팅방 설정 변경은 할 수 없습니다.</p>';
    echo '<form method="get" class="filter"><input type="hidden" name="view" value="settings"><div class="field"><label>사용자 검색</label><input type="text" name="member_q" value="' . emc_h($q) . '" placeholder="회원번호, 아이디, 닉네임, 이메일"></div><button class="btn" type="submit">검색</button></form>';
    if ($q !== '') {
        $found = emc_search_members($q, 20);
        echo '<h3>검색 결과</h3><table><thead><tr><th>회원번호</th><th>아이디</th><th>이름/닉네임</th><th>이메일</th><th>관리</th></tr></thead><tbody>';
        foreach ($found as $m) {
            $srl = (int)$m['member_srl'];
            $already = in_array($srl, $current_srls, true);
            echo '<tr><td>' . $srl . '</td><td>' . emc_h($m['user_id']) . '</td><td>' . emc_h($m['user_name']) . '<br><small>' . emc_h($m['nick_name']) . '</small></td><td>' . emc_h($m['email_address']) . '</td><td>';
            if ($already) echo '<span class="muted">이미 부관리자</span>';
            else echo '<form method="post"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="add_sub_admin"><input type="hidden" name="member_srl" value="' . $srl . '"><button class="btn green slim" type="submit">부관리자 추가</button></form>';
            echo '</td></tr>';
        }
        if (!$found) echo '<tr><td colspan="5" class="muted">검색 결과가 없습니다.</td></tr>';
        echo '</tbody></table>';
    }
    echo '<h3>현재 부관리자</h3><table><thead><tr><th>회원번호</th><th>아이디</th><th>이름/닉네임</th><th>이메일</th><th>관리</th></tr></thead><tbody>';
    foreach ($current_srls as $srl) {
        $m = isset($current_members[$srl]) ? $current_members[$srl] : array('member_srl'=>$srl,'user_id'=>'','user_name'=>'','nick_name'=>'삭제되었거나 찾을 수 없는 회원','email_address'=>'');
        echo '<tr><td>' . (int)$srl . '</td><td>' . emc_h($m['user_id']) . '</td><td>' . emc_h($m['user_name']) . '<br><small>' . emc_h($m['nick_name']) . '</small></td><td>' . emc_h($m['email_address']) . '</td><td><form method="post" onsubmit="return confirm(\'이 부관리자 권한을 해제할까요?\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="remove_sub_admin"><input type="hidden" name="member_srl" value="' . (int)$srl . '"><button class="btn red slim" type="submit">해제</button></form></td></tr>';
    }
    if (!$current_srls) echo '<tr><td colspan="5" class="muted">등록된 부관리자가 없습니다.</td></tr>';
    echo '</tbody></table></div>';
}


function emc_build_widget_embed_code($attrs)
{
    $code = '<img';
    foreach ($attrs as $key => $value) {
        if ($value === null || $value === '') continue;
        $key = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$key);
        if ($key === '') continue;
        $code .= ' ' . $key . '="' . htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8') . '"';
    }
    return $code . ' />';
}

function emc_room_code_modal($room_id, $room_title, $settings)
{
    $room_id = emc_clean_room($room_id);
    $effective = emc_get_effective_settings($room_id);
    if (!$effective) $effective = $settings;
    $title = trim((string)$room_title) !== '' ? trim((string)$room_title) : (isset($effective['title']) ? $effective['title'] : $settings['title']);
    $width = isset($effective['max_width']) ? $effective['max_width'] : $settings['max_width'];
    $height = isset($effective['height']) ? $effective['height'] : $settings['height'];
    $collapsed = isset($effective['default_collapsed']) && $effective['default_collapsed'] === 'Y' ? 'Y' : 'N';
    $safe_id = 'emc-code-modal-' . substr(md5($room_id), 0, 12);
    $inherit_id = 'emc-code-inherit-' . substr(md5($room_id), 0, 12);
    $fixed_id = 'emc-code-fixed-' . substr(md5($room_id), 0, 12);
    $inherit_code = emc_build_widget_embed_code(array(
        'class' => 'zbxe_widget_output',
        'widget' => 'esils_chat',
        'skin' => 'default',
        'room' => $room_id
    ));
    $fixed_code = emc_build_widget_embed_code(array(
        'class' => 'zbxe_widget_output',
        'widget' => 'esils_chat',
        'skin' => 'default',
        'room' => $room_id,
        'title' => $title,
        'max_width' => $width,
        'height' => $height,
        'default_collapsed' => $collapsed
    ));
    $html = '<button class="btn green slim" type="button" onclick="emcOpenCode(\'' . emc_h($safe_id) . '\')">코드생성</button>';
    $html .= '<div class="modal" id="' . emc_h($safe_id) . '" onclick="if(event.target===this) emcCloseCode(\'' . emc_h($safe_id) . '\')"><div class="modal-box">';
    $html .= '<div class="modal-head"><h3>위젯 코드 생성: ' . emc_h($room_id) . '</h3><button class="btn gray slim" type="button" onclick="emcCloseCode(\'' . emc_h($safe_id) . '\')">닫기</button></div>';
    $html .= '<p class="muted">게시글, 페이지, 레이아웃 HTML 영역에 아래 위젯 코드를 붙여 넣어 사용합니다.</p>';
    $html .= '<div class="modal-section"><h4>권장 코드: 관리자 설정 연동</h4><p class="muted">room 값만 고정합니다. 이후 관리자에서 제목, 크기, 처음 상태를 바꾸면 해당 설정이 계속 반영됩니다.</p><textarea readonly class="room-code-text" id="' . emc_h($inherit_id) . '" onclick="this.select()">' . emc_h($inherit_code) . '</textarea><div class="modal-actions"><button class="btn" type="button" onclick="emcCopyCode(\'' . emc_h($inherit_id) . '\')">복사</button></div></div>';
    $html .= '<div class="modal-section"><h4>현재값 고정 코드</h4><p class="muted">현재 제목, 크기, 처음 상태를 코드에 직접 넣습니다. 이후 관리자 설정을 바꿔도 코드에 들어간 값이 우선됩니다.</p><textarea readonly class="room-code-text" id="' . emc_h($fixed_id) . '" onclick="this.select()">' . emc_h($fixed_code) . '</textarea><div class="modal-actions"><button class="btn" type="button" onclick="emcCopyCode(\'' . emc_h($fixed_id) . '\')">복사</button><a class="btn gray" href="admin.php?view=room_edit&amp;room=' . urlencode($room_id) . '">이 방 설정 수정</a></div></div>';
    $html .= '<p class="muted">현재 적용값: 제목 <b>' . emc_h($title) . '</b>, 가로폭 <b>' . emc_h($width) . '</b>, 높이 <b>' . emc_h($height) . '</b>, 처음 상태 <b>' . ($collapsed === 'Y' ? '접힘' : '펼침') . '</b></p>';
    $html .= '</div></div>';
    return $html;
}

function emc_view_rooms($token, $settings)
{
    $db = emc_db();
    $rooms_table = emc_table('esils_chat_rooms');
    $msg_table = emc_table('esils_chat_messages');

    echo '<form method="post" class="card"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="save_room"><h2>채팅방 추가</h2><p class="muted">방 ID는 코드 생성과 API 접근 기준값입니다. 영문, 숫자, _, -만 사용하십시오.</p><div class="room-add-grid"><div class="field"><label>채팅방 ID</label><input type="text" name="room_id" placeholder="main"><div class="desc">예: main, guild1, trade</div></div><div class="field"><label>표시 제목</label><input type="text" name="room_title" placeholder="예: 자유 채팅"><div class="desc">비우면 전체 기본 제목 사용</div></div><button class="btn green" type="submit">추가</button></div></form>';

    $counts = array();
    $lasts = array();
    $res = @$db->query("SELECT room_id, COUNT(*) AS c, MAX(regdate) AS last_regdate FROM {$msg_table} GROUP BY room_id");
    if ($res) {
        while ($r = $res->fetch_assoc()) { $counts[$r['room_id']] = (int)$r['c']; $lasts[$r['room_id']] = $r['last_regdate']; }
        $res->free();
    }

    echo '<div class="card"><h2>등록된 채팅방</h2><p class="muted">코드생성을 누르면 해당 방에 맞는 위젯 코드를 바로 복사할 수 있습니다.</p><table><thead><tr><th>방 ID</th><th>제목</th><th>상태</th><th>주요 설정</th><th>로그</th><th>최근</th><th>관리</th></tr></thead><tbody>';
    $registered = array();
    $res = @$db->query("SELECT room_id, room_title, is_enabled, allow_guest_chat, default_collapsed, max_width, height, flood_seconds, max_length, show_admin_link, room_note FROM {$rooms_table} ORDER BY room_id ASC");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $registered[$row['room_id']] = true;
            $cnt = isset($counts[$row['room_id']]) ? $counts[$row['room_id']] : 0;
            $last = isset($lasts[$row['room_id']]) ? $lasts[$row['room_id']] : '';
            echo '<tr><td><b>' . emc_h($row['room_id']) . '</b></td><td>' . emc_h($row['room_title']) . '<br><small>' . emc_h($row['room_note']) . '</small></td><td>' . ($row['is_enabled']==='Y' ? '<span class="badge">활성</span>' : '<span class="badge off">비활성</span>') . '</td>';
            echo '<td>비회원: ' . emc_room_inherit_label($row, 'allow_guest_chat', $settings['allow_guest_chat']==='Y'?'허용':'비허용', true) . '<br>크기: ' . emc_room_inherit_label($row, 'max_width', $settings['max_width'], false) . ' / ' . emc_room_inherit_label($row, 'height', $settings['height'], false) . '<br>전송제한: ' . emc_room_inherit_label($row, 'flood_seconds', $settings['flood_seconds'], false) . '초</td>';
            echo '<td>' . (int)$cnt . '건</td><td>' . ($last ? emc_fmt_regdate($last) : '<span class="muted">없음</span>') . '</td><td><div class="actions">' . emc_room_code_modal($row['room_id'], $row['room_title'], $settings) . '<a class="btn slim" href="admin.php?view=room_edit&room=' . urlencode($row['room_id']) . '">설정</a><a class="btn gray slim" href="admin.php?view=logs&room=' . urlencode($row['room_id']) . '">로그</a>';
            echo '<form method="post" onsubmit="return confirm(\'이 채팅방의 모든 로그를 삭제할까요?\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="clear_room_messages"><input type="hidden" name="room_id" value="' . emc_h($row['room_id']) . '"><button class="btn red slim" type="submit">로그삭제</button></form>';
            echo '</div></td></tr>';
        }
        $res->free();
    }
    echo '</tbody></table></div>';

    $missing = array();
    foreach ($counts as $room_id => $cnt) if (!isset($registered[$room_id])) $missing[$room_id] = $cnt;
    if ($missing) {
        echo '<div class="card"><h2>기존 로그에서 발견된 미등록 채팅방</h2><p class="muted">강화판에서는 등록되지 않은 방의 API 접근을 차단합니다. 기존 로그가 있는 방은 아래에서 등록하십시오.</p><table><thead><tr><th>방 ID</th><th>로그</th><th>관리</th></tr></thead><tbody>';
        foreach ($missing as $room_id => $cnt) {
            echo '<tr><td><b>' . emc_h($room_id) . '</b></td><td>' . (int)$cnt . '건</td><td><form method="post"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="register_discovered_room"><input type="hidden" name="room_id" value="' . emc_h($room_id) . '"><button class="btn green slim" type="submit">등록</button></form></td></tr>';
        }
        echo '</tbody></table></div>';
    }
}

function emc_view_room_edit($token, $settings)
{
    $room_id = isset($_GET['room']) ? emc_clean_room($_GET['room']) : '';
    $room = $room_id ? emc_get_room($room_id) : null;
    if (!$room) $room = emc_room_row_default($room_id);
    $is_new = $room_id === '' || !emc_room_exists($room_id);
    echo '<form method="post" class="card"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="save_room"><h2>채팅방 설정</h2>';
    echo '<div class="grid">';
    if ($is_new) echo '<div class="field"><label>채팅방 ID</label><input type="text" name="room_id" value="' . emc_h($room['room_id']) . '" style="width:100%"><div class="desc">예: main, guild1, trade</div></div>';
    else echo '<div class="field"><label>채팅방 ID</label><input type="hidden" name="room_id" value="' . emc_h($room['room_id']) . '"><input type="text" value="' . emc_h($room['room_id']) . '" readonly style="width:100%"></div>';
    echo '<div class="field"><label>표시 제목</label><input type="text" name="room_title" value="' . emc_h($room['room_title']) . '" style="width:100%"><div class="desc">비우면 전체 제목을 사용합니다.</div></div>';
    echo '<div class="field"><label>방 상태</label><select name="is_enabled"><option value="Y"' . ($room['is_enabled']==='Y'?' selected':'') . '>활성</option><option value="N"' . ($room['is_enabled']==='N'?' selected':'') . '>비활성</option></select></div>';
    echo '<div class="field"><label>비회원 채팅</label><select name="allow_guest_chat"><option value=""' . ($room['allow_guest_chat']===''?' selected':'') . '>전체 설정 상속(' . ($settings['allow_guest_chat']==='Y'?'허용':'비허용') . ')</option><option value="N"' . ($room['allow_guest_chat']==='N'?' selected':'') . '>비허용</option><option value="Y"' . ($room['allow_guest_chat']==='Y'?' selected':'') . '>허용</option></select></div>';
    echo '<div class="field"><label>처음 상태</label><select name="default_collapsed"><option value=""' . ($room['default_collapsed']===''?' selected':'') . '>전체 설정 상속(' . ($settings['default_collapsed']==='Y'?'접힘':'펼침') . ')</option><option value="N"' . ($room['default_collapsed']==='N'?' selected':'') . '>펼친다</option><option value="Y"' . ($room['default_collapsed']==='Y'?' selected':'') . '>접는다</option></select></div>';
    echo '<div class="field"><label>관리 버튼 표시</label><select name="show_admin_link"><option value=""' . ($room['show_admin_link']===''?' selected':'') . '>전체 설정 상속(' . ($settings['show_admin_link']==='Y'?'표시':'숨김') . ')</option><option value="Y"' . ($room['show_admin_link']==='Y'?' selected':'') . '>표시</option><option value="N"' . ($room['show_admin_link']==='N'?' selected':'') . '>숨김</option></select></div>';
    echo '<div class="field"><label>가로 폭</label><input type="text" name="max_width" value="' . emc_h($room['max_width']) . '" placeholder="상속: ' . emc_h($settings['max_width']) . '"><div class="desc">220, 320px, 100% 가능. 비우면 상속.</div></div>';
    echo '<div class="field"><label>메시지 높이</label><input type="text" name="height" value="' . emc_h($room['height']) . '" placeholder="상속: ' . emc_h($settings['height']) . '"></div>';
    echo '<div class="field"><label>전송 간격 제한(초)</label><input type="number" min="1" name="flood_seconds" value="' . emc_h($room['flood_seconds']) . '" placeholder="상속: ' . emc_h($settings['flood_seconds']) . '"></div>';
    echo '<div class="field"><label>최대 글자 수</label><input type="number" name="max_length" value="' . emc_h($room['max_length']) . '" placeholder="상속: ' . emc_h($settings['max_length']) . '"></div>';
    echo '</div><div class="field"><label>관리 메모</label><textarea name="room_note">' . emc_h($room['room_note']) . '</textarea></div><p><button class="btn green" type="submit">채팅방 설정 저장</button> <a class="btn gray" href="admin.php?view=rooms">목록</a></p></form>';
}

function emc_admin_log_show_options($selected)
{
    $allowed = array(5, 10, 20, 50, 100, 200);
    $html = '';
    foreach ($allowed as $n) {
        $html .= '<option value="' . $n . '"' . ((int)$selected === $n ? ' selected' : '') . '>' . $n . '개</option>';
    }
    return $html;
}

function emc_render_log_row($row, $token, $is_super_admin)
{
    $deleted = $row['is_deleted'] === 'Y';
    $content = (string)$row['content'];
    if ($deleted && trim($content) === '') $content = '원문 없음 - 이전 버전에서 삭제된 메시지입니다.';
    echo '<tr><td>' . (int)$row['message_srl'] . '</td><td>' . emc_fmt_regdate($row['regdate']) . '</td><td>' . emc_h($row['room_id']) . '</td>';
    
    $author_meta = 'member_srl: ' . (int)$row['member_srl'];
    if (!empty($row['external_site_id']) || !empty($row['external_user_id'])) {
        $author_meta .= '<br>external: ' . emc_h($row['external_site_id']) . ':' . emc_h($row['external_user_id']);
    }
    echo '<td>' . emc_h($row['nick_name']) . '<br><small>' . $author_meta . '</small></td><td>' . emc_h($row['ipaddress']) . '</td>';
    echo '<td class="content' . ($deleted ? ' deleted' : '') . '">' . nl2br(emc_h($content)) . '</td>';
    echo '<td>' . ($deleted ? '<span class="badge off">삭제처리됨</span>' : '<span class="badge okay">정상</span>') . '</td><td><div class="actions">';
    if (!$deleted) {
        echo '<form method="post" onsubmit="return confirm(\'이 메시지를 삭제할까요? 로그에는 원문이 보관되고 채팅창에는 삭제 처리로 표시됩니다.\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="delete_message"><input type="hidden" name="message_srl" value="' . (int)$row['message_srl'] . '"><button class="btn red slim" type="submit">삭제</button></form>';
    }
    if ((int)$row['member_srl'] > 0) {
        echo '<form method="post" onsubmit="return confirm(\'이 회원을 현재 방 기준 1일 차단할까요?\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="quick_block"><input type="hidden" name="room_id" value="' . emc_h($row['room_id']) . '"><input type="hidden" name="target_type" value="member"><input type="hidden" name="target_value" value="' . (int)$row['member_srl'] . '"><input type="hidden" name="nick_name" value="' . emc_h($row['nick_name']) . '"><input type="hidden" name="reason" value="채팅 관리자 차단"><input type="hidden" name="days" value="1"><button class="btn gray slim" type="submit">회원 1일 차단</button></form>';
    }
    if (!empty($row['external_site_id']) && !empty($row['external_user_id'])) {
        $external_key = 'external:' . $row['external_site_id'] . ':' . $row['external_user_id'];
        echo '<form method="post" onsubmit="return confirm(\'이 외부 사용자를 현재 방 기준 1일 차단할까요?\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="quick_block"><input type="hidden" name="room_id" value="' . emc_h($row['room_id']) . '"><input type="hidden" name="target_type" value="external"><input type="hidden" name="target_value" value="' . emc_h($external_key) . '"><input type="hidden" name="nick_name" value="' . emc_h($row['nick_name']) . '"><input type="hidden" name="reason" value="채팅 관리자 차단"><input type="hidden" name="days" value="1"><button class="btn gray slim" type="submit">외부 1일 차단</button></form>';
    }
    if ($row['ipaddress']) {
        echo '<form method="post" onsubmit="return confirm(\'이 IP를 현재 방 기준 1일 차단할까요?\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="quick_block"><input type="hidden" name="room_id" value="' . emc_h($row['room_id']) . '"><input type="hidden" name="target_type" value="ip"><input type="hidden" name="target_value" value="' . emc_h($row['ipaddress']) . '"><input type="hidden" name="nick_name" value="' . emc_h($row['nick_name']) . '"><input type="hidden" name="reason" value="채팅 관리자 차단"><input type="hidden" name="days" value="1"><button class="btn gray slim" type="submit">IP 1일 차단</button></form>';
    }
    echo '</div></td></tr>';
}

function emc_view_logs($token, $is_super_admin)
{
    $db = emc_db();
    $table = emc_table('esils_chat_messages');
    $date = isset($_GET['date']) ? preg_replace('/[^0-9]/', '', $_GET['date']) : '';
    $room = isset($_GET['room']) ? emc_clean_room($_GET['room']) : '';
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $show_count = isset($_GET['show']) ? (int)$_GET['show'] : 5;
    if (!in_array($show_count, array(5,10,20,50,100,200), true)) $show_count = 5;
    $per = max(50, $show_count);
    if ($per > 200) $per = 200;
    $offset = ($page - 1) * $per;
    $where = array('1=1');
    if (strlen($date) === 8) $where[] = "regdate LIKE '" . $db->real_escape_string($date) . "%'";
    if ($room !== '') $where[] = "room_id = '" . $db->real_escape_string($room) . "'";
    if ($q !== '') {
        $eq = $db->real_escape_string($q);
        $where[] = "(nick_name LIKE '%{$eq}%' OR content LIKE '%{$eq}%' OR ipaddress LIKE '%{$eq}%' OR external_site_id LIKE '%{$eq}%' OR external_user_id LIKE '%{$eq}%')";
    }
    $where_sql = implode(' AND ', $where);

    echo '<div class="card"><h2>채팅 로그</h2><p class="muted">기본은 최근 5개만 바로 표시하고, 같은 페이지의 나머지 로그는 접힌 영역에 넣습니다. 표시 개수는 이 페이지 안에서 조정할 수 있습니다.</p><form class="filter admin-filter" method="get"><input type="hidden" name="view" value="logs">';
    echo '<div class="field"><label>날짜</label><input type="text" name="date" placeholder="YYYYMMDD" value="' . emc_h($date) . '"></div>';
    echo '<div class="field"><label>방 ID</label><select name="room"><option value=""' . ($room===''?' selected':'') . '>전체</option>' . emc_admin_room_options(false, $room) . '</select></div>';
    echo '<div class="field"><label>검색</label><input type="text" name="q" value="' . emc_h($q) . '"></div>';
    echo '<div class="field"><label>바로 표시</label><select name="show">' . emc_admin_log_show_options($show_count) . '</select><div class="desc">초기 노출 개수</div></div>';
    echo '<button class="btn" type="submit">검색</button><a class="btn gray" href="admin.php?view=logs">초기화</a></form></div>';

    $sql = "SELECT message_srl, room_id, member_srl, nick_name, content, ipaddress, external_site_id, external_user_id, regdate, is_deleted FROM {$table} WHERE {$where_sql} ORDER BY message_srl DESC LIMIT {$offset}, {$per}";
    $res = @$db->query($sql);
    $rows = array();
    if ($res) {
        while ($row = $res->fetch_assoc()) $rows[] = $row;
        $res->free();
    }
    $visible = array_slice($rows, 0, $show_count);
    $folded = array_slice($rows, $show_count);

    echo '<div class="card"><h2>최근 로그</h2><p class="muted">현재 페이지에서 ' . (int)count($rows) . '건을 불러왔고, 그중 ' . (int)count($visible) . '건을 바로 표시합니다.</p><table><thead><tr><th>번호</th><th>시각</th><th>방</th><th>작성자</th><th>IP</th><th>내용</th><th>상태</th><th>관리</th></tr></thead><tbody>';
    foreach ($visible as $row) emc_render_log_row($row, $token, $is_super_admin);
    if (!$visible) echo '<tr><td colspan="8" class="muted">표시할 채팅 로그가 없습니다.</td></tr>';
    echo '</tbody></table>';
    if ($folded) {
        echo '<details class="fold-box"><summary>나머지 ' . (int)count($folded) . '건 펼치기</summary><table><thead><tr><th>번호</th><th>시각</th><th>방</th><th>작성자</th><th>IP</th><th>내용</th><th>상태</th><th>관리</th></tr></thead><tbody>';
        foreach ($folded as $row) emc_render_log_row($row, $token, $is_super_admin);
        echo '</tbody></table></details>';
    }
    echo '<div class="pager">';
    $base = 'view=logs&date=' . urlencode($date) . '&room=' . urlencode($room) . '&q=' . urlencode($q) . '&show=' . (int)$show_count;
    if ($page > 1) echo '<a class="btn gray" href="admin.php?' . $base . '&page=' . ($page-1) . '">이전</a>';
    if (count($rows) >= $per) echo '<a class="btn gray" href="admin.php?' . $base . '&page=' . ($page+1) . '">다음</a>';
    echo '</div></div>';
}

function emc_view_blocks($token)
{
    $db = emc_db();
    $table = emc_table('esils_chat_blocks');
    $selected_room = isset($_GET['room']) ? trim($_GET['room']) : '';
    echo '<form method="post" class="card"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="add_block"><h2>차단 추가</h2><div class="block-form-grid">';
    echo '<div class="field"><label>적용 방 (전체는 _all)</label><select name="room_id">' . emc_admin_room_options(true, '_all') . '</select></div>';
    echo '<div class="field"><label>대상 종류</label><select name="target_type"><option value="member">회원번호</option><option value="ip">IP 주소</option><option value="nick">닉네임</option><option value="external">외부 사용자</option></select></div>';
    echo '<div class="field"><label>대상 값</label><input type="text" name="target_value" placeholder="member_srl / IP / 닉네임 / external:site:user"></div>';
    echo '<div class="field"><label>표시 이름</label><input type="text" name="nick_name"></div>';
    echo '<div class="field block-reason"><label>사유</label><input type="text" name="reason" value="채팅 관리자 차단"></div>';
    echo '<div class="field block-period"><label>차단 기간</label><div class="period-line"><input class="short-num" type="number" name="days" value="1"> <span>일</span> <input class="short-num" type="number" name="hours" value="0"> <span>시간</span> <label style="display:inline-flex;align-items:center;gap:4px;margin-left:8px"><input type="checkbox" name="permanent" value="Y"> 영구</label><button class="btn red" type="submit">추가</button></div></div>';
    echo '</div></form>';

    $now = emc_now();
    $res = @$db->query("SELECT block_srl, room_id, target_type, target_value, nick_name, reason, start_regdate, expire_regdate, created_nick_name, is_active FROM {$table} ORDER BY block_srl DESC LIMIT 200");
    echo '<div class="card"><h2>차단 목록</h2><table><thead><tr><th>번호</th><th>방</th><th>대상</th><th>이름</th><th>기간</th><th>사유</th><th>상태</th><th>관리</th></tr></thead><tbody>';
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $active = $row['is_active'] === 'Y' && ($row['expire_regdate'] === '00000000000000' || $row['expire_regdate'] >= $now);
            echo '<tr><td>' . (int)$row['block_srl'] . '</td><td>' . emc_h($row['room_id']) . '</td><td>' . emc_h($row['target_type']) . ': <b>' . emc_h($row['target_value']) . '</b></td><td>' . emc_h($row['nick_name']) . '</td>';
            echo '<td>' . emc_fmt_regdate($row['start_regdate']) . '<br><small>해제: ' . ($row['expire_regdate'] === '00000000000000' ? '영구' : emc_fmt_regdate($row['expire_regdate'])) . '</small></td><td>' . emc_h($row['reason']) . '</td><td>' . ($active ? '<b style="color:#dc2626">활성</b>' : '<span class="muted">비활성/만료</span>') . '</td><td>';
            if ($row['is_active'] === 'Y') {
                echo '<form method="post"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="deactivate_block"><input type="hidden" name="block_srl" value="' . (int)$row['block_srl'] . '"><button class="btn green slim" type="submit">해제</button></form>';
            }
            echo '</td></tr>';
        }
        $res->free();
    }
    echo '</tbody></table></div>';
}



function emc_external_php_sample($s, $room_sample, $embed_base_url)
{
    $ttl = (int)$s['token_ttl'];
    return "<?php\n" .
        "// Esils Chat 외부 연동 PHP 예제\n" .
        "// 이 코드는 게임 서버에서 실행되어야 하며, Secret Key를 브라우저에 직접 출력하면 안 됩니다.\n" .
        "function esils_chat_b64url(\$data) { return rtrim(strtr(base64_encode(\$data), '+/', '-_'), '='); }\n" .
        "\$site_id = '" . $s['site_id'] . "';\n" .
        "\$room = '" . $room_sample . "';\n" .
        "\$secret = '" . $s['secret_key'] . "';\n" .
        "\n" .
        "// 아래 두 값은 실제 게임 로그인 세션/데이터에서 가져오십시오.\n" .
        "\$login_user_id = isset(\$game_user_id) ? \$game_user_id : 'game_user_001';      // 예: 회원번호, 계정ID, 캐릭터ID\n" .
        "\$login_nickname = isset(\$game_nickname) ? \$game_nickname : '게임닉네임';    // 예: 게임 닉네임/캐릭터명\n" .
        "\n" .
        "\$payload = array(\n" .
        "    'site' => \$site_id,\n" .
        "    'room' => \$room,\n" .
        "    'user_id' => \$login_user_id,\n" .
        "    'nickname' => \$login_nickname,\n" .
        "    'iat' => time(),\n" .
        "    'exp' => time() + " . $ttl . ",\n" .
        "    'nonce' => substr(sha1(uniqid('', true) . mt_rand()), 0, 12),\n" .
        ");\n" .
        "\$payload_b64 = esils_chat_b64url(json_encode(\$payload, JSON_UNESCAPED_UNICODE));\n" .
        "\$sig = esils_chat_b64url(hash_hmac('sha256', \$payload_b64, \$secret, true));\n" .
        "\$chat_token = \$payload_b64 . '.' . \$sig;\n" .
        "?>\n" .
        "<iframe src=\"" . $embed_base_url . "?room=<?php echo rawurlencode(\$room); ?>&auth=<?php echo rawurlencode(\$chat_token); ?>\" width=\"320\" height=\"420\" style=\"border:0;overflow:hidden\" loading=\"lazy\"></iframe>";
}

function emc_external_perl_cgi_sample($s, $room_sample, $embed_base_url)
{
    $ttl = (int)$s['token_ttl'];
    return "#!/usr/bin/perl\n" .
        "# Esils Chat 외부 연동 Perl CGI 예제\n" .
        "# 이 코드는 게임 CGI 서버에서 실행되어야 하며, Secret Key를 브라우저에 직접 출력하면 안 됩니다.\n" .
        "use strict;\n" .
        "use warnings;\n" .
        "use utf8;\n" .
        "use Digest::SHA qw(hmac_sha256 sha1_hex);\n" .
        "use MIME::Base64 qw(encode_base64);\n" .
        "use Encode qw(encode);\n" .
        "\n" .
        "binmode STDOUT, ':encoding(UTF-8)';\n" .
        "\n" .
        "sub esils_chat_b64url {\n" .
        "    my (\$data) = @_;\n" .
        "    my \$b64 = encode_base64(\$data, '');\n" .
        "    \$b64 =~ tr{+/}{-_};\n" .
        "    \$b64 =~ s/=+\\z//;\n" .
        "    return \$b64;\n" .
        "}\n" .
        "\n" .
        "sub esils_chat_json_escape {\n" .
        "    my (\$s) = @_;\n" .
        "    \$s = '' unless defined \$s;\n" .
        "    \$s =~ s/\\\\/\\\\\\\\/g;\n" .
        "    \$s =~ s/\"/\\\\\"/g;\n" .
        "    \$s =~ s/\\r/\\\\r/g;\n" .
        "    \$s =~ s/\\n/\\\\n/g;\n" .
        "    \$s =~ s/\\t/\\\\t/g;\n" .
        "    return \$s;\n" .
        "}\n" .
        "\n" .
        "my \$site_id = '" . $s['site_id'] . "';\n" .
        "my \$room = '" . $room_sample . "';\n" .
        "my \$secret = '" . $s['secret_key'] . "';\n" .
        "my \$embed_base = '" . $embed_base_url . "';\n" .
        "\n" .
        "# 아래 두 값은 실제 게임 로그인 세션/데이터에서 가져오십시오.\n" .
        "# 예: hako류 CGI라면 현재 로그인 ID, 섬 이름, 군주명, 캐릭터명을 넣으면 됩니다.\n" .
        "my \$login_user_id = 'game_user_001';       # TODO: 실제 게임 로그인 고유 ID로 교체\n" .
        "my \$login_nickname = '게임닉네임';     # TODO: 실제 게임 닉네임/캐릭터명으로 교체\n" .
        "\n" .
        "my \$iat = time();\n" .
        "my \$exp = \$iat + " . $ttl . ";\n" .
        "my \$nonce = substr(sha1_hex(\$iat . rand() . \$\$), 0, 12);\n" .
        "\n" .
        "my \$json = '{'\n" .
        "    . '\"site\":\"' . esils_chat_json_escape(\$site_id) . '\",'\n" .
        "    . '\"room\":\"' . esils_chat_json_escape(\$room) . '\",'\n" .
        "    . '\"user_id\":\"' . esils_chat_json_escape(\$login_user_id) . '\",'\n" .
        "    . '\"nickname\":\"' . esils_chat_json_escape(\$login_nickname) . '\",'\n" .
        "    . '\"iat\":' . \$iat . ','\n" .
        "    . '\"exp\":' . \$exp . ','\n" .
        "    . '\"nonce\":\"' . esils_chat_json_escape(\$nonce) . '\"'\n" .
        "    . '}';\n" .
        "\n" .
        "my \$payload_b64 = esils_chat_b64url(encode('UTF-8', \$json));\n" .
        "my \$sig = esils_chat_b64url(hmac_sha256(\$payload_b64, \$secret));\n" .
        "my \$chat_token = \$payload_b64 . '.' . \$sig;\n" .
        "\n" .
        "print qq{<iframe src=\"\$embed_base?room=\$room&auth=\$chat_token\" width=\"320\" height=\"420\" style=\"border:0;overflow:hidden\" loading=\"lazy\"></iframe>};\n";
}

function emc_view_external($token, $settings)
{
    $sites = emc_external_sites();
    $enabled = emc_get_setting('external_embed_enabled', 'N') === 'Y';
    $ttl = (int)emc_get_setting('external_default_ttl', '300');
    if ($ttl < 60) $ttl = 300;
    echo '<div class="card"><h2>외부 연동 기본 설정</h2><p class="muted">관리 주체는 XE/Rhymix에 두고, 각 게임 로그인 닉네임은 서명 토큰으로만 채팅에 전달합니다. 외부 토큰으로 관리자/부관리자 권한은 부여하지 않습니다.</p>';
    echo '<form method="post" class="grid3"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="save_external_global">';
    echo '<div class="field"><label>외부 iframe 연동</label><select name="external_embed_enabled"><option value="N"' . (!$enabled ? ' selected' : '') . '>사용 안 함</option><option value="Y"' . ($enabled ? ' selected' : '') . '>사용</option></select><div class="desc">꺼져 있으면 외부 인증 토큰을 거부합니다.</div></div>';
    echo '<div class="field"><label>기본 토큰 유효시간(초)</label><input type="number" min="60" max="86400" name="external_default_ttl" value="' . (int)$ttl . '"><div class="desc">권장 300초. 게임 페이지가 열릴 때마다 새 토큰을 생성합니다.</div></div>';
    echo '<div class="field"><label>&nbsp;</label><button class="btn" type="submit">기본 설정 저장</button></div></form></div>';

    echo '<form method="post" class="card"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="save_external_site"><h2>외부 사이트 추가/수정</h2>';
    echo '<div class="grid3"><div class="field"><label>사이트 ID</label><input type="text" name="site_id" placeholder="hako55"><div class="desc">영문, 숫자, _, -만 사용. 예: hako55, garden</div></div>';
    echo '<div class="field"><label>표시 이름</label><input type="text" name="site_name" placeholder="구상의 모형정원"></div>';
    echo '<div class="field"><label>상태</label><select name="enabled"><option value="Y">사용</option><option value="N">중지</option></select></div></div>';
    echo '<div class="grid"><div class="field"><label>허용 도메인</label><textarea name="allowed_origins" placeholder="https://esils.com&#10;https://esil.shop"></textarea><div class="desc">iframe을 붙일 게임 도메인입니다. 한 줄에 하나씩 입력합니다.</div></div>';
    echo '<div class="field"><label>허용 채팅방</label><textarea name="allowed_rooms" placeholder="hakophp55&#10;hakonew&#10;또는 *"></textarea><div class="desc">한 줄에 하나씩 입력합니다. 전체 허용은 * 입니다.</div></div></div>';
    echo '<div class="grid3"><div class="field"><label>토큰 유효시간(초)</label><input type="number" min="60" max="86400" name="token_ttl" value="' . (int)$ttl . '"></div>';
    echo '<div class="field"><label>Secret Key</label><input type="text" name="secret_key" placeholder="비우면 자동 생성"><div class="desc">게임 서버와 채팅 서버만 알고 있어야 합니다.</div></div>';
    echo '<div class="field"><label>&nbsp;</label><button class="btn green" type="submit">사이트 저장</button></div></div></form>';

    echo '<div class="card"><h2>등록된 외부 사이트</h2><table><thead><tr><th>사이트</th><th>허용 도메인</th><th>허용 방</th><th>토큰</th><th>Secret</th><th>관리</th></tr></thead><tbody>';
    if (!$sites) echo '<tr><td colspan="6" class="muted">등록된 외부 사이트가 없습니다.</td></tr>';
    foreach ($sites as $s) {
        echo '<tr><td><b>' . emc_h($s['site_id']) . '</b><br><small>' . emc_h($s['site_name']) . ' / ' . ($s['enabled'] === 'Y' ? '사용' : '중지') . '</small></td>';
        echo '<td>' . emc_h(implode("\n", $s['allowed_origins'])) . '</td><td>' . emc_h(implode(', ', $s['allowed_rooms'])) . '</td><td>' . (int)$s['token_ttl'] . '초</td>';
        $site_key = 'ext_' . substr(md5($s['site_id']), 0, 12);
        echo '<td><code>' . emc_h(substr($s['secret_key'], 0, 10)) . '...</code></td><td><div class="actions"><button class="btn green slim" type="button" onclick="emcOpenCode(\'extCode_' . emc_h($site_key) . '\')">코드생성</button>';
        echo '<form method="post" onsubmit="return confirm(\'이 외부 사이트 설정을 삭제할까요?\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="delete_external_site"><input type="hidden" name="site_id" value="' . emc_h($s['site_id']) . '"><button class="btn red slim" type="submit">삭제</button></form></div></td></tr>';

        $room_sample = (!empty($s['allowed_rooms']) && $s['allowed_rooms'][0] !== '*') ? $s['allowed_rooms'][0] : 'main';
        $embed_base_url = emc_widget_base_url() . '/embed.php';
        $iframe_code = '<iframe src="' . $embed_base_url . '?room=' . rawurlencode($room_sample) . '&auth=CHAT_TOKEN_HERE" width="320" height="420" style="border:0;overflow:hidden" loading="lazy"></iframe>';
        $php_sample = emc_external_php_sample($s, $room_sample, $embed_base_url);
        $perl_sample = emc_external_perl_cgi_sample($s, $room_sample, $embed_base_url);
        echo '<div id="extCode_' . emc_h($site_key) . '" class="modal" onclick="if(event.target===this) emcCloseCode(\'extCode_' . emc_h($site_key) . '\')"><div class="modal-box"><div class="modal-head"><h3>외부 iframe 코드 생성 - ' . emc_h($s['site_id']) . '</h3><button class="btn gray slim" type="button" onclick="emcCloseCode(\'extCode_' . emc_h($site_key) . '\')">닫기</button></div>';
        echo '<p class="section-note">게임 서버에서 로그인한 사용자 ID와 닉네임으로 서명 토큰을 만든 뒤 iframe의 auth 값에 넣습니다. Secret Key는 브라우저에 직접 노출하지 말고 서버 코드 안에서만 사용하십시오.</p>';
        echo '<div class="modal-section"><h4>아이프레임 코드 생성</h4><p class="muted">아래 값으로 외부 페이지에 붙일 iframe 코드를 즉시 만들 수 있습니다. <b>CHAT_TOKEN_HERE</b>는 게임 서버에서 생성한 실제 토큰 변수/값으로 치환하십시오.</p>';
        echo '<input type="hidden" id="extBase_' . emc_h($site_key) . '" value="' . emc_h($embed_base_url) . '"><div class="grid3">';
        echo '<div class="field"><label>채팅방 ID</label>';
        if (!empty($s['allowed_rooms']) && $s['allowed_rooms'][0] !== '*') {
            echo '<select id="extRoom_' . emc_h($site_key) . '">';
            foreach ($s['allowed_rooms'] as $r) echo '<option value="' . emc_h($r) . '"' . ($r === $room_sample ? ' selected' : '') . '>' . emc_h($r) . '</option>';
            echo '</select>';
        } else {
            echo '<input type="text" id="extRoom_' . emc_h($site_key) . '" value="' . emc_h($room_sample) . '" placeholder="main">';
        }
        echo '<div class="desc">허용 채팅방에 등록된 room_id를 사용합니다.</div></div>';
        echo '<div class="field"><label>auth 토큰 표기</label><input type="text" id="extAuth_' . emc_h($site_key) . '" value="CHAT_TOKEN_HERE"><div class="desc">PHP/CGI 예제에서 생성한 토큰 변수로 치환</div></div>';
        echo '<div class="field"><label>가로 / 세로</label><div class="period-line"><input class="short-num" style="width:74px" type="text" id="extWidth_' . emc_h($site_key) . '" value="320"><span>×</span><input class="short-num" style="width:74px" type="text" id="extHeight_' . emc_h($site_key) . '" value="420"><button class="btn green slim" type="button" onclick="emcBuildExternalIframe(\'' . emc_h($site_key) . '\')">생성</button></div><div class="desc">숫자, px, %, vw, vh 사용 가능</div></div></div>';
        echo '<textarea id="extCodeText_' . emc_h($site_key) . '_iframe" class="room-code-text" readonly onclick="this.select()">' . emc_h($iframe_code) . '</textarea><div class="modal-actions"><button class="btn" type="button" onclick="emcCopyCode(\'extCodeText_' . emc_h($site_key) . '_iframe\')">아이프레임 코드 복사</button></div></div>';
        echo '<h4>PHP 게임용 전체 예제</h4><textarea id="extCodeText_' . emc_h($site_key) . '_php" class="room-code-text" readonly style="min-height:240px">' . emc_h($php_sample) . '</textarea><div class="modal-actions"><button class="btn" type="button" onclick="emcCopyCode(\'extCodeText_' . emc_h($site_key) . '_php\')">PHP 예제 복사</button></div>';
        echo '<h4>CGI/Perl 게임용 전체 예제</h4><p class="muted">Perl CGI 게임은 Digest::SHA, MIME::Base64, Encode 모듈로 같은 HMAC-SHA256 토큰을 만들 수 있습니다.</p><textarea id="extCodeText_' . emc_h($site_key) . '_cgi" class="room-code-text" readonly style="min-height:320px">' . emc_h($perl_sample) . '</textarea><div class="modal-actions"><button class="btn" type="button" onclick="emcCopyCode(\'extCodeText_' . emc_h($site_key) . '_cgi\')">CGI/Perl 예제 복사</button></div></div></div>';
    }
    echo '</tbody></table></div>';

    echo '<div class="card"><h2>외부 연동 기준</h2><ul class="help-list"><li>관리자/부관리자 권한은 XE/Rhymix 로그인 기준만 사용합니다.</li><li>외부 토큰 사용자는 일반 채팅 사용자로만 처리됩니다.</li><li>차단 관리에서 대상 종류를 <b>외부 사용자</b>로 선택하고 값에 <span class="code">external:사이트ID:게임유저ID</span>를 입력하면 특정 게임 유저를 차단할 수 있습니다.</li><li>외부 페이지에서는 iframe 방식이 가장 안정적입니다.</li><li>다른 도메인에서는 브라우저의 타사 쿠키 제한이 있을 수 있으므로, 게임 닉네임 연동은 서명 토큰 방식을 사용합니다.</li></ul></div>';
}

function emc_view_backups($token, $is_super_admin)
{
    $db = emc_db();
    $table = emc_table('esils_chat_backups');
    $default_date = date('Ymd', time() - 86400);
    if ($is_super_admin) {
        echo '<form method="post" class="card"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="backup_date"><h2>백업 생성</h2><p class="muted">기본은 DB 보관입니다. JSON 파일 저장을 켠 경우에도 backups/private/에 저장되고 웹 접근 차단 파일을 생성합니다.</p><div class="backup-create-grid"><div class="field"><label>날짜</label><input type="text" name="backup_date" value="' . emc_h($default_date) . '" placeholder="YYYYMMDD"><div class="desc">YYYYMMDD</div></div><div class="field"><label>방 ID</label><select name="room_id">' . emc_admin_room_options(true, '_all') . '</select><div class="desc">전체는 _all</div></div><button class="btn green" type="submit">생성/갱신</button></div></form>';
    } else {
        echo '<div class="card"><h2>백업 확인</h2><p class="muted">부관리자는 백업 내용을 확인할 수 있지만 생성, 갱신, 삭제는 할 수 없습니다.</p></div>';
    }
    $res = @$db->query("SELECT backup_srl, backup_date, room_id, message_count, file_path, file_ok, regdate FROM {$table} ORDER BY backup_date DESC, backup_srl DESC LIMIT 200");
    echo '<div class="card"><h2>백업 목록</h2><table><thead><tr><th>번호</th><th>날짜</th><th>방</th><th>메시지</th><th>파일</th><th>생성시각</th><th>관리</th></tr></thead><tbody>';
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            echo '<tr><td>' . (int)$row['backup_srl'] . '</td><td>' . emc_h($row['backup_date']) . '</td><td>' . emc_h($row['room_id']) . '</td><td>' . (int)$row['message_count'] . '건</td><td>' . ($row['file_ok']==='Y' ? emc_h($row['file_path']) : '<span class="muted">DB 보관</span>') . '</td><td>' . emc_fmt_regdate($row['regdate']) . '</td><td><div class="actions"><a class="btn slim" href="admin.php?view=backup_detail&id=' . (int)$row['backup_srl'] . '">보기</a>';
            if ($is_super_admin) echo '<form method="post" onsubmit="return confirm(\'이 백업을 삭제할까요?\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="delete_backup"><input type="hidden" name="backup_srl" value="' . (int)$row['backup_srl'] . '"><button class="btn red slim" type="submit">삭제</button></form>';
            echo '</div></td></tr>';
        }
        $res->free();
    }
    echo '</tbody></table></div>';
}

function emc_backup_messages_from_payload($data)
{
    if (!is_array($data)) return array();
    if (isset($data['messages']) && is_array($data['messages'])) return $data['messages'];
    if (isset($data['rows']) && is_array($data['rows'])) return $data['rows'];
    if (isset($data['data']) && is_array($data['data']) && isset($data['data']['messages']) && is_array($data['data']['messages'])) return $data['data']['messages'];
    if (isset($data[0]) && is_array($data[0])) return $data;
    return array();
}

function emc_view_backup_detail()
{
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $db = emc_db();
    $table = emc_table('esils_chat_backups');

    echo '<div class="card"><h2>백업 상세</h2>';
    if ($id <= 0) {
        echo '<p class="err msg">백업 번호가 올바르지 않습니다.</p><p><a class="btn gray" href="admin.php?view=backups">목록으로</a></p></div>';
        return;
    }

    // LONGTEXT bind_result 환경 차이와 과거 테이블 컬럼 차이를 피하기 위해 정수 ID 직접 조회 + fetch_assoc 사용.
    $res = @$db->query("SELECT * FROM {$table} WHERE backup_srl = " . (int)$id . " LIMIT 1");
    if (!$res) {
        echo '<p class="err msg">백업 조회 실패: ' . emc_h($db->error) . '</p><p><a class="btn gray" href="admin.php?view=backups">목록으로</a></p></div>';
        return;
    }
    $row = $res->fetch_assoc();
    $res->free();
    if (!$row) {
        echo '<p class="warn msg">백업을 찾을 수 없습니다.</p><p><a class="btn gray" href="admin.php?view=backups">목록으로</a></p></div>';
        return;
    }

    $backup_srl = isset($row['backup_srl']) ? (int)$row['backup_srl'] : $id;
    $backup_date = isset($row['backup_date']) ? (string)$row['backup_date'] : '';
    $room_id = isset($row['room_id']) ? (string)$row['room_id'] : '_all';
    $message_count = isset($row['message_count']) ? (int)$row['message_count'] : 0;
    $file_path = isset($row['file_path']) ? (string)$row['file_path'] : '';
    $file_ok = isset($row['file_ok']) ? (string)$row['file_ok'] : 'N';
    $regdate = isset($row['regdate']) ? (string)$row['regdate'] : '';

    $raw = '';
    foreach (array('backup_json', 'json', 'backup_data', 'data') as $json_col) {
        if (isset($row[$json_col]) && (string)$row[$json_col] !== '') {
            $raw = (string)$row[$json_col];
            break;
        }
    }
    $json_source = $raw !== '' ? 'DB' : '없음';

    if ($raw === '' && $file_ok === 'Y' && $file_path && strpos($file_path, '..') === false) {
        $candidate = __DIR__ . '/' . ltrim($file_path, '/');
        if (is_file($candidate)) {
            $file_raw = @file_get_contents($candidate);
            if ($file_raw !== false && $file_raw !== '') {
                $raw = $file_raw;
                $json_source = '파일';
            }
        }
    }

    $decode_error = '';
    $data = array();
    if ($raw !== '') {
        $raw_trim = trim($raw);
        $data = json_decode($raw_trim, true);
        if (!is_array($data)) {
            $decode_error = function_exists('json_last_error_msg') ? json_last_error_msg() : 'JSON 해석 실패';
            emc_log_error('backup_detail_json', 'backup_srl=' . $backup_srl . ' ' . $decode_error);
            $data = array();
        }
    } else {
        $decode_error = '저장된 DB JSON 또는 파일 JSON이 없습니다.';
    }

    $messages = emc_backup_messages_from_payload($data);
    $used_fallback = false;
    if (count($messages) === 0 && $message_count > 0) {
        // 백업 JSON이 비어 있어도 백업 날짜/방 기준으로 현재 로그 테이블에서 다시 확인한다.
        $messages = emc_backup_messages_from_db($backup_date, $room_id);
        $used_fallback = count($messages) > 0;
    }
    $shown_total = count($messages);

    echo '<p>날짜: <b>' . emc_h($backup_date) . '</b> / 방: <b>' . emc_h($room_id) . '</b> / 기록 메시지: <b>' . $message_count . '</b>건 / 표시 가능: <b>' . $shown_total . '</b>건</p>';
    echo '<p>보관 방식: <b>' . ($file_ok === 'Y' ? 'DB + 파일' : 'DB') . '</b> / JSON 출처: <b>' . emc_h($json_source) . '</b> / 생성시각: ' . emc_fmt_regdate($regdate) . '</p>';
    echo '<p>파일: ' . ($file_ok === 'Y' ? emc_h($file_path) : 'DB 보관') . '</p>';
    if ($decode_error !== '') echo '<p class="warn msg">백업 JSON 확인: ' . emc_h($decode_error) . '</p>';
    if ($used_fallback) echo '<p class="section-note">백업 JSON에서 메시지를 읽지 못해 현재 DB의 같은 날짜/방 로그를 기준으로 내용을 표시했습니다. 이 백업은 다시 생성/갱신하는 것을 권장합니다.</p>';
    if ($message_count > 0 && $shown_total === 0) echo '<p class="warn msg">메시지 수는 기록되어 있으나 표시할 내용을 찾지 못했습니다. 같은 날짜의 원본 로그가 삭제되었거나 과거 백업 JSON 저장이 실패한 상태입니다.</p>';
    echo '<p><a class="btn gray" href="admin.php?view=backups">목록으로</a></p></div>';

    echo '<div class="card"><h2>백업 메시지 내용</h2>';
    if ($shown_total === 0) {
        echo '<p class="muted">표시할 메시지가 없습니다.</p>';
    } else {
        echo '<table><thead><tr><th>번호</th><th>시각</th><th>방</th><th>작성자</th><th>IP</th><th>상태</th><th>내용</th></tr></thead><tbody>';
        $shown = 0;
        foreach ($messages as $m) {
            if ($shown >= 500) break;
            if (!is_array($m)) continue;
            $message_srl = isset($m['message_srl']) ? (int)$m['message_srl'] : (isset($m['id']) ? (int)$m['id'] : 0);
            $m_room = isset($m['room_id']) ? $m['room_id'] : $room_id;
            $member_srl = isset($m['member_srl']) ? (int)$m['member_srl'] : 0;
            $nick = isset($m['nick_name']) ? $m['nick_name'] : (isset($m['nick']) ? $m['nick'] : '');
            $ip = isset($m['ipaddress']) ? $m['ipaddress'] : (isset($m['ip']) ? $m['ip'] : '');
            $regdate_m = isset($m['regdate']) ? $m['regdate'] : '';
            $is_deleted = isset($m['is_deleted']) ? $m['is_deleted'] : 'N';
            $content = isset($m['content']) ? $m['content'] : '';
            if ($is_deleted === 'Y' && $content === '') $content = '원문 없음 - 이전 버전에서 삭제된 메시지입니다.';
            echo '<tr><td>' . $message_srl . '</td><td>' . emc_fmt_regdate($regdate_m) . '</td><td>' . emc_h($m_room) . '</td><td>' . emc_h($nick) . '<br><small>member_srl: ' . $member_srl . '</small></td><td>' . emc_h($ip) . '</td><td>' . ($is_deleted === 'Y' ? '<span class="badge off">삭제처리됨</span>' : '<span class="badge okay">정상</span>') . '</td><td class="content">' . nl2br(emc_h($content)) . '</td></tr>';
            $shown++;
        }
        echo '</tbody></table>';
        if ($shown_total > 500) echo '<p class="muted">500건까지만 미리보기로 표시합니다.</p>';
    }
    echo '</div>';

    echo '<div class="card"><h2>백업 JSON 원문</h2>';
    $raw_show = (string)$raw;
    if ($raw_show === '') {
        echo '<p class="muted">저장된 JSON 원문이 없습니다.</p>';
    } else {
        $raw_limit = 524288;
        if (strlen($raw_show) > $raw_limit) {
            $raw_show = substr($raw_show, 0, $raw_limit);
            echo '<p class="muted">용량이 커서 앞부분 512KB까지만 표시합니다.</p>';
        }
        echo '<textarea readonly style="min-height:220px;font-family:Consolas,monospace;font-size:12px">' . emc_h($raw_show) . '</textarea>';
    }
    echo '</div>';
}

function emc_list_error_log_files()
{
    $dir = emc_log_dir();
    $files = array();
    if (is_dir($dir)) {
        $list = @glob($dir . '/error*.log');
        if (is_array($list)) {
            foreach ($list as $path) {
                $base = basename($path);
                if (preg_match('/^error(?:-[0-9]{8}-[0-9]{6})?\.log$/', $base)) $files[] = $base;
            }
        }
    }
    rsort($files);
    if (!in_array('error.log', $files, true)) array_unshift($files, 'error.log');
    return array_values(array_unique($files));
}

function emc_tail_file($path, $max_bytes)
{
    if (!is_file($path)) return '';
    $size = @filesize($path);
    if ($size === false || $size <= 0) return '';
    $fp = @fopen($path, 'rb');
    if (!$fp) return '';
    if ($size > $max_bytes) @fseek($fp, -$max_bytes, SEEK_END);
    $data = @fread($fp, min($size, $max_bytes));
    @fclose($fp);
    return $data === false ? '' : $data;
}

function emc_view_error_logs($token)
{
    $files = emc_list_error_log_files();
    $selected = isset($_GET['file']) ? basename((string)$_GET['file']) : 'error.log';
    if (!preg_match('/^error(?:-[0-9]{8}-[0-9]{6})?\.log$/', $selected)) $selected = 'error.log';
    $line_count = isset($_GET['lines']) ? (int)$_GET['lines'] : 5;
    if (!in_array($line_count, array(5,10,20,50,100,200,500), true)) $line_count = 5;
    $dir = emc_log_dir();
    emc_harden_private_dir($dir);
    $path = $dir . '/' . $selected;
    $content = emc_tail_file($path, 262144);
    $size = is_file($path) ? (int)@filesize($path) : 0;

    echo '<div class="card"><h2>에러 로그</h2><p class="muted">최고 관리자 전용입니다. 기본은 최근 5줄만 바로 표시하고, 나머지는 접힌 영역에 넣습니다.</p>';
    echo '<form method="get" class="filter admin-filter errors"><input type="hidden" name="view" value="errors"><div class="field"><label>로그 파일</label><select name="file">';
    foreach ($files as $f) echo '<option value="' . emc_h($f) . '"' . ($selected === $f ? ' selected' : '') . '>' . emc_h($f) . '</option>';
    echo '</select></div><div class="field"><label>바로 표시</label><select name="lines">';
    foreach (array(5,10,20,50,100,200,500) as $n) echo '<option value="' . $n . '"' . ($line_count === $n ? ' selected' : '') . '>' . $n . '줄</option>';
    echo '</select><div class="desc">최근 로그 기준</div></div><button class="btn" type="submit">보기</button></form>';
    echo '<p>선택 파일: <b>' . emc_h($selected) . '</b> / 크기: <b>' . number_format($size) . '</b> bytes</p>';
    echo '<form method="post" onsubmit="return confirm(\'선택한 에러 로그를 비울까요?\')"><input type="hidden" name="token" value="' . emc_h($token) . '"><input type="hidden" name="action" value="clear_error_log"><input type="hidden" name="log_file" value="' . emc_h($selected) . '"><button class="btn red slim" type="submit">선택 로그 비우기</button></form>';
    echo '</div>';

    echo '<div class="card"><h2>로그 내용</h2>';
    if ($content === '') {
        echo '<p class="muted">기록된 에러가 없습니다.</p>';
    } else {
        if ($size > 262144) echo '<p class="muted">파일이 커서 마지막 256KB 범위 안에서만 표시합니다.</p>';
        $normalized = str_replace(array("\r\n", "\r"), "\n", $content);
        $lines = explode("\n", trim($normalized));
        if (count($lines) === 1 && $lines[0] === '') $lines = array();
        $total_lines = count($lines);
        $visible = array();
        $folded = array();
        if ($total_lines > 0) {
            $visible = array_slice($lines, max(0, $total_lines - $line_count));
            $folded = array_slice($lines, 0, max(0, $total_lines - $line_count));
        }
        echo '<p class="muted">총 ' . (int)$total_lines . '줄 중 최근 ' . (int)count($visible) . '줄을 바로 표시합니다.</p>';
        echo '<div class="logbox">' . emc_h(implode("\n", $visible)) . '</div>';
        if ($folded) {
            echo '<details class="fold-box"><summary>이전 로그 ' . (int)count($folded) . '줄 펼치기</summary><div class="logbox">' . emc_h(implode("\n", $folded)) . '</div></details>';
        }
    }
    echo '</div>';
}

emc_admin_header($view, $message, $error, $is_super_admin, $admin_info);
if ($view === 'dashboard') emc_view_dashboard($settings, $is_super_admin);
else if ($view === 'settings' && $is_super_admin) emc_view_settings($settings, $token);
else if ($view === 'rooms' && $is_super_admin) emc_view_rooms($token, $settings);
else if ($view === 'external' && $is_super_admin) emc_view_external($token, $settings);
else if ($view === 'room_edit' && $is_super_admin) emc_view_room_edit($token, $settings);
else if ($view === 'logs') emc_view_logs($token, $is_super_admin);
else if ($view === 'blocks') emc_view_blocks($token);
else if ($view === 'backups') emc_view_backups($token, $is_super_admin);
else if ($view === 'backup_detail') emc_view_backup_detail();
else if ($view === 'errors' && $is_super_admin) emc_view_error_logs($token);
emc_admin_footer();
