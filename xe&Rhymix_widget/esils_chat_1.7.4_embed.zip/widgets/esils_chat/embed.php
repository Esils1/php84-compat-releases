<?php
/**
 * Esils Chat external iframe embed endpoint.
 * 관리 주체는 XE/Rhymix에 두고, 외부 게임 로그인 닉네임은 서명 토큰으로만 전달한다.
 */
require_once __DIR__ . '/lib.php';
emc_bootstrap_xe(false);
emc_install_schema();

$room = emc_clean_room(isset($_GET['room']) ? $_GET['room'] : EMC_ROOM_DEFAULT);
$settings = emc_get_effective_settings($room);
if (!$settings || $settings['room_enabled'] !== 'Y') {
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!doctype html><meta charset="UTF-8"><div style="font-family:sans-serif;padding:16px">사용할 수 없는 채팅방입니다.</div>';
    exit;
}

$external_token = emc_external_token_from_request();
$external_error = '';
$external_identity = null;
if ($external_token !== '') {
    $external_identity = emc_external_verify_token($external_token, $room, $external_error);
}

$frame_origins = array("'self'");
foreach (emc_external_sites() as $site) {
    if ($site['enabled'] !== 'Y') continue;
    if (!emc_external_room_allowed($site, $room)) continue;
    foreach ($site['allowed_origins'] as $origin) {
        $origin = rtrim((string)$origin, '/');
        if ($origin !== '') $frame_origins[] = $origin;
    }
}
$frame_origins = array_values(array_unique($frame_origins));
if (!headers_sent()) {
    header('Content-Type: text/html; charset=UTF-8');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('X-Robots-Tag: noindex, nofollow');
    header('Content-Security-Policy: frame-ancestors ' . implode(' ', $frame_origins));
}

$title = $settings['title'];
$height = emc_sanitize_css_length(isset($_GET['height']) ? $_GET['height'] : $settings['height'], $settings['height'], 80, 1600, true);
$max_width = emc_sanitize_css_length(isset($_GET['width']) ? $_GET['width'] : $settings['max_width'], $settings['max_width'], 120, 2000, true);
$collapsed = isset($_GET['collapsed']) ? ($_GET['collapsed'] === 'Y' ? 'Y' : 'N') : ($settings['default_collapsed'] === 'Y' ? 'Y' : 'N');
$poll_normal = max(1, min(60, (int)$settings['poll_normal_seconds']));
$poll_active = max(1, min(60, (int)$settings['poll_active_seconds']));
if ($poll_active > $poll_normal) $poll_active = $poll_normal;
$poll_active_duration = max(1, min(300, (int)$settings['poll_active_duration_seconds']));
$refresh_after_send = isset($settings['refresh_after_send']) && $settings['refresh_after_send'] === 'N' ? 'N' : 'Y';
$base = emc_widget_base_url();
$ver = '20260605_174';
?><!doctype html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo emc_h($title); ?></title>
<link rel="stylesheet" href="<?php echo emc_h($base); ?>/assets/chat.css?v=<?php echo $ver; ?>">
<style>html,body{margin:0;padding:0;background:transparent}.emc-embed-wrap{padding:0}.emc-embed-error{font-family:Arial,"Malgun Gothic",sans-serif;font-size:13px;color:#991b1b;background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:12px;margin:0}</style>
</head>
<body>
<div class="emc-embed-wrap">
<?php if ($external_token !== '' && !$external_identity): ?>
    <div class="emc-embed-error">외부 채팅 인증 실패: <?php echo emc_h($external_error); ?></div>
<?php else: ?>
    <div class="emc-chat"
        data-api="<?php echo emc_h($base); ?>/api.php"
        data-admin-url="<?php echo emc_h($base); ?>/admin.php"
        data-room="<?php echo emc_h($room); ?>"
        data-title="<?php echo emc_h($title); ?>"
        data-height="<?php echo emc_h($height); ?>"
        data-max-width="<?php echo emc_h($max_width); ?>"
        data-collapsed="<?php echo emc_h($collapsed); ?>"
        data-poll-normal="<?php echo (int)$poll_normal; ?>"
        data-poll-active="<?php echo (int)$poll_active; ?>"
        data-poll-active-duration="<?php echo (int)$poll_active_duration; ?>"
        data-refresh-after-send="<?php echo emc_h($refresh_after_send); ?>"
        data-external-token="<?php echo emc_h($external_token); ?>"></div>
<?php endif; ?>
</div>
<script src="<?php echo emc_h($base); ?>/assets/chat.js?v=<?php echo $ver; ?>" defer></script>
</body>
</html>
