<?php
/*
 * Local UTF-8 chat for Gagawar / Promisance.
 * - Logged-in game users are fixed to their empire name.
 * - External visitors may choose any nickname.
 * - Chat control is handled only from admin.php.
 * - Active chat is automatically backed up and cleared every 3 days.
 */
error_reporting(E_ALL ^ E_NOTICE);
@session_start();
header('Content-Type: text/html; charset=utf-8');

$chat_dir = dirname(__FILE__) . '/chatlog';
$chat_file = $chat_dir . '/chatlog.json';
$legacy_chat_file = dirname(__FILE__) . '/chatlog.json';
$last_rotate_file = $chat_dir . '/last_rotate.txt';
$rotate_seconds = 60 * 60 * 24 * 3;
$max_active_messages = 500;

@include_once(dirname(__FILE__) . '/const.php');

if (!is_dir($chat_dir)) @mkdir($chat_dir, 0777);
if (!file_exists($chat_file) && file_exists($legacy_chat_file)) @rename($legacy_chat_file, $chat_file);

function chat_h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
function chat_format_time($ts) {
    if (!$ts) $ts = time();
    $week = array('일','월','화','수','목','금','토');
    return date('Y년 m월 d일', $ts) . ' (' . $week[intval(date('w', $ts))] . ') ' . date('H:i:s', $ts) . ' KST-9';
}
function chat_read_json($file) {
    if (!file_exists($file)) return array();
    $json = @file_get_contents($file);
    $data = @json_decode($json, true);
    return is_array($data) ? $data : array();
}
function chat_write_json($file, $data) {
    $fp = @fopen($file, 'c+');
    if (!$fp) return false;
    @flock($fp, LOCK_EX);
    @ftruncate($fp, 0);
    @rewind($fp);
    @fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE));
    @fflush($fp);
    @flock($fp, LOCK_UN);
    @fclose($fp);
    return true;
}
function chat_backup_file_name($dir, $ts) {
    return $dir . '/chat_backup_' . date('Ymd_His', $ts) . '.json';
}
function chat_rotate_if_needed($chat_file, $chat_dir, $last_rotate_file, $rotate_seconds) {
    $now = time();
    $last = 0;
    if (file_exists($last_rotate_file)) $last = intval(trim(@file_get_contents($last_rotate_file)));
    if ($last <= 0) {
        @file_put_contents($last_rotate_file, $now, LOCK_EX);
        return;
    }
    if (($now - $last) < $rotate_seconds) return;
    $chat = chat_read_json($chat_file);
    if (count($chat) > 0) {
        $backup = chat_backup_file_name($chat_dir, $now);
        chat_write_json($backup, $chat);
        chat_write_json($chat_file, array());
    }
    @file_put_contents($last_rotate_file, $now, LOCK_EX);
}
function chat_clean_text($s, $max) {
    $s = trim((string)$s);
    $s = str_replace(array("\r", "\n", "\t"), ' ', $s);
    $s = preg_replace('/\s+/u', ' ', $s);
    if (function_exists('mb_substr')) $s = mb_substr($s, 0, $max, 'UTF-8');
    else $s = substr($s, 0, $max);
    return $s;
}
function chat_current_empire() {
    global $dbhost, $dbuser, $dbpass, $dbname, $playerdb;
    if (!isset($_COOKIE['usernamecookie']) || !isset($_COOKIE['passwordcookie'])) return '';
    $u = $_COOKIE['usernamecookie'];
    $p = $_COOKIE['passwordcookie'];
    if ($u === '' || $p === '') return '';
    $link = @mysql_connect($dbhost, $dbuser, $dbpass);
    if (!$link) return '';
    if (!@mysql_select_db($dbname, $link)) return '';
    @mysql_query('SET NAMES utf8', $link);
    $u = mysql_real_escape_string($u, $link);
    $p = mysql_real_escape_string($p, $link);
    $tbl = isset($playerdb) && $playerdb != '' ? $playerdb : 'players';
    $q = @mysql_query("SELECT empire,username,disabled FROM $tbl WHERE username='$u' AND password='$p' LIMIT 1", $link);
    if ($q && ($r = mysql_fetch_assoc($q))) {
        if (intval($r['disabled']) > 2) return '';
        if (trim($r['empire']) != '') return trim($r['empire']);
        return trim($r['username']);
    }
    return '';
}

chat_rotate_if_needed($chat_file, $chat_dir, $last_rotate_file, $rotate_seconds);

$login_name = chat_current_empire();
$logged_in = ($login_name !== '');
$cookie_name = isset($_COOKIE['chat_name']) ? $_COOKIE['chat_name'] : '';
$default_name = $logged_in ? $login_name : $cookie_name;
$chat = chat_read_json($chat_file);

if (isset($_GET['load'])) {
    if (count($chat) == 0) {
        echo "<div class='chat-empty'>아직 채팅 내용이 없습니다.</div>";
        exit;
    }
    $start = count($chat) - 100;
    if ($start < 0) $start = 0;
    for ($i=$start; $i<count($chat); $i++) {
        $name = isset($chat[$i]['name']) ? $chat[$i]['name'] : '익명';
        $msg = isset($chat[$i]['message']) ? $chat[$i]['message'] : '';
        $ts = isset($chat[$i]['ts']) ? intval($chat[$i]['ts']) : 0;
        $time = $ts > 0 ? chat_format_time($ts) : (isset($chat[$i]['time']) ? $chat[$i]['time'] : '');
        echo "<div class='chat-msg'><span class='chat-name'>".chat_h($name)."</span><span class='chat-text'>".chat_h($msg)."</span><span class='chat-time'>".chat_h($time)."</span></div>";
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $name = $logged_in ? $login_name : chat_clean_text(isset($_POST['name']) ? $_POST['name'] : '', 24);
    if ($name === '') $name = '익명';
    if (!$logged_in) @setcookie('chat_name', $name, time() + 60 * 60 * 24 * 30, '/');
    $message = chat_clean_text(isset($_POST['message']) ? $_POST['message'] : '', 300);
    if ($message !== '') {
        $now = time();
        $chat[] = array(
            'name' => $name,
            'message' => $message,
            'time' => chat_format_time($now),
            'ts' => $now,
            'ip' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''
        );
        if (count($chat) > $max_active_messages) $chat = array_slice($chat, -$max_active_messages);
        chat_write_json($chat_file, $chat);
    }
    echo 'OK';
    exit;
}
?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>가가전쟁 채팅방</title>
<style>
body{font-family:Arial,'Malgun Gothic',sans-serif;margin:0;background:#eef3f8;color:#17202a;font-size:13px}.head{background:#2f3d50;color:#fff;padding:8px 10px;font-weight:bold}.chat-box{height:230px;overflow-y:auto;padding:10px;background:#fff;border-bottom:1px solid #ccd4dd}.chat-msg{margin-bottom:7px;line-height:1.35}.chat-name{font-weight:bold;color:#1f5fa8;margin-right:7px}.chat-text{color:#222}.chat-time{display:block;font-size:11px;color:#888;margin-left:0;margin-top:2px}.chat-empty{color:#777;padding:10px}.form{display:table;width:100%;box-sizing:border-box;padding:8px;background:#f6f8fb}.row{display:table-row}.cell{display:table-cell;padding:2px;vertical-align:middle}.name{width:110px}.name input{width:100px}.msg input{width:100%;box-sizing:border-box}.send{width:58px}input{border:1px solid #aeb8c4;padding:6px;border-radius:3px}button{background:#2f3d50;color:#fff;border:0;border-radius:3px;padding:7px 10px;cursor:pointer}.fixed{background:#e9edf3;color:#333}.note{font-size:11px;color:#667;padding:0 10px 8px;background:#f6f8fb}</style>
<script>
function enc(v){return encodeURIComponent(v);}
function loadChat(){var x=new XMLHttpRequest();x.open('GET','chat.php?load=1&t='+(new Date().getTime()),true);x.onreadystatechange=function(){if(x.readyState==4&&x.status==200){var b=document.getElementById('chat-box');b.innerHTML=x.responseText;b.scrollTop=b.scrollHeight;}};x.send(null);}
function sendChat(e){if(e&&e.preventDefault)e.preventDefault();var n=document.getElementById('name')?document.getElementById('name').value:'';var m=document.getElementById('message').value;if(m.replace(/^\s+|\s+$/g,'')=='')return false;var x=new XMLHttpRequest();x.open('POST','chat.php',true);x.setRequestHeader('Content-Type','application/x-www-form-urlencoded');x.onreadystatechange=function(){if(x.readyState==4){document.getElementById('message').value='';loadChat();}};x.send('name='+enc(n)+'&message='+enc(m));return false;}
window.onload=function(){loadChat();setInterval(loadChat,5000);document.getElementById('chat-form').onsubmit=sendChat;document.getElementById('message').focus();};
</script>
</head>
<body>
<div class="head">가가전쟁 채팅방</div>
<div id="chat-box" class="chat-box"></div>
<form id="chat-form" class="form" method="post" action="chat.php">
<div class="row">
<div class="cell name"><?php if ($logged_in) { ?><input class="fixed" type="text" value="<?php echo chat_h($default_name); ?>" readonly><?php } else { ?><input id="name" name="name" type="text" value="<?php echo chat_h($default_name); ?>" placeholder="이름"><?php } ?></div>
<div class="cell msg"><input id="message" name="message" type="text" maxlength="300" placeholder="메시지를 입력하세요"></div>
<div class="cell send"><button type="submit">전송</button></div>
</div>
</form>
<div class="note"><?php if ($logged_in) { ?>로그인 사용자는 제국 이름으로 고정됩니다.<?php } else { ?>외부 접속자는 이름을 입력하고 채팅할 수 있습니다.<?php } ?></div>
</body>
</html>
