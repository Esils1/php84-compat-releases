<?php
//!!!S
	if($digibbs != 0)  {
	$data_iddata = $db->dataiddata();

	$signup_name = $data_id[name];
	$signup_email = $data_iddata[email];
	$signup_email_verify = $data_iddata[email];
	$signup_username = $data_id[id];
	$signup_password = substr(md5($data_id[id] . $digibbskey), 0, 8);
	$signup_password_verify = substr(md5($data_id[id] . $digibbskey), 0, 8);
}
//!!!E

//!!!T START
  $GLOBALS[l_empireempire] = "제국 이름은 영문자/숫자로만 구성되어야 합니다.<br>";
//!!!T END

include("funcs.php");
setcookie("usernamecookie","");
setcookie("passwordcookie","");
HTMLbegincompact("Signup");

function EndNow ($reason)
{
	print "$reason<br>\n";
	HTMLendcompact();
	exit;
}

if ($signupsclosed)
	EndNow("죄송하지만, 현재 게임은 신규 가입을 받지 않고 있습니다.");
$lockdb = 0;							// need to allow DB modifications for signups
if ($do_signup)
{
//!!!S
if($onlyenglish == 1)  {
  if(!preg_match("/^[\w]+$/", $signup_empire)) {
    echo $GLOBALS[l_empireempire];
    $flag = 1;
    exit;
    }
  }
//!!!E
	if (($signup_username == "") || ($signup_password == ""))
		EndNow("당신은 암호와 아이디를 모두 입력하셔야 합니다!");
//	if (!strstr($signup_name," "))
//		EndNow("Sorry, you cannot signup without FULL and CORRECT information.<br>
//			Everybody has a last name, and I doubt you're an exception.<br>
//			Why do we ask?  Prevent cheating, that's all.");
//	if (stristr($signup_name,"the "))
//		EndNow("Nice try, but nobody has 'The' as part of their name.");
	if ((strstr($signup_email,",")) || (strstr($signup_email," ")) || (!strstr($signup_email,".")) || (!strstr($signup_email,"@")))
		EndNow("이메일 주소를 바르게 입력하시길 바랍니다.");
	if ($signup_password != $signup_password_verify)
		EndNow("암호와 암호 확인이 일치하지 않습니다!");
	if ($signup_email != $signup_email_verify)
		EndNow("당신의 이메일 주소는 이메일 주소 확인과 일치하지 않습니다!");
	if (sqleval("SELECT COUNT(*) FROM $playerdb WHERE username='$signup_username';"))
		EndNow("당신은 이미 가입되어 있습니다!");
	if (sqleval("SELECT COUNT(*) FROM $playerdb WHERE empire='$signup_empire';"))
		EndNow("죄송하지만, 그 제국 이름은 이미 사용되고 있습니다!");

	$multi = sqleval("SELECT COUNT(*) FROM $playerdb WHERE email='$signup_email' AND land>0 AND disabled!=2;");

	mysql_query("INSERT INTO $playerdb (num) VALUES (NULL);");	// add a new user entry (with defaults)
	$users = loadUser(mysql_insert_id());				// and load it

	$users[username] = $signup_username;
	$users[password] = md5($signup_password);
	$users[name] = $signup_name;
	$users[email] = $signup_email;
	$users[IP] = $REMOTE_ADDR;

	$users[signedup] = $time;
	if ($users[num] == 1) {
		$users[disabled] = 2;
		addBank($config[banknum]);
	}
	else	$users[disabled] = 0;
	$users[valcode] = md5($users[username].mt_rand().$users[email]);// should be fairly unique
	$users[idle] = $time;

	$users[empire] = trim(HTMLSpecialChars($signup_empire));
	$users[race] = $signup_race;
	$users[era] = 1;
	$users[rank] = $users[num];

	$users[turns] = $config[initturns];

	$users[msgtime] = $time;
	$users[newstime] = $time;

	saveUserDataNet($users,"networth username password name email IP signedup disabled valcode idle empire race era rank turns msgtime newstime");

	if ($multi)
		mysql_query("UPDATE $playerdb SET ismulti=1,disabled=3 WHERE email='$signup_email' AND disabled!=2;");

//!!!S
//	mail($users[email],"[중요] $config[servname] - 인증코드 - $users[empire] (#$users[num])","
//$config[servname]에 가입하신 것을 축하합니다!
//
//사용자명: $signup_username
//인증 코드: $users[valcode]
//
//$config[valturns] 턴을 노신 뒤에 인증 코드를 입력하셔야 계속 놀 수 있습니다.
//
//http://www.digirave.net
//$config[adminemail]
//","From: 가가전쟁 <$config[valemail]>\nX-Mailer: Promisance Automatic Validation Script");
//!!!E
?>
가가전쟁에 오신것을 환영합니다, <b><?php echo $users[empire]?> (#<?php echo $users[num]?>)</b>!<br>
<a href="<?php echo $config[main]?>?action=login">로그인</a> 하셔서 제국을 관리하시길 바랍니다!<br><br>
<?php
	EndNow("");
}
?>
<?php
if($digibbs != 0)  {?>
<form method="post" action="<?php echo $config[main]?>?action=signup">
<table class="inputtable">
<tr><th colspan="2" style="font-size:large">개인 정보</th></tr>
<tr><th class="aright">이름:</th>
    <td><?php echo $signup_name?></td></tr>
<tr><th class="aright">이메일:</th>
    <td><?php echo $signup_email?></td></tr>
<tr><th colspan="2" style="font-size:large">게임 정보</th></tr>
<tr><th class="aright">아이디:</th>
    <td><?php echo $signup_username?></td></tr>
<tr><th class="aright">제국 이름:</th>
    <td><input type="text" name="signup_empire" size="24" maxlength="32"></td></tr>
<tr><th class="aright">당신의 종족:</th>
    <td><select name="signup_race" size="1">
<?php }
else{
?>
<form method="post" action="<?php echo $config[main]?>?action=signup">
<table class="inputtable">
<tr><th colspan="2" style="font-size:large">개인 정보</th></tr>
<tr><th class="aright">이름:</th>
    <td><input type="text" name="signup_name" size="24"></td></tr>
<tr><th class="aright">이메일:</th>
    <td><input type="text" name="signup_email" size="24"></td></tr>
<tr><th class="aright">이메일 확인:</th>
    <td><input type="text" name="signup_email_verify" size="24"></td></tr>
<tr><th colspan="2" style="font-size:large">게임 정보</th></tr>
<tr><th class="aright">아이디:</th>
    <td><input type="text" name="signup_username" size="8"></td></tr>
<tr><th class="aright">암호:</th>
    <td><input type="password" name="signup_password" size="8"></td></tr>
<tr><th class="aright">암호 확인:</th>
    <td><input type="password" name="signup_password_verify" size="8"></td></tr>
<tr><th class="aright">제국 이름:</th>
    <td><input type="text" name="signup_empire" size="24" maxlength="32"></td></tr>
<tr><th class="aright">당신의 종족:</th>
    <td><select name="signup_race" size="1">
<?php
}
$races = mysql_query("select id,name from $racedb;");
while ($race = mysql_fetch_array($races))
{
?>
    <option value="<?php echo $race[id]?>"<?php if ($race[id] == 1) print " selected";?>><?php echo $race[name]?></option>
<?php
}
?>
    </select></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td><input type="submit" name="do_signup" value="가입하기!"></td>
    <td class="aright"><input type="reset" value="초기화!"</td></tr>
</table>
</form>
<?php
HTMLendcompact();
?>
