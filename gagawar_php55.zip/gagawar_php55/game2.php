<frameset rows="1,*">
  <frame name="menu" scrolling="no" SRC="indextop.html" noresize>
  <frame name="display" SRC="promisance.php?action=main">
  <noframes>
  <body>
  <p>Use a Frames Capable Browser.</p>
  </body>
  </noframes>
</frameset>
