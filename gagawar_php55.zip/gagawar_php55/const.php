<?php // All the constants in the game
$dbhost = 'localhost';			// MySQL server hostname
$dbuser = 'esils0';			// MySQL username
$dbpass = 'answn100';			// MySQL password
$dbname = 'esils0';			// MySQL database name
$version = '1.2.1';		// Game version number

// Default language: Korean labels for races, units and buildings
if (!isset($GLOBALS['lang']) || $GLOBALS['lang'] == '') {
  $GLOBALS['lang'] = 'korean';
}

//!!!S
$playerdb = 'players';		// Player table name
//!!!T START
if(!preg_match('/korean/', $GLOBALS[lang])) {
  $racedb = 'en_races';		// Races table name
  $eradb = 'en_eras';		// Eras table name
  }
else  {
  $racedb = 'kr_races';		// Races table name
  $eradb = 'kr_eras';		// Eras table name
  }
//!!!T END
$lotterydb = 'lottery';		// Lottery table name
$marketdb = 'market';		// Public Market table name
$messagedb = 'messages';	// Messages table name
$newsdb = 'news';		// News table name
$clandb = 'clan'; 	// Clans table name
//!!!E

$config[protection] = 200;	// Duration of protection
$config[initturns] = 120;	// Turns given on signup
$config[maxturns] = 300;	// Max accumulated turns
$config[maxstoredturns] = 100;	// Max stored turns
$config[valturns] = 1000000000;	// How long before validation is necessary
$config[shamemult] = 5; // The 3% Multiplier. (Default: 5)
$config[nonattack] = 2; // The "Can't attack" (Default: 50)
$config[edneed] = 500000; // Acres Need for casting Emminent Domain (Default: 10000)
$config[edcap] = 50; // Emminent Domain Cap (Default: 5000)
$config[buymarket] = 1; // Let users in protection buy in the public market? (Default: 0) (0 = no) (1 = yes)
$config[maxattacks] = 10; // Too many attacks

$config[clans] = 0; // Let clans? (0=no)(1=yes)

$config[minvacation] = 48;	// Minimum vacation duration
$config[vacationdelay] = 6;	// Delay before empire is protected

// Styles Configuration

$config[maxstyles] = 5; // Max Styles
$styles[0] = "EZClan"; // 1st Style
$styles[1] = "QM Promisance"; // 2nd Style
$styles[2] = "United Realms"; // 3rd Style
$styles[3] = "SubSilver"; // 4th Style
$styles[4] = "Modern Readable"; // 5th Style


// Message Configuration

$config[maxmsg] = 10; // Max Messages you can send. (Default: 10)

// Aid Configuration

$config[canaid] = 0; // Can Send Aid? (0 = No, 1 = Yes)
$config[aidtax] = .10; // Aid Tax (Default: .10) (.10 = 10%)
$config[nonaid] = .75; // The Aid multiplier (Default: .75) meaning you can aid someone 1/75 your size.
$config[aid_ac] = 1; // This is an anti cheating measure, if you want to turn it off put 0 (Default: 1)
$config[maxaid] = 1; // This is the max aiding you can do. (Default: 1)
$config[aidhours] = 24; // The hours to reset the aiding :P (Default: 24)
$config[maxaidget] = 1; // This is how many aid can you get (Default: 1)

// DB Configuration

$signupsclosed = 0;		// Signups closed?
$lockdb = 0;			// Lock the players database?
$lastweek = 0;			// Last week of the game? don't allow loans

//!!!default was 2 -> 10
$turnsper = 4;			// X turns
$perminutes = 10;		// per Y minutes
$turnoffset = 0;		// in case we don't run exactly 0 minutes after the hour
				// Note: perminutes must divide evenly into 60
				// 2nd Note: turnoffset can never be negative.

$maxtickets = 3;		// Maximum # of lottery tickets per empire

$tick_curjp = 0;		// DO NOT MODIFY THESE
$tick_lastjp = 1;		// DO NOT MODIFY THESE
$tick_lastnum = 2;		// DO NOT MODIFY THESE
$tick_lastwin = 3;		// DO NOT MODIFY THESE
$tick_jpgrow = 4;		// DO NOT MODIFY THESE

$trplst[0] = 'armtrp';		// an array of troop names so for loops can be used when all types are referenced
$trplst[1] = 'lndtrp';		// DO NOT MODIFY THESE
$trplst[2] = 'flytrp';		// DO NOT MODIFY THESE
$trplst[3] = 'seatrp';		// DO NOT MODIFY THESE
$trplst[4] = 'food';		// this commonly follows the troop listings
$trplst[5] = 'runes'; // Alpha Testing too...
$trplst[6] = 'iron';

$config[armtrp] = 110;		// Base market costs
$config[lndtrp] = 220;
$config[flytrp] = 440;
$config[seatrp] = 660;
$config[food] = 55;
$config[runes] = 14;
$config[iron] = 19;

$config[loanbase] = 6;		// Base savings/loan rates
$config[savebase] = 4;
$config[buildings] = 3000;	// Base building cost
$config[market] = 1;		// Hours to arrive on market
$config[bmperc] = 10000;		// Percentage of troops that can be sold on black market (divide by 100 for percentage)
$config[mktshops] = 0.20;	// percentage of cost black market bonus for which shops are responsible

				// News text
$config[news] = '<span style="color:white"></span>';
				// Name of primary script file. DO NOT MODIFY
$config[main] = 'promisance.php';
				// Site/path in which the game resides
$config[sitedir] = '';
				// server title
//!!!T START
if(!preg_match('/korean/', $GLOBALS[lang])) {
  $config[servname] = 'Gagawar server 1';
  }
else  {
  $config[servname] = '가가전쟁 서버 1';
  }
//!!!T END
				// where we go when we logout
$config[home] = '';
				// link to forum for this game
$config[forums] = '../html/kr_board.html';
				// administrative contact
$config[adminemail] = '';
				// From address of validation emails
$config[valemail] = 'gagaspace@hanmail.net';

// Update E-Mails 
// (It checks the version if it has been updated every 12 hours and mails you if you haven't update)
$config[updater] = 1; // Default: 1
$prom_version = 10102012; // Do NOT Change This * DO NOT * Prom may go crazy if this is changed.


$time = time();			// not really constants, but stuff used for all pages
if (!function_exists('gaga_korean_datetime')) {
    function gaga_korean_datetime($ts = 0) {
        if (!$ts) $ts = time();
        $week = array('일','월','화','수','목','금','토');
        return date('Y년 m월 d일', $ts) . ' (' . $week[intval(date('w', $ts))] . ') ' . date('H:i:s', $ts) . ' KST-9';
    }
}
$datetime = gaga_korean_datetime(time());
$cookie = $HTTP_COOKIE_VARS;

//!!!ADDED
$digibbs = 0; //whether to use as digibbs
$digibbskey = "";
$onlyenglish = 1; //whether to allow only english characters
?>
