<?php
/*
 * Simple administrator page for Gagawar / Promisance PHP 5.5.
 * Login uses players table account admin/admin by default.
 * This file does not auto-load from promisance.php, so normal game access is not affected.
 */
error_reporting(E_ALL ^ E_NOTICE);
@session_start();

if (!isset($HTTP_GET_VARS)) $HTTP_GET_VARS = $_GET;
if (!isset($HTTP_POST_VARS)) $HTTP_POST_VARS = $_POST;
if (!isset($HTTP_COOKIE_VARS)) $HTTP_COOKIE_VARS = $_COOKIE;

@include_once(dirname(__FILE__) . '/const.php');

function ga_h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function ga_chat_format_time($ts) {
    if (!$ts) $ts = time();
    $week = array('일','월','화','수','목','금','토');
    return date('Y년 m월 d일', $ts) . ' (' . $week[intval(date('w', $ts))] . ') ' . date('H:i:s', $ts) . ' KST-9';
}
function ga_read_json_file($file) {
    if (!file_exists($file)) return array();
    $data = @json_decode(@file_get_contents($file), true);
    return is_array($data) ? $data : array();
}
function ga_write_json_file($file, $data) {
    $fp = @fopen($file, 'c+');
    if (!$fp) return false;
    @flock($fp, LOCK_EX);
    @ftruncate($fp, 0);
    @rewind($fp);
    @fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE));
    @fflush($fp);
    @flock($fp, LOCK_UN);
    @fclose($fp);
    return true;
}
function ga_post($k, $d) { return isset($_POST[$k]) ? $_POST[$k] : $d; }
function ga_get($k, $d) { return isset($_GET[$k]) ? $_GET[$k] : $d; }
function ga_db() {
    global $dbhost, $dbuser, $dbpass, $dbname;
    $link = @mysql_connect($dbhost, $dbuser, $dbpass);
    if (!$link) return false;
    if (!@mysql_select_db($dbname, $link)) return false;
    @mysql_query("SET NAMES utf8", $link);
    return $link;
}
function ga_need_db($link) {
    if (!$link) {
        ga_page('DB 오류', '<p>DB 연결 실패. const.php의 DB 정보를 확인하세요.</p>');
        exit;
    }
}
function ga_is_login() { return isset($_SESSION['ga_admin_login']) && $_SESSION['ga_admin_login'] == 1; }
function ga_page($title, $body) {
    echo '<!doctype html><html><head><meta charset="utf-8"><title>'.ga_h($title).'</title>';
    echo '<style>body{font-family:Arial,Helvetica,sans-serif;background:#18202b;color:#e9eef5;margin:0}a{color:#9fd0ff} .wrap{max-width:1180px;margin:0 auto;padding:18px}.box{background:#222c3a;border:1px solid #3a4658;border-radius:8px;padding:16px;margin:12px 0}input,select,textarea{background:#101722;color:#fff;border:1px solid #526070;border-radius:4px;padding:6px}textarea{width:100%;min-height:100px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #3a4658;padding:6px;text-align:left}th{background:#2d394a}.nav a{display:inline-block;margin:3px 5px 3px 0;padding:7px 10px;background:#314052;border-radius:4px;text-decoration:none}.ok{color:#9cff9c}.bad{color:#ffb0b0}.btn{background:#4c6f9f;color:#fff;border:0;padding:7px 12px;border-radius:4px;cursor:pointer}.danger{background:#8b3030}.small{font-size:12px;color:#b8c3d2}.pager a{display:inline-block;margin:2px;padding:4px 7px;background:#314052;border-radius:3px;text-decoration:none}.pager b{display:inline-block;margin:2px;padding:4px 7px;background:#4c6f9f;border-radius:3px}.chat-message{max-width:520px;word-break:break-all}</style>';
    echo '</head><body><div class="wrap"><h1>'.ga_h($title).'</h1>';
    if (ga_is_login()) {
        echo '<div class="nav"><a href="admin.php">서버상태</a><a href="admin.php?m=turn">턴관리</a><a href="admin.php?m=users">유저검색</a><a href="admin.php?m=notice">공지작성</a><a href="admin.php?m=ranking">랭킹재생성</a><a href="admin.php?m=chat">채팅관리</a><a href="admin.php?m=settings">게임설정</a><a href="admin.php?m=passwd">관리자비번</a><a href="admin.php?m=logout">로그아웃</a></div>';
    }
    echo $body.'</div></body></html>';
}
function ga_run_turns() {
    global $action;
    $old_action = isset($action) ? $action : '';
    $action = 'turns';
    ob_start();
    @include(dirname(__FILE__) . '/turns.php');
    ob_end_clean();
    $action = $old_action;
}
function ga_make_ranking() {
    $_GET['action'] = 'top10';
    $action = 'top10';
    ob_start();
    @include(dirname(__FILE__) . '/top10.php');
    $html = ob_get_contents();
    ob_end_clean();
    if (!is_dir(dirname(__FILE__) . '/sql')) @mkdir(dirname(__FILE__) . '/sql', 0755);
    $file = dirname(__FILE__) . '/sql/kr_gagawar1.html';
    @file_put_contents($file, $html . "\n", FILE_APPEND | LOCK_EX);
    return $file;
}

function ga_setting_label($k) {
    $labels = array(
        'turnsper'=>'턴 지급 수',
        'perminutes'=>'턴 회복 시간(분)',
        'signupsclosed'=>'회원가입 차단',
        'lockdb'=>'유저 DB 잠금',
        'protection'=>'신규 보호 턴',
        'initturns'=>'가입 시 기본 턴',
        'maxturns'=>'최대 보유 턴',
        'maxstoredturns'=>'최대 저장 턴',
        'valturns'=>'인증 필요 전 유예 턴',
        'shamemult'=>'약자 공격 제한 배율',
        'nonattack'=>'공격 불가 기준값',
        'edneed'=>'토지마법 필요 에이커',
        'edcap'=>'토지마법 최대 획득',
        'buymarket'=>'보호 중 공개시장 구매 허용',
        'maxattacks'=>'최대 연속 공격 수',
        'clans'=>'클랜 사용 여부',
        'minvacation'=>'최소 휴가 시간',
        'vacationdelay'=>'휴가 보호 대기 시간',
        'maxmsg'=>'최대 메시지 수',
        'canaid'=>'원조 사용 여부',
        'aidtax'=>'원조 세금',
        'nonaid'=>'원조 가능 규모 배율',
        'aid_ac'=>'원조 부정방지 사용',
        'maxaid'=>'최대 원조 횟수',
        'aidhours'=>'원조 횟수 초기화 시간',
        'maxaidget'=>'최대 원조 수령 횟수',
        'armtrp'=>'병사 기본 시장가',
        'lndtrp'=>'보병 기본 시장가',
        'flytrp'=>'공중유닛 기본 시장가',
        'seatrp'=>'해상유닛 기본 시장가',
        'food'=>'식량 기본 시장가',
        'runes'=>'마나 기본 시장가',
        'iron'=>'철 기본 시장가',
        'loanbase'=>'대출 기본 이율',
        'savebase'=>'저축 기본 이율',
        'buildings'=>'건물 기본 비용',
        'market'=>'시장 도착 시간',
        'bmperc'=>'암시장 판매 가능 비율',
        'mktshops'=>'상점 암시장 보너스 비율',
        'servname'=>'서버 이름',
        'forums'=>'게시판 경로',
        'adminemail'=>'관리자 이메일',
        'valemail'=>'인증 메일 발신 주소',
        'news'=>'게임 공지 HTML',
        'style_0'=>'스타일 1 이름',
        'style_1'=>'스타일 2 이름',
        'style_2'=>'스타일 3 이름',
        'style_3'=>'스타일 4 이름',
        'style_4'=>'스타일 5 이름'
    );
    return isset($labels[$k]) ? $labels[$k] : $k;
}
function ga_setting_help($k) {
    $helps = array(
        'turnsper'=>'한 번 회복될 때 지급되는 턴 수입니다.',
        'perminutes'=>'몇 분마다 턴을 회복할지 설정합니다. 예: 10 = 10분마다.',
        'signupsclosed'=>'0=가입 허용, 1=가입 차단.',
        'lockdb'=>'0=정상, 1=유저 DB 잠금.',
        'protection'=>'신규 유저가 보호받는 기간입니다.',
        'initturns'=>'새 계정 생성 시 지급되는 시작 턴입니다.',
        'maxturns'=>'누적 가능한 최대 일반 턴입니다.',
        'maxstoredturns'=>'저장 가능한 최대 저장 턴입니다.',
        'buymarket'=>'0=불가, 1=허용.',
        'clans'=>'0=클랜 미사용, 1=클랜 사용.',
        'canaid'=>'0=원조 불가, 1=원조 허용.',
        'aidtax'=>'0.10 = 10% 세금.',
        'market'=>'시장 물품 도착까지 걸리는 시간입니다.',
        'news'=>'HTML 입력 가능. 잘못된 태그를 넣으면 화면이 깨질 수 있습니다.'
    );
    return isset($helps[$k]) ? $helps[$k] : '';
}

function ga_update_const_values($pairs) {
    $file = dirname(__FILE__) . '/const.php';
    $src = @file_get_contents($file);
    if ($src === false) return false;
    foreach ($pairs as $name => $val) {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) continue;
        if (is_numeric($val)) $rep = '$config['.$name.'] = '.$val.';';
        else $rep = '$config['.$name.'] = '.var_export($val, true).';';
        $src = preg_replace('/\$config\['.preg_quote($name,'/').'\]\s*=\s*[^;]*;/', $rep, $src, 1);
    }
    for ($i=0; $i<5; $i++) {
        $k = 'style_'.$i;
        if (isset($pairs[$k])) {
            $src = preg_replace('/\$styles\['.$i.'\]\s*=\s*[^;]*;/', '$styles['.$i.'] = '.var_export($pairs[$k], true).';', $src, 1);
        }
    }
    if (isset($pairs['turnsper'])) $src = preg_replace('/\$turnsper\s*=\s*[^;]*;/', '$turnsper = '.intval($pairs['turnsper']).';', $src, 1);
    if (isset($pairs['perminutes'])) $src = preg_replace('/\$perminutes\s*=\s*[^;]*;/', '$perminutes = '.intval($pairs['perminutes']).';', $src, 1);
    if (isset($pairs['signupsclosed'])) $src = preg_replace('/\$signupsclosed\s*=\s*[^;]*;/', '$signupsclosed = '.intval($pairs['signupsclosed']).';', $src, 1);
    if (isset($pairs['lockdb'])) $src = preg_replace('/\$lockdb\s*=\s*[^;]*;/', '$lockdb = '.intval($pairs['lockdb']).';', $src, 1);
    return @file_put_contents($file, $src, LOCK_EX) !== false;
}

$link = ga_db();
$m = ga_get('m', 'home');

if ($m == 'logout') { $_SESSION = array(); @session_destroy(); header('Location: admin.php'); exit; }

if (!ga_is_login()) {
    $msg = '';
    if (isset($_POST['login'])) {
        ga_need_db($link);
        $u = mysql_real_escape_string(ga_post('username',''), $link);
        $p = md5(ga_post('password',''));
        $q = @mysql_query("SELECT num,username FROM players WHERE username='admin' AND password='".mysql_real_escape_string($p,$link)."' LIMIT 1", $link);
        if ($q && mysql_num_rows($q) > 0) { $_SESSION['ga_admin_login'] = 1; header('Location: admin.php'); exit; }
        $msg = '<p class="bad">로그인 실패</p>';
    }
    ga_page('Gagawar 관리자 로그인', '<div class="box">'.$msg.'<form method="post"><p>ID <input name="username" value="admin"></p><p>PW <input type="password" name="password" value=""></p><p><input class="btn" type="submit" name="login" value="로그인"></p><p class="small">초기값은 admin / admin 입니다. 로그인 후 즉시 비밀번호를 변경하세요.</p></form></div>');
    exit;
}

ga_need_db($link);

if ($m == 'passwd') {
    $msg='';
    if (isset($_POST['save'])) {
        $p1 = ga_post('p1',''); $p2 = ga_post('p2','');
        if ($p1 == '' || $p1 != $p2) $msg = '<p class="bad">비밀번호가 비었거나 확인값이 다릅니다.</p>';
        else { @mysql_query("UPDATE players SET password='".mysql_real_escape_string(md5($p1),$link)."' WHERE username='admin' LIMIT 1", $link); $msg='<p class="ok">변경 완료</p>'; }
    }
    ga_page('관리자 비밀번호 변경', '<div class="box">'.$msg.'<form method="post"><p>새 비밀번호 <input type="password" name="p1"></p><p>확인 <input type="password" name="p2"></p><p><input class="btn" type="submit" name="save" value="저장"></p></form></div>'); exit;
}

if ($m == 'turn') {
    $msg='';
    if (isset($_POST['run'])) { ga_run_turns(); $msg='<p class="ok">turns.php 강제 실행 완료</p>'; }
    if (isset($_POST['reset_last'])) { @unlink(dirname(__FILE__).'/turn_last.dat'); $msg='<p class="ok">자동 턴 기준 시간 초기화 완료</p>'; }
    $last = file_exists(dirname(__FILE__).'/turn_last.dat') ? date('Y-m-d H:i:s', intval(trim(@file_get_contents(dirname(__FILE__).'/turn_last.dat')))) : '없음';
    ga_page('턴 관리', '<div class="box">'.$msg.'<p>턴 지급: '.ga_h($turnsper).'턴 / '.ga_h($perminutes).'분</p><p>마지막 자동 턴 기준: '.ga_h($last).'</p><form method="post"><input class="btn" type="submit" name="run" value="턴 강제 실행"> <input class="btn" type="submit" name="reset_last" value="자동 턴 기준 초기화"></form></div>'); exit;
}

if ($m == 'users') {
    $msg='';
    if (isset($_POST['delete_user'])) { $num=intval($_POST['num']); if ($num != 2) { @mysql_query("DELETE FROM players WHERE num=$num LIMIT 1", $link); $msg='<p class="ok">삭제 완료</p>'; } else $msg='<p class="bad">admin 계정은 삭제하지 않았습니다.</p>'; }
    if (isset($_POST['save_user'])) {
        $num=intval($_POST['num']);
        $fields=array('username','empire','email','turns','turnsstored','cash','food','land','freeland','networth','disabled','validated','style');
        $sets=array();
        for ($i=0;$i<count($fields);$i++) { $f=$fields[$i]; $sets[] = "$f='".mysql_real_escape_string(ga_post($f,''),$link)."'"; }
        @mysql_query("UPDATE players SET ".join(',',$sets)." WHERE num=$num LIMIT 1", $link); $msg='<p class="ok">저장 완료</p>';
    }
    $kw = ga_get('q','');
    $html='<div class="box">'.$msg.'<form method="get"><input type="hidden" name="m" value="users">검색 <input name="q" value="'.ga_h($kw).'"> <input class="btn" type="submit" value="검색"></form></div>';
    if ($kw !== '') {
        $s=mysql_real_escape_string($kw,$link);
        $q=@mysql_query("SELECT * FROM players WHERE username LIKE '%$s%' OR empire LIKE '%$s%' OR email LIKE '%$s%' OR num='".intval($kw)."' ORDER BY num LIMIT 50", $link);
    } else $q=@mysql_query("SELECT * FROM players ORDER BY num LIMIT 50", $link);
    $html.='<div class="box"><table><tr><th>num</th><th>username</th><th>empire</th><th>email</th><th>turns</th><th>cash</th><th>land</th><th>정지</th><th>작업</th></tr>';
    while ($r=$q ? mysql_fetch_assoc($q) : false) {
        $html.='<tr><form method="post"><td>'.ga_h($r['num']).'<input type="hidden" name="num" value="'.ga_h($r['num']).'"></td>';
        foreach(array('username','empire','email','turns','cash','land') as $f) $html.='<td><input name="'.$f.'" value="'.ga_h($r[$f]).'" size="10"></td>';
        $html.='<td><select name="disabled"><option value="0"'.($r['disabled']?'':' selected').'>정상</option><option value="1"'.($r['disabled']?' selected':'').'>정지</option></select><input type="hidden" name="turnsstored" value="'.ga_h($r['turnsstored']).'"><input type="hidden" name="food" value="'.ga_h($r['food']).'"><input type="hidden" name="freeland" value="'.ga_h($r['freeland']).'"><input type="hidden" name="networth" value="'.ga_h($r['networth']).'"><input type="hidden" name="validated" value="'.ga_h($r['validated']).'"><input type="hidden" name="style" value="'.ga_h($r['style']).'"></td><td><input class="btn" type="submit" name="save_user" value="저장"> <input class="btn danger" type="submit" name="delete_user" value="삭제" onclick="return confirm(\'삭제?\')"></td></form></tr>';
    }
    $html.='</table><p class="small">세부 변경이 필요한 값은 검색 후 기본 필드부터 수정하고, 추가 필드는 추후 확장 가능합니다.</p></div>';
    ga_page('유저 관리', $html); exit;
}

if ($m == 'notice') {
    $msg='';
    if (isset($_POST['save'])) { if (ga_update_const_values(array('news'=>ga_post('news','')))) $msg='<p class="ok">공지 저장 완료</p>'; else $msg='<p class="bad">const.php 저장 실패. 파일 권한을 확인하세요.</p>'; }
    ga_page('공지 작성', '<div class="box">'.$msg.'<form method="post"><textarea name="news">'.ga_h(isset($config['news'])?$config['news']:'').'</textarea><p><input class="btn" type="submit" name="save" value="저장"></p></form></div>'); exit;
}

if ($m == 'ranking') {
    $msg='';
    if (isset($_POST['make'])) { $file=ga_make_ranking(); $msg='<p class="ok">랭킹 저장 완료: '.ga_h($file).'</p>'; }
    ga_page('랭킹 재생성', '<div class="box">'.$msg.'<form method="post"><input class="btn" type="submit" name="make" value="top10 랭킹 저장"></form></div>'); exit;
}


if ($m == 'chat') {
    $chat_dir = dirname(__FILE__) . '/chatlog';
    if (!is_dir($chat_dir)) @mkdir($chat_dir, 0777);
    $chat_file = $chat_dir . '/chatlog.json';
    $legacy_chat_file = dirname(__FILE__) . '/chatlog.json';
    if (!file_exists($chat_file) && file_exists($legacy_chat_file)) @rename($legacy_chat_file, $chat_file);
    $msg = '';
    $chat = ga_read_json_file($chat_file);

    if (isset($_POST['clear_chat'])) {
        if (count($chat) > 0) {
            $backup = $chat_dir . '/chat_backup_' . date('Ymd_His') . '_manual.json';
            ga_write_json_file($backup, $chat);
        }
        ga_write_json_file($chat_file, array());
        $chat = array();
        $msg = '<p class="ok">채팅 전체 삭제 완료. 삭제 전 내용은 chatlog 폴더에 백업했습니다.</p>';
    }
    if (isset($_POST['delete_one'])) {
        $idx = intval($_POST['idx']);
        if (isset($chat[$idx])) {
            unset($chat[$idx]);
            $chat = array_values($chat);
            ga_write_json_file($chat_file, $chat);
            $msg = '<p class="ok">선택 메시지 삭제 완료</p>';
        }
    }
    if (isset($_POST['delete_backup'])) {
        $bf = basename($_POST['backup_file']);
        if (preg_match('/^chat_backup_[A-Za-z0-9_]+\.json$/', $bf)) {
            @unlink($chat_dir . '/' . $bf);
            $msg = '<p class="ok">백업 파일 삭제 완료</p>';
        }
    }

    $view = ga_get('view', 'active');
    $html = '<div class="box">'.$msg;
    $html .= '<p><a class="btn" href="chat.php" target="_blank">채팅방 열기</a> ';
    $html .= '<a class="btn" href="admin.php?m=chat">현재 채팅 보기</a> ';
    $html .= '<a class="btn" href="admin.php?m=chat&view=backup">백업 채팅내용 확인</a></p>';
    $html .= '<form method="post"><input class="btn danger" type="submit" name="clear_chat" value="채팅 전체 삭제" onclick="return confirm(\'현재 채팅을 백업 후 삭제합니까?\')"></form>';
    $html .= '<p class="small">현재 채팅은 3일마다 자동으로 chatlog 폴더에 백업된 뒤 초기화됩니다. 관리 화면은 최근 50개씩 나누어 표시합니다.</p></div>';

    if ($view == 'backup') {
        $files = glob($chat_dir . '/chat_backup_*.json');
        if (!is_array($files)) $files = array();
        rsort($files);
        $sel = basename(ga_get('file', ''));
        $html .= '<div class="box"><h3>백업 목록</h3><table><tr><th>파일</th><th>크기</th><th>작업</th></tr>';
        for ($i=0; $i<count($files); $i++) {
            $bf = basename($files[$i]);
            $html .= '<tr><td><a href="admin.php?m=chat&view=backup&file='.ga_h($bf).'">'.ga_h($bf).'</a></td><td>'.ga_h(filesize($files[$i])).' bytes</td><td><form method="post" onsubmit="return confirm(\'이 백업을 삭제합니까?\')"><input type="hidden" name="backup_file" value="'.ga_h($bf).'"><input class="btn danger" type="submit" name="delete_backup" value="백업 삭제"></form></td></tr>';
        }
        if (count($files) == 0) $html .= '<tr><td colspan="3">백업 파일이 없습니다.</td></tr>';
        $html .= '</table></div>';
        if ($sel != '' && preg_match('/^chat_backup_[A-Za-z0-9_]+\.json$/', $sel) && file_exists($chat_dir . '/' . $sel)) {
            $backup_chat = ga_read_json_file($chat_dir . '/' . $sel);
            $page = intval(ga_get('p', 1)); if ($page < 1) $page = 1;
            $per = 50; $total = count($backup_chat); $pages = ceil($total / $per); if ($pages < 1) $pages = 1;
            if ($page > $pages) $page = $pages;
            $offset = ($page - 1) * $per;
            $html .= '<div class="box"><h3>백업 내용: '.ga_h($sel).'</h3><table><tr><th>시간</th><th>이름</th><th>내용</th><th>IP</th></tr>';
            for ($i=$total-1-$offset; $i>=0 && $i>$total-1-$offset-$per; $i--) {
                if (!isset($backup_chat[$i])) continue;
                $r = $backup_chat[$i];
                $ts = isset($r['ts']) ? intval($r['ts']) : 0;
                $time = $ts > 0 ? ga_chat_format_time($ts) : (isset($r['time']) ? $r['time'] : '');
                $html .= '<tr><td>'.ga_h($time).'</td><td>'.ga_h(isset($r['name'])?$r['name']:'').'</td><td class="chat-message">'.ga_h(isset($r['message'])?$r['message']:'').'</td><td>'.ga_h(isset($r['ip'])?$r['ip']:'').'</td></tr>';
            }
            if ($total == 0) $html .= '<tr><td colspan="4">기록이 없습니다.</td></tr>';
            $html .= '</table><p class="pager">';
            for ($i=1; $i<=$pages; $i++) {
                if ($i == $page) $html .= '<b>'.$i.'</b>'; else $html .= '<a href="admin.php?m=chat&view=backup&file='.ga_h($sel).'&p='.$i.'">'.$i.'</a>';
            }
            $html .= '</p></div>';
        }
        ga_page('채팅 관리', $html); exit;
    }

    $page = intval(ga_get('p', 1)); if ($page < 1) $page = 1;
    $per = 50; $total = count($chat); $pages = ceil($total / $per); if ($pages < 1) $pages = 1;
    if ($page > $pages) $page = $pages;
    $offset = ($page - 1) * $per;
    $html .= '<div class="box"><h3>현재 채팅</h3><table><tr><th>시간</th><th>이름</th><th>내용</th><th>IP</th><th>작업</th></tr>';
    for ($i=$total-1-$offset; $i>=0 && $i>$total-1-$offset-$per; $i--) {
        if (!isset($chat[$i])) continue;
        $r = $chat[$i];
        $ts = isset($r['ts']) ? intval($r['ts']) : 0;
        $time = $ts > 0 ? ga_chat_format_time($ts) : (isset($r['time'])?$r['time']:'');
        $html .= '<tr><td>'.ga_h($time).'</td><td>'.ga_h(isset($r['name'])?$r['name']:'').'</td><td class="chat-message">'.ga_h(isset($r['message'])?$r['message']:'').'</td><td>'.ga_h(isset($r['ip'])?$r['ip']:'').'</td><td><form method="post"><input type="hidden" name="idx" value="'.ga_h($i).'"><input class="btn danger" type="submit" name="delete_one" value="삭제"></form></td></tr>';
    }
    if ($total == 0) $html .= '<tr><td colspan="5">채팅 기록이 없습니다.</td></tr>';
    $html .= '</table><p class="pager">';
    for ($i=1; $i<=$pages; $i++) {
        if ($i == $page) $html .= '<b>'.$i.'</b>'; else $html .= '<a href="admin.php?m=chat&p='.$i.'">'.$i.'</a>';
    }
    $html .= '</p><p class="small">일반 사용자는 채팅 작성만 가능하며, 삭제/초기화는 관리자 페이지에서만 가능합니다.</p></div>';
    ga_page('채팅 관리', $html); exit;
}

if ($m == 'settings') {
    $keys=array('protection','initturns','maxturns','maxstoredturns','valturns','shamemult','nonattack','edneed','edcap','buymarket','maxattacks','clans','minvacation','vacationdelay','maxmsg','canaid','aidtax','nonaid','aid_ac','maxaid','aidhours','maxaidget','armtrp','lndtrp','flytrp','seatrp','food','runes','iron','loanbase','savebase','buildings','market','bmperc','mktshops','servname','forums','adminemail','valemail','news');
    $msg='';
    if (isset($_POST['save'])) {
        $pairs=array();
        for($i=0;$i<count($keys);$i++) if(isset($_POST[$keys[$i]])) $pairs[$keys[$i]]=$_POST[$keys[$i]];
        for($i=0;$i<5;$i++) $pairs['style_'.$i]=ga_post('style_'.$i, isset($styles[$i])?$styles[$i]:'');
        $pairs['turnsper']=ga_post('turnsper',$turnsper); $pairs['perminutes']=ga_post('perminutes',$perminutes); $pairs['signupsclosed']=ga_post('signupsclosed',$signupsclosed); $pairs['lockdb']=ga_post('lockdb',$lockdb);
        if (ga_update_const_values($pairs)) $msg='<p class="ok">설정 저장 완료</p>'; else $msg='<p class="bad">저장 실패. const.php 권한을 확인하세요.</p>';
    }
    $html='<div class="box">'.$msg.'<form method="post"><table><tr><th>설정 항목</th><th>값</th><th>설명</th></tr>';
    $html.='<tr><td>'.ga_h(ga_setting_label('turnsper')).'<br><span class="small">turnsper</span></td><td><input name="turnsper" value="'.ga_h($turnsper).'"></td><td class="small">'.ga_h(ga_setting_help('turnsper')).'</td></tr><tr><td>'.ga_h(ga_setting_label('perminutes')).'<br><span class="small">perminutes</span></td><td><input name="perminutes" value="'.ga_h($perminutes).'"></td><td class="small">'.ga_h(ga_setting_help('perminutes')).'</td></tr><tr><td>'.ga_h(ga_setting_label('signupsclosed')).'<br><span class="small">signupsclosed</span></td><td><input name="signupsclosed" value="'.ga_h($signupsclosed).'"></td><td class="small">'.ga_h(ga_setting_help('signupsclosed')).'</td></tr><tr><td>'.ga_h(ga_setting_label('lockdb')).'<br><span class="small">lockdb</span></td><td><input name="lockdb" value="'.ga_h($lockdb).'"></td><td class="small">'.ga_h(ga_setting_help('lockdb')).'</td></tr>';
    for($i=0;$i<count($keys);$i++) { $k=$keys[$i]; $html.='<tr><td>'.ga_h(ga_setting_label($k)).'<br><span class="small">'.ga_h($k).'</span></td><td><input name="'.ga_h($k).'" value="'.ga_h(isset($config[$k])?$config[$k]:'').'" size="70"></td><td class="small">'.ga_h(ga_setting_help($k)).'</td></tr>'; }
    for($i=0;$i<5;$i++) { $sk='style_'.$i; $html.='<tr><td>'.ga_h(ga_setting_label($sk)).'<br><span class="small">styles['.$i.']</span></td><td><input name="style_'.$i.'" value="'.ga_h(isset($styles[$i])?$styles[$i]:'').'" size="70"></td><td class="small">게임 내 스타일 선택에 표시되는 이름입니다.</td></tr>'; }
    $html.='</table><p><input class="btn" type="submit" name="save" value="설정 저장"></p><p class="small">저장 전 const.php 백업을 권장합니다. 파일 권한이 쓰기 가능해야 합니다.</p></form></div>';
    ga_page('게임 설정', $html); exit;
}

$q1=@mysql_query("SELECT COUNT(*) c FROM players", $link); $r1=$q1?mysql_fetch_assoc($q1):array('c'=>'?');
$q2=@mysql_query("SELECT COUNT(*) c FROM players WHERE disabled=1", $link); $r2=$q2?mysql_fetch_assoc($q2):array('c'=>'?');
$last = file_exists(dirname(__FILE__).'/turn_last.dat') ? date('Y-m-d H:i:s', intval(trim(@file_get_contents(dirname(__FILE__).'/turn_last.dat')))) : '없음';
$body='<div class="box"><table><tr><th>항목</th><th>값</th></tr><tr><td>전체 유저</td><td>'.ga_h($r1['c']).'</td></tr><tr><td>정지 유저</td><td>'.ga_h($r2['c']).'</td></tr><tr><td>턴 설정</td><td>'.ga_h($turnsper).'턴 / '.ga_h($perminutes).'분</td></tr><tr><td>마지막 자동 턴 기준</td><td>'.ga_h($last).'</td></tr><tr><td>서버명</td><td>'.ga_h(isset($config['servname'])?$config['servname']:'').'</td></tr></table></div>';
ga_page('서버 상태', $body);
?>
