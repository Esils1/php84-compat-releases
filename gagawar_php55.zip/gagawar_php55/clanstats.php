<?php
include("funcs.php");
$ctags = loadClanTags();
HTMLbegincompact("Top Clans");

$minmembers = 3;

$allusers = mysql_query("SELECT clan,networth FROM $playerdb WHERE land>0;");
$unallied = $utotal = 0;
while ($users = mysql_fetch_array($allusers))
{
	if ($n = $users[clan])
	{
		$members[$n]++;
		$totalnet[$n] += $users[networth];
		$avgnet[$n] = round($totalnet[$n] / $members[$n]);
	}
	else	$unallied++;
	$utotal++;
}
if ($unallied == $utotal)
{
?>
<h3>현재 존재하는 동맹이 없습니다!</h3>
<?php
	HTMLendcompact();
	exit;
}
?>
<table class="inputtable">
<tr><th colspan="5">동맹 순위 - 정렬: <?php
switch ($sort_type)
{
case 'members':
	print "총 구성원 수";
	$sortby = $members;
	break;
case 'avgnet':
	print "평균 총 재산";
	$sortby = $avgnet;
	break;
case 'totalnet':
	print "총 재산";
	$sortby = $totalnet;
	break;
}
arsort($sortby);
reset($sortby);
while (list($key,$val) = each($sortby))
	$clan[] = $key;
reset($sortby);
reset($clan);
?> (<?php echo $minmembers?> 최소 인원)</th></tr>
<tr><th>동맹명</th>
    <th>태그</th>
    <th><a href="<?php echo $config[main]?>?action=clanstats&sort_type=members">구성원</a></th>
    <th><a href="<?php echo $config[main]?>?action=clanstats&sort_type=avgnet">평균 총 재산</a></th>
    <th><a href="<?php echo $config[main]?>?action=clanstats&sort_type=totalnet">총 재산</a></th></tr>
<?php
$cunlisted = $ctotal = 0;
while (list($i,$num) = each($clan))
{
	$uclan = loadClan($num);
	if ($uclan[members] >= $minmembers)
	{
?>
<tr class="acenter">
    <td><?php
	if ($uclan[url])
		print "<a href=\"$uclan[url]\" target=\"_blank\">";
	print "$uclan[name]";
	if ($uclan[url])
		print "</a>";	?></td>
    <td><a href="<?php echo $config[main]?>?action=search&amp;search_type=clan&amp;search_clan=<?php echo $uclan[num]?>&amp;do_search=1"><?php echo $uclan[tag]?></a></td>
    <td><?php echo $uclan[members]?></td>
    <td>$<?php echo commas($avgnet[$uclan[num]])?></td>
    <td>$<?php echo commas($totalnet[$uclan[num]])?></td></tr>
<?php
	}
	else	$cunlisted++;
	$ctotal++;
}
?>
</table>
<?php echo $cunlisted?>/<?php echo $ctotal?> (<?php echo round($cunlisted/$ctotal*100)?>%) 의 동맹들이 구성원수가 적어서 이 목록에서 제외되었습니다.<br>
<?php echo $unallied?>/<?php echo $utotal?> (<?php echo round($unallied/$utotal*100)?>%) 제국들이 독립적입니다.<br>
<?php
HTMLendcompact();
?>
