<?php
include("header.php");
 
function structures()
{
        global $uera;
?>
<table class="inputtable" width="777">
<tr><th colspan="2" width="771"> 건설하기 : 『<?php echo $uera[name]?> 건물의 설명』</th></tr>
<tr><th width="78"><?php echo $uera[shops]?></th>
    <td width="689">
            <p>시장은 제국의 경제성장을 도와줍니다. 이 건물이 많을수록 제국의 
            수입이 올라갑니다. 매턴 더 많은 돈을 얻을 수 있습니다.</p>
</td></tr>
<tr><th width="78"><?php echo $uera[homes]?></th>
    <td width="689">
            <p>국민의 생활터전입니다. 낮은 세율에 강한 군사력, 그리고 충분한 
            가옥이 있다면 더 많은 국민들이 모여들 겁니다.</p>
</td></tr>
<tr><th width="78"><?php echo $uera[barracks]?></th>
    <td width="689">
            <p>키프는 병력이 소모하는 유지비를 보다 능률적으로 사용하게 하여 
            많은 지출비를 절감하게 해줍니다.또한 키프는, 당신이 암거래 시장에서 
            뭔가를 구입하거나 판매할 때 키프의 양에 비례하여 당신에게 이득을 
            안겨 줄 겁니다.</p>
</td></tr>
<tr><th width="78"><?php echo $uera[industry]?></th>
    <td width="689">
            <p>이것은 병력이 될 기본 재원을 차출합니다. 당신이 제국관리 메뉴에서 설정한 
            생산비율에 맞추어 전투병력이 구성 됩니다.이것이 없으면 병력이 모이지 않습니다</p>
</td></tr>
<tr><th width="78"><?php echo $uera[labs]?></th>
    <td width="689">
            <p>마법의 탑은 마법시전에 있어 반드시 필요한 마법사들을 교육시켜 
            만들어 냅니다. 마법사들은 매턴마다 마법력을 축적시켜 갑니다. 보다 
            많은 마법사가 있을수록 강력한 마법을 시전시킬 수 있게 됩니다.</p>
</td></tr>
<tr><th width="78"><?php echo $uera[farms]?></th>
    <td width="689">
            <p>제국의 국민과 군대에게 반드시 필요한 식량을 생산합니다. 식량이 
            고갈되어 제국의 사람들이 굶주리게 된다면, 그들은 곧 제국을 떠나버립니다.당연히 
            건강도 떨어집니다. 이것은 언제나 넉넉해야 합니다.</p>
</td></tr>
<tr><th width="78"><?php echo $uera[towers]?></th>
    <td width="689">
            <p>이것은 훌륭한 방어건물입니다. 하나에 5명의 일반병사급 공격력을 
            견딜 수 있는 방어력이 있습니다.</p>
</td></tr>
<tr><th height="23" width="78"><?php echo $uera[banks]?></th>
    <td height="23" width="689">
            <p>은행은 돈을 입금하거나 대출할 수 있는 곳입니다. 1000이상의 돈을 
            입금, 대출 할 수 있습니다.</p>
</td></tr>
<tr><th width="78"><?php echo $uera[mines]?></th>
    <td width="689">
            <p>철광은 병사, 용과 갈레온 배, 그리고 농빈들에게 반드시 필요한 
            자원입니다.이게 없으면 제국 사람들은 떠나갈 것이며 제국의 기술발전도 
            중단되어 버립니다.</p>
</td>
    </tr>
</table>
<?php
}
 
function munits()
{
        global $eradb, $uera, $era, $config, $section;
        $myera = $uera;
        $eras = mysql_query("SELECT id,name FROM $eradb ORDER BY id;");
        while ($eera = mysql_fetch_array($eras))
        {
?>
<?php echo $eera[name]?>
<?php
        }
        if ($era)
                $uera = loadEra($era);
?>
<table class="inputtable" width="818">
<tr><th colspan="5" width="812"><?php echo $uera[name]?>의 세대에 따른 병력종류와 변화치</th></tr>
<tr><th width="98">Unit</th>
    <th width="519">설명</th>
    <th width="88">기본가격</th>
    <th width="49">공격.</th>
    <th width="42">방어.</th></tr>
<tr><th width="98" height="5"><?php echo $uera[armtrp]?></th>
    <td width="519" height="5">가장 기초적인 병력유닛입니다. 그다지 강력한 유닛은 
            아닙니다만  <br>싼가격에 구매&amp;생산이가능하며무리를 짓는다면 
            적에게 큰타격을 입힐 <br> 수 있습니다.<br></td>
    <td class="acenter" width="88" height="5">$<?php echo $config[armtrp]?></td>
    <td class="acenter" width="49" height="5"><?php echo $uera[o_armtrp]?></td>
    <td class="acenter" width="42" height="5"><?php echo $uera[d_armtrp]?></td></tr>
<tr><th width="98"><?php echo $uera[lndtrp]?></th>
    <td width="519">매우강력한 <?php if ($uera[o_lndtrp] > $uera[d_lndtrp]) echo "공격"; else echo "방어";?> 유닛입니다. 
            적에게 쉽게 공격이 가능하며 초반에  <br>일반병사와 같이 무난히 쓸 수 
            있는 유닛입니다.</td>
    <td class="acenter" width="88">$<?php echo $config[lndtrp]?></td>
    <td class="acenter" width="49"><?php echo $uera[o_lndtrp]?></td>
    <td class="acenter" width="42"><?php echo $uera[d_lndtrp]?></td></tr>
<tr><th width="98"><?php echo $uera[flytrp]?></th>
    <td width="519">공중공격을 하는 최고의 유닛입니다. 이들은 또한 적의 중심을 
            순식간에 <br> 점령해내는 강력한 공격력이있으며 허공에서 공격하기에
            회피와 공격의 전환도 쉬워  <b><?php if ($uera[o_flytrp] > $uera[d_flytrp]) echo "공격력"; else echo "방어력";?></b>이 특히 강력합니다.</td>
 
    <td class="acenter" width="88">$<?php echo $config[flytrp]?></td>
    <td class="acenter" width="49"><?php echo $uera[o_flytrp]?></td>
    <td class="acenter" width="42"><?php echo $uera[d_flytrp]?></td></tr>
<tr><th width="98"><?php echo $uera[seatrp]?></th>
    <td width="519">이 유닛은 군사목적 뿐만아니라 외국으로 나가 다른 군주에게 
            도움을  <br>주는 용도로도 쓰입니다.<br> 공격과방어가 모두 강한 능력을 
            갖추고 있지만 강력하고 다목적으로  <br>쓰이는 만큼 가격도 많이 비쌉니다.</td>
    <td class="acenter" width="88">$<?php echo $config[seatrp]?></td>
    <td class="acenter" width="49"><?php echo $uera[o_seatrp]?></td>
    <td class="acenter" width="42"><?php echo $uera[d_seatrp]?></td></tr>
</table>
<?php
        $uera = $myera;
}
 
function military()
{
        global $eradb, $uera, $era;
        munits();
?>
<hr style="width:100%">
<table class="inputtable">
<tr><td><table class="inputtable">
<tr><th>공격하기</th>
    <td>당신의 침략으로 적군의 제국에 타격을 입힙니다.</td></tr>
<tr><th>공격에 관한 몇가지 이야기</th>
    <td>침략을 성공적으로 이루어 내려면 상대방이상의 힘이 갖춰져 있어야합니다. 
            군사로 밀어붙일지 마법으로 밀어붙일지는 순 당신의 선택입니다.</td></tr>
<tr><td></td>
    <td>침략에 성공하게 되면 적의 자원을 약탈할 수 있게 됩니다.</td></tr>
<tr><th>방어에 관한 몇가지 이야기</th>
    <td>제국의 국력과 건강, 방어탑등의 조건이 풍부할수록 방어는 수월하게 됩니다.</td></tr>
</table>
<table class="inputtable">
<tr><th>공격방식</th>
    <th>설명</th></tr>
<tr><th>일반공격</th>
    <th>스스로 정한 배율법대로의 공격을 시행하여 가장평균적인 효과를 거둘 수 있는 전투방식입니다.
by 8%.</th>
</tr>
<tr><th>습격</th>
    <td>출동시키면 25%의 추가 공격력을 얻습니다. 하지만 건강을 소모시키며 병력의 
            손실도 증가하게 됩니다. 조심하여야 합니다.</td></tr>
<tr><th>게릴라전</th>
    <td>오로지 <?php echo $uera[armtrp]?> 유닛만을 사용합니다.</td></tr>
<tr><th>땅공격</th>
    <td>오로지 <?php echo $uera[lndtrp]?> 유닛만을 사용합니다.</td></tr>
<tr><th>공중공격</th>
    <td>오로지 <?php echo $uera[flytrp]?> 유닛만을 사용합니다.</td></tr>
<tr><th>수중공격</th>
    <td>오로지 <?php echo $uera[seatrp]?> 유닛만을 사용합니다.</td></tr>
<tr><td colspan="2"><hr style="width:100%"></td></tr>
<tr><th>일반공격/습격/게릴라 효과</th>
    <td>0-7% 의 건물을 파괴, 0~10%의 빈땅을 갈취해 옵니다.</td></tr>
<tr><th>공중공격</th>
    <td>이공격은 공중에서 불을 토해 적의 건물을 태워 버리고 영지를 강탈하는 
            것입니다.</td></tr>
<tr><th>수상공격,폭격전</th>
    <td><?php echo $uera[seatrp]?> 오로지나 <?php echo $uera[lndtrp]?> 만을 동원하여 <?php echo $uera[towers]?> 와(/과) <?php echo $uera[labs]?> 
            를 집중공격하는 방식입니다. 역시 땅을 강탈할 수 있습니다.</td></tr>
</table>
<hr style="width:100%"></td></tr>
</table>
<table class="inputtable" style="width:100%">
<tr><td colspan="3"><hr style="width:100%"></td></tr>
<tr><th></th>
    <th>Enemy losses</th>
    <th>Your losses</th></tr>
<tr><th><?php echo $uera[armtrp]?></th>
    <td class="acenter">0%-8.05%</td>
    <td class="acenter">0%-14.5%</td></tr>
<tr><th><?php echo $uera[lndtrp]?></th>
    <td class="acenter">0%-7.3%</td>
    <td class="acenter">0%-12.85%</td></tr>
<tr><th><?php echo $uera[flytrp]?></th>
    <td class="acenter">0%-6.75%</td>
    <td class="acenter">0%-7.88%</td></tr>
<tr><th><?php echo $uera[seatrp]?></th>
    <td class="acenter">0%-5.55%</td>
    <td class="acenter">0%-6.5%</td></tr>
<tr><th>Troop loss multiplier</th>
    <th colspan="2">Multipiers to the loss percentages</th></tr>
<tr><th>Your troops</th>
    <td colspan="2">1/((Offensive_Points/(Defensive_Points+1))/1.25)</td></tr>
<tr><th>Enemy</th>
    <td colspan="2">(Offensive_Points/(Defensive_Points+1))/1.5</td></tr>
</table>
<?php
}
 
function status()
{
        global $uera;
?>
<table class="inputtable" width="810">
<tr><th width="147">필드</th>
    <th width="653">설명</th></tr>
<tr><th colspan="2" width="804">상황창 설명 : 제국</th></tr>
<tr><th width="147">
            <p>돈</p>
</th>
    <td width="653">당신이 지금 보유하고 있는 돈의 총합을 표시합니다.</td></tr>
<tr><th width="147">재산</th>
    <td width="653">
            <p>당신의 재산은 제국을 구성하고 있는 유닛들의 통합을 계산하여 가치로 
            나타냅니다. 마법사, 시민, 쌀, 돈과 당신이 가진 땅 등, 당신이 계획적으로 
            육성시킨 제국의 총가치를 표시합니다.</p>
</td></tr>
<tr><th width="147">Population</th>
    <td width="653">
            <p>당신의 제국안에서 살고 있는 시민의 수를 나타냅니다.이것은 당신의 
            제국제정에 없어서는 안될 수입입니다. 제국관리에서 세율을 조정할 
            수 있습니다. 이들은 집과 넓은 땅을 보유하고 있으며, 강력하고 세율이 
            낮은 제국에 모여듭니다.</p>
</td></tr>
<tr><th width="147">종족</th>
    <td width="653">
            <p>당신의 제국에 살고있는 거주자를 나타냅니다.</p>
</td></tr>
<tr><th width="147">
            <p>세대</p>
</th>
    <td width="653">
            <p>당신의 제국에 살고있는 거주자의 세대를 나타냅니다. </p>
</td></tr>
<tr><th colspan="2" width="804">
            <p>상황창설명 : 농사</p>
</th></tr>
<tr><th width="147">생산</th>
    <td width="653">
            <p>&nbsp;농장과 아직사용하지 않은 영토는 쌀을 생산합니다. 이것은 
            데개 턴마다 얼마나 많은 쌀을 생산하는가 나타냅니다.</p>
</td></tr>
<tr><th width="147">
            <p>소비</p>
</th>
    <td width="653">
            <p>당신의 군대, 시민, 그리고 마법사는 생존을 위해서 쌀을 요구합니다. 
            매턴마다 판단됩니다.<b>팁 : </b>비율을 조정하여 군대를 줄이던지 
            농장과 시장을 더 만드시던지 돈모으기나 농사짓기 메뉴를 사용하시면 
            됩니다.</p>
</td></tr>
<tr><th width="147">총합</th>
    <td width="653">이것은 당신이 쌀을 얻던지 적자를내던지에 관한 포괄적인 것을 
            나타냅니다..</td></tr>
<tr><th colspan="2" width="804">상황창 설명 : 상태</th></tr>
<tr><th width="147">사용된 턴</th>
    <td width="653">이것은 당신의 제국이 건설된 이래 사용한 총턴을 나타냅니다.</td></tr>
<tr><th width="147">순위</th>
    <td width="653">세계의 군주들과, 총재산을 견주어 당신의 제국순위를 결정냅니다.</td></tr>
<tr><th width="147">공격행위</th>
    <td width="653">당신이 타 제국 침략에 얼마나 열을 올렸는지 가르켜 줍니다. 
            당신이 행한 침략횟수와, 그횟수중에 성공적인 공격이었는 것에 따른 
            % 도 가 나타납니다.</td></tr>
<tr><th width="147">방어행위</th>
    <td width="653">타 제국이 당신영토에 &nbsp;얼마나 침략했는지 가르켜 줍니다. 
            타제국이 행한 침략횟수와, 그 침략들을 얼마나 성공적으로 막아왔는가를 
            % 도 가 나타내어줍니다.</td></tr>
<tr><th width="147">킬(Kill)</th>
    <td width="653">당신이 파괴시켜 버린 제국의 수를 나타냅니다.</td></tr>
<tr><th colspan="2" width="804">상황창설명 : 땅</th></tr>
<tr><th width="147"></th>
    <td width="653">이 것은 제국이&nbsp;얼마나 많은 종류별의 구조물을 가지고 
            있나를 나태닙니다.</td></tr>
<tr><th colspan="2" width="804">상황창설명 : 재정은행에서 거래되고 있는 당신의 
            금전상황치도 나타내어줍니다.</th></tr>
<tr><th width="147">예상수입</th>
    <td width="653">당신 제국인의 건강치와비례된 &nbsp;제국에 속한 시민의 수입능력을 
            가르켜줍니다.</td></tr>
<tr><th width="147">예상지출</th>
    <td width="653">당신의 지출대부분은 군대의 유지비로 사용됩니다. 키프는 이런 
            지출을 보다 효율적으로 사용하게 하여 지출을 보다 효과적으로 줄일 
            수 있게 해줍니다. 지출을 줄이시려면 군대의 생산비율을 줄이시던지,키프를 
            늘리시기 바랍니다.</td></tr>
<tr><th width="147">총</th>
    <td width="653">수입과 지출의 결과를 나타내어줍니다.</td></tr>
<tr><th width="147">대출</th>
    <td width="653">만약 당신이 세계은행에서 돈을 대출 받으면 매턴당 이자가 
            붙어갑니다. 당신이 빌린돈이 다음턴에는 어떻게 불어날지를 표시해줍니다.</td></tr>
<tr><th width="147">저금</th>
    <td width="653">세계은행에 돈을 저금하면 매턴당 이자가 붙어갑니다. 당신이 
            저금한돈이 다음턴에는 어떻게 불어날지와 이자율을 표시해줍니다.</td></tr>
<tr><th colspan="2" width="804">상황창설명 : 군사</th></tr>
<tr><th width="147">유닛</th>
    <td width="653">당신이 지금 가지고 있는 군사유닛이 얼마나 많은가 나타냅니다.</td></tr>
<tr><th width="147">공격점수</th>
    <td width="653">당신의 공격력을 나타냅니다. <a href="<?php echo $config[main]?>?action=guide&amp;section=military&amp;era=<?php echo $users[era]?>"><b><font color="blue">가가전쟁 
            &nbsp;의 군사설명 보기</font></b></a></td></tr>
<tr><th width="147">방어점수</th>
    <td width="653">당신의 방어력을 나타냅니다. <a href="<?php echo $config[main]?>?action=guide&amp;section=military&amp;era=<?php echo $users[era]?>"><b><font color="blue">가가전쟁                 &nbsp;의 군사설명 보기</font></b></a></td></tr>
</table>
<?php
}
 
function scores()
{
        global $perminutes;
?>
<b>순위는 매일 <?php echo $perminutes?> 분마다 업데이트 됩니다..</b><br>
<table class="inputtable" width="807">
<tr><th colspan="2" width="801">
            <p>『스코어 페이지 : color 』</p>
</th></tr>
<tr><th width="72">
            <p><font color="#98E7B2">여행모드</font></p>
</th>
    <td width="725">
            <p>군주는 제국에서 떠나 여행을 갑니다. 가가전쟁 법에 따라 군주가 
            비어있는 제국으로는 타국이 침범할 수 없습니다.그대신 해당군주의 
            플레이어는 여행에 책정된 시간만큼 게임플레이가 제한됩니다 여행을 
            떠난 군주는 스코어 페이지에서 이런색깔로 표시됩니다.</p>
</td></tr>
<tr><th width="72">
            <p><font color="red">멸망</font></p>
</th>
    <td width="725">
            <p>제국이 멸망해 버리면 이런색으로 표시됩니다.</p>
</td></tr>
<tr><th width="72">
            <p><font color="yellow">버려진 제국</font></p>
</th>
    <td width="725">
            <p>이 경우는 대개, 플레이어가 부정한 방법으로 게임을 즐기다가 적발되거나 
            한 플레이어가 두개 이상의 영지를 만들려다적발되어 운영자에 의해 
            계정이 파괴될 때 이루어집니다. 게임 내에 버그를 신고하지 않고 버그를 
            이용하여 이득을 보는 것도 이에 해당됩니다. 노매너는 이 경우에 해당하지 
            않습니다. 이 때는 이런색으로 표시됩니다.</p>
</td></tr>
<tr><th width="72">
            <p><font color="aqua">당신</font></p>
</th>
    <td width="725">
            <p>지금 플레이를 하고 있는 당신을 나타내는 색은 이것입니다.스코어보드에서 
            영지앞에 *가 띄워져 있는 제국은 플레이어들이 당신과 함께 접속하고 
            있다는 말입니다.</p>
</td></tr>
<tr><th colspan="2" width="801">
            <p>『스코어 페이지 : 현황창』</p>
</th></tr>
<tr><th width="72">
            <p>순위</p>
</th>
    <td width="725">
            <p>모든 군주들의 자산을 합산 계산하여 서로간의 비교를 통해 등위를 
            매기는 것입니다. 순위는 얼마든지 변동할 수 있습니다.</p>
</td></tr>
<tr><th width="72">
            <p>제국</p>
</th>
    <td width="725">
            <p>여기는 군주들의 제국명과 번호가 나타납니다.</p>
</td></tr>
<tr><th width="72">
            <p>땅 </p>
</th>
    <td width="725">
            <p>여기에는 군주들이 가지고 있는 영지의 넓이를 나타냅니다.</p>
</td></tr>
<tr><th width="72">
            <p>재산 </p>
</th>
    <td width="725">
            <p>군주들의 총 자산가치를 계산하여 나타내어 줍니다.</p>
</td></tr>
<tr><th width="72">
            <p>동맹</p>
</th>
    <td width="725">
            <p>군주가 속해있는 동맹단체의 명을 나타냅니다. 'None'은 아무곳에도 
            속해있지 않음을 의미합니다.</p>
</td></tr>
<tr><th width="72">
            <p>종족 </p>
</th>
    <td width="725">
            <p>군주들의 종족과, 그들이 다스리는 종족입니다.</p>
</td></tr>
<tr><th width="72">
            <p>세대 </p>
</th>
    <td width="725">
            <p>군주들의 발전된 정도 - 세대 - 를 나타냅니다.세대가 높다고 꼭 
            모든면에서 발전이 된 것은 아닙니다. 일부 부분은 오히려 퇴보할 수 
            있습니다.</p>
</td></tr>
</table>
<?php
}
 
function esearch()
{
?>
<table class="inputtable" width="803">
<tr><th colspan="2" width="797">
            <p>『제국 검색』</p>
</th></tr>
<tr><th width="111">
            <p>제국 번호</p>
</th>
    <td width="682">
            <p>이곳에 특정 군주의 번호를 넣으시길 바랍니다. (게임 내 모든 군주의 
            번호는 앞에 #가 붙는데, #는 입력하실 필요가 없습니다.)</p>
</td></tr>
<tr><th width="111">
            <p>제국명 검색</p>
</th>
    <td width="682">
            <p>만약 당신이 누군가의 제국 이름까지 포함하여 검색을 하시려면, 
            이것을 누르십시오.</p>
</td></tr>
<tr><th width="111">
            <p>세대 검색</p>
</th>
    <td width="682">
            <p>세대를 통해 제국을 검색하실 때 사용하십시오.</p>
</td></tr>
<tr><th width="111">
            <p>온라인 검색</p>
</th>
    <td width="682">
            <p>지금 접속해 있는 플레이어들만 검색합니다. </p>
</td></tr>
<tr><th colspan="2" width="797">
            <p>(최고 25명의 플레이어 리스트가 뜹니다.)</p>
</th></tr>
</table>
<?php
}
 
function cash()
{
        global $uera;
?>
<b>돈 모으기</b><table class="inputtable" width="762">
<tr><td width="756"> 15%, 25%, 53% 등 당신의 세대발전으로 인해 증가한 재정능력에 
            따라 <?php echo $uera[peasants]?> 들이 생산해내는 돈을 모읍니다.</td></tr>
</table>
<?php
}
 
function farm()
{
        global $uera;
?>
<b>농사짓기</b><br>
<table class="inputtable" width="798">
<tr><td width="792"> 세대가 발전함에 따라 15%, 25%, 53%씩 광부들이 한 번에 캐내는 
            철의 양도 증가합니다.<br>※주의 : 위의 15%, 25%, 53%가 반드시 1, 
            2, 3 세대에 순서대로 적용되는 것은 아닙니다.</td></tr>
</table>
<?php
}
 
// New Function: mine() 
// Use:
// Shows the guide for mining.
 
function mine()
{
        global $uera;
?>
<b>광물 캐기</b><table class="inputtable" width="792">
<tr><td width="786">
            <p>세대가 발전함에 따라 15%, 25%, 53%씩 광부들이 한 번에 캐내는 
            철의 양도 증가합니다.<br>※주의 : 위의 15%, 25%, 53%가 반드시 1, 
            2, 3 세대에 순서대로 적용되는 것은 아닙니다.</p>
</td></tr>
</table>
<?php
}
 
// End of new function mine()
// - zEro
 
function explore()
{
?>
<b>탐사</b><br>
제국의 영토를 넓힐 때 사용됩니다. 턴당 얻을 수 있는 수치는 계속 달라지는데 작아지는 
추세로 감소하니,<br>한번에 많은 양의 턴을 투자하는 것이 좋습니다. 하지만 무리한 
탐사로 인해 턴을 함부로 쓰는 <br>것은 조심해야 할 것입니다.결국 당신의 제국에 
더 이상 탐사할 여분의 황무지가 남지 않아 탐사를 못할 상황에 <br>놓인다면, 가지고 
있는 땅 위의 건물을 제거하여여분의 땅을 만들거나 전쟁을 일으켜 땅을 뺏는 방법이 
있습니다. <br>그 외에 탐사가 다시 가능하게 될 때까지 기다리는 것과 마지막으로 
마법을사용하여 땅을 만들어내는 방법이 있습니다..<br>
<?php
}
 
function news()
{
?>
<b>뉴스검색</b><table class="inputtable">
<tr><td>이것은, 최근에 일어난 주요한 전투의 소식을 쉽게 알아볼 수 있도록 하는 
            것입니다.<br>뉴스에는 궁주들의 공격과 방어에 대한 것이 포함되어 
            있으며 군주들은 이것을 자주볼.<br>필요성이 있습니다.</td></tr>
</table>
<?php
}
 
function bmarket()
{
        global $uera, $config;
?>
<h2>암거래시장</h2><br>
<table class="inputtable" width="770">
<tr><th width="103">
            <p>정의</p>
</th>
    <td width="657">
            <p>대중에게는 공개되지 않은 어둠의 시장은 당신의 제국 내에 존재하지 
            않습니다.</p>
</td></tr>
<tr><th width="103">
            <p>보충비율</p>
</th>
    <td width="657">
            <p>암거래 시장은 어느 곳보다도 물건 보충이 빠릅니다.</p>
</td></tr>
<tr><th width="103">
            <p>가격</p>
</th>
    <td width="657"><?php echo $uera[barracks]?> 는 최대 <?php echo (1-$config[mktshops])*100?>% 까지 
            가격을 할인시키는데 도와줄 것입니다. &nbsp;물건을 쉽게 구할 수 있는대신 
            <br>가격이 비싸단 단점이 있습니다.70%의 기본가격에서 종족에 따라 
            가격보너스를 더 받을 수도 있습니다.</td></tr>
<tr><th width="103">
            <p>매각에관해</p>
</th>
    <td width="657">
            <p>당신은 어떤 타입의 병력이라도 매각할 수 있습니다. (매각비율은 
            기록되고 시간에 따라 1%*(1+가게/땅)씩 떨어져 갑니다.)</p>
</td></tr>
</table>
<p style="line-height:125%; margin-top:0; margin-bottom:0;"><?php
}
 
function pmarket()
{
?> <b>열린시장</b><br>
열린시장은 제국의 안에서 장사하는 것이 허가되어 있는 곳입니다. 각종 물건들을 
이곳에서 구매할 수 있습니다.
<p style="line-height:125%; margin-top:0; margin-bottom:0;">당신이 뭔가 물건을 
산다면, 여기서는 세일기간 동안 5%의 상품가격을 깎아 줄 것입니다.</p>
<p style="line-height:125%; margin-top:0; margin-bottom:0;">당신이 구매한 물건을 
되팔려고 한다면 당신은 물건 가격의 20%를 손해볼 것입니다.</p>
<p style="line-height:125%; margin-top:0; margin-bottom:0;">시장에 없는 물건을 
당신이 팔아준다면 시장은 당신을 우대할 것입니다.</p>
<p>
<?php
}
 
function manage()
{
        global $uera, $config;
?>
<b>제국관리하기</b></p>
<table class="inputtable">
<tr><th>세금</th>
    <td>국민들의 세금을 그들의 수익에서 얼마만큼 징수할 것인지 퍼센트를 부과하는 
            것입니다.</td></tr>
<tr><th></th>
    <td>세금을 너무 부과시키면 민심이 흉흉해지고 나라의 건강이 떨어지며 국력이 
            약해지고 반란이 일어납니다.</td></tr>
<tr><th></th>
    <td>세금을 60~70% 이상이나 초과해서 사용하시는 분들은 세금징수 <b>10%</b>가 
            초과될 때 마다 건강도가 1%씩 떨어진다는 사실을 알아두셔야할 것입니다.</td></tr>
<tr><th></th>
    <td>건강은 마법으로 치료하거나 세금을 낮게 책정하거나 전쟁에서 승리하여 
            올릴 수 있습니다.</td></tr>
<tr><td colspan="2"><hr style="width:100%"></td></tr>
<tr><th>다형변화</th>
    <td>원하는 종족으로 국민전체를 갈아치우는 것입니다.</td></tr>
<tr><th></th>
    <th>다형변화(폴리모프)를 위한 조건.</th></trd>
    </tr>
<tr><th></th>
    <td class="acenter">당신제국의 <?php echo $uera[wizards]?> 이 소모됩니다.</td></tr>
<tr><th></th>
    <td class="acenter"><?php echo $config[initturns]?> 턴의 시간이 듭니다.</td></tr>
<tr><th></th>
    <td class="acenter">75%의 건강이 소모됩니다.</td></tr>
<tr><th></th>
    <th>그로부터오는 무거운 변화</th></tr>
<tr><th></th>
    <td class="acenter">10%-15% 가량의 유닛을 잃게 됩니다. (죽이게 되는 것입니다)</td></tr>
<tr><th></th>
    <td class="acenter">16%-54% 가량의 건물을 부서지게 합니다. (빈땅으로 돌아오는 
            것도 일부 입니다)</td></tr>
<tr><th></th>
    <td class="acenter">15%-45% 의 <?php echo $uera[wizards]?> 가 소모가 되고 전체적인 
            마나 증가치가 떨어지게 됩니다.(종족에 따라 다르긴 합니다)</td></tr>
<tr><th></th>
    <td class="acenter"><?php echo $config[initturns]?> 가 소모됩니다.</td></tr>
<tr><th></th>
    <td class="acenter">오로지</td></tr>
<tr><td colspan="2"><hr style="width:100%"></td></tr>
<tr><th>생산비율설정</th>
    <td>당신의 대장장이에게 주문할 유닛의 비율을 조절할 수 있습니다.</td></tr>
<tr><th></th>
    <td><b>계산하는 방식에 대한 정의.</b></td></tr>
<tr><th></th>
    <td>(<?php echo $uera[industry]?>) * (본디 대장장이가 소화할 수 있는오로지생산비율) * (당신이 
            정한 비율)</td></tr>
<tr><th>비율:</th>
    <td><table class="guide" style="width:100%"><tr><td><?php echo $uera[armtrp]?> = 1.2</td><td><?php echo $uera[lndtrp]?> = 
0.6</td><td><?php echo $uera[flytrp]?> = 0.3</td><td><?php echo $uera[seatrp]?> = 0.2</td></tr></table></td></tr>
<tr><td colspan="2"><hr style="width:100%"></td></tr>
<tr><th>암호변경</th>
    <td>당신의 암호를 변경합니다.</td></tr>
<tr><th></th>
    <td>안전을 위해서라도 주변에서 쉽게 캐어낼 수 있는 간단한 것은 피합시다. 
            당신이 이메일이나 기타 중요한 목적으로 사용하는 암호를 기입하셔도 
            상관 없습니다. 암호는 복잡한 코드로 재변경되어 게임의 운영자도 알아낼 
            수 없게 됩니다. 문제가 발생할시, 운영자는 그 어떤 책임도 져드리지 
            않습니다.</td></tr>
<tr><td colspan="2"><hr style="width:100%"></td></tr>
<tr><th>여행모드</th>
    <td>가가전쟁의 불문율에 따라 군주가 여행을 떠나 제국을 비웠을 때는 서로 
            공격하지 않게 됩니다.</td></tr>
<tr><th></th>
    <td>한번 설정하게 되면 12시간 이상 아무 것도 할 수 없게 됩니다. 그대신 공격을 
            쉽게 받지 않게 됩니다.</td></tr>
<tr><th></th>
    <td>하지만 안심할 순 없습니다. 마법을 사용하여 비열한 방법으로 해당 제국을 
            공격하는 방법도 존재하니까요.</td></tr>
</table>
<?php
}
 
function magic()
{
        global $uera, $config;
include("magicfun.php");
        global $spname; 
?>
<b>Magic</b><br>
<table class="inputtable">
<tr><td><hr style="width:100%"></td></tr>
<tr><td>
<table class="inputtable">
<tr><th>마법시전하기</th>
    <td>당신의 원하는 <?php echo $uera[runes]?> 을(/를) 사용합니다.</td></tr>
<tr><th>성공/실패</th>
    <td>당신의 제국이 얼마나 부국하냐,  <?php echo $uera[wizards]?>은(/는) 얼마만큼 
            준비되어있나 등에 따라 확률이 갈립니다.</td></tr>
<tr><th>공격하는 마법계산</th>
    <td>((당신의_<?php echo $uera[wizards]?>)/((당신의 땅 + 적국의 땅)의 절반)))/((적국의_<?php echo $uera[wizards]?>)/(적국의 
            땅))</td></tr>
<tr><th>성공에 중요한 것</th><td>(<?php echo $uera[wizards]?>)/(<?php echo $uera[labs]?>)</td></tr>
</table>
    <table class="inputtable" style="width:100%">
    <tr><th>스펠이름
:</th><th><?php echo $spname[3]?></th><th><?php echo $spname[6]?></th><th><?php echo $spname[10]?></th><th><?php echo $spname[11]?></th><th>세
대진화</th></tr>
    <tr><th>힘:</th><td>15</td><td>30</td><td>75</td><td>80</td><td>90</td></tr>
    </table>
    <table class="inputtable" style="width:100%">
    <tr><th>스펠이름
:</th><th><?php echo $spname[1]?></th><th><?php echo $spname[2]?></th><th><?php echo $spname[4]?></th><th><?php echo $spname[5]?></th><th><?php echo $spname[7]?></th><th><?php echo $spname[8]?></th><th><?php echo $spname[9]?></th></tr>
    <tr><th>힘:</th><td>1</td><td>20%</td><td>1.21</td><td>1.3</td><td>1.7</td><td>1.75</td><td>2.2</td></tr>
    </table><table class="inputtable">
<tr><th><?php echo $spname[1]?></th>
    <td>상대방의 정보를 훔쳐볼 수 있습니다.</td></tr>
<tr><th><?php echo $spname[2]?></th>
    <td>3~10%가량의 적군 병력을 파괴의 불로 녹여버립니다.</td></tr>
<tr><th><?php echo $spname[3]?></th>
    <td>마법에 의한 데미지를 깎아주는 막을 형성합니다.</td></tr>
<tr><th><?php echo $spname[4]?></th>
    <td>거대한 폭풍으로 적의 식량과 금전창고를 부셔버립니다.</td></tr>
<tr><th><?php echo $spname[5]?></th>
    <td>적의  <?php echo $uera[runes]?> 힘의 일부를 소진시켜버립니다. </td></tr>
<tr><th><?php echo $spname[6]?></th>
    <td>
            <p style="line-height:120%; margin-top:0; margin-bottom:0;">제작방식 (<?php echo $uera[wizards]?> * 나라의 
            건강 * 70 * (1 + (<?php echo $uera[labs]?>/땅) * (기타 마법보너스))) 
            <p style="line-height:120%; margin-top:0; margin-bottom:0;">당신의 
            땅에 돈이 떨어지게 합니다.</p>
</td></tr>
<tr><th><?php echo $spname[7]?></th>
    <td>적군의 시민을 미치게하여 도시내에서 난동을 부리게 합니다. 그 결과로 
            적군의 건설물이 파괴됩니다.</td></tr>
<tr><th><?php echo $spname[8]?></th>
    <td>적군의 돈을 훔쳐냅니다. 당신의 힘이 강할수록 그 수치가 증가합니다.</td></tr>
<tr><th><?php echo $spname[9]?></th>
    <td>성공한다면 적땅의 일부를 갈취하게 될 것 입니다. 적의 마법력이 강하다면 
            그 반발이 일어나 엄청난 부작용이 일어날 수도 있습니다. 당신이 강하다면 
            사용하십시오,</td></tr>
<tr><th><?php echo $spname[10]?></th>
    <td>시공을 초월하는 문을 엽니다. 효과는 불명입니다.</td></tr>
<tr><th><?php echo $spname[11]?></th>
    <td>시공을 초월하는 문을 닫습니다. 효과는 불명입니다.</td></tr>
<tr><th>세대진화</th>
    <td>1세대 -&gt; 2세대 -&gt; 3세대 순으로 진화가 됩니다. 여러 가지 국가 벨런스가 
            수정됩니다.</td></tr>
<tr><th>땅생성마법</th>
    <td>당신의 마법력이 강하면 강할수록 땅을 더욱 많이 생성하게 됩니다.</td></tr>
<tr><th>치료</th>
    <td>국민과 군대의 건강을 달랠 수 있습니다. 하지만 국가가 너무나도 쇄약해지면 
            이것은 무용지물이 됩니다.</td></tr>
                <tr>
<th>
                        <p>숨겨진것</p>
</th>
    <td>
                        <p>가가전쟁에는 고대유적에 잠들어 있는 기묘한 술법들이 
                        많이 숨어있습니다. 그중 어떤 것은 하나의 나라를 완전히 
                        파괴시킬 정도로 강력한 위력을 지니고 있다고 합니다. 
                        어떻게 사용하는 지, 얼마만큼의 희생을 치뤄야하는 지는 
                        누구도 알 수 없습니다.</p>
</td>
                </tr>
</table>
</td></tr>
<tr><td><hr style="width:100%"></td></tr>
</table>
<?php
}
 
function races()
{
        global $racedb, $uera, $config;
?>
<h2>종족에 따른 보너스</h2>
<table>
<tr><th>공격:</th>
    <td>당신의 공격적인 힘으로 다른 군주를 침략하는 것입니다.</td></tr>
<tr><th>방어:</th>
    <td>&nbsp;방어의 힘으로 다른 군주의 침략을 막는&nbsp;것입니다.</td></tr>
<tr><th>건설:</th>
    <td>당신은 간단하게 건물을 건설(또는 파괴) 할수있습니다.</td></tr>
<tr><th>제정:</th>
    <td>당신의 돈의 총액에서는 병력 유닛에 대한 유지비가 계속적으로 나갑니다.</td></tr>
<tr><th>마법:</th>
    <td>당신의 마법으로 다른 군주에게 마법을 걸 수 있습니다.<br> 종족에따라서 
            효율과 위력의 차이가 나타납니다.</td></tr>
<tr><th>산업:</th>
    <td>당신의 이능력으로 군사유닛을 생산할 수 있습니다.</td></tr>
<tr><th>생산:</th>
    <td>당신의 영지에서는 매턴 얼마만큼의 수익을 낼 수 있는지를 나타냅니다.</td></tr>
<tr><th>탐사:</th>
    <td>이것으로 당신의 건물을 지을 빈 땅을 얻을 수 있습니다. 땅을 얻는 방법에는<br>이것말고로 
            침략과 땅생성마법의 방법이 있습니다.</td></tr>
<tr><th>시장:</th>
    <td>열린시장에서는 군주끼리의 (혹은 상인들의) 쉬운거래가 가능하지만<br> 
            공급과 수요가 원활치못하다는 단점이 있습니다.</td></tr>
<tr><th>식량:</th>
    <td>당신의 사람(국민,병력)이 턴당 먹어치우는 유지비용의 일종입니다.</td></tr>
<tr><th>마법력:</th>
    <td>당신의 마법사들은 매턴당 국가에서 전쟁으로 쓰일(혹은 기타용도로)<br>마법력을 
            축적합니다.</td></tr>
<tr><th>농장:</th>
    <td>매턴당 당신의 영지에서 쓰일 식량을 생산합니다.</td></tr>
<tr><th>광산:</th>
    <td>이 갱도에서 당신의 영지에서 사용할 철을 생산합니다.</td></tr>
<tr><th>철소모:</th>
    <td>당신영토의 각종건물과, 군수물품을 제작하려면 철이 소모됩니다.<br>철이 
            떨어지면 매턴생산되는 군사병력이 생산되지않습니다.</td></tr>
    <tr>
<th>
            <p>보는법</p>
</th>
    <td>
            <p>+ 와 - 치수를 떠나서 <font color="#00CC33">녹색</font>은 무조건 
            좋은 것, <font color="red">붉은 것</font>은 나쁜 것입니다.</p>
</td>
    </tr>
</table>
<table border width="934">
<tr><th width="50" height="30"><span style="font-size:9pt;">종족명</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">공격력</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">방어력</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">건설력</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">재정추가소비</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">마법력</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">산업력</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">생산력</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">탐사능력</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">시장추가소비</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">식량추가소모</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">마력축적</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">농장생산</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">광산</span></th>
    <th width="50" height="30"><span style="font-size:9pt;">철추가소모</span></th></yt>
<?php
function printRace ($race)
{
?>
    </tr>
<tr><th width="50" height="30"><span style="font-size:9pt;"><?php echo $race[name]?></span></th>
<?php
        printAttrib($race,'offense',1);
        printAttrib($race,'defense',1);
        printAttrib($race,'bpt',1);
        printAttrib($race,'costs',2);
        printAttrib($race,'magic',1);
        printAttrib($race,'ind',1);
        printAttrib($race,'pci',1);
        printAttrib($race,'expl',1);
        printAttrib($race,'mkt',2);
        printAttrib($race,'food',2);
        printAttrib($race,'runes',1);
        printAttrib($race,'farms',1);
        printAttrib($race,'ironbonus',1);
        printAttrib($race,'ironlack',2);
 
}
 
function printAttrib ($race, $attrib, $type)
{
        $val = 100 * ($race[$attrib] - 1);
        if ($val < 0)
                $sign = '-';
        if ($val > 0)
                $sign = '+';
        if ($val == 0)
                $color = 'cneutral';
        if ($type == 1)
        {
                if ($val < 0)
                        $color = 'cbad';
                elseif ($val > 0)
                        $color = 'cgood';
                else    $sign = '+';
        }
        if ($type == 2)
        {
                if ($val < 0)
                        $color = 'cgood';
                elseif ($val > 0)
                        $color = 'cbad';
                else    $sign = '-';
        }
?>
    <td class="<?php echo $color?>" width="50" height="30"><?php echo $sign?><?php echo abs($val)?><span style="font-size:9pt;">%</span></td>
 
     
 
<?php
        // if ($attrib == 'farms') print '</tr>';
                if ($attrib == 'ironlack') print '</tr>';
?>
 
<?php
}
$races = mysql_query("SELECT * FROM $racedb;");
while ($race = mysql_fetch_array($races))
        printRace($race);
?>
    </tr>
</table>
<?php
}
 
function intro()
{
        global $turnsper, $perminutes, $config;
?>
<h3>당신의 목표</h3>
<table class="inputtable">
<tr><td>당신은 당신만의 제국을 다스리는 군주가되어, 다른 모든 군주를 뛰어넘어 
            최고의 제왕으로 <br>군림한다는 목표가 있습니다. 때로는 화친,모략. 
            그리고 전쟁을 일으켜서라도 당신과 <br>경쟁하는 모든 자들을 이겨내고 
            누구도 넘볼 수 없는 부와 권력을 거느림으로써,<br>당신의 목표를 성취하여야 
            합니다.</td></tr>
</table>
<h3>턴에관한 기본 게임규칙</h3>
<table class="inputtable">
<tr><th>턴</th>
    <td>이 검과마법( <?php echo $config[servname]?> )에서는 당신은 <b><?php echo $turnsper?>의 
            턴을  <?php echo $perminutes?></b> 분마다 받을 수 있습니다.<br>
        당신은  <?php echo $config[maxturns]?> 턴이상을 축적할 수 없으며, 일반적으로 
            당신에게 주어진 턴을 날마다 <br>사용해 주어야합니다. 이용할 수 있는 
            턴은 상황창(<a href="<?php echo $config[main]?>?action=guide&amp;section=statusbar"><b><font color="#33CC33">status 
bar</font></b></a>)에서 
            보실수 있습니다.</td></tr>
<tr><th>턴사용하기</th>
    <td>침략하기. 마법을 쓰기와 다른 제국 도와주기. 땅탐색하기, 건물짓기. 그리고 
            돈을 사용하는 행동등등<br>당신은 당신의 턴을 이런 방식등으로 사용하게 
            됩니다.<br>턴을 다쓰게되면, 시간의 흐름에 따라 턴이 다시 모여집니다.<br></td></tr>
<tr><th>특수턴</th>
    <td>당신이 모으는 것 외에 축적이 따로되는 턴이 있는데,&nbsp;이 특수한 턴은 
            <?php echo $config[maxstoredturns]?> 턴까지 모으실수 있습니다.<br> <?php echo $perminutes?> 분마다 
            이 턴이 축적되며, 자동으로 턴을 하나씩 채워줍니다.</td></tr>
<tr><th>턴의흐름</th>
    <td>당신이 턴을 사용한다는 것은, 당신의 제국에서 시간이 흘러간다는 말이며 
            자연히 당신의 영지가<br>성장하거나 피폐해져가는 것을 의미합니다. 
            당신의 경제사정은 당신의 판단 나름으로 흘러갈겁니다.<br></td></tr>
<tr><th>보호턴</th>
    <td>처음 <?php echo $config[protection]?> 턴 동안은 당신의 제국이 보호받습니다. 
            그말인즉, <?php echo $config[protection]?> 을 사용하지 않은 군주는 공격받지도,<br>할 
            수도 없고 외교에도 제한을 받는다는 말입니다. 당연히 서로에게 공격적인 
            마법도 할 수 없습니다.<br>(처음시작하는 모든 군주들은 <?php echo $config[protection]?> 
            턴이 넘어가는 순간부터 바짝긴장 하셔야 할겁니다)</td></tr>
</table>
<?php
}
 
function messages()
{
        global $perminutes;
?>
<h3>Messages</h3>
<table class="inputtable" width="624">
<tr><th width="51">이용법 </th>
    <td width="563">다른 군주에게 전문을 날릴 수 있습니다. 메시지함을 클릭하여 
            원하시는 제국의 번호를 기입하고 글을쓰고 보내기버튼을오로지클릭 
            하면 자동으로 해당 군주에게 메시지가 갑니다. 게임에서는 &quot;서신&quot;이라는 
            개념을 도입하고 있기 때문에 메시지를 주고받음에 있어 약간의 딜레이와 
            한계치수를 두고 있습니다. 메시지가 더 이상 보내지지 않게 되면 15분을 
            기다리셨다가 다시 해보세요.</td></tr>
</table>
<?php
}
 
function statusbar()
{
        global $uera;
?>
<h3>상황창</h3>
<table class="inputtable" width="761">
<tr><th width="79">메세지함</th>
    <td width="672">이것은 메시지보기에 사용됩니다. &quot;<b><font color="red">New Mail!</font></b>&quot; 이라고 
            뜨면 타영지의 군주로부터<br>새로운 전문이 도착했단 말입니다.</td></tr>
<tr><th width="79">턴</th>
    <td width="672">이용가능한 당신의 턴을 표시합니다. 턴에 관한 정보는  <a href="<?php echo $config[main]?>?action=guide&amp;section=intro">이것</a> 을 
            누르셔서 보실수 있습니다.</td></tr>
<tr><th width="79">돈</th>
    <td width="672">당신이 가지고 있는 금전의 총합을 표시합니다. 당신이 은행에 
            맡긴 재산은 표시되지 않습니다</td></tr>
<tr><th width="79">땅</th>
    <td width="672">당신의 제국이 소유하고 있는땅의 총합을 표시합니다.</td></tr>
<tr><th width="79"><?php echo $uera[runes]?></th>
    <td width="672">당신의 마법사들의 마법력 총합을 표시합니다.</td></tr>
<tr><th width="79"><?php echo $uera[food]?></th>
    <td width="672">당신이 보유하고 있는 <?php echo $uera[food]?> 의 총합을 표시합니다.</td></tr>
<tr><th width="79">건강</th>
    <td width="672">당신의 사람들 (시민,군대와 마법사)의 건강을 표시합니다.<br> 
            건강은 당신의 공격과 방어데 대한 힘에 영향을 주며, 당신제국의 풍족도와 
            전쟁에<br>따라서 변동됩니다.</td></tr>
<tr><th width="79">재산</th>
    <td width="672">당신제국의 총합가치를 표시합니다.</td></tr>
<tr><th width="79">철</th>
    <td width="672">당신이 가진 철의 총합을 표시합니다.</td></tr>
</table>
<?php
}
 
function eras()
{
        global $uera;
?>
<h3>세대변화의 차이</h3>
 
<table class="guide" width="324">
  <tr>
    <th width="43">세대</th>
    <th width="51">산업력</th>
    <th width="51">마법력 </th>
    <th width="51">재정력</th>
    <th width="53">농사력</th>
    <th width="49">채광력</th>
  </tr>
  <tr>
    <th width="43">1세대</th>
    <td width="51">-5%</td>
    <td width="51">+40%</td>
    <td width="51">+25%</td>
         <td width="53">+53%</td>
         <td width="49">+25%</td>
  </tr>
  <tr>
    <th width="43">2세대</th>
    <td width="51">+0%</td>
    <td width="51">+0%</td>
    <td width="51">+53%</td>
         <td width="53">+15%</td>
         <td width="49">+15%</td>
  </tr>
  <tr>
    <th width="43">3세대</th>
    <td width="51">+15%</td>
    <td width="51">-20%</td>
    <td width="51">+15%</td>
         <td width="53">+23%</td>
         <td width="49">+53%</td>
  </tr>
  <tr>
    <th width="43">유닛</th>
    <td colspan="2" width="106"> <a href="<?php echo $config[main]?>?action=guide&amp;section=munits">군사유닛보기</a></td>
        <td width="51"></td>
        <td width="53"></td>
        <td width="49"></td>
  </tr>
</table>
 
<?php
}
 
?>
<h1><a href="<?php echo $config[main]?>?action=guide">가가전쟁 가이드</a><br><span style="font-size:10pt;"><br>가가전쟁 한글판 원작: <a href="http://gagax.com" target=_top>GaGaX.com</a><br>가이드 번역: <a href="http://darknrei.wo.to" target=_top>Darkmaster</a><br></h1>
<?php
 
switch ($section)
{
        case messages:          messages();     break;
        case statusbar:         statusbar();    break;
        case build:             structures();   break;
        case eras:              eras();         break;
        case military:          military();     break;
        case status:            status();       break;
        case scores:            scores();       break;
        case search:            esearch();      break;
        case farm:              farm();         break;
        case cash:              cash();         break;
        case land:              explore();      break;
        case news:              news();         break;
        case intro:             intro();        break;
        case munits:            munits();       break;
        case pvtmarketbuy:
        case pvtmarketsell:     bmarket();      break;
        case pubmarketbuy:
        case pubmarketsell:     pmarket();      break;
        case manage:            manage();       break;
        case magic:             magic();        break;
        case races:             races();        break;
        case mine:              mine(); break;
        default:
?>
<table class="guide" style="width:90%">
<tr><th>기본설명</th>
    <th>정보</th>
    <th>턴사용</th>
    <th>거래</th>
    <th>주변과관계</th>
    <th>기타</th></tr>
<tr><td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=intro">게임시작</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=news">뉴스검색</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=cash">돈모으기</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=pubmarketbuy">열린시장</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=magic">마법과 
            스펠</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=manage">제국관리</a></td></tr>
<tr><td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=races">종족에 대하여</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=status">제국정보</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=land">탐사</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=pvtmarketbuy">암거래시장</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=military">공격하기</a></td>
    <td>
            <p align="center"><a href="promisance.php?action=credits">게임제작</a></td></tr>
<tr><td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=munits">군사유닛</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=scores">점수</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=build">건설하기</a></td>
    <td>
            <p align="center">&nbsp;</td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=messages">메세지</a></td>
    <td>
            <p align="center">&nbsp;</td></tr>
<tr><td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=statusbar">상황창</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=search">제국검색</a></td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=farm">농사짓기</a></td>
    <td>
            <p align="center">&nbsp;</td>
    <td>
            <p align="center">&nbsp;</td>
    <td>
            <p align="center">&nbsp;</td></tr>
<tr><td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=eras">세대의흐름</a></td>
    <td>
            <p align="center">&nbsp;</td>
    <td>
            <p align="center"><a href="<?php echo $config[main]?>?action=guide&amp;section=mine">광물캐기</a></td>
    <td>
            <p align="center">&nbsp;</td>
    <td>
            <p align="center">&nbsp;</td>
    <td>
            <p align="center">&nbsp;</td></tr>
</table>
<?php
                break;
}
TheEnd("");
?>
