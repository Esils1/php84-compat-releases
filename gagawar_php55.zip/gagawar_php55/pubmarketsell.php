<?php
include("header.php");

if ($lockdb)
	TheEnd("열린 시장을 사용할 수 없습니다!");

function printRow ($type)
{
	global $users, $uera, $costs, $basket;
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($users[$type])?></td>
    <td class="aright"><?php echo commas($basket[$type])?></td>
    <td class="aright">$<input type="text" name="sellprice[<?php echo $type?>]" value="<?php echo $costs[$type]?>" size="5"></td>
    <td class="aright"><input type="text" name="sell[<?php echo $type?>]" value="0" size="8"></td></tr>
<?php
}

function getCosts ($type)
{
	global $marketdb, $config, $users, $costs, $time;
	$market = mysql_fetch_array(mysql_query("SELECT * FROM $marketdb WHERE type='$type' AND seller!=$users[num] AND time<=$time ORDER BY price ASC, time ASC LIMIT 1;"));
	if ($market[price])
		$costs[$type] = $market[price];
	else	$costs[$type] = $config[$type];
}

function calcBasket ($type, $percent)
{
	global $marketdb, $users, $uera, $basket, $config, $time;
	$onsale = 0;
	$goods = mysql_query("SELECT * FROM $marketdb WHERE type='$type' AND seller=$users[num] ORDER BY amount DESC;");
	while ($market = mysql_fetch_array($goods))
	{
		$onsale += $market[amount];
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($market[amount])?></td>
    <td class="aright">$<?php echo commas($market[price])?></td>
    <td class="aright"><?php
		if (($market[time] -= $time) < 0)
		{
			?>On Sale for <?php echo round($market[time]/-3600,1)?> hour(s) - <a href="<?php echo $config[main]?>?action=pubmarketsell&amp;do_removeunits=yes&amp;remove_id=<?php echo $market[id]?>">Remove</a><?php
		}
		else
		{
			?>In Transit, <?php echo round($market[time]/3600,1)?> hour(s) remaining<?php
		}
?></td></tr>
<?php
	}
	$basket[$type] = round(($users[$type] + $onsale) * $percent) - $onsale;
	if ($basket[$type] < 0)
		$basket[$type] = 0;
}

function sellUnits ($type)
{
	global $marketdb, $users, $uera, $sell, $sellprice, $config, $basket, $time;
	$minprice = $config[$type] * 0.2;
	$maxprice = $config[$type] * 2.5;
	$amount = $sell[$type];
	fixInputNum($amount);
	$price = $sellprice[$type];
	fixInputNum($price);
	if (($amount == 0) || ($price == 0))
		return;
	if ($amount < 0)
		print "$uera[$type] 를 0 보다 적게 팔 수 없습니다!<br>\n";
	elseif ($amount > $basket[$type])
		print "$uera[$type] 를 그렇게 많이 팔 수 없습니다!<br>\n";
	elseif ($price < $minprice)
		print "$uera[$type] 를 그렇게 싸게 팔 수 없습니다!<br>\n";
	elseif ($price > $maxprice)
		print "$uera[$type] 를 그렇게 비싸게 팔 수 없습니다!<br>\n";
	else
	{
		$users[$type] -= $amount;
		$basket[$type] -= $amount;
		mysql_query("INSERT INTO $marketdb (type,seller,amount,price,time) VALUES ('$type',$users[num],$amount,$price,$time+3600*$config[market]);");
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($amount)?></td>
    <td class="aright">$<?php echo commas($price)?></td>
    <td class="aright">수송중: <?php echo $config[market]?>시간 남았습니다</td></tr>
<?php
	}
}

function removeUnits ($id)
{
	global $marketdb, $users, $uera;
	$market = mysql_fetch_array(mysql_query("SELECT * FROM $marketdb WHERE id=$id;"));
	if ($market[seller] != $users[num])
		print "그런 물건이 없습니다!<br>\n";
	else
	{
		$amount = $market[amount];
		$type = $market[type];
		mysql_query("DELETE FROM $marketdb WHERE id=$id;");
		$users[$type] += floor($market[amount] * .8);
		print "당신은 ".commas($amount)." $uera[$type] 를 시장에서 뺏습니다.<br>\n";
		saveUserDataNet($users,"networth $type");
	}
}

if ($users[turnsused] <= $config[protection])
	TheEnd("보호 받고 있는 중 열린 시장을 이용할 수 없습니다!");

if ($do_removeunits)
	removeUnits($remove_id);
?>
<table class="inputtable">
<caption>시장에 있거나 시장에 도착 예정인 물건:</caption>
<tr><th class="aleft">유닛</th>
    <th class="aright">양</th>
    <th class="aright">가격</th>
    <th class="aright">상태</th></tr>
<?php
for ($i = 0; $i < 4; $i++)
	calcBasket($trplst[$i],0.25);
calcBasket(food,0.90);
// Runes Alpha Code
calcBasket(runes,0.90);
calcBasket(iron,0.90);
if ($do_sell)
{
//	for ($i = 0; $i < 5; $i++)
	for ($i = 0; $i < 7; $i++)
		sellUnits($trplst[$i]);
//	saveUserDataNet($users,"networth armtrp lndtrp flytrp seatrp food");
	saveUserDataNet($users,"networth armtrp lndtrp flytrp seatrp food runes iron");
}
?>
    <tr><td colspan="4"><hr></td></tr>
</table>
참고: <a href="<?php echo $config[main]?>?action=guide&amp;section=military&amp;era=<?php echo $users[era]?>">가가전쟁 설명서: 군대</a><br>
당신의 물건이 시장에 도착하려면 <?php echo $config[market]?> 시간이 걸릴 것입니다.<br>
<form method="post" action="<?php echo $config[main]?>?action=pubmarketsell">
<?php
// for ($i = 0; $i < 5; $i++)
	for ($i = 0; $i < 7; $i++)
	getCosts($trplst[$i]);
?>
<table class="inputtable">
<tr><td colspan="2"><a href="<?php echo $config[main]?>?action=pubmarketbuy">물건 구입하기</a></td>
    <td>&nbsp;</td>
    <td colspan="2" class="aright"><a href="<?php echo $config[main]?>?action=pubmarketsell">물건 판매하기</a></td></tr>
<tr><th class="aleft">유닛</th>
    <th class="aright">보유</th>
    <th class="aright">판매 가능양</th>
    <th class="aright">가격</th>
    <th class="aright">판매</th></tr>
<?php
// for ($i = 0; $i < 5; $i++)
for ($i = 0; $i < 7; $i++)
	printRow($trplst[$i]);
?>
<tr><td colspan="5" class="acenter"><input type="submit" name="do_sell" value="Sell Goods"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
