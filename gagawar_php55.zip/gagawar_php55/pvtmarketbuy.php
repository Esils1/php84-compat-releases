<?php
include("header.php");

function getCosts ($type)
{
	global $users, $config, $urace, $costs, $canbuy;
	$mkttype = "pmkt_".$type;
	$costbonus = 1 - ((1-$config[mktshops])*($users[barracks] / $users[land]) + $config[mktshops]*($users[shops] / $users[land]));
	if ($type == food)
		$costs[$type] = $config[$type];
	if ($type == iron)
		$costs[$type] = $config[$type];
	else
	{
		$costs[$type] = $config[$type] * $costbonus;
		if ($costs[$type] < $config[$type] * .7)
			$costs[$type] = $config[$type] * .7;
		$costs[$type] = round($costs[$type] * $urace[mkt]);
	}
	$canbuy[$type] = floor($users[cash] / $costs[$type]);
	if ($canbuy[$type] > $users[$mkttype])
		$canbuy[$type] = $users[$mkttype];
}

function buyUnits ($type)
{
	global $costs, $users, $uera, $buy, $canbuy;
	$amount = $buy[$type];
	fixInputNum($amount);
	$cost = $amount * $costs[$type];
	$mkttype = "pmkt_".$type;
	if ($amount == 0)
		return;
	elseif ($amount < 0)
		print "$uera[$type]를 0개 보다 적개 살 수 없습니다!<br>\n";
	elseif ($amount > $users[$mkttype])
		print "$uera[$type] 이 부족합니다!<br>\n";
	elseif ($cost > $users[cash])
		print "$uera[$type]를 $amount 개 살 돈이 부족합니다!<br>\n";
	else
	{
		$users[cash] -= $cost;
		$users[$type] += $amount;
		$users[$mkttype] -= $amount;
		$canbuy[$type] -= $amount;
		print commas($amount)."개의 $uera[$type] 를 구입했습니다. 비용: $".commas($cost).".<br>\n";
	}
}

function printRow ($type)
{
	global $users, $uera, $costs, $canbuy;
	$mkttype = "pmkt_".$type;
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($users[$type])?></td>
    <td class="aright"><?php echo commas($users[$mkttype])?></td>
    <td class="aright">$<?php echo commas($costs[$type])?></td>
    <td class="aright"><?php echo commas($canbuy[$type])?></td>
    <td class="aright"><input type="text" name="buy[<?php echo $type?>]" size="8" value="0"></td></tr>
<?php
}

for ($i = 0; $i < 5; $i++)
	getCosts($trplst[$i]);
	getCosts($trplst[6]);
if ($do_buy)
{
	for ($i = 0; $i < 5; $i++)
		buyUnits($trplst[$i]);
		buyUnits($trplst[6]);
	saveUserDataNet($users,"networth cash armtrp lndtrp flytrp seatrp food pmkt_armtrp pmkt_lndtrp pmkt_flytrp pmkt_seatrp pmkt_food iron");
}
for ($i = 0; $i < 5; $i++)
	getCosts($trplst[$i]);
	getCosts($trplst[6]);
?>
Also see: <a href="<?php echo $config[main]?>?action=guide&amp;section=military&amp;era=<?php echo $users[era]?>">가가전쟁 설명서: 군대</a><br>
<form method="post" action="<?php echo $config[main]?>?action=pvtmarketbuy">
<table class="inputtable">
<tr><td colspan="3"><a href="<?php echo $config[main]?>?action=pvtmarketbuy">물건 구입하기</a></td>
    <td colspan="3" class="aright"><a href="<?php echo $config[main]?>?action=pvtmarketsell">물건 판매하기</a></td></tr>
<tr><th class="aleft">대상</th>
    <th class="aright">소유</th>
    <th class="aright">구입 가능</th>
    <th class="aright">비용</th>
    <th class="aright">구매 가능</th>
    <th class="aright">구입</th></tr>
<?php
for ($i = 0; $i < 5; $i++)
	printRow($trplst[$i]);
	printRow($trplst[6]);
?>
<tr><td colspan="6" class="acenter"><input type="submit" name="do_buy" value="물건 구입하기"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
