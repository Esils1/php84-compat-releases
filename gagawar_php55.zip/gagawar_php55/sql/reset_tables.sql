-- Gagawar monthly reset: clear game tables only. Database is not dropped.
SET NAMES utf8;
-- Run this against the existing game database before gagawar_reset_data_only.sql.
SET FOREIGN_KEY_CHECKS=0;
TRUNCATE TABLE `clan`;
TRUNCATE TABLE `en_eras`;
TRUNCATE TABLE `en_races`;
TRUNCATE TABLE `kr_eras`;
TRUNCATE TABLE `kr_races`;
TRUNCATE TABLE `lottery`;
TRUNCATE TABLE `market`;
TRUNCATE TABLE `messages`;
TRUNCATE TABLE `news`;
TRUNCATE TABLE `players`;
SET FOREIGN_KEY_CHECKS=1;
