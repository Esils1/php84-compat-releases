<?php
/*
 * rankings1.php
 * PHP 5.5 compatible local ranking saver.
 * 위치: sql/rankings1.php
 * 동작: 상위 폴더의 promisance.php?action=top10 과 같은 결과를 로컬 include 방식으로 생성합니다.
 */

$base_dir = realpath(dirname(__FILE__) . '/..');
$outfile = dirname(__FILE__) . '/kr_gagawar1.html';

if ($base_dir === false || !file_exists($base_dir . '/promisance.php')) {
    fwrite(STDERR, "promisance.php not found\n");
    exit(1);
}

$old_cwd = getcwd();
chdir($base_dir);

$_GET['action'] = 'top10';
$_REQUEST['action'] = 'top10';
$action = 'top10';

if (!isset($_SERVER['REMOTE_ADDR'])) {
    $_SERVER['REMOTE_ADDR'] = '127.0.0.1';
}
if (!isset($_SERVER['SERVER_NAME'])) {
    $_SERVER['SERVER_NAME'] = 'localhost';
}
if (!isset($_SERVER['HTTP_REFERER'])) {
    $_SERVER['HTTP_REFERER'] = '';
}

ob_start();
include $base_dir . '/promisance.php';
$input = ob_get_clean();

if ($old_cwd) {
    chdir($old_cwd);
}

$pos = stripos($input, '<html>');
if ($pos !== false) {
    $input = substr($input, $pos);
}

if (@file_put_contents($outfile, $input . "\n", FILE_APPEND | LOCK_EX) === false) {
    fwrite(STDERR, "cannot write ranking file: " . $outfile . "\n");
    exit(1);
}

exit(0);
?>
