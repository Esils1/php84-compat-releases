-- Gagawar PHP 5.5 initial install SQL
-- 기존 데이터베이스는 삭제하지 않습니다. 선택한 DB 안에서 게임 테이블만 재생성합니다.
-- 초기 설치 후 한글 레이블까지 포함됩니다.
SET NAMES utf8;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `clan`;
DROP TABLE IF EXISTS `en_eras`;
DROP TABLE IF EXISTS `en_races`;
DROP TABLE IF EXISTS `kr_eras`;
DROP TABLE IF EXISTS `kr_races`;
DROP TABLE IF EXISTS `lottery`;
DROP TABLE IF EXISTS `market`;
DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `news`;
DROP TABLE IF EXISTS `players`;
SET FOREIGN_KEY_CHECKS=1;

-- MySQL dump 9.11
--
-- Host: localhost    Database: gagawar1
-- ------------------------------------------------------
-- Server version	4.0.20-standard-log

--
-- Table structure for table `clan`
--

CREATE TABLE clan (
  num smallint(5) unsigned NOT NULL auto_increment,
  founder mediumint(8) unsigned NOT NULL default '0',
  ally1 smallint(5) unsigned NOT NULL default '0',
  ally2 smallint(5) unsigned NOT NULL default '0',
  ally3 smallint(5) unsigned NOT NULL default '0',
  war1 smallint(5) unsigned NOT NULL default '0',
  war2 smallint(5) unsigned NOT NULL default '0',
  war3 smallint(5) unsigned NOT NULL default '0',
  pic tinytext NOT NULL,
  url tinytext NOT NULL,
  motd text NOT NULL,
  members smallint(5) unsigned NOT NULL default '1',
  name tinytext NOT NULL,
  tag tinytext NOT NULL,
  password tinytext NOT NULL,
  PRIMARY KEY  (num)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clan`
--


--
-- Table structure for table `en_eras`
--

CREATE TABLE en_eras (
  id tinyint(3) unsigned NOT NULL auto_increment,
  name tinytext NOT NULL,
  peasants tinytext NOT NULL,
  food tinytext NOT NULL,
  runes tinytext NOT NULL,
  armtrp tinytext NOT NULL,
  lndtrp tinytext NOT NULL,
  flytrp tinytext NOT NULL,
  seatrp tinytext NOT NULL,
  wizards tinytext NOT NULL,
  homes tinytext NOT NULL,
  shops tinytext NOT NULL,
  industry tinytext NOT NULL,
  barracks tinytext NOT NULL,
  labs tinytext NOT NULL,
  farms tinytext NOT NULL,
  towers tinytext NOT NULL,
  o_armtrp tinyint(3) unsigned NOT NULL default '0',
  d_armtrp tinyint(3) unsigned NOT NULL default '0',
  o_lndtrp tinyint(3) unsigned NOT NULL default '0',
  d_lndtrp tinyint(3) unsigned NOT NULL default '0',
  o_flytrp tinyint(3) unsigned NOT NULL default '0',
  d_flytrp tinyint(3) unsigned NOT NULL default '0',
  o_seatrp tinyint(3) unsigned NOT NULL default '0',
  d_seatrp tinyint(3) unsigned NOT NULL default '0',
  banks tinytext NOT NULL,
  bartrp tinytext NOT NULL,
  mines tinytext NOT NULL,
  iron tinytext NOT NULL,
  PRIMARY KEY  (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_eras`
--

INSERT INTO en_eras VALUES (1,'1st Age','Peasants','Grains','Mana','Footmen','Catapults','Dragons','Galleons','Wizards','Huts','Markets','Blacksmiths','Keeps','Mage Towers','Farms','Guard Towers',1,2,3,4,7,10,8,8,'Banks','Barbarians','Iron Mines','Iron');
INSERT INTO en_eras VALUES (2,'2nd Age','Peasants','Grains','Mana','Footmen','Catapults','Dragons','Galleons','Wizards','Huts','Markets','Blacksmiths','Keeps','Mage Towers','Farms','Guard Towers',2,2,4,3,8,6,9,7,'Banks','Barbarians','Iron Mines','Iron');
INSERT INTO en_eras VALUES (3,'3rd Age','Peasants','Grains','Mana','Footmen','Catapults','Dragons','Galleons','Wizards','Huts','Markets','Blacksmiths','Keeps','Mage Towers','Farms','Guard Towers',2,2,3,4,10,8,10,8,'Banks','Barbarians','Iron Mines','Iron');

--
-- Table structure for table `en_races`
--

CREATE TABLE en_races (
  id tinyint(3) unsigned NOT NULL auto_increment,
  name tinytext NOT NULL,
  offense float(5,3) NOT NULL default '1.000',
  defense float(5,3) NOT NULL default '1.000',
  bpt float(5,3) NOT NULL default '1.000',
  costs float(5,3) NOT NULL default '1.000',
  magic float(5,3) NOT NULL default '1.000',
  ind float(5,3) NOT NULL default '1.000',
  pci float(5,3) NOT NULL default '1.000',
  expl float(5,3) NOT NULL default '1.000',
  mkt float(5,3) NOT NULL default '1.000',
  food float(5,3) NOT NULL default '1.000',
  runes float(5,3) NOT NULL default '1.000',
  farms float(5,3) NOT NULL default '1.000',
  turns tinyint(1) unsigned NOT NULL default '2',
  mturns tinyint(1) unsigned NOT NULL default '2',
  ironbonus float(5,3) NOT NULL default '1.000',
  ironlack float(5,3) NOT NULL default '1.000',
  aidturns tinyint(1) unsigned NOT NULL default '2',
  PRIMARY KEY  (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_races`
--

INSERT INTO en_races VALUES (1,'Human',1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,2,2,1.000,1.000,2);
INSERT INTO en_races VALUES (2,'Elf',0.860,0.980,0.950,1.000,1.180,0.880,1.020,1.120,1.000,1.000,1.120,0.940,3,1,1.000,1.150,1);
INSERT INTO en_races VALUES (3,'Dwarf',1.060,1.160,1.160,1.080,0.840,1.120,1.000,0.820,1.080,1.000,0.880,1.000,1,3,1.120,1.000,3);
INSERT INTO en_races VALUES (4,'Troll',1.240,0.900,1.080,1.000,0.880,1.000,1.040,1.140,1.120,1.000,0.920,0.920,1,3,1.000,1.000,3);
INSERT INTO en_races VALUES (5,'Gnome',0.840,1.100,1.000,0.940,1.000,0.900,1.100,0.880,0.760,1.000,0.880,1.000,2,2,1.000,1.000,1);
INSERT INTO en_races VALUES (6,'Gremlin',1.100,0.940,1.000,1.000,0.900,0.860,0.800,1.000,0.920,0.860,1.000,1.180,2,2,1.000,1.000,2);
INSERT INTO en_races VALUES (7,'Orc',1.160,1.000,1.040,1.140,0.960,1.080,1.000,1.190,1.000,1.100,0.860,0.920,1,3,1.030,1.000,3);
INSERT INTO en_races VALUES (8,'Drow',1.140,1.060,0.880,1.100,1.180,1.000,1.000,0.840,1.000,1.000,1.060,0.940,1,2,1.000,1.200,3);
INSERT INTO en_races VALUES (9,'Goblin',0.820,0.840,1.000,0.820,1.000,1.140,1.000,1.000,1.060,0.920,1.000,1.000,2,2,1.000,1.110,2);
INSERT INTO en_races VALUES (10,'Golem',1.000,1.000,1.150,1.100,1.000,1.200,0.850,1.000,1.100,1.150,1.000,0.850,2,2,1.300,1.000,3);

--
-- Table structure for table `kr_eras`
--

CREATE TABLE kr_eras (
  id tinyint(3) unsigned NOT NULL auto_increment,
  name tinytext NOT NULL,
  peasants tinytext NOT NULL,
  food tinytext NOT NULL,
  runes tinytext NOT NULL,
  armtrp tinytext NOT NULL,
  lndtrp tinytext NOT NULL,
  flytrp tinytext NOT NULL,
  seatrp tinytext NOT NULL,
  wizards tinytext NOT NULL,
  homes tinytext NOT NULL,
  shops tinytext NOT NULL,
  industry tinytext NOT NULL,
  barracks tinytext NOT NULL,
  labs tinytext NOT NULL,
  farms tinytext NOT NULL,
  towers tinytext NOT NULL,
  o_armtrp tinyint(3) unsigned NOT NULL default '0',
  d_armtrp tinyint(3) unsigned NOT NULL default '0',
  o_lndtrp tinyint(3) unsigned NOT NULL default '0',
  d_lndtrp tinyint(3) unsigned NOT NULL default '0',
  o_flytrp tinyint(3) unsigned NOT NULL default '0',
  d_flytrp tinyint(3) unsigned NOT NULL default '0',
  o_seatrp tinyint(3) unsigned NOT NULL default '0',
  d_seatrp tinyint(3) unsigned NOT NULL default '0',
  banks tinytext NOT NULL,
  bartrp tinytext NOT NULL,
  mines tinytext NOT NULL,
  iron tinytext NOT NULL,
  PRIMARY KEY  (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kr_eras`
--

INSERT INTO kr_eras VALUES (1,'1 세대','시민','쌀','마법','일반병사','노포','용','갈레온배','마법사','가옥','시장','대장장이','Ű프','마법 ž','농장','방어ž',1,2,3,4,7,10,8,8,'은행','야만인','ö광','ö');
INSERT INTO kr_eras VALUES (2,'2 세대','시민','쌀','마법','일반병사','노포','용','갈레온배','마법사','가옥','시장','대장장이','Ű프','마법 ž','농장','방어ž',2,2,4,3,8,6,9,7,'은행','야만인','ö광','ö');
INSERT INTO kr_eras VALUES (3,'3 세대','시민','쌀','마법','일반병사','노포','용','갈레온배','마법사','가옥','시장','대장장이','Ű프','마법 ž','농장','방어ž',2,2,3,4,10,8,10,8,'은행','야만인','ö광','ö');

--
-- Table structure for table `kr_races`
--

CREATE TABLE kr_races (
  id tinyint(3) unsigned NOT NULL auto_increment,
  name tinytext NOT NULL,
  offense float(5,3) NOT NULL default '1.000',
  defense float(5,3) NOT NULL default '1.000',
  bpt float(5,3) NOT NULL default '1.000',
  costs float(5,3) NOT NULL default '1.000',
  magic float(5,3) NOT NULL default '1.000',
  ind float(5,3) NOT NULL default '1.000',
  pci float(5,3) NOT NULL default '1.000',
  expl float(5,3) NOT NULL default '1.000',
  mkt float(5,3) NOT NULL default '1.000',
  food float(5,3) NOT NULL default '1.000',
  runes float(5,3) NOT NULL default '1.000',
  farms float(5,3) NOT NULL default '1.000',
  turns tinyint(1) unsigned NOT NULL default '2',
  mturns tinyint(1) unsigned NOT NULL default '2',
  ironbonus float(5,3) NOT NULL default '1.000',
  ironlack float(5,3) NOT NULL default '1.000',
  aidturns tinyint(1) unsigned NOT NULL default '2',
  PRIMARY KEY  (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kr_races`
--

INSERT INTO kr_races VALUES (1,'인간',1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,2,2,1.000,1.000,2);
INSERT INTO kr_races VALUES (2,'엘프',0.860,0.980,0.950,1.000,1.180,0.880,1.020,1.120,1.000,1.000,1.120,0.940,3,1,1.000,1.150,2);
INSERT INTO kr_races VALUES (3,'드워프',1.060,1.160,1.160,1.080,0.840,1.120,1.000,0.820,1.080,1.000,0.880,1.000,1,3,1.120,1.000,2);
INSERT INTO kr_races VALUES (4,'Ʈ롤',1.240,0.900,1.080,1.000,0.880,1.000,1.040,1.140,1.120,1.000,0.920,0.920,1,3,1.000,1.000,2);
INSERT INTO kr_races VALUES (5,'놈',0.840,1.100,1.000,0.940,1.000,0.900,1.100,0.880,0.760,1.000,0.880,1.000,2,2,1.000,1.000,2);
INSERT INTO kr_races VALUES (6,'그렘린',1.100,0.940,1.000,1.000,0.900,0.860,0.800,1.000,0.920,0.860,1.000,1.180,2,2,1.000,1.000,2);
INSERT INTO kr_races VALUES (7,'오ũ',1.160,1.000,1.040,1.140,0.960,1.080,1.000,1.190,1.000,1.100,0.860,0.920,1,3,1.030,1.000,2);
INSERT INTO kr_races VALUES (8,'다ũ엘프',1.140,1.060,0.880,1.100,1.180,1.000,1.000,0.840,1.000,1.000,1.060,0.940,1,2,1.000,1.200,2);
INSERT INTO kr_races VALUES (9,'고블린',0.820,0.840,1.000,0.820,1.000,1.140,1.000,1.000,1.060,0.920,1.000,1.000,2,2,1.000,1.110,2);
INSERT INTO kr_races VALUES (10,'골렘',1.000,1.000,1.150,1.100,1.000,1.200,0.850,1.000,1.100,1.150,1.000,0.850,2,2,1.300,1.000,2);

--
-- Table structure for table `lottery`
--

CREATE TABLE lottery (
  num int(10) unsigned NOT NULL default '0',
  ticket int(10) unsigned NOT NULL default '0',
  cash bigint(20) unsigned NOT NULL default '0',
  KEY num (num),
  KEY ticket (ticket)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lottery`
--

INSERT INTO lottery VALUES (2,2,4336290);
INSERT INTO lottery VALUES (0,0,1096150320);
INSERT INTO lottery VALUES (0,1,1000000000);
INSERT INTO lottery VALUES (0,2,0);
INSERT INTO lottery VALUES (0,3,0);
INSERT INTO lottery VALUES (0,4,500000000);

--
-- Table structure for table `market`
--

CREATE TABLE market (
  id int(10) unsigned NOT NULL auto_increment,
  type tinytext NOT NULL,
  seller mediumint(8) unsigned NOT NULL default '0',
  amount bigint(20) unsigned NOT NULL default '0',
  price int(10) unsigned NOT NULL default '0',
  time int(11) NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY price (price),
  KEY time (time)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `market`
--


--
-- Table structure for table `messages`
--

CREATE TABLE messages (
  id int(10) unsigned NOT NULL auto_increment,
  time int(11) NOT NULL default '0',
  src mediumint(8) unsigned NOT NULL default '0',
  dest mediumint(8) unsigned NOT NULL default '0',
  msg text NOT NULL,
  replied tinyint(3) unsigned NOT NULL default '0',
  deleted tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY dest (dest),
  KEY time (time),
  KEY deleted (deleted)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--


--
-- Table structure for table `news`
--

CREATE TABLE news (
  time int(11) NOT NULL default '0',
  num_s mediumint(8) unsigned NOT NULL default '0',
  num_d mediumint(8) unsigned NOT NULL default '0',
  event smallint(5) unsigned NOT NULL default '0',
  data0 bigint(20) NOT NULL default '0',
  data1 bigint(20) NOT NULL default '0',
  data2 bigint(20) NOT NULL default '0',
  data3 bigint(20) NOT NULL default '0',
  data4 bigint(20) NOT NULL default '0',
  data5 bigint(20) NOT NULL default '0',
  data6 bigint(20) NOT NULL default '0',
  data7 bigint(20) NOT NULL default '0',
  data8 bigint(20) NOT NULL default '0',
  clan_s smallint(5) unsigned NOT NULL default '0',
  clan_d smallint(5) unsigned NOT NULL default '0',
  KEY time (time),
  KEY num_s (num_s),
  KEY num_d (num_d),
  KEY event (event),
  KEY clan_s (clan_s),
  KEY clan_d (clan_d)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--


--
-- Table structure for table `players`
--

CREATE TABLE players (
  username tinytext NOT NULL,
  password tinytext NOT NULL,
  name tinytext NOT NULL,
  email tinytext NOT NULL,
  IP tinytext NOT NULL,
  signedup int(11) NOT NULL default '0',
  ismulti tinyint(3) unsigned NOT NULL default '0',
  isbank tinyint(3) unsigned NOT NULL default '0',
  disabled tinyint(3) unsigned NOT NULL default '0',
  valcode tinytext NOT NULL,
  validated tinyint(3) unsigned NOT NULL default '0',
  online tinyint(3) unsigned NOT NULL default '0',
  vacation smallint(5) unsigned NOT NULL default '0',
  idle int(11) NOT NULL default '0',
  free int(11) NOT NULL default '0',
  empire tinytext NOT NULL,
  num mediumint(8) unsigned NOT NULL auto_increment,
  race tinyint(3) unsigned NOT NULL default '1',
  era tinyint(3) unsigned NOT NULL default '1',
  rank mediumint(8) unsigned NOT NULL default '0',
  offsucc int(10) unsigned NOT NULL default '0',
  offtotal int(10) unsigned NOT NULL default '0',
  defsucc int(10) unsigned NOT NULL default '0',
  deftotal int(10) unsigned NOT NULL default '0',
  kills int(10) unsigned NOT NULL default '0',
  turns int(10) unsigned NOT NULL default '0',
  turnsstored int(10) unsigned NOT NULL default '0',
  turnsused int(10) unsigned NOT NULL default '0',
  networth bigint(20) unsigned NOT NULL default '0',
  cash bigint(20) unsigned NOT NULL default '100000',
  food bigint(20) unsigned NOT NULL default '10000',
  peasants int(10) unsigned NOT NULL default '500',
  armtrp bigint(20) unsigned NOT NULL default '100',
  lndtrp bigint(20) unsigned NOT NULL default '15',
  flytrp bigint(20) unsigned NOT NULL default '10',
  seatrp bigint(20) unsigned NOT NULL default '0',
  health tinyint(3) unsigned NOT NULL default '100',
  wizards int(10) unsigned NOT NULL default '0',
  runes int(10) unsigned NOT NULL default '500',
  shield int(11) NOT NULL default '0',
  gate int(11) NOT NULL default '0',
  ind_armtrp tinyint(3) unsigned NOT NULL default '25',
  ind_lndtrp tinyint(3) unsigned NOT NULL default '25',
  ind_flytrp tinyint(3) unsigned NOT NULL default '25',
  ind_seatrp tinyint(3) unsigned NOT NULL default '25',
  land int(10) unsigned NOT NULL default '250',
  shops int(10) unsigned NOT NULL default '0',
  homes int(10) unsigned NOT NULL default '0',
  industry int(10) unsigned NOT NULL default '0',
  barracks int(10) unsigned NOT NULL default '0',
  labs int(10) unsigned NOT NULL default '0',
  farms int(10) unsigned NOT NULL default '0',
  towers int(10) unsigned NOT NULL default '0',
  freeland int(10) unsigned NOT NULL default '250',
  tax tinyint(3) unsigned NOT NULL default '10',
  savings bigint(20) unsigned NOT NULL default '0',
  loan bigint(20) unsigned NOT NULL default '0',
  pmkt_armtrp bigint(20) unsigned NOT NULL default '5000',
  pmkt_lndtrp bigint(20) unsigned NOT NULL default '5000',
  pmkt_flytrp bigint(20) unsigned NOT NULL default '5000',
  pmkt_seatrp bigint(20) unsigned NOT NULL default '5000',
  pmkt_food bigint(20) unsigned NOT NULL default '100000',
  bmperarmtrp smallint(5) unsigned NOT NULL default '0',
  bmperlndtrp smallint(5) unsigned NOT NULL default '0',
  bmperflytrp smallint(5) unsigned NOT NULL default '0',
  bmperseatrp smallint(5) unsigned NOT NULL default '0',
  aidcred tinyint(3) unsigned NOT NULL default '5',
  aidget tinyint(3) unsigned NOT NULL default '0',
  msgcred tinyint(3) unsigned NOT NULL default '5',
  msgtime int(11) NOT NULL default '0',
  newstime int(11) NOT NULL default '0',
  banks int(10) unsigned NOT NULL default '0',
  bartrp bigint(20) unsigned NOT NULL default '0',
  mines int(10) unsigned NOT NULL default '0',
  iron bigint(20) unsigned NOT NULL default '10000',
  pmkt_iron bigint(20) unsigned NOT NULL default '100000',
  style int(11) unsigned NOT NULL default '0',
  clan smallint(5) unsigned NOT NULL default '0',
  forces tinyint(3) unsigned NOT NULL default '0',
  allytime int(11) NOT NULL default '0',
  attacks int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (num),
  KEY networth (networth),
  KEY rank (rank)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `players`
--

INSERT INTO players VALUES ('admin','21232f297a57a5a743894a0e4a801fc3','admin','admin@hanmail.net','61.74.155.230',1093120408,0,0,0,'8ecfc9094626c6bcd288195409a8ec77',0,0,0,1093120408,0,'admin',2,1,1,2,0,0,0,0,0,120,0,0,24980,100000,10000,500,100,15,10,0,100,0,500,0,0,25,25,25,25,250,0,0,0,0,0,0,0,250,10,0,0,5000,5000,5000,5000,100000,0,0,0,0,5,0,5,1093120408,1093120408,0,0,0,10000,100000,0,0,0,0,0);

-- Korean label update for current DB.
-- Run once in phpMyAdmin or mysql client if an existing database still shows English unit/race labels.

UPDATE en_eras SET name='1시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=1;
UPDATE en_eras SET name='2시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=2;
UPDATE en_eras SET name='3시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=3;

UPDATE kr_eras SET name='1시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=1;
UPDATE kr_eras SET name='2시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=2;
UPDATE kr_eras SET name='3시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=3;

UPDATE en_races SET name='인간' WHERE id=1;
UPDATE en_races SET name='엘프' WHERE id=2;
UPDATE en_races SET name='드워프' WHERE id=3;
UPDATE en_races SET name='트롤' WHERE id=4;
UPDATE en_races SET name='노움' WHERE id=5;
UPDATE en_races SET name='그렘린' WHERE id=6;
UPDATE en_races SET name='오크' WHERE id=7;
UPDATE en_races SET name='다크엘프' WHERE id=8;
UPDATE en_races SET name='고블린' WHERE id=9;
UPDATE en_races SET name='골렘' WHERE id=10;

UPDATE kr_races SET name='인간' WHERE id=1;
UPDATE kr_races SET name='엘프' WHERE id=2;
UPDATE kr_races SET name='드워프' WHERE id=3;
UPDATE kr_races SET name='트롤' WHERE id=4;
UPDATE kr_races SET name='노움' WHERE id=5;
UPDATE kr_races SET name='그렘린' WHERE id=6;
UPDATE kr_races SET name='오크' WHERE id=7;
UPDATE kr_races SET name='다크엘프' WHERE id=8;
UPDATE kr_races SET name='고블린' WHERE id=9;
UPDATE kr_races SET name='골렘' WHERE id=10;
