-- Gagawar monthly reset data SQL
-- reset_tables.sql 실행 후 사용합니다. 한글 레이블을 포함합니다.
SET NAMES utf8;

-- MySQL dump 9.11
--
-- Host: localhost    Database: gagawar1
-- ------------------------------------------------------
-- Server version	4.0.20-standard-log


--
-- Dumping data for table `clan`
--



--
-- Dumping data for table `en_eras`
--

INSERT INTO en_eras VALUES (1,'1st Age','Peasants','Grains','Mana','Footmen','Catapults','Dragons','Galleons','Wizards','Huts','Markets','Blacksmiths','Keeps','Mage Towers','Farms','Guard Towers',1,2,3,4,7,10,8,8,'Banks','Barbarians','Iron Mines','Iron');
INSERT INTO en_eras VALUES (2,'2nd Age','Peasants','Grains','Mana','Footmen','Catapults','Dragons','Galleons','Wizards','Huts','Markets','Blacksmiths','Keeps','Mage Towers','Farms','Guard Towers',2,2,4,3,8,6,9,7,'Banks','Barbarians','Iron Mines','Iron');
INSERT INTO en_eras VALUES (3,'3rd Age','Peasants','Grains','Mana','Footmen','Catapults','Dragons','Galleons','Wizards','Huts','Markets','Blacksmiths','Keeps','Mage Towers','Farms','Guard Towers',2,2,3,4,10,8,10,8,'Banks','Barbarians','Iron Mines','Iron');


--
-- Dumping data for table `en_races`
--

INSERT INTO en_races VALUES (1,'Human',1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,2,2,1.000,1.000,2);
INSERT INTO en_races VALUES (2,'Elf',0.860,0.980,0.950,1.000,1.180,0.880,1.020,1.120,1.000,1.000,1.120,0.940,3,1,1.000,1.150,1);
INSERT INTO en_races VALUES (3,'Dwarf',1.060,1.160,1.160,1.080,0.840,1.120,1.000,0.820,1.080,1.000,0.880,1.000,1,3,1.120,1.000,3);
INSERT INTO en_races VALUES (4,'Troll',1.240,0.900,1.080,1.000,0.880,1.000,1.040,1.140,1.120,1.000,0.920,0.920,1,3,1.000,1.000,3);
INSERT INTO en_races VALUES (5,'Gnome',0.840,1.100,1.000,0.940,1.000,0.900,1.100,0.880,0.760,1.000,0.880,1.000,2,2,1.000,1.000,1);
INSERT INTO en_races VALUES (6,'Gremlin',1.100,0.940,1.000,1.000,0.900,0.860,0.800,1.000,0.920,0.860,1.000,1.180,2,2,1.000,1.000,2);
INSERT INTO en_races VALUES (7,'Orc',1.160,1.000,1.040,1.140,0.960,1.080,1.000,1.190,1.000,1.100,0.860,0.920,1,3,1.030,1.000,3);
INSERT INTO en_races VALUES (8,'Drow',1.140,1.060,0.880,1.100,1.180,1.000,1.000,0.840,1.000,1.000,1.060,0.940,1,2,1.000,1.200,3);
INSERT INTO en_races VALUES (9,'Goblin',0.820,0.840,1.000,0.820,1.000,1.140,1.000,1.000,1.060,0.920,1.000,1.000,2,2,1.000,1.110,2);
INSERT INTO en_races VALUES (10,'Golem',1.000,1.000,1.150,1.100,1.000,1.200,0.850,1.000,1.100,1.150,1.000,0.850,2,2,1.300,1.000,3);


--
-- Dumping data for table `kr_eras`
--

INSERT INTO kr_eras VALUES (1,'1 세대','시민','쌀','마법','일반병사','노포','용','갈레온배','마법사','가옥','시장','대장장이','Ű프','마법 ž','농장','방어ž',1,2,3,4,7,10,8,8,'은행','야만인','ö광','ö');
INSERT INTO kr_eras VALUES (2,'2 세대','시민','쌀','마법','일반병사','노포','용','갈레온배','마법사','가옥','시장','대장장이','Ű프','마법 ž','농장','방어ž',2,2,4,3,8,6,9,7,'은행','야만인','ö광','ö');
INSERT INTO kr_eras VALUES (3,'3 세대','시민','쌀','마법','일반병사','노포','용','갈레온배','마법사','가옥','시장','대장장이','Ű프','마법 ž','농장','방어ž',2,2,3,4,10,8,10,8,'은행','야만인','ö광','ö');


--
-- Dumping data for table `kr_races`
--

INSERT INTO kr_races VALUES (1,'인간',1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,1.000,2,2,1.000,1.000,2);
INSERT INTO kr_races VALUES (2,'엘프',0.860,0.980,0.950,1.000,1.180,0.880,1.020,1.120,1.000,1.000,1.120,0.940,3,1,1.000,1.150,2);
INSERT INTO kr_races VALUES (3,'드워프',1.060,1.160,1.160,1.080,0.840,1.120,1.000,0.820,1.080,1.000,0.880,1.000,1,3,1.120,1.000,2);
INSERT INTO kr_races VALUES (4,'Ʈ롤',1.240,0.900,1.080,1.000,0.880,1.000,1.040,1.140,1.120,1.000,0.920,0.920,1,3,1.000,1.000,2);
INSERT INTO kr_races VALUES (5,'놈',0.840,1.100,1.000,0.940,1.000,0.900,1.100,0.880,0.760,1.000,0.880,1.000,2,2,1.000,1.000,2);
INSERT INTO kr_races VALUES (6,'그렘린',1.100,0.940,1.000,1.000,0.900,0.860,0.800,1.000,0.920,0.860,1.000,1.180,2,2,1.000,1.000,2);
INSERT INTO kr_races VALUES (7,'오ũ',1.160,1.000,1.040,1.140,0.960,1.080,1.000,1.190,1.000,1.100,0.860,0.920,1,3,1.030,1.000,2);
INSERT INTO kr_races VALUES (8,'다ũ엘프',1.140,1.060,0.880,1.100,1.180,1.000,1.000,0.840,1.000,1.000,1.060,0.940,1,2,1.000,1.200,2);
INSERT INTO kr_races VALUES (9,'고블린',0.820,0.840,1.000,0.820,1.000,1.140,1.000,1.000,1.060,0.920,1.000,1.000,2,2,1.000,1.110,2);
INSERT INTO kr_races VALUES (10,'골렘',1.000,1.000,1.150,1.100,1.000,1.200,0.850,1.000,1.100,1.150,1.000,0.850,2,2,1.300,1.000,2);


--
-- Dumping data for table `lottery`
--

INSERT INTO lottery VALUES (2,2,4336290);
INSERT INTO lottery VALUES (0,0,1096150320);
INSERT INTO lottery VALUES (0,1,1000000000);
INSERT INTO lottery VALUES (0,2,0);
INSERT INTO lottery VALUES (0,3,0);
INSERT INTO lottery VALUES (0,4,500000000);


--
-- Dumping data for table `market`
--



--
-- Dumping data for table `messages`
--



--
-- Dumping data for table `news`
--



--
-- Dumping data for table `players`
--

INSERT INTO players VALUES ('admin','21232f297a57a5a743894a0e4a801fc3','admin','admin@hanmail.net','61.74.155.230',1093120408,0,0,0,'8ecfc9094626c6bcd288195409a8ec77',0,0,0,1093120408,0,'admin',2,1,1,2,0,0,0,0,0,120,0,0,24980,100000,10000,500,100,15,10,0,100,0,500,0,0,25,25,25,25,250,0,0,0,0,0,0,0,250,10,0,0,5000,5000,5000,5000,100000,0,0,0,0,5,0,5,1093120408,1093120408,0,0,0,10000,100000,0,0,0,0,0);

-- Korean label update for current DB.
-- Run once in phpMyAdmin or mysql client if an existing database still shows English unit/race labels.

UPDATE en_eras SET name='1시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=1;
UPDATE en_eras SET name='2시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=2;
UPDATE en_eras SET name='3시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=3;

UPDATE kr_eras SET name='1시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=1;
UPDATE kr_eras SET name='2시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=2;
UPDATE kr_eras SET name='3시대', peasants='농민', food='곡물', runes='마나', armtrp='보병', lndtrp='투석기', flytrp='드래곤', seatrp='갤리온', wizards='마법사', homes='오두막', shops='시장', industry='대장간', barracks='성채', labs='마법탑', farms='농장', towers='방어탑', banks='은행', bartrp='야만인', mines='철광산', iron='철' WHERE id=3;

UPDATE en_races SET name='인간' WHERE id=1;
UPDATE en_races SET name='엘프' WHERE id=2;
UPDATE en_races SET name='드워프' WHERE id=3;
UPDATE en_races SET name='트롤' WHERE id=4;
UPDATE en_races SET name='노움' WHERE id=5;
UPDATE en_races SET name='그렘린' WHERE id=6;
UPDATE en_races SET name='오크' WHERE id=7;
UPDATE en_races SET name='다크엘프' WHERE id=8;
UPDATE en_races SET name='고블린' WHERE id=9;
UPDATE en_races SET name='골렘' WHERE id=10;

UPDATE kr_races SET name='인간' WHERE id=1;
UPDATE kr_races SET name='엘프' WHERE id=2;
UPDATE kr_races SET name='드워프' WHERE id=3;
UPDATE kr_races SET name='트롤' WHERE id=4;
UPDATE kr_races SET name='노움' WHERE id=5;
UPDATE kr_races SET name='그렘린' WHERE id=6;
UPDATE kr_races SET name='오크' WHERE id=7;
UPDATE kr_races SET name='다크엘프' WHERE id=8;
UPDATE kr_races SET name='고블린' WHERE id=9;
UPDATE kr_races SET name='골렘' WHERE id=10;
