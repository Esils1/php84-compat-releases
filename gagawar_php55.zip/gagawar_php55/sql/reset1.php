<?php
/*
 * reset1.php
 * PHP 5.5 compatible monthly reset runner for cron.
 * 위치: sql/reset1.php
 * 실행: php /절대경로/sql/reset1.php
 * 순서: 랭킹 저장 -> reset_tables.sql -> reset_data.sql
 */

$base_dir = realpath(dirname(__FILE__) . '/..');
$sql_dir = dirname(__FILE__);

if ($base_dir === false || !file_exists($base_dir . '/const.php')) {
    fwrite(STDERR, "const.php not found\n");
    exit(1);
}

require $base_dir . '/const.php';

if (!isset($dbhost) || !isset($dbuser) || !isset($dbname)) {
    fwrite(STDERR, "database settings not found in const.php\n");
    exit(1);
}
if (!isset($dbpass)) {
    $dbpass = '';
}

/* 1. 랭킹 저장 */
$ranking_script = $sql_dir . '/rankings1.php';
if (file_exists($ranking_script)) {
    $cmd = escapeshellcmd(PHP_BINARY) . ' ' . escapeshellarg($ranking_script);
    system($cmd, $rank_ret);
    if ($rank_ret !== 0) {
        fwrite(STDERR, "ranking save failed\n");
        exit(1);
    }
}

/* 2. DB 접속 */
$link = @mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$link) {
    fwrite(STDERR, "database connect failed\n");
    exit(1);
}
@mysqli_query($link, "SET NAMES utf8");

function run_sql_file_php55($link, $file)
{
    if (!file_exists($file)) {
        fwrite(STDERR, "sql file not found: " . $file . "\n");
        return false;
    }

    $sql = file_get_contents($file);
    if ($sql === false) {
        fwrite(STDERR, "cannot read sql file: " . $file . "\n");
        return false;
    }

    if (!mysqli_multi_query($link, $sql)) {
        fwrite(STDERR, "sql failed: " . $file . "\n" . mysqli_error($link) . "\n");
        return false;
    }

    do {
        if ($result = mysqli_store_result($link)) {
            mysqli_free_result($result);
        }
        if (mysqli_more_results($link)) {
            if (!mysqli_next_result($link)) {
                fwrite(STDERR, "sql failed: " . $file . "\n" . mysqli_error($link) . "\n");
                return false;
            }
        } else {
            break;
        }
    } while (true);

    return true;
}

if (!run_sql_file_php55($link, $sql_dir . '/reset_tables.sql')) {
    mysqli_close($link);
    exit(1);
}

if (!run_sql_file_php55($link, $sql_dir . '/reset_data.sql')) {
    mysqli_close($link);
    exit(1);
}

mysqli_close($link);
echo "reset complete\n";
exit(0);
?>
