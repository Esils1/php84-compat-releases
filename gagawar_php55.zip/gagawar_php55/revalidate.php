<?php
include("header.php");

mail($users[email],"가가전쟁 가입 - $config[servname] - $users[empire] (#$users[num])","
가가전쟁 - $config[servname] - 에 가입하신것을 축하합니다!
당신의 인증 코드는 $users[valcode] 입니다

http://www.digirave.net
","From: 가가전쟁 <$config[valemail]>\nX-Mailer: QM Promisance Automatic Validation Script");
TheEnd("당신의 인증 코드는 재발송되었습니다!");
?>
