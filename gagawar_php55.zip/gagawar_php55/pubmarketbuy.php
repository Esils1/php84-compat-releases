<?php
include("header.php");

if ($lockdb)
	TheEnd("열린 시장 기능이 꺼져있습니다!");

function buyUnits ($type)
{
	global $playerdb, $marketdb, $users, $uera, $buy, $buyprice, $datetime, $time;
	$amount = $buy[$type];
	fixInputNum($amount);
	$price = $buyprice[$type];
	fixInputNum($price);
	if ($amount == 0)				// did I specify a value?
		return;
	$market = mysql_fetch_array(mysql_query("SELECT * FROM $marketdb WHERE type='$type' AND price<=$price AND seller!=$users[num] AND time<=$time ORDER BY price ASC, time ASC LIMIT 1;"));
	if (!$market[amount])
		return;
	if ($market[price] < $price)
	{
		$price = $market[price];
		print "당신이 구경하고 있는 동안, 더 저렴한 $uera[$type] 이 사장에 도착했습니다!<br>\n";
		if ($amount > $market[amount])
			print "하지만 현재 ".commas($market[amount])." 만 구입 가능합니다.<br>\n";
	}
	if ($amount > $market[amount])
		$amount = $market[amount];
	if ($amount < 0)
		print "$uera[$type] 를 0 개 이하 구입할 수 없습니다!<br>\n";
	elseif ($amount * $price > $users[cash])
		print "$uera[$type] 를 그렇게 많이 살 돈이 부족합니다!<br>\n";
	else
	{
		$enemy = loadUser($market[seller]);
		$spent = $amount * $price;
		$sales = round($spent * .95);
		$users[cash] -= $spent;
		$enemy[cash] += $sales;
		$users[$type] += $amount;
		mysql_query("UPDATE $marketdb SET amount=(amount-$amount) WHERE id=$market[id];");
		mysql_query("DELETE FROM $marketdb WHERE amount=0;");
		print commas($amount)."개의 $uera[$type] 를 시장에서 구입했습니다. 비용: $".commas($spent).".<br>\n";
		switch ($type)
		{
		case food:	addNews(100,$users,$enemy,1,$amount,$spent,$sales);	break;
		case armtrp:	addNews(100,$users,$enemy,2,$amount,$spent,$sales);	break;
		case lndtrp:	addNews(100,$users,$enemy,3,$amount,$spent,$sales);	break;
		case flytrp:	addNews(100,$users,$enemy,4,$amount,$spent,$sales);	break;
		case seatrp:	addNews(100,$users,$enemy,5,$amount,$spent,$sales);	break;
		// Alpha Code
		case runes:		addNews(100,$users,$enemy,6,$amount,$spent,$sales);	break;
		case iron:		addNews(100,$users,$enemy,7,$amount,$spent,$sales);	break;
		}
		saveUserDataNet($enemy,"networth cash");
	}
}

function getCosts ($type)
{
	global $marketdb, $users, $costs, $avail, $canbuy, $time;
	$market = mysql_fetch_array(mysql_query("SELECT * FROM $marketdb WHERE type='$type' AND seller!=$users[num] AND time<=$time ORDER BY price ASC, time ASC LIMIT 1;"));
	if ($market[id])
	{
		$costs[$type] = $market[price];
		$avail[$type] = $market[amount];
		$canbuy[$type] = floor($users[cash] / $market[price]);
		if ($canbuy[$type] > $market[amount])
			$canbuy[$type] = $market[amount];
	}
	else	$costs[$type] = $avail[$type] = $canbuy[$type] = 0;
}

function printRow ($type)
{
	global $users, $uera, $costs, $avail, $canbuy;
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($users[$type])?></td>
    <td class="aright"><?php echo commas($avail[$type])?></td>
    <td class="aright"><input type="hidden" name="buyprice[<?php echo $type?>]" value="<?php echo $costs[$type]?>">$<?php echo commas($costs[$type])?></td>
    <td class="aright"><?php echo commas($canbuy[$type])?></td>
    <td class="aright"><input type="text" name="buy[<?php echo $type?>]" size="6" value="0"></td></tr>
<?php
}

if ($config[buymarket] == 0) {
	if ($users[turnsused] <= $config[protection])
		TheEnd("보호 받고 있는 동안 시장에서 거래할 수 없습니다!");
}


// for ($i = 0; $i < 5; $i++)
for ($i = 0; $i < 6; $i++)
	getCosts($trplst[$i]);
	getCosts($trplst[6]);
if ($do_buy)
{
//	for ($i = 0; $i < 5; $i++)
	for ($i = 0; $i < 6; $i++)
		buyUnits($trplst[$i]);
		buyUnits($trplst[6]);
	saveUserDataNet($users,"networth cash armtrp lndtrp flytrp seatrp food runes iron");
}
// for ($i = 0; $i < 5; $i++)
	for ($i = 0; $i < 6; $i++)
	getCosts($trplst[$i]);
	getCosts($trplst[6]);
?>
참고: <a href="<?php echo $config[main]?>?action=guide&amp;section=military&amp;era=<?php echo $users[era]?>">가가전쟁 설명서: 군대</a><br>
<form method="post" action="<?php echo $config[main]?>?action=pubmarketbuy">
<table class="inputtable">
<tr><td colspan="3"><a href="<?php echo $config[main]?>?action=pubmarketbuy">물건 구입하기</a></td>
    <td colspan="3" class="aright"><a href="<?php echo $config[main]?>?action=pubmarketsell">물건 판매하기</a></td></tr>
<tr><th class="aleft">대상</th>
    <th class="aright">소유</th>
    <th class="aright">구입 가능</th>
    <th class="aright">비용</th>
    <th class="aright">구매 가능</th>
    <th class="aright">구입</th></tr>
<?php
// for ($i = 0; $i < 5; $i++)
for ($i = 0; $i < 6; $i++)
	printRow($trplst[$i]);
	printRow($trplst[6]);
?>
<tr><td colspan="6" class="acenter"><input type="submit" name="do_buy" value="물건 구입하기"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
