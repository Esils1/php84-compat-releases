<?php
/*
 * PHP 5.5 compatible safe automatic turn runner.
 *
 * Fixes delayed/hidden turn backlog:
 * - elapsed turns are caught up in one request up to the maximum effective turn
 *   reservoir (maxturns + maxstoredturns), instead of only 3 intervals;
 * - any elapsed intervals beyond the maximum reservoir are discarded by advancing
 *   turn_last.dat to the current time, so maxed-out players do not receive old
 *   hidden turns after clicking another menu;
 * - turn_last.dat / turn_lock.dat are protected with flock() to prevent concurrent
 *   requests from generating duplicate turns.
 */
if (!defined('GAGAW_AUTO_TURN_RUNNING')) {
    define('GAGAW_AUTO_TURN_RUNNING', 1);

    $auto_turn_dir = dirname(__FILE__);
    $auto_turn_last_file = $auto_turn_dir . '/turn_last.dat';
    $auto_turn_lock_file = $auto_turn_dir . '/turn_lock.dat';
    $auto_turn_have_lock = false;
    $auto_turn_lock_fp = false;

    if (!function_exists('gagaw_auto_turn_cleanup')) {
        function gagaw_auto_turn_cleanup()
        {
            if (isset($GLOBALS['auto_turn_have_lock']) && $GLOBALS['auto_turn_have_lock']) {
                if (isset($GLOBALS['auto_turn_lock_fp']) && $GLOBALS['auto_turn_lock_fp']) {
                    @flock($GLOBALS['auto_turn_lock_fp'], LOCK_UN);
                    @fclose($GLOBALS['auto_turn_lock_fp']);
                }
                if (isset($GLOBALS['auto_turn_lock_file']) && $GLOBALS['auto_turn_lock_file']) {
                    @unlink($GLOBALS['auto_turn_lock_file']);
                }
            }
        }
    }
    @register_shutdown_function('gagaw_auto_turn_cleanup');

    $auto_turn_interval = 600;
    if (isset($perminutes) && intval($perminutes) > 0) {
        $auto_turn_interval = intval($perminutes) * 60;
    }
    if ($auto_turn_interval < 60) {
        $auto_turn_interval = 60;
    }

    $auto_turn_now = time();
    $auto_turn_last = 0;

    if (file_exists($auto_turn_last_file)) {
        $auto_turn_last = intval(trim(@file_get_contents($auto_turn_last_file)));
    }
    if ($auto_turn_last <= 0) {
        @file_put_contents($auto_turn_last_file, $auto_turn_now, LOCK_EX);
        $auto_turn_last = $auto_turn_now;
    }

    if (($auto_turn_now - $auto_turn_last) >= $auto_turn_interval) {
        $auto_turn_lock_age = file_exists($auto_turn_lock_file) ? ($auto_turn_now - @filemtime($auto_turn_lock_file)) : 999999;
        if ($auto_turn_lock_age > 120) {
            $auto_turn_lock_fp = @fopen($auto_turn_lock_file, 'c');
            if ($auto_turn_lock_fp && @flock($auto_turn_lock_fp, LOCK_EX | LOCK_NB)) {
                $auto_turn_have_lock = true;
                $GLOBALS['auto_turn_have_lock'] = true;
                $GLOBALS['auto_turn_lock_file'] = $auto_turn_lock_file;
                $GLOBALS['auto_turn_lock_fp'] = $auto_turn_lock_fp;
                @ftruncate($auto_turn_lock_fp, 0);
                @fwrite($auto_turn_lock_fp, (string)$auto_turn_now);
                @fflush($auto_turn_lock_fp);

                /* Re-read last turn time inside the lock; another request may have just updated it. */
                if (file_exists($auto_turn_last_file)) {
                    $auto_turn_last = intval(trim(@file_get_contents($auto_turn_last_file)));
                }
                if ($auto_turn_last <= 0) {
                    $auto_turn_last = $auto_turn_now;
                    @file_put_contents($auto_turn_last_file, $auto_turn_last, LOCK_EX);
                }

                if (($auto_turn_now - $auto_turn_last) >= $auto_turn_interval) {
                    $auto_turn_raw_count = floor(($auto_turn_now - $auto_turn_last) / $auto_turn_interval);
                    if ($auto_turn_raw_count < 1) $auto_turn_raw_count = 1;

                    $auto_turn_turnsper = isset($turnsper) ? intval($turnsper) : 1;
                    if ($auto_turn_turnsper < 1) $auto_turn_turnsper = 1;
                    $auto_turn_max_turns = (isset($config['maxturns']) ? intval($config['maxturns']) : 0);
                    $auto_turn_max_stored = (isset($config['maxstoredturns']) ? intval($config['maxstoredturns']) : 0);
                    if ($auto_turn_max_turns < 0) $auto_turn_max_turns = 0;
                    if ($auto_turn_max_stored < 0) $auto_turn_max_stored = 0;

                    /*
                     * The total useful turn reservoir is maxturns + maxstoredturns.
                     * Once that much has been awarded, further elapsed time must be lost,
                     * not stored as hidden backlog that appears after later menu clicks.
                     */
                    $auto_turn_effective_limit = (int)ceil(($auto_turn_max_turns + $auto_turn_max_stored + $auto_turn_turnsper) / $auto_turn_turnsper);
                    if ($auto_turn_effective_limit < 1) $auto_turn_effective_limit = 1;

                    $auto_turn_count = $auto_turn_raw_count;
                    $auto_turn_drop_backlog = false;
                    if ($auto_turn_count > $auto_turn_effective_limit) {
                        $auto_turn_count = $auto_turn_effective_limit;
                        $auto_turn_drop_backlog = true;
                    }

                    @ob_start();

                    for ($auto_turn_i = 0; $auto_turn_i < $auto_turn_count; $auto_turn_i++) {
                        $time = time();
                        $hour = date('H');
                        $min = date('i');

                        if (isset($lockdb) && $lockdb) {
                            @mysql_query("UPDATE $playerdb SET idle=$time");
                        } else {
                            @mysql_query("UPDATE $playerdb SET attacks=(attacks-1) WHERE attacks>0");

                            if ($min == $turnoffset) {
                                if ($hour == $config['aidhours']) {
                                    @mysql_query("UPDATE $playerdb SET aidcred=(aidcred+1) WHERE aidcred < " . intval($config['maxaid']));
                                    @mysql_query("UPDATE $playerdb SET aidget=(aidget-1) WHERE aidget >= 0");
                                }
                                @mysql_query("OPTIMIZE TABLE $lotterydb, $marketdb");
                                @mysql_query("UPDATE $playerdb SET vacation=(vacation+1) WHERE vacation>0");
                            }

                            @mysql_query("UPDATE $playerdb SET turns=(turns+$turnsper) WHERE vacation=0 AND disabled<=2");
                            @mysql_query("UPDATE $playerdb SET health=(health+1) WHERE health<100");
                            @mysql_query("UPDATE $playerdb SET health=100 WHERE health>100");
                            @mysql_query("UPDATE $playerdb SET turns=(turns+1),turnsstored=(turnsstored-1) WHERE vacation=0 AND disabled<=2 AND turnsstored>0");
                            @mysql_query("UPDATE $playerdb SET turnsstored=(turnsstored+(turns-" . $auto_turn_max_turns . ")),turns=" . $auto_turn_max_turns . " WHERE turns>" . $auto_turn_max_turns);
                            @mysql_query("UPDATE $playerdb SET turnsstored=" . $auto_turn_max_stored . " WHERE turnsstored>" . $auto_turn_max_stored);
                            @mysql_query("UPDATE $playerdb SET msgcred=(msgcred+1) WHERE msgcred < " . intval($config['maxmsg']));

                            @mysql_query("UPDATE $playerdb SET bmperarmtrp=(bmperarmtrp-(100*(1+shops/land))) WHERE bmperarmtrp > (100*(1+shops/land)) AND land>0");
                            @mysql_query("UPDATE $playerdb SET bmperlndtrp=(bmperlndtrp-(100*(1+shops/land))) WHERE bmperlndtrp > (100*(1+shops/land)) AND land>0");
                            @mysql_query("UPDATE $playerdb SET bmperflytrp=(bmperflytrp-(100*(1+shops/land))) WHERE bmperflytrp > (100*(1+shops/land)) AND land>0");
                            @mysql_query("UPDATE $playerdb SET bmperseatrp=(bmperseatrp-(100*(1+shops/land))) WHERE bmperseatrp > (100*(1+shops/land)) AND land>0");
                            @mysql_query("UPDATE $playerdb SET bmperarmtrp=0 WHERE bmperarmtrp < (100*(1+shops/land)) AND land>0");
                            @mysql_query("UPDATE $playerdb SET bmperlndtrp=0 WHERE bmperlndtrp < (100*(1+shops/land)) AND land>0");
                            @mysql_query("UPDATE $playerdb SET bmperflytrp=0 WHERE bmperflytrp < (100*(1+shops/land)) AND land>0");
                            @mysql_query("UPDATE $playerdb SET bmperseatrp=0 WHERE bmperseatrp < (100*(1+shops/land)) AND land>0");

                            @mysql_query("UPDATE $playerdb SET pmkt_armtrp=(pmkt_armtrp+(8*(land + barracks))) WHERE pmkt_armtrp < (250 * (land+(2 * barracks)))");
                            @mysql_query("UPDATE $playerdb SET pmkt_lndtrp=(pmkt_lndtrp+(5*(land + barracks))) WHERE pmkt_lndtrp < (200 * (land+(2 * barracks)))");
                            @mysql_query("UPDATE $playerdb SET pmkt_flytrp=(pmkt_flytrp+(3*(land + barracks))) WHERE pmkt_flytrp < (180 * (land+(2 * barracks)))");
                            @mysql_query("UPDATE $playerdb SET pmkt_seatrp=(pmkt_seatrp+(2*(land + barracks))) WHERE pmkt_seatrp < (150 * (land+(2 * barracks)))");
                            @mysql_query("UPDATE $playerdb SET pmkt_food=(pmkt_food+(50*(land + farms))) WHERE pmkt_food < (2000 * (land + farms))");

                            @mysql_query("UPDATE $playerdb SET online=0 WHERE idle<($time-(3600 / $perminutes))");
                            @mysql_query("UPDATE $playerdb SET idle=$time WHERE password='farm'");
                        }
                    }

                    /* Final cap pass protects databases that already contain over-limit values. */
                    @mysql_query("UPDATE $playerdb SET turnsstored=(turnsstored+(turns-" . $auto_turn_max_turns . ")),turns=" . $auto_turn_max_turns . " WHERE turns>" . $auto_turn_max_turns);
                    @mysql_query("UPDATE $playerdb SET turnsstored=" . $auto_turn_max_stored . " WHERE turnsstored>" . $auto_turn_max_stored);

                    $rank_q = @mysql_query("SELECT num FROM $playerdb ORDER BY networth DESC");
                    if ($rank_q) {
                        $urank = 0;
                        while ($rank_user = @mysql_fetch_array($rank_q)) {
                            $urank++;
                            @mysql_query("UPDATE $playerdb SET rank=$urank WHERE num=" . intval($rank_user['num']));
                        }
                    }

                    while (@ob_get_level() > 0) {
                        @ob_end_clean();
                    }

                    if ($auto_turn_drop_backlog) {
                        $auto_turn_new_last = $auto_turn_now;
                    } else {
                        $auto_turn_new_last = $auto_turn_last + ($auto_turn_count * $auto_turn_interval);
                        if ($auto_turn_new_last > $auto_turn_now) {
                            $auto_turn_new_last = $auto_turn_now;
                        }
                    }
                    @file_put_contents($auto_turn_last_file, $auto_turn_new_last, LOCK_EX);
                }

                $auto_turn_have_lock = false;
                $GLOBALS['auto_turn_have_lock'] = false;
                @flock($auto_turn_lock_fp, LOCK_UN);
                @fclose($auto_turn_lock_fp);
                $auto_turn_lock_fp = false;
                $GLOBALS['auto_turn_lock_fp'] = false;
                @unlink($auto_turn_lock_file);
            } elseif ($auto_turn_lock_fp) {
                @fclose($auto_turn_lock_fp);
            }
        }
    }


    /* Always enforce visible turn caps when this runner is loaded, even if no new interval is due. */
    $auto_turn_final_max_turns = (isset($config['maxturns']) ? intval($config['maxturns']) : 0);
    $auto_turn_final_max_stored = (isset($config['maxstoredturns']) ? intval($config['maxstoredturns']) : 0);
    if ($auto_turn_final_max_turns < 0) $auto_turn_final_max_turns = 0;
    if ($auto_turn_final_max_stored < 0) $auto_turn_final_max_stored = 0;
    @mysql_query("UPDATE $playerdb SET turnsstored=(turnsstored+(turns-" . $auto_turn_final_max_turns . ")),turns=" . $auto_turn_final_max_turns . " WHERE turns>" . $auto_turn_final_max_turns);
    @mysql_query("UPDATE $playerdb SET turnsstored=" . $auto_turn_final_max_stored . " WHERE turnsstored>" . $auto_turn_final_max_stored);
}
?>
