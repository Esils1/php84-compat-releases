<?php
include("header.php");

// clan.php
// (c) Quietust and Morvandium
// Last Revision: Jan 23 2002 by zEro


// Configuration for clan/clanless
if ($config[clans] == 0) 
	TheEnd("How do you got here? This is a clan<b>less</b> version!");

if ($users[disabled] == 2)	// are they admin?
	TheEnd("Cannot join clans as an admin!");
if ($users[clan])
{
	$uclan = loadClan($users[clan]);
	if ($do_removeself)
	{
		if ($users[allytime] > $time)
			TheEnd("죄송하지만 72 시간이 지나기 이전에 동맹을 떠날 수 없습니다");
		if ($uclan[founder] == $users[num])
		{
			$remuser = mysql_query("SELECT num,clan,forces,allytime FROM $playerdb WHERE clan=$uclan[num];");
			while ($enemy = mysql_fetch_array($remuser))
			{
				$enemy[clan] = $enemy[forces] = 0;
				saveUserData($enemy,"clan forces");
				addNews(117,$users,$enemy,0);
			}
			addNews(111,$users,$users,0);
			$uclan[members] = 0;
			saveClanData($uclan,"members");
			TheEnd("모든 구성원이 <b>$uclan[name]</b> 으로 부터 쫓겨났습니다.  잠시 후 동맹이 해체될 것입니다.");
		}
		else
		{
			$uclan[members]--;
			$users[clan] = 0;
			addNews(113,$users,loadUser($uclan[founder]),0);
			saveUserData($users,"clan");
			saveClanData($uclan,"members");
			TheEnd("당신은 <b>$uclan[name]</b> 으로 부터 쫓겨났습니다.");
		}
	}

	if ($do_useforces)
	{
		$users[forces] = 11;
		saveUserData($users,"forces");
		print "이제 당신은 동맹 구성원에게 군사 지원을 합니다.<br>\n";
	}
	if ($do_notuseforces)
	{
		$users[forces] = 10;
		saveUserData($users,"forces");
		print "당신의 군사는 2 시간 후 당신에게 사용 가능할 것입니다.<br>\n";
	}

	if ($uclan[founder] == $users[num])
	{
?>
<h3><a href="<?php echo $config[main]?>?action=clanmanage">동맹 관리하기</a></h3>
<?php
	}

	if ($uclan[url])
	{
?><a href="<?php echo $uclan[url]?>" target="_blank"><?php
	}
	if ($uclan[pic])
	{
?><img src="<?php echo $uclan[pic]?>" style="border:0" alt="$uclan[name] 동맹 홈페이지"><?php
	}
	elseif ($uclan[url])
	{
?><?php echo $uclan[name]?> 동맹 홈페이지<?php
	}
	if ($uclan[url])
	{
?></a><?php
	}
?>
<br>
<table class="inputtable">
<tr><th class="시기 <?php echo $users[era]?>">, 동맹 정보: <i><?php echo $uclan[tag]?></i></th></tr>
<tr><td class="acenter"><a href="<?php echo $config[main]?>?action=clanstats&amp;sort_type=avgnet">평균 총 재산에 의한 최고 동맹</a></th></tr>
<tr><td class="acenter"><a href="<?php echo $config[main]?>?action=clanstats&amp;sort_type=members">구성원수에 의한 최고 동맹</a></th></tr>
<tr><td class="acenter"><a href="<?php echo $config[main]?>?action=clanstats&amp;sort_type=totalnet">총 재산에 의한 최고 동맹</a></th></tr>
</table>
<form method="post" action="<?php echo $config[main]?>?action=clan">
<div>
<h3><?php echo $uclan[name]?> 관계</h3>
<table class="inputtable">
<tr><th style="width:50%"><span class="cgood">동맹</span><br>공격 불가<br>무한 지원</th>
    <th style="width:50%"><span class="cbad">전쟁</span><br>무한 공격/마법<br>지원 불가</th></tr>
<tr><td class="acenter"><?php echo $ctags["$uclan[ally1]"]?></td>
    <td class="acenter"><?php echo $ctags["$uclan[war1]"]?></td></tr>
<tr><td class="acenter"><?php echo $ctags["$uclan[ally2]"]?></td>
    <td class="acenter"><?php echo $ctags["$uclan[war2]"]?></td></tr>
<tr><td class="acenter"><?php echo $ctags["$uclan[ally3]"]?></td>
    <td class="acenter"><?php echo $ctags["$uclan[war3]"]?></td></tr>
</table><br>
<?php 	if ($users[forces] > 10)
	{ ?>
<table class="inputtable">
<caption><b>동맹 지원에 쓰이는 군사</b></caption>
<?php 	for($i=0;$i < 4; $i++)
	{
?>
<tr><th><?php echo $uera[$trplst[$i]]?></th>
    <td class="aright"><?php echo commas(round($users[$trplst[$i]] * 0.10))?></td></tr>
<?php
}
?>
</table>
<input type="submit" name="do_notuseforces" value="동맹 지원에 내 군사 사용하지 않기"><br>
<?php
	}
	else
	{
		if($users[forces] > 0)
		{ ?>
<b>동맹 지원에 사용되는 군사 (<?php echo ($users[forces] * 10)?> 분 동안.)</b>
<table class="inputtable">
<?php 	for($i=0;$i < 4; $i++)
	{
?>
<tr><th><?php echo $uera[$trplst[$i]]?></th>
    <td class="aright"><?php echo commas(round($users[$trplst[$i]] * 0.10))?></td></tr>
<?php
}
?>
</table> <?php
		}
?>
<input type="submit" name="do_useforces" value="내 군사를 동맹 지원에 사용하기"><br>
<?php
	}
?>
<?php echo $uclan[name]?> 는 <?php echo $uclan[members]?> 구성원을 가지고 있습니다.<br><br>
<table class="inputtable">
<caption><b>제국 목록</b></caption>
<tr><th>제국</th>
    <th>총 재산</th>
    <th>순위</th>
<?php //!!!???>
    <th>Sharing</th></tr>
<?php
	$list = mysql_query("SELECT empire,num,forces,rank,networth FROM $playerdb WHERE clan=$uclan[num];");
	while ($listclan = mysql_fetch_array($list))
	{
?>
<tr><td class="acenter"><?php echo $listclan[empire]?> (#<?php echo $listclan[num]?>)</td>
    <td class="aright">$<?php echo commas($listclan[networth])?></td>
    <td class="aright">#<?php echo $listclan[rank]?></td>
    <td class="acenter"><span class=<?php if ($listclan[forces]) print '"cgood">예'; else print '"cbad">아니오';?></span></td></tr>
<?php
	}
?>
</table>
<input type="submit" name="do_removeself" value="<?php if ($users[num] == $uclan[founder]) print "해체하기"; else print "탈퇴하기";?> Clan">
</div>
</form>
<?php
}
else
{
	if ($do_joinclan)
	{
		$uclan = loadClan($join_num);
		$password = md5($join_pass);
		if ($password == $uclan[password])
		{
			$users[clan] = $uclan[num];
			$users[forces] = 0;
			$users[allytime] = $time + 3600*72;
			saveUserData($users,"clan forces allytime");
			$uclan[members]++;
			saveClanData($uclan,"members");
			addNews(112,$users,loadUser($uclan[founder]),0);
			TheEnd("당신은 이제 $uclan[name]! 의 구성원 입니다");
		}
		else	TheEnd("암호가 틀렸습니다!");
	}
	if ($do_createclan)
	{
		if ($lockdb)
			TheEnd("게임이 시작하기 전에 동맹을 만들 수 없습니다!");
		if (($create_name == "") || ($create_tag == ""))
			TheEnd("동맹 이름 및 tag를 입력하셔야 합니다!");
		if ($create_tag == "None")
			TheEnd("잘못된 tag 이름입니다!");
		if (sqleval("SELECT COUNT(*) FROM $clandb WHERE tag='$create_tag';"))
			TheEnd("그 tag 은 이미 다른 동맹에 의해 사용되고 있습니다!");

		mysql_query("INSERT INTO $clandb (founder) VALUES ($users[num]);");
		$uclan = loadClan(mysql_insert_id());

		$uclan[name] = trim(HTMLSpecialChars($create_name));
		$uclan[tag] = trim(HTMLSpecialChars($create_tag));
		$uclan[password] = md5($create_pass);
		$uclan[pic] = $create_flag;
		$uclan[url] = $create_url;
		$uclan[motd] = "$create_name 에 오신 것을 환영합니다!";
		saveClanData($uclan,"name tag password pic url motd");
		$users[clan] = $uclan[num];
		$users[allytime] = $time + 3600*72;
		saveUserData($users,"clan allytime");
		addNews(110,$users,$users,0);
		TheEnd("$uclan[name] 동맹이 성공적으로 만들어졌습니다!");
	}
?>
이 메뉴에서 동맹을 가입할 수 있습니다.<br>
<form method="post" action="<?php echo $config[main]?>?action=clan">
<table class="inputtable">
<tr><th colspan="2">동맹 가입하기</th></tr>
<tr><td class="aright">동맹:</td>
    <td><select name="join_num" size="1">
<?php
$clanlist = mysql_query("SELECT num,name,tag FROM $clandb WHERE members>0 ORDER BY num;");
while ($clan = mysql_fetch_array($clanlist))
{
?>
        <option value="<?php echo $clan[num]?>"><?php echo $clan[tag]?> - <?php echo $clan[name]?></option>
<?php
}
?>
    </select></td></tr>
<tr><td class="aright">암호:</td>
    <td><input type="password" name="join_pass" size="8"></td></tr>
<tr><td colspan="2" class="acenter"><input type="submit" name="do_joinclan" value="동맹 가입하기"></td></tr>
</table>
<hr>
<table class="inputtable">
<tr><th colspan="2">동맹 만들기</th></tr>
<tr><td class="aright">동맹 Tag:</td>
    <td><input type="text" name="create_tag" size="8" maxlength="8"></td></tr>
<tr><td class="aright">암호:</td>
    <td><input type="password" name="create_pass" size="8" maxlength="16"></td></tr>
<tr><td class="aright">동맹 이름:</td>
    <td><input type="text" name="create_name" size="16" maxlength="32"></td></tr>
<tr><td class="aright">동맹 깃발 주소(URL):</td>
    <td><input type="text" name="create_flag" size="25"></td></tr>
<tr><td class="aright">동맹 홈페이지 주소(URL):</td>
    <td><input type="text" name="create_url" size="25"></td></tr>
<tr><td colspan="2" class="acenter"><input type="submit" name="do_createclan" value="동맹 만들기"></td></tr>
</table>
</form>
<br>
<a href="<?php echo $config[main]?>?action=clanstats&amp;sort_type=avgnet">평균 총 재산에 의한 최고 동맹</a><br>
<a href="<?php echo $config[main]?>?action=clanstats&amp;sort_type=totalnet">총 재산에 의한 최고 동맹</a><br>
<a href="<?php echo $config[main]?>?action=clanstats&amp;sort_type=members">구성원수에 의한 최고 동맹</a><br>
<?php
}
TheEnd("");
?>
