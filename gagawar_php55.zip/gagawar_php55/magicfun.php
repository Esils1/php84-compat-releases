<?php
include("spells.php");

// Stock functions for spell success/failure, so we don't have to edit them all individually
function SpellSucceed ($msg)
{
?>
마법 주문을 외웁니다... <span class="cgood">성공적이었습니다!</span><br>
<?php echo $msg?><br>
<?php
}

function SpellFail ()
{
	global $users, $uera, $wizloss;
?>
마법 주문을 외웠지만 <span class="cbad">실패했습니다!</span><br>
<?php echo $wizloss?> <?php echo $uera[wizards]?> 이 마법의 부작용으로 사망합니다!<br>
<?php
	$users[wizards] -= $wizloss;
}

function SpellShielded ()
{
?>
<span class="cwarn">...마법이 일부 막아진 듯합니다.</span><br>
<?php
}

function printMRow ($num)
{
	global $spname, $sptype, $spcost, $uera;
?>
        <option value="<?php echo $num?>"><?php echo $spname[$num]?> (<?php echo commas($spcost[$num])?> <?php echo $uera[runes]?>) <?php if ($sptype[$num] == d) echo "(자기 자신)"?></option>
<?php
}

// Here you add the costs for the spells.
// Coders: Here you add the new spells

function setspcost()
{	
	global $users, $urace, $sptype, $spcost;
	// this chunk sets the costs of spells
	// array was created so that it's easier to reference
	$manabase = (($users[land] * .1) + ($users[labs] * .2) * $urace[magic]) + 100;
	// sptype is "o" for offense, "d" for defense
	$spcost[1]  = ceil($manabase *  1.00);	$sptype[1] = "o";	// Crystal Ball
	$spcost[2]  = ceil($manabase *  2.50);	$sptype[2] = "o";	// Fireball
	$spcost[3]  = ceil($manabase *  4.90);	$sptype[3] = "d";	// Spell Shield
	$spcost[4]  = ceil($manabase *  7.25);	$sptype[4] = "o";	// Storms
	$spcost[5]  = ceil($manabase *  9.50);	$sptype[5] = "o";	// Lightning Strike
	$spcost[6]  = ceil($manabase * 17.00);	$sptype[6] = "d";	// Tree of Gold
	$spcost[7]  = ceil($manabase * 18.00);	$sptype[7] = "o";	// Wrath of Demons
	$spcost[8]  = ceil($manabase * 25.75);	$sptype[8] = "o";	// Embezzlement
	$spcost[9]  = ceil($manabase * 22.75);	$sptype[9] = "o";	// Magic User Fight
	$spcost[10] = ceil($manabase * 4.90);	$sptype[10] = "d";	// Open Time Gate
	$spcost[11] = ceil($manabase * 5.90);	$sptype[11] = "d";	// Close Time Gate
	$spcost[12] = ceil($manabase * 47.50);	$sptype[12] = "d";	// Advance
	$spcost[13] = ceil($manabase * 30.55);	$sptype[13] = "d";	// Emminent Domain
	$spcost[14] = ceil($manabase * 20.31);	$sptype[14] = "d";	// Heal
	$spcost[15]  = ceil($manabase * 17.00);	$sptype[15] = "d";	// Horn of Plenty (food Tog)
}

function setspnames()
{
	global $spname, $users;
	if ($users[era] == 1)
	{
		$spname[12] = "제 2 세대로 발전하기";
	}
	elseif ($users[era] == 2)
	{
		$spname[12] = "제 3 세대로 발전하기";
	}
	elseif ($users[era] == 3)
	{
		$spname[12] = "";
	}
	$spname[1] = "마법의 수정구";
	$spname[2] = "화이어 볼";
	$spname[3] = "마법의 방어막";
	$spname[4] = "폭풍";
	$spname[5] = "번개";
	$spname[6] = "금의 나무";
	$spname[7] = "악마의 분노";
	$spname[8] = "도둑질";	
	$spname[9] = "마법 공격";
	$spname[10] = "시간의 문 열기";	
	$spname[11] = "시간의 문 닫기";
	$spname[14] = "치료";
	$spname[13] = "Emminent Domain";
// Here you add the next spell name ;)
	$spname[15] = "풍부의 뿌리";
		
	if ($users[turnsused] < 500 * $users[era])
		$spname[12] = "";
}
setspcost();
setspnames();
if ($do_spell)
{
	if ($spell_num == 0)
		TheEnd("마법을 선택하셔야합니다!");

// Turns Hack - According to Race!
// Changed to be used on the db

		if ($users[turns] < $urace[mturns])
		TheEnd("턴이 부족합니다!");

	if ($users[runes] < $spcost["$spell_num"])
		TheEnd("$uera[runes] 이 부족합니다!");
	if ($users[health] < 20)
		TheEnd("건강이 나빠서, 마법사들이 마법을 걸지 못합니다.");

	if ($sptype["$spell_num"] == o)			// offense spell?
	{
		if (!$target)
			TheEnd("대상자를 선택해야합니다!");
		if ($target == $users[num])
			TheEnd("자기 자신을 공격할 수 없습니다!");
		$enemy = loadUser($target);
		if ($enemy[num] != $target)
			TheEnd("그런 제국은 존재하지 않습니다!");
		$erace = loadRace($enemy[race]);
		$eera = loadEra($enemy[era]);

		if (($enemy[land] == 0) || ($enemy[land] < 0))
			TheEnd("그 제국은 멸망했습니다!");
		if (($users[clan] > 0) && ($users[clan] == $enemy[clan]))
			TheEnd("당신의 동맹의 구성원ㅇ 공격할 수 없습니다!");
		if ($enemy[disabled] >= 2)
			TheEnd("정지 당한 제국에 마법을 사용할 수 없습니다!");
		if ($enemy[turnsused] <= $config[protection])
			TheEnd("보호 받고 있는 제국에 마법을 사용할 수 없습니다!");
		if ($enemy[vacation] > $config[vacationdelay])
			TheEnd("그 제국은 현재 여행 모드입니다!");
		if (($enemy[era] != $users[era]) && ($users[gate] <= $time) && ($enemy[gate] <= $time))
			TheEnd("시간의 문을 먼저 열어야합니다!");

		$uclan = loadClan($users[clan]);
		$warflag = 0;
		$netmult = 10;
		if ($enemy[clan])
		{
			if ($users[clan] == $enemy[clan])
				TheEnd("당신의 동맹 구성원을 공격할 수 없습니다!");
			if (($uclan[ally1] == $enemy[clan]) || ($uclan[ally2] == $enemy[clan])|| ($uclan[ally3] == $enemy[clan]))
				TheEnd("당신의 장군들은 동맹 구성원을 공격하라는 명령어를 그냥 무시합니다.");
			if (($uclan[war1] == $enemy[clan]) || ($uclan[war2] == $enemy[clan])|| ($uclan[war3] == $enemy[clan]))
			{
				$warflag = 1;
				$netmult = 30;
			}
		}


		if ($spell_num != 1)
		{
			if ($enemy[networth] > $users[networth] * $config[nonattack])
				TheEnd("당신의 $uera[wizards] 는 그렇게 강한 상대를 공격하는 것을 노골적으로 거부합니다!");
			if ($users[networth] > $enemy[networth] * $config[nonattack])
				TheEnd("당신의 $uera[wizards] 는 그렇게 약한 상대를 공격하는 것을 정중히 거부합니다!");

			if ($warflag == 0)
			{
//!!!S
				if ($enemy[attacks] > 2)
//!!!E
					TheEnd("그 제국은 너무 많은 공격을 받았습니다. 6 분 이후에 다시 시도하시길 바랍니다.");
				$revolt = 1;
				if ($users[networth] > $enemy[networth] * $config[shamemult])
				{				// Shame is less powerful than fear
?><span class="cwarn">당신의 <?php echo $uera[wizards]?> 는 그렇게 강한 상대를 공격하는 것을 경악해합니다. 많은 이들이 떠납니다!</span><br>
<?php 					$revolt = 1 - $users[networth] / $enemy[networth] / 125;
				}
				elseif ($enemy[networth] > $users[networth] * $config[shamemult])
				{
			{
?><span class="cwarn">당신의 <?php echo $uera[wizards]?> 는 그렇게 약한 상대를 공격하는 것을 슬퍼합니다. 많은 이들이 떠납니다!</span><br>
<?php 				$revolt = 1 - $users[networth] / $enemy[networth] / 100;
			}
				if ($revolt < .9)
					$revolt = .9;
				$users[wizards] = ceil($users[wizards] * $revolt);
			}
			if ($warflag == 0)
				$enemy[attacks]++;
			$users[attacks] -= 1;
			if ($users[attacks] < 0) $users[attacks] = 0;
			$users[health] -= 4;
 			$users[offtotal]++;
 			$enemy[deftotal]++;
 		}

			$users[offtotal]++;
			$enemy[deftotal]++;
		}
								// for offense, wizards/avgland
		$uratio = $users[wizards] / (($users[land] + $enemy[land]) / 2) * $urace[magic];
		$eratio = $enemy[wizards] / $enemy[land] * 1.05 * $erace[magic];
	}
	if ($users[labs])					// for defense, wizards/towers
		$lratio = $users[wizards] / $users[labs] * $urace[magic];
	else	$lratio = 0;

	// lose 1%-5% of your wizards if spell fails
	$wizloss = mt_rand(ceil($users[wizards] * .01),ceil($users[wizards] * .05 + 1));
	if ($wizloss > $users[wizards])
		$wizloss = $users[wizards];

	if ((1 <= $spell_num) && ($spell_num <= 15))
	{
		if ($enemy[shield] > $time)
			$shmod = 1/3;
		else	$shmod = 1;
		CastSpell($spell_num);
	}
	$users[runes] -= $spcost["$spell_num"];
	saveUserData($users,"attacks offsucc offtotal kills");
	if ($enemy[num])
		saveUserData($enemy,"attacks defsucc deftotal");
	
// Second Turns Hack!
// v1.0b - Using MySQL instead of code :P
// zEro

		takeTurns($urace[mturns],magic);
}
?>
