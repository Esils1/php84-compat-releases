<?php
include("header.php");

function sendUnits ($type)
{
	global $users, $uera, $enemy, $eera, $send, $cansend, $mesg;
	fixInputNum($send[$type]);
	$amount = $send[$type];
	if ($amount == 0)
		return;
	elseif ($amount < 0)
		TheEnd("당신은 0 보다 적은 수의 $uera[$type] 를 보낼 수 없습니다!");
	elseif ($amount > $users[$type])
		TheEnd("당신은 그렇게 많은 $uera[$type] 를 가지고 있지 않습니다!");
	elseif ($amount > $cansend[$type])
		TheEnd("당신은 $uera[$type] 의 20% 이상을 보낼 수 없습니다!");
	else
	{

// takes the aidtax :)
// - zEro
		$amount1 = $amount * $config[aidtax];
		$amount = $amount - $amount1;

		$users[$type] -= $amount;
		$enemy[$type] += $amount;
		if ($type == seatrp)
			;
		elseif ($type == cash)
			$mesg .= "$".commas($amount)."<br>";
		else	$mesg .= commas($amount)." $eera[$type]<br>";
	}
}

function printRow ($type)
{
	global $users, $uera, $cansend, $convoy;
?>
<tr><td><?php if ($type == cash) echo "돈"; else echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($users[$type])?></td>
    <td class="aright"><?php echo commas($cansend[$type])?></td>
    <td class="aright"><input type="text" name="send[<?php echo $type?>]" size="8" value="<?php if ($type == seatrp) echo $convoy; else echo 0;?>"></td></tr>
<?php
}

if ($users[turnsused] <= $config[protection])
	TheEnd("보호 받고 있는 동안 동맹 지원을 보낼 수 없습니다!");
if ($users[aidcred] == 0)
	TheEnd("더 많은 지원을 보낼 수 없습니다!");

// Anti Cheating protection

if ($config[aid_ac] == 1) {
	if ($users[aidget] > 0)
		TheEnd("오늘 지우너 받았기 때문에 또 지원할 수 없습니다!"); 
}

$convoy = 2 * floor($users[networth] / 10);

// Now you need at least 5% of your land filled with markets
// - zEro

$markets_need = floor($users[land] * .05);

for ($i = 0; $i < 4; $i++)
	$cansend[$trplst[$i]] = round($users[$trplst[$i]] * .20);
$cansend[cash] = round($users[cash] * .20);
$cansend[runes] = round($users[runes] * .20);
$cansend[food] = round($users[food] * .20);
$cansend[iron] = round($users[iron] * .20);

if ($do_sendaid)
{
	if ($users[turns] < $urace[aidturns])
		TheEnd("턴이 부족합니다!");
	if (!$dest)
		TheEnd("제국을 선택해야합니다!");
	if ($dest == $users[num])
		TheEnd("자기한테 지원을 보낼 수 없습니다!");
	if ($users[seatrp] < $convoy)
		TheEnd("$uera[seatrp]를 충분히 가지고 있지 않습니다!");
	if ($users[shops] < $markets_need)
		TheEnd("당신은 최소 $markets_need 개의 $uera[shops] 를 가지고 있지 않습니다");
	fixInputNum($send[seatrp]);
	if ($send[seatrp] < $convoy)
		TheEnd("당신은 최소 $convoy 개의 $uera[seatrp] 를 보내야합니다!");

	$enemy = loadUser($dest);
	$eera = loadEra($enemy[era]);

// Two new lines for the new code.

//	$bankuser = loadUser($config[banknum]);
//	$bank_era = loadEra($bankuser[era]);	

	if ($enemy[num] != $dest)
		TheEnd("그런 제국은 존재하지 않습니다!");
	if (($enemy[era] != $users[era]) && ($enemy[gate] <= $time) && ($users[gate] <= $time))
		TheEnd("시간의 문을 먼저 열어야합니다!");
	if ($enemy[disabled] >= 2)
		TheEnd("정지 당한 제국한테 지원을 보낼 수 없습니다!");
// Anti Cheating Protection
	if ($config[aid_ac] == 1) {
		if (($enemy[aidget] > 0) && ($enemy[aidget] < $config[maxaidget]))
			TheEnd("$enemy[empire] (#$enemy[num]) 이 $config[maxaidget] 지원을 받았기 때문에 지원을 더 보낼 수 없습니다!");
		if ($enemy[aidcred] < $config[maxaid])
			TheEnd("$config[aidhours] 동안 지원을 보낸 사람에게 지원을 보낼 수 없습니다!");
	}
	if ($enemy[turnsused] <= $config[protection])
		TheEnd("보호 받고 있는 제국에게 지원을 보낼 수 없습니다!");
	if ($enemy[vacation] > $config[vacationdelay])
		TheEnd("여행 모드로 설정된 제국에게 지원을 보낼 수 없습니다!");
	if ($enemy[networth] > ($users[networth] * $config[nonaid]))
		if ($config[nonaid] > 1)
			TheEnd("당신의 지원을 받기에 그 제국은 너무 큽니다!");
		if ($config[nonaid] < 1)
			TheEnd("당신의 제국과 총 재산이 너무 비슷하기 때문에 지원을 보낼 수 없습니다!");

	$uclan = loadClan($users[clan]);
	if ($enemy[clan])
	{
		if (($uclan[war1] == $enemy[clan]) || ($uclan[war2] == $enemy[clan])|| ($uclan[war3] == $enemy[clan]))
			TheEnd("적에게 지원을 보내겠다는 당신의 말에 장군들이 비웃습니다.");
		if (($users[clan] == $enemy[clan]) || ($uclan[ally1] == $enemy[clan]) || ($uclan[ally2] == $enemy[clan]) || ($uclan[ally3] == $enemy[clan]))
			$users[aidcred]++;	// unlimited aid to allies
	}


	sendUnits(seatrp);	// MUST do this first
	for ($i = 0; $i < 3; $i++)
		sendUnits($trplst[$i]);
	sendUnits(cash);
	sendUnits(runes);
	sendUnits(food);
	sendUnits(iron);

	addNews(120,$users,$enemy,$send[seatrp],$send[armtrp],$send[lndtrp],$send[flytrp],$send[cash],$send[runes],$send[food],$send[aid]);
	$users[aidcred]--;
	saveUserDataNet($users,"networth armtrp lndtrp flytrp seatrp cash runes food aidcred iron");
	saveUserDataNet($enemy,"networth armtrp lndtrp flytrp seatrp cash runes food aidget iron");

// Beta code

//	saveUserDataNet($bankuser,"networth cash armtrp lndtrp flytrp seatrp runes food iron");

	// New turns for aiding :)

	takeTurns($urace[aidturns],aid);
?>
<?php echo commas($send[seatrp])?> <?php echo $uera[seatrp]?> have departed with shipment to <b><?php echo $enemy[empire]?> (#<?php echo $enemy[num]?>)</b>
<hr>
<?php
$convoy = 2 * floor($users[networth] / 10);

// Now you need at least 5% of your land filled with markets
// - zEro

$markets_need = floor($users[land] * .05);

	for ($i = 0; $i < 4; $i++)
		$cansend[$trplst[$i]] = round($users[$trplst[$i]] * .20);
	$cansend[cash] = round($users[cash] * .20);
	$cansend[runes] = round($users[runes] * .20);
	$cansend[food] = round($users[food] * .20);
	$cansend[iron] = round($users[iron] * .20);
}
?>

<?php 

// Configuration so you can or can't aid.

if ($config[canaid] == 0)
	TheEnd("이 게임에서 지원을 보낼 수 없습니다!");
		
?>

동맹 지원을 보내려면 최소 <?php echo $urace[aidturns]?> 턴이 필요하며 최소 <?php echo $convoy?> <?php echo $uera[seatrp]?> 이 필요하다<br>
세계 세금 정책에 의해 <?php $test = $config[aidtax] * 100; print "$test";?>% 지원금 세금을 내야합니다.<br>
그리고 최소 <?php echo $markets_need?> 시장이 필요합니다.<br>
우리는 <?php echo $users[aidcred]?> 까지 보낼 수 있습니다.<br>
그리고 매시간 한번 더 보낼 수 있습니다.<br><br>
<form method="post" action="<?php echo $config[main]?>?action=aid">
<table class="inputtable">
<tr><td colspan="3" class="aright">어느 제국에 보내겠습니까?</td>
    <td><input type="text" name="dest" size="6"></td></tr>
<tr><th class="aleft">유닛</th>
    <th class="aright">보유</th>
    <th class="aright">보내기 가능한가</th>
    <th class="aright">보내기</th></tr>
<?php
for ($i = 0; $i < 3; $i++)
	printRow($trplst[$i]);
printRow(cash);
printRow(runes);
printRow(food);
printRow(iron);
?>
<tr><td colspan="4" class="acenter"><input type="submit" name="do_sendaid" value="지원군 보내기"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
