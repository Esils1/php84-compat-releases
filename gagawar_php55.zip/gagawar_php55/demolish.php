<?php
include("header.php");

$destroyrate = round(($users[land] * 0.02) + 2);
//if ($destroyrate > 400)	$destroyrate = 400;
$destroyrate = floor($urace[bpt] * $destroyrate);
$salvage = round(($config[buildings] + ($users[land] * .1)) / 5);

$totbuildings = $users[land] - $users[freeland];

function getDestroyAmount ($type)
{
	global $config, $users, $candestroy, $destroyrate;
	$candestroy[$type] = $destroyrate * $users[turns];
	if ($candestroy[$type] > $users[$type]) $candestroy[$type] = $users[$type];
	$candestroy[all] += $candestroy[$type];
	if ($candestroy[all] > $users[turns] * $destroyrate)
		$candestroy[all] = $users[turns] * $destroyrate;
}

function destroyStructures ($type, $salvage)
{
	global $users, $demolish, $candestroy, $totaldestroyed, $totalsalvaged;
	fixInputNum($demolish[$type]);
	$amount = $demolish[$type];
	if ($amount < 0)
		TheEnd("0 보다 적은 숫자의 구조물을 파괴할 수 없습니다!");
	if ($amount > $candestroy[$type])
		TheEnd("그렇게 많이 가지고 있지 않습니다!");
	$users[$type] -= $amount;
	if ($type == land)
		$users[freeland] -= $amount;
	else
	{
		$users[freeland] += $amount;
		$totaldestroyed += $amount;
	}
	$users[cash] += $amount * $salvage;
	$totalsalvaged += $amount * $salvage;
}

function printRow ($type)
{
	global $users, $uera, $candestroy;
?>
<tr><td><?php echo $uera[$type]?></td>
    <td class="aright"><?php echo commas($users[$type])?></td>
    <td class="aright"><?php echo commas($candestroy[$type])?></td>
    <td class="aright"><input type="text" name="demolish[<?php echo $type?>]" size="5" value="0"></td></tr>
<?php
}

getDestroyAmount(homes);
getDestroyAmount(shops);
getDestroyAmount(industry);
getDestroyAmount(barracks);
getDestroyAmount(labs);
getDestroyAmount(farms);
getDestroyAmount(towers);
getDestroyAmount(banks);
getDestroyAmount(mines);
$candestroy[land] = $users[freeland];
if ($do_demolish)
{
	destroyStructures(homes,$salvage);
	destroyStructures(shops,$salvage);
	destroyStructures(industry,$salvage);
	destroyStructures(barracks,$salvage);
	destroyStructures(labs,$salvage);
	destroyStructures(farms,$salvage);
	destroyStructures(towers,$salvage);
	destroyStructures(banks,$salvage);
	destroyStructures(mines,$salvage);
	destroyStructures(land,0);

	$turns = ceil($totaldestroyed / $destroyrate);
	if ($users[turns] < $turns)
		TheEnd("Not enough turns!");
	saveUserData($users,"homes shops industry barracks labs farms towers land freeland cash mines banks");
	takeTurns($turns,demolish);
?>
당신은 <?php echo commas($totaldestroyed)?> 구조물을 <?php echo $turns?> 턴 동안 파괴하고 $<?php echo commas($totalsalvaged)?> 를 얻습니다.<hr>
<?php
	getDestroyAmount(homes);
	getDestroyAmount(shops);
	getDestroyAmount(industry);
	getDestroyAmount(barracks);
	getDestroyAmount(labs);
	getDestroyAmount(farms);
	getDestroyAmount(towers);
	getDestroyAmount(banks);
	getDestroyAmount(mines);
	$candestroy[land] = $users[freeland];
}
?>
<a href="<?php echo $config[main]?>?action=guide&amp;section=structures&amp;era=<?php echo $users[era]?>">가가전쟁 설명서: 구조물</a><br><br>
각 구조물의 파괴는 1 땅을 사용 가능하게 하며 $<?php echo commas($salvage)?> 돈을 얻습니다.<br>
우리는 턴당 <?php echo commas($destroyrate)?> 구조물을 파괴할 수 있습니다.<br>
우리의 자원으로는 <span class="cbad"><?php echo commas($candestroy[all])?></span> 구조물을 파괴할 수 있습니다.<br><br>
<form method="post" action="<?php echo $config[main]?>?action=demolish">
<table class="inputtable">
<tr><th class="aleft">구조물</th>
    <th class="aright">보유</th>
    <th class="aright">파괴 가능한</th>
    <th class="aright">파괴</th></tr>
<?php
printRow(shops);
printRow(homes);
printRow(barracks);
printRow(industry);
printRow(labs);
printRow(farms);
printRow(towers);
printRow(banks);
printRow(mines);

?>
<tr><td>사용하지 않는 땅은 버리기</td>
    <td class="aright"><?php echo commas($users[freeland])?></td>
    <td class="aright"><?php echo commas($candestroy[land])?></td>
    <td class="aright"><input type="text" name="demolish[land]" size="5" value="0"></td></tr>
<tr><td colspan="4" class="acenter"><input type="submit" name="do_demolish" value="파괴하기"></td></tr>
</table>
</form>
<a href="<?php echo $config[main]?>?action=build">구조물 짓기</a>
<?php
TheEnd("");
?>
