<?php
include("header.php");

if ($users[era] == 1) { $rev = "53%"; }
if ($users[era] == 2)
	$rev = "15%";
if ($users[era] == 3)
	$rev = "25%";

if ($do_farm)
{
	fixInputNum($farm_turns);
	if ($farm_turns < 0)
		TheEnd("0 보다 적은 턴 동안 농사를 지을 수 없습니다!");
	if ($farm_turns > $users[turns])
		TheEnd("턴이 부족합니다!");
	$turns = takeTurns($farm_turns,farm);
?>
당신으 총 <?php echo commas($foodgained)?> <?php echo $uera[food]?> 을 <?php echo $turns?> 턴 동안 얻습니다.<hr>
<?php
}
?>
<form method="post" action="<?php echo $config[main]?>?action=farm">
<center>농사를 하는동안 <?php echo $rev?> 를 매턴 얻습니다.</center>
<table class="inputtable">
<tr><td>몇 턴 동안 농사를 짓겠습니까?</td>
    <td><input type="text" name="farm_turns" size="5" value="0"></td></tr>
<tr><td colspan="2" class="acenter"><input type="submit" name="do_farm" value="농사 짓기"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
