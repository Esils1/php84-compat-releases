<?php
include("header.php");

if ($users[era] == 1) { $rev = "25%"; }
if ($users[era] == 2)
	$rev = "53%";
if ($users[era] == 3)
	$rev = "15%";

if ($do_cash)
{
	fixInputNum($cash_turns);
	if ($cash_turns < 0)
		TheEnd("0 이하의 턴 동안 돈 모으기를 할 수 없습니다!");
	if ($cash_turns > $users[turns])
		TheEnd("턴이 부족합니다!");
	$turns = takeTurns($cash_turns,cash);
?>
당신은 총 $<?php echo commas($cashgained)?> 을 <?php echo $turns?> 턴 동안 얻습니다.<hr>
<?php
}
?>
<form method="post" action="<?php echo $config[main]?>?action=cash">
<center>돈 모으기를 하면 턴당 <?php echo $rev?> 를 얻습니다.</center>
<table class="inputtable">
<tr><td>몇 턴 동안 돈 모으기를 하겠습니까?</td>
    <td><input type="text" name="cash_turns" size="5" value="0"></td></tr>
<tr><td colspan="2" class="acenter"><input type="submit" name="do_cash" value="돈 모으기"></td></tr>
</table>
</form>
<?php
TheEnd("");
?>
