<?php
include("header.php");
?>
<a href="http://digirave.net" target="_top">한글판 가가전쟁 by: Digirave</a>, Copyright &copy; 2004 by <a href="mailto:gagaspace@hanmail.net">digirave</a><br>
원작: <a href="http://www.madeinphp.com/" target="_blank">Enhanced Promisance</a>&trade; v<?php echo $version?> - Copyright &copy; 2001 by <a href="mailto:zero_skape%20at%20yahoo.com">zEro</a><br>
Took from: <a href="http://qm.ath.cx/" target="_blank">QM Promisance</a>&trade; v3.0 - Copyright &copy; 2001 by <a href="mailto:quietust@ircN.org">The Quietust</a> &amp; <a href="mailto:lord_of_fire1@yahoo.com">Morvandium</a><br>
<hr>
QM Promisance code written by <a href="mailto:quietust@ircn.org">The Quietust</a> and <a href="mailto:lord_of_fire1@yahoo.com">Morvandium</a><br>
Based on code from <a href="http://prom.ezclan.net">EZClan Promisance</a>, by <a href="mailto:Inferno@ezclan.com">Tom Finnell</a> and <a href="mailto:mambo@usimp.com">Jordan Heine</a><br>
Based on the original <a href="http://www.netwurx.net/~ppurgett/">Promisance</a>, by <a href="mailto:ppurgett@netwurx.net">PC Purgett</a><br>
<hr>
Promisance Enhanced Coders (alphabetical order):<br>
<a href="ssayan3%20at%20hotmail.com">gzip</a>
<hr>
Alpha/Beta Testers (in alphabetical order) for Promisance Enhanced:<br>
Arghan,
<a href="darrian@swirve.com">Darrian</a>,
Darkone,
Electric Uncle Sam,
killerwolf,
<a href="Striker71@swirve.com">Mr. Kid</a>,
<a href="rayzer@hotmail.com">RayZer</a>,
Ronan,
<a href="samimahamed@hotmail.com">SaMi</a>,
<a href="surgstriker@yahoo.com">SurgicalStriker</a>,
<a href="DragoonX@swirve.com">Tassador</a>

<br><br>Alpha/Beta Testers (in alphabetical order) for QM Promisance:<br>
<a href="mailto:devlyn@zonnel.nl">Devlyn</a>, 
<a href="mailto:panteraicp@hotmail.com">General Galaf</a>,
<a href="mailto:g8rpic@yahoo.com">Lady Gwendolyn</a>,
<a href="mailto:hetchman@hotmail.com">Archbishop Hetchman</a>,
The High Priest,
<a href="mailto:row119@hotmail.com">Leaping Frogs</a>,
Leaijrn, 
<a href="mailto:Richard.jr1@excite.com">Starion</a>,
<a href="mailto:boston_fan@hotmail.com">Swest</a>, 
<a href="mailto:Baloo4321@hotmail.com">Dark Templar</a>,
<a href="mailto:thorin.mcgee@wanadoo.nl">Thorin</a>,
<a href="mailto:thrust@w00t-plaza.com">Thrustaevis</a>,
<a href="mailto:dwwest@dwwest.screaming.net">Woody</a>,
<a href="mailto:zero_skape@yahoo.com">zEro</a>.<br>
<?php
TheEnd("");
?>
